#!/usr/bin/env python3
"""EightMax 5.17: the independent best-response check of 4.8 (independent_br48.py: its own tree, its own seven-card
evaluator, its own pot settlement, every turn and river card enumerated; no code shared with the engine) applied to
request method exact-hu instead of method exact.

usage: independent_brhu517.py <mwcli> <spec.json> <state> [tolerance=1e-9]
prints the JSON report of independent_br48.py; exit 0 when every seat agrees with `mwcli --gain` (method exact-hu).
Only studies with Exact cards (independent_br48.py reads rows by range index and public cards), two seats, chip EV.

The checker's text is taken from independent_br48.py with one change: the request it sends to the engine."""
import pathlib, sys
src = (pathlib.Path(__file__).resolve().parent / 'independent_br48.py').read_text()
old = "json.dump({'method': 'exact', 'timeLimitMs': 3600000, 'maxVisits': 2000000000}, q)"
assert src.count(old) == 1, 'independent_br48.py changed: its request line was not found'
exec(compile(src.replace(old, "json.dump({'method': 'exact-hu', 'timeLimitMs': 3600000, 'memoryMiB': 2048}, q)"), 'independent_br48.py (request: exact-hu)', 'exec'))
