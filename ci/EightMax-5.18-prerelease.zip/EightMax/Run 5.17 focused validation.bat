@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.17 focused validation on this Windows PC: the exact best response of heads-up studies, and the checks of 5.11 to 5.16.
echo   - method exact-hu (brhu-5.17-v1) on the CPU: the bits recorded on Linux for twelve heads-up studies (ranges of
echo     10 to 1176 hands a seat), every thread count, agreement with method exact, refusals
echo   - the same on the GPU of this PC through its OpenCL driver: the bits of the CPU, every item repeated on the
echo     CPU, and the seconds of both on three whole-range studies (skipped if no OpenCL GPU answers)
echo   - unchanged, and run here because 5.17 must not have changed them: the Ranked grouping of 5.16, bounties and
echo     future hands of 5.15, pruning, the merge of frozen batches and the equal-time tool of 5.14, the satellite
echo     checks of 5.13, the 6-max checks of 5.12, the philox64 checks of 5.11, and the trainer against the
echo     recorded states of 5.10
echo Nothing is installed. This takes about 30 to 55 minutes.
echo Saved studies are not touched: everything is written to a temporary folder, which is removed at the end.
echo Reports are written into this folder:
echo   Windows-selftest517-5.17.json          the checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-focused-validation-5.17.json   every check, with its status and its evidence
echo   Windows-focused-validation-5.17.txt    the same as text
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest517-5.17.json" del /q "Windows-selftest517-5.17.json"
if exist "Windows-focused-validation-5.17.json" del /q "Windows-focused-validation-5.17.json"
if exist "Windows-focused-validation-5.17.txt" del /q "Windows-focused-validation-5.17.txt"
echo Step 1 of 2: mwcli.exe --selftest517
set "em_st=%TEMP%\EightMax-5.17-selftest517-%RANDOM%%RANDOM%"
mwcli.exe --selftest517 "validation\5.17\windows\brhu" "studies" "%em_st%" all
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest517.json" copy /y "%em_st%\selftest517.json" "Windows-selftest517-5.17.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.17: every check passed.) else (echo Self-test 5.17: exit status %selftest_result%: a check failed or could not be made. See Windows-selftest517-5.17.json.)
rem A self-test that ends with status 0 but wrote no report has not shown anything: that is not a pass.
if not exist "Windows-selftest517-5.17.json" if "%selftest_result%"=="0" set "selftest_result=2"
if not exist "Windows-selftest517-5.17.json" echo NOTE: Windows-selftest517-5.17.json was not written.
echo.
echo Step 2 of 2: the validation script, focused mode
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows517.ps1" -Focused %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-focused-validation-5.17.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.11 to 5.17 sections have not run on a physical Windows PC before this release; please keep the report files and the text above. The self-test result of step 1 stands on its own.
if not exist "Windows-focused-validation-5.17.json" echo NOTE: Windows-focused-validation-5.17.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
