/* EightMax 5.17 (Phase 7): heads-up vector best response, algorithm brhu-5.17-v1.
 *
 * ONE SOURCE, TWO COMPILERS. This file is compiled as C++ into the program (the CPU path) and is handed, as text,
 * to the OpenCL compiler of the graphics driver (the GPU path). Both run the same statements in the same order on
 * IEEE-754 doubles, which is why their results are compared bit for bit and not within a tolerance.
 *
 * What one ITEM is: one river subtree (an "entry") on one complete five-card board, for every hand of the
 * responding seat at once. Input: the opponent's reach on that board. Output: for every own hand the value of the
 * best response (BR) and the value of the evaluated policy (PV) inside that subtree, both unnormalised
 * (sum over the opponent's hands of reach times utility). An item is worked by one thread from start to end and
 * writes only to its own scratch slot and its own output rows, so items never interact.
 *
 * Arithmetic rules (they are the definition of the algorithm):
 *   - sums run in the index order written here; nothing is reordered;
 *   - a product that feeds a sum goes through BR_MUL. In C++ it is a plain product (the build forbids contraction:
 *     -ffp-contract=off and no FMA instruction in the x86-64 baseline). In OpenCL its bits are XOR-ed with a zero
 *     the compiler cannot see (it is read from a buffer), so no compiler can fuse it with the following addition;
 *   - no library function of floating point is called (no fmax, no fma, no pow).
 *
 * Restrictions of OpenCL C 1.2 kept here: no recursion, no pointers to pointers, no dynamic allocation.
 */
#ifdef BRHU_OPENCL
#pragma OPENCL EXTENSION cl_khr_fp64 : enable
typedef ulong br_u64; typedef uint br_u32; typedef int br_i32; typedef ushort br_u16;
#define BR_G __global
#ifdef BRHU_UNPROTECTED
/* Test only (EM_BRHU_TEST=unprotected): what the kernel would be without its protection, to show that the probe
   refuses a device that fuses a product with a sum. Never used for a result. */
#pragma OPENCL FP_CONTRACT ON
#define BR_MUL(a, b) ((a) * (b))
#else
#pragma OPENCL FP_CONTRACT OFF
#define BR_MUL(a, b) as_double(as_ulong((a) * (b)) ^ zero)
#endif
#else
typedef uint64_t br_u64; typedef uint32_t br_u32; typedef int32_t br_i32; typedef uint16_t br_u16;
#define BR_G
#define BR_MUL(a, b) ((a) * (b))
#endif

#define BR_NI 6                    /* ints of a node: type, k, state, first child (index into CH), first number (index into NUM), reserved */
#define BR_OWN 0                   /* decision of the responding seat */
#define BR_OPP 1                   /* decision of the other seat */
#define BR_FOLD 2                  /* uncontested terminal: NUM[n] = utility of the responder */
#define BR_SHOW 3                  /* showdown: NUM[n..n+2] = utility when the responder wins, ties, loses */
#define BR_NONE 0xffffffffu        /* no stored row: the fallback policy of the node */
#define BR_NOKEY 0xffffffffffffffffUL   /* the hand has no strategy key on this board */
#define BR_EMPTY 0xffffffffffffffffUL   /* empty slot of the row table */

/* Where the stored policy of (state, key) starts in POL, or BR_NONE. */
static br_u32 brhu_find(BR_G const br_u64 *HK, BR_G const br_u32 *HV, br_u64 hmask, br_i32 state, br_u64 kk) {
  br_u64 key, x, i;
  if (state < 0 || kk == BR_NOKEY) return BR_NONE;
  key = ((br_u64)(br_u32)state << 37) | kk;
  x = key; x ^= x >> 33; x *= 0xff51afd7ed558ccdUL; x ^= x >> 33; x *= 0xc4ceb9fe1a85ec53UL; x ^= x >> 33;
  i = x & hmask;
  for (;;) {
    br_u64 have = HK[i];
    if (have == key) return HV[i];
    if (have == BR_EMPTY) return BR_NONE;
    i = (i + 1) & hmask;
  }
}

/* Scratch of one slot.
 *   doubles (DW = (D+1)*nOpp + (2*(D+1)+3)*nOwn):
 *     R(l)  = l*nOpp                         opponent reach made at depth l (l = 0: the reach of the item)
 *     VB(d) = (D+1)*nOpp + (2*d)*nOwn        value of the node at depth d, best response
 *     VP(d) = (D+1)*nOpp + (2*d+1)*nOwn      value of the node at depth d, evaluated policy
 *     T1..T3 after them: nOwn each
 *   ints (IW = 3*(D+1) + (D+1)*HS):
 *     node[d], act[d], rl[d] (the reach level the node at depth d reads), then PO(d)[HS]: where the actor's
 *     hands have their policies in POL
 */
static void brhu_item(
    BR_G const br_i32 *NODE, BR_G const br_i32 *CH, BR_G const double *NUM,
    BR_G const br_u64 *HK, BR_G const br_u32 *HV, BR_G const double *POL,
    BR_G const br_u64 *KK, BR_G const br_i32 *SC, BR_G const br_u16 *ORD, BR_G const br_i32 *HAND,
    BR_G const double *REACH, BR_G const br_i32 *ITEM,
    BR_G double *RES, BR_G br_u32 *CNT, BR_G double *WD, BR_G br_i32 *WI,
    br_u64 hmask, br_u64 zero, br_i32 seat, br_i32 nOwn, br_i32 nOpp, br_i32 HS, br_i32 D, br_i32 it, br_i32 slot) {
  const br_i32 opp = 1 - seat;
  const br_i32 entry = ITEM[it * 4], board = ITEM[it * 4 + 1], group = ITEM[it * 4 + 2];
  const br_u64 DW = (br_u64)(D + 1) * (br_u64)nOpp + (br_u64)(2 * (D + 1) + 3) * (br_u64)nOwn;
  const br_u64 IW = (br_u64)3 * (br_u64)(D + 1) + (br_u64)(D + 1) * (br_u64)HS;
  BR_G double *wd = WD + (br_u64)slot * DW;
  BR_G br_i32 *wi = WI + (br_u64)slot * IW;
  BR_G double *V = wd + (br_u64)(D + 1) * (br_u64)nOpp;
  BR_G double *T1 = V + (br_u64)(2 * (D + 1)) * (br_u64)nOwn;
  BR_G double *T2 = T1 + nOwn;
  BR_G double *T3 = T2 + nOwn;
  BR_G br_i32 *node = wi, *act = wi + (D + 1), *rl = wi + 2 * (D + 1), *PO = wi + 3 * (D + 1);
  BR_G const br_u64 *kkOwn = KK + ((br_u64)board * 2 + (br_u64)seat) * (br_u64)HS;
  BR_G const br_u64 *kkOpp = KK + ((br_u64)board * 2 + (br_u64)opp) * (br_u64)HS;
  BR_G const br_i32 *scOwn = SC + ((br_u64)board * 2 + (br_u64)seat) * (br_u64)HS;
  BR_G const br_i32 *scOpp = SC + ((br_u64)board * 2 + (br_u64)opp) * (br_u64)HS;
  BR_G const br_u16 *ordOwn = ORD + ((br_u64)board * 2 + (br_u64)seat) * (br_u64)HS;
  BR_G const br_u16 *ordOpp = ORD + ((br_u64)board * 2 + (br_u64)opp) * (br_u64)HS;
  BR_G const br_i32 *hOwn = HAND + (br_u64)seat * (br_u64)HS * 3;
  BR_G const br_i32 *hOpp = HAND + (br_u64)opp * (br_u64)HS * 3;
  BR_G const double *reach0 = REACH + (br_u64)group * (br_u64)nOpp;
  br_u32 lookups = 0, fallbacks = 0;
  br_i32 d = 0, h, o;
  double ct[52], cc[52];

  /* reach of the item: the reach of its group, without the hands the complete board blocks */
  for (o = 0; o < nOpp; o++) wd[o] = scOpp[o] < 0 ? 0.0 : reach0[o];
  node[0] = entry; act[0] = -1; rl[0] = 0;

  for (;;) {
    const br_i32 j = node[d];
    const br_i32 type = NODE[j * BR_NI], k = NODE[j * BR_NI + 1], state = NODE[j * BR_NI + 2], ch0 = NODE[j * BR_NI + 3], num0 = NODE[j * BR_NI + 4];
    BR_G double *R = wd + (br_u64)rl[d] * (br_u64)nOpp;
    BR_G double *VB = V + (br_u64)(2 * d) * (br_u64)nOwn, *VP = VB + nOwn;
    br_i32 descend = 0;
    if (type >= BR_FOLD) {
      /* mass(h): the reach of the opponent's hands that share no card with h. total - reach with the first card
         - reach with the second card + reach of the identical hand (it was subtracted twice). */
      double tot = 0.0; br_i32 c;
      for (c = 0; c < 52; c++) ct[c] = 0.0;
      for (o = 0; o < nOpp; o++) { const double r = R[o]; tot += r; ct[hOpp[o * 3]] += r; ct[hOpp[o * 3 + 1]] += r; }
      for (h = 0; h < nOwn; h++) {
        const br_i32 same = hOwn[h * 3 + 2];
        T3[h] = scOwn[h] < 0 ? 0.0 : ((tot - ct[hOwn[h * 3]]) - ct[hOwn[h * 3 + 1]]) + (same < 0 ? 0.0 : R[same]);
      }
      if (type == BR_FOLD) {
        const double u = NUM[num0];
        for (h = 0; h < nOwn; h++) { const double v = scOwn[h] < 0 ? 0.0 : BR_MUL(u, T3[h]); VB[h] = v; VP[h] = v; }
      } else {
        const double uW = NUM[num0], uT = NUM[num0 + 1], uL = NUM[num0 + 2];
        double cum = 0.0; br_i32 i = 0, x;
        /* upwards: the reach of the opponent's hands this hand beats */
        for (c = 0; c < 52; c++) cc[c] = 0.0;
        for (x = 0; x < nOwn; x++) {
          const br_i32 hh = ordOwn[x], sh = scOwn[hh];
          if (sh < 0) continue;
          while (i < nOpp) { const br_i32 oo = ordOpp[i]; double r; if (scOpp[oo] >= sh) break; r = R[oo]; cum += r; cc[hOpp[oo * 3]] += r; cc[hOpp[oo * 3 + 1]] += r; i++; }
          T1[hh] = (cum - cc[hOwn[hh * 3]]) - cc[hOwn[hh * 3 + 1]];
        }
        /* downwards: the reach of the opponent's hands that beat this hand */
        cum = 0.0; i = nOpp - 1;
        for (c = 0; c < 52; c++) cc[c] = 0.0;
        for (x = nOwn - 1; x >= 0; x--) {
          const br_i32 hh = ordOwn[x], sh = scOwn[hh];
          if (sh < 0) continue;
          while (i >= 0) { const br_i32 oo = ordOpp[i]; double r; if (scOpp[oo] <= sh) break; r = R[oo]; cum += r; cc[hOpp[oo * 3]] += r; cc[hOpp[oo * 3 + 1]] += r; i--; }
          T2[hh] = (cum - cc[hOwn[hh * 3]]) - cc[hOwn[hh * 3 + 1]];
        }
        for (h = 0; h < nOwn; h++) {
          double v = 0.0;
          if (scOwn[h] >= 0) { const double win = T1[h], lose = T2[h], tie = (T3[h] - win) - lose; v = (BR_MUL(win, uW) + BR_MUL(tie, uT)) + BR_MUL(lose, uL); }
          VB[h] = v; VP[h] = v;
        }
      }
    } else {
      BR_G br_i32 *po = PO + (br_u64)d * (br_u64)HS;
      br_i32 a = act[d];
      if (a < 0) {
        /* first arrival: where the actor's hands have their policies */
        if (type == BR_OWN) {
          for (h = 0; h < nOwn; h++) {
            br_u32 at = BR_NONE;
            if (scOwn[h] >= 0) { at = brhu_find(HK, HV, hmask, state, kkOwn[h]); lookups++; if (at == BR_NONE) fallbacks++; }
            po[h] = (br_i32)at;
          }
        } else {
          for (o = 0; o < nOpp; o++) {
            br_u32 at = BR_NONE;
            if (R[o] > 0.0) { at = brhu_find(HK, HV, hmask, state, kkOpp[o]); lookups++; if (at == BR_NONE) fallbacks++; }
            po[o] = (br_i32)at;
          }
          for (h = 0; h < nOwn; h++) { VB[h] = 0.0; VP[h] = 0.0; }
        }
        a = 0;
      } else {
        /* back from the child of action a (its values are one depth below) */
        BR_G const double *CB = VB + 2 * nOwn, *CP = CB + nOwn;
        if (type == BR_OWN) {
          for (h = 0; h < nOwn; h++) {
            const br_u32 at = (br_u32)po[h];
            const double p = at == BR_NONE ? NUM[num0 + a] : POL[at + (br_u32)a];
            const double t = BR_MUL(p, CP[h]);
            if (a == 0) { VB[h] = CB[h]; VP[h] = t; }
            else { if (CB[h] > VB[h]) VB[h] = CB[h]; VP[h] = VP[h] + t; }
          }
        } else {
          for (h = 0; h < nOwn; h++) { VB[h] = VB[h] + CB[h]; VP[h] = VP[h] + CP[h]; }
        }
        a++;
      }
      if (type == BR_OWN) { if (a < k) descend = 1; }
      else {
        /* the next action the opponent takes with some hand; its reach is made one level down */
        BR_G double *RC = wd + (br_u64)(d + 1) * (br_u64)nOpp;
        while (a < k) {
          br_i32 any = 0;
          for (o = 0; o < nOpp; o++) {
            const double r = R[o]; double q = 0.0;
            if (r > 0.0) { const br_u32 at = (br_u32)po[o]; const double p = at == BR_NONE ? NUM[num0 + a] : POL[at + (br_u32)a]; q = BR_MUL(r, p); }
            RC[o] = q; if (q > 0.0) any = 1;
          }
          if (any) break;
          a++;
        }
        if (a < k) descend = 1;
      }
      if (descend) {
        act[d] = a; node[d + 1] = CH[ch0 + a]; act[d + 1] = -1; rl[d + 1] = type == BR_OWN ? rl[d] : d + 1; d++;
        continue;
      }
    }
    if (d == 0) break;
    d--;
  }
  {
    BR_G double *out = RES + (br_u64)it * 2 * (br_u64)nOwn;
    for (h = 0; h < nOwn; h++) { out[h] = V[h]; out[nOwn + h] = V[nOwn + h]; }
    CNT[it * 2] = lookups; CNT[it * 2 + 1] = fallbacks;
  }
}

#ifdef BRHU_OPENCL
__kernel void brhu(
    __global const int *NODE, __global const int *CH, __global const double *NUM,
    __global const ulong *HK, __global const uint *HV, __global const double *POL,
    __global const ulong *KK, __global const int *SC, __global const ushort *ORD, __global const int *HAND,
    __global const double *REACH, __global const int *ITEM,
    __global double *RES, __global uint *CNT, __global double *WD, __global int *WI,
    __global const ulong *PAR) {
  /* PAR: 0 hmask, 1 the zero of BR_MUL, 2 seat, 3 nOwn, 4 nOpp, 5 HS, 6 D, 7 number of items */
  const int it = (int)get_global_id(0);
  if ((ulong)it >= PAR[7]) return;
  brhu_item(NODE, CH, NUM, HK, HV, POL, KK, SC, ORD, HAND, REACH, ITEM, RES, CNT, WD, WI,
            PAR[0], PAR[1], (int)PAR[2], (int)PAR[3], (int)PAR[4], (int)PAR[5], (int)PAR[6], it, it);
}
/* The arithmetic the algorithm relies on, on values the host chooses: out[5*i..] = a*b (through BR_MUL), a*b+c,
   a+c, a/b, a-c for the triples in[3*i..]. The host compares every bit with its own result before any use. */
__kernel void brhu_probe(__global const double *in, __global double *out, __global const ulong *PAR) {
  const int i = (int)get_global_id(0);
  const ulong zero = PAR[1];
  double a, b, c;
  if ((ulong)i >= PAR[7]) return;
  a = in[3 * i]; b = in[3 * i + 1]; c = in[3 * i + 2];
  out[5 * i] = BR_MUL(a, b); out[5 * i + 1] = BR_MUL(a, b) + c; out[5 * i + 2] = a + c; out[5 * i + 3] = a / b; out[5 * i + 4] = a - c;
}
#endif
