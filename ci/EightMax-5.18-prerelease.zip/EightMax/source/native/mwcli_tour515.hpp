// EightMax 5.15: mwcli --tour515 request.json - values of the tournament payoff model tour-5.15-v1 (tour515.hpp) with
// 17 significant digits and their IEEE-754 bit patterns, for independent implementations, the JavaScript mirror and
// the self-test.
//   {"seats":n,"start":[hand-start stacks, study seats first],"prizes":[..],
//    "bounty":{"share":k,"heads":[one per player]},
//    "fgs":{"depth":d,"table":[indices of start in position order],"smallBlind":..,"bigBlind":..,"ante":..,"anteType":"none|classic|bba"},
//    "outcomes":[{"final":[stack of every seat after the hand],"won":[for a seat without chips: bit mask of the seats that won its last pot]}, ...],
//    "nextHand":true}
// "nextHand" adds, for every outcome, the first future hand: its players (indices of start, in the order of that hand),
// their stacks, the push/fold solution by hand class, the worth of every outcome of that hand, and the values.
#pragma once
#include <cstdarg>
namespace tq515 {
static void app(std::string &o, const char *f, ...) { char b[512]; va_list a; va_start(a, f); const int n = vsnprintf(b, sizeof b, f, a); va_end(a); if (n > 0) o.append(b, std::min<size_t>((size_t)n, sizeof b - 1)); }
static void list(std::string &o, const char *name, const double *v, size_t n) { app(o, ",\"%s\":[", name); for (size_t i = 0; i < n; i++) app(o, "%s%.17g", i ? "," : "", v[i]); o += "]"; }
// 0 answered, 1 the request is refused (why), 2 it cannot be read
static int answer(const std::string &text, std::string &o, std::string &why) {
  char e[200] = ""; JV *q = json_parse(text.data(), text.size(), e, sizeof e);
  if (!q) { why = std::string("the request is not JSON: ") + e; return 2; }
  struct Free { JV *q; ~Free() { json_free(q); } } guard{q};
  Tournament T; const JV *seats = jget(q, "seats"), *outs = jget(q, "outcomes");
  auto nums = [&](const JV *v, std::vector<double> &out) { if (!v || v->type != J_ARR || v->n > 16) return false; for (int i = 0; i < v->n; i++) { if (v->items[i]->type != J_NUM || !std::isfinite(v->items[i]->num) || v->items[i]->num < 0) return false; out.push_back(v->items[i]->num); } return true; };
  const int n = seats && seats->type == J_NUM ? (int)seats->num : 0;
  if (!nums(jget(q, "start"), T.start) || !nums(jget(q, "prizes"), T.payout) || n < 2 || n > 8 || (int)T.start.size() < n || T.payout.empty() || T.payout.size() > T.start.size() || !outs || outs->type != J_ARR) { why = "the request needs seats (2 to 8), start, prizes and outcomes"; return 1; }
  for (double s : T.start) if (!(s > 0)) { why = "every hand-start stack must be above 0"; return 1; }
  for (size_t i = (size_t)n; i < T.start.size(); i++) T.others.push_back(T.start[i]);
  if (const JV *bo = jget(q, "bounty")) { const JV *sh = jget(bo, "share"); if (!sh || sh->type != J_NUM || !nums(jget(bo, "heads"), T.ext.heads)) { why = "bounty needs share and heads"; return 1; } T.ext.share = sh->num; }
  if (const JV *fg = jget(q, "fgs")) {
    const JV *dp = jget(fg, "depth"), *tb = jget(fg, "table"); const char *at = jstr(jget(fg, "anteType"));
    if (!dp || dp->type != J_NUM || !tb || tb->type != J_ARR) { why = "fgs needs depth and table"; return 1; }
    T.ext.depth = (int)dp->num; for (int i = 0; i < tb->n; i++) T.ext.table.push_back(tb->items[i]->type == J_NUM ? (int)tb->items[i]->num : -1);
    if (const JV *x = jget(fg, "smallBlind")) T.ext.sb = x->num; if (const JV *x = jget(fg, "bigBlind")) T.ext.bb = x->num; if (const JV *x = jget(fg, "ante")) T.ext.ante = x->num;
    T.ext.anteType = at && !std::strcmp(at, "classic") ? 1 : at && !std::strcmp(at, "bba") ? 2 : 0;
  }
  why = T.ext.prepare(T.start, n, T.payout); if (!why.empty()) return 1;
  const JV *nx = jget(q, "nextHand"); const bool next = nx && nx->type == J_BOOL && nx->num != 0 && T.ext.depth > 0;
  Tournament::Workspace ws; T.prepare(ws, 16 * 1048576.0);
  o.clear(); app(o, "{\"model\":\"%s\",\"payoffKey\":\"%s\",\"summary\":\"%s\",\"worstCaseSolutionsPerOutcome\":%.17g,\"outcomes\":[", t515::MODEL, T.ext.keyHash().c_str(), T.ext.summary().c_str(), T.ext.work);
  for (int k = 0; k < outs->n; k++) {
    const JV *fin = jget(outs->items[k], "final"), *won = jget(outs->items[k], "won"); double chips[8], fin0[8]; uint32_t w[8] = {};
    if (!fin || fin->type != J_ARR || fin->n != n) { why = "outcome " + std::to_string(k) + " needs final (one stack per seat)"; return 1; }
    for (int i = 0; i < n; i++) { if (fin->items[i]->type != J_NUM || !std::isfinite(fin->items[i]->num) || fin->items[i]->num < 0) { why = "outcome " + std::to_string(k) + ": a final stack is a number, 0 or more"; return 1; }
      chips[i] = fin0[i] = fin->items[i]->num; if (won && won->type == J_ARR && i < won->n && won->items[i]->type == J_NUM) w[i] = (uint32_t)won->items[i]->num; }
    T.evaluate(chips, n, ws, w);
    app(o, "%s{\"values\":[", k ? "," : ""); for (int i = 0; i < n; i++) app(o, "%s%.17g", i ? "," : "", chips[i]);
    o += "],\"bits\":["; for (int i = 0; i < n; i++) { unsigned long long u; std::memcpy(&u, &chips[i], 8); app(o, "%s\"%016llx\"", i ? "," : "", u); }
    o += "]";
    if (next) {   // the first future hand: who is left at the table, in the order of that hand
      const auto &X = T.ext; const int nt = (int)X.table.size(); double x[8], hh[8], val[8], h[16]; int ids[8], m = 0;
      for (size_t i = 0; i < X.heads.size(); i++) h[i] = X.heads[i];
      if (X.bounty()) for (int p = 0; p < n; p++) if (fin0[p] <= 1e-9) { const uint32_t ww = w[p] & ~(1u << p); const int c = std::popcount(ww); for (uint32_t y = ww; y; y &= y - 1) h[std::countr_zero(y)] += (1 - X.share) * X.heads[(size_t)p] / c; h[p] = 0; }
      for (int j = 1; j <= nt; j++) { const int g = X.table[(size_t)(j % nt)]; const double st = g < n ? fin0[g] : X.start[(size_t)g]; if (st > 1e-9) { ids[m] = g; x[m] = st; hh[m] = h[g]; m++; } }
      t515::Model::Report R; const int left = m + (int)X.otherStack.size(), pays = std::min((int)X.prizes.size(), left);
      const bool played = m >= 2 && X.solveNext(X.depth, m, x, hh, pays, true, val, &R);
      app(o, ",\"nextHand\":{\"played\":%s,\"players\":[", played ? "true" : "false"); for (int j = 0; j < m; j++) app(o, "%s%d", j ? "," : "", ids[j]);
      o += "]"; list(o, "stacks", x, (size_t)m);
      if (played) {
        app(o, ",\"iterations\":%d,\"exploitability\":%.17g,\"unit\":%.17g", R.iterations, R.exploitability, R.unit); list(o, "values", val, (size_t)m);
        list(o, "jamPercent", R.jamPct.data(), R.jamPct.size());
        o += ",\"callPercent\":["; bool first = true; for (int i = 0; i < m - 1; i++) for (int j = i + 1; j < m; j++) { app(o, "%s[%d,%d,%.17g]", first ? "" : ",", i, j, R.callPct[(size_t)i * m + j]); first = false; }
        o += "]"; list(o, "foldValues", R.foldValues.data(), R.foldValues.size()); list(o, "showdownValues", R.showdownValues.data(), R.showdownValues.size());
        list(o, "jam", R.jam.data(), R.jam.size()); list(o, "call", R.call.data(), R.call.size());
      }
      o += "}";
    }
    o += "}";
  }
  app(o, "],\"futureHandsSolved\":%lld", T.ext.solvesDone());
  if (next) { o += ",\"classes\":["; for (int c = 0; c < t515::NC; c++) app(o, "%s\"%s\"", c ? "," : "", t515::PF515_NAMES[c]); o += "]"; }
  o += "}"; return 0;
}
}
