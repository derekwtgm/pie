"""Embeds brhu_kernel.h as a C++ string (brhu_kernel_src.hpp) for the OpenCL path of method exact-hu.

usage: python3 gen_brhu.py            writes brhu_kernel_src.hpp beside this file
       python3 gen_brhu.py --check    exit 1 when the embedded text is not the file

The program compiles brhu_kernel.h itself for the CPU and hands this text to the OpenCL compiler of the driver,
so the two paths run one source. A regression test runs --check.
"""
import sys
from pathlib import Path
here = Path(__file__).resolve().parent
src = (here / 'brhu_kernel.h').read_text(encoding='ascii').replace('\r\n', '\n')
out = ['// generated from brhu_kernel.h by gen_brhu.py; do not edit', '#pragma once', 'static const char BRHU_KERNEL_SRC[] =']
for line in src.split('\n'):
    out.append('  "' + line.replace('\\', '\\\\').replace('"', '\\"') + '\\n"')
out[-1] += ';'
text = '\n'.join(out) + '\n'
target = here / 'brhu_kernel_src.hpp'
if '--check' in sys.argv:
    sys.exit(0 if target.exists() and target.read_text(encoding='ascii').replace('\r\n', '\n') == text else 1)
target.write_text(text, encoding='ascii', newline='\n')
