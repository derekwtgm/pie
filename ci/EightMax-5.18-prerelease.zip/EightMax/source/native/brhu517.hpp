// EightMax 5.17 (Phase 7): exact best response of a heads-up postflop study over whole ranges, on the CPU and on an
// OpenCL GPU, with results that are compared bit for bit. Algorithm identifier: brhu-5.17-v1.
//
// What is computed is what method "exact" computes for two seats: against the fixed policy of the other seat, the
// value of the best response of one seat over physical hands and boards (never restricted to a hand grouping), and
// the value of the evaluated policy; their difference over the weight of the possible deals is the gain.
//
// How it differs from method "exact": that method walks the tree once per own hand and sums over the opponent's
// hands at every terminal (own hands x opponent hands x boards x terminals). This one carries every own hand
// through the tree at once and evaluates a terminal in one pass over the two ranges sorted by strength. The
// order of the floating-point sums is therefore another one, and the two methods agree to rounding, not to the
// bit. That is why this method has its own identifier and "exact" is unchanged.
//
// The split: the streets before the river are walked on the host (few nodes). Every river subtree on every
// complete board is one ITEM of brhu_kernel.h; items are worked by CPU threads or by the GPU, in any order and any
// batching, and their results are added on the host in a fixed order (river cards ascending). Hence the result is
// the same double for every thread count, batch size and device.
#pragma once
#include <map>
#include "brhu_kernel.h"
#include "brhu_ocl.hpp"

namespace {
namespace es {
namespace hu {
constexpr const char *ALGORITHM = "brhu-5.17-v1";
enum class Where { Cpu, Gpu, Both };
struct Options { Where where = Where::Cpu; long long verifyEvery = 16; int threads = 1; long long memoryBytes = 512LL << 20; };
struct Counters {
  long long entries = 0, nodes = 0, groups = 0, items = 0, boards = 0, kernelLookups = 0, kernelFallbacks = 0, hostLookups = 0, hostFallbacks = 0;
  long long gpuItems = 0, gpuBatches = 0, verifiedItems = 0, mismatches = 0; double secTables = 0, secWalk = 0, secItems = 0, secVerify = 0; int depth = 0;
};
inline uint64_t mixKey(uint64_t x) { x ^= x >> 33; x *= 0xff51afd7ed558ccdULL; x ^= x >> 33; x *= 0xc4ceb9fe1a85ec53ULL; x ^= x >> 33; return x; }

// Tables both seats share: the hands, every complete board the study can reach, and the stored policies.
struct Tables {
  int n[2] = {0, 0}, HS = 0, startLen = 0; uint64_t startMask = 0;
  std::vector<int32_t> HAND;                    // [seat][HS]{card, card, index of the same two cards in the other range or -1}
  std::vector<int16_t> boardAt;                 // [turn or 52][river or 52] -> board index
  std::vector<uint64_t> KK; std::vector<int32_t> SC; std::vector<uint16_t> ORD; size_t boards = 0;
  std::vector<uint64_t> HK; std::vector<uint32_t> HV; uint64_t hmask = 0; std::vector<double> POL; size_t storedRows = 0;
  double bytes() const { return HAND.size() * 4.0 + KK.size() * 8.0 + SC.size() * 4.0 + ORD.size() * 2.0 + HK.size() * 8.0 + HV.size() * 4.0 + POL.size() * 8.0; }
  int board(int turn, int river) const { return boardAt[(size_t)turn * 53 + (size_t)river]; }
};
inline double tableBytesEstimate(const MW &m) {
  const double hs = (double)std::max(m.hands[0].size(), m.hands[1].size());
  const double boards = m.startLen == 5 ? 1 : m.startLen == 4 ? 48 : 49.0 * 48;
  double slots = 1024; while (slots < 2.0 * (double)m.rows.size()) slots *= 2;
  return boards * 2 * hs * 14 + slots * 12 + (double)m.vals.size() * 4;
}
inline void buildTables(const MW &m, const Game &g, Pol pol, EvShared &S, int threads, Tables &T) {
  T.startLen = m.startLen; for (int i = 0; i < m.startLen; i++) T.startMask |= 1ULL << m.board[i];
  for (int s = 0; s < 2; s++) T.n[s] = (int)m.hands[(size_t)s].size();
  T.HS = std::max(T.n[0], T.n[1]); const size_t HS = (size_t)T.HS;
  T.HAND.assign(2 * HS * 3, -1);
  for (int s = 0; s < 2; s++) for (int h = 0; h < T.n[s]; h++) {
    const Hand &x = m.hands[(size_t)s][(size_t)h]; int same = -1;
    const auto &other = m.hands[(size_t)(1 - s)];
    for (size_t o = 0; o < other.size(); o++) if ((other[o].a == x.a && other[o].b == x.b) || (other[o].a == x.b && other[o].b == x.a)) { same = (int)o; break; }
    T.HAND[((size_t)s * HS + (size_t)h) * 3] = x.a; T.HAND[((size_t)s * HS + (size_t)h) * 3 + 1] = x.b; T.HAND[((size_t)s * HS + (size_t)h) * 3 + 2] = same;
  }
  // the complete boards, in the order (turn ascending, river ascending)
  struct B { int c[5]; }; std::vector<B> boards; T.boardAt.assign(53 * 53, -1);
  auto add = [&](int turn, int river) { B b; std::copy_n(m.board, 5, b.c); if (turn < 52) b.c[3] = turn; if (river < 52) b.c[4] = river; T.boardAt[(size_t)turn * 53 + (size_t)river] = (int16_t)boards.size(); boards.push_back(b); };
  if (m.startLen == 5) add(52, 52);
  else if (m.startLen == 4) { for (int r = 0; r < 52; r++) if (!(T.startMask >> r & 1)) add(52, r); }
  else for (int t = 0; t < 52; t++) if (!(T.startMask >> t & 1)) for (int r = 0; r < 52; r++) if (r != t && !(T.startMask >> r & 1)) add(t, r);
  T.boards = boards.size();
  T.KK.assign(T.boards * 2 * HS, BR_NOKEY); T.SC.assign(T.boards * 2 * HS, -1); T.ORD.assign(T.boards * 2 * HS, 0);
  {
    const int workers = std::max(1, threads); std::vector<std::unique_ptr<Evaluator>> ev((size_t)workers);
    for (auto &e : ev) e = std::make_unique<Evaluator>(m, g, pol, false, 0, &S);
    parallelFor(S.ctl, workers, T.boards, [&](int w, size_t bi) {
      Evaluator &E = *ev[(size_t)w]; std::copy_n(boards[bi].c, 5, E.cards);
      uint64_t pub = 0; for (int i = 0; i < 5; i++) pub |= 1ULL << boards[bi].c[i];
      for (int s = 0; s < 2; s++) {
        const size_t at = (bi * 2 + (size_t)s) * HS; const int n = T.n[s];
        for (int h = 0; h < n; h++) {
          const Hand &x = m.hands[(size_t)s][(size_t)h];
          if ((pub >> x.a & 1) || (pub >> x.b & 1)) continue;
          T.SC[at + (size_t)h] = evalSeven(boards[bi].c, x.a, x.b);
          const Evaluator::Key k = E.key(s, h, 5);
          if (k.ok) T.KK[at + (size_t)h] = ((uint64_t)(uint32_t)k.hand << 26) | (uint64_t)k.code;
        }
        uint16_t *ord = T.ORD.data() + at; for (int h = 0; h < n; h++) ord[h] = (uint16_t)h;
        const int32_t *sc = T.SC.data() + at;
        std::sort(ord, ord + n, [&](uint16_t a, uint16_t b) { return sc[a] != sc[b] ? sc[a] < sc[b] : a < b; });
      }
    });
  }
  // the stored policies, normalised once on the host: the kernel only reads them
  size_t slots = 1024; while (slots < 2 * m.rows.size()) slots *= 2;
  T.HK.assign(slots, BR_EMPTY); T.HV.assign(slots, 0); T.hmask = slots - 1; T.POL.reserve(m.vals.size() / 2);
  double p[8];
  for (size_t r = 0; r < m.rows.size(); r++) {
    const int k = m.rows[r].k; if (k < 1 || k > 8) continue;
    const bool ok = pol == Pol::Average ? averageOf(m, (long long)r, k, p) : currentOf(m, (long long)r, k, p);
    if (!ok) continue;
    if (T.POL.size() + (size_t)k >= 0xffffffffULL) throw QueryError{422, "The strategy table is too large for method exact-hu"};
    size_t i = (size_t)(mixKey(m.rows[r].key) & T.hmask); while (T.HK[i] != BR_EMPTY) i = (i + 1) & T.hmask;
    T.HK[i] = m.rows[r].key; T.HV[i] = (uint32_t)T.POL.size(); for (int a = 0; a < k; a++) T.POL.push_back(p[a]); T.storedRows++;
  }
  if (T.POL.empty()) T.POL.push_back(0.0);
}

struct VV { std::vector<double> b, p; };
// One seat's response: the flattened river subtrees, the groups of items, and the walk of the earlier streets.
struct Seat {
  const MW &m; const Game &g; Evaluator &E; const Tables &T; const int seat, opp, nOwn, nOpp; Counters &C;
  std::vector<int32_t> NODE, CH, ITEM; std::vector<double> NUM, REACH, GV; int D = 0;
  struct Group { int entry, first, count; double div; };
  std::vector<Group> groups; std::map<std::string, int> entryOf; std::string path; bool collect = true; size_t cursor = 0;
  std::vector<uint64_t> ownMask, oppMask;
  Seat(const MW &mm, const Game &gg, Evaluator &e, const Tables &t, int s, Counters &c) : m(mm), g(gg), E(e), T(t), seat(s), opp(1 - s), nOwn(t.n[s]), nOpp(t.n[1 - s]), C(c) {
    for (const Hand &h : m.hands[(size_t)seat]) ownMask.push_back((1ULL << h.a) | (1ULL << h.b));
    for (const Hand &h : m.hands[(size_t)opp]) oppMask.push_back((1ULL << h.a) | (1ULL << h.b));
  }
  size_t DW() const { return (size_t)(D + 1) * (size_t)nOpp + (size_t)(2 * (D + 1) + 3) * (size_t)nOwn; }
  size_t IW() const { return (size_t)3 * (size_t)(D + 1) + (size_t)(D + 1) * (size_t)T.HS; }
  uint64_t pub(int len) const { uint64_t u = 0; for (int i = 0; i < len; i++) u |= 1ULL << E.cards[i]; return u; }

  int flatten(BS t, int state, int depth) {
    BS c;
    for (int guard = 0; t.kind == 0 && t.k == 1; guard++) { if (guard > 96) throw QueryError{500, "exact-hu: a chain of forced actions does not end"}; state = E.childOf(state, t, 0, c); t = c; }
    if (t.kind == 1) throw QueryError{500, "exact-hu: a card is dealt after the river"};
    const size_t j = NODE.size() / BR_NI; NODE.resize(NODE.size() + BR_NI, 0); D = std::max(D, depth); C.nodes++;
    if (depth > 60) throw QueryError{422, "exact-hu: the river betting is deeper than 60 decisions"};
    int type, k = 0, ch0 = 0; const int num0 = (int)NUM.size();
    if (t.kind == 2) {
      const int np = g.rules.pots(t, E.pots);
      if (!Evaluator::contested(E.pots, np)) { type = BR_FOLD; NUM.push_back(E.uncontested(t, np)); }
      else {
        int sc[8] = {}; type = BR_SHOW;
        sc[seat] = 1; sc[opp] = 0; NUM.push_back(E.utilityWithScores(t, np, sc));
        sc[seat] = 0; NUM.push_back(E.utilityWithScores(t, np, sc));
        sc[opp] = 1; NUM.push_back(E.utilityWithScores(t, np, sc));
      }
    } else {
      type = t.actor == seat ? BR_OWN : BR_OPP; k = t.k; ch0 = (int)CH.size(); CH.resize(CH.size() + (size_t)k, 0);
      double fb[8]; E.fallbackPolicy(&t, k, fb); for (int a = 0; a < k; a++) NUM.push_back(fb[a]);
      for (int a = 0; a < k; a++) { const int cs = E.childOf(state, t, a, c); const BS child = c; const int at = flatten(child, cs, depth + 1); CH[(size_t)ch0 + (size_t)a] = at; }
    }
    int32_t *nd = NODE.data() + j * BR_NI; nd[0] = type; nd[1] = k; nd[2] = state; nd[3] = ch0; nd[4] = num0; nd[5] = 0;
    return (int)j;
  }
  // The river below `t` (the betting state when the river card is known, or a terminal that only needs the cards),
  // for every river card (len 4) or on the complete board (len 5).
  VV riverGroup(const BS &t, int state, int len, const std::vector<double> &reach) {
    VV out; out.b.assign((size_t)nOwn, 0.0); out.p.assign((size_t)nOwn, 0.0);
    if (!collect) {
      const double *gv = GV.data() + cursor * 2 * (size_t)nOwn; cursor++;
      std::copy_n(gv, nOwn, out.b.begin()); std::copy_n(gv + nOwn, nOwn, out.p.begin()); return out;
    }
    auto it = entryOf.find(path); int entry;
    if (it != entryOf.end()) entry = it->second; else { entry = flatten(t, state, 0); entryOf[path] = entry; C.entries++; }
    Group G{entry, (int)(ITEM.size() / 4), 0, 0.0}; const int gi = (int)groups.size();
    if (len == 5) { ITEM.insert(ITEM.end(), {entry, T.board(52, 52), gi, 0}); G.count = 1; }
    else {
      const uint64_t u = pub(4); const int turn = T.startLen == 3 ? E.cards[3] : 52;
      for (int r = 0; r < 52; r++) if (!(u >> r & 1)) { ITEM.insert(ITEM.end(), {entry, T.board(turn, r), gi, r}); G.count++; }
      G.div = 52 - 4 - 4;
    }
    REACH.insert(REACH.end(), reach.begin(), reach.end()); groups.push_back(G);
    return out;
  }
  // Deals one card: the reach of the hands that hold it becomes 0.
  static void without(const std::vector<double> &r, const std::vector<uint64_t> &mask, int x, std::vector<double> &out) { out.resize(r.size()); for (size_t i = 0; i < r.size(); i++) out[i] = (mask[i] >> x & 1) ? 0.0 : r[i]; }
  // mass(h) of brhu_kernel.h, on the host, for a terminal before the river
  VV foldValue(double u, int len, const std::vector<double> &reach) {
    VV out; out.b.assign((size_t)nOwn, 0.0); const uint64_t pb = pub(len); double tot = 0.0, ct[52]; for (double &x : ct) x = 0.0;
    const int32_t *hOpp = T.HAND.data() + (size_t)opp * (size_t)T.HS * 3, *hOwn = T.HAND.data() + (size_t)seat * (size_t)T.HS * 3;
    for (int o = 0; o < nOpp; o++) { const double r = reach[(size_t)o]; tot += r; ct[hOpp[o * 3]] += r; ct[hOpp[o * 3 + 1]] += r; }
    for (int h = 0; h < nOwn; h++) {
      if (ownMask[(size_t)h] & pb) continue;
      const int same = hOwn[h * 3 + 2]; const double mass = ((tot - ct[hOwn[h * 3]]) - ct[hOwn[h * 3 + 1]]) + (same < 0 ? 0.0 : reach[(size_t)same]);
      out.b[(size_t)h] = u * mass;
    }
    out.p = out.b; return out;
  }
  VV walk(int state, const BS &t0, int len, const std::vector<double> &reach) {
    E.visits++; E.poll(SITE_BR);
    BS t = t0, c;
    for (int guard = 0; t.kind == 0 && t.k == 1; guard++) { if (guard > 96) throw QueryError{500, "exact-hu: a chain of forced actions does not end"}; state = E.childOf(state, t, 0, c); t = c; }
    if (len == 5) return riverGroup(t, state, 5, reach);
    if (t.kind == 2) {
      const int np = g.rules.pots(t, E.pots);
      if (!Evaluator::contested(E.pots, np)) return foldValue(E.uncontested(t, np), len, reach);
      if (len == 4) return riverGroup(t, state, 4, reach);
      return dealTurn(t, -1, reach, true);
    }
    if (t.kind == 1) {
      const int cs = state >= 0 ? g.states.find((uint32_t)state, CHANCE_SLOT) : -1; g.rules.nextStreet(t, c); const BS next = c;
      path.push_back('/'); VV out = len == 4 ? riverGroup(next, cs, 4, reach) : dealTurn(next, cs, reach, false); path.pop_back(); return out;
    }
    const int k = t.k; const uint64_t pb = pub(len); double p[8];
    VV out; out.b.assign((size_t)nOwn, 0.0); out.p.assign((size_t)nOwn, 0.0);
    if (t.actor == seat) {
      std::vector<double> pk((size_t)nOwn * (size_t)k, 0.0);
      for (int h = 0; h < nOwn; h++) {
        if (ownMask[(size_t)h] & pb) continue;
        const bool ok = E.policy(state, k, seat, h, len, p, &t); if (!collect) { C.hostLookups++; C.hostFallbacks += !ok; }
        for (int a = 0; a < k; a++) pk[(size_t)h * (size_t)k + (size_t)a] = p[a];
      }
      for (int a = 0; a < k; a++) {
        const int cs = E.childOf(state, t, a, c); const BS child = c;
        path.push_back((char)('0' + a)); const VV r = walk(cs, child, len, reach); path.pop_back();
        for (int h = 0; h < nOwn; h++) {
          const double tp = pk[(size_t)h * (size_t)k + (size_t)a] * r.p[(size_t)h];
          if (a == 0) { out.b[(size_t)h] = r.b[(size_t)h]; out.p[(size_t)h] = tp; }
          else { if (r.b[(size_t)h] > out.b[(size_t)h]) out.b[(size_t)h] = r.b[(size_t)h]; out.p[(size_t)h] = out.p[(size_t)h] + tp; }
        }
      }
      return out;
    }
    std::vector<std::vector<double>> wa((size_t)k, std::vector<double>((size_t)nOpp, 0.0));
    for (int o = 0; o < nOpp; o++) {
      const double r = reach[(size_t)o]; if (!(r > 0.0)) continue;
      const bool ok = E.policy(state, k, opp, o, len, p, &t); if (!collect) { C.hostLookups++; C.hostFallbacks += !ok; }
      for (int a = 0; a < k; a++) wa[(size_t)a][(size_t)o] = r * p[a];
    }
    for (int a = 0; a < k; a++) {
      bool any = false; for (double x : wa[(size_t)a]) any |= x > 0.0; if (!any) continue;
      const int cs = E.childOf(state, t, a, c); const BS child = c;
      path.push_back((char)('0' + a)); const VV r = walk(cs, child, len, wa[(size_t)a]); path.pop_back();
      for (int h = 0; h < nOwn; h++) { out.b[(size_t)h] = out.b[(size_t)h] + r.b[(size_t)h]; out.p[(size_t)h] = out.p[(size_t)h] + r.p[(size_t)h]; }
    }
    return out;
  }
  // The turn card of a study that starts on the flop: every card in ascending order, then the division by the
  // number of cards the two hands and the board leave (52 - 3 - 4). `terminal`: `t` is a showdown that only
  // waits for the cards.
  VV dealTurn(const BS &t, int state, const std::vector<double> &reach, bool terminal) {
    VV out; out.b.assign((size_t)nOwn, 0.0); out.p.assign((size_t)nOwn, 0.0); const uint64_t pb = pub(3); std::vector<double> r2;
    for (int x = 0; x < 52; x++) {
      if (pb >> x & 1) continue;
      without(reach, oppMask, x, r2); E.cards[3] = x;
      const VV r = terminal ? riverGroup(t, state, 4, r2) : walk(state, t, 4, r2);
      for (int h = 0; h < nOwn; h++) { if (ownMask[(size_t)h] >> x & 1) continue; out.b[(size_t)h] = out.b[(size_t)h] + r.b[(size_t)h]; out.p[(size_t)h] = out.p[(size_t)h] + r.p[(size_t)h]; }
    }
    const double deck = 52 - 3 - 4;
    for (int h = 0; h < nOwn; h++) { out.b[(size_t)h] = out.b[(size_t)h] / deck; out.p[(size_t)h] = out.p[(size_t)h] / deck; }
    return out;
  }
  VV root() {
    std::vector<double> reach((size_t)nOpp, 0.0);
    for (int o = 0; o < nOpp; o++) { const Hand &h = m.hands[(size_t)opp][(size_t)o]; if (h.w > 0 && !(oppMask[(size_t)o] & T.startMask)) reach[(size_t)o] = h.w; }
    std::copy_n(m.board, 5, E.cards); path.clear(); cursor = 0;
    return walk(0, g.rootState, m.startLen, reach);
  }

  // One item through the kernel compiled into this program.
  void cpuItem(size_t item, double *out, uint32_t *cnt, double *wd, int32_t *wi) const {
    int32_t one[4] = {ITEM[item * 4], ITEM[item * 4 + 1], ITEM[item * 4 + 2], ITEM[item * 4 + 3]};
    brhu_item(NODE.data(), CH.data(), NUM.data(), T.HK.data(), T.HV.data(), T.POL.data(), T.KK.data(), T.SC.data(), T.ORD.data(), T.HAND.data(),
              REACH.data(), one, out, cnt, wd, wi, T.hmask, 0, seat, nOwn, nOpp, T.HS, D, 0, 0);
  }
  // Adds the items of a group in the order of their river cards and divides by the number of river cards.
  void finishGroup(size_t gi, const double *outs /* [count][2][nOwn] */) {
    const Group &G = groups[gi]; double *gv = GV.data() + gi * 2 * (size_t)nOwn; const size_t w = 2 * (size_t)nOwn;
    for (size_t x = 0; x < w; x++) gv[x] = 0.0;
    for (int i = 0; i < G.count; i++) { const double *o = outs + (size_t)i * w; for (size_t x = 0; x < w; x++) gv[x] = gv[x] + o[x]; }
    if (G.div > 0) for (size_t x = 0; x < w; x++) gv[x] = gv[x] / G.div;
  }
  void runCpu(EvShared &S, int threads) {
    const int workers = std::max(1, threads); const size_t w = 2 * (size_t)nOwn;
    std::vector<std::vector<double>> wd((size_t)workers), outs((size_t)workers); std::vector<std::vector<int32_t>> wi((size_t)workers); std::vector<long long> look((size_t)workers, 0), fall((size_t)workers, 0);
    parallelFor(S.ctl, workers, groups.size(), [&](int wk, size_t gi) {
      auto &d = wd[(size_t)wk]; auto &o = outs[(size_t)wk]; auto &ii = wi[(size_t)wk];
      if (d.empty()) { d.assign(DW(), 0.0); ii.assign(IW(), 0); o.assign(48 * w, 0.0); }
      const Group &G = groups[gi]; uint32_t cnt[2];
      for (int i = 0; i < G.count; i++) { cpuItem((size_t)G.first + (size_t)i, o.data() + (size_t)i * w, cnt, d.data(), ii.data()); look[(size_t)wk] += cnt[0]; fall[(size_t)wk] += cnt[1]; }
      finishGroup(gi, o.data());
    });
    for (int i = 0; i < workers; i++) { C.kernelLookups += look[(size_t)i]; C.kernelFallbacks += fall[(size_t)i]; }
  }
};

// The device side of one request: opened once, the shared tables uploaded once, used by both seats.
struct Gpu {
  brhu::ClRun R; brhu::cl_mem bHK = nullptr, bHV = nullptr, bPOL = nullptr, bKK = nullptr, bSC = nullptr, bORD = nullptr, bHAND = nullptr;
  bool open(const Tables &T, std::string &why) {
    if (!R.open()) { why = R.error; return false; }
    if (R.dev.memBytes && T.bytes() > 0.6 * (double)R.dev.memBytes) { why = "the tables of this study (" + std::to_string((long long)(T.bytes() / 1048576) + 1) + " MiB) do not fit in the memory of the device (" + std::to_string(R.dev.memBytes >> 20) + " MiB)"; return false; }
    bHK = R.buffer(T.HK.size() * 8, T.HK.data(), "row keys"); bHV = bHK ? R.buffer(T.HV.size() * 4, T.HV.data(), "row index") : nullptr; bPOL = bHV ? R.buffer(T.POL.size() * 8, T.POL.data(), "policy") : nullptr;
    bKK = bPOL ? R.buffer(T.KK.size() * 8, T.KK.data(), "board key") : nullptr; bSC = bKK ? R.buffer(T.SC.size() * 4, T.SC.data(), "board score") : nullptr; bORD = bSC ? R.buffer(T.ORD.size() * 2, T.ORD.data(), "board order") : nullptr;
    bHAND = bORD ? R.buffer(T.HAND.size() * 4, T.HAND.data(), "hand") : nullptr;
    if (!bHAND) { why = R.error; return false; }
    return true;
  }
  // Every item of the seat on the device, in batches of whole groups; every `verifyEvery`-th item (and the first of
  // every batch) is worked again on the CPU and must have the same bits.
  void run(Seat &Z, const Tables &T, EvShared &S, long long verifyEvery, Counters &C) {
    using namespace brhu; const size_t nOwn = (size_t)Z.nOwn, nOpp = (size_t)Z.nOpp, w = 2 * nOwn, DW = Z.DW(), IW = Z.IW();
    auto die = [&](const std::string &what) { throw QueryError{500, "exact-hu on the GPU failed (" + what + "); no result is reported. brDevice cpu computes the same value."}; };
    cl_mem bNODE = R.buffer(Z.NODE.size() * 4, Z.NODE.data(), "tree"), bCH = R.buffer(Z.CH.size() * 4, Z.CH.data(), "tree children"), bNUM = R.buffer(Z.NUM.size() * 8, Z.NUM.data(), "tree numbers");
    if (!bNODE || !bCH || !bNUM) die(R.error);
    // slots: what the scratch may take (a quarter of the device memory, at most 1 GiB and one buffer)
    uint64_t budget = std::min<uint64_t>(R.dev.memBytes ? R.dev.memBytes / 4 : (256ULL << 20), 1024ULL << 20);
    if (R.dev.maxAllocBytes) budget = std::min<uint64_t>(budget, R.dev.maxAllocBytes);
    size_t slots = (size_t)std::clamp<uint64_t>(budget / (DW * 8 + w * 8 + IW * 4 + 64), 64, 8192);
    if (const char *env = std::getenv("EM_BRHU_BATCH")) { const long v = std::strtol(env, nullptr, 10); if (v >= 48 && v <= 65536) slots = (size_t)v; }
    slots = slots / 64 * 64; if (slots < 64) slots = 64;
    const size_t maxGroups = slots;   // a group has at least one item
    cl_mem bWD = R.buffer(slots * DW * 8, nullptr, "scratch"), bWI = bWD ? R.buffer(slots * IW * 4, nullptr, "scratch index") : nullptr, bOUT = bWI ? R.buffer(slots * w * 8, nullptr, "result") : nullptr,
           bCNT = bOUT ? R.buffer(slots * 2 * 4, nullptr, "counters") : nullptr, bITEM = bCNT ? R.buffer(slots * 4 * 4, nullptr, "items") : nullptr, bREACH = bITEM ? R.buffer(maxGroups * nOpp * 8, nullptr, "reach") : nullptr,
           bPAR = bREACH ? R.buffer(64, nullptr, "parameters") : nullptr;
    if (!bPAR) die(R.error);
    const cl_mem args[17] = {bNODE, bCH, bNUM, bHK, bHV, bPOL, bKK, bSC, bORD, bHAND, bREACH, bITEM, bOUT, bCNT, bWD, bWI, bPAR};
    for (cl_uint i = 0; i < 17; i++) { const cl_int e = R.A.SetKernelArg(R.krn, i, sizeof(cl_mem), &args[i]); if (e != 0) { R.fail("kernel argument", e); die(R.error); } }
    std::vector<double> out(slots * w), reach, cd(DW), co(w); std::vector<uint32_t> cnt(slots * 2); std::vector<int32_t> items, ci(IW);
    size_t limit = std::min<size_t>(slots, 256); double perItem = 0;   // the first batch is small; later ones aim at a fifth of a second
    for (size_t g0 = 0; g0 < Z.groups.size();) {
      Z.E.visits++; Z.E.poll(SITE_BR);
      items.clear(); reach.clear(); size_t g1 = g0, count = 0;
      while (g1 < Z.groups.size() && count + (size_t)Z.groups[g1].count <= limit) {
        const Seat::Group &G = Z.groups[g1];
        for (int i = 0; i < G.count; i++) { const int32_t *it = Z.ITEM.data() + ((size_t)G.first + (size_t)i) * 4; items.insert(items.end(), {it[0], it[1], (int32_t)(g1 - g0), it[3]}); }
        reach.insert(reach.end(), Z.REACH.begin() + (long long)(g1 * nOpp), Z.REACH.begin() + (long long)((g1 + 1) * nOpp)); count += (size_t)G.count; g1++;
      }
      const uint64_t par[8] = {T.hmask, 0, (uint64_t)Z.seat, (uint64_t)nOwn, (uint64_t)nOpp, (uint64_t)T.HS, (uint64_t)Z.D, (uint64_t)count};
      const double t0 = nowSec();
      if (!R.write(bITEM, items.size() * 4, items.data(), "items") || !R.write(bREACH, reach.size() * 8, reach.data(), "reach") || !R.write(bPAR, sizeof par, par, "parameters") ||
          !R.launch(R.krn, count) || !R.read(bOUT, count * w * 8, out.data(), "result") || !R.read(bCNT, count * 2 * 4, cnt.data(), "counters")) die(R.error);
      const double dt = nowSec() - t0; perItem = dt / (double)count; C.gpuBatches++; C.gpuItems += (long long)count;
      if (C.gpuBatches == 1) if (const char *test = std::getenv("EM_BRHU_TEST")) if (!std::strcmp(test, "flip")) { uint64_t bits; std::memcpy(&bits, &out[0], 8); bits ^= 1; std::memcpy(&out[0], &bits, 8); }   // test only: one bit of a device result altered
      const double tv = nowSec();
      for (size_t i = 0, at = 0; i < count; i++) {
        C.kernelLookups += cnt[i * 2]; C.kernelFallbacks += cnt[i * 2 + 1];
        const size_t global = (size_t)Z.groups[g0].first + i; (void)at;
        if (verifyEvery > 0 && (i == 0 || global % (size_t)verifyEvery == 0)) {
          uint32_t cc[2]; Z.cpuItem(global, co.data(), cc, cd.data(), ci.data()); C.verifiedItems++;
          if (std::memcmp(co.data(), out.data() + i * w, w * 8) || cc[0] != cnt[i * 2] || cc[1] != cnt[i * 2 + 1]) {
            C.mismatches++;
            die("item " + std::to_string(global) + " of seat " + std::to_string(Z.seat) + " has other bits on the device than on the CPU");
          }
        }
      }
      C.secVerify += nowSec() - tv;
      for (size_t gi = g0, at = 0; gi < g1; gi++) { Z.finishGroup(gi, out.data() + at * w); at += (size_t)Z.groups[gi].count; }
      g0 = g1;
      if (perItem > 0) limit = (size_t)std::clamp<double>(0.2 / perItem, 48.0, (double)slots);
    }
    for (cl_mem b : {bNODE, bCH, bNUM, bWD, bWI, bOUT, bCNT, bITEM, bREACH, bPAR}) R.release(b);
  }
};

struct Result { double br = 0, pv = 0, z = 0; };
inline Result seatResponse(const MW &m, const Game &g, Evaluator &E, const Tables &T, int seat, const Options &O, Gpu *gpu, EvShared &S, Counters &C) {
  Seat Z(m, g, E, T, seat, C);
  double t0 = nowSec();
  Z.collect = true; Z.root();
  C.groups += (long long)Z.groups.size(); C.items += (long long)(Z.ITEM.size() / 4); C.depth = std::max(C.depth, Z.D);
  const double need = (double)Z.groups.size() * 2 * Z.nOwn * 8 + (double)Z.REACH.size() * 8 + (double)Z.ITEM.size() * 4 + T.bytes();
  if (need > (double)O.memoryBytes) throw QueryError{422, "exact-hu needs " + std::to_string((long long)(need / 1048576) + 1) + " MiB for this study (" + std::to_string(Z.groups.size()) + " river groups); memoryMiB allows " + std::to_string(O.memoryBytes >> 20)};
  Z.GV.assign(Z.groups.size() * 2 * (size_t)Z.nOwn, 0.0);
  C.secWalk += nowSec() - t0; t0 = nowSec();
  if (gpu) gpu->run(Z, T, S, O.where == Where::Both ? 1 : O.verifyEvery, C); else Z.runCpu(S, O.threads);
  C.secItems += nowSec() - t0; t0 = nowSec();
  Z.collect = false; const VV v = Z.root();
  C.secWalk += nowSec() - t0;
  Result r;
  const auto &own = m.hands[(size_t)seat]; const auto &other = m.hands[(size_t)(1 - seat)];
  for (size_t h = 0; h < own.size(); h++) {
    const uint64_t om = (1ULL << own[h].a) | (1ULL << own[h].b);
    if (!(own[h].w > 0) || (om & T.startMask)) continue;
    double z = 0; bool any = false;   // the weight of the opponent's hands this hand can meet, in the order of method "exact"
    for (size_t o = 0; o < other.size(); o++) { const uint64_t b = (1ULL << other[o].a) | (1ULL << other[o].b); if (((T.startMask | om) & b) || !(other[o].w > 0)) continue; z += 1.0 * other[o].w; any = true; }
    if (!any) continue;
    r.br += own[h].w * v.b[h]; r.pv += own[h].w * v.p[h]; r.z += own[h].w * z;
  }
  return r;
}
} // namespace hu
} // namespace es
} // namespace
