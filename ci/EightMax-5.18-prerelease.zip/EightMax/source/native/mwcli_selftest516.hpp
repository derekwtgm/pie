// EightMax 5.16 (Phase 6, card-grouping error): mwcli --selftest516 <studies-dir> <work-dir> [all|training|checkpoint]
//
// The Ranked hand grouping ranked-5.16-v1 (es_groups.hpp RankedGroups). The specs are the shipped Compact fixtures
// flop3-kings (three seats) and flop6-jack (six seats) with the grouping named "ranked" instead of "compact"; nothing
// else is changed, so the pair differs in the grouping alone.
//   training    T1  recorded states (SHA-256 from the Linux build): both fixtures, 5.10 streams and philox64, one deal
//                     per update and frozen batches on three threads. A state holds the key of every row, so these
//                     hashes also pin the key function;
//                 T2  a frozen batch writes the same state on 1 and 3 threads; stopped after a third and continued =
//                     uninterrupted, byte for byte;
//                 T3  the trainer names the grouping; a Ranked table has more rows than the Compact one of the same
//                     fixture and budget and fewer than the Detailed one.
//   checkpoint  C1  a Ranked state names "grouping":"ranked-5.16-v1" in its header; Compact and Detailed states name none;
//                 C2  refused with the reason, exit 1 and nothing written: a Ranked state continued by the Compact
//                     study, a Compact state continued by the Ranked study; the Ranked study continues its own state;
//                 C3  specs refused before training: Ranked on a study that starts before the flop, an unknown
//                     grouping name.
// That the default trainer and the groupings Compact, Detailed and Exact cards write the states of 5.15 is checked by
// the earlier self-tests (their recorded states are unchanged) and by validation/5.16/identity516.py.
// Report: <work-dir>/selftest516.json. Exit status: 0 every check passed, 1 a check failed or is untested, 2 usage.
//   mwcli --selftest516 studies work record   writes selftest516_golden.hpp from THIS build (once, on Linux, at release).
#pragma once
namespace st516 {
namespace fs = std::filesystem;
using st58::Report; using st58::fmt; using st58::get; using st58::num; using st58::str; using st58::Doc;
using st510::writeText; using st510::Trained; using st510::train;
using st512::optionsOf; using st513::Fx; using st513::fixtureOf;
struct Golden516 { const char *fixture; long long updates; bool batch, wide; const char *sha; };
static const Golden516 GOLDEN516[] = {
#include "selftest516_golden.hpp"
};
static const std::vector<std::pair<std::string, std::string>> FIXED = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
static const char *const FIXTURES[] = {"flop3-kings", "flop6-jack"};
// the fixture's spec with another grouping name (both places); empty when the spec does not name Compact twice
static Fx grouped(const std::string &studies, const std::string &work, const char *fixture, const std::string &options, const std::string &tag, const char *grouping, std::string &why) {
  Fx f = fixtureOf(studies, work, fixture, options, tag, why); if (f.path.empty()) return f;
  const std::string from = "\"abstraction\":\"compact\"", to = std::string("\"abstraction\":\"") + grouping + "\""; int n = 0;
  for (size_t p = 0; (p = f.spec.find(from, p)) != std::string::npos; p += to.size()) { f.spec.replace(p, from.size(), to); n++; }
  std::error_code ec;
  if (n != 2 || !writeText(f.path, f.spec)) { why = std::string(fixture) + ": the spec does not name the Compact grouping twice"; fs::remove(f.path, ec); f.path.clear(); }
  return f;
}
static std::string headOf(const std::string &path) { const std::vector<unsigned char> raw = slurp(path.c_str()); return std::string(raw.begin(), raw.begin() + std::min<size_t>(raw.size(), 900)); }
static void trainingSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "training"; std::error_code ec; auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); };
  { int same = 0, total = 0; std::string detail;
    for (const Golden516 &g : GOLDEN516) { total++; std::string why; const Fx f = grouped(studies, work, g.fixture, optionsOf(g.wide, g.batch), "t1", "ranked", why); if (f.path.empty()) { detail += why + "; "; continue; }
      const Trained t = train(self, work, f.path, g.updates, g.batch ? 3 : 1, state("t1"), "", "512", FIXED);
      if (t.ok && t.sha == g.sha) same++; else detail += std::string(g.fixture) + (g.wide ? " philox64" : " 5.10 streams") + (g.batch ? " (batch)" : "") + ": " + (t.ok ? "state " + t.sha.substr(0, 16) + " instead of " + std::string(g.sha).substr(0, 16) : "exit " + std::to_string(t.exitCode) + " " + t.err) + "; ";
      fs::remove(f.path, ec); }
    R.check(sec, "T1", "training with the Ranked grouping ranked-5.16-v1: the saved states have the SHA-256 recorded from the Linux build of this release (flop3-kings and flop6-jack with Ranked instead of Compact groups; 5.10 streams and philox64; one deal per update and frozen batches of 64 on three threads). A state holds the key of every row, so the key function is pinned too", same == total && total > 0, std::to_string(same) + " of " + std::to_string(total) + " states identical" + (detail.empty() ? "" : "; " + detail)); fs::remove(state("t1"), ec); }
  { int good = 0, n = 0; std::string detail;
    for (const char *fx : FIXTURES) for (const bool wide : {false, true}) {
      n++; std::string why; const Fx f = grouped(studies, work, fx, optionsOf(wide, false), "t2", "ranked", why), fb = grouped(studies, work, fx, optionsOf(wide, true), "t2b", "ranked", why);
      if (f.path.empty() || fb.path.empty()) { detail += why + "; "; continue; }
      const Trained a = train(self, work, f.path, 9000, 1, state("t2a")), p = train(self, work, f.path, 3000, 1, state("t2p")), k = p.ok ? train(self, work, f.path, 6000, 1, state("t2c"), state("t2p")) : Trained{};
      const Trained b1 = train(self, work, fb.path, 150, 1, state("t2d"), "", "512", FIXED), b3 = train(self, work, fb.path, 150, 3, state("t2e"), "", "512", FIXED), bp = train(self, work, fb.path, 50, 2, state("t2f"), "", "512", FIXED), bc = bp.ok ? train(self, work, fb.path, 100, 3, state("t2g"), state("t2f"), "512", FIXED) : Trained{};
      const bool ok = a.ok && k.ok && b1.ok && b3.ok && bc.ok && k.sha == a.sha && b1.sha == b3.sha && bc.sha == b1.sha; good += ok;
      if (!ok) detail += std::string(fx) + (wide ? " philox64" : " 5.10 streams") + ": continued " + (k.sha == a.sha ? "same" : "DIFFERENT") + ", 3 threads " + (b1.sha == b3.sha ? "same" : "DIFFERENT") + ", batch continued " + (bc.sha == b1.sha ? "same" : "DIFFERENT") + " [exit codes: uninterrupted " + std::to_string(a.exitCode) + ", part " + std::to_string(p.exitCode) + ", continued " + std::to_string(k.exitCode) + ", batch 1 thread " + std::to_string(b1.exitCode) + ", 3 threads " + std::to_string(b3.exitCode) + ", batch part " + std::to_string(bp.exitCode) + ", batch continued " + std::to_string(bc.exitCode) + "] " + a.err + k.err + b1.err + b3.err + bc.err + "; ";
      fs::remove(f.path, ec); fs::remove(fb.path, ec); }
    R.check(sec, "T2", "with the Ranked grouping a frozen batch gives the same state on 1 and 3 threads, and a training stopped after a third and continued equals the uninterrupted one, byte for byte (the key of a hand is a function of the spec and the cards alone, whichever thread computes the range's strengths on a board first); two fixtures, 5.10 streams and philox64", good == n && n > 0, std::to_string(good) + " of " + std::to_string(n) + " cases" + (detail.empty() ? "" : "; " + detail));
    for (const char *t : {"t2a", "t2p", "t2c", "t2d", "t2e", "t2f", "t2g"}) fs::remove(state(t), ec); }
  { std::string why, detail; bool ok = true; long long rows[3] = {0, 0, 0}; const char *names[3] = {"compact", "ranked", "detailed"};
    for (int i = 0; i < 3; i++) { const Fx f = grouped(studies, work, "flop3-kings", "", "t3", names[i], why); const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 20000, 1, state("t3")); Doc d(t.out);
      const std::string named = str(get(get(d.v, "handGroups"), "abstraction")); rows[i] = t.rows; const bool good = t.ok && named == names[i]; ok = ok && good;
      detail += std::string(names[i]) + ": " + (good ? std::to_string(t.rows) + " rows" : "NOT AS EXPECTED (named \"" + named + "\") " + t.err) + "; "; if (!f.path.empty()) fs::remove(f.path, ec); }
    R.check(sec, "T3", "the trainer names the grouping it trained with, and after 20,000 deals on flop3-kings the Ranked table has more rows than the Compact one and fewer than the Detailed one", ok && rows[0] < rows[1] && rows[1] < rows[2], detail); fs::remove(state("t3"), ec); }
}
static void checkpointSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "checkpoint"; std::error_code ec; auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); }; std::string why;
  const Fx rk = grouped(studies, work, "flop3-kings", "", "c-ranked", "ranked", why), cp = grouped(studies, work, "flop3-kings", "", "c-compact", "compact", why), dt = grouped(studies, work, "flop3-kings", "", "c-detailed", "detailed", why);
  if (rk.path.empty() || cp.path.empty() || dt.path.empty()) { R.add(sec, "C1", "checkpoint rules of the Ranked grouping", "untested", why); return; }
  const Trained tr = train(self, work, rk.path, 2000, 1, state("c-ranked")), tc = train(self, work, cp.path, 2000, 1, state("c-compact")), td = train(self, work, dt.path, 2000, 1, state("c-detailed"));
  { const std::string hr = headOf(state("c-ranked")), hc = headOf(state("c-compact")), hd = headOf(state("c-detailed"));
    const bool named = hr.find("\"grouping\":\"ranked-5.16-v1\"") != std::string::npos && hr.find("\"rowKeys\":2") != std::string::npos && hc.find("\"rowKeys\":1") != std::string::npos && hd.find("\"rowKeys\":1") != std::string::npos, none = hc.find("\"grouping\"") == std::string::npos && hd.find("\"grouping\"") == std::string::npos;
    R.check(sec, "C1", "a state trained with the Ranked grouping names \"grouping\":\"ranked-5.16-v1\" and \"rowKeys\":2 in its header (earlier programs refuse that row format); Compact and Detailed states of the same spot name no grouping (their headers are those of 5.15)", tr.ok && tc.ok && td.ok && named && none, std::string(named ? "the Ranked state names the grouping" : "THE RANKED STATE DOES NOT NAME THE GROUPING") + "; Compact and Detailed states: " + (none ? "no grouping field" : "NAME ONE") + (tr.ok && tc.ok && td.ok ? "" : "; a training failed: " + tr.err + tc.err + td.err)); }
  { struct Try { const std::string *spec; const char *in, *want; }; const Try tries[] = {{&cp.path, "c-ranked", "trained with a hand grouping this study does not use"}, {&rk.path, "c-compact", "was not trained with the Ranked grouping ranked-5.16-v1"}, {&dt.path, "c-ranked", ""}, {&rk.path, "c-detailed", ""}};
    int refused = 0; std::string detail;
    for (const Try &t : tries) { const std::string out = state("c-no"); fs::remove(out, ec); const Trained r = train(self, work, *t.spec, 5, 1, out, state(t.in)); const bool ok = !r.ok && r.exitCode == 1 && !r.err.empty() && r.err.find(t.want) != std::string::npos && !fs::exists(out, ec); refused += ok;
      if (!ok) detail += std::string(t.in) + ": exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 200) + "; "; }
    const Trained c = train(self, work, rk.path, 5, 1, state("c-yes"), state("c-ranked"));
    R.check(sec, "C2", "refused with a reason, exit 1 and nothing written: a Ranked state continued by the Compact study and by the Detailed study, a Compact state and a Detailed state continued by the Ranked study (the four specs carry the same study identifier here, so the header field alone must stop the first two); the Ranked study continues its own state", refused == 4 && c.ok, "refused " + std::to_string(refused) + " of 4; own state " + (c.ok ? "continued" : "NOT CONTINUED: " + c.err) + (detail.empty() ? "" : "; " + detail)); fs::remove(state("c-yes"), ec); fs::remove(state("c-no"), ec); }
  { int refused = 0, n = 0; std::string detail; struct Bad { const char *fixture, *grouping, *want; }; const Bad bad[] = {{"btn25-open", "ranked", "starts on the flop, turn or river"}, {"flop3-kings", "rankedx", "Compact, Detailed or Ranked"}};
    for (const Bad &b : bad) { n++; const Fx f = grouped(studies, work, b.fixture, "", "c3", b.grouping, why); const std::string out = state("c3"); fs::remove(out, ec);
      const Trained r = f.path.empty() ? Trained{} : train(self, work, f.path, 5, 1, out); const bool ok = !f.path.empty() && !r.ok && r.exitCode == 1 && r.err.find(b.want) != std::string::npos && !fs::exists(out, ec); refused += ok;
      if (!ok) detail += std::string("expected \"") + b.want + "\": " + (f.path.empty() ? why : "exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 160)) + "; "; if (!f.path.empty()) fs::remove(f.path, ec); }
    R.check(sec, "C3", "specs refused before anything is trained, with the reason, exit 1 and nothing written: the Ranked grouping on a study that starts before the flop (btn25-open), an unknown grouping name", refused == n, std::to_string(refused) + " of " + std::to_string(n) + " refused" + (detail.empty() ? "" : "; " + detail)); }
  for (const Fx *f : {&rk, &cp, &dt}) fs::remove(f->path, ec);
  for (const char *t : {"c-ranked", "c-compact", "c-detailed"}) fs::remove(state(t), ec);
}
static int record(const std::string &studies, const std::string &work, const std::string &self) {
  std::error_code ec; std::string golden, why; int bad = 0, count = 0; auto p = [&](const char *n) { return (fs::path(work) / n).string(); };
  for (const char *fx : FIXTURES) for (const bool wide : {false, true}) for (const bool batch : {false, true}) {
    const Fx f = grouped(studies, work, fx, optionsOf(wide, batch), "record", "ranked", why); const long long updates = batch ? 150 : 9000;
    const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, updates, batch ? 3 : 1, p("record.state"), "", "512", FIXED); bad += !t.ok; count++;
    golden += std::string("{\"") + fx + "\", " + std::to_string(updates) + ", " + (batch ? "true" : "false") + ", " + (wide ? "true" : "false") + ", \"" + (t.ok ? t.sha : "FAILED") + "\"},\n"; if (!f.path.empty()) fs::remove(f.path, ec); }
  fs::remove(p("record.state"), ec); writeText(p("selftest516_golden.hpp"), golden);
  std::printf("{\"recorded\":%d,\"failed\":%d%s}\n", count, bad, why.empty() ? "" : (",\"note\":" + mwa::jsonEsc(why)).c_str()); return bad ? 1 : 0;
}
static int run(int argc, char **argv) {
  if (argc < 4 || argc > 5) { std::fprintf(stderr, "usage: mwcli --selftest516 studies-dir work-dir [all|training|checkpoint]\n"); return 2; }
  const std::string studies = argv[2], work = argv[3], section = argc > 4 ? argv[4] : "all"; std::error_code ec; fs::create_directories(work, ec); mw_study_identity(EM_VERSION, EM_BUILD_ID);
  if (section == "record") return record(fs::absolute(studies, ec).string(), fs::absolute(work, ec).string(), ckpt::selfPath(argv[0]));
  if (section != "all" && section != "training" && section != "checkpoint") { std::fprintf(stderr, "error: the section must be all, training or checkpoint\n"); return 2; }
  if (!fs::is_directory(studies, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: studies-dir and work-dir must be directories\n"); return 2; }
  Report R; const auto t0 = std::chrono::steady_clock::now(); const std::string S = fs::absolute(studies, ec).string(), W = fs::absolute(work, ec).string(), self = ckpt::selfPath(argv[0]);
  if (section == "all" || section == "training") trainingSection(R, S, W, self);
  if (section == "all" || section == "checkpoint") checkpointSection(R, S, W, self);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest516\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"" + section + "\",\"grouping\":\"ranked-5.16-v1\",\"passed\":" + std::to_string(R.passed) + ",\"failed\":" + std::to_string(R.failed) + ",\"untested\":" + std::to_string(R.untested) + ",\"seconds\":" + fmt(secs) + ",\"checks\":[";
  for (size_t i = 0; i < R.checks.size(); i++) { const st58::Check &c = R.checks[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}"; const std::string report = (fs::path(work) / "selftest516.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest516\",\"build\":\"%s\",\"section\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"report\":%s}\n", EM_BUILD_ID, section.c_str(), R.passed, R.failed, R.untested, mwa::jsonEsc(report).c_str());
  return R.failed || R.untested ? 1 : 0;
}
}
