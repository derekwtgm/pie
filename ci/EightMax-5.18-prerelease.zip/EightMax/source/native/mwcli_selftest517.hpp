// EightMax 5.17 (Phase 7, exact best response on the GPU): mwcli --selftest517 <cases-dir> <studies-dir> <work-dir> [all|cpu|gpu]
//
// Method exact-hu (brhu-5.17-v1): the exact best response of a heads-up postflop study over whole ranges, on the
// CPU and on an OpenCL GPU. The cases are the specs of <cases-dir> (validation/5.17/windows/brhu) with the values
// recorded on the Linux build in <cases-dir>/reference.json: the SHA-256 of each trained state and the bits of
// every value.
//
//   cpu  S1  training every case gives the state recorded on Linux (the default trainer, one thread)
//        B1  exact-hu on one CPU thread: the bits recorded on Linux, for every case, seat and value
//        B2  the same bits on 2, 3 and 4 CPU threads
//        B3  agreement with method exact (1e-9 relative) on every case method exact finished within 30 seconds on Linux
//        B4  a table with no stored strategy: every lookup falls back; equal to method exact; refused with
//            missing "refuse"
//        B5  policy "current": agreement with method exact
//        B6  refusals with a reason: three seats, a tournament or preflop study, brDevice with another method,
//            too little memory
//   gpu  G1  an OpenCL device with double precision, the kernel compiled by its driver, the arithmetic probe
//        G2  brDevice gpu: the bits of the CPU for every case
//        G3  brDevice both: every item repeated on the CPU, none with other bits
//        G4  device batches of 48 and of 4096 items: the same bits
//        G5  one bit of a device result altered (test hook): the request fails and reports no value
//        G6  the unprotected kernel (test hook): refused if this device fuses a product with a sum
//      Without a usable device every gpu check is "skipped" (reported, not a failure): nothing about a GPU was tested.
//
// Report: <work-dir>/selftest517.json (with the seconds of every case on the CPU and on the device).
// Exit status: 0 every check passed (skipped checks allowed), 1 a check failed or is untested, 2 usage.
//   mwcli --selftest517 cases studies work record   fills <work-dir>/reference.json from THIS build (Linux, at release).
#pragma once
namespace st517 {
namespace fs = std::filesystem;
using st58::Report; using st58::get; using st58::num; using st58::str; using st58::Doc;
using st510::writeText; using st510::Trained; using st510::train;
static const std::vector<std::pair<std::string, std::string>> FIXED = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
struct Case { std::string name, spec, sha; long long deals = 0; bool exact = false; std::string bits[2][3], nash; };   // bits: seat x {policy value, best response value, gain}
struct Gain { bool ok = false; int exitCode = -1; std::string err, bits[2][3], nash, raw; double v[2][3] = {}, nc = NAN, ms = 0; long long lookups = 0, fallbacks = 0, repeated = -1, other = -1, items = 0, batches = 0; std::string device; bool isGpu = false; };
static std::string text(const std::string &path) { const std::vector<unsigned char> raw = slurp(path.c_str()); return std::string(raw.begin(), raw.end()); }
static bool loadCases(const std::string &dir, std::vector<Case> &out, std::string &why) {
  const std::string t = text((fs::path(dir) / "reference.json").string()); Doc d(t); const JV *cs = get(d.v, "cases");
  if (!cs || cs->type != J_ARR) { why = "reference.json of the cases directory is missing or unreadable"; return false; }
  for (int i = 0; i < cs->n; i++) {
    const JV *c = cs->items[i]; Case k; k.name = str(get(c, "name")); k.spec = (fs::path(dir) / str(get(c, "spec"))).string(); k.deals = (long long)num(get(c, "deals"), 0); k.sha = str(get(c, "stateSha256"));
    const JV *e = get(c, "exactFinishes"); k.exact = e && e->type == J_BOOL && e->num != 0; k.nash = str(get(c, "nashConvBits"));
    const JV *s = get(c, "seats");
    if (s && s->type == J_ARR && s->n == 2) for (int p = 0; p < 2; p++) { k.bits[p][0] = str(get(s->items[p], "policyValueBits")); k.bits[p][1] = str(get(s->items[p], "bestResponseValueBits")); k.bits[p][2] = str(get(s->items[p], "gainBits")); }
    if (k.name.empty() || k.deals < 1) { why = "reference.json: a case without name or deals"; return false; }
    out.push_back(k);
  }
  if (out.empty()) { why = "reference.json lists no case"; return false; }
  return true;
}
static Gain gain(const std::string &self, const std::string &work, const std::string &spec, const std::string &state, const std::string &request, const std::vector<std::pair<std::string, std::string>> &env = {}, const char *mem = "4096") {
  Gain g; const std::string rq = (fs::path(work) / "st517-request.json").string(); writeText(rq, request);
  const ckpt::Run r = ckpt::spawn({self, "--gain", spec, state, rq, mem}, work, 3600, env); g.exitCode = r.exitCode; g.err = (r.err + " " + r.out).substr(0, 300); g.raw = r.out; g.ms = r.ms;
  if (!r.started || r.exitCode != 0) return g;
  Doc d(r.out); const JV *s = get(d.v, "seats");
  if (!s || s->type != J_ARR) return g;
  for (int p = 0; p < s->n && p < 2; p++) {
    const JV *x = s->items[p]; static const char *names[3] = {"policyValue", "bestResponseValue", "gain"};
    for (int k = 0; k < 3; k++) { g.v[p][k] = num(get(x, names[k])); g.bits[p][k] = str(get(x, (std::string(names[k]) + "Bits").c_str())); }
    g.lookups += (long long)num(get(x, "policyLookups"), 0); g.fallbacks += (long long)num(get(x, "fallbackLookups"), 0);
  }
  g.nc = num(get(d.v, "nashConv")); g.nash = str(get(d.v, "nashConvBits")); g.items = (long long)num(get(get(d.v, "exactHu"), "items"), 0);
  if (const JV *u = get(d.v, "gpu")) { g.repeated = (long long)num(get(u, "itemsRepeatedOnCpu"), -1); g.other = (long long)num(get(u, "itemsWithOtherBits"), -1); g.batches = (long long)num(get(u, "batches"), 0); g.device = str(get(u, "device")); const JV *b = get(u, "isGpu"); g.isGpu = b && b->type == J_BOOL && b->num != 0; }
  g.ok = s->n == 2 && std::isfinite(g.nc); return g;
}
static bool sameBits(const Gain &g, const Case &c) { for (int p = 0; p < 2; p++) for (int k = 0; k < 3; k++) if (g.bits[p][k].empty() || g.bits[p][k] != c.bits[p][k]) return false; return g.nash == c.nash; }
static bool sameBits(const Gain &a, const Gain &b) { for (int p = 0; p < 2; p++) for (int k = 0; k < 3; k++) if (a.bits[p][k].empty() || a.bits[p][k] != b.bits[p][k]) return false; return a.nash == b.nash; }
static bool close(double a, double b) { return std::isfinite(a) && std::isfinite(b) && std::fabs(a - b) <= 1e-9 * std::max(1.0, std::fabs(b)); }
static bool agree(const Gain &hu, const Gain &ex) { for (int p = 0; p < 2; p++) for (int k = 0; k < 3; k++) if (!close(hu.v[p][k], ex.v[p][k])) return false; return close(hu.nc, ex.nc); }
static std::string hu(int threads, const char *extra = "") { return std::string("{\"method\":\"exact-hu\",\"timeLimitMs\":3600000,\"memoryMiB\":4096,\"threads\":") + std::to_string(threads) + extra + "}"; }
static const char *EXACT = "{\"method\":\"exact\",\"maxVisits\":2000000000,\"timeLimitMs\":3600000,\"memoryMiB\":2048,\"threads\":2}";
struct Timing { std::string name; double cpu1 = -1, cpuN = -1, gpu = -1, exact = -1; long long items = 0; };

static std::string stateOf(const std::string &work, const Case &c) { return (fs::path(work) / ("st517-" + c.name + ".state")).string(); }
static void cpuSection(Report &R, const std::vector<Case> &cases, const std::string &studies, const std::string &work, const std::string &self, std::vector<Timing> &times) {
  const std::string sec = "cpu"; std::error_code ec;
  { int same = 0; std::string detail;
    for (const Case &c : cases) { const Trained t = train(self, work, c.spec, c.deals, 1, stateOf(work, c), "", "2048", FIXED); if (t.ok && t.sha == c.sha) same++; else detail += c.name + ": " + (t.ok ? "state " + t.sha.substr(0, 16) + " instead of " + c.sha.substr(0, 16) : "exit " + std::to_string(t.exitCode) + " " + t.err) + "; "; }
    R.check(sec, "S1", "training every case with the default trainer on one thread gives the state recorded on the Linux build (SHA-256), so every best response below is computed from the same file as on Linux", same == (int)cases.size(), std::to_string(same) + " of " + std::to_string(cases.size()) + " states identical" + (detail.empty() ? "" : "; " + detail)); }
  std::vector<Gain> one(cases.size());
  { int same = 0; std::string detail;
    for (size_t i = 0; i < cases.size(); i++) { one[i] = gain(self, work, cases[i].spec, stateOf(work, cases[i]), hu(1)); times[i].cpu1 = one[i].ms; times[i].items = one[i].items; if (one[i].ok && sameBits(one[i], cases[i])) same++; else detail += cases[i].name + (one[i].ok ? ": other bits (NashConv " + one[i].nash + " instead of " + cases[i].nash + ")" : ": exit " + std::to_string(one[i].exitCode) + " " + one[i].err) + "; "; }
    R.check(sec, "B1", "method exact-hu on one CPU thread: policy value, best-response value and gain of both seats and NashConv have the bits recorded on the Linux build, for every case (heads-up river, turn and flop; ranges of 10 to 1176 hands a seat; Compact, Detailed, Ranked and Exact cards)", same == (int)cases.size(), std::to_string(same) + " of " + std::to_string(cases.size()) + " cases identical" + (detail.empty() ? "" : "; " + detail)); }
  { int same = 0, total = 0; std::string detail;
    for (size_t i = 0; i < cases.size(); i++) for (int th : {2, 3, 4}) { total++; const Gain g = gain(self, work, cases[i].spec, stateOf(work, cases[i]), hu(th)); if (th == 4) times[i].cpuN = g.ms; if (g.ok && sameBits(g, one[i])) same++; else detail += cases[i].name + " on " + std::to_string(th) + " threads; "; }
    R.check(sec, "B2", "the same bits on 2, 3 and 4 CPU threads (the items are added in a fixed order, whichever thread worked them)", same == total, std::to_string(same) + " of " + std::to_string(total) + " runs identical to one thread" + (detail.empty() ? "" : "; differing: " + detail)); }
  { int ok = 0, total = 0; std::string detail; double worst = 0;
    for (size_t i = 0; i < cases.size(); i++) if (cases[i].exact) { total++; const Gain e = gain(self, work, cases[i].spec, stateOf(work, cases[i]), EXACT, {}, "2048"); times[i].exact = e.ms;
      if (e.ok && one[i].ok) worst = std::max(worst, std::fabs(one[i].nc - e.nc) / std::max(1.0, std::fabs(e.nc)));
      if (e.ok && one[i].ok && agree(one[i], e)) ok++; else detail += cases[i].name + (e.ok ? ": differs" : ": method exact exit " + std::to_string(e.exitCode) + " " + e.err) + "; "; }
    char w[64]; std::snprintf(w, sizeof w, "%.3g", worst);
    R.check(sec, "B3", "agreement with method exact (unchanged since 5.16): policy value, best-response value and gain of both seats and NashConv within 1e-9 relative, on every case method exact finished within 30 seconds on Linux (the two methods add in another order, so they agree to rounding and not to the bit)", ok == total && total > 0, std::to_string(ok) + " of " + std::to_string(total) + " cases; largest relative difference of NashConv " + w + (detail.empty() ? "" : "; " + detail)); }
  // B4/B5 use the first case method exact finishes on a turn or flop
  const Case *sm = nullptr; for (const Case &c : cases) if (c.exact && c.name.find("river") == std::string::npos) { sm = &c; break; }
  if (!sm) { R.add(sec, "B4", "a table without stored strategies", "untested", "no case for it"); R.add(sec, "B5", "policy current", "untested", "no case for it"); }
  else {
    const std::string fresh = (fs::path(work) / "st517-fresh.state").string(); const Trained t = train(self, work, sm->spec, 1, 1, fresh, "", "2048", FIXED);
    const Gain h = gain(self, work, sm->spec, fresh, hu(1)), e = gain(self, work, sm->spec, fresh, EXACT, {}, "2048"), r = gain(self, work, sm->spec, fresh, hu(1, ",\"missing\":\"refuse\""));
    R.check(sec, "B4", "a table trained for one deal: nearly every lookup has no stored strategy and takes the uniform fallback; exact-hu agrees with method exact (1e-9), and with missing \"refuse\" the request is refused with a reason and reports no value", t.ok && h.ok && e.ok && agree(h, e) && h.fallbacks > 0 && !r.ok && r.exitCode != 0 && r.err.find("no stored") != std::string::npos,
            sm->name + ": " + std::to_string(h.fallbacks) + " of " + std::to_string(h.lookups) + " lookups fell back; refusal: " + (r.ok ? "NOT refused" : r.err.substr(0, 140)));
    const Gain hc = gain(self, work, sm->spec, stateOf(work, *sm), hu(1, ",\"policy\":\"current\"")), ecur = gain(self, work, sm->spec, stateOf(work, *sm), "{\"method\":\"exact\",\"policy\":\"current\",\"maxVisits\":2000000000,\"timeLimitMs\":3600000,\"memoryMiB\":2048}", {}, "2048");
    R.check(sec, "B5", "policy \"current\" (the regret-matching strategy instead of the average): exact-hu agrees with method exact (1e-9)", hc.ok && ecur.ok && agree(hc, ecur), sm->name + ": NashConv " + std::to_string(hc.nc) + " and " + std::to_string(ecur.nc));
    fs::remove(fresh, ec);
  }
  { int refused = 0, n = 0; std::string detail; std::string why;
    struct Bad { std::string spec, state, request, want; const char *what; };
    std::vector<Bad> bad;
    const st513::Fx three = st513::fixtureOf(studies, work, "flop3-kings", "", "st517", why), pre = st513::fixtureOf(studies, work, "sat3-fold-aces", "", "st517b", why);
    const std::string s3 = (fs::path(work) / "st517-three.state").string(), sp = (fs::path(work) / "st517-pre.state").string();
    if (!three.path.empty() && train(self, work, three.path, 50, 1, s3, "", "512", FIXED).ok) bad.push_back({three.path, s3, hu(1), "exactly two seats", "a study with three seats"});
    if (!pre.path.empty() && train(self, work, pre.path, 50, 1, sp, "", "512", FIXED).ok) bad.push_back({pre.path, sp, hu(1), "exact-hu", "a preflop tournament study"});
    bad.push_back({cases[0].spec, stateOf(work, cases[0]), "{\"method\":\"exact\",\"brDevice\":\"gpu\"}", "apply to method exact-hu", "brDevice with method exact"});
    const Case *big = &cases[0]; for (const Case &c : cases) if (c.name.find("wr-flop") == 0) { big = &c; break; }
    bad.push_back({big->spec, stateOf(work, *big), "{\"method\":\"exact-hu\",\"memoryMiB\":16}", "MiB", "16 MiB for a whole-range study"});
    for (const Bad &b : bad) { n++; const Gain g = gain(self, work, b.spec, b.state, b.request, {}, "512"); const bool ok = !g.ok && g.exitCode != 0 && g.err.find(b.want) != std::string::npos && g.raw.find("nashConv") == std::string::npos; refused += ok; detail += std::string(b.what) + (ok ? ": refused; " : ": NOT refused as expected (" + g.err.substr(0, 120) + "); "); }
    R.check(sec, "B6", "requests refused with the reason and without a value: a study with three seats, a preflop tournament study, brDevice with another method, a memory limit the tables do not fit in", refused == n && n == 4, std::to_string(refused) + " of " + std::to_string(n) + " refused; " + detail);
    for (const std::string &f : {three.path, pre.path, s3, sp}) if (!f.empty()) fs::remove(f, ec);
  }
}
// The device of this computer, as mwcli --opencl-info reports it.
struct Device { bool usable = false, isGpu = false; std::string name, why, raw; long long values = 0; };
static Device device(const std::string &self, const std::string &work, const std::vector<std::pair<std::string, std::string>> &env = {}) {
  Device d; const ckpt::Run r = ckpt::spawn({self, "--opencl-info"}, work, 600, env); d.raw = r.out; Doc j(r.out);
  const JV *u = get(j.v, "usable"); d.usable = u && u->type == J_BOOL && u->num != 0; d.name = str(get(j.v, "chosenName")); d.why = str(get(j.v, "why"));
  const JV *g = get(j.v, "chosenIsGpu"); d.isGpu = g && g->type == J_BOOL && g->num != 0; d.values = (long long)num(get(get(j.v, "arithmeticProbe"), "values"), 0);
  if (!r.started || r.exitCode != 0) d.why = "mwcli --opencl-info did not run";
  return d;
}
static void gpuSection(Report &R, std::vector<st58::Check> &skipped, const std::vector<Case> &cases, const std::string &work, const std::string &self, std::vector<Timing> &times, std::string &deviceJson) {
  const std::string sec = "gpu"; const Device D = device(self, work); deviceJson = D.raw.empty() ? "null" : D.raw; while (!deviceJson.empty() && (deviceJson.back() == '\n' || deviceJson.back() == '\r')) deviceJson.pop_back();
  static const char *names[6][2] = {{"G1", "an OpenCL device with double precision, the kernel compiled by its driver, the arithmetic probe identical to the CPU"}, {"G2", "brDevice gpu: the bits of the CPU for every case"}, {"G3", "brDevice both: every item repeated on the CPU, none with other bits"},
                                    {"G4", "device batches of 48 and of 4096 items: the same bits"}, {"G5", "one bit of a device result altered: the request fails and reports no value"}, {"G6", "the unprotected kernel: refused if this device fuses a product with a sum"}};
  if (!D.usable) { for (auto &n : names) skipped.push_back({sec, n[0], n[1], "skipped", "no usable OpenCL device on this computer (" + D.why + "): nothing about a GPU was tested"}); for (const auto &c : skipped) std::fprintf(stderr, "[skipped] %s %s: %s -- %s\n", c.section.c_str(), c.id.c_str(), c.name.c_str(), c.detail.c_str()); return; }
  R.check(sec, "G1", "an OpenCL device with double precision is present, its driver compiled the kernel (the text of brhu_kernel.h, the source the CPU path is compiled from) and the arithmetic probe (products, a product followed by a sum, sums, differences and quotients of chosen doubles, subnormal results among them) has the bits of the CPU", D.usable && D.values > 0,
          D.name + (D.isGpu ? " (a GPU)" : " (NOT a GPU: an OpenCL implementation on the CPU; this exercises the path, it says nothing about a graphics card)") + "; " + std::to_string(D.values) + " probe values identical");
  std::vector<Gain> cpu(cases.size());
  { int same = 0; std::string detail; long long items = 0, rep = 0;
    for (size_t i = 0; i < cases.size(); i++) { cpu[i] = gain(self, work, cases[i].spec, stateOf(work, cases[i]), hu(1)); const Gain g = gain(self, work, cases[i].spec, stateOf(work, cases[i]), hu(1, ",\"brDevice\":\"gpu\"")); times[i].gpu = g.ms; items += g.items; rep += std::max(0LL, g.repeated);
      if (g.ok && cpu[i].ok && sameBits(g, cpu[i]) && g.other == 0) same++; else detail += cases[i].name + (g.ok ? ": other bits" : ": exit " + std::to_string(g.exitCode) + " " + g.err) + "; "; }
    R.check(sec, "G2", "brDevice gpu: every river subtree on every complete board is worked on the device; policy value, best-response value and gain of both seats and NashConv have the bits of the CPU path, for every case", same == (int)cases.size(),
            std::to_string(same) + " of " + std::to_string(cases.size()) + " cases identical; " + std::to_string(items) + " items on the device, " + std::to_string(rep) + " of them repeated on the CPU (every 16th and the first of each batch), none with other bits" + (detail.empty() ? "" : "; " + detail)); }
  { int same = 0; std::string detail; long long items = 0, rep = 0;
    for (size_t i = 0; i < cases.size(); i++) { const Gain g = gain(self, work, cases[i].spec, stateOf(work, cases[i]), hu(1, ",\"brDevice\":\"both\"")); items += g.items; rep += std::max(0LL, g.repeated);
      if (g.ok && sameBits(g, cpu[i]) && g.other == 0 && g.repeated == g.items) same++; else detail += cases[i].name + (g.ok ? ": " + std::to_string(g.repeated) + " of " + std::to_string(g.items) + " repeated, " + std::to_string(g.other) + " other" : ": exit " + std::to_string(g.exitCode) + " " + g.err) + "; "; }
    R.check(sec, "G3", "brDevice both: every item worked on the device is worked again on the CPU and compared bit for bit (both values of every hand, and the two counters)", same == (int)cases.size(), std::to_string(rep) + " of " + std::to_string(items) + " items repeated, in " + std::to_string(same) + " of " + std::to_string(cases.size()) + " cases none with other bits" + (detail.empty() ? "" : "; " + detail)); }
  { int same = 0, total = 0; std::string detail;
    for (size_t i = 0; i < cases.size(); i++) { if (cases[i].name.find("turn") == std::string::npos && cases[i].name.find("flop") == std::string::npos) continue;
      for (const char *b : {"48", "4096"}) { total++; const Gain g = gain(self, work, cases[i].spec, stateOf(work, cases[i]), hu(1, ",\"brDevice\":\"gpu\""), {{"EM_BRHU_BATCH", b}}); if (g.ok && sameBits(g, cpu[i])) same++; else detail += cases[i].name + " batch " + b + "; "; } }
    R.check(sec, "G4", "the device is given its items in batches of 48 and of 4096 instead of the size it chooses: the same bits (an item does not depend on what is worked beside it)", same == total && total > 0, std::to_string(same) + " of " + std::to_string(total) + " runs identical" + (detail.empty() ? "" : "; differing: " + detail)); }
  { const Case *c = &cases[0]; for (const Case &k : cases) if (k.name.find("turn") != std::string::npos) { c = &k; break; }
    const Gain g = gain(self, work, c->spec, stateOf(work, *c), hu(1, ",\"brDevice\":\"gpu\""), {{"EM_BRHU_TEST", "flip"}});
    R.check(sec, "G5", "test hook: the lowest bit of one value the device returned is altered before the host reads it; the repetition on the CPU finds it, the request fails and reports no value", !g.ok && g.exitCode != 0 && g.err.find("other bits") != std::string::npos && g.raw.find("nashConv") == std::string::npos, c->name + ": " + (g.ok ? "NOT detected" : g.err.substr(0, 170))); }
  { const Device U = device(self, work, {{"EM_BRHU_TEST", "unprotected"}}); const bool refused = !U.usable && U.why.find("differs from the CPU") != std::string::npos;
    R.check(sec, "G6", "test hook: the kernel without its protection (plain products, contraction allowed, -cl-mad-enable) goes through the same probe. A device that then fuses a product with a sum must be refused; a device that does not fuse even then passes, and the probe has not been shown to detect fusing on it", refused || U.usable,
            refused ? "this device fuses when allowed, and the probe refused it: " + U.why.substr(0, 150) : "this device does not fuse even when allowed: the probe passed, so it was not shown to detect fusing here"); }
}
static int record(const std::string &dir, const std::string &work, const std::string &self) {
  std::vector<Case> cases; std::string why; if (!loadCases(dir, cases, why)) { std::fprintf(stderr, "error: %s\n", why.c_str()); return 2; }
  std::string o = "{\"algorithm\":\"brhu-5.17-v1\",\"cases\":["; int bad = 0;
  for (size_t i = 0; i < cases.size(); i++) {
    const Case &c = cases[i]; const Trained t = train(self, work, c.spec, c.deals, 1, stateOf(work, c), "", "2048", FIXED); const Gain g = t.ok ? gain(self, work, c.spec, stateOf(work, c), hu(1)) : Gain{};
    const Gain e = t.ok ? gain(self, work, c.spec, stateOf(work, c), EXACT, {}, "2048") : Gain{}; bad += !g.ok;
    o += std::string(i ? "," : "") + "\n {\"name\":" + mwa::jsonEsc(c.name) + ",\"spec\":" + mwa::jsonEsc(fs::path(c.spec).filename().string()) + ",\"deals\":" + std::to_string(c.deals) + ",\"rows\":" + std::to_string(t.rows) + ",\"stateSha256\":\"" + t.sha + "\",\"exactFinishes\":" + (e.ok && e.ms < 30000 ? "true" : "false") + ",\"exactSecondsOnLinux\":" + (e.ok ? st58::fmt(e.ms / 1000) : std::string("null")) + ",\"exactAgrees\":" + (e.ok ? (agree(g, e) ? "true" : "false") : "null") +
         ",\"items\":" + std::to_string(g.items) + ",\"nashConv\":" + st58::fmt(g.nc) + ",\"nashConvBits\":\"" + g.nash + "\",\"seats\":[";
    for (int p = 0; p < 2; p++) o += std::string(p ? "," : "") + "{\"policyValueBits\":\"" + g.bits[p][0] + "\",\"bestResponseValueBits\":\"" + g.bits[p][1] + "\",\"gainBits\":\"" + g.bits[p][2] + "\"}";
    o += "]}"; std::error_code ec; fs::remove(stateOf(work, c), ec);
  }
  o += "\n]}\n"; writeText((fs::path(work) / "reference.json").string(), o);
  std::printf("{\"recorded\":%zu,\"failed\":%d}\n", cases.size(), bad); return bad ? 1 : 0;
}
static int run(int argc, char **argv) {
  if (argc < 5 || argc > 6) { std::fprintf(stderr, "usage: mwcli --selftest517 cases-dir studies-dir work-dir [all|cpu|gpu]\n"); return 2; }
  const std::string dir = argv[2], studies = argv[3], work = argv[4], section = argc > 5 ? argv[5] : "all"; std::error_code ec; fs::create_directories(work, ec); mw_study_identity(EM_VERSION, EM_BUILD_ID);
  if (!fs::is_directory(dir, ec) || !fs::is_directory(studies, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: cases-dir, studies-dir and work-dir must be directories\n"); return 2; }
  const std::string Dd = fs::absolute(dir, ec).string(), S = fs::absolute(studies, ec).string(), W = fs::absolute(work, ec).string(), self = ckpt::selfPath(argv[0]);
  if (section == "record") return record(Dd, W, self);
  if (section != "all" && section != "cpu" && section != "gpu") { std::fprintf(stderr, "error: the section must be all, cpu or gpu\n"); return 2; }
  std::vector<Case> cases; std::string why; if (!loadCases(Dd, cases, why)) { std::fprintf(stderr, "error: %s\n", why.c_str()); return 2; }
  Report R; std::vector<st58::Check> skipped; std::vector<Timing> times(cases.size()); for (size_t i = 0; i < cases.size(); i++) times[i].name = cases[i].name; std::string deviceJson = "null";
  const auto t0 = std::chrono::steady_clock::now();
  if (section == "gpu") { int have = 0; for (const Case &c : cases) { const Trained t = train(self, W, c.spec, c.deals, 1, stateOf(W, c), "", "2048", FIXED); have += t.ok && t.sha == c.sha; }
    R.check("gpu", "G0", "the states of the cases, trained here, are the ones recorded on Linux", have == (int)cases.size(), std::to_string(have) + " of " + std::to_string(cases.size())); }
  if (section == "all" || section == "cpu") cpuSection(R, cases, S, W, self, times);
  if (section == "all" || section == "gpu") gpuSection(R, skipped, cases, W, self, times, deviceJson);
  for (const Case &c : cases) fs::remove(stateOf(W, c), ec);
  fs::remove((fs::path(W) / "st517-request.json").string(), ec);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest517\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"" + section + "\",\"algorithm\":\"brhu-5.17-v1\",\"passed\":" + std::to_string(R.passed) + ",\"failed\":" + std::to_string(R.failed) + ",\"untested\":" + std::to_string(R.untested) +
                  ",\"skipped\":" + std::to_string(skipped.size()) + ",\"seconds\":" + st58::fmt(secs) + ",\"openclDevice\":" + deviceJson + ",\"milliseconds\":[";
  for (size_t i = 0; i < times.size(); i++) { const Timing &t = times[i]; o += std::string(i ? "," : "") + "{\"case\":" + mwa::jsonEsc(t.name) + ",\"items\":" + std::to_string(t.items) + ",\"exactHuOneThread\":" + st58::fmt(t.cpu1) + ",\"exactHuFourThreads\":" + st58::fmt(t.cpuN) + ",\"exactHuDevice\":" + st58::fmt(t.gpu) + ",\"methodExact\":" + st58::fmt(t.exact) + "}"; }
  o += "],\"millisecondsNote\":\"whole processes, started once each (-1: not run): a first look, not a measurement\",\"checks\":[";
  std::vector<st58::Check> all = R.checks; all.insert(all.end(), skipped.begin(), skipped.end());
  for (size_t i = 0; i < all.size(); i++) { const st58::Check &c = all[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}"; const std::string report = (fs::path(work) / "selftest517.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest517\",\"build\":\"%s\",\"section\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"skipped\":%zu,\"report\":%s}\n", EM_BUILD_ID, section.c_str(), R.passed, R.failed, R.untested, skipped.size(), mwa::jsonEsc(report).c_str());
  return R.failed || R.untested ? 1 : 0;
}
}
