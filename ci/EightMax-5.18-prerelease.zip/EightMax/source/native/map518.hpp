// EightMax 5.18: bet sizes outside the tree. Identifier map-5.18-v1.
//
// A size that the tree does not have is mapped onto the sizes it has, as a fraction of the pot (for a raise: of the
// pot after the call, the way the tree's own sizes are defined). Between two neighbouring tree sizes A < B a size x
// is mapped by one of three rules:
//
//   nearest    to A if x - A <= B - x, else to B                                  (arithmetic midpoint)
//   harmonic   to A if f >= 1/2, else to B, with f = (B - x)(1 + A) / ((B - A)(1 + x))
//              (the pseudo-harmonic mapping of Ganzfried and Sandholm, 2013, used as a threshold)
//   blend      to A with weight f and to B with weight 1 - f
//
// Below the smallest tree size x is mapped to the smallest, above the largest to the largest. A size within 1e-9 of
// a tree size is that size. Fold, call and check are never mapped. This file holds the rule and nothing else; it is
// mirrored by EM.offTree in web/lib_offtree.js, and tests compare the two.
//
// "blend" as used by mwcli --translate is an interpolation of the two strategies with the fixed weights f and 1 - f
// at every later decision. It is NOT the strategy that draws A or B once and then follows it: that one has a memory
// the table of a study cannot hold. MATHEMATICAL-VALIDATION-5.18.md, section 2.
#pragma once
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace map518 {
constexpr const char *ID = "map-5.18-v1";
enum Rule { NEAREST = 0, HARMONIC = 1, BLEND = 2 };
inline int ruleOf(const std::string &name) { return name == "nearest" ? NEAREST : name == "harmonic" ? HARMONIC : name == "blend" ? BLEND : -1; }
inline const char *ruleName(int r) { return r == NEAREST ? "nearest" : r == HARMONIC ? "harmonic" : "blend"; }
constexpr double SAME = 1e-9;

// weight of the lower neighbour A for a size x, A < x < B (fractions of the pot)
inline double lowerWeight(double A, double B, double x) { return (B - x) * (1 + A) / ((B - A) * (1 + x)); }

struct Target { int index; double weight; };
// sizes: the tree's fractions in ascending order. Returns one target, or two for BLEND strictly between two sizes.
inline std::vector<Target> mapSize(const std::vector<double> &sizes, double x, int rule) {
  const int n = (int)sizes.size(); if (!n) return {};
  for (int i = 0; i < n; i++) if (std::fabs(sizes[(size_t)i] - x) <= SAME) return {{i, 1.0}};
  if (x < sizes[0]) return {{0, 1.0}};
  if (x > sizes[(size_t)n - 1]) return {{n - 1, 1.0}};
  int j = 0; while (j + 1 < n && sizes[(size_t)j + 1] < x) j++;
  const double A = sizes[(size_t)j], B = sizes[(size_t)j + 1], f = lowerWeight(A, B, x);
  if (rule == NEAREST) return {{x - A <= B - x ? j : j + 1, 1.0}};
  if (rule == HARMONIC) return {{f >= 0.5 ? j : j + 1, 1.0}};
  return {{j, f}, {j + 1, 1.0 - f}};
}

// The study identifier in the header of a translated state: a function of the study it is for, the rule and the
// study it came from. Programs before 5.18 compare the header's identifier with the spec's and refuse the file.
inline std::string studyOf(const std::string &study, const std::string &rule, const std::string &from) {
  uint64_t h = 1469598103934665603ULL;
  for (const std::string *s : {&study, &rule, &from}) { for (unsigned char c : *s) { h ^= c; h *= 1099511628211ULL; } h ^= 0xff; h *= 1099511628211ULL; }
  for (const char *c = ID; *c; c++) { h ^= (unsigned char)*c; h *= 1099511628211ULL; }
  char hex[24]; snprintf(hex, sizeof hex, "t518-%016llx", (unsigned long long)h); return hex;
}
// The check both loaders make. Returns nullptr if the header belongs to this study (plainly, or as a translated
// state), else the reason.
inline const char *studyCheck(const std::string &specStudy, const char *study, const char *translated, const char *rule, const char *from) {
  if (!translated) return study && specStudy == study ? nullptr : "State belongs to a different study";
  if (std::string(translated) != ID) return "State was translated by an algorithm this program does not know (see its \"translated\" header field)";
  if (!rule || ruleOf(rule) < 0 || !from) return "Translated state names no known mapping rule or no source study";
  if (!study || studyOf(specStudy, rule, from) != study) return "Translated state belongs to a different study, rule or source";
  return nullptr;
}
}
