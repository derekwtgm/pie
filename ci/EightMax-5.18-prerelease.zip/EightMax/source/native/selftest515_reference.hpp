{"pko6-bb-call-small", 0, 20000, 0.048561083438467989},
{"pko6-bb-call-small", 1, 20000, 0.13444269161601596},
{"fgs4-bubble-bb-call-small", 0, 20000, 0.17430403892214485},
{"fgs4-bubble-bb-call-small", 1, 20000, 0.13958834499705119},
