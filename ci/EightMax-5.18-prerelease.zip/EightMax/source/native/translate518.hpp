// EightMax 5.18: bet sizes outside the tree (map-5.18-v1). Included at the end of mw.cpp.
//
//   mw_translate  the average strategy of a trained study A, written as a state of a study B that differs from A in
//                 its bet sizes only. Every decision of B is answered with what A does at the decision the mapping
//                 rule (map518.hpp) leads to. The result is an ordinary EMMW4 state of B with three more header
//                 fields; every evaluator reads it (mwcli --gain, --ev, --node), nothing trains it.
//   mw_offtree    a line of real actions with real amounts, mapped step by step onto the tree of one study.
//
// How a decision of B is answered. The two trees are walked together. B's node carries a list of A's nodes with
// weights (one node, except under the rule "blend").
//   * An action taken in B moves each of A's nodes: fold to fold, call or check to call or check, a bet or raise to
//     the bet or raise of A the rule gives for its fraction of the pot (two of them under "blend"). If A cannot bet
//     or raise there, it is taken as a call or check. If A has no such node (never visited in training, or A's hand
//     is over because the mapped bet was all-in), that part ends: B gets no rows below, and an evaluator reports the
//     lookups there as fallbacks.
//   * The strategy row of a hand at B's node is the weighted mean of A's rows for that hand, each action of A
//     placed on the action of B it is realised as: fold, call/check, and for a bet or raise the size of B the rule
//     gives for A's fraction of the pot (always one size: "blend" uses the harmonic threshold here).
// Row keys are copied byte for byte: no grouping depends on the betting, so a hand has the same key in A and in B.
#pragma once

namespace tr518 {
using es::BS; using es::EPS;
enum { FOLD = 0, PASSIVE = 1, AGGRESSIVE = 2 };
inline int kindOf(const BS &s, int a) { return s.facing && a == 0 ? FOLD : s.to[a] <= s.price + EPS ? PASSIVE : AGGRESSIVE; }
inline double fraction(const BS &s, int a) { const int p = s.actor; return (s.to[a] - s.price) / (s.pot + (s.facing ? s.price - s.put[p] : 0)); }
inline int foldSlot(const BS &s) { return s.facing ? 0 : -1; }
inline int passiveSlot(const BS &s) { if (!s.facing) return 0; return s.k > 1 && s.to[1] <= s.price + EPS ? 1 : -1; }
struct Step { std::vector<map518::Target> to; bool offTree = false, noRaise = false; double x = 0; };
// action a of node F (the game being followed) onto the actions of node T (the tree that holds the strategy)
inline Step mapAction(const BS &F, int a, const BS &T, int rule) {
  Step r; const int kind = kindOf(F, a);
  if (kind == FOLD) { if (foldSlot(T) >= 0) r.to.push_back({foldSlot(T), 1.0}); return r; }
  if (kind == PASSIVE) { if (passiveSlot(T) >= 0) r.to.push_back({passiveSlot(T), 1.0}); return r; }
  std::vector<double> sizes; std::vector<int> slots;
  for (int j = 0; j < T.k; j++) if (kindOf(T, j) == AGGRESSIVE) { sizes.push_back(fraction(T, j)); slots.push_back(j); }
  r.x = fraction(F, a);
  if (sizes.empty()) { r.noRaise = true; r.offTree = true; if (passiveSlot(T) >= 0) r.to.push_back({passiveSlot(T), 1.0}); return r; }
  for (const map518::Target &t : map518::mapSize(sizes, r.x, rule)) r.to.push_back({slots[(size_t)t.index], t.weight});
  r.offTree = !(r.to.size() == 1 && std::fabs(sizes[(size_t)(std::find(slots.begin(), slots.end(), r.to[0].index) - slots.begin())] - r.x) <= map518::SAME);
  return r;
}

inline const char *sameGame(const MW *A, const MW *B) {
  const es::Rules &a = A->es->rules, &b = B->es->rules;
  if (a.n != b.n || a.rootLength != b.rootLength || a.pre != b.pre || a.shove != b.shove || a.noLimp != b.noLimp || a.common != b.common || a.pot0 != b.pot0 || a.folded != b.folded) return "the two studies differ in more than their bet sizes (seats, street, pot or preflop rules)";
  for (int p = 0; p < a.n; p++) if (a.stacks[p] != b.stacks[p] || a.prior[p] != b.prior[p] || a.ownAnte[p] != b.ownAnte[p] || a.posted[p] != b.posted[p] || a.open[p] != b.open[p]) return "the two studies differ in more than their bet sizes (stacks or chips already in the pot)";
  if (A->startLen != B->startLen || !std::equal(A->board, A->board + 5, B->board)) return "the two studies have different boards";
  const es::GroupKeys &g = A->es->groups, &h = B->es->groups;
  if (g.on != h.on || g.detailed != h.detailed || bool(g.ranked) != bool(h.ranked)) return "the two studies use different hand groupings";
  for (int p = 0; p < a.n; p++) {
    if (A->hands[p].size() != B->hands[p].size()) return "the two studies have different ranges";
    for (size_t i = 0; i < A->hands[p].size(); i++) { const Hand &x = A->hands[p][i], &y = B->hands[p][i]; if (x.a != y.a || x.b != y.b || x.w != y.w || x.strategyHand != y.strategyHand) return "the two studies have different ranges or hand groupings"; }
  }
  if (A->es->dcfr || B->es->dcfr) return "studies with discounted weighting (DCFR) are not translated";
  return nullptr;
}

struct Mapped { BS s; uint32_t id; double w; };
struct Translator {
  MW *A, *B; int rule; const es::Rules &ra, &rb;
  std::vector<std::vector<uint32_t>> byState;
  std::vector<unsigned char> states, rows; uint32_t stateCount = 0, rowCount = 0;
  long long decisionNodes = 0, offTree = 0, noRaise = 0, endedParts = 0, unguided = 0, blendedRows = 0, exactNodes = 0;
  std::string examples; int exampleCount = 0;
  Translator(MW *a, MW *b, int r) : A(a), B(b), rule(r), ra(a->es->rules), rb(b->es->rules) {}
  template <class T> static void put(std::vector<unsigned char> &v, const T &x) { const unsigned char *p = (const unsigned char *)&x; v.insert(v.end(), p, p + sizeof(T)); }
  uint32_t addState(uint32_t parent, int slot, const BS &s) {
    put(states, parent); const uint8_t x[] = {(uint8_t)slot, (uint8_t)s.kind, (uint8_t)std::max(0, s.actor), (uint8_t)s.length, (uint8_t)s.k}; states.insert(states.end(), x, x + 5);
    return stateCount++;
  }
  std::string keyBytes(const MW::RowMeta &rm, int length) const {
    std::string k;
    if (A->es->groups.on) { const std::string &t = *A->es->groups.text[(size_t)(rm.key & ((1u << 26) - 1))]; const uint16_t n = (uint16_t)t.size(); k.append((const char *)&n, 2); k += t; return k; }
    const uint16_t hand = (uint16_t)((rm.key >> 26) & 2047); uint8_t cards[5]; es::decodeCards((uint32_t)(rm.key & ((1u << 26) - 1)), length, cards);
    k.append((const char *)&hand, 2); k.append((const char *)cards, 5); return k;
  }
  void example(const BS &L, int a, const BS &S, const Step &st) {
    if (exampleCount >= 12) return;
    char buf[400]; int n = snprintf(buf, sizeof buf, "%s{\"street\":%d,\"to\":%.6g,\"potFraction\":%.6g,\"mappedTo\":[", exampleCount ? "," : "", L.length, L.to[a], st.x);
    for (size_t i = 0; i < st.to.size() && n < 300; i++) n += snprintf(buf + n, sizeof buf - (size_t)n, "%s{\"to\":%.6g,\"potFraction\":%.6g,\"weight\":%.6g}", i ? "," : "", S.to[st.to[i].index], kindOf(S, st.to[i].index) == AGGRESSIVE ? fraction(S, st.to[i].index) : 0.0, st.to[i].weight);
    snprintf(buf + n, sizeof buf - (size_t)n, "]}"); examples += buf; exampleCount++;
  }
  void walk(const BS &L, uint32_t lid, const std::vector<Mapped> &ms, int depth) {
    if (depth > es::MAX_DEPTH) throw std::runtime_error("tree too deep");
    if (L.kind == 1) {
      BS c; rb.nextStreet(L, c); if (c.kind == 2) return;
      std::vector<Mapped> next;
      for (const Mapped &m : ms) { if (m.s.kind != 1) { endedParts++; continue; } const int cid = A->es->states.find(m.id, es::CHANCE_SLOT); if (cid < 0) { endedParts++; continue; } Mapped x; ra.nextStreet(m.s, x.s); x.id = (uint32_t)cid; x.w = m.w; next.push_back(x); }
      if (next.empty()) { unguided++; return; }
      walk(c, addState(lid, es::CHANCE_SLOT, c), next, depth + 1); return;
    }
    if (L.kind != 0) return;
    decisionNodes++;
    std::vector<const Mapped *> live; for (const Mapped &m : ms) { if (m.s.kind == 0 && m.s.actor == L.actor) live.push_back(&m); else endedParts++; }
    // the rows of this node
    if (L.k >= 2) {
      const int det = rule == map518::NEAREST ? map518::NEAREST : map518::HARMONIC;
      std::map<std::string, std::pair<std::vector<double>, std::pair<double, int>>> acc; bool exact = live.size() == 1;
      const bool raw = live.size() == 1 && live[0]->w == 1.0;
      for (const Mapped *m : live) {
        int realise[8];
        for (int s = 0; s < m->s.k; s++) { const Step st = mapAction(m->s, s, L, det); realise[s] = st.to.empty() ? (passiveSlot(L) >= 0 ? passiveSlot(L) : 0) : st.to[0].index; if (st.offTree || st.to.empty()) exact = false; }
        if (m->s.k != L.k) exact = false;
        for (uint32_t r : byState[m->id]) {
          const MW::RowMeta &rm = A->rows[r]; const double *avg = A->vals.data() + rm.off + rm.k; double sum = 0; for (int s = 0; s < rm.k; s++) sum += avg[s];
          if (!(sum > 0) || rm.k != m->s.k) continue;
          auto &e = acc[keyBytes(rm, m->s.length)]; if (e.first.empty()) e.first.assign((size_t)L.k, 0.0);
          // one source node with weight 1: the sums are copied as they are, so a translation into the same tree
          // gives every evaluator the numbers of the source, bit for bit
          if (raw) { for (int s = 0; s < rm.k; s++) e.first[(size_t)realise[s]] += avg[s]; e.second.first = 1.0; }
          else { for (int s = 0; s < rm.k; s++) e.first[(size_t)realise[s]] += m->w * (avg[s] / sum); e.second.first += m->w; }
          e.second.second++;
        }
      }
      exactNodes += exact;
      for (auto &kv : acc) {
        put(rows, lid); rows.insert(rows.end(), kv.first.begin(), kv.first.end()); rows.push_back((unsigned char)L.k);
        for (int j = 0; j < L.k; j++) put(rows, 0.0);
        for (int j = 0; j < L.k; j++) put(rows, kv.second.first[(size_t)j] / kv.second.second.first);
        rowCount++; blendedRows += kv.second.second.second > 1;
      }
    }
    for (int a = 0; a < L.k; a++) {
      BS c; rb.advance(L, a, c); if (c.kind == 2) continue;
      std::vector<Mapped> next; bool counted = false;
      for (const Mapped *m : live) {
        const Step st = mapAction(L, a, m->s, rule);
        if (st.offTree && !counted) { offTree++; counted = true; noRaise += st.noRaise; example(L, a, m->s, st); }
        if (st.to.empty()) { endedParts++; continue; }
        for (const map518::Target &t : st.to) {
          const int cid = A->es->states.find(m->id, t.index); if (cid < 0) { endedParts++; continue; }
          bool merged = false; for (Mapped &x : next) if (x.id == (uint32_t)cid) { x.w += m->w * t.weight; merged = true; }
          if (merged) continue;
          Mapped x; ra.advance(m->s, t.index, x.s); x.id = (uint32_t)cid; x.w = m->w * t.weight; next.push_back(x);
        }
      }
      if (next.empty()) { unguided++; continue; }
      walk(c, addState(lid, a, c), next, depth + 1);
    }
  }
};
}

// Writes the translated state to `file`. Returns 200, or a status with the reason in err.
extern "C" int mw_translate(MW *A, MW *B, const char *ruleName, FILE *file, JB *report, char *err, int errlen) {
  try {
    if (!A || !B || !A->es || !B->es) { fail(err, errlen, "mwcli --translate needs two external-sampling studies"); return 422; }
    const int rule = map518::ruleOf(ruleName ? ruleName : ""); if (rule < 0) { fail(err, errlen, "unknown mapping rule (nearest, harmonic or blend)"); return 400; }
    if (!A->translatedRule.empty()) { fail(err, errlen, "the source state is itself a translated state; translate from the trained state"); return 422; }
    if (const char *why = tr518::sameGame(A, B)) { fail(err, errlen, why); return 422; }
    if (A->iterations < 1) { fail(err, errlen, "the source state has no training"); return 422; }
    tr518::Translator t(A, B, rule);
    t.byState.resize(A->es->states.parent.size());
    for (size_t r = 0; r < A->rows.size(); r++) if (A->rows[r].visited) t.byState[(size_t)(A->rows[r].key >> 37)].push_back((uint32_t)r);
    const es::BS &ar = A->es->rootState, &br = B->es->rootState;
    if (br.kind == 2 || ar.kind != br.kind) { fail(err, errlen, "the two studies do not start alike"); return 422; }
    std::vector<tr518::Mapped> root(1); root[0].s = ar; root[0].id = 0; root[0].w = 1.0;
    { unsigned char x[9]; const uint32_t none = 0xffffffffu; std::memcpy(x, &none, 4); x[4] = A->es->states.slot.empty() ? 0 : A->es->states.slot[0]; x[5] = (uint8_t)br.kind; x[6] = (uint8_t)std::max(0, br.actor); x[7] = (uint8_t)br.length; x[8] = (uint8_t)br.k; t.states.insert(t.states.end(), x, x + 9); t.stateCount = 1; }
    t.walk(br, 0, root, 0);
    B->translatedRule = map518::ruleName(rule); B->translatedFrom = A->studyId;
    B->iterations = A->iterations; B->trainingDeals = B->dealsBefore(A->iterations); B->stateVisits = A->stateVisits;
    JB h; jb_init(&h); esHeaderJson(B, h); if (h.failed || h.n < 10) { jb_free(&h); fail(err, errlen, "header"); return 500; }
    const uint32_t hl = (uint32_t)h.n; uint32_t crc = ~0u;
    crc = crcUpdate(crc, (const unsigned char *)&t.stateCount, 4); crc = crcUpdate(crc, t.states.data(), t.states.size());
    crc = crcUpdate(crc, (const unsigned char *)&t.rowCount, 4); if (!t.rows.empty()) crc = crcUpdate(crc, t.rows.data(), t.rows.size());
    char hex[9]; snprintf(hex, sizeof hex, "%08x", ~crc); std::memcpy(h.s + hl - 10, hex, 8);
    bool ok = fwrite("EMMW4\0\0\0", 1, 8, file) == 8 && fwrite(&hl, 1, 4, file) == 4 && fwrite(h.s, 1, hl, file) == hl && fwrite(&t.stateCount, 1, 4, file) == 4 &&
              fwrite(t.states.data(), 1, t.states.size(), file) == t.states.size() && fwrite(&t.rowCount, 1, 4, file) == 4 && (t.rows.empty() || fwrite(t.rows.data(), 1, t.rows.size(), file) == t.rows.size()) && !fflush(file);
    jb_free(&h); if (!ok) { fail(err, errlen, "cannot write the translated state"); return 500; }
    jb_printf(report, "{\"algorithm\":\"%s\",\"mapping\":\"%s\",\"from\":", map518::ID, map518::ruleName(rule)); jb_str(report, A->studyId.c_str());
    jb_puts(report, ",\"study\":"); jb_str(report, B->studyId.c_str()); jb_puts(report, ",\"stateStudyId\":"); jb_str(report, map518::studyOf(B->studyId, B->translatedRule, B->translatedFrom).c_str());
    jb_printf(report, ",\"sourceStates\":%zu,\"sourceRows\":%zu,\"states\":%u,\"rows\":%u,\"decisionNodes\":%lld,\"nodesAnsweredByOneNodeWithTheSameActions\":%lld,\"actionsOutsideTheSourceTree\":%lld,\"ofThoseWhereTheSourceCannotRaise\":%lld,\"rowsBlendedFromSeveralNodes\":%lld,\"branchesWithoutASourceNode\":%lld,\"sourcePartsThatEnded\":%lld,\"examples\":[%s]}",
              A->es->states.parent.size(), A->rows.size(), t.stateCount, t.rowCount, t.decisionNodes, t.exactNodes, t.offTree, t.noRaise, t.blendedRows, t.unguided, t.endedParts, t.examples.c_str());
    return 200;
  } catch (const std::bad_alloc &) { fail(err, errlen, "not enough memory to translate"); return 503; }
  catch (const std::exception &e) { fail(err, errlen, e.what()); return 500; }
}

// A line of real actions mapped onto the tree of study T.
// request: {"mapping":"blend" (default; or "nearest", "harmonic"),"actions":["check", 7.5, "call", "next", {"pot":0.6}, "fold" ...]}
//   a number or {"to":x} is a bet or raise TO x chips on this street (the street contribution of the actor, as in
//   the tree's own actions); {"pot":f} is a bet or raise of the fraction f of the pot; "next" deals the next street.
extern "C" int mw_offtree(MW *T, const char *json, size_t len, JB *out, char *err, int errlen) {
  using namespace tr518;
  try {
    if (!T || !T->es) { fail(err, errlen, "mwcli --offtree needs an external-sampling study"); return 422; }
    JV *rq = json_parse(json, len, err, errlen); if (!rq) return 400;
    std::unique_ptr<JV, decltype(&json_free)> hold(rq, json_free);
    const char *rn = jstr(jget(rq, "mapping")); const int rule = map518::ruleOf(rn ? rn : "blend"); if (rule < 0) { fail(err, errlen, "unknown mapping rule (nearest, harmonic or blend)"); return 400; }
    const JV *acts = jget(rq, "actions"); if (!acts || acts->type != J_ARR) { fail(err, errlen, "\"actions\" must be a list"); return 400; }
    const es::Rules &R = T->es->rules;
    struct Path { BS s; std::string slots; double w; };
    BS real = T->es->rootState; std::vector<Path> paths(1); paths[0].s = real; paths[0].w = 1.0;
    jb_printf(out, "{\"algorithm\":\"%s\",\"mapping\":\"%s\",\"steps\":[", map518::ID, map518::ruleName(rule));
    for (size_t i = 0; i < acts->n; i++) {
      const JV *a = acts->items[i]; if (i) jb_putc(out, ',');
      const char *word = jstr(a); std::string w = word ? word : "";
      if (w == "next") {
        if (real.kind != 1) { fail(err, errlen, "\"next\": the betting of this street is not over"); return 422; }
        BS c; R.nextStreet(real, c); real = c; std::vector<Path> next;
        for (Path &p : paths) if (p.s.kind == 1) { Path x; R.nextStreet(p.s, x.s); x.slots = p.slots + "7"; x.w = p.w; next.push_back(x); }
        paths.swap(next); jb_printf(out, "{\"action\":\"next\",\"street\":%d,\"treePaths\":%zu}", real.length, paths.size()); continue;
      }
      if (real.kind != 0) { fail(err, errlen, real.kind == 1 ? "the betting of this street is over: \"next\" deals the next card" : "the hand is over"); return 422; }
      const int p = real.actor; const double remaining = R.stacks[p] - real.previous[p]; BS f = real; int slot = -1; double to = 0; bool aggressive = false;
      if (w == "fold") { if (!real.facing) { fail(err, errlen, "\"fold\": there is no bet to fold to"); return 422; } slot = 0; }
      else if (w == "call" || w == "check") { if ((w == "call") != real.facing) { fail(err, errlen, real.facing ? "\"check\": there is a bet to call" : "\"call\": there is no bet"); return 422; } slot = real.facing ? 1 : 0; f.to[slot] = real.facing ? std::min(real.price, remaining) : real.put[p]; if (f.k <= slot) f.k = slot + 1; }
      else {
        const JV *tv = a->type == J_NUM ? a : jget(a, "to"), *pv = a->type == J_NUM ? nullptr : jget(a, "pot");
        if (tv && tv->type == J_NUM) to = tv->num; else if (pv && pv->type == J_NUM) to = real.price + pv->num * (real.pot + (real.facing ? real.price - real.put[p] : 0));
        else { fail(err, errlen, "an action is \"fold\", \"call\", \"check\", \"next\", a number (bet or raise to), {\"to\":x} or {\"pot\":f}"); return 400; }
        if (!(to > real.price + EPS)) { fail(err, errlen, "a bet or raise must exceed the price to call"); return 422; }
        if (to > remaining + EPS) { fail(err, errlen, "a bet or raise cannot exceed the stack"); return 422; }
        to = std::min(to, remaining);
        if (to < real.price + real.full - EPS && to < remaining - EPS) { fail(err, errlen, "a raise below the minimum raise must be all-in"); return 422; }
        slot = 7; f.to[7] = to; aggressive = true;
      }
      BS c; R.advance(f, slot, c);
      jb_printf(out, "{\"seat\":%d,\"street\":%d,\"action\":\"%s\"", p, real.length, aggressive ? (real.facing ? "raise" : "bet") : w.c_str());
      if (aggressive) jb_printf(out, ",\"to\":%.9g,\"potFraction\":%.9g", to, fraction(f, slot));
      jb_puts(out, ",\"mapped\":[");
      std::vector<Path> next; bool first = true;
      for (Path &q : paths) {
        if (q.s.kind != 0 || q.s.actor != p) continue;
        const Step st = mapAction(f, slot, q.s, rule);
        for (const map518::Target &t : st.to) {
          Path x; R.advance(q.s, t.index, x.s); x.slots = q.slots + (char)('0' + t.index); x.w = q.w * t.weight;
          bool merged = false; for (Path &y : next) if (y.slots == x.slots) { y.w += x.w; merged = true; }
          if (!merged) next.push_back(x);
          if (!first) jb_putc(out, ','); first = false;
          jb_printf(out, "{\"fromPath\":\"%s\",\"slot\":%d,\"treeTo\":%.9g,\"treePotFraction\":%.9g,\"weight\":%.17g,\"inTree\":%s%s}", q.slots.c_str(), t.index, q.s.to[t.index],
                    kindOf(q.s, t.index) == AGGRESSIVE ? fraction(q.s, t.index) : 0.0, t.weight, st.offTree ? "false" : "true", st.noRaise ? ",\"note\":\"the tree has no bet or raise here: taken as a call or check\"" : "");
        }
      }
      jb_puts(out, "]}"); real = c; paths.swap(next);
    }
    jb_printf(out, "],\"real\":{\"street\":%d,\"pot\":%.9g,\"over\":%s},\"tree\":[", real.length, real.pot, real.kind == 2 ? "true" : "false");
    for (size_t i = 0; i < paths.size(); i++) jb_printf(out, "%s{\"path\":\"%s\",\"weight\":%.17g,\"pot\":%.9g,\"kind\":\"%s\"}", i ? "," : "", paths[i].slots.c_str(), paths[i].w, paths[i].s.pot, paths[i].s.kind == 0 ? "decision" : paths[i].s.kind == 1 ? "next street" : "over");
    // weight of the line for which the tree has no node: a mapped bet was all-in in the tree, or the tree's betting
    // ended where the real one went on
    double held = 0; for (const Path &q : paths) held += q.w;
    jb_printf(out, "],\"weightWithoutATreeNode\":%.17g}", held >= 1.0 ? 0.0 : 1.0 - held); return 200;
  } catch (const std::bad_alloc &) { fail(err, errlen, "not enough memory"); return 503; }
}
