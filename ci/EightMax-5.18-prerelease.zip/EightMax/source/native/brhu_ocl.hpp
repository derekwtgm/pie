// EightMax 5.17: the OpenCL side of the heads-up vector best response (brhu-5.17-v1).
//
// OpenCL is loaded at run time (OpenCL.dll in System32 / libOpenCL.so.1), so the program starts on a PC without a
// graphics driver. The kernel is the text of brhu_kernel.h, compiled by the driver with no option that relaxes
// floating point. Before a device is used it must pass brhu_probe: products, sums, differences and quotients of
// chosen doubles must have the bits the CPU computes. A device that fails is refused and nothing it computed is used.
#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#else
#include <dlfcn.h>
#endif
#include "brhu_kernel_src.hpp"

namespace brhu {
typedef int32_t cl_int; typedef uint32_t cl_uint; typedef uint64_t cl_ulong; typedef cl_ulong cl_bitfield;
typedef struct _cl_platform_id *cl_platform_id; typedef struct _cl_device_id *cl_device_id; typedef struct _cl_context *cl_context;
typedef struct _cl_command_queue *cl_command_queue; typedef struct _cl_mem *cl_mem; typedef struct _cl_program *cl_program;
typedef struct _cl_kernel *cl_kernel; typedef intptr_t cl_context_properties;
#ifdef _WIN32
#define BRHU_CLAPI __stdcall
#else
#define BRHU_CLAPI
#endif
struct ClApi {
  cl_int (BRHU_CLAPI *GetPlatformIDs)(cl_uint, cl_platform_id *, cl_uint *);
  cl_int (BRHU_CLAPI *GetPlatformInfo)(cl_platform_id, cl_uint, size_t, void *, size_t *);
  cl_int (BRHU_CLAPI *GetDeviceIDs)(cl_platform_id, cl_bitfield, cl_uint, cl_device_id *, cl_uint *);
  cl_int (BRHU_CLAPI *GetDeviceInfo)(cl_device_id, cl_uint, size_t, void *, size_t *);
  cl_context (BRHU_CLAPI *CreateContext)(const cl_context_properties *, cl_uint, const cl_device_id *, void *, void *, cl_int *);
  cl_command_queue (BRHU_CLAPI *CreateCommandQueue)(cl_context, cl_device_id, cl_bitfield, cl_int *);
  cl_program (BRHU_CLAPI *CreateProgramWithSource)(cl_context, cl_uint, const char **, const size_t *, cl_int *);
  cl_int (BRHU_CLAPI *BuildProgram)(cl_program, cl_uint, const cl_device_id *, const char *, void *, void *);
  cl_int (BRHU_CLAPI *GetProgramBuildInfo)(cl_program, cl_device_id, cl_uint, size_t, void *, size_t *);
  cl_kernel (BRHU_CLAPI *CreateKernel)(cl_program, const char *, cl_int *);
  cl_mem (BRHU_CLAPI *CreateBuffer)(cl_context, cl_bitfield, size_t, void *, cl_int *);
  cl_int (BRHU_CLAPI *ReleaseMemObject)(cl_mem);
  cl_int (BRHU_CLAPI *SetKernelArg)(cl_kernel, cl_uint, size_t, const void *);
  cl_int (BRHU_CLAPI *EnqueueWriteBuffer)(cl_command_queue, cl_mem, cl_uint, size_t, size_t, const void *, cl_uint, const void *, void *);
  cl_int (BRHU_CLAPI *EnqueueReadBuffer)(cl_command_queue, cl_mem, cl_uint, size_t, size_t, void *, cl_uint, const void *, void *);
  cl_int (BRHU_CLAPI *EnqueueNDRangeKernel)(cl_command_queue, cl_kernel, cl_uint, const size_t *, const size_t *, const size_t *, cl_uint, const void *, void *);
  cl_int (BRHU_CLAPI *Finish)(cl_command_queue);
  cl_int (BRHU_CLAPI *ReleaseKernel)(cl_kernel);
  cl_int (BRHU_CLAPI *ReleaseProgram)(cl_program);
  cl_int (BRHU_CLAPI *ReleaseCommandQueue)(cl_command_queue);
  cl_int (BRHU_CLAPI *ReleaseContext)(cl_context);
  bool ok = false; std::string why;
};
inline ClApi &clApi() {
  static ClApi A; static bool tried = false;
  if (tried) return A;
  tried = true;
#ifdef _WIN32
  HMODULE lib = LoadLibraryExA("OpenCL.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
  auto sym = [&](const char *n) -> void * { return lib ? (void *)GetProcAddress(lib, n) : nullptr; };
#else
  void *lib = dlopen("libOpenCL.so.1", RTLD_NOW | RTLD_LOCAL);
  if (!lib) lib = dlopen("libOpenCL.so", RTLD_NOW | RTLD_LOCAL);
  auto sym = [&](const char *n) -> void * { return lib ? dlsym(lib, n) : nullptr; };
#endif
  if (!lib) { A.why = "no OpenCL library on this computer (graphics driver missing?)"; return A; }
#define BRHU_LD(n) { void *p = sym("cl" #n); if (!p) { A.why = "the OpenCL library lacks cl" #n; return A; } std::memcpy(&A.n, &p, sizeof p); }
  BRHU_LD(GetPlatformIDs) BRHU_LD(GetPlatformInfo) BRHU_LD(GetDeviceIDs) BRHU_LD(GetDeviceInfo) BRHU_LD(CreateContext) BRHU_LD(CreateCommandQueue)
  BRHU_LD(CreateProgramWithSource) BRHU_LD(BuildProgram) BRHU_LD(GetProgramBuildInfo) BRHU_LD(CreateKernel) BRHU_LD(CreateBuffer) BRHU_LD(ReleaseMemObject)
  BRHU_LD(SetKernelArg) BRHU_LD(EnqueueWriteBuffer) BRHU_LD(EnqueueReadBuffer) BRHU_LD(EnqueueNDRangeKernel) BRHU_LD(Finish)
  BRHU_LD(ReleaseKernel) BRHU_LD(ReleaseProgram) BRHU_LD(ReleaseCommandQueue) BRHU_LD(ReleaseContext)
#undef BRHU_LD
  A.ok = true; return A;
}
inline const char *clErr(cl_int e) {
  switch (e) {
    case -1: return "device not found"; case -2: return "device not available"; case -3: return "compiler not available";
    case -4: return "out of device memory"; case -5: return "out of resources"; case -6: return "out of host memory";
    case -11: return "kernel build failed"; case -30: return "invalid value"; case -36: return "invalid queue"; case -38: return "invalid buffer";
    case -48: return "invalid kernel"; case -51: return "invalid argument size"; case -52: return "invalid kernel arguments";
    case -54: return "invalid work-group size"; case -61: return "buffer too large"; case -1001: return "no OpenCL platform";
    default: return "OpenCL error";
  }
}
struct ClDevice {
  cl_platform_id platform = nullptr; cl_device_id id = nullptr; int index = 0;
  std::string name, vendor, driver, version, platformName; bool gpu = false, fp64 = false, available = false;
  uint64_t memBytes = 0, maxAllocBytes = 0;
};
inline std::string clTrim(std::string s) { while (!s.empty() && (s.back() == 0 || s.back() == ' ')) s.pop_back(); size_t i = 0; while (i < s.size() && s[i] == ' ') i++; return s.substr(i); }
// Every device of every platform, in the order the driver lists them.
inline std::vector<ClDevice> clDevices(std::string &why) {
  std::vector<ClDevice> out; ClApi &A = clApi();
  if (!A.ok) { why = A.why; return out; }
  cl_platform_id plats[16]; cl_uint np = 0;
  if (A.GetPlatformIDs(16, plats, &np) != 0 || !np) { why = "no OpenCL platform (graphics driver missing?)"; return out; }
  auto dstr = [&](cl_device_id d, cl_uint what) { char buf[1024] = ""; size_t n = 0; A.GetDeviceInfo(d, what, sizeof buf - 1, buf, &n); return clTrim(std::string(buf, std::min(n, sizeof buf - 1))); };
  for (cl_uint p = 0; p < np && p < 16; p++) {
    char pn[256] = ""; size_t pl = 0; A.GetPlatformInfo(plats[p], 0x0902, sizeof pn - 1, pn, &pl);
    cl_device_id devs[16]; cl_uint nd = 0;
    if (A.GetDeviceIDs(plats[p], 0xFFFFFFFFu, 16, devs, &nd) != 0) continue;
    for (cl_uint i = 0; i < nd && i < 16; i++) {
      ClDevice D; D.platform = plats[p]; D.id = devs[i]; D.index = (int)out.size(); D.platformName = clTrim(pn);
      D.name = dstr(devs[i], 0x102B); D.vendor = dstr(devs[i], 0x102C); D.driver = dstr(devs[i], 0x102D); D.version = dstr(devs[i], 0x102F);
      cl_bitfield type = 0; A.GetDeviceInfo(devs[i], 0x1000, sizeof type, &type, nullptr); D.gpu = (type & 4) != 0;
      cl_uint avail = 0; A.GetDeviceInfo(devs[i], 0x1027, sizeof avail, &avail, nullptr); D.available = avail != 0;
      cl_ulong v = 0; A.GetDeviceInfo(devs[i], 0x101F, sizeof v, &v, nullptr); D.memBytes = v; v = 0; A.GetDeviceInfo(devs[i], 0x1010, sizeof v, &v, nullptr); D.maxAllocBytes = v;
      { std::vector<char> ext(65536, 0); size_t n = 0; A.GetDeviceInfo(devs[i], 0x1030, ext.size() - 1, ext.data(), &n); D.fp64 = std::string(ext.data()).find("cl_khr_fp64") != std::string::npos; }
      out.push_back(D);
    }
  }
  if (out.empty()) why = "the OpenCL platforms list no device";
  return out;
}
// The device a request gets. EM_BRHU_DEVICE=<index> names one; otherwise the first available GPU with double
// precision, NVIDIA before others. A CPU device (an OpenCL implementation without a GPU) is taken only when
// EM_BRHU_ALLOW_CPU_DEVICE=1: that is how the path is exercised on a machine without a graphics card.
inline bool clPick(ClDevice &pick, std::string &why) {
  std::vector<ClDevice> all = clDevices(why);
  if (all.empty()) return false;
  const char *env = std::getenv("EM_BRHU_DEVICE"); const char *cpu = std::getenv("EM_BRHU_ALLOW_CPU_DEVICE"); const bool allowCpu = cpu && !std::strcmp(cpu, "1");
  if (env && *env) {
    char *end = nullptr; long w = std::strtol(env, &end, 10);
    if (end == env || *end || w < 0 || w >= (long)all.size()) { why = "EM_BRHU_DEVICE does not name a listed OpenCL device"; return false; }
    pick = all[(size_t)w];
    if (!pick.fp64) { why = "OpenCL device '" + pick.name + "' has no double precision (cl_khr_fp64)"; return false; }
    if (!pick.gpu && !allowCpu) { why = "OpenCL device '" + pick.name + "' is not a GPU (set EM_BRHU_ALLOW_CPU_DEVICE=1 to use it anyway)"; return false; }
    return true;
  }
  const ClDevice *best = nullptr;
  for (const ClDevice &d : all) { if (!d.available || !d.fp64 || !d.gpu) continue; const bool nv = d.vendor.find("NVIDIA") != std::string::npos; if (!best || (nv && best->vendor.find("NVIDIA") == std::string::npos)) best = &d; }
  if (!best && allowCpu) for (const ClDevice &d : all) if (d.available && d.fp64) { best = &d; break; }
  if (!best) { why = "no OpenCL GPU with double precision on this computer (" + std::to_string(all.size()) + " OpenCL device(s) listed)"; return false; }
  pick = *best; return true;
}

// Probe values: products whose exact value is not a double, so that a fused multiply-add gives other bits than
// a product followed by a sum; sums with cancellation; subnormal results; quotients.
inline std::vector<double> probeInput() {
  std::vector<double> v; uint64_t s = 0x9e3779b97f4a7c15ULL;
  auto next = [&]() { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return s; };
  for (int i = 0; i < 4096; i++) {
    const double a = 1.0 + (double)(next() >> 11) / 9007199254740992.0, b = 1.0 + (double)(next() >> 11) / 9007199254740992.0;
    double c = -(a * b);                                  // a*b + c: exactly the rounding error of the product when fused, 0 when not
    if (i % 4 == 1) c = (double)(next() >> 11) / 9007199254740992.0 - 0.5;
    if (i % 4 == 2) c = -(a * b) * (1.0 + 2.220446049250313e-16);
    double x = a, y = b;
    if (i % 16 == 3) { x = a * 1e-160; y = b * 1e-160; c = 4.9e-324; }   // subnormal product
    if (i % 16 == 7) { x = a * 1e-300; y = b; c = -x; }
    v.push_back(x); v.push_back(y); v.push_back(c);
  }
  return v;
}
inline void probeExpect(const std::vector<double> &in, std::vector<double> &out) {
  const size_t n = in.size() / 3; out.resize(n * 5);
  for (size_t i = 0; i < n; i++) {
    volatile double a = in[3 * i], b = in[3 * i + 1], c = in[3 * i + 2]; volatile double p = a * b;
    out[5 * i] = p; out[5 * i + 1] = p + c; /* the kernel's second value is BR_MUL(a, b) + c */ out[5 * i + 2] = a + c; out[5 * i + 3] = a / b; out[5 * i + 4] = a - c;
  }
}

struct ClRun {
  ClApi &A = clApi(); ClDevice dev; cl_context ctx = nullptr; cl_command_queue q = nullptr; cl_program prog = nullptr; cl_kernel krn = nullptr, probe = nullptr;
  std::vector<cl_mem> held; uint64_t bytes = 0; std::string error; bool probed = false; long long probeValues = 0;
  ~ClRun() { close(); }
  ClRun() = default; ClRun(const ClRun &) = delete; ClRun &operator=(const ClRun &) = delete;
  void close() {
    for (cl_mem m : held) if (m) A.ReleaseMemObject(m);
    held.clear();
    if (krn) A.ReleaseKernel(krn); if (probe) A.ReleaseKernel(probe); if (prog) A.ReleaseProgram(prog); if (q) A.ReleaseCommandQueue(q); if (ctx) A.ReleaseContext(ctx);
    krn = probe = nullptr; prog = nullptr; q = nullptr; ctx = nullptr;
  }
  bool fail(const std::string &what, cl_int e) { error = what + ": " + clErr(e) + " (" + std::to_string((int)e) + ")"; return false; }
  bool open() {
    if (!clPick(dev, error)) return false;
    cl_int e = 0; const cl_context_properties props[3] = {0x1084, (cl_context_properties)dev.platform, 0};
    ctx = A.CreateContext(props, 1, &dev.id, nullptr, nullptr, &e); if (!ctx) return fail("OpenCL context", e);
    q = A.CreateCommandQueue(ctx, dev.id, 0, &e); if (!q) return fail("OpenCL queue", e);
    const char *test = std::getenv("EM_BRHU_TEST"); const bool unprotected = test && !std::strcmp(test, "unprotected");   // see brhu_kernel.h
    const std::string src = std::string("#define BRHU_OPENCL 1\n") + (unprotected ? "#define BRHU_UNPROTECTED 1\n" : "") + BRHU_KERNEL_SRC; const char *text = src.c_str(); const size_t len = src.size();
    prog = A.CreateProgramWithSource(ctx, 1, &text, &len, &e); if (!prog) return fail("OpenCL program", e);
    e = A.BuildProgram(prog, 1, &dev.id, unprotected ? "-cl-std=CL1.2 -cl-mad-enable" : "-cl-std=CL1.2", nullptr, nullptr);   // no -cl-mad-enable, no -cl-fast-relaxed-math, no -cl-unsafe-math-optimizations
    if (e != 0) {
      std::vector<char> log(16384, 0); size_t n = 0; A.GetProgramBuildInfo(prog, dev.id, 0x1183, log.size() - 1, log.data(), &n);
      fail("the driver could not compile the kernel", e); error += ": " + clTrim(std::string(log.data())).substr(0, 1500); return false;
    }
    krn = A.CreateKernel(prog, "brhu", &e); if (!krn) return fail("OpenCL kernel brhu", e);
    probe = A.CreateKernel(prog, "brhu_probe", &e); if (!probe) return fail("OpenCL kernel brhu_probe", e);
    return runProbe();
  }
  cl_mem buffer(size_t bytesWanted, const void *data, const char *what) {
    const size_t n = std::max<size_t>(bytesWanted, 16);
    if (dev.maxAllocBytes && n > dev.maxAllocBytes) { error = std::string("the ") + what + " table (" + std::to_string(n >> 20) + " MiB) is larger than one buffer of this device may be (" + std::to_string(dev.maxAllocBytes >> 20) + " MiB)"; return nullptr; }
    cl_int e = 0; cl_mem m = A.CreateBuffer(ctx, 1 /* read-write */, n, nullptr, &e);
    if (!m) { fail(std::string("device buffer for ") + what, e); return nullptr; }
    held.push_back(m); bytes += n;
    if (data && bytesWanted && !write(m, bytesWanted, data, what)) return nullptr;
    return m;
  }
  bool write(cl_mem m, size_t n, const void *data, const char *what) { const cl_int e = A.EnqueueWriteBuffer(q, m, 1, 0, n, data, 0, nullptr, nullptr); return e == 0 || fail(std::string("upload of ") + what, e); }
  bool read(cl_mem m, size_t n, void *data, const char *what) { const cl_int e = A.EnqueueReadBuffer(q, m, 1, 0, n, data, 0, nullptr, nullptr); return e == 0 || fail(std::string("download of ") + what, e); }
  void release(cl_mem m) { for (cl_mem &x : held) if (x == m) { A.ReleaseMemObject(m); x = nullptr; } }
  bool launch(cl_kernel k, size_t count) {
    const size_t global = (count + 63) / 64 * 64;
    cl_int e = A.EnqueueNDRangeKernel(q, k, 1, nullptr, &global, nullptr, 0, nullptr, nullptr); if (e != 0) return fail("kernel launch", e);
    e = A.Finish(q); return e == 0 || fail("kernel run", e);
  }
  bool runProbe() {
    const std::vector<double> in = probeInput(); std::vector<double> want, got; probeExpect(in, want); got.assign(want.size(), 0.0);
    const uint64_t par[8] = {0, 0, 0, 0, 0, 0, 0, in.size() / 3};
    cl_mem bi = buffer(in.size() * 8, in.data(), "probe input"), bo = buffer(want.size() * 8, nullptr, "probe output"), bp = buffer(sizeof par, par, "probe parameters");
    if (!bi || !bo || !bp) return false;
    cl_int e = A.SetKernelArg(probe, 0, sizeof(cl_mem), &bi); e |= A.SetKernelArg(probe, 1, sizeof(cl_mem), &bo); e |= A.SetKernelArg(probe, 2, sizeof(cl_mem), &bp);
    if (e != 0) return fail("probe arguments", e);
    if (!launch(probe, in.size() / 3) || !read(bo, want.size() * 8, got.data(), "probe output")) return false;
    release(bi); release(bo); release(bp);
    long long bad = 0; size_t first = 0;
    for (size_t i = 0; i < want.size(); i++) if (std::memcmp(&want[i], &got[i], 8)) { if (!bad) first = i; bad++; }
    if (std::getenv("EM_BRHU_DEBUG")) { int shown = 0; for (size_t i = 0; i < want.size() && shown < 12; i++) if (std::memcmp(&want[i], &got[i], 8)) { std::fprintf(stderr, "probe %zu kind %zu: a=%a b=%a c=%a want=%a got=%a\n", i / 5, i % 5, in[i / 5 * 3], in[i / 5 * 3 + 1], in[i / 5 * 3 + 2], want[i], got[i]); shown++; } }
    probeValues = (long long)want.size();
    if (bad) {
      static const char *names[5] = {"a product", "a product followed by a sum (the device fuses them)", "a sum", "a quotient", "a difference"};
      error = "the arithmetic of this device differs from the CPU in " + std::to_string(bad) + " of " + std::to_string(want.size()) + " probe values (first: " + names[first % 5] + "); it is not used";
      return false;
    }
    probed = true; return true;
  }
};
} // namespace brhu
