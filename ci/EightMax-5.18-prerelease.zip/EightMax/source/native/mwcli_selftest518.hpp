// EightMax 5.18 (Phase 8, bet sizes outside the tree): mwcli --selftest518 <cases-dir> <work-dir> [all|record]
//
// map-5.18-v1: the mapping rule (map518.hpp), mwcli --translate (a trained strategy written as a state of the same
// game with other bet sizes) and mwcli --offtree (a line of real actions mapped onto a tree). The cases are the
// specs of <cases-dir> (validation/5.18/windows/offtree) with the values recorded on the Linux build in
// <cases-dir>/reference.json.
//
//   M1  the rule: recorded targets and weights (bits) for a table of sizes; the weight is 1 at the lower size, 0 at
//       the upper one, 1/2 at x = (A + B + 2AB) / (A + B + 2), and falls in between
//   T1  training every base study gives the state recorded on Linux
//   T2  a strategy translated into its own tree: the bits of the source under the exact method, for each rule
//   T3  every translated state is the file recorded on Linux (SHA-256)
//   T4  the exact best response against every translated strategy: the bits recorded on Linux
//   T5  what must hold: in the tree with the added size no seat's gain is below its gain in the source tree, and
//       its policy value is the same (1e-9); with the fallback "callCheck" where no row is stored
//   T6  refusals with a reason: training from a translated state (nothing written); translating a translated state;
//       two studies with different boards; an unknown rule; a translated state under another study; a translated
//       state whose header was altered
//   T7  mwcli --offtree: the recorded tree paths and weights of every recorded line; an impossible line is refused
//
// Two-seat cases use method exact-hu, cases with more seats method exact.
// Report: <work-dir>/selftest518.json. Exit status: 0 every check passed, 1 a check failed or is untested, 2 usage.
//   mwcli --selftest518 cases work record   fills <work-dir>/reference.json from THIS build (Linux, at release).
#pragma once
namespace st518 {
namespace fs = std::filesystem;
using st58::Report; using st58::get; using st58::num; using st58::str; using st58::Doc;
using st510::writeText; using st510::Trained; using st510::train;
static const std::vector<std::pair<std::string, std::string>> FIXED = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
static std::string text(const std::string &path) { const std::vector<unsigned char> raw = slurp(path.c_str()); return std::string(raw.begin(), raw.end()); }
static std::string bitsOf(double v) { uint64_t u; std::memcpy(&u, &v, 8); char b[20]; std::snprintf(b, sizeof b, "%016llx", (unsigned long long)u); return b; }
struct Values { bool ok = false; int exitCode = -1, seats = 0; std::string err, raw, nash; std::vector<std::string> bits; std::vector<double> policy, gain; double nc = NAN; };
static bool same(const Values &a, const Values &b) { return a.ok && b.ok && a.nash == b.nash && a.bits == b.bits && !a.bits.empty(); }
struct Base { std::string name, spec, sha; long long deals = 0; int seats = 2; Values own; };
struct Tr { std::string name, base, spec, rule, sha; Values rec; };
struct Line { std::string name, spec, request; std::vector<std::pair<std::string, double>> tree; };
struct RuleRow { std::vector<double> sizes; double x = 0; std::string rule; std::vector<std::pair<int, std::string>> targets; };
struct Ref { std::vector<Base> bases; std::vector<Tr> trs; std::vector<Line> lines; std::vector<RuleRow> rules; };
static Values readValues(const JV *c) {
  Values v; v.nash = str(get(c, "nashConvBits")); const JV *s = get(c, "seats");
  if (s && s->type == J_ARR) for (int p = 0; p < s->n; p++) for (const char *k : {"policyValueBits", "bestResponseValueBits", "gainBits"}) v.bits.push_back(str(get(s->items[p], k)));
  v.ok = !v.nash.empty() && !v.bits.empty(); return v;
}
static bool load(const std::string &dir, Ref &R, std::string &why) {
  const std::string t = text((fs::path(dir) / "reference.json").string()); Doc d(t);
  const JV *bs = get(d.v, "bases"), *ts = get(d.v, "translations"), *ls = get(d.v, "lines"), *rs = get(d.v, "rules");
  if (!bs || bs->type != J_ARR || !ts || ts->type != J_ARR || !ls || ls->type != J_ARR || !rs || rs->type != J_ARR) { why = "reference.json of the cases directory is missing or unreadable"; return false; }
  for (int i = 0; i < bs->n; i++) { const JV *c = bs->items[i]; Base b; b.name = str(get(c, "name")); b.spec = (fs::path(dir) / str(get(c, "spec"))).string(); b.deals = (long long)num(get(c, "deals"), 0); b.seats = (int)num(get(c, "seatCount"), 2); b.sha = str(get(c, "stateSha256")); b.own = readValues(c); R.bases.push_back(b); }
  for (int i = 0; i < ts->n; i++) { const JV *c = ts->items[i]; Tr x; x.name = str(get(c, "name")); x.base = str(get(c, "base")); x.spec = (fs::path(dir) / str(get(c, "spec"))).string(); x.rule = str(get(c, "rule")); x.sha = str(get(c, "stateSha256")); x.rec = readValues(c); R.trs.push_back(x); }
  for (int i = 0; i < ls->n; i++) { const JV *c = ls->items[i]; Line l; l.name = str(get(c, "name")); l.spec = (fs::path(dir) / str(get(c, "spec"))).string(); l.request = jvText(get(c, "request"));
    if (const JV *tr = get(c, "tree")) if (tr->type == J_ARR) for (int j = 0; j < tr->n; j++) l.tree.push_back({str(get(tr->items[j], "path")), num(get(tr->items[j], "weight"))});
    R.lines.push_back(l); }
  for (int i = 0; i < rs->n; i++) { const JV *c = rs->items[i]; RuleRow r; r.x = num(get(c, "x")); r.rule = str(get(c, "rule")); const JV *sz = get(c, "sizes"), *tg = get(c, "targets");
    if (sz && sz->type == J_ARR) for (int j = 0; j < sz->n; j++) r.sizes.push_back(num(sz->items[j]));
    if (tg && tg->type == J_ARR) for (int j = 0; j < tg->n; j++) r.targets.push_back({(int)num(get(tg->items[j], "index"), -1), str(get(tg->items[j], "weightBits"))});
    R.rules.push_back(r); }
  if (R.bases.empty() || R.trs.empty() || R.rules.empty()) { why = "reference.json lists no case"; return false; }
  return true;
}
static Values gain(const std::string &self, const std::string &work, const std::string &spec, const std::string &state, int seats, const char *fallback = "uniform") {
  Values g; const std::string rq = (fs::path(work) / "st518-request.json").string();
  writeText(rq, std::string(seats == 2 ? "{\"method\":\"exact-hu\",\"timeLimitMs\":3600000,\"memoryMiB\":4096,\"threads\":1" : "{\"method\":\"exact\",\"maxVisits\":2000000000,\"timeLimitMs\":3600000,\"memoryMiB\":2048,\"threads\":1") + ",\"fallback\":\"" + fallback + "\"}");
  const ckpt::Run r = ckpt::spawn({self, "--gain", spec, state, rq, "4096"}, work, 3600, {}); g.exitCode = r.exitCode; g.err = (r.err + " " + r.out).substr(0, 300); g.raw = r.out;
  if (!r.started || r.exitCode != 0) return g;
  Doc d(r.out); const JV *s = get(d.v, "seats"); if (!s || s->type != J_ARR) return g;
  g.seats = s->n;
  for (int p = 0; p < s->n; p++) { const JV *x = s->items[p]; const double pv = num(get(x, "policyValue")), br = num(get(x, "bestResponseValue")), ga = num(get(x, "gain")); g.policy.push_back(pv); g.gain.push_back(ga);
    // method exact has no ...Bits fields: the bits are taken from the printed doubles (17 significant digits)
    for (const auto &kv : {std::pair<const char *, double>{"policyValueBits", pv}, {"bestResponseValueBits", br}, {"gainBits", ga}}) { const std::string b = str(get(x, kv.first)); g.bits.push_back(b.empty() ? bitsOf(kv.second) : b); } }
  g.nc = num(get(d.v, "nashConv")); g.nash = str(get(d.v, "nashConvBits")); if (g.nash.empty()) g.nash = bitsOf(g.nc);
  g.ok = s->n == seats && std::isfinite(g.nc); return g;
}
struct Tl { bool ok = false; int exitCode = -1; std::string err, sha, out; };
static Tl translate(const std::string &self, const std::string &work, const std::string &a, const std::string &state, const std::string &b, const std::string &out, const std::string &rule) {
  Tl t; std::error_code ec; fs::remove(out, ec); const ckpt::Run r = ckpt::spawn({self, "--translate", a, state, b, out, rule, "3072"}, work, 1800, {}); t.exitCode = r.exitCode; t.err = (r.err + " " + r.out).substr(0, 300); t.out = r.out;
  if (!r.started || r.exitCode != 0) return t;
  t.sha = ckpt::inspect(out).sha256; t.ok = !t.sha.empty(); return t;
}
static std::string baseState(const std::string &work, const std::string &name) { return (fs::path(work) / ("st518-" + name + ".state")).string(); }
static std::string trState(const std::string &work, const std::string &name) { return (fs::path(work) / ("st518-" + name + ".tr.state")).string(); }
static const Base *baseOf(const Ref &R, const std::string &n) { for (const Base &b : R.bases) if (b.name == n) return &b; return nullptr; }
struct LineOut { bool ok = false; int exitCode = -1; std::string err; std::vector<std::pair<std::string, double>> tree; };
static LineOut line(const std::string &self, const std::string &work, const std::string &spec, const std::string &request) {
  LineOut o; const std::string rq = (fs::path(work) / "st518-line.json").string(); writeText(rq, request);
  const ckpt::Run r = ckpt::spawn({self, "--offtree", spec, rq}, work, 600, {}); o.exitCode = r.exitCode; o.err = (r.err + " " + r.out).substr(0, 200);
  if (!r.started || r.exitCode != 0) return o;
  Doc d(r.out); const JV *tr = get(d.v, "tree"); if (!tr || tr->type != J_ARR) return o;
  for (int j = 0; j < tr->n; j++) o.tree.push_back({str(get(tr->items[j], "path")), num(get(tr->items[j], "weight"))});
  o.ok = true; return o;
}
static std::string valuesJson(const Values &g) {
  std::string o = "\"nashConv\":" + st58::fmt(g.nc) + ",\"nashConvBits\":\"" + g.nash + "\",\"seats\":[";
  for (size_t p = 0; p * 3 < g.bits.size(); p++) o += std::string(p ? "," : "") + "{\"policyValueBits\":\"" + g.bits[p * 3] + "\",\"bestResponseValueBits\":\"" + g.bits[p * 3 + 1] + "\",\"gainBits\":\"" + g.bits[p * 3 + 2] + "\"}";
  return o + "]";
}
static int record(const std::string &dir, const std::string &work, const std::string &self) {
  Ref R; std::string why; if (!load(dir, R, why)) { std::fprintf(stderr, "error: %s\n", why.c_str()); return 2; }
  int bad = 0; std::string o = std::string("{\"algorithm\":\"") + map518::ID + "\",\"rules\":[";
  for (size_t i = 0; i < R.rules.size(); i++) { const RuleRow &r = R.rules[i]; o += std::string(i ? "," : "") + "\n {\"sizes\":[";
    for (size_t j = 0; j < r.sizes.size(); j++) o += std::string(j ? "," : "") + st58::fmt(r.sizes[j]);
    o += "],\"x\":" + st58::fmt(r.x) + ",\"rule\":\"" + r.rule + "\",\"targets\":[";
    const auto t = map518::mapSize(r.sizes, r.x, map518::ruleOf(r.rule));
    for (size_t j = 0; j < t.size(); j++) o += std::string(j ? "," : "") + "{\"index\":" + std::to_string(t[j].index) + ",\"weight\":" + st58::fmt(t[j].weight) + ",\"weightBits\":\"" + bitsOf(t[j].weight) + "\"}";
    o += "]}"; }
  o += "\n],\"bases\":[";
  for (size_t i = 0; i < R.bases.size(); i++) { const Base &b = R.bases[i]; const Trained t = train(self, work, b.spec, b.deals, 1, baseState(work, b.name), "", "3072", FIXED); const Values g = t.ok ? gain(self, work, b.spec, baseState(work, b.name), b.seats) : Values{}; bad += !g.ok;
    o += std::string(i ? "," : "") + "\n {\"name\":" + mwa::jsonEsc(b.name) + ",\"spec\":" + mwa::jsonEsc(fs::path(b.spec).filename().string()) + ",\"deals\":" + std::to_string(b.deals) + ",\"seatCount\":" + std::to_string(b.seats) + ",\"rows\":" + std::to_string(t.rows) + ",\"stateSha256\":\"" + t.sha + "\"," + valuesJson(g) + "}"; }
  o += "\n],\"translations\":[";
  for (size_t i = 0; i < R.trs.size(); i++) { const Tr &x = R.trs[i]; const Base *b = baseOf(R, x.base); if (!b) { bad++; continue; }
    const Tl t = translate(self, work, b->spec, baseState(work, b->name), x.spec, trState(work, x.name), x.rule); const Values g = t.ok ? gain(self, work, x.spec, trState(work, x.name), b->seats) : Values{}; bad += !g.ok;
    o += std::string(i ? "," : "") + "\n {\"name\":" + mwa::jsonEsc(x.name) + ",\"base\":" + mwa::jsonEsc(x.base) + ",\"spec\":" + mwa::jsonEsc(fs::path(x.spec).filename().string()) + ",\"rule\":\"" + x.rule + "\",\"stateSha256\":\"" + t.sha + "\"," + valuesJson(g) + "}";
    std::error_code ec; fs::remove(trState(work, x.name), ec); }
  o += "\n],\"lines\":[";
  for (size_t i = 0; i < R.lines.size(); i++) { const Line &l = R.lines[i]; const LineOut r = line(self, work, l.spec, l.request); bad += !r.ok;
    o += std::string(i ? "," : "") + "\n {\"name\":" + mwa::jsonEsc(l.name) + ",\"spec\":" + mwa::jsonEsc(fs::path(l.spec).filename().string()) + ",\"request\":" + l.request + ",\"tree\":[";
    for (size_t j = 0; j < r.tree.size(); j++) o += std::string(j ? "," : "") + "{\"path\":\"" + r.tree[j].first + "\",\"weight\":" + st58::fmt(r.tree[j].second) + "}";
    o += "]}"; }
  o += "\n]}\n"; writeText((fs::path(work) / "reference.json").string(), o);
  for (const Base &b : R.bases) { std::error_code ec; fs::remove(baseState(work, b.name), ec); }
  std::printf("{\"recorded\":%zu,\"failed\":%d}\n", R.bases.size() + R.trs.size() + R.lines.size(), bad); return bad ? 1 : 0;
}
static int run(int argc, char **argv) {
  if (argc < 4 || argc > 5) { std::fprintf(stderr, "usage: mwcli --selftest518 cases-dir work-dir [all|record]\n"); return 2; }
  const std::string dir = argv[2], work = argv[3], section = argc > 4 ? argv[4] : "all"; std::error_code ec; fs::create_directories(work, ec); mw_study_identity(EM_VERSION, EM_BUILD_ID);
  if (!fs::is_directory(dir, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: cases-dir and work-dir must be directories\n"); return 2; }
  const std::string Dd = fs::absolute(dir, ec).string(), W = fs::absolute(work, ec).string(), self = ckpt::selfPath(argv[0]);
  if (section == "record") return record(Dd, W, self);
  if (section != "all") { std::fprintf(stderr, "error: the section must be all or record\n"); return 2; }
  Ref R; std::string why; if (!load(Dd, R, why)) { std::fprintf(stderr, "error: %s\n", why.c_str()); return 2; }
  Report rep; const std::string sec = "off-tree"; const auto t0 = std::chrono::steady_clock::now();
  { int ok = 0; std::string detail;
    for (const RuleRow &r : R.rules) { const auto t = map518::mapSize(r.sizes, r.x, map518::ruleOf(r.rule)); bool good = t.size() == r.targets.size() && !t.empty(); double sum = 0;
      for (size_t j = 0; good && j < t.size(); j++) { good = t[j].index == r.targets[j].first && bitsOf(t[j].weight) == r.targets[j].second; sum += t[j].weight; }
      good = good && std::fabs(sum - 1) < 1e-12; ok += good; if (!good) detail += "x " + st58::fmt(r.x) + " rule " + r.rule + "; "; }
    bool shape = true; const double A = 0.5, B = 1.0, mid = (A + B + 2 * A * B) / (A + B + 2);
    shape = shape && map518::lowerWeight(A, B, A) == 1.0 && map518::lowerWeight(A, B, B) == 0.0 && std::fabs(map518::lowerWeight(A, B, mid) - 0.5) < 1e-15;
    for (double x = A; x < B; x += 0.01) shape = shape && map518::lowerWeight(A, B, x) > map518::lowerWeight(A, B, x + 0.01);
    shape = shape && map518::mapSize({A, B}, 0.74, map518::NEAREST)[0].index == 0 && map518::mapSize({A, B}, 0.74, map518::HARMONIC)[0].index == 1;   // between the harmonic threshold (0.714) and the midpoint (0.75) the two rules differ
    rep.check(sec, "M1", "the mapping rule: the recorded target sizes and weights (bit for bit) for a table of sizes and the three rules; the weight of the lower size is 1 at the lower size, 0 at the upper one, 1/2 at (A + B + 2AB) / (A + B + 2), and falls in between; nearest and harmonic differ only between that point and the midpoint", ok == (int)R.rules.size() && shape,
              std::to_string(ok) + " of " + std::to_string(R.rules.size()) + " recorded rows identical; shape " + (shape ? "as stated" : "NOT as stated") + (detail.empty() ? "" : "; differing: " + detail)); }
  { int same = 0; std::string detail;
    for (const Base &b : R.bases) { const Trained t = train(self, W, b.spec, b.deals, 1, baseState(W, b.name), "", "3072", FIXED); if (t.ok && t.sha == b.sha) same++; else detail += b.name + ": " + (t.ok ? "another state" : "exit " + std::to_string(t.exitCode) + " " + t.err) + "; "; }
    rep.check(sec, "T1", "training every base study with the default trainer on one thread gives the state recorded on the Linux build (SHA-256)", same == (int)R.bases.size(), std::to_string(same) + " of " + std::to_string(R.bases.size()) + " states identical" + (detail.empty() ? "" : "; " + detail)); }
  std::vector<Values> own(R.bases.size());
  { int ok = 0, total = 0; std::string detail; int recorded = 0;
    for (size_t i = 0; i < R.bases.size(); i++) { const Base &b = R.bases[i]; own[i] = gain(self, W, b.spec, baseState(W, b.name), b.seats); recorded += same(own[i], b.own);
      for (const char *rule : {"nearest", "harmonic", "blend"}) { total++; const std::string out = trState(W, b.name + "-identity"); const Tl t = translate(self, W, b.spec, baseState(W, b.name), b.spec, out, rule); const Values g = t.ok ? gain(self, W, b.spec, out, b.seats) : Values{};
        if (same(g, own[i])) ok++; else detail += b.name + " " + rule + (t.ok ? "" : ": " + t.err) + "; "; fs::remove(out, ec); } }
    rep.check(sec, "T2", "a strategy translated into its own tree is the same strategy: policy value, best-response value and gain of every seat and NashConv have the bits of the source state under the exact method, for each rule; and the source values are the ones recorded on Linux", ok == total && recorded == (int)R.bases.size(),
              std::to_string(ok) + " of " + std::to_string(total) + " translations identical to their source; " + std::to_string(recorded) + " of " + std::to_string(R.bases.size()) + " source results as recorded" + (detail.empty() ? "" : "; differing: " + detail)); }
  std::vector<Values> got(R.trs.size()); std::vector<Tl> tl(R.trs.size());
  { int ok = 0; std::string detail;
    for (size_t i = 0; i < R.trs.size(); i++) { const Tr &x = R.trs[i]; const Base *b = baseOf(R, x.base); if (!b) { detail += x.name + ": no base; "; continue; }
      tl[i] = translate(self, W, b->spec, baseState(W, b->name), x.spec, trState(W, x.name), x.rule); if (tl[i].ok && tl[i].sha == x.sha) ok++; else detail += x.name + (tl[i].ok ? ": another file" : ": exit " + std::to_string(tl[i].exitCode) + " " + tl[i].err) + "; "; }
    rep.check(sec, "T3", "mwcli --translate: the strategy of every base study written as a state of the study with one more bet or raise size, under the recorded rule, is the file recorded on the Linux build (SHA-256), and loads as a state of that study", ok == (int)R.trs.size(), std::to_string(ok) + " of " + std::to_string(R.trs.size()) + " translated states identical" + (detail.empty() ? "" : "; " + detail)); }
  { int ok = 0; std::string detail;
    for (size_t i = 0; i < R.trs.size(); i++) { const Tr &x = R.trs[i]; const Base *b = baseOf(R, x.base); if (!b || !tl[i].ok) { detail += x.name + ": not translated; "; continue; }
      got[i] = gain(self, W, x.spec, trState(W, x.name), b->seats); if (same(got[i], x.rec)) ok++; else detail += x.name + (got[i].ok ? ": other bits" : ": exit " + std::to_string(got[i].exitCode) + " " + got[i].err) + "; "; }
    rep.check(sec, "T4", "the exact best response against every translated strategy, in the tree with the added size (method exact-hu for two seats, method exact for three): policy value, best-response value and gain of every seat and NashConv have the bits recorded on the Linux build", ok == (int)R.trs.size(), std::to_string(ok) + " of " + std::to_string(R.trs.size()) + " results identical" + (detail.empty() ? "" : "; " + detail)); }
  { int ok = 0, total = 0; std::string detail; double worst = 0; std::vector<Values> ownCc(R.bases.size());
    for (size_t i = 0; i < R.trs.size(); i++) { const Tr &x = R.trs[i]; size_t bi = 0; while (bi < R.bases.size() && R.bases[bi].name != x.base) bi++; if (bi == R.bases.size() || !got[i].ok || !own[bi].ok) continue;
      // with the fallback "callCheck": the same strategy in both trees where no row is stored (the default, uniform, is uniform over one more action in the larger tree)
      if (ownCc[bi].nash.empty() && !ownCc[bi].ok) ownCc[bi] = gain(self, W, R.bases[bi].spec, baseState(W, R.bases[bi].name), R.bases[bi].seats, "callCheck");
      const Values b = gain(self, W, x.spec, trState(W, x.name), R.bases[bi].seats, "callCheck"), &a = ownCc[bi];
      total++; bool good = a.ok && b.ok && b.gain.size() == a.gain.size();
      for (size_t p = 0; good && p < b.gain.size(); p++) { const double tol = 1e-9 * std::max(1.0, std::fabs(a.gain[p])); if (b.gain[p] < a.gain[p] - tol) good = false; if (std::fabs(b.policy[p] - a.policy[p]) > 1e-9 * std::max(1.0, std::fabs(a.policy[p]))) good = false; worst = std::max(worst, b.gain[p] - a.gain[p]); }
      ok += good; if (!good) detail += x.name + "; "; }
    rep.check(sec, "T5", "what must hold for every translated strategy: in the tree with the added size no seat's gain is below its gain in the source tree (a best response can always stay inside the source tree), and every seat's policy value is the one of the source (no translated strategy uses the added size), both within 1e-9. Checked with the fallback \"callCheck\" for hands without a stored row, which is the same strategy in both trees", ok == total && total == (int)R.trs.size(),
              std::to_string(ok) + " of " + std::to_string(total) + " cases; the largest increase of a seat's gain is " + st58::sci(worst) + " chips" + (detail.empty() ? "" : "; failing: " + detail)); }
  { int refused = 0, n = 0; std::string detail; const Tr &x = R.trs[0]; const Base *b = baseOf(R, x.base); const std::string ts = trState(W, x.name);
    auto note = [&](const char *what, bool ok, const std::string &err) { n++; refused += ok; detail += std::string(what) + (ok ? ": refused; " : ": NOT refused as expected (" + err.substr(0, 120) + "); "); };
    if (b && tl[0].ok) {
      const std::string out = (fs::path(W) / "st518-continued.state").string(); fs::remove(out, ec);
      const Trained t = train(self, W, x.spec, 100, 1, out, ts, "3072", FIXED); note("training from a translated state", !t.ok && t.err.find("translated") != std::string::npos && !fs::exists(out), t.err);
      const Tl again = translate(self, W, x.spec, ts, x.spec, (fs::path(W) / "st518-again.state").string(), "harmonic"); note("translating a translated state", !again.ok && again.err.find("itself a translated state") != std::string::npos, again.err);
      const Base *other = nullptr; for (const Base &o : R.bases) if (o.name != b->name && o.seats == b->seats) { other = &o; break; }
      if (other) { const Tl t2 = translate(self, W, b->spec, baseState(W, b->name), other->spec, (fs::path(W) / "st518-other.state").string(), "harmonic"); note("two studies with different boards", !t2.ok && t2.err.find("differ") != std::string::npos, t2.err); }
      const Tl t3 = translate(self, W, b->spec, baseState(W, b->name), x.spec, (fs::path(W) / "st518-rule.state").string(), "closest"); note("an unknown rule", !t3.ok && t3.err.find("unknown mapping rule") != std::string::npos, t3.err);
      const Values v = gain(self, W, b->spec, ts, b->seats); note("a translated state under the source study", !v.ok && v.exitCode != 0 && v.raw.find("nashConv") == std::string::npos, v.err);
      // the header names the source study: one character of it changed, and the identifier no longer fits
      { std::vector<unsigned char> raw = slurp(ts.c_str()); const std::string all(raw.begin(), raw.end()); const size_t at = all.find("\"translatedFrom\":\""); const std::string bad = (fs::path(W) / "st518-altered.state").string();
        if (at != std::string::npos) { raw[at + 18] = raw[at + 18] == '0' ? '1' : '0'; FILE *f = std::fopen(bad.c_str(), "wb"); if (f) { std::fwrite(raw.data(), 1, raw.size(), f); std::fclose(f); } const Values a = gain(self, W, x.spec, bad, b->seats); note("a translated state with an altered header", !a.ok && a.exitCode != 0 && a.raw.find("nashConv") == std::string::npos, a.err); fs::remove(bad, ec); } }
    }
    rep.check(sec, "T6", "refused with a reason: training continued from a translated state (and nothing written); translating a translated state; translating between studies with different boards; an unknown rule; a translated state evaluated under the source study; a translated state whose header was altered", refused == n && n == 6, std::to_string(refused) + " of " + std::to_string(n) + " refused; " + detail); }
  { int ok = 0; std::string detail;
    for (const Line &l : R.lines) { const LineOut r = line(self, W, l.spec, l.request); bool good = r.ok && r.tree.size() == l.tree.size();
      for (size_t j = 0; good && j < r.tree.size(); j++) good = r.tree[j].first == l.tree[j].first && std::fabs(r.tree[j].second - l.tree[j].second) <= 1e-12;
      ok += good; if (!good) detail += l.name + (r.ok ? ": other paths or weights" : ": " + r.err) + "; "; }
    const LineOut badLine = R.lines.empty() ? LineOut{} : line(self, W, R.lines[0].spec, "{\"actions\":[\"fold\"]}");
    const bool refused = !badLine.ok && badLine.exitCode != 0;
    rep.check(sec, "T7", "mwcli --offtree: every recorded line of real actions (bets and raises of sizes the tree does not have, on two and three seats, the three rules) ends on the recorded tree paths with the recorded weights; a line that cannot be played (a fold with no bet to fold to) is refused", ok == (int)R.lines.size() && !R.lines.empty() && refused,
              std::to_string(ok) + " of " + std::to_string(R.lines.size()) + " lines as recorded; the impossible line: " + (refused ? "refused" : "NOT refused") + (detail.empty() ? "" : "; " + detail)); }
  for (const Base &b : R.bases) fs::remove(baseState(W, b.name), ec);
  for (const Tr &x : R.trs) fs::remove(trState(W, x.name), ec);
  for (const char *f : {"st518-request.json", "st518-line.json", "st518-again.state", "st518-other.state", "st518-rule.state", "st518-continued.state"}) fs::remove((fs::path(W) / f).string(), ec);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest518\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"all\",\"algorithm\":\"" + map518::ID + "\",\"passed\":" + std::to_string(rep.passed) + ",\"failed\":" + std::to_string(rep.failed) + ",\"untested\":" + std::to_string(rep.untested) + ",\"seconds\":" + st58::fmt(secs) + ",\"checks\":[";
  for (size_t i = 0; i < rep.checks.size(); i++) { const st58::Check &c = rep.checks[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}"; const std::string report = (fs::path(work) / "selftest518.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest518\",\"build\":\"%s\",\"section\":\"all\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"report\":%s}\n", EM_BUILD_ID, rep.passed, rep.failed, rep.untested, mwa::jsonEsc(report).c_str());
  return rep.failed || rep.untested ? 1 : 0;
}
}
