// 5.15: the tournament payoff model "tour-5.15-v1": knockout and progressive-knockout bounties, and future-game
// simulation of the next hands, for the multiway engine. Off unless a spec asks for it ("icm":{"model":"tour-5.15"}).
//
// What a final stack vector of one hand is worth to a player (prize units), V_d, d = hands simulated after this one:
//
//   V_0(x, h)  =  ICM(x)  +  (x_i / X) * sum of the heads h of the players still in          ("pool rule")
//                 ICM is the Malmuth-Harville recursion of icm.hpp / lib_icm.js with the bust rule of this program
//                 (players busted in the same hand take the open places by their stack at the start of the hand);
//                 X is every chip in play after the hand. Every head that is still out is paid to somebody in the end; the rule
//                 gives a player the share of that money that equals the share of the chips. It is a MODEL (exact
//                 when two players remain and the bigger chance to win is the share of the chips; an approximation
//                 otherwise; MATHEMATICAL-VALIDATION-5.15.md).
//   V_d(x, h)  =  the value of the next hand at the same blind level, played as the push/fold game of
//                 web/lib_pushfold.js among the players still at the table (button one seat on), in which every
//                 outcome y of that hand is worth: bounty cash paid in it + V_{d-1}(y, h').
//                 If fewer than two remain at the table, a player cannot post, or no prize and no head is left to
//                 play for, V_d = V_0.
//
// Bounties: a player busted in a hand pays share k of the head on them to the winner(s) of the last pot the player
// was in (k = 1 knockout, k = 0.5 progressive; equal parts on a split pot); the rest, 1 - k, is added to the
// winners' own heads.
//
// The push/fold game is a port of lib_pushfold.js, operation for operation, with one exception: the two discount
// factors t^1.5/(t^1.5+1) and ((t-1)/t)^2 are computed with sqrt and products instead of pow (pow is not the same
// function in every C library; sqrt is exact in all of them). Values therefore agree with the JavaScript calculator to
// rounding (tools/tour515_js.js), not to the bit; Linux and Windows builds agree to the bit (--selftest515).
#ifndef EM_TOUR515_HPP
#define EM_TOUR515_HPP
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>
namespace t515 {
#include "pf515_tables.hpp"
static constexpr const char *MODEL = "tour-5.15-v1";
static constexpr int NC = 169, MAXN = 16, MAXT = 8, MAX_DEPTH = 6;
static constexpr double MAX_WORK = 2000;   // future-hand solutions below one outcome of the studied hand (worst case)

struct Tables {
  std::vector<double> MT, MWT, MTT; double pi[NC];
  Tables() : MT(NC * NC), MWT(NC * NC), MTT(NC * NC) {
    std::vector<double> W(NC * NC), T(NC * NC); int k = 0;
    for (int a = 0; a < NC; a++) for (int b = a; b < NC; b++) {
      const double w = PF515_EQ[k++] / 65535.0, t = PF515_EQ[k++] / 65535.0;
      W[a * NC + b] = w; T[a * NC + b] = t;
      if (a != b) { W[b * NC + a] = std::max(0.0, 1 - w - t); T[b * NC + a] = t; }
    }
    for (int a = 0; a < NC; a++) pi[a] = PF515_COMBOS[a] / 1326.0;
    for (int h = 0; h < NC; h++) for (int c = 0; c < NC; c++) {
      const double m = PF515_PAIRS[h * NC + c] / (PF515_COMBOS[h] * 1225.0);
      MT[c * NC + h] = m; MWT[c * NC + h] = m * W[h * NC + c]; MTT[c * NC + h] = m * T[h * NC + c];
    }
  }
};
inline const Tables &tables() { static const Tables t; return t; }

// ---- ICM (lib_icm.js icmRawReference and icmWithBusts) ----
inline void icmRaw(const double *stacks, int n, const double *payouts, int paid, double *res) {
  for (int i = 0; i < n; i++) res[i] = 0;
  if (!n) return;
  const int P = std::min(paid, n); double total = 0; for (int i = 0; i < n; i++) total += stacks[i];
  const unsigned size = 1u << n;
  // Scratch memory is local to the call. A first version kept it in thread_local vectors; on a Windows machine the
  // program then ended with a heap-corruption status (0xC0000374) in some trainings that solved future hands on three
  // threads, and never on Linux or under Wine. Thread-local objects with destructors are the suspected cause with
  // this toolchain; that was not examined further once the status no longer appeared (VALIDATION-5.15.md).
  std::vector<double> prob(size, 0.0), msum(size); std::vector<uint8_t> pc(size);
  prob[0] = 1; msum[0] = 0; pc[0] = 0;
  for (unsigned mask = 1; mask < size; mask++) { const unsigned low = mask & (0u - mask), rest = mask ^ low; msum[mask] = msum[rest] + stacks[std::countr_zero(low)]; pc[mask] = (uint8_t)(pc[rest] + 1); }
  for (unsigned mask = 0; mask < size; mask++) {
    const double pm = prob[mask]; if (pm == 0) continue;
    const int k = pc[mask]; if (k >= P) continue;
    const double rem = total - msum[mask]; if (rem <= 1e-12) continue;
    const double pay = payouts[k];
    for (int i = 0; i < n; i++) { if (mask & (1u << i)) continue; const double p = pm * stacks[i] / rem; if (p == 0) continue; res[i] += p * pay; prob[mask | (1u << i)] += p; }
  }
}
inline void icmWithBusts(const double *fin, const double *start, int n, const double *payouts, int paid, double *res) {
  int alive[MAXN], busted[MAXN], na = 0, nb = 0; double st[MAXN], eq[MAXN];
  for (int i = 0; i < n; i++) { if (fin[i] > 1e-9) alive[na++] = i; else busted[nb++] = i; }
  for (int j = 0; j < na; j++) st[j] = fin[alive[j]];
  icmRaw(st, na, payouts, std::min(paid, na), eq);
  for (int i = 0; i < n; i++) res[i] = 0;
  for (int j = 0; j < na; j++) res[alive[j]] = eq[j];
  std::stable_sort(busted, busted + nb, [&](int a, int b) { return start[a] > start[b]; });
  for (int k = 0; k < nb;) {
    int end = k + 1; while (end < nb && std::fabs(start[busted[end]] - start[busted[k]]) < 1e-9) end++;
    double pool = 0; for (int j = k; j < end; j++) pool += na + j < paid ? payouts[na + j] : 0;
    for (int j = k; j < end; j++) res[busted[j]] = pool / (end - k);
    k = end;
  }
}

// ---- the push/fold game of lib_pushfold.js (ICM mode) for n players; the payoff of an outcome comes from Val ----
// Val(v, winner, loser, out): out[p] = value of final stacks v to seat p; winner/loser are -1 unless seat `winner`
// won an all-in against seat `loser`.
template <class Val> struct PushFold {
  int n = 0; bool ok = false; double S[MAXT], ante[MAXT], blind[MAXT], L[MAXT], base[MAXT], sumAnte = 0, sumBlind = 0;
  std::vector<double> VF, VS;   // VF[i][p]; VS[((i*n+j)*3+r)*n+p]
  struct Dec { std::vector<double> r0, r1, s0, s1, cur, avg; Dec() : r0(NC), r1(NC), s0(NC), s1(NC), cur(NC, 0.5), avg(NC, 0.5) {} };
  std::vector<Dec> jam, call;   // jam[i]; call[i*n+j]
  std::vector<double> RJ, WJ, TJ, EVJ, PC, EW, ET, EVC, EVF, Eacc, after, FVC, Fr;
  double Pjam[MAXT], R[MAXT], FV[MAXT]; int t = 0;
  // anteType: 0 none, 1 classic (every seat), 2 big-blind ante
  PushFold(int n_, const double *stacks, double sb, double bb, int anteType, double anteAmt, Val &val) : n(n_) {
    tables();
    if (n < 2 || n > MAXT) return;
    for (int p = 0; p < n; p++) { S[p] = stacks[p]; if (!(S[p] > 0)) return; }
    const int sbSeat = n - 2, bbSeat = n - 1;
    for (int p = 0; p < n; p++) {
      const double bl = p == bbSeat ? bb : p == sbSeat ? sb : 0;
      if (anteType == 1) { ante[p] = std::min(anteAmt, S[p]); blind[p] = std::min(bl, S[p] - ante[p]); }
      else if (anteType == 2) { blind[p] = std::min(bl, S[p]); ante[p] = p == bbSeat ? std::min(anteAmt, S[p] - blind[p]) : 0; }
      else { blind[p] = std::min(bl, S[p]); ante[p] = 0; }
    }
    for (int p = 0; p < n; p++) if (S[p] - ante[p] - blind[p] <= 1e-9) return;   // all-in from posting: no game
    for (int p = 0; p < n; p++) { L[p] = S[p] - ante[p]; sumAnte += ante[p]; sumBlind += blind[p]; }
    for (int p = 0; p < n; p++) base[p] = S[p] - ante[p] - blind[p];
    VF.assign((size_t)n * n, 0); VS.assign((size_t)n * n * 3 * n, 0);
    double v[MAXT];
    for (int i = 0; i < n; i++) { std::copy_n(base, n, v); v[i] += sumAnte + sumBlind; val(v, -1, -1, &VF[(size_t)i * n]); }
    for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) {
      const double m = std::min(L[i], L[j]), pot = 2 * m + sumAnte + sumBlind - blind[i] - blind[j];
      for (int r = 0; r < 3; r++) {
        std::copy_n(base, n, v); v[i] = S[i] - ante[i] - m; v[j] = S[j] - ante[j] - m;
        if (r == 0) v[i] += pot; else if (r == 1) v[j] += pot; else { v[i] += pot / 2; v[j] += pot / 2; }
        double *out = &VS[(((size_t)i * n + j) * 3 + r) * n];
        if (r == 0) val(v, i, j, out); else if (r == 1) val(v, j, i, out); else val(v, -1, -1, out);
      }
    }
    jam.resize((size_t)n); call.resize((size_t)n * n);
    const size_t a1 = (size_t)n * NC, a2 = (size_t)n * n * NC;
    RJ.assign(a1, 0); WJ.assign(a1, 0); TJ.assign(a1, 0); EVJ.assign(a1, 0);
    PC.assign(a2, 0); EW.assign(a2, 0); ET.assign(a2, 0); EVC.assign(a2, 0); EVF.assign(a2, 0);
    Eacc.assign((size_t)n * (n + 1) * n, 0); after.assign((size_t)n * n, 0); FVC.assign((size_t)n * n, 0); Fr.assign((size_t)n * (n + 1), 0);
    ok = true;
  }
  static void mv3(const double *x, double *o1, double *o2, double *o3) {
    const Tables &T = tables(); const double *MT = T.MT.data(), *MWT = T.MWT.data(), *MTT = T.MTT.data();
    std::fill_n(o1, NC, 0.0); std::fill_n(o2, NC, 0.0); std::fill_n(o3, NC, 0.0);
    for (int c = 0; c < NC; c++) {
      const double xc = x[c]; if (xc < 1e-12) continue;
      const double *a = MT + c * NC, *b = MWT + c * NC, *d = MTT + c * NC;
      for (int h = 0; h < NC; h++) { o1[h] += a[h] * xc; o2[h] += b[h] * xc; o3[h] += d[h] * xc; }
    }
  }
  double *vs(int i, int j, int r) { return &VS[(((size_t)i * n + j) * 3 + r) * n]; }
  double *eacc(int i, int j0) { return &Eacc[((size_t)i * (n + 1) + j0) * n]; }
  void compute(bool useAvg) {
    const double *pi = tables().pi; double tmp[MAXT], pcU[MAXT + 1];
    for (int i = 0; i < n - 1; i++) {
      const double *Ji = useAvg ? jam[i].avg.data() : jam[i].cur.data();
      mv3(Ji, &RJ[(size_t)i * NC], &WJ[(size_t)i * NC], &TJ[(size_t)i * NC]);
      double pj = 0; for (int c = 0; c < NC; c++) pj += pi[c] * Ji[c];
      Pjam[i] = pj;
      for (int j = i + 1; j < n; j++) { const Dec &d = call[(size_t)i * n + j]; const size_t o = ((size_t)i * n + j) * NC; mv3(useAvg ? d.avg.data() : d.cur.data(), &PC[o], &EW[o], &ET[o]); }
    }
    R[0] = 1; for (int i = 1; i < n - 1; i++) R[i] = R[i - 1] * (1 - Pjam[i - 1]);
    for (int i = 0; i < n - 1; i++) {
      const double *Ji = useAvg ? jam[i].avg.data() : jam[i].cur.data();
      for (int j0 = i + 1; j0 <= n; j0++) std::fill_n(eacc(i, j0), n, 0.0);
      std::fill_n(pcU, n + 1, 0.0);
      double wsum = 0; const double *vf = &VF[(size_t)i * n];
      for (int c = 0; c < NC; c++) {
        const double wgt = pi[c] * (Ji[c] + 1e-9);
        wsum += wgt;
        std::copy_n(vf, n, tmp);
        double *acc = eacc(i, n); for (int p = 0; p < n; p++) acc[p] += wgt * tmp[p];
        for (int j0 = n - 1; j0 > i; j0--) {
          const size_t o = ((size_t)i * n + j0) * NC;
          const double pc = PC[o + c], ew = EW[o + c], et = ET[o + c], el = pc - ew - et, nf = 1 - pc;
          const double *vw = vs(i, j0, 0), *vl = vs(i, j0, 1), *vt = vs(i, j0, 2);
          for (int p = 0; p < n; p++) tmp[p] = ew * vw[p] + et * vt[p] + el * vl[p] + nf * tmp[p];
          acc = eacc(i, j0); for (int p = 0; p < n; p++) acc[p] += wgt * tmp[p];
          pcU[j0] += wgt * pc;
        }
        EVJ[(size_t)i * NC + c] = tmp[i];
      }
      for (int j0 = i + 1; j0 <= n; j0++) { double *a = eacc(i, j0); for (int p = 0; p < n; p++) a[p] /= wsum; }
      Fr[(size_t)i * (n + 1) + i + 1] = 1;
      for (int j = i + 1; j < n; j++) { FVC[(size_t)i * n + j] = eacc(i, j + 1)[j]; Fr[(size_t)i * (n + 1) + j + 1] = Fr[(size_t)i * (n + 1) + j] * (1 - pcU[j] / wsum); }
    }
    std::copy_n(&VF[(size_t)(n - 1) * n], n, &after[(size_t)(n - 2) * n]);
    for (int k = n - 2; k >= 1; k--) {
      double *a = &after[(size_t)(k - 1) * n]; const double *e = eacc(k, k + 1), *b = &after[(size_t)k * n]; const double pj = Pjam[k];
      for (int p = 0; p < n; p++) a[p] = pj * e[p] + (1 - pj) * b[p];
    }
    for (int i = 0; i < n - 1; i++) FV[i] = after[(size_t)i * n + i];
    for (int i = 0; i < n - 1; i++) for (int j = i + 1; j < n; j++) {
      const double vJ = vs(i, j, 1)[j], vT = vs(i, j, 2)[j], vI = vs(i, j, 0)[j], fv = FVC[(size_t)i * n + j];
      double *ec = &EVC[((size_t)i * n + j) * NC], *ef = &EVF[((size_t)i * n + j) * NC]; const double *rj = &RJ[(size_t)i * NC], *wj = &WJ[(size_t)i * NC], *tj = &TJ[(size_t)i * NC];
      for (int h = 0; h < NC; h++) { ec[h] = wj[h] * vJ + tj[h] * vT + (rj[h] - wj[h] - tj[h]) * vI; ef[h] = rj[h] * fv; }
    }
  }
  static void update(Dec &d, const double *q1, const double *q0, double q0c, double scale, double pd, double sd) {
    for (int h = 0; h < NC; h++) {
      const double a = q1[h] * scale, b = (q0 ? q0[h] : q0c) * scale, s = d.cur[h], v = s * a + (1 - s) * b;
      double x = d.r1[h]; d.r1[h] = (x > 0 ? x * pd : x * 0.5) + (a - v);
      x = d.r0[h]; d.r0[h] = (x > 0 ? x * pd : x * 0.5) + (b - v);
      d.s1[h] = d.s1[h] * sd + s; d.s0[h] = d.s0[h] * sd + (1 - s);
    }
  }
  template <class F> void each(F f) { for (int i = 0; i < n - 1; i++) f(jam[i]); for (int i = 0; i < n - 1; i++) for (int j = i + 1; j < n; j++) f(call[(size_t)i * n + j]); }
  void refreshAvg() { each([](Dec &d) { for (int h = 0; h < NC; h++) { const double s = d.s0[h] + d.s1[h]; d.avg[h] = s > 0 ? d.s1[h] / s : 0.5; } }); }
  void iterate(int k) {
    for (int it = 0; it < k; it++) {
      t++;
      each([](Dec &d) { for (int h = 0; h < NC; h++) { const double a = d.r1[h] > 0 ? d.r1[h] : 0, b = d.r0[h] > 0 ? d.r0[h] : 0, s = a + b; d.cur[h] = s > 0 ? a / s : 0.5; } });
      compute(false);
      const double td = t, ta = td * std::sqrt(td), pd = ta / (ta + 1), q = (td - 1) / td, sd = q * q;
      for (int i = 0; i < n - 1; i++) update(jam[i], &EVJ[(size_t)i * NC], nullptr, FV[i], R[i], pd, sd);
      for (int i = 0; i < n - 1; i++) for (int j = i + 1; j < n; j++) update(call[(size_t)i * n + j], &EVC[((size_t)i * n + j) * NC], &EVF[((size_t)i * n + j) * NC], 0, R[i] * Fr[(size_t)i * (n + 1) + j], pd, sd);
    }
    refreshAvg();
  }
  // largest gain of one player from best-responding to the average profile (per hand dealt)
  double exploitability(double *gains = nullptr) {
    refreshAvg(); compute(true);
    const double *pi = tables().pi; double g[MAXT] = {};
    for (int i = 0; i < n - 1; i++) {
      const double *s = jam[i].avg.data(), *ev = &EVJ[(size_t)i * NC], fv = FV[i]; double x = 0;
      for (int h = 0; h < NC; h++) { const double a = ev[h], b = fv; x += pi[h] * (std::max(a, b) - (s[h] * a + (1 - s[h]) * b)); }
      g[i] += R[i] * x;
    }
    for (int i = 0; i < n - 1; i++) for (int j = i + 1; j < n; j++) {
      const double *s = call[(size_t)i * n + j].avg.data(), *ec = &EVC[((size_t)i * n + j) * NC], *ef = &EVF[((size_t)i * n + j) * NC]; double x = 0;
      for (int h = 0; h < NC; h++) { const double a = ec[h], b = ef[h]; x += pi[h] * (std::max(a, b) - (s[h] * a + (1 - s[h]) * b)); }
      g[j] += R[i] * Fr[(size_t)i * (n + 1) + j] * x;
    }
    double mx = 0; for (int p = 0; p < n; p++) { mx = std::max(mx, g[p]); if (gains) gains[p] = g[p]; }
    return mx;
  }
  // lib_pushfold.js solve({maxIter, tol}): blocks of 50 iterations until t >= maxIter or the gain is below tol * unit
  double solve(int maxIter, double tol, double unit) { double ex = 0; while (t < maxIter) { iterate(50); ex = exploitability(); if (ex / unit < tol) break; } return ex; }
  void values(double *out) {
    refreshAvg(); compute(true);
    const double *e = eacc(0, 1), *f = &after[0], pj = Pjam[0];
    for (int p = 0; p < n; p++) out[p] = pj * e[p] + (1 - pj) * f[p];
  }
  double jamPct(int i) const { const double *pi = tables().pi; double s = 0; for (int h = 0; h < NC; h++) s += pi[h] * jam[i].avg[h]; return s * 100; }
  double callPct(int i, int j) const { const double *pi = tables().pi; double s = 0; for (int h = 0; h < NC; h++) s += pi[h] * call[(size_t)i * n + j].avg[h]; return s * 100; }
};

// ---- the model ----
struct Model {
  // configuration (set by the spec parser, checked by prepare)
  bool enabled = false;
  double share = 0; std::vector<double> heads;        // bounties: share k in (0, 1], one head per player of "start"
  int depth = 0; std::vector<int> table;              // future hands; players at this table in position order (indices of "start")
  double sb = 0.5, bb = 1, ante = 0; int anteType = 0; // of the future hands
  // derived
  int players = 0, seats = 0; std::vector<double> start, prizes, otherStack, otherHead; std::vector<int> seatAt;   // seatAt[p] = place of seat p in table
  double headsTotal = 0; std::string key; double work = 0;
  // The solutions of future hands are a pure function of the model's parameters and the stacks, so every study of
  // one process with the same parameters (the seeds and budgets of a --study run, for example) shares them.
  struct Solved { std::mutex lock; std::unordered_map<std::string, std::array<double, MAXT>> map; long long solves = 0, hits = 0; };
  std::shared_ptr<Solved> memo = std::make_shared<Solved>();
  static std::shared_ptr<Solved> shared(const std::string &key) {
    static std::mutex m; static std::unordered_map<std::string, std::shared_ptr<Solved>> all;
    std::lock_guard<std::mutex> g(m); auto &p = all[key]; if (!p) p = std::make_shared<Solved>(); return p;
  }
  long long solvesDone() const { std::lock_guard<std::mutex> g(memo->lock); return memo->solves; }
  bool on() const { return enabled; }
  bool bounty() const { return share > 0; }
  static double workOf(int nt, int d) { double w = 1; for (int i = 1; i < d; i++) w *= nt + 1.5 * nt * (nt - 1); return w; }
  // start: the hand-start stack of every player (study seats first); n: study seats. Returns "" or the reason.
  std::string prepare(const std::vector<double> &start_, int n, const std::vector<double> &prizes_) {
    start = start_; prizes = prizes_; players = (int)start.size(); seats = n; enabled = true;
    if (players < 2 || players > MAXN || n < 2 || n > MAXT || n > players) return "the model takes 2 to 8 study seats and at most 16 players";
    if (!bounty() && !depth) return "name \"bounty\", \"fgs\" or both";
    headsTotal = 0;
    if (bounty()) {
      if (!(share > 0 && share <= 1)) return "bounty.share must be above 0 and at most 1 (1 = knockout, 0.5 = progressive knockout)";
      if ((int)heads.size() != players) return "bounty.heads must list one bounty for every player of \"start\" (study seats first, then \"others\")";
      bool any = false; for (double h : heads) { if (!std::isfinite(h) || h < 0) return "a bounty cannot be negative"; any = any || h > 0; headsTotal += h; }
      if (!any) return "at least one bounty must be above 0";
    } else heads.assign((size_t)players, 0.0);
    seatAt.assign((size_t)n, -1); otherStack.clear(); otherHead.clear(); work = 0;
    if (depth) {
      if (depth < 1 || depth > MAX_DEPTH) return "fgs.depth must be a whole number from 1 to 6";
      const int nt = (int)table.size();
      if (nt < 2 || nt > MAXT) return "fgs.table must list 2 to 8 players (indices of \"start\") in position order";
      std::vector<char> seen((size_t)players, 0);
      for (int k = 0; k < nt; k++) { const int g = table[(size_t)k]; if (g < 0 || g >= players || seen[(size_t)g]) return "fgs.table: every entry is a different index of \"start\""; seen[(size_t)g] = 1; if (g < n) seatAt[(size_t)g] = k; }
      for (int p = 0; p < n; p++) if (seatAt[(size_t)p] < 0) return "fgs.table must contain every study seat";
      for (int g = 0; g < players; g++) if (!seen[(size_t)g]) { otherStack.push_back(start[(size_t)g]); otherHead.push_back(heads[(size_t)g]); }
      if (!(std::isfinite(sb) && std::isfinite(bb) && std::isfinite(ante) && sb >= 0 && bb > 0 && sb <= bb && ante >= 0 && ante <= 10 && bb <= 1000)) return "fgs: blinds need 0 <= smallBlind <= bigBlind, bigBlind > 0 and an ante from 0 to 10";
      work = workOf(nt, depth);
      if (work > MAX_WORK) {
        static thread_local char text[256]; int most = 1; while (most < MAX_DEPTH && workOf(nt, most + 1) <= MAX_WORK) most++;
        snprintf(text, sizeof text, "fgs.depth %d at a table of %d needs up to %.0f future-hand solutions for one outcome of the studied hand (limit %.0f): at most %d hands at this table size", depth, nt, work, MAX_WORK, most);
        return text;
      }
    } else if (!table.empty()) return "fgs.table without fgs.depth";
    char buf[64]; key = std::string(MODEL) + ";start=";
    auto num = [&](double x) { snprintf(buf, sizeof buf, "%.17g,", x); key += buf; };
    for (double s : start) num(s);
    key += ";prizes="; for (double p : prizes) num(p);
    if (bounty()) { key += ";share="; num(share); key += ";heads="; for (double h : heads) num(h); }
    if (depth) { snprintf(buf, sizeof buf, ";fgs=%d;anteType=%d;", depth, anteType); key += buf; key += "blinds="; num(sb); num(bb); num(ante); key += ";table="; for (int g : table) { snprintf(buf, sizeof buf, "%d,", g); key += buf; } }
    memo = shared(key);
    return "";
  }
  // 16 hex digits of FNV-1a over the canonical text of the model's parameters: the checkpoint header carries it
  std::string keyHash() const { uint64_t h = 1469598103934665603ULL; for (unsigned char c : key) { h ^= c; h *= 1099511628211ULL; } char b[17]; snprintf(b, sizeof b, "%016llx", (unsigned long long)h); return b; }
  std::string summary() const {
    char b[160]; std::string s;
    if (bounty()) { snprintf(b, sizeof b, "bounties (share %.3g paid at once, %.6g out)", share, headsTotal); s += b; }
    if (depth) { snprintf(b, sizeof b, "%sfuture-game simulation of %d hand%s at a table of %d", s.empty() ? "" : "; ", depth, depth > 1 ? "s" : "", (int)table.size()); s += b; }
    return s;
  }

  // V_0 for the nt table players: ICM with the bust rule, plus the pool rule. x: stacks after the hand, st: at its start.
  void base(int nt, const double *x, const double *st, const double *h, int paid, double *res) const {
    double fin[MAXN], sta[MAXN], out[MAXN]; const int no = (int)otherStack.size();
    for (int i = 0; i < nt; i++) { fin[i] = x[i]; sta[i] = st[i]; }
    for (int i = 0; i < no; i++) { fin[nt + i] = otherStack[(size_t)i]; sta[nt + i] = otherStack[(size_t)i]; }
    icmWithBusts(fin, sta, nt + no, prizes.data(), paid, out);
    for (int i = 0; i < nt; i++) res[i] = out[i];
    if (bounty()) {
      double pool = 0; for (int i = 0; i < nt; i++) if (x[i] > 1e-9) pool += h[i];
      double chips = 0; for (int i = 0; i < nt; i++) chips += x[i];
      for (int i = 0; i < no; i++) { pool += otherHead[(size_t)i]; chips += otherStack[(size_t)i]; }
      for (int i = 0; i < nt; i++) res[i] += x[i] / chips * pool;
    }
  }
  // What the next hand found: for --tour515 and the tests (never needed by training).
  struct Report { int n = 0, iterations = 0; double exploitability = 0, unit = 0; std::vector<double> jam, call, gains; std::vector<double> jamPct, callPct, foldValues, showdownValues; };
  // The next hand among m players (position order, stacks before posting, heads hh): its equilibrium values val[m].
  // false: the hand cannot be played (a player is all-in from posting). Solutions are kept (a pure function of the key).
  bool solveNext(int d, int m, const double *stacks, const double *hh, int pays, bool top, double *val, Report *rep) const {
    std::string ck; ck.resize(2 + sizeof(double) * 2 * (size_t)m);
    ck[0] = (char)(d * 2 + (top && depth == 1 ? 1 : 0)); ck[1] = (char)(pays * 16 + (m - 1)); std::memcpy(&ck[2], stacks, sizeof(double) * (size_t)m); std::memcpy(&ck[2 + sizeof(double) * (size_t)m], hh, sizeof(double) * (size_t)m);
    if (!rep) { std::lock_guard<std::mutex> g(memo->lock); auto it = memo->map.find(ck); if (it != memo->map.end()) { memo->hits++; if (std::isnan(it->second[0])) return false; std::copy_n(it->second.begin(), m, val); return true; } }
    auto inner = [&](const double *v, int w, int l, double *out) {
      double h2[MAXT], cash = 0; std::copy_n(hh, m, h2);
      if (bounty() && w >= 0 && l >= 0 && v[l] <= 1e-9) { cash = share * hh[l]; h2[w] += (1 - share) * hh[l]; h2[l] = 0; }
      value(d - 1, m, v, stacks, h2, pays, false, out);
      if (cash != 0) out[w] += cash;
    };
    PushFold<decltype(inner)> g(m, stacks, sb, bb, anteType, ante, inner);
    std::array<double, MAXT> store; store.fill(0);
    if (g.ok) {
      double unit = 0; for (int i = 0; i < pays; i++) unit += prizes[(size_t)i];
      if (bounty()) unit += headsTotal;
      g.solve(top && depth == 1 ? 120 : 60, 1e-7, unit); g.values(val); std::copy_n(val, m, store.begin());
      if (rep) {
        rep->n = m; rep->iterations = g.t; rep->unit = unit; rep->gains.assign((size_t)m, 0); rep->exploitability = g.exploitability(rep->gains.data());
        rep->foldValues = g.VF; rep->showdownValues = g.VS;   // what every outcome of this hand was worth (VF[i][p]; VS[i][j][win, lose, tie of i][p])
        rep->jam.clear(); rep->call.clear(); rep->jamPct.clear(); rep->callPct.assign((size_t)m * m, 0);
        for (int i = 0; i < m - 1; i++) { rep->jam.insert(rep->jam.end(), g.jam[(size_t)i].avg.begin(), g.jam[(size_t)i].avg.end()); rep->jamPct.push_back(g.jamPct(i)); for (int j = i + 1; j < m; j++) rep->callPct[(size_t)i * m + j] = g.callPct(i, j); }
        for (int i = 0; i < m - 1; i++) for (int j = i + 1; j < m; j++) { const auto &c = g.call[(size_t)i * m + j].avg; rep->call.insert(rep->call.end(), c.begin(), c.end()); }
      }
    } else store[0] = std::nan("");
    std::lock_guard<std::mutex> gl(memo->lock); if (memo->map.size() >= 400000) memo->map.clear(); memo->map.emplace(ck, store); memo->solves++;
    return g.ok;
  }
  // V_d for the nt table players in position order of the hand that just ended (seat nt-1 was the big blind).
  void value(int d, int nt, const double *x, const double *st, const double *h, int paid, bool top, double *res) const {
    base(nt, x, st, h, paid, res);
    if (!d) return;
    int order[MAXT], m = 0;
    for (int k = 1; k <= nt; k++) { const int p = k % nt; if (x[p] > 1e-9) order[m++] = p; }
    if (m < 2) return;
    const int left = m + (int)otherStack.size(), pays = std::min(paid, left);
    if (!bounty()) {
      bool any = false, flat = true; for (int i = 0; i < pays; i++) { any = any || prizes[(size_t)i] > 0; flat = flat && std::fabs(prizes[(size_t)i] - prizes[0]) < 1e-12; }
      if (!any || (flat && left <= pays)) return;
    }
    double stacks[MAXT], hh[MAXT], val[MAXT];
    for (int k = 0; k < m; k++) { stacks[k] = x[order[k]]; hh[k] = h[order[k]]; }
    const bool playable = solveNext(d, m, stacks, hh, pays, top, val, nullptr);
    if (playable) for (int k = 0; k < m; k++) res[order[k]] = val[k];
  }
  // The value of one outcome of the studied hand to the study seats. chips[p]: final stack of seat p (in) and its
  // value (out). won[p]: for a seat with no chips left, the seats that won the last pot it was in.
  // icmOf(chips): the plain ICM of this study (the caller's cached recursion), used when no future hand is simulated.
  template <class Icm> void evaluate(double *chips, int n, const uint32_t *won, Icm icmOf) const {
    double fin[MAXT], cash[MAXT] = {}, h[MAXT], lost = 0;
    for (int p = 0; p < n; p++) { fin[p] = chips[p]; h[p] = heads[(size_t)p]; }
    if (bounty()) for (int p = 0; p < n; p++) if (fin[p] <= 1e-9 && heads[(size_t)p] > 0) {
      const uint32_t w = won[p] & ~(1u << p); const int c = std::popcount(w);
      h[p] = 0; lost += c ? share * heads[(size_t)p] : heads[(size_t)p];   // nobody to pay: the head leaves the pool
      for (uint32_t x = w; x; x &= x - 1) { const int e = std::countr_zero(x); cash[e] += share * heads[(size_t)p] / c; h[e] += (1 - share) * heads[(size_t)p] / c; }
    }
    if (!depth) {
      icmOf(chips);
      double pool = headsTotal - lost, all = 0;   // every chip in play after the hand (dead money of the pot included)
      for (int p = 0; p < n; p++) all += fin[p];
      for (int g = n; g < players; g++) all += start[(size_t)g];
      for (int p = 0; p < n; p++) chips[p] += cash[p] + fin[p] / all * pool;
      return;
    }
    const int nt = (int)table.size(); double x[MAXT], st[MAXT], hh[MAXT], res[MAXT];
    for (int k = 0; k < nt; k++) { const int g = table[(size_t)k]; st[k] = start[(size_t)g]; x[k] = g < n ? fin[g] : start[(size_t)g]; hh[k] = g < n ? h[g] : heads[(size_t)g]; }
    value(depth, nt, x, st, hh, (int)prizes.size(), true, res);
    for (int p = 0; p < n; p++) chips[p] = res[seatAt[(size_t)p]] + cash[p];
  }
};
// For every seat without chips: the seats that won the last pot it was in (the pot with the fewest eligible seats).
// potMask(q), potAmount(q), score(seat).
template <class Mask, class Amount, class Score> inline void lastPotWinners(int n, int np, const double *chips, Mask potMask, Amount potAmount, Score score, uint32_t *won) {
  for (int p = 0; p < n; p++) {
    won[p] = 0; if (chips[p] > 1e-9) continue;
    int best = -1, size = 99;
    for (int q = 0; q < np; q++) { const uint32_t mk = potMask(q); if (!(mk >> p & 1) || !(potAmount(q) > 0)) continue; const int c = std::popcount(mk); if (c < size) { size = c; best = q; } }
    if (best < 0) continue;
    const uint32_t mk = potMask(best); bool first = true; auto top = score(0);
    for (uint32_t x = mk; x; x &= x - 1) { const int e = std::countr_zero(x); const auto v = score(e); if (first || v > top) { top = v; first = false; } }
    for (uint32_t x = mk; x; x &= x - 1) { const int e = std::countr_zero(x); if (score(e) == top) won[p] |= 1u << e; }
  }
}
// A state continues only under the payoff model and the parameters it was trained for.
inline const char *payoffMismatch(const Model &m, const char *model, const char *keyHash) {
  const bool mine = model && !std::strcmp(model, MODEL);
  if (!m.on()) return mine ? "State was trained under the tournament payoff model tour-5.15-v1 (bounties or future-game simulation; see its \"payoffModel\" header field) and cannot be continued by a study without it" : nullptr;
  if (!model) return "State was not trained under the payoff model tour-5.15-v1 of this study (its header names no \"payoffModel\")";
  if (!mine) return "State was trained under another payoff model than tour-5.15-v1";
  if (!keyHash || m.keyHash() != keyHash) return "State was trained for other bounties or another future-game simulation (the \"payoffKey\" of its header differs)";
  return nullptr;
}
}
#endif
