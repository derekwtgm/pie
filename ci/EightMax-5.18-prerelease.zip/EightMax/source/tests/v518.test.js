// EightMax 5.18 (Phase 8, bet sizes outside the tree; map-5.18-v1).
//
//   The comparisons of the release (the cost of a missing size, the three rules against each other, equal time, how
//   much results move when a size is added) are validation/5.18; these tests cover what the release adds:
//     - the mapping rule: native (map518.hpp, through mwcli --offtree) against JavaScript (EM.offTree);
//     - mwcli --translate: a strategy in its own tree is unchanged to the bit; in a tree with one more size no seat
//       gains less than before; the three rules; the file is the same every time; three seats;
//     - a translated state: evaluated, never trained; refused by the 5.17 program and by the JavaScript engine;
//     - mwcli --offtree: lines of real actions, weights, what is refused;
//     - the strategy explorer: a size the tree does not have is mapped onto the node's sizes;
//     - the games (tools/games518.js); the unchanged 5.17 program writes the same states;
//     - mwcli --selftest518; the Windows validation script of 5.18, its launchers and the workflow.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
const build = require('./native_build');
const E = require('../tools/loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river', 'lib_pushfold', 'lib_offtree', 'lib_explorer']) require('../web/' + l);
const src = path.resolve(__dirname, '..'), root = path.resolve(src, '..');
const g518 = require('../tools/games518.js');
const cli = () => process.env.EM_TEST_MWCLI || build.cli().cli;
const tmp = t => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em518-')); t.after(() => fs.rmSync(d, { recursive: true, force: true })); return d; };
const run = (args, env = {}, exe = null) => cp.spawnSync(exe || cli(), args.map(String), { encoding: 'utf8', timeout: 3600000, maxBuffer: 256 << 20, env: { ...process.env, EIGHTMAX_THREAD_CHOICE: 'fixed', ...env } });
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const write = (dir, name, value) => { const f = path.join(dir, name); fs.writeFileSync(f, typeof value === 'string' ? value : JSON.stringify(value)); return f; };
const old517 = () => process.env.EM_TEST_MWCLI_517 || path.join(root, 'validation/5.17/linux-bin/mwcli');
const cases = path.join(root, 'validation/5.18/windows/offtree');
const IDS = ['off-tree M1', 'off-tree T1', 'off-tree T2', 'off-tree T3', 'off-tree T4', 'off-tree T5', 'off-tree T6', 'off-tree T7'];
const RULES = ['nearest', 'harmonic', 'blend'];
const specOf = (dir, game, variant, grouping) => write(dir, game + (variant === 'base' ? '' : variant) + '.json', g518.spec(game, variant, grouping, 5181));
const gain = (dir, spec, state, seats = 2, fallback = 'uniform') => { const r = run(['--gain', spec, state, write(dir, 'rq.json', seats === 2 ? { method: 'exact-hu', threads: 1, fallback } : { method: 'exact', maxVisits: 2000000000, timeLimitMs: 3600000, threads: 1, fallback }), 4096]); let j = null; try { j = JSON.parse(r.stdout); } catch { /* an error text */ } return { r, j }; };
const bitsOf = j => j.seats.map(s => [s.policyValueBits, s.bestResponseValueBits, s.gainBits].join(' ')).join(' | ') + ' | ' + j.nashConvBits;
const translate = (a, state, b, out, rule) => { const r = run(['--translate', a, state, b, out, rule, 2048]); let j = null; try { j = JSON.parse(r.stdout); } catch { /* an error text */ } return { r, j }; };
const offtree = (dir, spec, request) => { const r = run(['--offtree', spec, write(dir, 'line.json', request)]); let j = null; try { j = JSON.parse(r.stdout); } catch { /* an error text */ } return { r, j }; };
const bits = v => { const b = Buffer.alloc(8); b.writeDoubleBE(v); return b.toString('hex'); };

test('5.18 the rule: nearest, harmonic and blend; the JavaScript mirror gives the doubles of the native rule', t => {
  const O = E.offTree; assert.equal(O.ID, 'map-5.18-v1'); assert.deepEqual(O.RULES, RULES);
  assert.equal(O.lowerWeight(0.5, 1, 0.5), 1); assert.equal(O.lowerWeight(0.5, 1, 1), 0); assert.ok(Math.abs(O.lowerWeight(0.5, 1, (0.5 + 1 + 2 * 0.5) / (0.5 + 1 + 2)) - 0.5) < 1e-15);
  assert.deepEqual(O.mapSize([0.5, 1], 0.74, 'nearest'), [{ index: 0, weight: 1 }]); assert.deepEqual(O.mapSize([0.5, 1], 0.74, 'harmonic'), [{ index: 1, weight: 1 }]);
  assert.deepEqual(O.mapSize([0.5, 1], 0.2, 'blend'), [{ index: 0, weight: 1 }]); assert.deepEqual(O.mapSize([0.5, 1], 3, 'blend'), [{ index: 1, weight: 1 }]); assert.deepEqual(O.mapSize([0.5, 1], 1 + 1e-10, 'nearest'), [{ index: 1, weight: 1 }]);
  const b = O.mapSize([0.33, 1], 0.66, 'blend'); assert.equal(b.length, 2); assert.ok(Math.abs(b[0].weight + b[1].weight - 1) < 1e-15); assert.deepEqual(O.mapSize([], 0.5, 'blend'), []); assert.throws(() => O.mapSize([0.5], 0.6, 'closest'), /unknown mapping rule/);
  if (!fs.existsSync(path.join(cases, 'reference.json'))) return;
  // the recorded table of the native rule, row by row
  const ref = JSON.parse(fs.readFileSync(path.join(cases, 'reference.json'), 'utf8')); assert.ok(ref.rules.length >= 150);
  for (const r of ref.rules) { const got = O.mapSize(r.sizes, r.x, r.rule); assert.deepEqual(got.map(x => [x.index, bits(x.weight)]), r.targets.map(x => [x.index, x.weightBits]), JSON.stringify(r)); }
  // and through a node: the fractions the native side computes when facing a bet
  const dir = tmp(t), spec = specOf(dir, 'ot-river', 'base', 'exact');
  for (const rule of RULES) { const { j } = offtree(dir, spec, { mapping: rule, actions: [{ pot: 0.33 }, 11] }); assert.ok(j, rule); const st = j.steps[1]; assert.equal(st.action, 'raise');
    const node = { price: 1.98, pot: 6 + 1.98, put: 0, facing: true }, js = O.mapAmount(node, st.mapped.length === 2 ? st.mapped.map(m => m.treeTo) : [st.mapped[0].treeTo], 11, rule); assert.ok(Math.abs(js.potFraction - st.potFraction) < 1e-9, rule); }
});

test('5.18 mwcli --translate: unchanged in its own tree; with a size added no seat gains less; the three rules; the same file every time', { timeout: 3600000 }, t => {
  const dir = tmp(t), A = specOf(dir, 'ot-river', 'base', 'exact'), st = path.join(dir, 'a.state'); assert.equal(run([A, 300000, 1, st, 1024]).status, 0);
  const own = gain(dir, A, st).j, ownCc = gain(dir, A, st, 2, 'callCheck').j; assert.ok(own && ownCc);
  for (const rule of RULES) { const out = path.join(dir, 'id.state'), tr = translate(A, st, A, out, rule); assert.equal(tr.r.status, 0, tr.r.stderr); assert.equal(tr.j.algorithm, 'map-5.18-v1'); assert.equal(tr.j.mapping, rule); assert.equal(tr.j.actionsOutsideTheSourceTree, 0); assert.equal(tr.j.loadsAsAStateOfTheTargetStudy, true);
    assert.equal(bitsOf(gain(dir, A, out).j), bitsOf(own), 'its own tree, ' + rule); }
  const nc = {};
  for (const variant of ['+66', '+200', '+15', '+r50']) { const B = specOf(dir, 'ot-river', variant, 'exact'); nc[variant] = {};
    for (const rule of RULES) { const out = path.join(dir, 'b.state'), tr = translate(A, st, B, out, rule); assert.equal(tr.r.status, 0, tr.r.stderr); assert.ok(tr.j.actionsOutsideTheSourceTree > 0); assert.ok(tr.j.states > tr.j.sourceStates);
      const first = sha(out); assert.equal(translate(A, st, B, out, rule).r.status, 0); assert.equal(sha(out), first, 'the same file: ' + variant + ' ' + rule);
      const g = gain(dir, B, out).j, c = gain(dir, B, out, 2, 'callCheck').j; assert.ok(g && c); nc[variant][rule] = g.nashConv;
      for (const p of [0, 1]) { assert.ok(c.seats[p].gain >= ownCc.seats[p].gain - 1e-9, variant + ' ' + rule + ' seat ' + p); assert.ok(Math.abs(c.seats[p].policyValue - ownCc.seats[p].policyValue) <= 1e-9 * Math.max(1, Math.abs(ownCc.seats[p].policyValue))); }
      const info = JSON.parse(run(['--state-info', out]).stdout).state.header; assert.equal(info.translated, 'map-5.18-v1'); assert.equal(info.mapping, rule); assert.match(info.studyId, /^t518-[0-9a-f]{16}$/); assert.equal(info.translatedFrom, JSON.parse(fs.readFileSync(A, 'utf8')).studyId); } }
  // between two sizes the rules give different strategies; outside the tree's sizes they give the same one
  assert.notEqual(nc['+66'].blend, nc['+66'].nearest); assert.notEqual(nc['+66'].harmonic, nc['+66'].nearest);
  for (const v of ['+200', '+15']) { assert.equal(nc[v].nearest, nc[v].harmonic); assert.equal(nc[v].blend, nc[v].harmonic); }
});

test('5.18 a translated state: evaluated, never trained; refused by the 5.17 program and by the JavaScript engine; what --translate refuses', { timeout: 3600000 }, t => {
  const dir = tmp(t), A = specOf(dir, 'ot-river', 'base', 'exact'), B = specOf(dir, 'ot-river', '+66', 'exact'), st = path.join(dir, 'a.state'), out = path.join(dir, 'b.state'); assert.equal(run([A, 50000, 1, st, 1024]).status, 0);
  assert.equal(translate(A, st, B, out, 'harmonic').r.status, 0);
  const more = path.join(dir, 'more.state'), r = run([B, 100, 1, more, 1024, out]); assert.notEqual(r.status, 0); assert.match(r.stderr, /translated from another study/); assert.ok(!fs.existsSync(more));
  { const x = run(['--node', B, out, write(dir, 'q.json', { path: [], limit: 10 }), 1024]); assert.equal(x.status, 0, x.stderr); const e = run(['--ev', B, out, write(dir, 'q.json', { path: [], hands: [0, 1] }), 1024]); assert.equal(e.status, 0, e.stderr); }
  assert.notEqual(gain(dir, A, out).r.status, 0); assert.match(gain(dir, A, out).r.stderr, /different study/);
  assert.match(translate(B, out, B, path.join(dir, 'c.state'), 'harmonic').r.stderr, /itself a translated state/); assert.match(translate(A, st, B, path.join(dir, 'c.state'), 'closest').r.stderr, /unknown mapping rule/);
  const T = specOf(dir, 'ot-turn', 'base', 'ranked'); assert.match(translate(A, st, T, path.join(dir, 'c.state'), 'harmonic').r.stderr, /differ/); assert.ok(!fs.existsSync(path.join(dir, 'c.state')) && !fs.existsSync(path.join(dir, 'c.state.tmp')));
  const C = write(dir, 'compact.json', g518.spec('ot-river', '+66', 'compact', 5181)); assert.match(translate(A, st, C, path.join(dir, 'c.state'), 'harmonic').r.stderr, /different ranges or hand groupings/);
  { const Ts = path.join(dir, 't.state'); assert.equal(run([T, 5000, 1, Ts, 1024]).status, 0); const Tc = write(dir, 'turn-compact.json', g518.spec('ot-turn', '+t33', 'compact', 5181)); assert.match(translate(T, Ts, Tc, path.join(dir, 'c.state'), 'harmonic').r.stderr, /different hand groupings/); }
  const raw = fs.readFileSync(out), at = raw.indexOf('"mapping":"harmonic"'); assert.ok(at > 0); const bad = Buffer.from(raw); bad.write('"mapping":"nearest" ', at, 'latin1'); const altered = write(dir, 'altered.state', ''); fs.writeFileSync(altered, bad);
  const g = gain(dir, B, altered); assert.notEqual(g.r.status, 0);
  if (fs.existsSync(old517())) { const old = path.join(os.tmpdir(), 'em518-mwcli517-' + process.pid); fs.copyFileSync(old517(), old); fs.chmodSync(old, 0o755); t.after(() => fs.rmSync(old, { force: true }));
    const o = run(['--gain', B, out, write(dir, 'rq.json', { method: 'exact-hu' }), 1024], {}, old); assert.notEqual(o.status, 0); assert.match(o.stderr, /different study/);
    const o2 = run([B, 100, 1, more, 1024, out], {}, old); assert.notEqual(o2.status, 0); assert.ok(!fs.existsSync(more)); }
  const js = fs.readFileSync(path.join(src, 'web/lib_wide.js'), 'utf8'); assert.ok(js.includes("if(head.translated)throw Error('This state was translated from another study"));
});

test('5.18 mwcli --translate with three seats: every seat gains at least what it gained in the source tree (method exact)', { timeout: 3600000 }, t => {
  const dir = tmp(t), A = specOf(dir, 'ot-turn3', 'base', 'exact'), st = path.join(dir, 'a.state'); assert.equal(run([A, 60000, 1, st, 1024]).status, 0);
  const own = gain(dir, A, st, 3, 'callCheck').j; assert.ok(own); assert.equal(own.seats.length, 3);
  for (const [variant, rule] of [['+t100', 'nearest'], ['+t100', 'blend'], ['+r33', 'harmonic']]) { const B = specOf(dir, 'ot-turn3', variant, 'exact'), out = path.join(dir, 'b.state'); assert.equal(translate(A, st, B, out, rule).r.status, 0);
    const g = gain(dir, B, out, 3, 'callCheck').j; assert.ok(g, variant); for (const p of [0, 1, 2]) assert.ok(g.seats[p].gain >= own.seats[p].gain - 1e-9 * Math.max(1, own.seats[p].gain), variant + ' ' + rule + ' seat ' + p); }
});

test('5.18 mwcli --offtree: lines of real actions onto the tree; weights; what is refused', t => {
  const dir = tmp(t), spec = specOf(dir, 'ot-river', 'base', 'exact');
  const a = offtree(dir, spec, { mapping: 'blend', actions: ['check', { pot: 0.66 }, 12, 'call'] }).j; assert.ok(a); assert.equal(a.algorithm, 'map-5.18-v1'); assert.equal(a.steps.length, 4); assert.equal(a.real.over, true); assert.equal(a.real.pot, 30);
  assert.deepEqual(a.tree.map(x => x.path), ['0121', '0221']); assert.ok(Math.abs(a.tree[0].weight + a.tree[1].weight - 1) < 1e-12); assert.equal(a.weightWithoutATreeNode, 0); assert.equal(a.steps[1].mapped[0].inTree, false); assert.equal(a.steps[0].mapped[0].inTree, true);
  assert.equal(a.tree[0].weight, E.offTree.mapSize([0.33, 1], a.steps[1].potFraction, 'blend')[0].weight);
  const inTree = offtree(dir, spec, { actions: [{ pot: 0.33 }, 'call'] }).j; assert.equal(inTree.mapping, 'blend'); assert.equal(inTree.steps[0].mapped[0].inTree, true); assert.deepEqual(inTree.tree.map(x => x.path), ['11']);
  const byAmount = offtree(dir, spec, { actions: [{ to: 1.98 }, 'call'] }).j; assert.deepEqual(byAmount.tree, inTree.tree);
  for (const [actions, why] of [[['fold'], /no bet to fold to/], [['call'], /no bet/], [[{ pot: 0.33 }, 'check'], /there is a bet/], [[25], /exceed the stack/], [[0.5], /minimum raise/], [[{ pot: 0.33 }, 2.5], /minimum raise/], [['check', 'check', 'check'], /hand is over/], [['next'], /not over/], [[{ size: 3 }], /an action is/]]) {
    const r = offtree(dir, spec, { actions }).r; assert.notEqual(r.status, 0, JSON.stringify(actions)); assert.match(r.stderr, why); }
  assert.match(offtree(dir, spec, { mapping: 'closest', actions: [] }).r.stderr, /unknown mapping rule/);
  const turn = specOf(dir, 'ot-turn', 'base', 'ranked'), l = offtree(dir, turn, { actions: [{ pot: 1.5 }, 'call', 'next', 'check', { pot: 0.4 }, 'fold'] }).j; assert.ok(l); assert.equal(l.real.over, true); assert.equal(l.tree.length, 1); assert.ok(l.tree[0].path.includes('7'));
});

test('5.18 the strategy explorer: a size the tree does not have is mapped onto the sizes of the node', { timeout: 600000 }, t => {
  const dir = tmp(t), spec = specOf(dir, 'ot-river', 'base', 'exact'), st = path.join(dir, 'a.state'); assert.equal(run([spec, 20000, 1, st, 1024]).status, 0);
  const node = p => JSON.parse(run(['--node', spec, st, write(dir, 'q.json', { path: p, limit: 1326 }), 1024]).stdout);
  for (const p of [[], [1]]) { const r = node(p), n = r.node, sized = r.actions.filter(a => a.to > n.price + 1e-8), to = p.length ? 11 : 3.96;
    const res = E.offTree.mapAmount({ price: n.price, pot: n.pot, put: n.streetPut[n.actor], facing: n.facing }, sized.map(a => a.to), to, 'blend');
    const native = offtree(dir, spec, { mapping: 'blend', actions: [...(p.length ? [{ pot: 0.33 }] : []), to] }).j.steps[p.length];
    assert.ok(Math.abs(res.potFraction - native.potFraction) < 1e-9); assert.deepEqual(res.targets.map(x => x.to), native.mapped.map(x => x.treeTo)); for (let i = 0; i < res.targets.length; i++) assert.ok(Math.abs(res.targets[i].weight - native.mapped[i].weight) < 1e-12);
    const plain = E.renderExplorer(r, { kind: 'average' }); assert.ok(plain.includes('id="ex-offtree-to"') && plain.includes('data-ex-offtree="1"') && plain.includes('id="ex-offtree-rule"'));
    const html = E.renderExplorer(r, { kind: 'average', offTree: { to, rule: 'blend', result: res } }); assert.ok(html.includes('is taken as')); for (const x of res.targets) assert.ok(html.includes('data-ex-action="' + sized[x.index].slot + '"')); assert.ok(html.includes('map-5.18-v1'));
    assert.ok(E.renderExplorer(r, { kind: 'average', offTree: { to: 0, rule: 'harmonic', error: 'The amount must exceed the price to call (0).' } }).includes('must exceed the price')); }
  const ui = fs.readFileSync(path.join(src, 'web/lib_river_ui.js'), 'utf8'); for (const s of ['d.exOfftree!==undefined', 'EM.offTree.mapAmount(', 'explorer.offTree=null']) assert.ok(ui.includes(s), s);
});

test('5.18 the games: a variant differs from its base in one list of sizes, and the 5.17 program trains the same states', { timeout: 3600000 }, t => {
  assert.deepEqual(Object.keys(g518.GAMES), ['ot-river', 'ot-turn', 'ot-flop', 'ot-turn2', 'ot-turn3']); assert.equal(Object.values(g518.GAMES).filter(g => !g.seats && !g.supplement).reduce((n, g) => n + g.variants.length, 0), 12);
  for (const [key, g] of Object.entries(g518.GAMES)) { const base = g518.spec(key, 'base', g.grouping, 5181);
    for (const v of g.variants) { const s = g518.spec(key, v[0], g.grouping, 5181); assert.notEqual(s.studyId, base.studyId); const a = JSON.parse(JSON.stringify(s)), b = JSON.parse(JSON.stringify(base)); delete a.studyId; delete b.studyId; assert.notDeepEqual(a.rules.sizes, b.rules.sizes); a.rules.sizes = b.rules.sizes = null; assert.deepEqual(a, b, key + v[0]);
      const st = { river: '5', turn: '4', flop: '3' }[v[1]], la = s.rules.sizes[st][v[2]], lb = base.rules.sizes[st][v[2]]; assert.equal(la.length, lb.length + 1); assert.ok(la.some(x => x[0] === 2 && Math.abs(x[1] * 100 - parseFloat(v[3])) < 1e-9)); } }
  if (!fs.existsSync(old517())) { t.diagnostic('validation/5.17/linux-bin/mwcli is not in this tree'); return; }
  const old = path.join(os.tmpdir(), 'em518-mwcli517b-' + process.pid); fs.copyFileSync(old517(), old); fs.chmodSync(old, 0o755); t.after(() => fs.rmSync(old, { force: true })); const dir = tmp(t);
  for (const [key, variant] of [['ot-river', '+66'], ['ot-turn', 'base'], ['ot-flop', '+f100'], ['ot-turn3', '+t100']]) { const spec = specOf(dir, key, variant, g518.GAMES[key].grouping), a = path.join(dir, 'a.state'), b = path.join(dir, 'b.state');
    assert.equal(run([spec, 20000, 1, a, 1024]).status, 0); assert.equal(run([spec, 20000, 1, b, 1024], {}, old).status, 0); assert.equal(sha(a), sha(b), key + variant); }
});

test('5.18 mwcli --selftest518: every check passes; usage', { timeout: 7200000 }, t => {
  if (!fs.existsSync(path.join(cases, 'reference.json'))) { t.skip('validation/5.18/windows/offtree is not in this tree'); return; }
  const dir = tmp(t), r = run(['--selftest518', cases, dir, 'all']); assert.equal(r.status, 0, r.stdout + r.stderr);
  const rep = JSON.parse(fs.readFileSync(path.join(dir, 'selftest518.json'), 'utf8')); assert.equal(rep.algorithm, 'map-5.18-v1'); assert.equal(rep.failed, 0); assert.equal(rep.untested, 0); assert.equal(rep.passed, IDS.length);
  assert.deepEqual(rep.checks.map(c => c.section + ' ' + c.id), IDS); for (const c of rep.checks) assert.equal(c.status, 'passed', c.id + ': ' + c.detail);
  assert.equal(run(['--selftest518', cases]).status, 2); assert.equal(run(['--selftest518', cases, dir, 'nothing']).status, 2); assert.equal(run(['--selftest518', dir, dir]).status, 2);
});

test('5.18 Windows validation: the script keeps every section of the 5.17 script, plans and imports every 5.18 check, the launchers run the self-tests first, the reference files are complete', () => {
  const file = path.join(src, 'tools/validate_windows518.ps1'), ps = fs.readFileSync(file, 'utf8'), version = fs.readFileSync(path.join(src, 'VERSION'), 'utf8').trim();
  assert.equal(version, '5.18'); assert.match(ps, /\$Release = '5\.18'/); assert.match(ps, /tool = 'validate_windows518\.ps1'/); assert.ok(!/[^\x00-\x7f]/.test(ps), 'the script is ASCII');
  for (const s of ["Run-Section 'self-test 5.18'", "Run-Section 'self-test 5.17'", "Run-Section 'exact best response 5.17'", "Run-Section 'GPU'", "'--selftest518', $cases, $dir, 'all'", "'validation\\5.18\\windows\\offtree'", "'off-tree' = 'off-tree 5.18 (self-test)'"]) assert.ok(ps.includes(s), s);
  for (const id of IDS) assert.ok(ps.includes("'" + id + "'"), 'expected check ' + id);
  const plans = [...ps.matchAll(/^Plan '([^']+)' '([^']+)' '([^']+)'/gm)];
  for (const name of ['mwcli --selftest518 ran and wrote its report', 'every expected 5.18 check is in the report', 'the 5.18 report agrees with the exit status of mwcli']) {
    assert.equal(plans.filter(p => p[2] === name).length, 1, 'planned once: ' + name); const sec = plans.find(p => p[2] === name)[1]; assert.equal(sec, 'self-test 5.18'); assert.ok(ps.includes("Check '" + sec + "' '" + name + "'"), 'planned but never recorded: ' + name); }
  const focus = /\$focusSections = @\(([^)]*)\)/.exec(ps)[1]; for (const s of ["'self-test 5.18'", "'self-test 5.17'", "'exact best response 5.17'", "'golden states'", "'integrity'"]) assert.ok(focus.includes(s), 'focused: ' + s);
  const sections = text => [...text.matchAll(/^Run-Section '([^']+)'/gm)].map(m => m[1]), before = sections(fs.readFileSync(path.join(src, 'tools/validate_windows517.ps1'), 'utf8')), now = sections(ps);
  assert.deepEqual(now.filter(s => before.includes(s)), before); assert.deepEqual(now.filter(s => !before.includes(s)), ['self-test 5.18']); assert.equal(now.length, 34);
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (py) { const r = cp.spawnSync(py, [path.join(src, 'tools/ps_lint571.py'), file], { encoding: 'utf8' }); assert.equal(r.status, 0, r.stdout + r.stderr); }
  for (const [name, needs] of [['Run 5.18 Windows validation.bat', ['mwcli.exe --selftest57 ', 'mwcli.exe --selftest517 "validation\\5.17\\windows\\brhu" "studies"', 'mwcli.exe --selftest518 "validation\\5.18\\windows\\offtree"', 'validate_windows518.ps1" %*', 'Windows-selftest518-5.18.json', 'Windows-validation-5.18.json', 'Step 14 of 14', 'if not "%selftest518_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"']],
    ['Run 5.18 focused validation.bat', ['mwcli.exe --selftest518 "validation\\5.18\\windows\\offtree"', 'validate_windows518.ps1" -Focused %*', 'Windows-focused-validation-5.18.json', 'Windows-selftest518-5.18.json']]]) {
    const f = path.join(root, name); if (!fs.existsSync(f)) continue;
    const text = fs.readFileSync(f).toString('latin1'); assert.ok(!/[^\x00-\x7f]/.test(text), name + ' is ASCII'); assert.ok(!/[^\r]\n/.test(text), name + ' has CRLF line ends'); for (const n of needs) assert.ok(text.includes(n), name + ': ' + n); assert.match(text, /exit \/b %\w+%\r\n$/);
    assert.ok(!text.includes('-5.17.json') && !text.includes('validate_windows517'), name + ' writes 5.18 reports only');
  }
  if (fs.existsSync(cases)) { const ref = JSON.parse(fs.readFileSync(path.join(cases, 'reference.json'), 'utf8')); assert.equal(ref.algorithm, 'map-5.18-v1'); assert.equal(ref.bases.length, 4); assert.equal(ref.translations.length, 15); assert.ok(ref.lines.length >= 12);
    for (const c of [...ref.bases, ...ref.translations]) { assert.ok(fs.existsSync(path.join(cases, c.spec)), c.spec); assert.match(c.stateSha256, /^[0-9a-f]{64}$/); assert.match(c.nashConvBits, /^[0-9a-f]{16}$/); for (const s of c.seats) for (const k of ['policyValueBits', 'bestResponseValueBits', 'gainBits']) assert.match(s[k], /^[0-9a-f]{16}$/); }
    for (const rule of RULES) assert.ok(ref.translations.some(c => c.rule === rule)); assert.ok(ref.bases.some(b => b.seatCount === 3)); for (const l of ref.lines) { const w = l.tree.reduce((s, x) => s + x.weight, 0); assert.ok(l.tree.length >= 1 && w > 0 && w <= 1 + 1e-12, l.name); } assert.ok(ref.lines.filter(l => Math.abs(l.tree.reduce((s, x) => s + x.weight, 0) - 1) < 1e-12).length >= 10); }
  const wf = path.join(root, '.github/workflows/windows.yml'); if (fs.existsSync(wf)) { const y = fs.readFileSync(wf, 'utf8'); for (const s of ['--selftest518 validation/5.18/windows/offtree', 'validate_windows518.ps1 -Root', 'Windows-validation-5.18.json', 'windows-selftest518.json', 'source/tests/v518.test.js']) assert.ok(y.includes(s), 'workflow: ' + s); }
});
