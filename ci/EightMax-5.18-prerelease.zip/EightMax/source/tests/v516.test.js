// EightMax 5.16 (Phase 6, card-grouping error).
//
//   The measurement itself (Compact, Detailed and Exact cards on the same games, in exact NashConv and in strategy)
//   is validation/5.16; these tests cover what the release adds to the program:
//     - the Ranked hand grouping ranked-5.16-v1: training, the state header, continuation, threads, refusals, the
//       explorer and the exact evaluation; the JavaScript mirror writes the tables of the native engine;
//     - the key itself, recomputed here from its definition on a river game;
//     - the games of the measurement (tools/games516.js): only the grouping differs between the versions of a game;
//     - the unchanged 5.15 program refuses a Ranked study and writes the same states as 5.16 for Compact, Detailed and
//       Exact cards;
//     - mwcli --selftest516; the Windows validation script of 5.16, its launchers and the workflow.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
const build = require('./native_build');
const src = path.resolve(__dirname, '..'), root = path.resolve(src, '..'), studies = path.join(src, 'studies');
const EM = require('../tools/loadlib.js'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river', 'lib_river_ui']) require('../web/' + l);
const g516 = require('../tools/games516.js'), g510 = require('../tools/games510.js');
const cli = () => process.env.EM_TEST_MWCLI || build.cli().cli;
const tmp = t => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em516-')); t.after(() => fs.rmSync(d, { recursive: true, force: true })); return d; };
const run = (args, env = {}, exe = null) => cp.spawnSync(exe || cli(), args.map(String), { encoding: 'utf8', timeout: 1800000, maxBuffer: 256 << 20, env: { ...process.env, ...env } });
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const fixture = id => JSON.parse(fs.readFileSync(path.join(studies, id + '.emfix.json'), 'utf8').replace(/^﻿/, ''));
const specOf = (id, extra = {}) => ({ ...fixture(id).variants[0].nativeSpec, ...extra });
const regroup = (spec, grouping) => ({ ...spec, abstraction: grouping, groupKeys: { ...spec.groupKeys, abstraction: grouping } });
const write = (dir, name, spec) => { const f = path.join(dir, name); fs.writeFileSync(f, JSON.stringify(spec)); return f; };
const header = f => fs.readFileSync(f).subarray(0, 900).toString('latin1');
const old515 = () => process.env.EM_TEST_MWCLI_515 || path.join(root, 'validation/5.15/linux-bin/mwcli');
const IDS = ['training T1', 'training T2', 'training T3', 'checkpoint C1', 'checkpoint C2', 'checkpoint C3'];

test('5.16 Ranked grouping in the engine: training, the header, continuation, threads, refusals and the explorer', { timeout: 1800000 }, t => {
  const dir = tmp(t), st = n => path.join(dir, n + '.state'), base = specOf('flop3-kings');
  const rk = write(dir, 'ranked.json', regroup(base, 'ranked')), cpn = write(dir, 'compact.json', base), dt = write(dir, 'detailed.json', regroup(base, 'detailed'));
  const a = run([rk, 3000, 1, st('a')]); assert.equal(a.status, 0, a.stderr); const info = JSON.parse(a.stdout); assert.equal(info.handGroups.abstraction, 'ranked'); assert.ok(info.handGroups.keys > 0);
  assert.ok(header(st('a')).includes('"grouping":"ranked-5.16-v1"')); assert.ok(header(st('a')).includes('"rowKeys":2'));
  const p1 = run([rk, 1000, 1, st('p1')]), p2 = run([rk, 2000, 1, st('p2'), 512, st('p1')]); assert.equal(p1.status + p2.status, 0, p2.stderr); assert.equal(sha(st('p2')), sha(st('a')));
  const batch = { batchDeals: 16, actionStreams: 'deal' }, rb = write(dir, 'ranked-batch.json', regroup(specOf('flop3-kings', batch), 'ranked'));
  const hashes = [1, 2, 4].map(n => { const r = run([rb, 100, n, st('t' + n)], { EIGHTMAX_THREAD_CHOICE: 'fixed' }); assert.equal(r.status, 0, r.stderr); return sha(st('t' + n)); }); assert.equal(new Set(hashes).size, 1);
  const c = run([cpn, 3000, 1, st('c')]), d = run([dt, 3000, 1, st('d')]); assert.equal(c.status + d.status, 0); assert.ok(!header(st('c')).includes('"grouping"') && !header(st('d')).includes('"grouping"'));
  const rows = [c, a, d].map(r => JSON.parse(r.stdout).rows); assert.ok(rows[0] < rows[1] && rows[1] < rows[2], 'rows compact < ranked < detailed: ' + rows);
  for (const [spec, input, want] of [[cpn, 'a', /hand grouping this study does not use/], [rk, 'c', /not trained with the Ranked grouping ranked-5\.16-v1/], [dt, 'a', /./], [rk, 'd', /./]]) {
    const r = run([spec, 5, 1, st('no'), 512, st(input)]); assert.equal(r.status, 1, r.stdout); assert.match(r.stderr, want); assert.ok(!fs.existsSync(st('no'))); }
  // refused specs: before the flop; an unknown name
  const pre = write(dir, 'pre.json', regroup(specOf('btn25-open'), 'ranked')), r1 = run([pre, 5, 1, st('pre')]); assert.equal(r1.status, 1); assert.match(r1.stderr, /starts on the flop, turn or river/); assert.ok(!fs.existsSync(st('pre')));
  const unk = write(dir, 'unk.json', regroup(base, 'rankedx')), r2 = run([unk, 5, 1, st('unk')]); assert.equal(r2.status, 1); assert.match(r2.stderr, /Compact, Detailed or Ranked/);
  assert.throws(() => EM.MultiwayGame({ ...g510.base, preflop: { mode: 'shove' }, dealt: 4, common: 0, board: '', stacks: [12, 7, 20, 4], ranges: ['AA', 'KK', 'QQ', 'JJ'], abstraction: 'ranked', privateMode: 'sampled', traversal: 'external' }), /Ranked grouping needs a study that starts on the flop, turn or river|ranked/i);
  // the explorer names the grouping and gives hands of equal strength in a seat's range one row
  const nq = write(dir, 'node.json', { path: [] }), nr = run(['--node', rk, st('a'), nq]); assert.equal(nr.status, 0, nr.stderr); const node = JSON.parse(nr.stdout); assert.equal(node.study.abstraction, 'ranked groups');
  const items = node.hands.items, board = base.board, byScore = new Map();
  for (const h of items) { const s = EM.evalCards([...board, ...h.cards]); const cards = [...board, ...h.cards], suits = [0, 0, 0, 0]; for (const x of cards) suits[x & 3]++; const k = s + ':' + suits.includes(4); if (!byScore.has(k)) byScore.set(k, new Set()); byScore.get(k).add(JSON.stringify(h.average)); }
  assert.ok(items.length > 100); let shared = 0; for (const set of byScore.values()) if (set.size === 1) shared++; assert.ok(shared / byScore.size > 0.8, 'hands of one strength share a row in most cases: ' + shared + ' of ' + byScore.size);
});

test('5.16 the Ranked key, recomputed from its definition: on a river every hand of a seat is grouped with the hands of its strength bucket and no other', () => {
  for (const key of ['rg-hu-river', 'rg-river3', 'ho-hu-river']) {
    const s = g516.spec(key, 'ranked', 5161); assert.ok(Array.isArray(s.riverGroups) && s.abstraction === 'ranked');
    s.hands.forEach((range, p) => {
      const scores = range.map(h => EM.evalCards([...s.board, h[1], h[2]])), d = [...new Set(scores)].sort((a, b) => a - b), D = d.length;
      const bucket = scores.map(x => D <= 16 ? d.indexOf(x) : Math.floor(d.indexOf(x) * 16 / D)), rep = s.riverGroups[p];
      const small = range.length <= 12;
      for (let i = 0; i < range.length; i++) for (let j = 0; j < i; j++) assert.equal(rep[i] === rep[j], small ? false : bucket[i] === bucket[j], key + ' seat ' + p + ' hands ' + i + ',' + j);
    });
  }
});

test('5.16 the games of the measurement: four groupings of every game, and only the grouping differs', () => {
  assert.deepEqual(g516.GROUPINGS, ['compact', 'detailed', 'ranked', 'exact']); assert.equal(g516.KEYS.length, 8); assert.deepEqual(g516.HELD_OUT, ['ho-hu-river', 'ho-hu-turn']);
  const strip = s => { const { abstraction, groupKeys, riverGroups, turnGroups, studyId, ...rest } = s; return JSON.stringify(rest); };
  for (const key of [...g516.KEYS, ...g516.HELD_OUT]) {
    const specs = g516.GROUPINGS.map(a => g516.spec(key, a, 5161)); for (const s of specs) assert.equal(strip(s), strip(specs[3]), key);
    assert.equal(new Set(specs.map(s => s.studyId)).size, 4, key + ': four study identifiers'); assert.ok(!('abstraction' in specs[3]));
    const kind = specs[0].board.length === 5 ? 'riverGroups' : specs[0].turnGroups ? 'turnGroups' : 'groupKeys'; for (const s of specs.slice(0, 3)) assert.ok(kind in s, key + ' ' + s.abstraction);
  }
  // the Exact-cards version of a 5.10 game is that game
  assert.equal(g516.spec('rg-hu-river', 'exact', 7).studyId, g510.spec('rg-hu-river', 7).studyId);
  const plan = JSON.parse(fs.readFileSync(path.join(root, 'validation/5.16/plan.json'), 'utf8')); assert.deepEqual(plan.games, g516.KEYS); assert.deepEqual(plan.seeds, [5161, 5162, 5163, 5164, 5165]); assert.equal(plan.budgetsDeals.at(-1), 10000000);
});

test('5.16 the JavaScript engine and the native engine write the same Ranked tables, and each continues the other\'s state (short set)', { timeout: 1800000 }, t => {
  const dir = tmp(t), r = cp.spawnSync(process.execPath, [path.join(src, 'tools/grouped516.js'), cli(), path.join(dir, 'out.json'), '--quick'], { encoding: 'utf8', timeout: 1800000 });
  assert.equal(r.status, 0, r.stdout + r.stderr); const out = JSON.parse(fs.readFileSync(path.join(dir, 'out.json'), 'utf8')); assert.equal(out.failed, 0); assert.equal(out.configs.length, 3);
  for (const c of out.configs) for (const x of c.runs) assert.ok(x.identicalTables && x.nativeStateLoadsInJavaScript && x.javaScriptStateLoadsNatively && x.headersNameTheGrouping && x.rows > 100);
});

test('5.16 against the unchanged 5.15 program: it refuses a Ranked study, and Compact, Detailed and Exact cards train to the same bytes', { timeout: 1800000 }, t => {
  const old = old515(); if (!fs.existsSync(old)) { t.diagnostic('no 5.15 mwcli at ' + old + ': the comparison with 5.15 was not run'); return; }
  const dir = tmp(t), st = n => path.join(dir, n + '.state'), base = specOf('flop3-kings');
  const rk = write(dir, 'ranked.json', regroup(base, 'ranked')), o1 = run([rk, 5, 1, st('o1')], {}, old); assert.equal(o1.status, 1); assert.match(o1.stderr, /Compact or Detailed/); assert.ok(!fs.existsSync(st('o1')));
  const batch = { batchDeals: 16, actionStreams: 'deal' };
  const cases = [['compact', base, 3000, 1], ['detailed', regroup(base, 'detailed'), 3000, 1], ['compact batch', specOf('flop3-kings', batch), 150, 3], ['detailed batch philox', regroup(specOf('flop3-kings', { ...batch, trainingStreams: 'philox64' }), 'detailed'), 150, 2],
    ['six seats compact', specOf('flop6-jack'), 3000, 1], ['preflop compact', specOf('btn25-open'), 2000, 1], ['exact', specOf('flop3-kings-small'), 3000, 1], ['exact rbes batch', specOf('flop6-jack-small', { estimator: 'rbes', ...batch }), 100, 2],
    ['river map compact', g516.spec('rg-hu-river', 'compact', 3), 20000, 1], ['turn map detailed', g516.spec('rg-hu-turn', 'detailed', 3), 20000, 1], ['bounties', fixture('pko6-bb-call-small').variants[0].nativeSpec, 3000, 1]];
  for (const [name, spec, updates, threads] of cases) {
    const f = write(dir, 'same.json', spec), n = run([f, updates, threads, st('new')], { EIGHTMAX_THREAD_CHOICE: 'fixed' }), o = run([f, updates, threads, st('old')], { EIGHTMAX_THREAD_CHOICE: 'fixed' }, old);
    assert.equal(n.status + o.status, 0, name + ': ' + n.stderr + o.stderr); assert.equal(sha(st('new')), sha(st('old')), name + ': 5.16 and 5.15 write different states'); }
  // a Ranked study through a representative map (river, small turn) is a map like any other: 5.15 trains it to the same bytes
  const m = write(dir, 'map.json', g516.spec('rg-hu-river', 'ranked', 3)), n = run([m, 20000, 1, st('mn')]), o = run([m, 20000, 1, st('mo')], {}, old); assert.equal(n.status + o.status, 0, n.stderr + o.stderr); assert.equal(sha(st('mn')), sha(st('mo')));
});

test('5.16 mwcli --selftest516: every check passes; sections and usage', { timeout: 3600000 }, t => {
  const dir = tmp(t), r = run(['--selftest516', studies, dir, 'all']); assert.equal(r.status, 0, r.stdout + r.stderr);
  const rep = JSON.parse(fs.readFileSync(path.join(dir, 'selftest516.json'), 'utf8')); assert.equal(rep.grouping, 'ranked-5.16-v1'); assert.equal(rep.failed, 0); assert.equal(rep.untested, 0);
  assert.deepEqual(rep.checks.map(c => c.section + ' ' + c.id), IDS); for (const c of rep.checks) assert.equal(c.status, 'passed', c.id + ': ' + c.detail);
  assert.equal(run(['--selftest516', studies, dir, 'checkpoint']).status, 0); assert.equal(run(['--selftest516', studies]).status, 2); assert.equal(run(['--selftest516', studies, dir, 'nothing']).status, 2);
});

test('5.16 Windows validation: the script keeps every section of the 5.15 script, plans and imports every 5.16 check, the launchers run the self-tests first, the reference files are complete', () => {
  const file = path.join(src, 'tools/validate_windows516.ps1'), ps = fs.readFileSync(file, 'utf8'), version = fs.readFileSync(path.join(src, 'VERSION'), 'utf8').trim();
  assert.ok(['5.16', '5.17', '5.18'].includes(version), version); assert.match(ps, /\$Release = '5\.16'/);   // 5.17: the 5.16 script is kept as it ran; validate_windows517.ps1 is the current one
  assert.match(ps, /tool = 'validate_windows516\.ps1'/); assert.ok(!/[^\x00-\x7f]/.test(ps), 'the script is ASCII'); assert.ok(ps.includes('$count -gt 1000'));
  for (const s of ["Run-Section 'self-test 5.16'", "Run-Section 'grouping 5.16'", "Run-Section 'self-test 5.15'", "Run-Section 'tournament 5.15'", "Run-Section 'GPU'", "'--selftest516', $studies, $dir, 'all'", "$i.handGroups.abstraction"]) assert.ok(ps.includes(s), s);
  for (const id of IDS) assert.ok(ps.includes("'" + id + "'"), 'expected check ' + id);
  const plans = [...ps.matchAll(/^Plan '([^']+)' '([^']+)' '([^']+)'/gm)];
  for (const name of ['mwcli --selftest516 ran and wrote its report', 'every expected 5.16 check is in the report', 'the 5.16 report agrees with the exit status of mwcli', 'the interface file offers the Ranked grouping', 'identical Ranked state for every thread count', 'Ranked state equals the Linux build', 'Ranked: every processing mode writes the same state', 'Ranked processing modes and times on this PC']) {
    assert.equal(plans.filter(p => p[2] === name).length, 1, 'planned once: ' + name); const sec = plans.find(p => p[2] === name)[1]; assert.ok(ps.includes("Check '" + sec + "' '" + name + "'") || ps.includes("Add-Check '" + sec + "' '" + name + "'"), 'planned but never recorded: ' + name); }
  const focus = /\$focusSections = @\(([^)]*)\)/.exec(ps)[1]; for (const s of ["'self-test 5.16'", "'grouping 5.16'", "'self-test 5.15'", "'tournament 5.15'", "'golden states'", "'integrity'"]) assert.ok(focus.includes(s), 'focused: ' + s);
  const sections = text => [...text.matchAll(/^Run-Section '([^']+)'/gm)].map(m => m[1]), before = sections(fs.readFileSync(path.join(src, 'tools/validate_windows515.ps1'), 'utf8')), now = sections(ps);
  assert.deepEqual(now.filter(s => before.includes(s)), before); assert.deepEqual(now.filter(s => !before.includes(s)), ['self-test 5.16', 'grouping 5.16']);
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (py) { const r = cp.spawnSync(py, [path.join(src, 'tools/ps_lint571.py'), file], { encoding: 'utf8' }); assert.equal(r.status, 0, r.stdout + r.stderr); }
  // the page the script looks into carries what it looks for
  const needles = /Check 'grouping 5\.16' 'the interface file offers the Ranked grouping'/.test(ps) && ['ranked-5.16-v1', 'function rankedGroup(', "['ranked','Ranked (5.16)']", 'Ranked grouping needs a study that starts on the flop, turn or river'];
  for (const s of needles) assert.ok(ps.includes(s), 'the script looks for ' + s);
  const page = path.join(root, 'EightMax-Offline.html'); if (fs.existsSync(page)) { const html = fs.readFileSync(page, 'utf8'); for (const s of needles) assert.ok(html.includes(s), 'the page lacks ' + s); }
  for (const [name, needs] of [['Run 5.16 Windows validation.bat', ['mwcli.exe --selftest57 ', 'mwcli.exe --selftest515 ', 'mwcli.exe --selftest516 ', 'validate_windows516.ps1" %*', 'Windows-selftest516-5.16.json', 'Windows-validation-5.16.json', 'Step 12 of 12', 'if not "%selftest516_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"']],
    ['Run 5.16 focused validation.bat', ['mwcli.exe --selftest516 ', 'validate_windows516.ps1" -Focused %*', 'Windows-focused-validation-5.16.json', 'Windows-selftest516-5.16.json']]]) {
    const f = path.join(root, name); if (!fs.existsSync(f)) continue;
    const text = fs.readFileSync(f).toString('latin1'); assert.ok(!/[^\x00-\x7f]/.test(text), name + ' is ASCII'); assert.ok(!/[^\r]\n/.test(text), name + ' has CRLF line ends'); for (const n of needs) assert.ok(text.includes(n), name + ': ' + n); assert.match(text, /exit \/b %\w+%\r\n$/);
    assert.ok(!text.includes('-5.15.json') && !text.includes('validate_windows515'), name + ' writes 5.16 reports only');
  }
  const refDir = path.join(root, 'validation/5.16/windows/grouping');
  if (fs.existsSync(refDir)) { const ref = JSON.parse(fs.readFileSync(path.join(refDir, 'reference.json'), 'utf8')); assert.equal(ref.cases.length, 2); assert.equal(ref.grouping, 'ranked-5.16-v1');
    for (const c of ref.cases) { assert.ok(fs.existsSync(path.join(refDir, c.spec))); assert.match(c.stateSha256, /^[0-9a-f]{64}$/); assert.equal(c.grouping, 'ranked'); const s = JSON.parse(fs.readFileSync(path.join(refDir, c.spec), 'utf8')); assert.equal(s.groupKeys.abstraction, 'ranked'); } }
  const wf = path.join(root, '.github/workflows/windows.yml');
  if (fs.existsSync(wf)) { const y = fs.readFileSync(wf, 'utf8'); for (const s of ['--selftest516 source/studies', version === '5.16' ? 'validate_windows516.ps1 -Root' : 'validate_windows518.ps1 -Root', version === '5.16' ? 'Windows-validation-5.16.json' : 'Windows-validation-5.18.json', 'windows-selftest516.json', 'source/tests/v516.test.js']) assert.ok(y.includes(s), s); }
});
