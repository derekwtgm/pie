// EightMax 5.18: the games of Phase 8 (bet sizes outside the tree).
//
// Each BASE game is a heads-up postflop study with a small set of bet sizes. Each VARIANT is the same game with one
// size added on one street (or, for 'raise' variants, one raise size). The base strategy is solved in the base tree;
// mwcli --translate writes it as a strategy of the variant; method exact-hu gives its exact NashConv there.
//
//   node tools/games518.js list
//   node tools/games518.js spec <base> <variant|base> <compact|detailed|ranked|exact> <out.json> [seed]
'use strict';
const fs = require('node:fs');
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river']) require('../web/' + l);
const g510 = require('./games510.js');
const S = (bets, raises = '', maxBets = 1) => ({ bets, raises, maxBets });
// variant: [name, street, 'bets' | 'raises', size, where the size lies among the tree's sizes]
const GAMES = {
  'ot-river': { title: 'Whole ranges on a river (1081 hands a seat): bets of 33% and 100% of the pot, a pot-sized raise', grouping: 'exact',
    options: { board: 'Ks9d4c7h2s', common: 6, stacks: [20, 20], ranges: ['random', 'random'], streets: { river: S('33,100', '100', 2) } },
    variants: [['+66', 'river', 'bets', '66', 'between'], ['+50', 'river', 'bets', '50', 'between'], ['+200', 'river', 'bets', '200', 'above'], ['+15', 'river', 'bets', '15', 'below'], ['+r50', 'river', 'raises', '50', 'below (raise)']] },
  'ot-turn': { title: 'Whole ranges on a turn (1128 hands a seat): one bet size a street (66% and 75%)', grouping: 'ranked',
    options: { board: 'Kh9d4c7s', common: 6, stacks: [20, 20], ranges: ['random', 'random'], streets: { turn: S('66'), river: S('75') } },
    variants: [['+t33', 'turn', 'bets', '33', 'below'], ['+t150', 'turn', 'bets', '150', 'above'], ['+r33', 'river', 'bets', '33', 'below'], ['+r150', 'river', 'bets', '150', 'above']] },
  'ot-flop': { title: 'Ranges of about 80 hands on a flop: one bet size a street (50%, 66%, 75%)', grouping: 'ranked',
    options: { board: 'Jh8d5c', common: 5, stacks: [20, 20], ranges: ['77+,ATs+,KTs+,QTs+,JTs,T9s,98s,87s,AQo+', '55+,A9s+,KJs+,QJs,JTs,T9s,76s,AJo+:0.5,KQo'], streets: { flop: S('50'), turn: S('66'), river: S('75') } },
    variants: [['+f100', 'flop', 'bets', '100', 'above'], ['+f25', 'flop', 'bets', '25', 'below'], ['+t33', 'turn', 'bets', '33', 'below']] },
  // supplement (plan, amendment 3, added after the results): a second game in which a size can lie BETWEEN two tree
  // sizes, on the turn and on the river; reported apart from the twelve variants of the plan
  'ot-turn2': { title: 'Whole ranges on a turn (1128 hands a seat): bets of 33% and 100% on the turn, 50% and 100% on the river, a pot-sized raise on both', grouping: 'ranked', supplement: true,
    options: { board: 'Td9d6c2s', common: 6, stacks: [30, 30], ranges: ['random', 'random'], streets: { turn: S('33,100', '100', 2), river: S('50,100', '100', 2) } },
    variants: [['+t66', 'turn', 'bets', '66', 'between'], ['+r75', 'river', 'bets', '75', 'between']] },
  // three seats: outside the measurement (no exact best response over whole ranges there); used by the self-test,
  // where method "exact" still finishes
  'ot-turn3': { title: 'Three players on a turn (about 22 hands a seat, unequal stacks, side pots): half-pot bet or all-in, all-in raise; river 66%', grouping: 'exact', seats: 3,
    options: { board: 'Js8s3d2c', dealt: 8, common: 1.5, stacks: [22, 30, 14], prior: [4, 4, 4],
      ranges: ['AJs,88:0.5,T9s,KQs:0.75,QJs,A5s:0.5', 'KJs,AA:0.25,97s,QTs:0.75,JTs,76s', 'JTs:0.75,33:0.5,A5s,76s,KJs:0.5,T9s'],
      streets: { turn: S('50,a', 'a', 2), river: S('66') } },
    variants: [['+t100', 'turn', 'bets', '100', 'between'], ['+r33', 'river', 'bets', '33', 'below']] },
};
function options(base, variant) {
  const g = GAMES[base]; if (!g) throw new Error('unknown game ' + base);
  const o = JSON.parse(JSON.stringify(g.options));
  if (variant && variant !== 'base') {
    const v = g.variants.find(x => x[0] === variant); if (!v) throw new Error('unknown variant ' + variant + ' of ' + base);
    const st = o.streets[v[1]]; const list = (st[v[2]] ? st[v[2]].split(',') : []).concat([v[3]]);
    list.sort((a, b) => (a === 'a') - (b === 'a') || parseFloat(a) - parseFloat(b)); st[v[2]] = list.join(',');
  }
  return o;
}
function spec(base, variant, grouping, seed = 1) { return E.MultiwayGame({ ...g510.base, ...options(base, variant), abstraction: grouping || GAMES[base].grouping, privateSeed: seed }).nativeSpec(); }
module.exports = { GAMES, options, spec };
if (require.main === module) {
  const [cmd, base, variant, grouping, out, seed] = process.argv.slice(2);
  if (cmd === 'list') for (const [k, g] of Object.entries(GAMES)) console.log(k + '  ' + g.title + '\n    variants: ' + g.variants.map(v => v[0] + ' (' + v[1] + ' ' + v[2] + ' ' + v[3] + '%, ' + v[4] + ')').join(', '));
  else if (cmd === 'spec') fs.writeFileSync(out, JSON.stringify(spec(base, variant, grouping, seed ? +seed : 1)));
  else { console.error('usage: node tools/games518.js list | spec <base> <variant|base> <grouping> <out.json> [seed]'); process.exit(2); }
}
