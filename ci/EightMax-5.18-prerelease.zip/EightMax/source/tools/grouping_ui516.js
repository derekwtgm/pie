// EightMax 5.16: the Ranked hand grouping in a browser (Chromium through Playwright).
//   node tools/grouping_ui516.js <5.16 EightMax-Offline.html> <out.json> [screenshot-dir]
'use strict';
const fs = require('node:fs'), path = require('node:path'), { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');
const [page516, outFile, shotDir] = process.argv.slice(2);
if (!page516 || !outFile) { console.error('usage: node grouping_ui516.js <page> <out.json> [screenshot-dir]'); process.exit(2); }
const checks = [], errors = [];
const check = (name, ok, detail) => { checks.push({ name, passed: !!ok, ...(detail !== undefined ? { detail } : {}) }); console.log((ok ? 'ok      ' : 'FAILED  ') + name + (ok || detail === undefined ? '' : '  ' + JSON.stringify(detail).slice(0, 500))); };
(async () => {
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 900, height: 1500 } }), p = await ctx.newPage();
  p.on('pageerror', e => errors.push(String(e))); p.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await p.goto(pathToFileURL(path.resolve(page516)).href); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForSelector('#v-preflop .grid13');
  await p.click('[data-tab="river"]'); await p.waitForSelector('#rv-abstraction', { state: 'attached' });
  const options = await p.$$eval('#rv-abstraction option', o => o.map(x => [x.value, x.textContent.trim()]));
  check('Multiway: the hand-grouping list offers Compact, Ranked (5.16), Detailed and Exact cards, in that order', JSON.stringify(options) === JSON.stringify([['compact', 'Compact'], ['ranked', 'Ranked (5.16)'], ['detailed', 'Detailed'], ['exact', 'Exact cards']]), options);
  check('the default grouping is unchanged (Detailed)', await p.$eval('#rv-abstraction', e => e.value) === 'detailed');
  // the page's own engine: a flop study with the Ranked grouping
  const r = await p.evaluate(() => {
    const cfg = { board: 'Ks8d5h', common: 12, stacks: [12, 20, 30], ranges: ['22+,A2s+,KTs+,QJs,AJo+', '22+,A2s+,K9s+,QTs+,JTs,ATo+,KJo+', 'JJ-22,A9s-A2s,KQs,QJs,JTs,T9s,98s'],
      streets: { flop: { bets: '33,a', raises: '3x', maxBets: 2 }, turn: { bets: '75', raises: '', maxBets: 1 }, river: { bets: 'a', raises: '', maxBets: 1 } }, privateMode: 'sampled', traversal: 'external', evaluationDeals: 128, privateSeed: 3 };
    const out = {}; const g = EM.MultiwayGame({ ...cfg, abstraction: 'ranked' }), s = g.nativeSpec(); out.abstraction = s.abstraction; out.groupKeys = s.groupKeys && s.groupKeys.abstraction;
    g.iterate(300); const st = g.exportNative(), u8 = new Uint8Array(st), hl = new DataView(u8.buffer, u8.byteOffset).getUint32(8, true); out.head = JSON.parse(new TextDecoder().decode(u8.subarray(12, 12 + hl)));
    const c = EM.MultiwayGame({ ...cfg, abstraction: 'compact' }), d = EM.MultiwayGame({ ...cfg, abstraction: 'detailed' }); c.iterate(300); d.iterate(300);
    const rows = x => { const b = new Uint8Array(x.exportNative()), l = new DataView(b.buffer, b.byteOffset).getUint32(8, true); return JSON.parse(new TextDecoder().decode(b.subarray(12, 12 + l))).rows; };
    out.rows = [rows(c), out.head.rows, rows(d)];
    const g2 = EM.MultiwayGame({ ...cfg, abstraction: 'ranked' }); g2.importNative(st); out.reloaded = g2.trainingDeals === g.trainingDeals;
    try { EM.MultiwayGame({ ...cfg, abstraction: 'compact' }).importNative(st); out.crossLoad = 'accepted'; } catch (e) { out.crossLoad = String(e.message); }
    try { EM.MultiwayGame({ preflop: { mode: 'shove' }, dealt: 4, common: 0, board: '', stacks: [12, 7, 20, 4], ranges: ['AA,KK', 'QQ,JJ', 'TT,99', '88,77'], abstraction: 'ranked', privateMode: 'sampled', traversal: 'external' }); out.preflop = 'accepted'; } catch (e) { out.preflop = String(e.message); }
    return out;
  });
  check('the page builds a Ranked flop study: the specification names the grouping in both places', r.abstraction === 'ranked' && r.groupKeys === 'ranked', r);
  check('the page trains it: the state names "grouping":"ranked-5.16-v1", and the table is larger than Compact and smaller than Detailed', r.head.grouping === 'ranked-5.16-v1' && r.head.rowKeys === 2 && r.rows[0] < r.rows[1] && r.rows[1] < r.rows[2], { rows: r.rows, head: r.head });
  check('a Ranked state loads back into a Ranked study and is refused by the Compact study of the same spot', r.reloaded === true && r.crossLoad !== 'accepted', r.crossLoad);
  check('a study that starts before the flop refuses the Ranked grouping with the reason', /flop, turn or river/.test(r.preflop), r.preflop);
  const html = fs.readFileSync(path.resolve(page516), 'utf8');
  check('the result note of the page explains Ranked groups', /Ranked groups \(5\.16; flop, turn and river starts\)/.test(html));
  if (shotDir) { fs.mkdirSync(shotDir, { recursive: true }); await p.screenshot({ path: path.join(shotDir, 'multiway-grouping.png'), fullPage: true }); }
  check('no script error and no console error', errors.length === 0, errors.slice(0, 5));
  await browser.close();
  const passed = checks.filter(c => c.passed).length, failed = checks.length - passed;
  fs.writeFileSync(outFile, JSON.stringify({ what: 'EightMax 5.16 the Ranked hand grouping, Chromium', passed, failed, checks }, null, 1) + '\n'); console.log(passed + ' passed, ' + failed + ' failed'); process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
