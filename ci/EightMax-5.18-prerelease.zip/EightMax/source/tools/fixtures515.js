// EightMax 5.15 (Phase 5): study fixtures for bounties and future-game simulation (payoff model tour-5.15-v1).
// Definitions only; built by tools/fixtures52.js like every fixture.
//
//   pko6-bb-call(-small)          six left at a progressive-knockout final table: the big blind covers a button all-in
//   fgs4-bubble-bb-call(-small)   four left, three paid: the short stack posts the big blind next; two future hands
// EVs are in percent of the regular prize pool; bounties are entered in the same unit.
'use strict';
module.exports = function ({ E, def, seat, tree }) {
  const base = (n, start, dealt) => ({ ...E.multiwayExample(n, start, dealt), privateMode: 'sampled', traversal: 'external', batchDeals: 1, privateSeed: 1, engine: 'native', measured: false, processingMode: 'cpu', maxIter: 20000 });
  const ALL = E.CLASS_NAMES.join(',');
  // ---------- 1. progressive knockout, six left ----------
  {
    const TABLE6 = { players: 6, smallBlind: 0.5, bigBlind: 1, antePerPlayer: 0.1, startingPotBeforeVoluntaryAction: 2.1, unit: 'BB' };
    const UNIT = { model: 'icm', unit: 'percent of the regular prize pool (bounties are in the same unit)' };
    const HEADS = '10,6,14,12,8,20';   // BTN, SB, BB, then the folded MP, HJ, CO
    const mk = (o = {}) => ({ ...base(3, 'Preflop', 6), study: 'linked', payoff: o.chip ? 'chip' : 'icm', payouts: '34,23,16,12,9,6', others: '21.9,13.9,25.9',
      ...(o.chip || o.plain ? {} : { bounty: o.kind || 'pko', bounties: o.heads || HEADS }),
      abstraction: o.small ? 'exact' : 'compact', memoryMiB: o.small ? 256 : 2048, preOpen: 'a', preRaises: 'a', preCap: 2, preLimps: false,
      tree: tree(o.small ? [''] : ['a'], [''], ['']), notes: o.small ? 'EightMax 5.15 study fixture (small companion of pko6-bb-call).' : 'EightMax 5.15 study fixture: progressive knockout, six left.',
      seats: o.small ? [seat('BTN', 12, o.btn || 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5'), seat('SB', 9, 'TsTh:0.5,Kd9d,Qc6c:0.75,5h4h'), seat('BB', 30, 'AdTc,6s6c,Kh8h:0.75,9c3d')]
        : [seat('BTN', 12, ALL), seat('SB', 9, ALL), seat('BB', 30, ALL)] });
    const descr = small => ({
      effectiveStacksBB: 12, stacksBB: { MP: 22, HJ: 14, CO: 26, BTN: 12, SB: 9, BB: 30 },
      payouts: { unit: 'percent of the regular prize pool', places: [34, 23, 16, 12, 9, 6] },
      bounties: { kind: 'progressive knockout: half of a bounty is paid at once, half joins the winner\'s own bounty', unit: 'percent of the regular prize pool', onEachPlayer: { MP: 12, HJ: 8, CO: 20, BTN: 10, SB: 6, BB: 14 } },
      positions: 'six players left, all paid: MP 22, HJ 14 and CO 26 folded (stacks before the 0.1 BB ante), BTN 12, SB 9, BB 30',
      actionHistory: 'MP, HJ and CO fold. BTN (12 BB, bounty 10) moves all-in, SB (9 BB) folds. Big blind (30 BB, covers the button) to act: call or fold.', board: 'none (preflop)',
      betSizes: { preflop: 'button: fold or all-in; blinds: fold or call all-in', postflop: 'none (every pot is all-in or folded)' },
      utility: { model: 'icm', unit: 'percent of the regular prize pool', convention: 'Payoff model tour-5.15-v1: Malmuth-Harville ICM value of the final stack, plus the bounty cash won in the hand (half of the bounty on a player who is busted), plus the chip share of every bounty still out after the hand. The last part is a model of what the bounties are worth later, not a measurement.' },
      abstraction: small ? 'Exact cards.' : 'Compact hand groups (169 preflop classes). Deals, blockers, showdowns, side pots, ICM and bounties use the physical cards and exact stacks.',
      continuation: 'All-in or fold preflop; no further decisions.',
      rangeWeights: small ? 'Four or five listed hands per seat with weights 0.5 to 1.' : 'Every hand for BTN, SB and BB at weight 1.',
      assumptions: ['The three folded players keep their stacks and their bounties.', 'Push-or-fold abstraction.', 'One hand of a tournament: later hands are represented by ICM and by the chip share of the bounties still out.'] });
    def('pko6-bb-call', {
      table: TABLE6, utility: UNIT,
      title: 'Progressive knockout, six left: big blind (30 BB) covering a button all-in of 12 BB', kind: 'realistic', companion: 'pko6-bb-call-small',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'], description: descr(false),
      study: { seeds: [5501, 5502, 5503, 5504, 5505], budgetsDeals: [500000, 2000000, 8000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 2000000, seed: 515 }, quality: { method: 'sampled', samples: 200000, selectionSamples: 1000, seed: 515 }, tolerance: { evGap: 0.02, frequency: 0.05, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk() },
        { name: 'knockout', change: 'The same bounties paid in full at once (a knockout tournament) instead of half.', spot: mk({ kind: 'ko' }) },
        { name: 'no-bounties', change: 'The same stacks and prizes without bounties (the ordinary ICM).', spot: mk({ plain: true }) },
        { name: 'big-bounty', change: 'The bounty on the button is 30 instead of 10.', spot: mk({ heads: '30,6,14,12,8,20' }) },
        { name: 'chip-ev', change: 'Same stacks, ranges and actions, but utilities are chips (BB).', spot: mk({ chip: true }) },
      ] });
    def('pko6-bb-call-small', {
      table: TABLE6, utility: UNIT,
      title: 'Progressive knockout, six left: small exact companion (four or five weighted hands per seat)', kind: 'companion', companionOf: 'pko6-bb-call',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'],
      description: { ...descr(true), simplifiedFrom: 'pko6-bb-call', simplifications: ['Ranges cut from every hand to four or five weighted hands per seat.', 'Hand groups replaced by exact cards; action EVs and best-response gains are exact inside this model.'] },
      study: { seeds: [5501, 5502, 5503, 5504, 5505], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 256, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.02, frequency: 0.05, quality: 0.02, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk({ small: true }) },
        { name: 'knockout', change: 'The same bounties paid in full at once.', spot: mk({ small: true, kind: 'ko' }) },
        { name: 'no-bounties', change: 'Without bounties (the ordinary ICM).', spot: mk({ small: true, plain: true }) },
        { name: 'chip-ev', change: 'Same spot with chip utilities (BB).', spot: mk({ small: true, chip: true }) },
      ] });
  }
  // ---------- 2. future hands on the bubble, four left ----------
  {
    const TABLE4 = { players: 4, smallBlind: 0.5, bigBlind: 1, antePerPlayer: 0.1, startingPotBeforeVoluntaryAction: 1.9, unit: 'BB' };
    const UNIT = { model: 'icm', unit: 'percent of the prize pool' };
    const mk = (o = {}) => ({ ...base(3, 'Preflop', 4), study: 'linked', payoff: o.chip ? 'chip' : 'icm', payouts: '50,30,20', others: '3.9',
      ...(o.chip || o.hands === 0 ? {} : { fgsHands: String(o.hands || 2) }),
      abstraction: o.small ? 'exact' : 'compact', memoryMiB: o.small ? 256 : 2048, preOpen: 'a', preRaises: 'a', preCap: 2, preLimps: false,
      tree: tree(o.small ? [''] : ['a'], [''], ['']), notes: o.small ? 'EightMax 5.15 study fixture (small companion of fgs4-bubble-bb-call).' : 'EightMax 5.15 study fixture: the bubble with future hands, four left.',
      seats: o.small ? [seat('BTN', 15, 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5'), seat('SB', 20, 'TsTh:0.5,Kd9d,Qc6c:0.75,5h4h'), seat('BB', 11, 'AdTc,6s6c,Kh8h:0.75,9c3d')]
        : [seat('BTN', 15, ALL), seat('SB', 20, ALL), seat('BB', 11, ALL)] });
    const descr = small => ({
      effectiveStacksBB: 11, stacksBB: { CO: 4, BTN: 15, SB: 20, BB: 11 }, payouts: { unit: 'percent of the prize pool', places: [50, 30, 20] },
      futureHands: { hands: 2, model: 'each result of this hand is valued by the push-or-fold solution of the next two hands at this table and blind level (0.5/1, ante 0.1 each); the button moves one seat, so the cutoff with 4 BB posts the big blind in the next hand' },
      positions: 'four players left, three paid: CO 4 folded (stack before the 0.1 BB ante), BTN 15, SB 20, BB 11',
      actionHistory: 'CO (4 BB) folds. BTN (15 BB) moves all-in, SB (20 BB) folds. Big blind (11 BB) to act: call or fold.', board: 'none (preflop)',
      betSizes: { preflop: 'button: fold or all-in; blinds: fold or call all-in', postflop: 'none (every pot is all-in or folded)' },
      utility: { model: 'icm', unit: 'percent of the prize pool', convention: 'Payoff model tour-5.15-v1: the value of the stacks after this hand is the equilibrium value of the next two hands played as push-or-fold (169 hand classes, heads-up all-ins) with Malmuth-Harville ICM after them. A model of the future, not a measurement; the plain-icm variant values the stacks as they are.' },
      abstraction: small ? 'Exact cards.' : 'Compact hand groups (169 preflop classes). Deals, blockers, showdowns, side pots and the valuation use the physical cards and exact stacks.',
      continuation: 'All-in or fold preflop; no further decisions in this hand.',
      rangeWeights: small ? 'Four or five listed hands per seat with weights 0.5 to 1.' : 'Every hand for BTN, SB and BB at weight 1.',
      assumptions: ['The folded cutoff keeps its stack in this hand and plays the future hands.', 'Push-or-fold abstraction, in this hand and in the future hands.', 'Blinds do not rise during the future hands.'] });
    def('fgs4-bubble-bb-call', {
      table: TABLE4, utility: UNIT,
      title: 'Bubble with future hands, four left and three paid: big blind (11 BB) facing a button all-in while a 4 BB stack posts next', kind: 'realistic', companion: 'fgs4-bubble-bb-call-small',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'], description: descr(false),
      study: { seeds: [5511, 5512, 5513, 5514, 5515], budgetsDeals: [500000, 2000000, 8000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 2000000, seed: 515 }, quality: { method: 'sampled', samples: 200000, selectionSamples: 1000, seed: 515 }, tolerance: { evGap: 0.02, frequency: 0.05, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk() },
        { name: 'one-hand', change: 'One future hand instead of two.', spot: mk({ hands: 1 }) },
        { name: 'three-hands', change: 'Three future hands instead of two (the most this table size allows).', spot: mk({ hands: 3 }) },
        { name: 'plain-icm', change: 'No future hands: the stacks are valued by ICM the moment the hand ends.', spot: mk({ hands: 0 }) },
        { name: 'chip-ev', change: 'Same stacks, ranges and actions, but utilities are chips (BB).', spot: mk({ chip: true }) },
      ] });
    def('fgs4-bubble-bb-call-small', {
      table: TABLE4, utility: UNIT,
      title: 'Bubble with future hands, four left: small exact companion (four or five weighted hands per seat)', kind: 'companion', companionOf: 'fgs4-bubble-bb-call',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'],
      description: { ...descr(true), simplifiedFrom: 'fgs4-bubble-bb-call', simplifications: ['Ranges cut from every hand to four or five weighted hands per seat (in this hand only; the future hands are the full push-or-fold game).', 'Hand groups replaced by exact cards; action EVs and best-response gains are exact inside this model.'] },
      study: { seeds: [5511, 5512, 5513, 5514, 5515], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 256, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.02, frequency: 0.05, quality: 0.02, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk({ small: true }) },
        { name: 'one-hand', change: 'One future hand instead of two.', spot: mk({ small: true, hands: 1 }) },
        { name: 'three-hands', change: 'Three future hands instead of two.', spot: mk({ small: true, hands: 3 }) },
        { name: 'plain-icm', change: 'No future hands (the ordinary ICM).', spot: mk({ small: true, hands: 0 }) },
        { name: 'chip-ev', change: 'Same spot with chip utilities (BB).', spot: mk({ small: true, chip: true }) },
      ] });
  }
};
