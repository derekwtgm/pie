// EightMax 5.17: the heads-up postflop games of Phase 7 (exact best response on the CPU and on a GPU).
//
// Two kinds. The SMALL games are the heads-up range games of 5.10 and 5.16 (10 to 60 hands a seat): method "exact"
// finishes on them, so the vector method "exact-hu" can be compared with it. The WHOLE-RANGE games give both seats
// every hand the board leaves ("random": 1081 hands on a river, 1128 on a turn, 1176 on a flop), which is what
// Phase 7 asks for; method "exact" finishes on the river and turn ones and refuses the flop ones.
//
//   node tools/games517.js list
//   node tools/games517.js spec <key> <compact|detailed|ranked|exact> <out.json> [seed]
'use strict';
const path = require('node:path'), fs = require('node:fs');
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river']) require('../web/' + l);
const g510 = require('./games510.js'), g516 = require('./games516.js');
const SMALL = ['rg-hu-river', 'rg-hu-turn', 'rg-hu-flop', 'ho-hu-river', 'ho-hu-turn'];
const one = (bets, raises = '', maxBets = 1) => ({ bets, raises, maxBets });
const added = {
  'wr-river': { title: 'Whole ranges, river: 1081 hands a seat, two bet sizes and a raise', hands: 1081,
    options: { board: 'Ks9d4c7h2s', common: 6, stacks: [20, 20], ranges: ['random', 'random'], streets: { river: one('50,100', '100', 2) } } },
  'wr-turn': { title: 'Whole ranges, turn and river: 1128 hands a seat, one bet size a street', hands: 1128,
    options: { board: 'Kh9d4c7s', common: 6, stacks: [20, 20], ranges: ['random', 'random'], streets: { turn: one('66'), river: one('75') } } },
  'wr-turn-wide': { title: 'Whole ranges, turn and river: 1128 hands a seat, two bet sizes and a raise on both streets', hands: 1128,
    options: { board: 'Td9d6c2s', common: 6, stacks: [30, 30], ranges: ['random', 'random'], streets: { turn: one('33,100', '100', 2), river: one('50,100', '100', 2) } } },
  'wr-flop': { title: 'Whole ranges, flop, turn and river: 1176 hands a seat, one bet size a street', hands: 1176,
    options: { board: 'Kh9d4c', common: 5, stacks: [20, 20], ranges: ['random', 'random'], streets: { flop: one('50'), turn: one('66'), river: one('75') } } },
  'wr-flop-allin': { title: 'Whole ranges, flop: 1176 hands a seat, bet or all-in on the flop (showdowns that wait for two cards), one bet size later', hands: 1176,
    options: { board: 'Qs8s3d', common: 4, stacks: [12, 12], ranges: ['random', 'random'], streets: { flop: one('75,a', 'a', 2), turn: one('66'), river: one('75') } } },
  // one whole range against a narrow weighted one; the narrow range repeats hands of the whole one (the identical-hand term)
  'mx-turn': { title: 'A whole range against a narrow weighted range, turn and river', hands: 1128,
    options: { board: 'Ah7d7c2s', common: 8, stacks: [16, 24], ranges: ['random', 'AA:0.5,A7s,77,AKs:0.25,KQs,65s:0.5,22,T9s:0.75,A2o:0.1'], streets: { turn: one('50,a', 'a', 2), river: one('75') } } },
  // about 80 hands a seat on a flop: wide, and still inside what method "exact" allows (it refused about 170)
  'mid-flop': { title: 'Wider ranges on a flop (about 80 hands a seat), one bet size a street: a flop method exact still finishes', hands: 80,
    options: { board: 'Jh8d5c', common: 5, stacks: [20, 20],
      ranges: ['77+,ATs+,KTs+,QTs+,JTs,T9s,98s,87s,AQo+', '55+,A9s+,KJs+,QJs,JTs,T9s,76s,AJo+:0.5,KQo'], streets: { flop: one('50'), turn: one('66'), river: one('75') } } },
};
const KEYS = [...SMALL, ...Object.keys(added)];
const GROUPINGS = ['compact', 'detailed', 'ranked', 'exact'];
function spec(key, grouping, seed = 1) {
  if (SMALL.includes(key)) return g516.spec(key, grouping, seed);
  if (!added[key]) throw new Error('unknown game ' + key);
  return E.MultiwayGame({ ...g510.base, ...added[key].options, abstraction: grouping, privateSeed: seed }).nativeSpec();
}
const title = key => added[key] ? added[key].title : key === 'rg-hu-flop' ? g516.added.title : g516.heldOut[key] ? g516.heldOut[key].title : g510.byKey[key].title;
module.exports = { KEYS, SMALL, WHOLE: Object.keys(added), GROUPINGS, spec, added, title };
if (require.main === module) {
  const [cmd, key, grouping, out, seed] = process.argv.slice(2);
  if (cmd === 'list') for (const k of KEYS) console.log(k.padEnd(14), title(k));
  else if (cmd === 'spec') fs.writeFileSync(path.resolve(out), JSON.stringify(spec(key, grouping, +(seed || 1))));
  else { console.error('usage: node tools/games517.js list | spec <key> <grouping> <out.json> [seed]'); process.exit(2); }
}
