// EightMax 5.16: the Ranked hand grouping (ranked-5.16-v1), JavaScript against native.
// usage: node tools/grouped516.js <mwcli> <out.json> [--quick]
// For each configuration and seed both engines train the same number of updates; the tool requires identical
// tables (every row key and every value, bit for bit). The JavaScript key function (lib_wide.js rankedGroup) and the
// native one (es_groups.hpp RankedGroups) are written separately, so this is the check that they are one function.
// It also loads the native state into the JavaScript engine and the JavaScript state into the native engine.
'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), { spawnSync } = require('node:child_process');
const [cli, out] = process.argv.slice(2), quick = process.argv.includes('--quick');
if (!cli || !out) { console.error('usage: node tools/grouped516.js <mwcli> <out.json> [--quick]'); process.exit(2); }
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river']) require('../web/' + l);
const flop3 = { board: 'Ks8d5h', common: 12, stacks: [12, 20, 30], ranges: ['AhKh,KdQd,8s8h,JsTs,7s6s,AcQc,QhJh,9c9d,22+,A2s+', 'AsKd,KcJc,5d5c,8h7h,AdQd,JdTd,6h6d,4c3c', 'Kc9c,QsQc:0.5,7d7c,Ah5s,Td9d,JhJc,6s5s,AdJd'],
  streets: { flop: { bets: '33,a', raises: '3x', maxBets: 2 }, turn: { bets: '75,g', raises: '', maxBets: 1 }, river: { bets: 'a', raises: '', maxBets: 1 } }, privateMode: 'sampled', traversal: 'external', evaluationDeals: 128 };
const six = { board: 'Td7c2h', dealt: 8, common: 1.5, stacks: [20, 35, 8, 50, 14, 26], prior: [2.5, 2.5, 2.5, 2.5, 2.5, 2.5], folded: [1, 2.5], ranges: Array(6).fill('22+,A2s+,K9s+,QTs+,JTs,ATo+,KJo+:0.6'),
  privateMode: 'sampled', traversal: 'external', evaluationDeals: 128, streets: { flop: { bets: '33', raises: '', maxBets: 1 }, turn: { bets: '50', raises: '', maxBets: 1 }, river: { bets: '75', raises: '', maxBets: 1 } }, batchDeals: 4, actionStreams: 'deal' };
const bigTurn = { board: 'Ks8d5h2c', common: 8, stacks: [20, 20], ranges: ['22+,A2s+,K2s+,Q2s+,J5s+,T6s+,96s+,85s+,75s+,64s+,A2o+,K5o+,Q8o+,J8o+,T8o+', '22+,A2s+,K2s+,Q2s+,J5s+,T6s+,96s+,85s+,75s+,64s+,A2o+,K5o+,Q8o+,J8o+,T8o+'],
  streets: { turn: { bets: '50,a', raises: 'a', maxBets: 2 }, river: { bets: '75', raises: '', maxBets: 1 } }, privateMode: 'sampled', traversal: 'external', evaluationDeals: 128 };
const configs = [['Ranked 3-seat flop', { ...flop3, abstraction: 'ranked' }, quick ? 300 : 3000, 1], ['Ranked 6-seat flop (4 deals/update, 4 threads)', { ...six, abstraction: 'ranked' }, quick ? 40 : 400, 4],
  ['Ranked heads-up turn with wide ranges (native keys, not a representative map)', { ...bigTurn, abstraction: 'ranked' }, quick ? 300 : 3000, 1]];
const seeds = quick ? [1] : [1, 2, 3], dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em516-grouped-'));
function rowsOf(u8) {
  const hl = u8.readUInt32LE(8), head = JSON.parse(u8.subarray(12, 12 + hl).toString()); let p = 12 + hl; const sc = u8.readUInt32LE(p); p += 4;
  const paths = []; for (let i = 0; i < sc; i++) { const par = u8.readUInt32LE(p), slot = u8[p + 4]; paths.push(i ? paths[par] + (slot === 7 ? 'c' : slot) : 'r'); p += 9; }
  const c = u8.readUInt32LE(p); p += 4; const m = new Map(), extra = head.rowSync ? 4 : 0;
  for (let i = 0; i < c; i++) { const st = u8.readUInt32LE(p), l = u8.readUInt16LE(p + 4), id = u8.subarray(p + 6, p + 6 + l).toString(), k = u8[p + 6 + l], at = p + 7 + l; m.set(paths[st] + '|' + id, u8.subarray(at, at + 16 * k + extra).toString('hex')); p = at + 16 * k + extra; }
  return { rows: m, head };
}
const result = { tool: 'grouped516.js', grouping: 'ranked-5.16-v1', configs: [] }; let failed = 0;
try {
  for (const [name, cfg, its, threads] of configs) { const runs = [];
    for (const seed of seeds) {
      const c = { ...cfg, privateSeed: seed }, g = E.MultiwayGame(c), spec = g.nativeSpec(), sf = path.join(dir, 'spec.json'); fs.writeFileSync(sf, JSON.stringify(spec));
      g.iterate(its); fs.writeFileSync(path.join(dir, 'js.state'), g.exportNative());
      const nat = spawnSync(cli, [sf, String(its), String(threads), path.join(dir, 'n.state'), '2048'], { encoding: 'utf8' }); if (nat.status) throw Error(name + ': ' + nat.stderr);
      const a = rowsOf(fs.readFileSync(path.join(dir, 'js.state'))), b = rowsOf(fs.readFileSync(path.join(dir, 'n.state')));
      let same = a.rows.size === b.rows.size; for (const [k, v] of a.rows) if (b.rows.get(k) !== v) { same = false; break; }
      // the native state continues in JavaScript, the JavaScript state continues natively
      let jsLoads = false, nativeLoads = false, why = '';
      try { const g2 = E.MultiwayGame(c); g2.importNative(fs.readFileSync(path.join(dir, 'n.state'))); jsLoads = g2.trainingDeals === g.trainingDeals; } catch (e) { why += 'JavaScript: ' + e.message + '; '; }
      const cont = spawnSync(cli, [sf, '1', '1', path.join(dir, 'c.state'), '2048', path.join(dir, 'js.state')], { encoding: 'utf8' }); nativeLoads = cont.status === 0; if (!nativeLoads) why += 'native: ' + cont.stderr.slice(0, 200);
      const ok = same && jsLoads && nativeLoads && spec.groupKeys && spec.groupKeys.abstraction === 'ranked' && a.head.grouping === 'ranked-5.16-v1' && b.head.grouping === 'ranked-5.16-v1'; if (!ok) failed++;
      runs.push({ seed, updates: its, threads, rows: a.rows.size, identicalTables: same, nativeStateLoadsInJavaScript: jsLoads, javaScriptStateLoadsNatively: nativeLoads, headersNameTheGrouping: a.head.grouping === 'ranked-5.16-v1' && b.head.grouping === 'ranked-5.16-v1', ...(why ? { why } : {}) });
      console.log((ok ? 'ok      ' : 'FAILED  ') + name + ', seed ' + seed + ': ' + a.rows.size + ' rows' + (why ? '  ' + why : ''));
    }
    result.configs.push({ name, runs });
  }
} finally { fs.rmSync(dir, { recursive: true, force: true }); }
result.failed = failed; fs.writeFileSync(out, JSON.stringify(result, null, 1) + '\n'); console.log(failed ? failed + ' FAILED' : 'every table identical'); process.exit(failed ? 1 : 0);
