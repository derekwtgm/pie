// EightMax 5.16: the reference games for the card-grouping measurement (Phase 6).
//
// The range games of tools/games510.js (10 to 60 hands a seat, small enough for an exact best response of every
// seat over physical hands and boards), each generated under the three hand groupings of the Multiway form:
// Compact, Detailed and Exact cards. Everything but the grouping is the same game: ranges, board, stacks, bet sizes.
// One game is added: a heads-up flop with three betting streets.
//
//   node tools/games516.js list
//   node tools/games516.js spec <key> <compact|detailed|exact> <out.json> [seed]
'use strict';
const path = require('node:path'), fs = require('node:fs');
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river']) require('../web/' + l);
const g510 = require('./games510.js');
const added = { key: 'rg-hu-flop', title: 'Heads-up flop, turn and river, ranges of about 20 hands a seat, one bet size a street, chip EV',
  options: { board: 'Kh9d4c', common: 5, stacks: [20, 20],
    ranges: ['AKs,99:0.5,JTs,76s:0.5,QJs,A4s:0.5', 'KJs,AKo:0.5,T9s,87s,QTs:0.5,44:0.5'],
    streets: { flop: { bets: '50', raises: '', maxBets: 1 }, turn: { bets: '66', raises: '', maxBets: 1 }, river: { bets: '75', raises: '', maxBets: 1 } } } };
const KEYS = ['rg-hu-river', 'rg-river3', 'rg-icm3-river', 'rg-hu-turn', 'rg-turn3', 'rg-turn4', 'rg-hu-flop', 'rg-flop3c'];
const GROUPINGS = ['compact', 'detailed', 'ranked', 'exact'];
// Two held-out games (validation/5.16/plan.json, amendment 3): defined before a better grouping was designed and not
// used while designing it. Other boards than the games above: a flush board with a pair, and a turn with draws.
const heldOut = {
  'ho-hu-river': { title: 'Held out: heads-up river on a three-flush paired board, ranges of about 50 hands a seat, chip EV',
    options: { board: 'QhJh7c7d3h', common: 10, stacks: [20, 20],
      ranges: ['AhKh,AQs,KQo:0.5,QJs,77:0.5,T9s,AJo:0.5,KhTh,98s:0.5,A7s:0.5,KK:0.5', 'AQo:0.5,KQs,JTs,QTs,33,A7s:0.5,T9s:0.5,AhTh,KJo:0.5,99,8h6h'],
      streets: { river: { bets: '50,a', raises: 'a', maxBets: 2 } } } },
  'ho-hu-turn': { title: 'Held out: heads-up turn and river on a board with straight and flush draws, ranges of about 30 hands a seat, chip EV',
    options: { board: 'Td9d6c2s', common: 8, stacks: [12, 12],
      ranges: ['AdKd,JTs,QJs:0.5,99:0.5,87s,AA:0.5,KQs:0.5,A9s:0.5', 'KdQd,T9s:0.5,J8s,66:0.5,AJs:0.5,QTs,76s:0.5,JJ'],
      streets: { turn: { bets: 'a', raises: '', maxBets: 1 }, river: { bets: '50', raises: '', maxBets: 1 } } } },
};
const options = key => key === added.key ? added.options : heldOut[key] ? heldOut[key].options : g510.byKey[key].options;
function spec(key, grouping, seed = 1) {
  if (!KEYS.includes(key) && !heldOut[key]) throw new Error('unknown game ' + key);
  return E.MultiwayGame({ ...g510.base, ...options(key), abstraction: grouping, privateSeed: seed }).nativeSpec();
}
module.exports = { KEYS, HELD_OUT: Object.keys(heldOut), GROUPINGS, spec, added, heldOut };
if (require.main === module) {
  const [cmd, key, grouping, out, seed] = process.argv.slice(2);
  if (cmd === 'list') for (const k of [...KEYS, ...Object.keys(heldOut)]) console.log(k.padEnd(14), k === added.key ? added.title : heldOut[k] ? heldOut[k].title : g510.byKey[k].title);
  else if (cmd === 'spec') fs.writeFileSync(path.resolve(out), JSON.stringify(spec(key, grouping, +(seed || 1))));
  else { console.error('usage: node tools/games516.js list | spec <key> <grouping> <out.json> [seed]'); process.exit(2); }
}
