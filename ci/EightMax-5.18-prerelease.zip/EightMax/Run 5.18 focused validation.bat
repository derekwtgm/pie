@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.18 focused validation on this Windows PC: bet sizes outside the tree, and the checks of 5.11 to 5.17.
echo   - map-5.18-v1: the rule that maps a bet size the tree does not have onto the sizes it has; strategies
echo     translated into a tree with one more size (mwcli --translate) are the files recorded on Linux, and their
echo     exact best responses have the recorded bits; lines of real actions (mwcli --offtree) end on the recorded
echo     tree paths; refusals
echo   - unchanged, and run here because 5.18 must not have changed them: method exact-hu of 5.17 on the CPU and on
echo     the GPU of this PC (through its OpenCL driver; skipped if no OpenCL GPU answers), the Ranked grouping of
echo     5.16, bounties and future hands of 5.15, pruning, the merge of frozen batches and the equal-time tool of
echo     5.14, the satellite checks of 5.13, the 6-max checks of 5.12, the philox64 checks of 5.11, and the trainer
echo     against the recorded states of 5.10
echo Nothing is installed. This takes about 30 to 60 minutes.
echo Saved studies are not touched: everything is written to a temporary folder, which is removed at the end.
echo Reports are written into this folder:
echo   Windows-selftest518-5.18.json          the checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-focused-validation-5.18.json   every check, with its status and its evidence
echo   Windows-focused-validation-5.18.txt    the same as text
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest518-5.18.json" del /q "Windows-selftest518-5.18.json"
if exist "Windows-focused-validation-5.18.json" del /q "Windows-focused-validation-5.18.json"
if exist "Windows-focused-validation-5.18.txt" del /q "Windows-focused-validation-5.18.txt"
echo Step 1 of 2: mwcli.exe --selftest518
set "em_st=%TEMP%\EightMax-5.18-selftest518-%RANDOM%%RANDOM%"
mwcli.exe --selftest518 "validation\5.18\windows\offtree" "%em_st%" all
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest518.json" copy /y "%em_st%\selftest518.json" "Windows-selftest518-5.18.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.18: every check passed.) else (echo Self-test 5.18: exit status %selftest_result%: a check failed or could not be made. See Windows-selftest518-5.18.json.)
rem A self-test that ends with status 0 but wrote no report has not shown anything: that is not a pass.
if not exist "Windows-selftest518-5.18.json" if "%selftest_result%"=="0" set "selftest_result=2"
if not exist "Windows-selftest518-5.18.json" echo NOTE: Windows-selftest518-5.18.json was not written.
echo.
echo Step 2 of 2: the validation script, focused mode
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows518.ps1" -Focused %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-focused-validation-5.18.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.11 to 5.18 sections have not run on a physical Windows PC before this release; please keep the report files and the text above. The self-test result of step 1 stands on its own.
if not exist "Windows-focused-validation-5.18.json" echo NOTE: Windows-focused-validation-5.18.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
