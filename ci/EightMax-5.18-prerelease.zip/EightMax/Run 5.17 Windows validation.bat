@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.17 validation on this Windows PC. Nothing is installed. This takes 60 to 135 minutes.
echo Reports are written into this folder:
echo   Windows-selftest-5.17.json        the 5.7 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest571-5.17.json     the checkpoint and memory checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest58-5.17.json      the 5.8 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest59-5.17.json      the 5.9 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest510-5.17.json     the 5.10 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest511-5.17.json     the 5.11 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest512-5.17.json     the 5.12 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest513-5.17.json     the 5.13 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest514-5.17.json     the 5.14 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest515-5.17.json     the 5.15 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest516-5.17.json     the 5.16 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest517-5.17.json     the 5.17 checks made by mwcli.exe itself, CPU and GPU (no PowerShell needed)
echo   Windows-validation-5.17.json      every check, with its status: passed, failed, skipped or untested
echo   Windows-validation-5.17.txt       the same as text
echo   hardware-validation.json         written by the GPU section when an NVIDIA GPU answers
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest-5.17.json" del /q "Windows-selftest-5.17.json"
if exist "Windows-selftest571-5.17.json" del /q "Windows-selftest571-5.17.json"
if exist "Windows-selftest58-5.17.json" del /q "Windows-selftest58-5.17.json"
if exist "Windows-selftest59-5.17.json" del /q "Windows-selftest59-5.17.json"
if exist "Windows-selftest510-5.17.json" del /q "Windows-selftest510-5.17.json"
if exist "Windows-selftest511-5.17.json" del /q "Windows-selftest511-5.17.json"
if exist "Windows-selftest512-5.17.json" del /q "Windows-selftest512-5.17.json"
if exist "Windows-selftest513-5.17.json" del /q "Windows-selftest513-5.17.json"
if exist "Windows-selftest514-5.17.json" del /q "Windows-selftest514-5.17.json"
if exist "Windows-selftest515-5.17.json" del /q "Windows-selftest515-5.17.json"
if exist "Windows-selftest516-5.17.json" del /q "Windows-selftest516-5.17.json"
if exist "Windows-selftest517-5.17.json" del /q "Windows-selftest517-5.17.json"
if exist "Windows-validation-5.17.json" del /q "Windows-validation-5.17.json"
if exist "Windows-validation-5.17.txt" del /q "Windows-validation-5.17.txt"
echo Step 1 of 13: mwcli.exe --selftest57
set "em_st=%TEMP%\EightMax-5.17-selftest-%RANDOM%%RANDOM%"
mwcli.exe --selftest57 "validation\5.7\fixtures" "%em_st%"
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest57.json" copy /y "%em_st%\selftest57.json" "Windows-selftest-5.17.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.7: every check passed.) else (echo Self-test 5.7: exit status %selftest_result%. See Windows-selftest-5.17.json.)
if not exist "Windows-selftest-5.17.json" if "%selftest_result%"=="0" set "selftest_result=2"
echo.
echo Step 2 of 13: mwcli.exe --selftest571 (checkpoint integrity and the process memory budget)
set "em_st2=%TEMP%\EightMax-5.17-selftest571-%RANDOM%%RANDOM%"
mwcli.exe --selftest571 "studies" "%em_st2%" all
set "selftest571_result=%errorlevel%"
if exist "%em_st2%\selftest571.json" copy /y "%em_st2%\selftest571.json" "Windows-selftest571-5.17.json" >nul
if exist "%em_st2%" rmdir /s /q "%em_st2%"
if "%selftest571_result%"=="0" (echo Self-test 5.7.1: every check passed.) else (echo Self-test 5.7.1: exit status %selftest571_result%: a check failed or could not be made. See Windows-selftest571-5.17.json.)
if not exist "Windows-selftest571-5.17.json" if "%selftest571_result%"=="0" set "selftest571_result=2"
echo.
echo Step 3 of 13: mwcli.exe --selftest58 (trained response, large-study limit, ICM cache)
set "em_st3=%TEMP%\EightMax-5.17-selftest58-%RANDOM%%RANDOM%"
mwcli.exe --selftest58 "studies" "%em_st3%" all
set "selftest58_result=%errorlevel%"
if exist "%em_st3%\selftest58.json" copy /y "%em_st3%\selftest58.json" "Windows-selftest58-5.17.json" >nul
if exist "%em_st3%" rmdir /s /q "%em_st3%"
if "%selftest58_result%"=="0" (echo Self-test 5.8: every check passed.) else (echo Self-test 5.8: exit status %selftest58_result%: a check failed or could not be made. See Windows-selftest58-5.17.json.)
if not exist "Windows-selftest58-5.17.json" if "%selftest58_result%"=="0" set "selftest58_result=2"
echo.
echo Step 4 of 13: mwcli.exe --selftest59 (confidence statements, evaluation random streams, the response summary against exact values)
set "em_st4=%TEMP%\EightMax-5.17-selftest59-%RANDOM%%RANDOM%"
mwcli.exe --selftest59 "studies" "%em_st4%" all
set "selftest59_result=%errorlevel%"
if exist "%em_st4%\selftest59.json" copy /y "%em_st4%\selftest59.json" "Windows-selftest59-5.17.json" >nul
if exist "%em_st4%" rmdir /s /q "%em_st4%"
if "%selftest59_result%"=="0" (echo Self-test 5.9: every check passed.) else (echo Self-test 5.9: exit status %selftest59_result%: a check failed or could not be made. See Windows-selftest59-5.17.json.)
if not exist "Windows-selftest59-5.17.json" if "%selftest59_result%"=="0" set "selftest59_result=2"
echo.
echo Step 5 of 13: mwcli.exe --selftest510 (the experimental estimator against exact targets, both trainers against recorded states, checkpoint rules, limits)
set "em_st5=%TEMP%\EightMax-5.17-selftest510-%RANDOM%%RANDOM%"
mwcli.exe --selftest510 "studies" "%em_st5%" all
set "selftest510_result=%errorlevel%"
if exist "%em_st5%\selftest510.json" copy /y "%em_st5%\selftest510.json" "Windows-selftest510-5.17.json" >nul
if exist "%em_st5%" rmdir /s /q "%em_st5%"
if "%selftest510_result%"=="0" (echo Self-test 5.10: every check passed.) else (echo Self-test 5.10: exit status %selftest510_result%: a check failed or could not be made. See Windows-selftest510-5.17.json.)
if not exist "Windows-selftest510-5.17.json" if "%selftest510_result%"=="0" set "selftest510_result=2"
echo.
echo Step 6 of 13: mwcli.exe --selftest511 (the counter-based training streams: generator, counter audit, recorded states, checkpoint rules, the update limit)
set "em_st6=%TEMP%\EightMax-5.17-selftest511-%RANDOM%%RANDOM%"
mwcli.exe --selftest511 "studies" "%em_st6%" all
set "selftest511_result=%errorlevel%"
if exist "%em_st6%\selftest511.json" copy /y "%em_st6%\selftest511.json" "Windows-selftest511-5.17.json" >nul
if exist "%em_st6%" rmdir /s /q "%em_st6%"
if "%selftest511_result%"=="0" (echo Self-test 5.11: every check passed.) else (echo Self-test 5.11: exit status %selftest511_result%: a check failed or could not be made. See Windows-selftest511-5.17.json.)
if not exist "Windows-selftest511-5.17.json" if "%selftest511_result%"=="0" set "selftest511_result=2"
echo.
echo Step 7 of 13: mwcli.exe --selftest512 (the six-handed study fixtures: tables, decisions, recorded states, exact NashConv, studies)
set "em_st7=%TEMP%\EightMax-5.17-selftest512-%RANDOM%%RANDOM%"
mwcli.exe --selftest512 "studies" "%em_st7%" all
set "selftest512_result=%errorlevel%"
if exist "%em_st7%\selftest512.json" copy /y "%em_st7%\selftest512.json" "Windows-selftest512-5.17.json" >nul
if exist "%em_st7%" rmdir /s /q "%em_st7%"
if "%selftest512_result%"=="0" (echo Self-test 5.12: every check passed.) else (echo Self-test 5.12: exit status %selftest512_result%: a check failed or could not be made. See Windows-selftest512-5.17.json.)
if not exist "Windows-selftest512-5.17.json" if "%selftest512_result%"=="0" set "selftest512_result=2"
echo.
echo Step 8 of 13: mwcli.exe --selftest513 (satellites: the payoff model, fixtures, recorded states, closed forms, checkpoint rules)
set "em_st8=%TEMP%\EightMax-5.17-selftest513-%RANDOM%%RANDOM%"
mwcli.exe --selftest513 "studies" "%em_st8%" all
set "selftest513_result=%errorlevel%"
if exist "%em_st8%\selftest513.json" copy /y "%em_st8%\selftest513.json" "Windows-selftest513-5.17.json" >nul
if exist "%em_st8%" rmdir /s /q "%em_st8%"
if "%selftest513_result%"=="0" (echo Self-test 5.13: every check passed.) else (echo Self-test 5.13: exit status %selftest513_result%: a check failed or could not be made. See Windows-selftest513-5.17.json.)
if not exist "Windows-selftest513-5.17.json" if "%selftest513_result%"=="0" set "selftest513_result=2"
echo.
echo Step 9 of 13: mwcli.exe --selftest514 (pruning: recorded states, counters, threads, checkpoint rules; the merge of frozen batches)
set "em_st9=%TEMP%\EightMax-5.17-selftest514-%RANDOM%%RANDOM%"
mwcli.exe --selftest514 "studies" "%em_st9%" all
set "selftest514_result=%errorlevel%"
if exist "%em_st9%\selftest514.json" copy /y "%em_st9%\selftest514.json" "Windows-selftest514-5.17.json" >nul
if exist "%em_st9%" rmdir /s /q "%em_st9%"
if "%selftest514_result%"=="0" (echo Self-test 5.14: every check passed.) else (echo Self-test 5.14: exit status %selftest514_result%: a check failed or could not be made. See Windows-selftest514-5.17.json.)
if not exist "Windows-selftest514-5.17.json" if "%selftest514_result%"=="0" set "selftest514_result=2"
echo.
echo Step 10 of 13: mwcli.exe --selftest515 (bounties and future hands: the model's recorded values, recorded states, threads, checkpoint rules)
set "em_st10=%TEMP%\EightMax-5.17-selftest515-%RANDOM%%RANDOM%"
mwcli.exe --selftest515 "studies" "%em_st10%" all
set "selftest515_result=%errorlevel%"
if exist "%em_st10%\selftest515.json" copy /y "%em_st10%\selftest515.json" "Windows-selftest515-5.17.json" >nul
if exist "%em_st10%" rmdir /s /q "%em_st10%"
if "%selftest515_result%"=="0" (echo Self-test 5.15: every check passed.) else (echo Self-test 5.15: exit status %selftest515_result%: a check failed or could not be made. See Windows-selftest515-5.17.json.)
if not exist "Windows-selftest515-5.17.json" if "%selftest515_result%"=="0" set "selftest515_result=2"
echo.
echo Step 11 of 13: mwcli.exe --selftest516 (the Ranked hand grouping: recorded states, threads, stop and continue, checkpoint rules)
set "em_st11=%TEMP%\EightMax-5.17-selftest516-%RANDOM%%RANDOM%"
mwcli.exe --selftest516 "studies" "%em_st11%" all
set "selftest516_result=%errorlevel%"
if exist "%em_st11%\selftest516.json" copy /y "%em_st11%\selftest516.json" "Windows-selftest516-5.17.json" >nul
if exist "%em_st11%" rmdir /s /q "%em_st11%"
if "%selftest516_result%"=="0" (echo Self-test 5.16: every check passed.) else (echo Self-test 5.16: exit status %selftest516_result%: a check failed or could not be made. See Windows-selftest516-5.17.json.)
if not exist "Windows-selftest516-5.17.json" if "%selftest516_result%"=="0" set "selftest516_result=2"
echo.
echo Step 12 of 13: mwcli.exe --selftest517 (exact best response of heads-up studies: recorded bits, threads, method exact, and the GPU through OpenCL)
set "em_st12=%TEMP%\EightMax-5.17-selftest517-%RANDOM%%RANDOM%"
mwcli.exe --selftest517 "validation\5.17\windows\brhu" "studies" "%em_st12%" all
set "selftest517_result=%errorlevel%"
if exist "%em_st12%\selftest517.json" copy /y "%em_st12%\selftest517.json" "Windows-selftest517-5.17.json" >nul
if exist "%em_st12%" rmdir /s /q "%em_st12%"
if "%selftest517_result%"=="0" (echo Self-test 5.17: every check passed; GPU checks are listed as skipped if no OpenCL GPU answered.) else (echo Self-test 5.17: exit status %selftest517_result%: a check failed or could not be made. See Windows-selftest517-5.17.json.)
if not exist "Windows-selftest517-5.17.json" if "%selftest517_result%"=="0" set "selftest517_result=2"
echo.
echo Step 13 of 13: the validation script
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows517.ps1" %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-validation-5.17.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed. Skipped checks, if any, are listed above with their reason.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.11 to 5.17 sections have not run on a physical Windows PC before this release; please keep the report files and the text above. The self-test results of steps 1 to 12 stand on their own.
if not exist "Windows-validation-5.17.json" echo NOTE: Windows-validation-5.17.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest571_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest58_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest59_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest510_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest511_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest512_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest513_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest514_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest515_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest516_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest517_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
