@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.8: strategy-quality measurement of a trained six-player flop study (trained response).
echo This trains the small six-player flop fixture for 200,000 deals, then measures, for every seat, how much a
echo response strategy trained against the other five seats gains: a lower bound of that seat's best-response gain.
echo The small fixture also allows the exact answer, so the report shows the share of exact NashConv that was found.
echo The result is written to EightMax-5.8-response-example.json in this folder. This takes about a minute.
echo.
set "em_w=%TEMP%\EightMax-5.8-response-%RANDOM%%RANDOM%"
mkdir "%em_w%"
mwcli.exe "validation\5.8\windows\response\flop6-jack-small.spec.json" 200000 1 "%em_w%\trained.state" 256 >nul
if errorlevel 1 (echo Training failed. & rmdir /s /q "%em_w%" & if not defined EIGHTMAX_NO_PAUSE pause & exit /b 1)
mwcli.exe --response "validation\5.8\windows\response\flop6-jack-small.spec.json" "%em_w%\trained.state" "validation\5.8\windows\response\example-request.json" 256 > "EightMax-5.8-response-example.json"
set "em_result=%errorlevel%"
rmdir /s /q "%em_w%"
if "%em_result%"=="0" (echo Done. Open EightMax-5.8-response-example.json: see "summary" and, per seat, "sampled" and "exact".) else (echo The measurement failed with exit status %em_result%.)
echo USER-GUIDE-5.8.md, section "Measuring strategy quality", explains every field and how to use your own study.
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %em_result%
