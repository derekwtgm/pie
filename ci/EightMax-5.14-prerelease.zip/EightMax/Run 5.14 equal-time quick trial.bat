@echo off
cd /d "%~dp0"
echo EightMax 5.14: a trial of the equal-time tool on this PC (a few minutes; never a result).
echo.
eqtime.exe all --quick %*
set "eq_result=%errorlevel%"
echo.
echo Exit status: %eq_result%  (0: the three parts ran and the equal-deals checks passed)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eq_result%
