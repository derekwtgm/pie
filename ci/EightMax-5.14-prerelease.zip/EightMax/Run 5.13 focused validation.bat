@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.13 focused validation on this Windows PC: satellites, and the checks of 5.11 and 5.12.
echo   - the satellite-field payoff model: against the exact recursion, its sum rule, and the bits of the Linux build
echo   - six satellite fixtures; two games with closed-form answers (a mixed river spot, folding aces on the bubble)
echo   - satellite studies with 1, 2, 4, 8 and all logical processors and every processing mode: one state each
echo   - a state continues only under the payoff model, seats and field it was trained for
echo   - unchanged, and run here because 5.13 must not have changed them: the 6-max checks of 5.12, the philox64
echo     checks of 5.11, and the trainer with the 5.10 streams against the recorded states of 5.10
echo The GPU is used by Hybrid and GPU-Preferred if it answers; the separate CUDA validation is in the full run.
echo Nothing is installed. This takes about 10 to 25 minutes.
echo Saved studies are not touched: everything is written to a temporary folder, which is removed at the end.
echo Reports are written into this folder:
echo   Windows-selftest513-5.13.json          the checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-focused-validation-5.13.json   every check, with its status and its evidence
echo   Windows-focused-validation-5.13.txt    the same as text
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest513-5.13.json" del /q "Windows-selftest513-5.13.json"
if exist "Windows-focused-validation-5.13.json" del /q "Windows-focused-validation-5.13.json"
if exist "Windows-focused-validation-5.13.txt" del /q "Windows-focused-validation-5.13.txt"
echo Step 1 of 2: mwcli.exe --selftest513
set "em_st=%TEMP%\EightMax-5.13-selftest513-%RANDOM%%RANDOM%"
mwcli.exe --selftest513 "studies" "%em_st%" all
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest513.json" copy /y "%em_st%\selftest513.json" "Windows-selftest513-5.13.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.13: every check passed.) else (echo Self-test 5.13: exit status %selftest_result%: a check failed or could not be made. See Windows-selftest513-5.13.json.)
rem A self-test that ends with status 0 but wrote no report has not shown anything: that is not a pass.
if not exist "Windows-selftest513-5.13.json" if "%selftest_result%"=="0" set "selftest_result=2"
if not exist "Windows-selftest513-5.13.json" echo NOTE: Windows-selftest513-5.13.json was not written.
echo.
echo Step 2 of 2: the validation script, focused mode
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows513.ps1" -Focused %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-focused-validation-5.13.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.11, 5.12 and 5.13 sections have not run on a physical Windows PC before this release; please keep the report files and the text above. The self-test result of step 1 stands on its own.
if not exist "Windows-focused-validation-5.13.json" echo NOTE: Windows-focused-validation-5.13.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
