@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.10 focused validation on this Windows PC: what 5.10 added or changed in the trainer.
echo   - the experimental estimator "rbes": the exact expectation of its regret and average-strategy increments
echo     against a brute-force walk of the whole betting tree (no statistics involved)
echo   - the default trainer: the states of 5.9, byte for byte, with 1, 2, 4, 8 and all logical processors
echo   - rbes: one state for every thread count, the state of the Linux build; stop and continue; checkpoint rules
echo   - reference fixtures: exact NashConv of both trainers after a fixed budget
echo   - the key caches (memory layout) on and off: the same states
echo   - unsupported configurations refused; the table limit stops cleanly and is resumable
echo No GPU test. Nothing is installed. This takes about 4 to 10 minutes.
echo Saved studies are not touched: everything is written to a temporary folder, which is removed at the end.
echo Reports are written into this folder:
echo   Windows-selftest510-5.10.json          the checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-focused-validation-5.10.json   every check, with its status and its evidence
echo   Windows-focused-validation-5.10.txt    the same as text
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest510-5.10.json" del /q "Windows-selftest510-5.10.json"
if exist "Windows-focused-validation-5.10.json" del /q "Windows-focused-validation-5.10.json"
if exist "Windows-focused-validation-5.10.txt" del /q "Windows-focused-validation-5.10.txt"
echo Step 1 of 2: mwcli.exe --selftest510
set "em_st=%TEMP%\EightMax-5.10-selftest510-%RANDOM%%RANDOM%"
mwcli.exe --selftest510 "studies" "%em_st%" all
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest510.json" copy /y "%em_st%\selftest510.json" "Windows-selftest510-5.10.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.10: every check passed.) else (echo Self-test 5.10: exit status %selftest_result%: a check failed or could not be made. See Windows-selftest510-5.10.json.)
rem A self-test that ends with status 0 but wrote no report has not shown anything: that is not a pass.
if not exist "Windows-selftest510-5.10.json" if "%selftest_result%"=="0" set "selftest_result=2"
if not exist "Windows-selftest510-5.10.json" echo NOTE: Windows-selftest510-5.10.json was not written.
echo.
echo Step 2 of 2: the validation script, focused mode
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows510.ps1" -Focused %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-focused-validation-5.10.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.10 sections have not run on Windows before this release; please keep the report files and the text above. The self-test result of step 1 stands on its own.
if not exist "Windows-focused-validation-5.10.json" echo NOTE: Windows-focused-validation-5.10.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
