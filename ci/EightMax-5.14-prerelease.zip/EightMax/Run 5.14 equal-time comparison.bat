@echo off
cd /d "%~dp0"
echo EightMax 5.14: equal-training-time experiments on this PC (eqtime.exe).
echo   part 1, pruning: the default trainer against the two pruning algorithms, 20 games, exact NashConv
echo   part 2, threads: rbes on one thread against rbes with frozen batches on 8 threads, 6 games
echo   part 3, scaling: sampled deals per second by batch size and thread count on two fixtures
echo This takes about two to two and a half hours. Close other heavy programs and leave the PC alone.
echo It can be interrupted: start it again and it continues with the units that are missing.
echo Nothing is installed and no GPU is used. The rules are in CONVERGENCE-5.14.md and in each plan.json.
echo.
eqtime.exe all %*
set "eq_result=%errorlevel%"
echo.
echo Exit status: %eq_result%
echo Send back the folder equal-time-results without its "units" subfolders:
echo   pruning\summary.txt summary.json raw.jsonl plan.json machine.txt, the same five of threads,
echo   scaling\scaling.txt and scaling.json.
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eq_result%
