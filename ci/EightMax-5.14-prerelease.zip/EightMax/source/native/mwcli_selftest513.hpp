// EightMax 5.13 (Phase 3, satellites): mwcli --selftest513 <studies-dir> <work-dir> [all|model|fixtures|training|closed|checkpoint]
//
//   model       the satellite-field payoff model satfield-5.13-v1 (satfield513.hpp), in this process:
//                 M1  satExp against the library exponential on 200,001 points of [-700, 0] (relative difference at
//                     most 1e-15), exact at 0, monotone;
//                 M2  small fields: the model against the program's EXACT Malmuth-Harville recursion with N equal
//                     prizes (icm.hpp), 400 random fields of at most 16 players: at most 1e-9 per player;
//                 M3  the values of all players of a field add up to the number of seats (five fields up to 2,000 players);
//                 M4  the values recorded from the Linux build, bit for bit (the model uses no library function, so
//                     every platform must compute the same bits);
//                 M5  what the model refuses: no seats, more seats than players at other tables, an empty or oversized field.
//   fixtures    F1  the six satellite fixtures are present; every variant's native specification is accepted;
//               F2  the engine reaches the advertised decision of every variant (seat, pot, legal actions).
//   training    T1  recorded states (SHA-256 from the Linux build): both kinds of streams, one deal per update and
//                   frozen batches on three threads;
//               T2  satellite-field companion: 1 thread = 3 threads; stopped and continued = uninterrupted;
//               T3  exact NashConv of the small fixtures after a fixed budget, as recorded (one seed; no convergence claim).
//   closed      K1  known-sat-akq-river: the value of folding equals the closed form; the trained calling frequency
//                   is within 0.02 of the closed form c = 1 - C/B computed with the exact recursion in this process;
//               K2  sat3-fold-aces: the value of folding equals the closed form (exact recursion), the value of
//                   calling is the recorded one, and folding aces is worth more than calling;
//               K3  one bubble spot specified twice - ordinary ICM with six equal prizes among twelve players, and
//                   the satellite-field model with the same nine other stacks as its field: the exact action values
//                   of the hero agree to 1e-8 and the exact NashConv of the same strategy to 1e-7.
//   checkpoint  C1  a satellite-field state names its payoff model, seats and field in the header and is refused,
//                   with the reason and nothing written, by the ordinary ICM, by another number of seats and by
//                   another field; an ordinary state is refused by the satellite-field model; a continued
//                   satellite-field training equals the uninterrupted one.
// Report: <work-dir>/selftest513.json. Exit status: 0 every check passed, 1 a check failed or is untested, 2 usage.
//   mwcli --selftest513 studies work record   writes selftest513_golden.hpp, selftest513_reference.hpp and
//                                             selftest513_values.hpp from THIS build (once, on Linux, at release).
#pragma once
namespace st513 {
namespace fs = std::filesystem;
using st58::Report; using st58::fmt; using st58::sci; using st58::get; using st58::num; using st58::str; using st58::Doc; using st58::take; using st58::specOf;
using st510::isTrue; using st510::withOptions; using st510::writeText; using st510::Trained; using st510::train; using st510::exactNashConv; using st510::BATCH;
using st512::readText; using st512::join; using st512::optionsOf;
static const char *const SAT[] = {"sat5-bubble-bb-call", "sat5-bubble-bb-call-small", "satfield-bb-call", "satfield-bb-call-small", "known-sat-akq-river", "sat3-fold-aces"};
struct Golden513 { const char *fixture; long long updates; bool batch, wide; const char *sha; };
static const Golden513 GOLDEN513[] = {
#include "selftest513_golden.hpp"
};
struct Reference513 { const char *fixture; long long updates; bool wide; double nash; };
static const Reference513 REFERENCE513[] = {
#include "selftest513_reference.hpp"
};
// recorded bits: the model's values for the cases of valueCases(), and the two action values of sat3-fold-aces
static const char *const VALUES513[] = {
#include "selftest513_values.hpp"
};
static std::string bits(double x) { unsigned long long u; std::memcpy(&u, &x, 8); char h[20]; std::snprintf(h, sizeof h, "%016llx", u); return h; }
struct Lcg { unsigned long long s; double next() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return (double)(s >> 11) / 9007199254740992.0; } };
// the exact recursion with N equal prizes: values of the first n of `stacks`
static void exactTopN(const std::vector<double> &stacks, int seats, int n, double *out) {
  Tournament t; t.start = stacks; t.others.assign(stacks.begin() + n, stacks.end()); t.payout.assign((size_t)seats, 1.0);
  Tournament::Workspace ws; t.prepare(ws, 16 * 1048576.0); for (int i = 0; i < n; i++) out[i] = stacks[(size_t)i]; t.evaluate(out, n, ws);
}
struct Case { int seats; std::vector<double> table; std::vector<std::pair<double, int>> groups; };
static std::vector<Case> valueCases() {
  std::vector<Case> c;
  c.push_back({3, {10, 20}, {{15, 4}}});
  c.push_back({40, {39.9, 0, 0}, {{8, 24}, {18, 38}, {30, 34}, {52, 22}, {21.9, 1}, {8.9, 1}, {30.9, 1}}});
  c.push_back({40, {22, 12, 35.9}, {{25.25, 121}}});
  c.push_back({1, {0.3, 900}, {{25, 50}}});
  c.push_back({500, {3, 14, 25, 61, 75, 120, 0.5, 44}, {{4, 250}, {6.4, 250}, {10.24, 250}, {16.384, 250}, {26.2144, 250}, {41.94, 250}, {67.1, 250}, {107.4, 250}}});
  c.push_back({900, {25}, {{25, 2000}}});
  c.push_back({57, {1, 12}, {{0.5, 3}, {20, 56}, {400, 1}}});
  return c;
}
static std::vector<double> valuesOf(const Case &c, std::string &why) {
  sat513::Field f; f.seats = c.seats; f.groups = c.groups; why = f.prepare(); std::vector<double> v = c.table; if (why.empty()) f.evaluate(v.data(), (int)v.size()); return v;
}
static void modelSection(Report &R) {
  const std::string sec = "model";
  { double worst = 0; bool mono = true; double prev = 0;
    for (int i = 0; i <= 200000; i++) { const double x = -700.0 + 700.0 * i / 200000.0, a = sat513::satExp(x), b = std::exp(x); const double rel = std::fabs(a - b) / b; if (rel > worst) worst = rel; if (a < prev) mono = false; prev = a; }
    R.check(sec, "M1", "satExp (IEEE additions, multiplications and divisions only) against the library exponential on 200,001 points of [-700, 0]: relative difference at most 1e-15; exactly 1 at 0; never decreasing; 0 below -700", worst <= 1e-15 && sat513::satExp(0.0) == 1.0 && mono && sat513::satExp(-701.0) == 0.0, "largest relative difference " + sci(worst) + (mono ? "" : "; NOT monotone")); }
  { Lcg g{513}; double worst = 0; int cases = 0, bad = 0; std::string detail;
    for (int it = 0; it < 400; it++) {
      const int n = 1 + (int)(g.next() * 6), K = 2 + (int)(g.next() * (15 - n)), seats = 1 + (int)(g.next() * (K - 1)); std::vector<double> all; Case c; c.seats = seats;
      for (int i = 0; i < n; i++) { const double s = 0.3 + 90.0 * g.next() * g.next(); c.table.push_back(s); all.push_back(s); }
      for (int j = 0; j < K; j++) { const double s = 0.5 + 120.0 * g.next() * g.next(); c.groups.push_back({s, 1}); all.push_back(s); }
      std::string why; const std::vector<double> v = valuesOf(c, why); double ex[8]; exactTopN(all, seats, n, ex); cases++;
      for (int i = 0; i < n; i++) { const double e = why.empty() ? std::fabs(v[(size_t)i] - ex[i]) : 1; if (e > worst) worst = e; if (e > 1e-9) { bad++; if (detail.size() < 300) detail += "case " + std::to_string(it) + " seat " + std::to_string(i) + ": " + fmt(v[(size_t)i]) + " against " + fmt(ex[i]) + " " + why + "; "; } }
    }
    R.check(sec, "M2", "small fields: the model against the program's exact Malmuth-Harville recursion with N equal prizes, 400 random fields of 3 to 16 players (1 to 6 seats at the table): at most 1e-9 per player", bad == 0 && cases == 400, std::to_string(cases) + " fields, largest difference " + sci(worst) + (detail.empty() ? "" : "; " + detail)); }
  { // M3: sum over all players = seats
    struct S { int seats; std::vector<std::pair<double, int>> groups; }; const S sums[] = {{9, {{8, 13}, {25, 14}, {70, 13}}}, {60, {{2, 50}, {25, 50}, {90, 50}}}, {40, {{8, 24}, {18, 38}, {30, 34}, {52, 22}, {21.9, 1}, {8.9, 1}, {30.9, 1}, {39.9, 1}, {12, 1}, {18, 1}}}, {450, {{5, 300}, {20, 400}, {60, 200}}}, {1000, {{25, 1500}, {60, 500}}}};
    double worst = 0; std::string detail;
    for (const S &s : sums) { double total = 0; bool ok = true;
      for (size_t gi = 0; gi < s.groups.size(); gi++) { Case c; c.seats = s.seats; c.table = {s.groups[gi].first}; for (size_t j = 0; j < s.groups.size(); j++) { const int cnt = s.groups[j].second - (j == gi ? 1 : 0); if (cnt > 0) c.groups.push_back({s.groups[j].first, cnt}); }
        std::string why; const std::vector<double> v = valuesOf(c, why); if (!why.empty()) { ok = false; detail += why + "; "; break; } total += s.groups[gi].second * v[0]; }
      const double e = ok ? std::fabs(total - s.seats) / s.seats : 1; if (e > worst) worst = e; }
    R.check(sec, "M3", "the values of all players of a field add up to the number of seats (five fields of 40 to 2,000 players; relative error at most 1e-9)", worst <= 1e-9, "largest relative error " + sci(worst) + (detail.empty() ? "" : "; " + detail)); }
  { const std::vector<Case> cs = valueCases(); int same = 0, total = 0; size_t at = 0; std::string detail; const size_t have = std::size(VALUES513);
    for (size_t k = 0; k < cs.size(); k++) { std::string why; const std::vector<double> v = valuesOf(cs[k], why);
      for (size_t i = 0; i < v.size(); i++, at++) { total++; const std::string b = why.empty() ? bits(v[i]) : "refused"; if (at < have && b == VALUES513[at]) same++; else if (detail.size() < 300) detail += "case " + std::to_string(k) + " seat " + std::to_string(i) + ": " + b + " instead of " + (at < have ? VALUES513[at] : "(not recorded)") + "; "; } }
    R.check(sec, "M4", "the values recorded from the Linux build of this release, bit for bit (seven fields of 4 to 2,000 players, 21 values; a table seat without chips is worth 0)", same == total && total == 21, std::to_string(same) + " of " + std::to_string(total) + " values identical" + (detail.empty() ? "" : "; " + detail)); }
  { struct B { Case c; const char *want; }; const B bad[] = {{{0, {10}, {{25, 9}}}, "seats must be"}, {{9, {10}, {{25, 9}}}, "more players than there are seats"}, {{3, {10}, {}}, "1 to 5000"}, {{3, {10}, {{25, 6000}}}, "1 to 5000"}, {{1900, {10}, {{25, 4000}}}, "must not exceed"}, {{3, {10}, {{-5, 9}}}, "positive stack"}};
    int ok = 0; std::string detail; for (const B &b : bad) { std::string why; valuesOf(b.c, why); if (why.find(b.want) != std::string::npos) ok++; else detail += std::string("expected \"") + b.want + "\", got \"" + why + "\"; "; }
    R.check(sec, "M5", "refused with a reason: no seats, as many seats as players at other tables, an empty field, more than 5,000 players, players x seats above 2,000,000, a stack that is not positive", ok == (int)std::size(bad), std::to_string(ok) + " of " + std::to_string(std::size(bad)) + (detail.empty() ? "" : "; " + detail)); }
}
static void fixturesSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "fixtures"; std::error_code ec; int ok1 = 0, n1 = 0, ok2 = 0, n2 = 0, variantsAll = 0, fieldVariants = 0; std::string d1, d2;
  for (const char *id : SAT) {
    n1++; const std::string text = readText((fs::path(studies) / (std::string(id) + ".emfix.json")).string()); Doc fx(text); const JV *vs = get(fx.v, "variants");
    if (!fx.v || !vs || vs->type != J_ARR || vs->n == 0) { d1 += std::string(id) + ": missing or unreadable; "; n2++; continue; }
    bool good = str(get(fx.v, "id")) == id; std::string bad;
    for (int v = 0; v < vs->n; v++) {
      variantsAll++; const JV *sp = get(vs->items[v], "nativeSpec"); const std::string name = str(get(vs->items[v], "name")), spec = sp ? jvText(sp) : ""; char err[512] = "";
      MW *m = spec.empty() ? nullptr : mw_create(spec.c_str(), spec.size(), 512, err, sizeof err);
      if (!m) { good = false; bad += name + ": refused by the engine: " + err + ", "; } else mw_free(m);
      if (str(get(get(sp, "icm"), "model")) == "satellite-field") fieldVariants++;
      n2++; const JV *dec = get(vs->items[v], "decision"), *path = get(dec, "path"), *acts = get(dec, "actions");
      const std::string sf = (fs::path(work) / "f2.spec.json").string(), stf = (fs::path(work) / "f2.state").string(), qf = (fs::path(work) / "f2.request.json").string();
      if (spec.empty() || !path || path->type != J_ARR || !acts || acts->type != J_ARR || !writeText(sf, spec)) { d2 += std::string(id) + "/" + name + ": no decision in the fixture; "; continue; }
      const Trained t = train(self, work, sf, 1, 1, stf, "", "1024"); writeText(qf, "{\"path\":" + jvText(path) + ",\"board\":[],\"limit\":1326}");
      const ckpt::Run r = t.ok ? ckpt::spawn({self, "--node", sf, stf, qf, "1024"}, work, 600) : ckpt::Run{}; Doc d(r.out); const JV *node = get(d.v, "node"), *got = get(d.v, "actions");
      bool same = t.ok && r.exitCode == 0 && str(get(node, "kind")) == "decision" && num(get(node, "actor"), -1) == num(get(dec, "seat"), -2) && std::fabs(num(get(node, "pot")) - num(get(dec, "potBB"))) < 1e-9 && got && got->type == J_ARR && got->n == acts->n;
      for (int a = 0; same && a < acts->n; a++) same = str(get(got->items[a], "name")) == str(get(acts->items[a], "name")) && std::fabs(num(get(got->items[a], "to"), 0) - num(get(acts->items[a], "to"), 0)) < 1e-9;
      ok2 += same; if (!same) d2 += std::string(id) + "/" + name + ": " + (t.ok ? "the engine's node differs from the fixture's decision " + r.err.substr(0, 120) : "one update could not be trained: " + t.err) + "; ";
      fs::remove(sf, ec); fs::remove(stf, ec); fs::remove(qf, ec);
    }
    ok1 += good; if (!good) d1 += std::string(id) + ": " + bad + "; ";
  }
  R.check(sec, "F1", "the six satellite fixtures are present and every variant's native specification is accepted by the engine (five variants use the satellite-field payoff model, the others the ordinary ICM with equal prizes or chips)", ok1 == n1 && n1 == 6 && fieldVariants == 5, std::to_string(ok1) + " of " + std::to_string(n1) + " fixtures, " + std::to_string(variantsAll) + " variants, " + std::to_string(fieldVariants) + " with the satellite-field model" + (d1.empty() ? "" : "; " + d1));
  R.check(sec, "F2", "the engine reaches the advertised decision of every variant: the hero seat is to act, the pot is the advertised pot, the legal actions are the advertised ones", ok2 == n2 && n2 > 0, std::to_string(ok2) + " of " + std::to_string(n2) + " variants" + (d2.empty() ? "" : "; " + d2));
}
struct Fx { std::string spec, path; int hand = -1; };
static Fx fixtureOf(const std::string &studies, const std::string &work, const std::string &name, const std::string &options, const std::string &tag, std::string &why, int variant = 0) {
  Fx f; const std::string text = readText((fs::path(studies) / (name + ".emfix.json")).string()); Doc fx(text); const JV *vs = get(fx.v, "variants");
  if (!vs || vs->type != J_ARR || vs->n <= variant) { why = "cannot read " + name; return f; }
  const JV *sp = get(vs->items[variant], "nativeSpec"), *dec = get(vs->items[variant], "decision"); if (!sp) { why = "no nativeSpec"; return f; }
  f.path = (fs::path(work) / (name + "-" + tag + ".spec.json")).string(); f.spec = withOptions(jvText(sp), options); if (!writeText(f.path, f.spec)) { why = "cannot write " + f.path; f.path.clear(); }
  f.hand = (int)num(get(dec, "handIndex"), -1); return f;
}
static void trainingSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "training"; std::error_code ec; auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); };
  const std::vector<std::pair<std::string, std::string>> fixed = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
  { int same = 0, total = 0; std::string detail;
    for (const Golden513 &g : GOLDEN513) { total++; std::string why; const Fx f = fixtureOf(studies, work, g.fixture, optionsOf(g.wide, g.batch), "t1", why); if (f.path.empty()) { detail += std::string(g.fixture) + ": " + why + "; "; continue; }
      const Trained t = train(self, work, f.path, g.updates, g.batch ? 3 : 1, state("t1"), "", "512", fixed);
      if (t.ok && t.sha == g.sha) same++; else detail += std::string(g.fixture) + (g.wide ? " philox64" : " 5.10 streams") + (g.batch ? " (batch)" : "") + ": " + (t.ok ? "state " + t.sha.substr(0, 16) + " instead of " + std::string(g.sha).substr(0, 16) : "exit " + std::to_string(t.exitCode) + " " + t.err) + "; ";
      fs::remove(f.path, ec); }
    R.check(sec, "T1", "satellite fixtures: the saved states have the SHA-256 recorded from the Linux build of this release (ordinary ICM with equal prizes and the satellite-field model; 5.10 streams and philox64; one deal per update and frozen batches of 64 on three threads)", same == total && total > 0, std::to_string(same) + " of " + std::to_string(total) + " states identical" + (detail.empty() ? "" : "; " + detail)); }
  { int good = 0, n = 0; std::string detail;
    for (const char *name : {"satfield-bb-call-small", "sat5-bubble-bb-call-small"}) for (const bool wide : {false, true}) {
      n++; std::string why; const Fx f = fixtureOf(studies, work, name, optionsOf(wide, false), "t2", why), fb = fixtureOf(studies, work, name, optionsOf(wide, true), "t2b", why); if (f.path.empty() || fb.path.empty()) { detail += why + "; "; continue; }
      const Trained a = train(self, work, f.path, 9000, 1, state("t2a")), p = train(self, work, f.path, 3000, 1, state("t2p")), c = p.ok ? train(self, work, f.path, 6000, 1, state("t2c"), state("t2p")) : Trained{};
      const Trained b1 = train(self, work, fb.path, 150, 1, state("t2d"), "", "512", fixed), b3 = train(self, work, fb.path, 150, 3, state("t2e"), "", "512", fixed), bp = train(self, work, fb.path, 50, 2, state("t2f"), "", "512", fixed), bc = bp.ok ? train(self, work, fb.path, 100, 3, state("t2g"), state("t2f"), "512", fixed) : Trained{};
      const bool ok = a.ok && c.ok && b1.ok && b3.ok && bc.ok && c.sha == a.sha && b1.sha == b3.sha && bc.sha == b1.sha; good += ok;
      if (!ok) detail += std::string(name) + (wide ? " philox64" : " 5.10 streams") + ": continued " + (c.sha == a.sha ? "same" : "DIFFERENT") + ", 3 threads " + (b1.sha == b3.sha ? "same" : "DIFFERENT") + ", batch continued " + (bc.sha == b1.sha ? "same" : "DIFFERENT") + " " + a.err + c.err + b1.err + "; ";
      fs::remove(f.path, ec); fs::remove(fb.path, ec); }
    R.check(sec, "T2", "satellite companions: a frozen batch gives the same state on 1 and 3 threads; stopped after a third and continued = uninterrupted, byte for byte; 5.10 streams and philox64; the satellite-field model and the ordinary ICM", good == n && n > 0, std::to_string(good) + " of " + std::to_string(n) + " configurations" + (detail.empty() ? "" : "; " + detail)); }
  { int okc = 0, total = 0; std::string detail;
    for (const Reference513 &ref : REFERENCE513) { total++; std::string why; const Fx f = fixtureOf(studies, work, ref.fixture, optionsOf(ref.wide, false), "t3", why); if (f.path.empty()) { detail += why + "; "; continue; }
      const Trained a = train(self, work, f.path, ref.updates, 1, state("t3")); double nc = NAN; if (a.ok) nc = exactNashConv(self, work, f.path, state("t3"), why);
      const bool good = std::isfinite(nc) && std::fabs(nc - ref.nash) <= 1e-9 * std::max({1.0, std::fabs(nc), std::fabs(ref.nash)}); okc += good;
      detail += std::string(ref.fixture) + (ref.wide ? " philox64" : " 5.10 streams") + ": exact NashConv " + sci(nc) + (good ? "" : " (recorded " + sci(ref.nash) + ") " + why + a.err) + "; "; fs::remove(f.path, ec); }
    R.check(sec, "T3", "satellite companions and the closed-form game: the exact NashConv of the trained strategy after a fixed budget equals the value recorded at release, in seat probability (a regression check; one seed each, no convergence claim)", okc == total && total > 0, std::to_string(okc) + " of " + std::to_string(total) + " reproduce the recorded value; " + detail); }
  for (const char *t : {"t1", "t2a", "t2p", "t2c", "t2d", "t2e", "t2f", "t2g", "t3"}) fs::remove(state(t), ec);
}
// exact action values of the hero hand at the fixture's decision (policy: average)
static bool actionValues(const std::string &self, const std::string &work, const std::string &studies, const std::string &name, const std::string &spec, const std::string &st, double *ev, double *freq, int want, std::string &why) {
  const std::string text = readText((fs::path(studies) / (name + ".emfix.json")).string()); Doc fx(text); const JV *vs = get(fx.v, "variants"); const JV *dec = vs && vs->type == J_ARR && vs->n ? get(vs->items[0], "decision") : nullptr; if (!dec) { why = "no decision"; return false; }
  const std::string q = (fs::path(work) / "ev513.json").string(); writeText(q, "{\"path\":" + jvText(get(dec, "path")) + ",\"board\":[],\"hands\":[" + std::to_string((int)num(get(dec, "handIndex"), 0)) + "],\"method\":\"exact\",\"policy\":\"average\"}");
  const ckpt::Run r = ckpt::spawn({self, "--ev", spec, st, q, "512"}, work, 900); std::error_code ec; fs::remove(q, ec); Doc d(r.out); const JV *hs = get(d.v, "hands"); const JV *h = hs && hs->type == J_ARR && hs->n ? hs->items[0] : nullptr; const JV *e = get(h, "ev"), *s = get(h, "strategy");
  if (r.exitCode != 0 || !e || e->type != J_ARR || e->n != want || !s || s->type != J_ARR || s->n != want) { why = "exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 200); return false; }
  for (int i = 0; i < want; i++) { ev[i] = num(e->items[i]); freq[i] = num(s->items[i]); } return true;
}
static void closedSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "closed"; std::error_code ec; auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); };
  auto v3 = [](double a, double b, double c) { if (!(a > 0)) return 0.0; std::vector<double> s{a}; if (b > 0) s.push_back(b); if (c > 0) s.push_back(c); double out[8]; exactTopN(s, std::min<int>(2, (int)s.size()), 1, out); return out[0]; };
  { std::string why; const Fx f = fixtureOf(studies, work, "known-sat-akq-river", "", "k1", why); double ev[2] = {NAN, NAN}, fr[2] = {NAN, NAN};
    const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 2000000, 1, state("k1")); const bool got = t.ok && actionValues(self, work, studies, "known-sat-akq-river", f.path, state("k1"), ev, fr, 2, why);
    const double F = v3(10, 20, 12), B = v3(20, 10, 12), c = 1 - F / B, q = F / (4 * (1 - F));
    R.check(sec, "K1", "known-sat-akq-river (three left, two seats): the exact value of folding equals the closed form F = v(10, 20, 12); after 2,000,000 deals the kings call within 0.02 of the closed form c = 1 - F / v(20, 10, 12), and calling is worth F within 0.005 (indifference)", got && std::fabs(ev[0] - F) <= 1e-9 && std::fabs(fr[1] - c) <= 0.02 && std::fabs(ev[1] - F) <= 0.005,
            got ? "fold " + fmt(ev[0]) + " (closed form " + fmt(F) + "); call frequency " + fmt(fr[1]) + " (closed form " + fmt(c) + "); value of calling " + fmt(ev[1]) + "; closed-form bluffing frequency of the queens " + fmt(q) : "not evaluated: " + why + t.err);
    if (!f.path.empty()) fs::remove(f.path, ec); }
  { std::string why; const Fx f = fixtureOf(studies, work, "sat3-fold-aces", "", "k2", why); double ev[2] = {NAN, NAN}, fr[2];
    const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 100, 1, state("k2")); const bool got = t.ok && actionValues(self, work, studies, "sat3-fold-aces", f.path, state("k2"), ev, fr, 2, why);
    const double F = v3(23.9, 31.2, 1.9); const size_t n = std::size(VALUES513); const std::string wantCall = n >= 1 ? VALUES513[n - 1] : "";
    R.check(sec, "K2", "sat3-fold-aces (three left, two seats, aces against an all-in with kings): the exact value of folding equals the closed form v(23.9, 31.2, 1.9); the value of calling has the bits recorded from the Linux build; folding is worth more", got && std::fabs(ev[0] - F) <= 1e-9 && bits(ev[1]) == wantCall && ev[0] > ev[1],
            got ? "fold " + fmt(ev[0]) + " (closed form " + fmt(F) + "); call " + fmt(ev[1]) + " (" + bits(ev[1]) + (bits(ev[1]) == wantCall ? "" : ", recorded " + wantCall) + ")" : "not evaluated: " + why + t.err);
    if (!f.path.empty()) fs::remove(f.path, ec); }
  { // K3: one spot, two specifications
    std::string why; const Fx base = fixtureOf(studies, work, "sat5-bubble-bb-call-small", "", "k3", why); const size_t at = base.spec.find("\"icm\":{"); size_t end = at == std::string::npos ? at : base.spec.find('}', at);
    if (base.path.empty() || at == std::string::npos || end == std::string::npos) R.add(sec, "K3", "one bubble spot under the ordinary ICM and under the satellite-field model", "untested", why.empty() ? "the fixture has no icm object" : why);
    else {
      const char *others = "21.9,13.9,8,11.5,17,24,29.5,36,47", *field = "[21.9,1],[13.9,1],[8,1],[11.5,1],[17,1],[24,1],[29.5,1],[36,1],[47,1]"; Doc sp(base.spec); const JV *start = get(get(sp.v, "icm"), "start"); std::string st3;
      for (int i = 0; start && start->type == J_ARR && i < 3 && i < start->n; i++) st3 += (i ? "," : "") + fmt(num(start->items[i]));
      const std::string head = base.spec.substr(0, at), tail = base.spec.substr(end + 1);
      const std::string ordinary = head + "\"icm\":{\"start\":[" + st3 + "," + others + "],\"others\":[" + others + "],\"payouts\":[1,1,1,1,1,1]}" + tail, model = head + "\"icm\":{\"model\":\"satellite-field\",\"seats\":6,\"start\":[" + st3 + "],\"field\":[" + field + "]}" + tail;
      const std::string fo = (fs::path(work) / "k3-ordinary.spec.json").string(), fm = (fs::path(work) / "k3-field.spec.json").string(); writeText(fo, ordinary); writeText(fm, model);
      // one update leaves the average strategy uniform under both utilities: the same strategy, evaluated twice
      const Trained a = train(self, work, fo, 1, 1, state("k3o")), b = train(self, work, fm, 1, 1, state("k3m")); double e1[2], e2[2], f1[2], f2[2];
      const bool g1 = a.ok && actionValues(self, work, studies, "sat5-bubble-bb-call-small", fo, state("k3o"), e1, f1, 2, why), g2 = b.ok && actionValues(self, work, studies, "sat5-bubble-bb-call-small", fm, state("k3m"), e2, f2, 2, why);
      std::string w1, w2; const double n1 = a.ok ? exactNashConv(self, work, fo, state("k3o"), w1) : NAN, n2 = b.ok ? exactNashConv(self, work, fm, state("k3m"), w2) : NAN;
      const double de = g1 && g2 ? std::max(std::fabs(e1[0] - e2[0]), std::fabs(e1[1] - e2[1])) : NAN;
      R.check(sec, "K3", "one bubble spot specified twice - the ordinary ICM with six equal prizes among twelve players, and the satellite-field model with the same nine other stacks as its field: the exact action values of the hero agree to 1e-8 and the exact NashConv of the same (uniform) strategy to 1e-7", g1 && g2 && de <= 1e-8 && f1[0] == f2[0] && std::isfinite(n1) && std::fabs(n1 - n2) <= 1e-7,
              g1 && g2 ? "fold " + fmt(e1[0]) + " / " + fmt(e2[0]) + ", call " + fmt(e1[1]) + " / " + fmt(e2[1]) + ": largest difference " + sci(de) + "; exact NashConv " + fmt(n1) + " / " + fmt(n2) + ", difference " + sci(std::fabs(n1 - n2)) : "not evaluated: " + why + a.err + b.err + w1 + w2);
      for (const std::string &x : {fo, fm, base.path}) fs::remove(x, ec);
    } }
  for (const char *t : {"k1", "k2", "k3o", "k3m"}) fs::remove(state(t), ec);
}
static void checkpointSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "checkpoint"; std::error_code ec; std::string why; auto p = [&](const char *n) { return (fs::path(work) / n).string(); };
  const Fx f = fixtureOf(studies, work, "satfield-bb-call-small", "", "c1", why), avg = fixtureOf(studies, work, "satfield-bb-call-small", "", "c1avg", why, 1), ord = fixtureOf(studies, work, "sat5-bubble-bb-call-small", "", "c1ord", why);
  if (f.path.empty() || avg.path.empty() || ord.path.empty()) { R.add(sec, "C1", "checkpoint rules of the satellite-field payoff model", "untested", why); return; }
  // the same study with 39 seats: the spec text with "seats":40 replaced (the header rule is checked before the study identifier)
  std::string s40 = f.spec, s39 = s40, savg = avg.spec, sord = ord.spec; const size_t at = s39.find("\"seats\":40"); if (at != std::string::npos) s39.replace(at, 10, "\"seats\":39");
  writeText(p("c40.json"), s40); writeText(p("c39.json"), s39); writeText(p("cavg.json"), savg); writeText(p("cord.json"), sord);
  const Trained a = train(self, work, p("c40.json"), 3000, 1, p("c40.state")), o = train(self, work, p("cord.json"), 3000, 1, p("cord.state"));
  const std::vector<unsigned char> raw = slurp(p("c40.state").c_str()); const std::string head(raw.begin(), raw.begin() + std::min<size_t>(raw.size(), 600));
  const bool named = head.find("\"payoffModel\":\"satfield-5.13-v1\"") != std::string::npos && head.find("\"satelliteSeats\":40") != std::string::npos && head.find("\"satelliteFieldPlayers\":121") != std::string::npos;
  const std::vector<unsigned char> rawo = slurp(p("cord.state").c_str()); const bool plain = std::string(rawo.begin(), rawo.begin() + std::min<size_t>(rawo.size(), 600)).find("payoffModel") == std::string::npos;
  struct Try { const char *spec, *in, *want; }; const Try tries[] = {{"c39.json", "c40.state", "another satellite"}, {"cavg.json", "c40.state", "another satellite"}, {"cord.json", "c40.state", "satellite-field payoff model"}, {"c40.json", "cord.state", "not trained under the satellite-field"}};
  int refused = 0; std::string detail;
  for (const Try &t : tries) { const std::string out = p("no.state"); fs::remove(out, ec); const Trained r = train(self, work, p(t.spec), 5, 1, out, p(t.in)); const bool ok = !r.ok && r.exitCode == 1 && r.err.find(t.want) != std::string::npos && !fs::exists(out, ec); refused += ok; if (!ok) detail += std::string(t.spec) + " <- " + t.in + ": exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 160) + "; "; }
  const Trained c = a.ok ? train(self, work, p("c40.json"), 3000, 1, p("c40b.state"), p("c40.state")) : Trained{}, u = train(self, work, p("c40.json"), 6000, 1, p("c40u.state"));
  R.check(sec, "C1", "a satellite-field state names its payoff model, seats and field in the header (an ordinary ICM state names none) and is refused, with the reason, exit 1 and nothing written, by another number of seats, by another field and by the ordinary ICM; an ordinary state is refused by the satellite-field model; a continued satellite-field training equals the uninterrupted one", a.ok && o.ok && named && plain && refused == 4 && c.ok && u.ok && c.sha == u.sha,
          std::string("header: ") + (named ? "names the model" : "DOES NOT name the model") + "; ordinary header: " + (plain ? "no payoff model" : "NAMES ONE") + "; refused " + std::to_string(refused) + " of 4; continued " + (c.sha == u.sha && c.ok ? "= uninterrupted" : "DIFFERS") + (detail.empty() ? "" : "; " + detail) + a.err + o.err);
  for (const char *n : {"c40.json", "c39.json", "cavg.json", "cord.json", "c40.state", "cord.state", "c40b.state", "c40u.state", "no.state"}) fs::remove(p(n), ec);
  for (const std::string &x : {f.path, avg.path, ord.path}) fs::remove(x, ec);
}
static int record(const std::string &studies, const std::string &work, const std::string &self) {
  std::error_code ec; std::string golden, reference, values, why; int bad = 0, count = 0; auto p = [&](const char *n) { return (fs::path(work) / n).string(); };
  const std::vector<std::pair<std::string, std::string>> fixed = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
  struct G { const char *fixture; long long updates, batchUpdates; }; const G plan[] = {{"sat5-bubble-bb-call-small", 9000, 150}, {"satfield-bb-call-small", 9000, 150}, {"known-sat-akq-river", 20000, 300}, {"sat3-fold-aces", 2000, 40}, {"sat5-bubble-bb-call", 1500, 30}, {"satfield-bb-call", 1500, 30}};
  for (const G &g : plan) for (const bool wide : {false, true}) for (const bool batch : {false, true}) {
    const Fx f = fixtureOf(studies, work, g.fixture, optionsOf(wide, batch), "record", why); const long long updates = batch ? g.batchUpdates : g.updates;
    const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, updates, batch ? 3 : 1, p("record.state"), "", "512", fixed); bad += !t.ok; count++;
    golden += std::string("{\"") + g.fixture + "\", " + std::to_string(updates) + ", " + (batch ? "true" : "false") + ", " + (wide ? "true" : "false") + ", \"" + (t.ok ? t.sha : "FAILED") + "\"},\n"; if (!f.path.empty()) fs::remove(f.path, ec); }
  for (const char *id : {"sat5-bubble-bb-call-small", "satfield-bb-call-small", "known-sat-akq-river"}) for (const bool wide : {false, true}) {
    const Fx f = fixtureOf(studies, work, id, optionsOf(wide, false), "record", why); const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 20000, 1, p("record.state")); const double nc = t.ok ? exactNashConv(self, work, f.path, p("record.state"), why) : NAN; bad += !std::isfinite(nc); count++;
    reference += std::string("{\"") + id + "\", 20000, " + (wide ? "true" : "false") + ", " + fmt(nc) + "},\n"; if (!f.path.empty()) fs::remove(f.path, ec); }
  for (const Case &c : valueCases()) { const std::vector<double> v = valuesOf(c, why); bad += !why.empty(); for (double x : v) { values += "\"" + bits(x) + "\",\n"; count++; } }
  { const Fx f = fixtureOf(studies, work, "sat3-fold-aces", "", "record", why); double ev[2] = {NAN, NAN}, fr[2]; const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 100, 1, p("record.state"));
    const bool got = t.ok && actionValues(self, work, studies, "sat3-fold-aces", f.path, p("record.state"), ev, fr, 2, why); bad += !got; values += "\"" + bits(ev[1]) + "\"\n"; count++; if (!f.path.empty()) fs::remove(f.path, ec); }
  fs::remove(p("record.state"), ec);
  writeText(p("selftest513_golden.hpp"), golden); writeText(p("selftest513_reference.hpp"), reference); writeText(p("selftest513_values.hpp"), values);
  std::printf("{\"recorded\":%d,\"failed\":%d}\n", count, bad); return bad ? 1 : 0;
}
static int run(int argc, char **argv) {
  if (argc < 4 || argc > 5) { std::fprintf(stderr, "usage: mwcli --selftest513 studies-dir work-dir [all|model|fixtures|training|closed|checkpoint]\n"); return 2; }
  const std::string studies = argv[2], work = argv[3], section = argc > 4 ? argv[4] : "all"; std::error_code ec; fs::create_directories(work, ec); mw_study_identity(EM_VERSION, EM_BUILD_ID);
  if (section == "record") return record(fs::absolute(studies, ec).string(), fs::absolute(work, ec).string(), ckpt::selfPath(argv[0]));
  if (section != "all" && section != "model" && section != "fixtures" && section != "training" && section != "closed" && section != "checkpoint") { std::fprintf(stderr, "error: the section must be all, model, fixtures, training, closed or checkpoint\n"); return 2; }
  if (!fs::is_directory(studies, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: studies-dir and work-dir must be directories\n"); return 2; }
  Report R; const auto t0 = std::chrono::steady_clock::now(); const std::string S = fs::absolute(studies, ec).string(), W = fs::absolute(work, ec).string(), self = ckpt::selfPath(argv[0]);
  if (section == "all" || section == "model") modelSection(R);
  if (section == "all" || section == "fixtures") fixturesSection(R, S, W, self);
  if (section == "all" || section == "training") trainingSection(R, S, W, self);
  if (section == "all" || section == "closed") closedSection(R, S, W, self);
  if (section == "all" || section == "checkpoint") checkpointSection(R, S, W, self);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest513\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"" + section + "\",\"payoffModel\":\"" + sat513::MODEL + "\",\"passed\":" + std::to_string(R.passed) + ",\"failed\":" + std::to_string(R.failed) + ",\"untested\":" + std::to_string(R.untested) + ",\"seconds\":" + fmt(secs) + ",\"checks\":[";
  for (size_t i = 0; i < R.checks.size(); i++) { const st58::Check &c = R.checks[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}"; const std::string report = (fs::path(work) / "selftest513.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest513\",\"build\":\"%s\",\"section\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"report\":%s}\n", EM_BUILD_ID, section.c_str(), R.passed, R.failed, R.untested, mwa::jsonEsc(report).c_str());
  return R.failed || R.untested ? 1 : 0;
}
}
