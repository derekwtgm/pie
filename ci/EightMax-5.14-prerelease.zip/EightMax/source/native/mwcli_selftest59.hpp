// EightMax 5.9: mwcli --selftest59 <studies-dir> <work-dir> [all|engine|statistics|response]
//
// What 5.9 added or changed in the mathematics of the trained-response measure, tested by the shipped program itself
// (nothing but mwcli is needed; "Run 5.9 Windows validation.bat" runs it and validate_windows59.ps1 imports its report
// check by check).
//
//   engine      mw_selftest59: the counter-based evaluation generator (Philox4x64-10) against the known-answer vectors
//               of its reference implementation; its inversion round by round (the bijection behind the stream
//               partition); one stream per (seat, block, purpose), a pure function of its address.
//   statistics  response_stats59.hpp without any game:
//                 S1  the one-sided empirical-Bernstein half-width and the standard-deviation bound against numbers
//                     computed by the independent Python implementation (tools/independent_stats59.py);
//                 S2  EXACT miss probabilities on two-point distributions (binomial sums, no simulation): the
//                     distribution-free bound never misses more often than its level, on 117 cases from a rare large
//                     value (probability 1e-6) to a rare small one;
//                 S3  the same sums for the 5.8 normal-approximation bound: it exceeds the true mean with probability
//                     above 0.8 where a small value is rare - the reason it is no longer presented as a confidence
//                     statement;
//                 S4  the simultaneous statement: reference numbers, the per-seat error budget, the floor at 0, a seat
//                     without evaluation (trivial bound 0; the sum of gains is then unavailable), more analyses
//                     (a smaller bound), and a sample outside the proven range (every statement withdrawn);
//                 S5  the pooled statement: reference numbers, the best subset leaves out a seat whose response loses,
//                     a seat without evaluation, one seat alone agrees with the per-seat bound;
//                 S6  order: no bound exceeds the estimate it bounds; more samples or a larger error budget never
//                     loosen a bound.
//   response    mwcli --response on four shipped fixtures small enough for the exact evaluator, started as a child
//               process (so the real command-line path is tested):
//                 R1  every seat's one-sided bound is at most the exact gain of that response; the simultaneous bound
//                     is at most the exact sum of gains and its NashConv bound at most exact NashConv; the pooled
//                     bounds are at most the exact sums they bound;
//                 R2  the 5.8 field keeps its 5.8 value under both names, and the summary's own recomputation from the
//                     printed per-seat statistics gives the printed bounds;
//                 R3  the same bits with 3 threads and 2 seats side by side (5.9 streams);
//                 R4  another evaluation seed: the same response (exact gain, bit for bit), other sampled numbers;
//                 R5  {"randomStreams":"5.8"} gives the bits the 5.8 program printed (recorded from 5.8 itself);
//                 R6  the evaluation walk: the 5.8 walk, the 5.9 walk without its offset index, with the index, and
//                     with the index and look-ahead all print the same estimate, variance and visit count, bit for
//                     bit (the index and the look-ahead may only change the time);
//               once: an evaluation that cannot finish in its time limit is reported as unavailable and the summary
//               falls back to the trivial bound without claiming a sum; malformed 5.9 request fields are refused.
//
// Everything is written inside <work-dir>. Statuses as in --selftest58: passed, failed, untested (never counted as
// passed). The report is <work-dir>/selftest59.json. Exit status: 0 every check passed, 1 a check failed or is
// untested, 2 usage or unreadable fixtures.
#pragma once
namespace st59 {
namespace fs = std::filesystem;
using st58::Report; using st58::fmt; using st58::sci; using st58::get; using st58::num; using st58::str; using st58::Doc; using st58::take; using st58::specOf;
static bool isTrue(const JV *v) { return v && v->type == J_BOOL && v->num != 0; }
static bool closeTo(double a, double b, double tol = 1e-12) { return std::isfinite(a) && std::isfinite(b) && std::fabs(a - b) <= tol * std::max({1.0, std::fabs(a), std::fabs(b)}); }

static void statisticsSection(Report &R) {
  const std::string sec = "statistics";
  { // S1: reference numbers of tools/independent_stats59.py (Python floats; written from the formulas, not from this code)
    const double a = stats59::ebOneSidedHalf(2.5, 160.0, 204800.0, 0.05), b = stats59::ebOneSidedHalf(0.0, 1.0, 1000.0, 0.01), c = stats59::sdUpper(2.5, 160.0, 204800.0, 0.01);
    const bool refused = std::isnan(stats59::ebOneSidedHalf(1, 1, 1, 0.05)) && std::isnan(stats59::ebOneSidedHalf(1, 1, 100, 0)) && std::isnan(stats59::ebOneSidedHalf(-1, 1, 100, 0.05)) && std::isnan(stats59::ebOneSidedHalf(1, INFINITY, 100, 0.05));
    R.check(sec, "S1", "one-sided empirical-Bernstein half-width and standard-deviation bound equal the independent implementation's numbers",
            closeTo(a, 0.016214575515275647) && closeTo(b, 0.012375115637583003) && closeTo(c, 2.6541244628258909) && refused && stats59::ebOneSidedHalf(1e9, 3.0, 10, 0.05) == 3.0,
            "half-widths " + fmt(a) + ", " + fmt(b) + "; standard-deviation bound " + fmt(c) + "; impossible inputs refused: " + (refused ? "yes" : "NO"));
  }
  const long long ns[3] = {1024, 20480, 204800}; const double ps[13] = {1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 0.1, 0.5, 0.9, 0.99, 1 - 1e-3, 1 - 1e-4, 1 - 1e-5, 1 - 1e-6}, ds[3] = {0.05, 0.05 / 8, 0.001};
  { // S2
    int cases = 0, bad = 0; double worst = 0; std::string where;
    for (long long n : ns) for (double p : ps) for (double d : ds) { const double miss = stats59::twoPointMiss(n, p, d, 0); cases++; if (!(miss <= d)) bad++; if (miss / d > worst) { worst = miss / d; where = "n " + std::to_string(n) + ", P(large) " + sci(p) + ", level " + sci(d); } }
    R.check(sec, "S2", "two-point distributions, exact binomial sums: the distribution-free bound never exceeds the true mean more often than its level", bad == 0 && cases == 117 && worst > 0,
            std::to_string(cases) + " cases, " + std::to_string(bad) + " above their level; largest miss probability / level " + sci(worst) + " (" + where + ")");
  }
  { // S3
    double worst = 0; std::string where; for (long long n : ns) for (double p : ps) { const double miss = stats59::twoPointMiss(n, p, 0.05, 1); if (miss > worst) { worst = miss; where = "n " + std::to_string(n) + ", P(small value) " + sci(1 - p); } }
    const double typical = stats59::twoPointMiss(204800, 1 - 1e-6, 0.05, 1), benign = stats59::twoPointMiss(204800, 0.5, 0.05, 1);
    R.check(sec, "S3", "the same sums show why the 5.8 normal-approximation bound is not a confidence statement: with a rare small value it exceeds the true mean most of the time",
            worst > 0.8 && typical > 0.8 && benign < 0.06, "largest miss probability " + sci(worst) + " (" + where + "); 204,800 samples, small value with probability 1e-6: " + sci(typical) + "; a fair coin: " + sci(benign) + " (nominal 0.05)");
  }
  auto seat = [](int s, double mean, double var, double n, double width, bool avail = true, bool within = true) { stats59::Seat q; q.seat = s; q.available = avail; q.within = within; q.mean = mean; q.variance = var; q.n = n; q.width = width; return q; };
  const std::vector<stats59::Seat> three = {seat(0, 0.40, 2.5, 204800, 160), seat(1, 0.05, 0.30, 204800, 99.2), seat(2, -0.20, 9.0, 102400, 240)};
  { // S4
    const stats59::Simultaneous a = stats59::simultaneous(three, 0.05), b = stats59::simultaneous(three, 0.05, 4);
    std::vector<stats59::Seat> missing = three; missing[1].available = false; const stats59::Simultaneous c = stats59::simultaneous(missing, 0.05);
    std::vector<stats59::Seat> outside = three; outside[2].within = false; const stats59::Simultaneous d = stats59::simultaneous(outside, 0.05);
    std::vector<stats59::Seat> none = three; for (auto &q : none) q.available = false; const stats59::Simultaneous e = stats59::simultaneous(none, 0.05);
    const bool ref = a.calibrated && a.complete && a.seats.size() == 3 && closeTo(a.seats[0].delta, 0.05 / 3, 1e-15) && closeTo(a.seats[0].lower, 0.38046155532732445) && closeTo(a.seats[1].lower, 0.040843999741429965) && closeTo(a.seats[2].lower, -0.25519135447113123) &&
                     closeTo(a.sumOfGainsLower, 0.16611420059762319) && closeTo(a.bestResponseSumLower, 0.42130555506875444) && a.seats[2].floored == 0;
    const bool more = b.calibrated && closeTo(b.bestResponseSumLower, 0.41523793585028257) && closeTo(b.sumOfGainsLower, 0.14853179549365525) && b.bestResponseSumLower < a.bestResponseSumLower;
    const bool miss = c.calibrated && !c.complete && std::isnan(c.sumOfGainsLower) && closeTo(c.bestResponseSumLower, 0.38046155532732445) && c.seats[1].floored == 0 && !c.seats[1].available && c.evaluated == 2 && closeTo(c.seats[0].delta, 0.05 / 3, 1e-15);
    const bool wd = !d.calibrated && d.reason == "payoffBoundViolated" && std::isnan(d.bestResponseSumLower) && std::isnan(d.sumOfGainsLower);
    const bool triv = e.calibrated && !e.complete && e.bestResponseSumLower == 0 && e.evaluated == 0;
    const bool level = !stats59::simultaneous(three, 0).calibrated && !stats59::simultaneous(three, 1).calibrated && !stats59::simultaneous(three, 0.05, 0).calibrated && !stats59::simultaneous({}, 0.05).calibrated;
    R.check(sec, "S4", "simultaneous statement: reference numbers, error budget alpha / seats, floor at 0, a seat without evaluation, more analyses, a sample outside the proven range", ref && more && miss && wd && triv && level,
            "three seats at 95%: per-seat bounds " + fmt(a.seats.size() == 3 ? a.seats[0].lower : NAN) + ", " + fmt(a.seats.size() == 3 ? a.seats[1].lower : NAN) + ", " + fmt(a.seats.size() == 3 ? a.seats[2].lower : NAN) + "; sum of gains >= " + fmt(a.sumOfGainsLower) + "; NashConv >= " + fmt(a.bestResponseSumLower) +
            "; four analyses: " + fmt(b.bestResponseSumLower) + "; seat 1 not evaluated: " + fmt(c.bestResponseSumLower) + " (sum of gains " + (std::isnan(c.sumOfGainsLower) ? "unavailable" : "REPORTED") + "); sample outside the range: " + (wd ? "withdrawn" : "NOT withdrawn") + "; nothing evaluated: " + fmt(e.bestResponseSumLower) + "; bad levels refused: " + (level ? "yes" : "NO"));
  }
  { // S5
    const stats59::Pooled a = stats59::pooledIndependent(three, 0.05);
    std::vector<stats59::Seat> missing = three; missing[1].available = false; const stats59::Pooled c = stats59::pooledIndependent(missing, 0.05);
    const stats59::Pooled one = stats59::pooledIndependent({three[0]}, 0.05); const double alone = 0.40 - stats59::ebOneSidedHalf(2.5, 160.0, 204800.0, 0.05);
    std::vector<stats59::Seat> outside = three; outside[0].within = false; const stats59::Pooled d = stats59::pooledIndependent(outside, 0.05);
    const bool ref = a.calibrated && a.complete && a.subsets == 7 && closeTo(a.deltaBernstein, 0.05 / 14, 1e-15) && closeTo(a.deltaVariance, 0.05 / 6, 1e-15) && closeTo(a.allSeatsLower, 0.18566266668748643) && closeTo(a.bestSubsetLower, 0.42670342809295464) &&
                     a.bestSubset == std::vector<int>({0, 1}) && closeTo(a.bestResponseSumLower, 0.42670342809295464);
    const bool miss = c.calibrated && !c.complete && std::isnan(c.allSeatsLower) && closeTo(c.bestSubsetLower, 0.37868818855447062) && c.bestSubset == std::vector<int>({0});
    const bool single = one.calibrated && closeTo(one.bestSubsetLower, 0.38378544324744435) && std::fabs(one.bestSubsetLower - alone) < 1e-6 && one.bestSubsetLower >= alone;
    R.check(sec, "S5", "pooled statement over independent seats: reference numbers, the best subset leaves out the seat whose response loses, a seat without evaluation, one seat alone", ref && miss && single && !d.calibrated && d.reason == "payoffBoundViolated",
            "three seats at 95%: all seats >= " + fmt(a.allSeatsLower) + "; best subset {0, 1} >= " + fmt(a.bestSubsetLower) + " over " + std::to_string(a.subsets) + " subsets; seat 1 not evaluated: {0} >= " + fmt(c.bestSubsetLower) + "; one seat alone " + fmt(one.bestSubsetLower) + " (per-seat bound " + fmt(alone) + ")");
  }
  { // S6
    int bad = 0, cases = 0; uint64_t x = 0x5900c0de5900c0deULL; auto next = [&] { x ^= x << 13; x ^= x >> 7; x ^= x << 17; return (double)(x >> 11) / 9007199254740992.0; };
    for (int t = 0; t < 2000; t++) {
      const int k = 1 + (int)(next() * 8); std::vector<stats59::Seat> S, big;
      for (int i = 0; i < k; i++) { const double w = 1 + 400 * next(), var = w * w / 4 * next() * next(), n = 1024.0 * (1 + std::floor(next() * 400)); S.push_back(seat(i, (next() - 0.4) * w / 50, var, n, w)); big.push_back(S.back()); big.back().n = n * 4; }
      const double alpha = 0.001 + 0.2 * next(); double means = 0, pos = 0; for (auto &q : S) { means += q.mean; pos += std::max(0.0, q.mean); }
      const stats59::Simultaneous a = stats59::simultaneous(S, alpha), a4 = stats59::simultaneous(big, alpha), aw = stats59::simultaneous(S, alpha * 2 < 1 ? alpha * 2 : alpha), an = stats59::simultaneous(S, alpha, 3);
      const stats59::Pooled p = stats59::pooledIndependent(S, alpha), p4 = stats59::pooledIndependent(big, alpha);
      cases++;
      bad += !(a.calibrated && p.calibrated && a.sumOfGainsLower <= means && a.bestResponseSumLower <= pos && a.bestResponseSumLower >= 0 && p.allSeatsLower <= means && p.bestSubsetLower <= pos + 1e-12 && p.bestResponseSumLower >= 0);
      bad += !(a4.sumOfGainsLower >= a.sumOfGainsLower && p4.allSeatsLower >= p.allSeatsLower && aw.sumOfGainsLower >= a.sumOfGainsLower && an.sumOfGainsLower <= a.sumOfGainsLower);
      double sub = 0; for (int s : p.bestSubset) sub += S[(size_t)s].mean; bad += !(p.bestSubsetLower <= sub);
    }
    R.check(sec, "S6", "order: no bound exceeds the estimate it bounds; four times the samples or twice the error budget never loosen a bound; more analyses never tighten it", bad == 0, std::to_string(cases) + " random families of 1 to 8 seats, " + std::to_string(bad) + " violations");
  }
}

struct Seat59 { int seat = -1; bool sampled = false, exact = false, indexed = false; long long visits = -1; std::string bits, varBits, exactBits, walk; double mean = NAN, se = NAN, var = NAN, n = 0, width = NAN, lower = NAN, exactGain = NAN, brGain = NAN, seatAlpha = NAN; bool within = false; };
struct Result59 { bool ok = false; std::string why, text; std::vector<Seat59> seats; double simSum = NAN, simNash = NAN, poolAll = NAN, poolBest = NAN, poolNash = NAN, legacy = NAN, legacyNew = NAN, exactSum = NAN, exactBr = NAN, exactNash = NAN, perSeatAlpha = NAN, sumMean = NAN;
  bool simCal = false, simComplete = false, poolCal = false, hasSum = false, hasLegacy = false, againstAll = false, hasAgainst = false; std::vector<int> bestSubset; std::string streams, calc; int exitCode = -1; std::string err; };
static Result59 respond59(const std::string &self, const std::string &work, const std::string &spec, const std::string &state, const std::string &request, const std::string &tag, const std::vector<std::pair<std::string, std::string>> &env = {}) {
  Result59 r; const std::string q = (fs::path(work) / ("request-" + tag + ".json")).string();
  { FILE *f = std::fopen(q.c_str(), "wb"); if (!f) { r.why = "cannot write " + q; return r; } std::fwrite(request.data(), 1, request.size(), f); std::fclose(f); }
  const ckpt::Run run = ckpt::spawn({self, "--response", spec, state, q, "512"}, work, 1800, env);
  r.exitCode = run.exitCode; r.err = run.err.substr(0, 300); std::error_code ec; fs::remove(q, ec);
  if (!run.started) { r.why = "the program could not be started: " + run.startError; return r; }
  if (run.exitCode != 0) { r.why = "exit " + std::to_string(run.exitCode) + ": " + r.err; return r; }
  r.text = run.out; Doc d(run.out); if (!d.v) { r.why = "the result is not JSON"; return r; }
  const JV *seats = get(d.v, "seats"), *S = get(d.v, "summary"); if (!seats || seats->type != J_ARR || !S) { r.why = "no seats or summary in the result"; return r; }
  r.streams = str(get(d.v, "randomStreams")); r.perSeatAlpha = num(get(d.v, "perSeatAlpha"));
  for (int i = 0; i < seats->n; i++) {
    const JV *s = seats->items[i], *x = get(s, "sampled"), *g = get(x, "gain"), *st = get(x, "statistics"), *lb = get(x, "lowerBound"), *e = get(s, "exact"); Seat59 o; o.seat = (int)num(get(s, "seat"), -1);
    o.sampled = g != nullptr; o.bits = str(get(g, "gainBits")); o.mean = num(get(g, "mean")); o.se = num(get(g, "stdErr")); o.var = num(get(st, "sampleVariance")); o.varBits = str(get(st, "sampleVarianceBits")); o.n = num(get(st, "samples"), 0); o.width = num(get(st, "provenSampleRange"));
    o.visits = (long long)num(get(x, "visits"), -1); o.walk = str(get(get(x, "walk"), "version")); o.indexed = isTrue(get(get(x, "walk"), "offsetIndex"));
    o.within = isTrue(get(st, "withinProvenRange")); o.lower = num(get(lb, "responseGain")); o.seatAlpha = num(get(lb, "alpha")); if (i == 0) r.calc = str(get(x, "calculation"));
    o.exact = isTrue(get(e, "available")); o.exactGain = num(get(e, "gain")); o.brGain = num(get(e, "bestResponseGain")); o.exactBits = str(get(e, "gainBits")); r.seats.push_back(o);
  }
  const JV *sim = get(S, "simultaneous"), *po = get(S, "pooledIndependent"), *sg = get(S, "sumOfSeatGains"), *ag = get(S, "againstExact");
  r.simCal = isTrue(get(sim, "calibrated")); r.simComplete = isTrue(get(sim, "complete")); r.simSum = num(get(sim, "sumOfResponseGainsLowerBound")); r.simNash = num(get(sim, "nashConvLowerBound"));
  r.poolCal = isTrue(get(po, "calibrated")); r.poolAll = num(get(po, "sumOfResponseGainsLowerBound")); r.poolBest = num(get(get(po, "bestSubset"), "sumOfResponseGainsLowerBound")); r.poolNash = num(get(po, "nashConvLowerBound"));
  if (const JV *bs = get(get(po, "bestSubset"), "seats")) if (bs->type == J_ARR) for (int i = 0; i < bs->n; i++) r.bestSubset.push_back((int)num(bs->items[i], -1));
  r.hasSum = sg != nullptr; r.sumMean = num(get(sg, "mean")); r.hasLegacy = get(S, "sumOfSeatLowerBounds95") != nullptr; r.legacy = num(get(S, "sumOfSeatLowerBounds95")); r.legacyNew = num(get(S, "sumOfNormalApproximationLowerBounds95"));
  r.exactSum = num(get(S, "exactSumOfSeatGains")); r.exactBr = num(get(S, "exactSumOfBestResponseGains")); r.exactNash = num(get(S, "exactNashConv"));
  r.hasAgainst = ag != nullptr; r.againstAll = isTrue(get(ag, "simultaneousHolds")) && isTrue(get(ag, "simultaneousNashConvBoundHolds")) && isTrue(get(ag, "pooledAllSeatsHolds")) && isTrue(get(ag, "pooledBestSubsetHolds"));
  r.ok = true; return r;
}

static void responseSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  struct Fx { const char *name; long long deals, responseDeals, samples; bool second; const char *bits58; };
  // bits58: the sampled gains the 5.8 program (build d4001e2c0cd77f41) printed for {"responseDeals":100000,"samples":51200,"seed":59}
  // on the state this self-test trains (20,000 deals, one thread), seat by seat. 5.9 must print them with randomStreams "5.8".
  const Fx fixtures[] = {{"known-akq-river", 20000, 100000, 51200, true, "3f943a74bd7deec6 3fb8205dcf285146"},
                         {"flop3-kings-small", 20000, 100000, 51200, true, nullptr},
                         {"flop6-jack-small", 20000, 100000, 51200, false, "3fb60ea783ec457f 3fb587bfdb70862d 3fc758a9b770c9bd 3fb561d40e513157 3fab544bd5eb4d17 3fa85ef1f4706d12"},
                         {"icm8-bb-call-small", 20000, 100000, 20480, false, nullptr}};
  const std::string sec = "response"; bool once = false;
  for (const Fx &fx : fixtures) {
    const std::string name = fx.name; std::string why;
    const std::string spec = specOf((fs::path(studies) / (name + ".emfix.json")).string(), why);
    if (spec.empty()) { R.add(sec, name, "fixture is readable", "untested", why); continue; }
    const std::string specPath = (fs::path(work) / (name + ".spec.json")).string(), state = (fs::path(work) / (name + ".state")).string();
    { FILE *f = std::fopen(specPath.c_str(), "wb"); if (f) { std::fwrite(spec.data(), 1, spec.size(), f); std::fclose(f); } }
    char err[512] = ""; MW *t = mw_create(spec.c_str(), spec.size(), 512, err, sizeof err);
    if (!t) { R.add(sec, name, "the engine accepts the fixture", "untested", err); continue; }
    bool saved = mw_train(t, fx.deals, 1, nullptr, nullptr, nullptr, err, sizeof err) != 0;
    if (saved) { SaveReport rep; saveWithReport(state.c_str(), [&](FILE *f) { return mw_write_stream(t, f, nullptr) > 0; }, rep); saved = rep.ok; if (!saved) std::snprintf(err, sizeof err, "%s", rep.text().c_str()); }
    mw_free(t);
    if (!saved) { R.add(sec, name, "trained state", "untested", err); continue; }
    const std::string base = "\"responseDeals\":" + std::to_string(fx.responseDeals) + ",\"samples\":" + std::to_string(fx.samples) + ",\"seed\":59";
    const Result59 a = respond59(self, work, specPath, state, "{" + base + ",\"exact\":true}", name + "-a");
    if (!a.ok) { R.add(sec, name, "mwcli --response with exact values", "untested", a.why); continue; }
    const size_t n = a.seats.size(); bool allExact = n > 0, allSampled = n > 0; for (const Seat59 &s : a.seats) { allExact &= s.exact; allSampled &= s.sampled && s.within; }
    if (!allExact || !allSampled) { R.add(sec, name, "every seat has a sampled and an exact value", "untested", "seats " + std::to_string(n) + ", all exact " + (allExact ? "yes" : "no") + ", all sampled " + (allSampled ? "yes" : "no")); continue; }
    { // R1
      int seatBad = 0; double exactSum = 0, exactBr = 0, worstMargin = INFINITY; for (const Seat59 &s : a.seats) { seatBad += !(s.lower <= s.exactGain); exactSum += s.exactGain; exactBr += s.brGain; worstMargin = std::min(worstMargin, s.exactGain - s.lower); }
      double subset = 0; for (int q : a.bestSubset) for (const Seat59 &s : a.seats) if (s.seat == q) subset += s.exactGain;
      const bool ok = seatBad == 0 && a.simCal && a.simComplete && a.simSum <= exactSum && a.simNash <= exactBr && a.simNash >= 0 && a.poolCal && a.poolAll <= exactSum && a.poolBest <= subset + 1e-15 && a.poolNash <= exactBr && a.hasAgainst && a.againstAll &&
                      closeTo(a.exactSum, exactSum, 1e-9) && closeTo(a.exactNash, exactBr, 1e-9) && a.streams == "5.9" && a.calc == "response-5.9-paired-v2";
      R.check(sec, name + " R1", "every confidence statement holds against the exact values of the same responses (per seat, simultaneous, pooled; NashConv bounds against exact NashConv)", ok,
              std::to_string(n) + " seats; exact sum of response gains " + sci(exactSum) + ", exact NashConv " + sci(exactBr) + "; estimate " + sci(a.sumMean) + "; simultaneous: sum >= " + sci(a.simSum) + ", NashConv >= " + sci(a.simNash) +
              "; pooled: all seats >= " + sci(a.poolAll) + ", best subset >= " + sci(a.poolBest) + "; smallest (exact - seat bound) " + sci(worstMargin) + "; seat bounds above exact: " + std::to_string(seatBad));
    }
    { // R2
      double legacy = 0; std::vector<stats59::Seat> S; for (const Seat59 &s : a.seats) { legacy += std::max(0.0, s.mean - 1.6448536269514722 * s.se); stats59::Seat q; q.seat = s.seat; q.available = true; q.within = s.within; q.mean = s.mean; q.variance = s.var; q.n = s.n; q.width = s.width; S.push_back(q); }
      const stats59::Simultaneous sim = stats59::simultaneous(S, 0.05); const stats59::Pooled po = stats59::pooledIndependent(S, 0.05);
      bool seatAlpha = closeTo(a.perSeatAlpha, 0.05 / (double)n, 1e-12); for (const Seat59 &s : a.seats) seatAlpha &= closeTo(s.seatAlpha, 0.05 / (double)n, 1e-12);
      bool seatLower = true; for (size_t i = 0; i < n && i < sim.seats.size(); i++) seatLower &= closeTo(a.seats[i].lower, sim.seats[i].lower);
      R.check(sec, name + " R2", "the 5.8 field keeps its value under both names; the bounds follow from the printed per-seat statistics; every seat was given alpha / seats", a.hasLegacy && closeTo(a.legacy, legacy) && a.legacy == a.legacyNew && closeTo(a.simSum, sim.sumOfGainsLower) && closeTo(a.simNash, sim.bestResponseSumLower) && closeTo(a.poolAll, po.allSeatsLower) && closeTo(a.poolBest, po.bestSubsetLower) && seatAlpha && seatLower,
              "sumOfSeatLowerBounds95 " + fmt(a.legacy) + " (recomputed " + fmt(legacy) + "); simultaneous NashConv bound " + fmt(a.simNash) + " (recomputed " + fmt(sim.bestResponseSumLower) + "); per-seat alpha " + fmt(a.perSeatAlpha));
    }
    { // R3
      const Result59 b = respond59(self, work, specPath, state, "{" + base + ",\"threads\":3,\"parallelSeats\":2}", name + "-b");
      int diff = 0; if (b.ok && b.seats.size() == n) for (size_t i = 0; i < n; i++) diff += b.seats[i].bits != a.seats[i].bits || b.seats[i].varBits != a.seats[i].varBits; else diff = -1;
      if (!b.ok) R.add(sec, name + " R3", "the same bits with 3 threads and 2 seats side by side", "untested", b.why);
      else R.check(sec, name + " R3", "the same bits with 3 threads and 2 seats side by side (estimates, variances and every bound of the summary)", diff == 0 && b.simSum == a.simSum && b.simNash == a.simNash && b.poolAll == a.poolAll && b.poolBest == a.poolBest && b.legacy == a.legacy,
                   std::to_string(n) + " seats, " + std::to_string(diff) + " differ; simultaneous " + fmt(b.simSum) + " and " + fmt(a.simSum));
    }
    if (fx.second) { // R4
      const Result59 c = respond59(self, work, specPath, state, "{" + base + ",\"exact\":true,\"evaluationSeed\":60}", name + "-c");
      int sameResponse = 0, sameSample = 0; if (c.ok && c.seats.size() == n) for (size_t i = 0; i < n; i++) { sameResponse += c.seats[i].exactBits == a.seats[i].exactBits && !c.seats[i].exactBits.empty(); sameSample += c.seats[i].bits == a.seats[i].bits; }
      if (!c.ok) R.add(sec, name + " R4", "another evaluation seed", "untested", c.why);
      else R.check(sec, name + " R4", "another evaluation seed evaluates the SAME response (exact gain bit for bit) on other deals, and its statements hold as well", sameResponse == (int)n && sameSample == 0 && c.hasAgainst && c.againstAll,
                   std::to_string(sameResponse) + " of " + std::to_string(n) + " exact gains identical, " + std::to_string(sameSample) + " sampled estimates identical; simultaneous NashConv bound " + sci(c.simNash) + " (first seed " + sci(a.simNash) + ")");
    }
    if (fx.bits58) { // R5
      const Result59 l = respond59(self, work, specPath, state, "{" + base + ",\"randomStreams\":\"5.8\"}", name + "-l");
      std::string got; if (l.ok) for (const Seat59 &s : l.seats) got += (got.empty() ? "" : " ") + s.bits;
      int differ59 = 0; if (l.ok && l.seats.size() == n) for (size_t i = 0; i < n; i++) differ59 += l.seats[i].bits != a.seats[i].bits;
      if (!l.ok) R.add(sec, name + " R5", "the 5.8 streams", "untested", l.why);
      else R.check(sec, name + " R5", "{\"randomStreams\":\"5.8\"} reproduces the sampled gains the 5.8 program printed, bit for bit; the 5.9 streams draw other numbers", got == fx.bits58 && l.streams == "5.8" && l.calc == "response-5.8-paired-v1" && differ59 == (int)n,
                   "printed " + got + "; 5.8 printed " + fx.bits58 + "; estimates that differ from the 5.9 streams: " + std::to_string(differ59) + " of " + std::to_string(n));
    }
    { // R6
      const std::string q = "{" + base + ",\"futureActions\":\"enumerate\"}", qs = "{" + base + ",\"futureActions\":\"sample\"}"; int diff = 0, runs = 0; std::string kinds, why6;
      for (const std::string &rq : {q, qs}) {
        const Result59 ref = respond59(self, work, specPath, state, rq, name + "-w58", {{"EIGHTMAX_RESPONSE_WALK", "5.8"}});
        if (!ref.ok || ref.seats.size() != n) { why6 = ref.why; break; }
        for (const char *mode : {"0", "1", "2", ""}) {
          const Result59 v = respond59(self, work, specPath, state, rq, name + "-w59", {{"EIGHTMAX_RESPONSE_INDEX", mode}}); runs++;
          if (!v.ok || v.seats.size() != n) { why6 = v.why; diff = -1; break; }
          for (size_t i = 0; i < n; i++) diff += v.seats[i].bits != ref.seats[i].bits || v.seats[i].varBits != ref.seats[i].varBits || v.seats[i].visits != ref.seats[i].visits || v.seats[i].walk != "5.9" || ref.seats[i].walk != "5.8";
          if (rq == q) kinds += std::string(kinds.empty() ? "" : ", ") + (*mode ? mode : "default") + (v.seats[0].indexed ? ": indexed" : ": not indexed");
        }
        if (diff < 0) break;
      }
      if (!why6.empty()) R.add(sec, name + " R6", "the evaluation walk", "untested", why6);
      else R.check(sec, name + " R6", "the 5.8 walk and the 5.9 walk (without its offset index, with it, with look-ahead, default) print the same estimates, variances and visit counts, bit for bit", diff == 0 && runs == 8,
                   std::to_string(runs) + " runs against the 5.8 walk (opponents enumerated and sampled), " + std::to_string(n) + " seats each, " + std::to_string(diff) + " differences; EIGHTMAX_RESPONSE_INDEX " + kinds);
    }
    if (!once) {
      once = true;
      { // an evaluation that cannot finish: a billion deals in a tenth of a second
        const Result59 u = respond59(self, work, specPath, state, "{\"responseDeals\":1000,\"samples\":1000000000,\"seed\":59,\"timeLimitMs\":100}", name + "-u");
        int unavailable = 0; for (const Seat59 &s : u.seats) unavailable += !s.sampled;
        if (!u.ok) R.add(sec, "incomplete", "an evaluation that cannot finish in its time limit", "untested", u.why);
        else R.check(sec, "incomplete", "an evaluation that cannot finish in its time limit is unavailable, never shortened; the summary keeps the trivial bound 0 and claims no sum", unavailable == (int)u.seats.size() && !u.seats.empty() && u.simCal && !u.simComplete && u.simNash == 0 && std::isnan(u.simSum) && !u.hasSum && !u.hasLegacy && u.poolCal && u.poolNash == 0 && std::isnan(u.poolAll),
                     std::to_string(unavailable) + " of " + std::to_string(u.seats.size()) + " seats unavailable; simultaneous NashConv bound " + fmt(u.simNash) + ", complete: " + (u.simComplete ? "yes" : "no") + ", sum of gains reported: " + (u.hasSum ? "YES" : "no"));
      }
      { // more analyses: a smaller per-seat error budget, a bound that is not larger
        const Result59 m = respond59(self, work, specPath, state, "{" + base + ",\"analyses\":4,\"confidence\":0.99}", name + "-m");
        if (!m.ok) R.add(sec, "family", "analyses and confidence", "untested", m.why);
        else R.check(sec, "family", "analyses and confidence set the per-seat error budget (1 - confidence) / analyses / seats, and a smaller budget never gives a larger bound", closeTo(m.perSeatAlpha, 0.01 / 4 / (double)n, 1e-12) && m.simSum <= a.simSum && m.simNash <= a.simNash && m.poolAll <= a.poolAll,
                     "per-seat alpha " + fmt(m.perSeatAlpha) + "; simultaneous sum bound " + fmt(m.simSum) + " (95%, one analysis: " + fmt(a.simSum) + ")");
      }
      { // malformed 5.9 request fields
        const char *bad[] = {"{\"confidence\":1.5}", "{\"confidence\":0.2}", "{\"confidence\":\"high\"}", "{\"analyses\":0}", "{\"analyses\":1.5}", "{\"randomStreams\":\"5.7\"}", "{\"randomStreams\":59}", "{\"evaluationSeed\":-1}", "{\"evaluationSeed\":4294967296}", "{\"simultaneous\":true}"};
        int refused = 0, total = 0; std::string notRefused;
        for (const char *q : bad) { total++; const Result59 x = respond59(self, work, specPath, state, q, name + "-x"); if (!x.ok && x.exitCode == 2) refused++; else notRefused += std::string(notRefused.empty() ? "" : "; ") + q + " -> exit " + std::to_string(x.exitCode); }
        R.check(sec, "requests", "malformed confidence, analyses, randomStreams and evaluationSeed, and an unknown field, are usage errors before anything is trained", refused == total, std::to_string(refused) + " of " + std::to_string(total) + " refused with exit 2" + (notRefused.empty() ? "" : "; " + notRefused));
      }
    }
    std::error_code ec; fs::remove(state, ec); fs::remove(specPath, ec);
  }
}

static int run(int argc, char **argv) {
  if (argc < 4 || argc > 5) { std::fprintf(stderr, "usage: mwcli --selftest59 studies-dir work-dir [all|engine|statistics|response]\n"); return 2; }
  const std::string studies = argv[2], work = argv[3], section = argc > 4 ? argv[4] : "all";
  if (section != "all" && section != "engine" && section != "statistics" && section != "response") { std::fprintf(stderr, "error: the section must be all, engine, statistics or response\n"); return 2; }
  std::error_code ec; fs::create_directories(work, ec);
  if (!fs::is_directory(studies, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: studies-dir and work-dir must be directories\n"); return 2; }
  mw_study_identity(EM_VERSION, EM_BUILD_ID);
  Report R; const auto t0 = std::chrono::steady_clock::now();
  if (section == "all" || section == "engine") {
    JB j; jb_init(&j); mw_selftest59(&j); const std::string text = take(j); Doc d(text);
    if (!d.v || d.v->type != J_ARR || !d.v->n) R.add("engine", "E0", "in-engine checks produced a report", "failed", text.substr(0, 200));
    else for (int i = 0; i < d.v->n; i++) { const JV *e = d.v->items[i]; R.check("engine", "E" + std::to_string(i + 1), str(get(e, "name")), isTrue(get(e, "passed")), str(get(e, "detail"))); }
  }
  if (section == "all" || section == "statistics") statisticsSection(R);
  if (section == "all" || section == "response") responseSection(R, fs::absolute(studies, ec).string(), fs::absolute(work, ec).string(), ckpt::selfPath(argv[0]));
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest59\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"" + section + "\",\"passed\":" + std::to_string(R.passed) + ",\"failed\":" + std::to_string(R.failed) +
                  ",\"untested\":" + std::to_string(R.untested) + ",\"seconds\":" + fmt(secs) + ",\"checks\":[";
  for (size_t i = 0; i < R.checks.size(); i++) { const st58::Check &c = R.checks[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}";
  const std::string report = (fs::path(work) / "selftest59.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest59\",\"build\":\"%s\",\"section\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"report\":%s}\n", EM_BUILD_ID, section.c_str(), R.passed, R.failed, R.untested, mwa::jsonEsc(report).c_str());
  return R.failed || R.untested ? 1 : 0;
}
}
