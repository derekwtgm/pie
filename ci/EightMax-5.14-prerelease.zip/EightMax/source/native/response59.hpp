// EightMax 5.9: evaluation of a trained response - random streams with a provable partition, and a one-sided
// distribution-free lower bound per seat that the summary of mwcli --response combines into a simultaneous statement
// (response_stats59.hpp). The response training itself (mw_response_begin, mw_train, mw_response_end) is 5.8's,
// unchanged: with equal seeds 5.9 trains the response 5.8 trained, value for value.
//
// RANDOM STREAMS (what 5.8 left open). 5.8 drew each block's two streams from SplitMix64 started at a hashed 64-bit
// state. All streams of all seeds lie on ONE cycle of 2^64 states, so two block streams can overlap; the chance is
// negligible for the default request and of order 0.1 for the largest request the engine accepts (a billion deals,
// about two million streams), as MATHEMATICAL-VALIDATION-5.8.md, section 2, stated. Nothing could be proved about a
// particular run.
//
// 5.9 uses a COUNTER-BASED generator: Philox4x64-10 (Salmon, Moraes, Dror & Shaw, "Parallel random numbers: as easy
// as 1, 2, 3", SC 2011; the generator of Random123, of numpy.random.Philox and of C++26 std::philox4x64). One call
// maps a 256-bit counter and a 128-bit key to 256 output bits, and for a fixed key that map is a BIJECTION of the
// 256-bit counters (ten rounds, each an invertible substitution-permutation step). Every random number of an
// evaluation has an address, and the address is the counter:
//     key     = (seed, DOMAIN59)                           the evaluation seed and a constant that belongs to this use
//     counter = (j, block, seat, purpose)                  j = 0, 1, 2, ...: the j-th group of four numbers of the stream
// purpose 0 = cards, 1 = opponents' actions. Consequences that are THEOREMS, not estimates:
//   (1) within one evaluation seed, two different (seat, block, purpose, j) never receive the same 256 bits: there is
//       no cycle to overlap on and no birthday bound; streams cannot collide, for any number of blocks and any length;
//   (2) a stream is a pure function of its address: it does not depend on the thread that computes it, on the other
//       blocks, or on how many numbers another stream consumed; a block can be recomputed alone;
//   (3) a stream cannot run out: 2^64 groups of four numbers per (seat, block, purpose).
// What is NOT a theorem (and is not for any pseudo-random generator): that the numbers behave as independent uniform
// variables. That is the empirical statement of the generator's authors (Philox4x64-10 passes TestU01 BigCrush with
// every counter and key arrangement they tried) and the assumption under which every sampling statement of this
// program is made; it is tested here only as far as a test can go (reference vectors, moments, and the estimates
// against exact values: MATHEMATICAL-VALIDATION-5.9.md, section 5). Different SEEDS use different keys: a different
// member of the family of bijections, with no theorem relating two members.
// The training of the response does not use these streams (it uses the engine's training streams, reseeded from the
// response seed), so the evaluation numbers play no part in choosing the response.
//
// {"streams":"5.8"} selects the 5.8 streams (SplitMix64, response58.hpp): the estimate then has the bits 5.8 printed,
// and `calculation` names the 5.8 method. The default is "5.9".
#pragma once
#include "response_stats59.hpp"
namespace {
namespace es {
struct Philox4x64 {
  static inline void mulhilo(uint64_t a, uint64_t b, uint64_t &hi, uint64_t &lo) { const unsigned __int128 p = (unsigned __int128)a * b; lo = (uint64_t)p; hi = (uint64_t)(p >> 64); }
  static inline void round(uint64_t c[4], const uint64_t k[2]) {
    uint64_t hi0, lo0, hi1, lo1; mulhilo(0xD2E7470EE14C6C93ULL, c[0], hi0, lo0); mulhilo(0xCA5A826395121157ULL, c[2], hi1, lo1);
    const uint64_t c1 = c[1], c3 = c[3]; c[0] = hi1 ^ c1 ^ k[0]; c[1] = lo1; c[2] = hi0 ^ c3 ^ k[1]; c[3] = lo0;
  }
  // out = Philox4x64-10(counter, key); counter and key are not modified.
  static inline void block(const uint64_t ctr[4], const uint64_t key[2], uint64_t out[4]) {
    uint64_t c[4] = {ctr[0], ctr[1], ctr[2], ctr[3]}, k[2] = {key[0], key[1]};
    round(c, k);
    for (int r = 1; r < 10; r++) { k[0] += 0x9E3779B97F4A7C15ULL; k[1] += 0xBB67AE8584CAA73BULL; round(c, k); }
    out[0] = c[0]; out[1] = c[1]; out[2] = c[2]; out[3] = c[3];
  }
};
constexpr uint64_t DOMAIN59 = 0x45694d6178353900ULL | 0x59;   // "EiMax59" and the release: the second key word of every 5.9 evaluation stream
constexpr const char *STREAMS59 = "philox4x64-10-counter-v1";
constexpr const char *STREAMS58 = "splitmix64-hashed-block-seeds-5.8";
struct Rng59 {
  uint64_t key[2], ctr[4], buf[4]; int left = 0;
  Rng59(uint64_t seed, uint64_t seat, uint64_t block, uint64_t purpose) : key{seed, DOMAIN59}, ctr{0, block, seat, purpose}, buf{0, 0, 0, 0} {}
  uint64_t bits() { if (!left) { Philox4x64::block(ctr, key, buf); ++ctr[0]; left = 4; } return buf[4 - left--]; }
  double next() { return (double)(bits() >> 11) * (1.0 / 9007199254740992.0); }   // 53 random bits, in [0, 1)
};
// ---- 5.9: the evaluation walk without what it never reports ----
// The 5.8 walk (pairValue, response58.hpp) read every strategy through Evaluator::policy, the reader of the action-EV
// evaluators: a memo lookup for the strategy key, the hash lookup of the table row, coverage accounting for every
// lookup (which the response result never prints), and, at the responding seat's own decisions, all of that twice -
// once for the response and once for sigma, which are two halves of the SAME table row. A profile of the three-player
// flop fixture attributed 73% of the evaluation to these lookups (PERFORMANCE-5.9.md, section 2).
// pairValue59 visits the same nodes in the same order, draws the same random numbers and performs the same
// floating-point operations in the same order; it differs only in how a row is found:
//   - the strategy key of (seat, street) is computed once per deal (the cards of a deal do not change during its walk);
//   - the row of the responding seat is looked up once and serves both profiles;
//   - coverage is not accounted.
// The values are therefore the bits of pairValue: tests/v59.test.js and mwcli --selftest59 compare the two walks, and
// the 5.8 program, on every reference game. EIGHTMAX_RESPONSE_WALK=5.8 selects the 5.8 walk (for those comparisons).
struct Keys59 {
  Evaluator::Key k[8][6]; uint8_t have[8][6];
  const uint32_t *slotOff = nullptr;   // the evaluation's offset index (see SlotIndex59), or nullptr
  bool ahead = false;                  // prefetch the children's index lines before walking them
  void reset() { std::memset(have, 0, sizeof have); }
  const Evaluator::Key &of(Evaluator &E, int seat, int len) { if (!have[seat][len]) { k[seat][len] = E.key(seat, E.hand[seat], len); have[seat][len] = 1; } return k[seat][len]; }
};
// THE OFFSET INDEX. A strategy lookup in the hashed table is a chain of four memory reads, each needing the result of
// the one before: the hash slot's key (hkeys), the slot's row number (hrow), the row record (for the offset of its
// values), the values. On tables that do not fit the processor's caches each is a cache miss, and the four cannot
// overlap: a profile of the three-player flop fixture put 82% of the evaluation walk in exactly these four loads
// (PERFORMANCE-5.9.md, section 2). A finished response state is not modified while it is evaluated, so the evaluation
// builds, once per call, one 32-bit number per hash slot: the offset of the slot's values. A lookup then reads the
// slot's key and its offset (two reads at the SAME index, issued together) and then the values: two waits instead of
// four. The index is a copy of numbers the table already holds - it cannot change which values are read - and it
// belongs to the evaluation call: it is charged to the evaluation's memory budget (4 bytes per hash slot; not built
// when that exceeds a quarter of the budget or when an offset does not fit 32 bits) and freed when the call returns.
// The strategy tables, their memory accounting and the checkpoint format are untouched.
struct SlotIndex59 {
  std::vector<uint32_t> off; bool on = false; size_t bytes = 0; const char *why = "";
  void build(const MW &m, long long budgetBytes) {
    if (m.dense) { why = "dense table: a lookup is already direct"; return; }
    if (m.hkeys.empty()) { why = "empty table"; return; }
    if (m.vals.size() > 0xffffffffULL) { why = "value offsets exceed 32 bits"; return; }
    if ((long long)(m.hkeys.size() * sizeof(uint32_t)) > budgetBytes / 4) { why = "the index would exceed a quarter of the evaluation memory"; return; }
    off.assign(m.hkeys.size(), 0); bytes = off.size() * sizeof(uint32_t);
    for (size_t i = 0; i < m.hkeys.size(); i++) if (m.hkeys[i] != -1) off[i] = (uint32_t)m.rows[(size_t)m.hrow[i]].off;
    on = true;
  }
};
// The values (regret slot, then average slot) of `seat`'s row at committed betting state `state`, or nullptr (no
// committed state, no hand group, no row): what findRow and the row record give, read through the index when there is one.
inline const double *values59(Evaluator &E, Keys59 &K, int state, int seat, int len) {
  if (state < 0) return nullptr;
  const Evaluator::Key &kk = K.of(E, seat, len); if (!kk.ok) return nullptr;
  const MW &m = E.m; const uint64_t key = rowKey((uint32_t)state, kk.hand, kk.code);
  if (K.slotOff) {
    const int64_t *hk = m.hkeys.data(); const size_t mask = m.hkeys.size() - 1; size_t i = MW::mix(key) & mask;
    __builtin_prefetch(K.slotOff + i);
    while (hk[i] != -1) { if ((uint64_t)hk[i] == key) return m.vals.data() + K.slotOff[i]; i = (i + 1) & mask; }
    return nullptr;
  }
  const long long row = m.findRow(key); return row >= 0 ? m.vals.data() + m.rows[(size_t)row].off : nullptr;
}
// Asks the processor to fetch the index lines of the next strategy lookup below child state `cs` while the walk is
// still busy elsewhere. A hint only: it reads nothing and decides nothing.
inline void ahead59(Evaluator &E, Keys59 &K, int cs, const BS &c, int len) {
  if (cs < 0 || c.kind != 0 || c.k <= 1) return;
  const Evaluator::Key &kk = K.of(E, c.actor, len); if (!kk.ok) return;
  const size_t i = MW::mix(rowKey((uint32_t)cs, kk.hand, kk.code)) & (E.m.hkeys.size() - 1);
  __builtin_prefetch(E.m.hkeys.data() + i); __builtin_prefetch(K.slotOff + i);
}
// The evaluators' averageOf / currentOf with their uniform fallback (Fallback::Uniform, the only one this measure allows).
inline void average59(const double *avg, int k, double *p) {
  double t = 0; if (avg) for (int a = 0; a < k; a++) t += avg[a];
  if (!(t > 0)) { for (int a = 0; a < k; a++) p[a] = 1.0 / k; return; }
  for (int a = 0; a < k; a++) p[a] = avg[a] / t;
}
inline void current59(const double *reg, int k, double *p) {
  if (!reg) { for (int a = 0; a < k; a++) p[a] = 1.0 / k; return; }
  double t = 0; for (int a = 0; a < k; a++) { p[a] = jsMax0(reg[a]); t += p[a]; }
  for (int a = 0; a < k; a++) p[a] = t ? p[a] / t : 1.0 / k;
}
template <class RNG> inline Pair58 pairValue59(Evaluator &E, Keys59 &K, int seat, int state, const BS &t, int len, RNG &rng, const PathTree::TermPots *trec = nullptr, int node = -1) {
  E.visits++; E.poll(SITE_TREE);
  if (t.kind == 2) { const double v = E.terminal(t, len, 1.0, false, trec); return {v, v}; }
  BS buf; int cs, cn; const PathTree::TermPots *rec;
  if (t.kind == 1) { const BS &c = *E.childAt(state, node, t, CHANCE_SLOT, buf, cs, rec, cn); return pairValue59(E, K, seat, cs, c, len + (len == 0 ? 3 : 1), rng, rec, cn); }
  if (t.k == 1) { const BS &c = *E.childAt(state, node, t, 0, buf, cs, rec, cn); return pairValue59(E, K, seat, cs, c, len, rng, rec, cn); }
  const int k = t.k; const double *reg = values59(E, K, state, t.actor, len);
  if (t.actor != seat) {
    double p[8]; average59(reg ? reg + k : nullptr, k, p);
    if (!E.sampleActions) {
      if (K.ahead) for (int a = 0; a < k; a++) if (p[a] > 0) { const BS &c = *E.childAt(state, node, t, a, buf, cs, rec, cn); ahead59(E, K, cs, c, len); }
      Pair58 out{0, 0};
      for (int a = 0; a < k; a++) {
        if (!(p[a] > 0)) continue;
        const BS &c = *E.childAt(state, node, t, a, buf, cs, rec, cn); const Pair58 v = pairValue59(E, K, seat, cs, c, len, rng, rec, cn);
        out.r += p[a] * v.r; out.s += p[a] * v.s;
      }
      return out;
    }
    const double x = rng.next(); double cum = 0; int a = k - 1;
    for (int b = 0; b < k; b++) { cum += p[b]; if (x < cum) { a = b; break; } }
    while (p[a] <= 0 && a > 0) a--;
    const BS &c = *E.childAt(state, node, t, a, buf, cs, rec, cn); return pairValue59(E, K, seat, cs, c, len, rng, rec, cn);
  }
  double pr[8], ps[8]; average59(reg ? reg + k : nullptr, k, pr); current59(reg, k, ps);
  if (K.ahead) for (int a = 0; a < k; a++) if (pr[a] > 0 || ps[a] > 0) { const BS &c = *E.childAt(state, node, t, a, buf, cs, rec, cn); ahead59(E, K, cs, c, len); }
  Pair58 out{0, 0};
  for (int a = 0; a < k; a++) {
    if (!(pr[a] > 0) && !(ps[a] > 0)) continue;
    const BS &c = *E.childAt(state, node, t, a, buf, cs, rec, cn); const Pair58 v = pairValue59(E, K, seat, cs, c, len, rng, rec, cn);
    out.r += pr[a] * v.r; out.s += ps[a] * v.s;
  }
  return out;
}
constexpr size_t AHEAD_SLOTS59 = 131072;   // hash slots from which the default walk fetches the children's index lines ahead
inline bool walk58() { static const bool old = [] { const char *v = std::getenv("EIGHTMAX_RESPONSE_WALK"); return v && !std::strcmp(v, "5.8"); }(); return old; }
} // namespace es
} // namespace

// Sampled evaluation of a finished response state.
// Request: {samples, seed, threads, timeLimitMs, memoryMiB, futureActions, streams, alpha}
//   streams  "5.9" (default: Philox4x64-10 counter streams) | "5.8" (the 5.8 streams; reproduces 5.8's bits)
//   alpha    one-sided error probability of `lowerBound` for THIS seat (default 0.05). mwcli --response passes the
//            seat's share of the familywise level (alpha / seats / analyses) so that the seats' bounds hold together.
// The fields 5.8 wrote are all still written and mean what they meant; what is new is listed in
// STATISTICAL-CHANGES-5.9.md, section 3.
extern "C" int mw_response_value(MW *m, const char *json, size_t len, JB *out, char *err, int errlen, volatile int *cancel) {
  using namespace es;
  if (!m || !m->es || m->response.seat < 0 || !m->response.finished) { fail(err, errlen, "The engine holds no finished response (mw_response_begin, mw_train, mw_response_end)"); return 409; }
  const Game &g = *m->es; const int n = m->n, seat = m->response.seat; const double t0 = nowSec();
  EvShared S; S.ctl.cancel = cancel;
  JV *req = nullptr;
  try { req = parseRequest(json, len, err, errlen); } catch (const QueryError &e) { fail(err, errlen, e.message.c_str()); return e.status; }
  struct Free { JV *v; ~Free() { json_free(v); } } freeReq{req};
  try {
    const Fields F(req, {"samples", "seed", "threads", "timeLimitMs", "memoryMiB", "futureActions", "streams", "alpha"});
    const std::string future = F.choice("futureActions", {"auto", "enumerate", "sample"}, "auto");
    const bool legacy = F.choice("streams", {"5.9", "5.8"}, "5.9") == "5.8";
    double alphaSeat = 0.05;
    if (const JV *a = F.get("alpha")) { if (a->type != J_NUM || !(a->num > 0) || !(a->num <= 0.5)) throw QueryError{400, "alpha must be a number above 0 and at most 0.5"}; alphaSeat = a->num; }
    constexpr long long BLOCK = 1024;
    const long long samples = F.optInt("samples", BLOCK, 1000000000LL, 200000), seed = F.optInt("seed", 0, 4294967295LL, 1), timeMs = F.optInt("timeLimitMs", 100, 86400000, 600000);
    const long long memoryMiB = F.optInt("memoryMiB", 16, 4096, 512); const int threads = effectiveThreads(F.optInt("threads", 1, 64, 0));
    const long long blocks = (samples + BLOCK - 1) / BLOCK, total = blocks * BLOCK;   // the sample count is fixed here, before any value is seen
    S.ctl.setDeadline(timeMs); S.device = Device::Cpu; S.memoryBudget = memoryMiB << 20; S.setCoverage(std::clamp<long long>(memoryMiB / 4, 4, 64)); S.fallback = Fallback::Uniform; S.ctl.maxVisits = LLONG_MAX; S.ctl.maxBoards = LLONG_MAX;
    const bool chip = m->tournament.start.empty();
    uint64_t board = 0; for (int i = 0; i < m->startLen; i++) board |= 1ULL << m->board[i];
    std::vector<std::vector<double>> cum((size_t)n);
    for (int p = 0; p < n; p++) {
      auto &c = cum[(size_t)p]; c.resize(m->hands[(size_t)p].size()); double t = 0;
      for (size_t i = 0; i < c.size(); i++) { const Hand &h = m->hands[(size_t)p][i]; if (!((board >> h.a & 1) || (board >> h.b & 1))) t += h.w; c[i] = t; }
      if (c.empty() || !(t > 0)) throw QueryError{422, "Seat " + std::to_string(p) + " has no possible hand"};
    }
    double lo, hi; utilityBounds(*m, g, seat, chip, lo, hi); const double range = hi - lo;
    EvalPool pool(*m, g, Pol::Average, false, seat, &S, threads);
    const long long subtreeNodes = pool.main().subtree(g.rootState, 4097);
    const bool sampleActions = future == "sample" || (future == "auto" && subtreeNodes > 4096);
    std::vector<Block58> done((size_t)blocks);
    // EIGHTMAX_RESPONSE_INDEX (comparisons only; the values never depend on it): 0 no index, 1 index, 2 index and the
    // children's index lines fetched ahead, unset: index, and fetching ahead when the opponents' actions are enumerated
    // AND the hash table has at least 131,072 slots (AHEAD_SLOTS59).
    // Measured (PERFORMANCE-5.9.md, section 2): the index helps or is neutral on every hashed table. Fetching ahead
    // helps the enumerated walk on tables that do not fit the processor's caches (three-player flop and preflop
    // fixtures: 2.00 against 1.87 and 2.35 against 2.05 times the 5.8 walk); on small tables, where every lookup is
    // already in the cache, the extra pass over the children only costs (10 to 20% on four reference games), and in
    // the sampled walk it visits children that are never walked.
    SlotIndex59 index; static const int mode59 = [] { const char *v = std::getenv("EIGHTMAX_RESPONSE_INDEX"); return v && *v ? std::atoi(v) : -1; }();
    if (!walk58() && mode59 != 0) { index.build(*m, S.memoryBudget); if (index.on && !S.ctl.tryCharge(index.bytes, S.memoryBudget)) { index.off.clear(); index.off.shrink_to_fit(); index.on = false; index.why = "the evaluation memory budget is exhausted"; } }
    S.ctl.unitsTotal += blocks;
    parallelFor(S.ctl, threads, (size_t)blocks, [&](int w, size_t b) {
      Evaluator &E = pool.at(w); E.exact = false; E.sampleActions = sampleActions; E.actor = seat; E.dev = nullptr;
      Block58 &B = done[b]; Keys59 keys; const bool old = walk58(); keys.slotOff = index.on ? index.off.data() : nullptr; keys.ahead = index.on && (mode59 == 2 || (mode59 < 0 && !sampleActions && m->hkeys.size() >= AHEAD_SLOTS59));
      auto run = [&](auto &deals, auto &actions) {
        for (long long i = 0; i < BLOCK; i++) {
          std::copy_n(m->board, 5, E.cards);
          if (!drawDeal58(E, cum, deals, board, m->startLen, 200000)) { B.failed = true; return; }
          keys.reset();
          const Pair58 v = old ? pairValue(E, seat, 0, g.rootState, m->startLen, actions) : pairValue59(E, keys, seat, 0, g.rootState, m->startLen, actions);
          const double d = v.r - v.s;
          B.n++; B.d += d; B.d2 += d * d; B.r += v.r; B.r2 += v.r * v.r; B.s += v.s; B.s2 += v.s * v.s;
          B.mn = std::min(B.mn, d); B.mx = std::max(B.mx, d); B.vmn = std::min({B.vmn, v.r, v.s}); B.vmx = std::max({B.vmx, v.r, v.s});
        }
      };
      if (legacy) { Rng64 deals{seed58((uint64_t)seed, (uint64_t)seat, b, 0)}, actions{seed58((uint64_t)seed, (uint64_t)seat, b, 1)}; run(deals, actions); }
      else { Rng59 deals((uint64_t)seed, (uint64_t)seat, b, 0), actions((uint64_t)seed, (uint64_t)seat, b, 1); run(deals, actions); }
      if (B.failed) return;
      S.ctl.samples += BLOCK; S.ctl.unitsDone++;
    });
    Block58 T; long long visits = 0;
    for (const Block58 &B : done) {   // block order: the same sums for every thread count
      if (B.failed) throw QueryError{422, "Compatible hands are too rare to sample reliably"};
      T.n += B.n; T.d += B.d; T.d2 += B.d2; T.r += B.r; T.r2 += B.r2; T.s += B.s; T.s2 += B.s2;
      T.mn = std::min(T.mn, B.mn); T.mx = std::max(T.mx, B.mx); T.vmn = std::min(T.vmn, B.vmn); T.vmx = std::max(T.vmx, B.vmx);
    }
    for (auto &e : pool.ev) if (e) visits += e->visits;
    if (T.n != total) throw QueryError{500, "The evaluation lost samples"};
    const double N = (double)T.n;
    auto var = [&](double sum, double sq) { const double mu = sum / N; return std::max(0.0, (sq - N * mu * mu) / (N - 1)); };
    const double gain = T.d / N, vd = var(T.d, T.d2), se = std::sqrt(vd / N);
    const double tol = 1e-9 * std::max(1.0, std::fabs(hi) + std::fabs(lo));
    const bool within = T.vmn >= lo - tol && T.vmx <= hi + tol && T.mn >= -range - tol && T.mx <= range + tol;
    // Distribution-free interval (study_stats55.hpp): samples in [-range, range], i.e. width 2 * range.
    const double alpha = 0.05, half = within ? study55::ebHalf(vd, 2 * range, N, alpha) : NAN;
    const double z95 = 1.6448536269514722;   // one-sided 95% point of the normal distribution
    const double oneSided = within ? stats59::ebOneSidedHalf(vd, 2 * range, N, alphaSeat) : NAN;   // 5.9: (A) of response_stats59.hpp
    jb_printf(out, "{\"engine\":\"native trained response\",\"version\":\"5.9\",\"calculation\":\"%s\",\"seat\":%d,\"players\":%d,\"threads\":%d,\"seed\":%lld,\"samples\":%lld,\"blockDeals\":%lld", legacy ? "response-5.8-paired-v1" : "response-5.9-paired-v2", seat, n, threads, seed, T.n, BLOCK);
    utilityJson(out, *m);
    jb_puts(out, ",\"estimand\":\"V_seat(response, sigma_-seat) - V_seat(sigma): the gain of one fixed response strategy of this seat (the average strategy of the response training) against the other seats' average strategies, from the study root\"");
    jb_puts(out, ",\"direction\":\"lower bound of this seat's best-response gain inside the study's betting abstraction; not an upper bound and not exploitability\"");
    jb_printf(out, ",\"evaluation\":\"deals independent of the response training; own actions enumerated under both strategies in one walk, %s\",\"opponentActions\":\"%s\"",
              sampleActions ? "each opponent action sampled once (common to both)" : "opponent actions enumerated (only the cards are sampled)", sampleActions ? "sampled" : "enumerated");
    // 5.9: which numbers were drawn, and what is known about them
    jb_printf(out, ",\"randomStreams\":{\"id\":\"%s\",\"method\":\"%s\",\"streamsPerBlock\":2,\"address\":\"%s\",\"partition\":\"%s\",\"independentOfResponseTraining\":true}",
              legacy ? "5.8" : "5.9", legacy ? STREAMS58 : STREAMS59,
              legacy ? "state = hash(seed, seat, block, purpose) on the single SplitMix64 cycle of 2^64 states" : "key = (seed, 0x45694d6178353959); counter = (group of four numbers, block, seat, purpose); purpose 0 cards, 1 opponent actions",
              legacy ? "none proven: two block streams overlap with probability about 4 B^2 L / 2^64 for B blocks of at most L numbers (MATHEMATICAL-VALIDATION-5.8.md, section 2)"
                     : "proven for one seed: Philox4x64-10 is a bijection of the 256-bit counter for a fixed key, so two different (seat, block, purpose, group) never receive the same output; no stream can overlap another or run out");
    jb_puts(out, ",\"gain\":{\"mean\":"); jnumOrNull(out, gain); jb_puts(out, ",\"gainBits\":"); jbits(out, gain); jb_puts(out, ",\"stdErr\":"); jnumOrNull(out, se);
    jb_puts(out, ",\"ci95\":["); jnumOrNull(out, gain - 1.959963984540054 * se); jb_putc(out, ','); jnumOrNull(out, gain + 1.959963984540054 * se); jb_puts(out, "],\"ci95Kind\":\"normal approximation (central limit theorem); see bounded for the distribution-free interval\"");
    jb_puts(out, ",\"sampleMin\":"); jnumOrNull(out, T.mn); jb_puts(out, ",\"sampleMax\":"); jnumOrNull(out, T.mx); jb_putc(out, '}');
    jb_puts(out, ",\"bounded\":{\"calculation\":\""); jb_puts(out, study55::CALCULATION); jb_puts(out, "\",\"utilityLow\":"); jnumOrNull(out, lo); jb_puts(out, ",\"utilityHigh\":"); jnumOrNull(out, hi);
    jb_puts(out, ",\"sampleRange\":"); jnumOrNull(out, 2 * range); jb_printf(out, ",\"withinBounds\":%s,\"alpha\":0.05,\"half\":", within ? "true" : "false"); jnumOrNull(out, half);
    jb_puts(out, ",\"lo\":"); jnumOrNull(out, gain - half); jb_puts(out, ",\"hi\":"); jnumOrNull(out, gain + half); jb_putc(out, '}');
    // The best-response gain is >= 0 by definition (the seat may keep sigma), so a negative bound is replaced by 0.
    jb_puts(out, ",\"bestResponseGainLowerBound\":{\"normal95\":"); jnumOrNull(out, std::max(0.0, gain - z95 * se)); jb_puts(out, ",\"bounded95\":"); jnumOrNull(out, std::isfinite(half) ? std::max(0.0, gain - half) : NAN);
    jb_puts(out, ",\"note\":\"normal95: one-sided 95% (normal approximation). bounded95: distribution-free at level 0.05 (two-sided empirical Bernstein). Both floored at 0, the value of keeping sigma.\"}");
    // 5.9: the sample as the simultaneous statement needs it, and the one-sided distribution-free bound of this seat.
    jb_printf(out, ",\"statistics\":{\"samples\":%lld,\"mean\":", T.n); jnumOrNull(out, gain); jb_puts(out, ",\"sampleVariance\":"); jnumOrNull(out, vd); jb_puts(out, ",\"sampleVarianceBits\":"); jbits(out, vd);
    jb_puts(out, ",\"provenSampleRange\":"); jnumOrNull(out, 2 * range);
    jb_printf(out, ",\"withinProvenRange\":%s,\"sampleCountFixedInAdvance\":true,\"responseFixedBeforeEvaluation\":true,\"identicallyDistributedEqualWeights\":true}", within ? "true" : "false");
    jb_printf(out, ",\"lowerBound\":{\"calculation\":\"%s\",\"method\":\"%s\",\"alpha\":", stats59::CALC_SEAT, stats59::METHOD_SEAT); jnumOrNull(out, alphaSeat);
    jb_puts(out, ",\"confidence\":"); jnumOrNull(out, 1 - alphaSeat); jb_puts(out, ",\"half\":"); jnumOrNull(out, oneSided);
    jb_puts(out, ",\"responseGain\":"); jnumOrNull(out, std::isfinite(oneSided) ? gain - oneSided : NAN);
    jb_puts(out, ",\"bestResponseGain\":"); jnumOrNull(out, std::isfinite(oneSided) ? std::max(0.0, gain - oneSided) : NAN);
    jb_printf(out, ",\"calibrated\":%s,\"reason\":\"%s\"", std::isfinite(oneSided) ? "true" : "false", std::isfinite(oneSided) ? "" : within ? "evaluationErrorUnavailable" : "payoffBoundViolated");
    jb_puts(out, ",\"reading\":\"with probability at least `confidence` (over the evaluation deals, for the response that was trained) the gain of this response is at least responseGain, and this seat's best-response gain at least bestResponseGain (never below 0: the seat may keep sigma). One-sided; no normal approximation. It is one seat's statement: for several seats together use summary.simultaneous.\"}");
    jb_puts(out, ",\"responseValue\":{\"mean\":"); jnumOrNull(out, T.r / N); jb_puts(out, ",\"stdErr\":"); jnumOrNull(out, std::sqrt(var(T.r, T.r2) / N));
    jb_puts(out, "},\"policyValue\":{\"mean\":"); jnumOrNull(out, T.s / N); jb_puts(out, ",\"stdErr\":"); jnumOrNull(out, std::sqrt(var(T.s, T.s2) / N)); jb_putc(out, '}');
    jb_printf(out, ",\"walk\":{\"version\":\"%s\",\"offsetIndex\":%s,\"offsetIndexBytes\":%zu,\"lookAhead\":%s,\"offsetIndexNote\":\"%s\",\"valuesDependOnIt\":false}", walk58() ? "5.8" : "5.9", index.on ? "true" : "false", index.bytes,
              index.on && (mode59 == 2 || (mode59 < 0 && !sampleActions && m->hkeys.size() >= AHEAD_SLOTS59)) ? "true" : "false", index.on ? "" : walk58() ? "the 5.8 walk was requested" : index.why);
    jb_printf(out, ",\"visits\":%lld,\"elapsedMs\":%.1f}", visits, (nowSec() - t0) * 1000);
    return 200;
  } catch (const QueryError &e) { fail(err, errlen, e.message.c_str()); return e.status; }
  catch (const EvStop &e) {
    if (e.code == 1) { fail(err, errlen, "Calculation cancelled; no result is reported"); return 409; }
    fail(err, errlen, "Time limit reached before the evaluation completed; a partial sample is never reported (the sample count is fixed in advance)"); return 408;
  }
  catch (const EvUnavailable &e) { fail(err, errlen, ("Unavailable: " + e.why).c_str()); return 422; }
  catch (const EvBudget &) { fail(err, errlen, "Evaluation exceeds its budget"); return 422; }
  catch (const EvMemory &) { fail(err, errlen, "Evaluation memory budget exceeded"); return 503; }
  catch (const std::bad_alloc &) { fail(err, errlen, "Out of memory"); return 503; }
}

// The first `count` numbers of the 5.9 evaluation stream with this address, as 64-bit patterns and as the doubles the
// evaluation uses: {"method","seed","seat","block","purpose","bits":["%016x",...],"unit":[...]}. For independent
// implementations (tools/independent_stats59.py compares them with Philox4x64-10 written in Python integers).
extern "C" int mw_stream59(unsigned long long seed, int seat, long long block, int purpose, int count, JB *out) {
  using namespace es;
  if (seat < 0 || seat > 7 || block < 0 || purpose < 0 || purpose > 1 || count < 1 || count > 4096) return 400;
  Rng59 bitsOf(seed, (uint64_t)seat, (uint64_t)block, (uint64_t)purpose), unitOf(seed, (uint64_t)seat, (uint64_t)block, (uint64_t)purpose);
  jb_printf(out, "{\"method\":\"%s\",\"seed\":%llu,\"seat\":%d,\"block\":%lld,\"purpose\":%d,\"bits\":[", STREAMS59, seed, seat, block, purpose);
  for (int i = 0; i < count; i++) jb_printf(out, "%s\"%016llx\"", i ? "," : "", (unsigned long long)bitsOf.bits());
  jb_puts(out, "],\"unit\":["); for (int i = 0; i < count; i++) jb_printf(out, "%s%.17g", i ? "," : "", unitOf.next());
  jb_puts(out, "]}"); return 200;
}

// ---- 5.9: in-engine checks of parts that have no command-line surface (used by mwcli --selftest59) ----
extern "C" int mw_selftest59(JB *out) {
  using namespace es; int failed = 0; bool first = true;
  auto item = [&](const char *name, bool ok, const std::string &detail) {
    if (!ok) failed++;
    jb_puts(out, first ? "{\"name\":" : ",{\"name\":"); first = false; jb_str(out, name);
    jb_printf(out, ",\"passed\":%s,\"detail\":", ok ? "true" : "false"); jb_str(out, detail.c_str()); jb_putc(out, '}');
  };
  auto hex = [](uint64_t v) { char b[20]; std::snprintf(b, sizeof b, "%016llx", (unsigned long long)v); return std::string(b); };
  jb_putc(out, '[');
  try {
    { // Philox4x64-10 against the known-answer vectors of the reference implementation (Random123, kat_vectors:
      // "philox4x64 10": counter and key all zero, all ones, and the digits of pi). The same three vectors were
      // recomputed with numpy.random.Philox and with an independent big-integer implementation in Python
      // (tools/independent_stats59.py; MATHEMATICAL-VALIDATION-5.9.md, section 5).
      struct Kat { uint64_t c[4], k[2], want[4]; };
      const Kat kats[3] = {
        {{0, 0, 0, 0}, {0, 0}, {0x16554d9eca36314cULL, 0xdb20fe9d672d0fdcULL, 0xd7e772cee186176bULL, 0x7e68b68aec7ba23bULL}},
        {{~0ULL, ~0ULL, ~0ULL, ~0ULL}, {~0ULL, ~0ULL}, {0x87b092c3013fe90bULL, 0x438c3c67be8d0224ULL, 0x9cc7d7c69cd777b6ULL, 0xa09caebf594f0ba0ULL}},
        {{0x243f6a8885a308d3ULL, 0x13198a2e03707344ULL, 0xa4093822299f31d0ULL, 0x082efa98ec4e6c89ULL}, {0x452821e638d01377ULL, 0xbe5466cf34e90c6cULL}, {0xa528f45403e61d95ULL, 0x38c72dbd566e9788ULL, 0xa5a1610e72fd18b5ULL, 0x57bd43b5e52b7fe6ULL}}};
      int bad = 0; std::string got;
      for (const Kat &t : kats) { uint64_t o[4]; Philox4x64::block(t.c, t.k, o); for (int i = 0; i < 4; i++) bad += o[i] != t.want[i]; got += (got.empty() ? "" : "; ") + hex(o[0]) + " " + hex(o[1]) + " " + hex(o[2]) + " " + hex(o[3]); }
      item("evaluation random numbers: Philox4x64-10 reproduces the three known-answer vectors of its reference implementation", bad == 0, std::to_string(bad) + " of 12 output words differ; computed: " + got);
    }
    { // The round function is invertible (which is what makes the generator a bijection of the counter for a fixed
      // key): undoing ten rounds returns the counter. The inverse multiplies by the inverses of the two odd
      // multipliers modulo 2^64 and needs the high halves that the forward round discarded, which the forward round
      // also fed into the other words; the inverse recovers them from the low halves.
      auto inv64 = [](uint64_t a) { uint64_t x = a; for (int i = 0; i < 6; i++) x *= 2 - a * x; return x; };   // Newton iteration: inverse of an odd number modulo 2^64
      const uint64_t M0 = 0xD2E7470EE14C6C93ULL, M1 = 0xCA5A826395121157ULL, I0 = inv64(M0), I1 = inv64(M1);
      uint64_t x = 0x5900c0de5900c0deULL; auto next = [&] { x ^= x << 13; x ^= x >> 7; x ^= x << 17; return x; };
      int bad = 0; const int N = 20000;
      for (int t = 0; t < N; t++) {
        const uint64_t c0[4] = {next(), next(), next(), next()}, k0[2] = {next(), next()}; uint64_t o[4]; Philox4x64::block(c0, k0, o);
        uint64_t ks[10][2]; ks[0][0] = k0[0]; ks[0][1] = k0[1]; for (int r = 1; r < 10; r++) { ks[r][0] = ks[r - 1][0] + 0x9E3779B97F4A7C15ULL; ks[r][1] = ks[r - 1][1] + 0xBB67AE8584CAA73BULL; }
        uint64_t c[4] = {o[0], o[1], o[2], o[3]};
        for (int r = 9; r >= 0; r--) {   // out = {hi1 ^ in1 ^ k0, lo1, hi0 ^ in3 ^ k1, lo0}; lo1 = M1 * in2, lo0 = M0 * in0 (mod 2^64)
          const uint64_t in2 = c[1] * I1, in0 = c[3] * I0; uint64_t hi0, lo0, hi1, lo1; Philox4x64::mulhilo(M0, in0, hi0, lo0); Philox4x64::mulhilo(M1, in2, hi1, lo1);
          const uint64_t in1 = c[0] ^ hi1 ^ ks[r][0], in3 = c[2] ^ hi0 ^ ks[r][1]; c[0] = in0; c[1] = in1; c[2] = in2; c[3] = in3;
        }
        bad += c[0] != c0[0] || c[1] != c0[1] || c[2] != c0[2] || c[3] != c0[3];
      }
      item("evaluation random numbers: Philox4x64-10 is inverted round by round (a bijection of the counter for a fixed key)", bad == 0 && M0 * I0 == 1 && M1 * I1 == 1, std::to_string(N) + " random (counter, key) pairs, " + std::to_string(bad) + " not recovered from their output");
    }
    { // Addresses: every (seat, block, purpose) of one seed has its own stream; a stream is a function of its address
      // alone (drawn again, alone and after other streams, it gives the same numbers); the 5.8 stream is unchanged.
      std::vector<std::array<uint64_t, 2>> firsts; firsts.reserve(8 * 20000 * 2);
      for (uint64_t seat = 0; seat < 8; seat++) for (uint64_t block = 0; block < 20000; block++) for (uint64_t purpose = 0; purpose < 2; purpose++) { Rng59 r(59, seat, block, purpose); const uint64_t a = r.bits(), b = r.bits(); firsts.push_back({a, b}); }
      const size_t all = firsts.size(); std::sort(firsts.begin(), firsts.end()); const size_t distinct = (size_t)(std::unique(firsts.begin(), firsts.end()) - firsts.begin());
      Rng59 a(59, 3, 777, 1); uint64_t keep[9]; for (auto &v : keep) v = a.bits();
      { Rng59 other(59, 3, 778, 1); for (int i = 0; i < 1000; i++) other.bits(); }
      Rng59 b(59, 3, 777, 1); int moved = 0; for (auto v : keep) moved += b.bits() != v;
      Rng59 c(60, 3, 777, 1); int same = 0; for (auto v : keep) same += c.bits() == v;
      Rng59 u(59, 0, 0, 0); double lo = 1, hi = 0, sum = 0, sq = 0; const int N = 1000000; for (int i = 0; i < N; i++) { const double v = u.next(); lo = std::min(lo, v); hi = std::max(hi, v); sum += v; sq += v * v; }
      const double mean = sum / N, var = sq / N - mean * mean;   // uniform on [0, 1): mean 1/2 (standard error 0.00029), variance 1/12
      Rng64 old{0}; const bool oldSame = old.bits() == 0xe220a8397b1dcdafULL && seed58(58, 0, 0, 0) == seed58(58, 0, 0, 0) && seed58(58, 0, 0, 0) != seed58(58, 0, 1, 0);
      item("evaluation random numbers: one stream per (seat, block, purpose), a pure function of its address; values lie in [0, 1)",
           distinct == all && moved == 0 && same == 0 && lo >= 0 && hi < 1 && std::fabs(mean - 0.5) < 0.0015 && std::fabs(var - 1.0 / 12) < 0.001 && oldSame,
           std::to_string(all) + " streams, " + std::to_string(distinct) + " distinct; redrawn stream differs in " + std::to_string(moved) + " of 9 numbers; another seed repeats " + std::to_string(same) + " of 9; 1,000,000 draws in [" + std::to_string(lo) + ", " + std::to_string(hi) + "], mean " + std::to_string(mean) + ", variance " + std::to_string(var));
    }
  } catch (const std::exception &e) { item("in-engine checks ran to the end", false, e.what()); }
  jb_putc(out, ']');
  return failed;
}
