// EightMax 5.13 (Phase 3): the satellite-field payoff model, "satfield-5.13-v1".
//
// A satellite pays N equal prizes ("seats"). With at most 16 players the existing ICM (icm.hpp: Malmuth-Harville by
// exact finishing-set recursion) with N equal payouts IS the satellite. This file is for fields larger than that:
// the seats at the table plus any number of players at other tables, who keep their stacks during the hand.
//
// MATHEMATICS (MATHEMATICAL-VALIDATION-5.13.md proves it). Malmuth-Harville draws the finishing order as a
// Plackett-Luce ranking with the stacks as weights. Independent exponential clocks T_j with rates s_j, read in
// increasing order, have exactly that law (the first clock is first place). So for a live player i
//     P(i finishes in the top N) = Int_0^inf s_i exp(-s_i t) * P( C_i(t) <= N-1 ) dt,
// where C_i(t) counts the OTHER players whose clock rang before t: a sum of independent indicators with
// probabilities 1 - exp(-s_j t). A player without chips has finished behind every player with chips and gets 0
// (the model requires more players with chips at other tables than there are seats, so no seat is left for him).
//
// NUMERICS. Rates are stacks divided by the mean field stack. The integral is taken over y in (0,1) with
// t = tau y / (1 - y), tau = the time at which N field players are expected to have finished, by 8-point
// Gauss-Legendre on M uniform panels plus 20 panels halving towards each end (for very large and very small
// stacks). The nodes depend on the field and N only, so the field's count distribution is tabulated once per study:
// for each node, P(field count <= N-1-b) for b = 0..7. An evaluation adds the at most seven other live seats.
//
// DETERMINISM. No library exponential or logarithm is called: satExp() is a fixed sequence of IEEE-754 double
// additions, multiplications, divisions and one exact scaling, so every platform computes the same bits
// (the JavaScript mirror in web/lib_icm.js performs the same operations in the same order).
#pragma once
#include <cmath>
#include <vector>
#include <array>
#include <utility>
namespace sat513 {
static constexpr const char *MODEL = "satfield-5.13-v1";
static constexpr int MAX_SEATS = 2000, MAX_FIELD = 5000; static constexpr double MAX_WORK = 2.0e6;   // field players x seats
// exp(x) for x <= 0. |error| about 1 ulp; what matters here is that it is the same on every platform.
inline double satExp(double x) {
  if (!(x < 0)) return 1.0;
  if (x < -700.0) return 0.0;
  const double LN2HI = 6.93147180369123816490e-01, LN2LO = 1.90821492927058770002e-10, INVLN2 = 1.44269504088896338700e+00;
  const double kf = std::floor(x * INVLN2 + 0.5);
  const double r = (x - kf * LN2HI) - kf * LN2LO;
  double p = 1.0 / 6227020800.0;                 // 1/13!
  p = p * r + 1.0 / 479001600.0; p = p * r + 1.0 / 39916800.0; p = p * r + 1.0 / 3628800.0; p = p * r + 1.0 / 362880.0;
  p = p * r + 1.0 / 40320.0; p = p * r + 1.0 / 5040.0; p = p * r + 1.0 / 720.0; p = p * r + 1.0 / 120.0;
  p = p * r + 1.0 / 24.0; p = p * r + 1.0 / 6.0; p = p * r + 0.5; p = p * r + 1.0; p = p * r + 1.0;
  return std::ldexp(p, (int)kf);
}
// 8-point Gauss-Legendre on (-1, 1): abscissae and weights (symmetric pairs).
static constexpr double GLX[4] = {0.18343464249564980493947614236018, 0.52553240991632898581773904918925, 0.79666647741362673959155393647583, 0.96028985649753623168356086856947};
static constexpr double GLW[4] = {0.36268378337836198296515044927720, 0.31370664587788728733796220198660, 0.22238103445337447054435599442624, 0.10122853629037625915253135430996};
struct Field {
  int seats = 0; long long players = 0; double mean = 0, tau = 0, chips = 0;
  std::vector<std::pair<double, int>> groups;        // (stack, count), as given
  std::vector<double> t, w;                          // nodes: time, and weight including dt/dy
  std::vector<std::array<double, 8>> cdf;            // per node: P(field count <= seats-1-b), b = 0..7 (0 when negative)
  bool on() const { return seats > 0; }
  int panels() const { const int root = (int)std::ceil(std::sqrt((double)seats)); const int m = 8 * root; return m < 64 ? 64 : m > 256 ? 256 : m; }
  // Returns an empty string, or why the field cannot be used.
  std::string prepare() {
    players = 0; chips = 0;
    for (auto &g : groups) { if (!(g.first > 0) || !std::isfinite(g.first) || g.second < 1) return "every field group needs a positive stack and a count of at least 1"; players += g.second; chips += g.first * g.second; }
    if (seats < 1 || seats > MAX_SEATS) return "seats must be from 1 to 2000";
    if (players < 1 || players > MAX_FIELD) return "the field must hold 1 to 5000 players at other tables";
    if (players < seats + 1) return "the field must hold more players than there are seats (otherwise use the ordinary ICM with equal prizes)";
    if ((double)players * seats > MAX_WORK) return "field players x seats must not exceed 2,000,000";
    mean = chips / (double)players;
    // tau: expected number of field players finished by tau equals seats (bisection; f is increasing in t)
    auto expected = [&](double time) { double e = 0; for (auto &g : groups) e += g.second * (1.0 - satExp(-(g.first / mean) * time)); return e; };
    double lo = 0, hi = 1; for (int i = 0; i < 200 && expected(hi) < seats; i++) hi *= 2;
    for (int i = 0; i < 80; i++) { const double mid = 0.5 * (lo + hi); if (expected(mid) < seats) lo = mid; else hi = mid; }
    tau = 0.5 * (lo + hi);
    // panels in y: 20 halving towards 0, M uniform, 20 halving towards 1
    const int M = panels(); std::vector<double> edge; const double h = 1.0 / M;
    edge.push_back(0.0); { double e = h; std::vector<double> small; for (int i = 0; i < 20; i++) { e *= 0.5; small.push_back(e); } for (int i = 19; i >= 0; i--) edge.push_back(small[(size_t)i]); }
    for (int k = 1; k < M; k++) edge.push_back(k * h);
    { double e = h; for (int i = 0; i < 20; i++) { e *= 0.5; edge.push_back(1.0 - e); } } edge.push_back(1.0);
    // the last edge is y = 1 (t = infinity): the last panel is dropped; its integrand is below exp(-tau M 2^20 s) times
    // P(fewer than N of more than N field players have finished), i.e. nothing
    t.clear(); w.clear();
    for (size_t e = 0; e + 2 < edge.size(); e++) {
      const double a = edge[e], b = edge[e + 1], half = 0.5 * (b - a), mid = 0.5 * (a + b);
      for (int q = 0; q < 8; q++) {
        const int j = q < 4 ? 3 - q : q - 4; const double x = q < 4 ? -GLX[j] : GLX[j];
        const double y = mid + half * x, one = 1.0 - y;
        t.push_back(tau * y / one); w.push_back(GLW[j] * half * tau / (one * one));
      }
    }
    // the field's count distribution at each node, truncated at seats (larger counts leave no seat)
    cdf.assign(t.size(), {}); std::vector<double> d((size_t)seats);
    for (size_t k = 0; k < t.size(); k++) {
      std::fill(d.begin(), d.end(), 0.0); d[0] = 1.0; int top = 0;   // d[c] = P(count = c), c <= top
      for (auto &g : groups) {
        const double miss = satExp(-(g.first / mean) * t[k]), hit = 1.0 - miss;
        for (int r = 0; r < g.second; r++) {
          const int upto = top + 1 < seats ? top + 1 : seats - 1;
          for (int c = upto; c >= 1; c--) d[(size_t)c] = d[(size_t)c] * miss + d[(size_t)c - 1] * hit;
          d[0] = d[0] * miss; top = upto;
        }
      }
      double run = 0; std::array<double, 8> &row = cdf[k];
      // row[b] = sum of d[c] for c <= seats-1-b
      std::vector<double> &dd = d; double acc[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
      for (int c = 0; c < seats; c++) { run += dd[(size_t)c]; const int b = seats - 1 - c; if (b < 8) acc[b] = run; }
      for (int b = 0; b < 8; b++) row[(size_t)b] = seats - 1 - b >= 0 ? acc[b] : 0.0;
    }
    return "";
  }
  // chips[0..n-1]: stacks of the table's seats after the hand, in BB. Replaced by their seat probabilities.
  void evaluate(double *chips_, int n) const {
    int live[8], a = 0; double rate[8], out[8];
    for (int i = 0; i < n; i++) { out[i] = 0; if (chips_[i] > 1e-9) { live[a] = i; rate[a] = chips_[i] / mean; a++; } }
    double miss[8], acc[8]; for (int j = 0; j < a; j++) acc[j] = 0;
    for (size_t k = 0; k < t.size(); k++) {
      const double time = t[k]; const std::array<double, 8> &F = cdf[k];
      for (int j = 0; j < a; j++) miss[j] = satExp(-rate[j] * time);
      for (int i = 0; i < a; i++) {
        // distribution of the number of OTHER live seats finished by now
        double pb[8]; pb[0] = 1.0; int top = 0;
        for (int j = 0; j < a; j++) if (j != i) {
          const double m = miss[j], hgt = 1.0 - m;
          pb[top + 1] = pb[top] * hgt;
          for (int c = top; c >= 1; c--) pb[c] = pb[c] * m + pb[c - 1] * hgt;
          pb[0] = pb[0] * m; top++;
        }
        double g = 0; for (int b = 0; b <= top; b++) g += pb[b] * F[(size_t)b];
        acc[i] += w[k] * rate[i] * miss[i] * g;
      }
    }
    for (int j = 0; j < a; j++) out[live[j]] = acc[j] > 1.0 ? 1.0 : acc[j];
    for (int i = 0; i < n; i++) chips_[i] = out[i];
  }
};
// A state continues only under the payoff model it was trained for (model, seats, field size and chips).
inline const char *payoffMismatch(const Field &f, const char *model, double seats, double players, double chips) {
  if (!f.on()) return model ? "State was trained under the satellite-field payoff model (see its \"payoffModel\" header field) and cannot be continued by a study without it" : nullptr;
  if (!model) return "State was not trained under the satellite-field payoff model of this study (its header names no \"payoffModel\")";
  if (std::string(model) != MODEL) return "State was trained under another payoff model than satfield-5.13-v1";
  if (seats != f.seats || players != (double)f.players || chips != f.chips) return "State was trained for another satellite (seats, or the number or chips of the players at other tables, differ)";
  return nullptr;
}
}
