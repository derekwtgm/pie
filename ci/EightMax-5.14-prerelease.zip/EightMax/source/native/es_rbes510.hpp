// EightMax 5.10 (experimental, opt-in: spec "estimator":"rbes"): Rao-Blackwellised external sampling ("RB-ES").
// Data structures; the traversal is in es_rbes510_walk.hpp (members of Walker) and the preparation of a deal in
// mw_es_impl.hpp (rbPrepareDeal). Included inside namespace es by mw_es.hpp.
//
// The default trainer samples one hand for every seat and, for the updating seat i, updates the information sets of
// that ONE hand. RB-ES keeps the default deal sampler and replaces two sampled quantities by their conditional
// expectations:
//
//  (R1) the updating seat's hand. Given the sampled board and the opponents' sampled hands (D_-i), the hand of seat
//       i has the conditional distribution c(x) = w_i(x) / sum_{y compatible} w_i(y) over the hands x of its range
//       that share no card with D_-i. One traversal carries a vector over all compatible x. An opponent's decision
//       never depends on x, so the opponents' sampled actions are shared by every x, and the increments written are
//           regret(I(x), a)  += c(x) * step    * (pi_-i / q_-i) * (v_a[x] - sum_b sigma_x(b) v_b[x])
//           average(I(x), a) += c(x) * avgStep * (pi_i[x] / q_-i) * sigma_x(a)
//       summed over the hands x that share a table row (one row per hand in the exact abstraction, one row per hand
//       group with Compact/Detailed keys). This is E[default increment | D_-i, opponents' sampled actions].
//
//  (R2) an opponent's action whose child is TERMINAL (a fold that ends the hand, a call that closes the betting with
//       nothing left to deal or act). At an opponent decision with terminal children T and non-terminal children N
//       the value is
//           v[x] = sum_{a in T} sigma(a) u_a[x]  +  [N not empty] * (sigma(a*) / p(a*)) * v_{a*}[x],
//       a* drawn from p(a) = q(a) / q(N) on N (q = keep * sigma + mix / k as in the default). The terminal part is
//       exact (no sampling); the sampled part is importance-weighted by the probability actually used, and the
//       sampling reach below a* is multiplied by p(a*). When N is empty nothing is sampled.
//
// Both are conditional expectations of an unbiased estimator of the counterfactual regret and of the reach-weighted
// strategy, so the expected increments are those targets (MATHEMATICAL-VALIDATION-5.10.md); the regret matching, the
// linear weighting, the merge and the table are the default trainer's. Not combined with the 4.7/5.5 experimental
// estimators, DCFR, regret matching+, stratified or Latin deals, or turn/river representative groups (refused).
#pragma once
constexpr uint16_t RB_NONE = 0xffff;
// Row keys of one seat at one street for given public cards: for every hand of the seat's range the index of its key
// among the distinct keys (RB_NONE: the hand shares a card with the public cards), and per distinct key the fields of
// the row key (hand field, code field). Exact abstraction: one static entry per seat (hand field = strategy hand; the
// code field is the street's card code, the same for every hand). Grouped keys: hand field 0, code = group id.
struct RbEntry { std::vector<uint16_t> idx; std::vector<uint32_t> code; std::vector<uint16_t> hand; };
// Showdown scores of every hand of a seat's range for one complete board, and the hands ordered by (score, index).
// A pure function of the range and the board; cached like the keys when at most two cards follow the starting street.
struct RbScores { std::vector<int> score; std::vector<uint16_t> order; };
// Entries of grouped keys by (seat, street index, public cards after the starting street). A CACHE of pure functions
// of the game and the dictionary: never saved, rebuilt on demand, dropped when the dictionary is truncated (a rolled
// back update) and when a state is imported. Only streets at most two cards after the start are cached (a flop start
// caches its turns and rivers); other streets are computed per deal.
struct RbKeyMemo {
  std::vector<std::unique_ptr<RbEntry>> table[8][4];
  std::unique_ptr<RbEntry> exact[8];        // exact abstraction: static per seat
  std::vector<std::unique_ptr<RbScores>> scores[8];
  double bytes = 0; double limitBytes = 256.0 * 1048576.0; long long entries = 0, built = 0;
  void clear() { for (auto &s : table) for (auto &t : s) { t.clear(); t.shrink_to_fit(); } for (auto &e : exact) e.reset(); for (auto &s : scores) { s.clear(); s.shrink_to_fit(); } bytes = 0; entries = 0; }
};
// One seat of one deal: its compatible hands as vector positions ordered by showdown score, and per street the row
// (slot) of every position. Built by rbBuildSeat on the thread that traverses the deal.
struct RbSeat {
  int H = 0;
  std::vector<int> hand, score; std::vector<double> cw;
  std::vector<uint16_t> slot[4]; std::vector<uint32_t> slotCode[4]; std::vector<uint16_t> slotHand[4]; int ns[4] = {0, 0, 0, 0};
  // per row (slot) of a street: the conditional weight of its hands, and the row of the previous street they shared
  std::vector<double> mass[4]; std::vector<uint16_t> parent[4];
  bool identity[4] = {false, false, false, false};   // every position has its own row at this street (slot[x] == x)
};
struct RbDeal {
  const RbEntry *entry[8][4] = {};                 // per seat and street index: the keys (cached or owned below)
  const RbScores *scores[8] = {};                  // per seat: cached scores and order of the range on this board (nullptr: computed per deal)
  std::unique_ptr<RbEntry> owned[8][4];            // streets that are not cached
  RbSeat seat[8];
};
