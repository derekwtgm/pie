{"flop3-queens-6max-small", 20000, false, 0.11521988204739353},
{"flop3-queens-6max-small", 20000, true, 0.13869047337398932},
{"icm6-bb-call-small", 20000, false, 0.032742872115903765},
{"icm6-bb-call-small", 20000, true, 0.044925136383287878},
