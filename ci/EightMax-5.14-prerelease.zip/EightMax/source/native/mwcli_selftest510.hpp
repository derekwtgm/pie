// EightMax 5.10: mwcli --selftest510 <studies-dir> <work-dir> [all|estimator|training|checkpoint|limits]
//
// What 5.10 added to the TRAINER, tested by the shipped program itself (nothing but mwcli is needed; "Run 5.10 focused
// validation.bat" runs it and validate_windows510.ps1 imports its report check by check).
//
//   estimator   the experimental estimator "rbes" (Rao-Blackwellised external sampling, es_rbes510.hpp) against the
//               quantity it must estimate, EXACTLY (mw_rbes_check, es_rbes510_check.hpp): on shipped fixtures, for
//               sampled deals and every updating seat, the expectation of what one traversal writes, formed over
//               EVERY outcome of its sampled opponent actions, equals the counterfactual regret and the reach-weighted
//               strategy computed by a brute-force walk of the whole betting tree for every compatible hand of the
//               seat; the production walk and the reference walk write the same increments; the probabilities of the
//               enumerated outcomes sum to 1.
//                 X1..  one check per fixture and estimator variant (exact / sampled terminal children; production /
//                       reference walk); chip EV, ICM, preflop and flop starts, two to six players.
//   training    the trainers as a user runs them (child processes of this program):
//                 D1  the DEFAULT trainer writes the states of 5.9: SHA-256 of the saved state of five shipped
//                     fixtures against the hashes recorded from the unchanged 5.9 program (one deal per update and
//                     frozen batches on three threads);
//                 D2  Detailed hand groups: the 5.10 key cache of the default trainer on and off gives the same state;
//                 R1  rbes: two runs give the same state; a frozen batch gives the same state on 1 and 3 threads, with
//                     the 5.6 batch update, and with the key cache switched off;
//                 R2  rbes: stopped after a third and continued = uninterrupted, byte for byte;
//                 R3  rbes: the saved states of three fixtures have the SHA-256 recorded from the Linux build (the
//                     estimator is deterministic across platforms);
//                 R4  rbes on fixtures small enough for the exact best response: exact NashConv of the trained
//                     strategy after a fixed budget, beside the default trainer's at the same budget and seed
//                     (deterministic numbers; the gate is that both are finite and rbes is not above the default's
//                     on the fixtures recorded as such at release - a regression check, not a convergence claim);
//                 R5  the trained response (5.8/5.9) of a state trained by rbes runs and its statements hold
//                     against the exact values;
//                 R6  a decision study with estimator=rbes completes and records the algorithm.
//   checkpoint  a state continues only under the algorithm that trained it:
//                 C1  a default state is refused by an rbes engine, an rbes state by the default engine, and an
//                     rbes state by the other rbes variant, each with a message that says why, exit 1, and no
//                     output file;
//                 C2  an rbes state carries "estimator" in its header and a study identifier different from the
//                     default's; a default state has neither change (its header is the 5.9 header);
//                 C3  a compressed (EMZ1) rbes state restores and continues to the uninterrupted state.
//   limits      configurations the estimator was not validated for are refused before anything is trained:
//                 L1  rbes with DCFR, regret matching+, own-hand enumeration, river enumeration, the terminal
//                     baseline, Latin deals or a batch schedule; an unknown estimator; estimator options without rbes;
//                 L2  a table budget that the rbes table outgrows: training stops at the limit with a valid state
//                     that holds only committed updates, and continuing it with a larger budget reaches the state
//                     of an uninterrupted run with that budget.
//
// Everything is written inside <work-dir>. Statuses as in --selftest58: passed, failed, untested (never counted as
// passed). The report is <work-dir>/selftest510.json. Exit status: 0 every check passed, 1 a check failed or is
// untested, 2 usage or unreadable fixtures.
#pragma once
namespace st510 {
namespace fs = std::filesystem;
using st58::Report; using st58::fmt; using st58::sci; using st58::get; using st58::num; using st58::str; using st58::Doc; using st58::take; using st58::specOf;
static bool isTrue(const JV *v) { return v && v->type == J_BOOL && v->num != 0; }
// The engine spec of a fixture with trainer options added (text insertion after the opening brace; the options are
// spec keys the fixtures do not carry).
static std::string withOptions(std::string spec, const std::string &options) {
  if (options.empty()) return spec;
  // a scalar option the fixture already carries is replaced, not repeated
  for (const char *k : {"\"weighting\":", "\"regretMatching\":", "\"batchDeals\":", "\"actionStreams\":"}) if (options.find(k) != std::string::npos) {
    const size_t at = spec.find(k); if (at == std::string::npos) continue;
    const size_t end = spec.find_first_of(",}", at); if (end == std::string::npos) continue;
    if (spec[end] == ',') spec.erase(at, end - at + 1); else { size_t from = at; while (from > 0 && spec[from - 1] != ',') from--; spec.erase(from ? from - 1 : at, end - (from ? from - 1 : at)); }
  }
  return "{" + options + "," + spec.substr(1);
}
static bool writeText(const std::string &path, const std::string &text) { FILE *f = std::fopen(path.c_str(), "wb"); if (!f) return false; const bool ok = std::fwrite(text.data(), 1, text.size(), f) == text.size(); std::fclose(f); return ok; }
struct Trained { bool ok = false; int exitCode = -1; std::string err, sha, out; long long deals = 0, rows = 0; bool limit = false; };
// mwcli spec updates threads out [memoryMiB] [in]
static Trained train(const std::string &self, const std::string &work, const std::string &spec, long long updates, int threads, const std::string &out, const std::string &in = "", const std::string &mem = "512",
                     const std::vector<std::pair<std::string, std::string>> &env = {}) {
  Trained t; std::vector<std::string> a = {self, spec, std::to_string(updates), std::to_string(threads), out, mem}; if (!in.empty()) a.push_back(in);
  const ckpt::Run r = ckpt::spawn(a, work, 1800, env); t.exitCode = r.exitCode; t.err = r.err.substr(0, 400); t.out = r.out;
  if (!r.started) { t.err = "the program could not be started: " + r.startError; return t; }
  if (r.exitCode != 0) return t;
  const ckpt::StateInfo s = ckpt::inspect(out); t.sha = s.sha256; Doc d(r.out); t.deals = (long long)num(get(d.v, "trainingDeals"), 0); t.rows = (long long)num(get(d.v, "rows"), 0); t.limit = isTrue(get(d.v, "limitReached"));
  t.ok = s.exists && !t.sha.empty(); return t;
}
static double exactNashConv(const std::string &self, const std::string &work, const std::string &spec, const std::string &state, std::string &why) {
  const std::string q = (fs::path(work) / "gain510.json").string();
  writeText(q, "{\"method\":\"exact\",\"policy\":\"average\",\"device\":\"cpu\",\"threads\":1,\"timeLimitMs\":1800000,\"maxVisits\":2000000000,\"memoryMiB\":512}");
  const ckpt::Run r = ckpt::spawn({self, "--gain", spec, state, q, "512"}, work, 1800); std::error_code ec; fs::remove(q, ec);
  if (!r.started || r.exitCode != 0) { why = "exit " + std::to_string(r.exitCode) + ": " + r.err.substr(0, 200); return NAN; }
  Doc d(r.out); const JV *seats = get(d.v, "seats"); if (!seats || seats->type != J_ARR) { why = "no seats in the exact result"; return NAN; }
  double total = 0; for (int i = 0; i < seats->n; i++) total += num(get(seats->items[i], "bestResponseValue")) - num(get(seats->items[i], "policyValue"));
  return total;
}
// ---- estimator: the exact check inside the engine ----
static void estimatorSection(Report &R, const std::string &studies) {
  const std::string sec = "estimator";
  struct Case { const char *fixture, *options, *label; long long prefix; int deals; };
  // prefix: updates trained with the estimator before the tables are frozen; deals: sampled deals of the check. The
  // number of traversal outcomes grows with the number of sampled opponent decisions, hence one deal for six players.
  const Case cases[] = {
    {"known-akq-river", "\"estimator\":\"rbes\"", "exact terminal children, production walk", 2000, 40},
    {"known-akq-river", "\"estimator\":\"rbes\",\"rbesOpponentTerminals\":\"sampled\"", "sampled terminal children, production walk", 2000, 40},
    {"flop3-kings-small", "\"estimator\":\"rbes\"", "exact terminal children, production walk", 3000, 12},
    {"flop3-kings-small", "\"estimator\":\"rbes\",\"rbesWalk\":\"reference\"", "exact terminal children, reference walk", 3000, 12},
    {"flop3-kings-small", "\"estimator\":\"rbes\",\"rbesOpponentTerminals\":\"sampled\"", "sampled terminal children, production walk", 3000, 6},
    {"icm8-bb-call-small", "\"estimator\":\"rbes\"", "exact terminal children, production walk (ICM, preflop start)", 3000, 12},
    {"btn25-open-small", "\"estimator\":\"rbes\"", "exact terminal children, production walk (preflop start, chip EV)", 3000, 12},
    {"flop6-jack-small", "\"estimator\":\"rbes\"", "exact terminal children, production walk (six players)", 3000, 1},
  };
  int index = 0;
  for (const Case &c : cases) {
    const std::string id = "X" + std::to_string(++index), name = std::string(c.fixture) + ": the exact expectation of the estimator's increments equals the brute-force target (" + c.label + ")";
    std::string why; const std::string spec = specOf((fs::path(studies) / (std::string(c.fixture) + ".emfix.json")).string(), why);
    if (spec.empty()) { R.add(sec, id, name, "untested", why); continue; }
    const std::string text = withOptions(spec, c.options); char err[512] = "";
    MW *m = mw_create(text.c_str(), text.size(), 512, err, sizeof err);
    if (!m) { R.add(sec, id, name, "untested", std::string("the engine was not built: ") + err); continue; }
    if (!mw_train(m, c.prefix, 1, nullptr, nullptr, nullptr, err, sizeof err)) { R.add(sec, id, name, "untested", std::string("training failed: ") + err); mw_free(m); continue; }
    JB before; jb_init(&before); mw_info(m, &before); const std::string infoBefore = take(before);
    const std::string rq = "{\"deals\":" + std::to_string(c.deals) + ",\"seed\":1296}"; JB b; jb_init(&b);
    const int st = mw_rbes_check(m, rq.c_str(), rq.size(), &b, err, sizeof err); const std::string out = take(b);
    JB after; jb_init(&after); mw_info(m, &after); const std::string infoAfter = take(after); mw_free(m);
    if (st != 200) { R.add(sec, id, name, "failed", std::string("status ") + std::to_string(st) + ": " + err); continue; }
    Doc d(out); const double worst = num(get(d.v, "largestDifferenceOverScale")), pair = num(get(d.v, "largestProductionReferenceDifferenceOverScale")), prob = num(get(d.v, "largestOutcomeProbabilityError"));
    const long long entries = (long long)num(get(d.v, "entriesCompared"), 0), outcomes = (long long)num(get(d.v, "traversalOutcomesEnumerated"), 0);
    // the check must leave the engine as it found it (tables, counters, random streams, dictionary)
    Doc ia(infoBefore), ib(infoAfter); const bool untouched = num(get(ia.v, "rng")) == num(get(ib.v, "rng")) && num(get(ia.v, "rows")) == num(get(ib.v, "rows")) && num(get(ia.v, "iterations")) == num(get(ib.v, "iterations")) && num(get(ia.v, "tableMiB")) == num(get(ib.v, "tableMiB"));
    R.check(sec, id, name, isTrue(get(d.v, "passed")) && entries > 0 && outcomes > 0 && worst <= 1e-11 && pair <= 1e-11 && prob <= 1e-9 && untouched,
            std::to_string((long long)num(get(d.v, "deals"), 0)) + " deals, " + std::to_string((int)num(get(d.v, "players"), 0)) + " seats, " + fmt(num(get(d.v, "handsPerSeatDeal"))).substr(0, 5) + " hands carried per seat; " + std::to_string(outcomes) + " traversal outcomes enumerated, " +
            std::to_string(entries) + " table entries compared; largest difference / scale " + sci(worst) + " (tolerance 1e-11); production against reference walk " + sci(pair) + "; outcome probabilities sum to 1 within " + sci(prob) + "; engine unchanged by the check: " + (untouched ? "yes" : "NO"));
  }
}
// SHA-256 of the saved states of the DEFAULT trainer, recorded from the unchanged 5.9 program (build 00600c81455ead44):
// {fixture, updates, one deal per update | 64 deals per update on 3 threads}.
struct Golden { const char *fixture; long long updates; bool batch; const char *sha; };
static const Golden GOLDEN59[] = {
#include "selftest510_golden59.hpp"
};
// SHA-256 of the saved states of the rbes estimator, recorded from the 5.10 Linux build.
static const Golden GOLDEN510[] = {
#include "selftest510_golden510.hpp"
};
// Exact NashConv after a fixed budget, recorded from the 5.10 Linux build: {fixture, updates, default, rbes}.
struct Reference { const char *fixture; long long updates; double nashDefault, nashRbes; };
static const Reference REFERENCE510[] = {
#include "selftest510_reference.hpp"
};
static const char *BATCH = "\"batchDeals\":64,\"actionStreams\":\"deal\"";
static void trainingSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "training"; std::error_code ec;
  auto fixture = [&](const std::string &name, const std::string &options, const std::string &tag, std::string &why) -> std::string {
    const std::string spec = specOf((fs::path(studies) / (name + ".emfix.json")).string(), why); if (spec.empty()) return "";
    const std::string path = (fs::path(work) / (name + "-" + tag + ".spec.json")).string(); if (!writeText(path, withOptions(spec, options))) { why = "cannot write " + path; return ""; } return path;
  };
  auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); };
  const std::vector<std::pair<std::string, std::string>> fixed = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
  { // D1
    int same = 0, total = 0; std::string detail;
    for (const Golden &gld : GOLDEN59) {
      total++; std::string why; const std::string sp = fixture(gld.fixture, gld.batch ? BATCH : "", "d1", why);
      if (sp.empty()) { detail += std::string(detail.empty() ? "" : "; ") + gld.fixture + ": " + why; continue; }
      const Trained t = train(self, work, sp, gld.updates, gld.batch ? 3 : 1, state("d1"), "", "512", fixed);
      if (t.ok && t.sha == gld.sha) same++; else detail += std::string(detail.empty() ? "" : "; ") + gld.fixture + (gld.batch ? " (batch)" : "") + ": " + (t.ok ? "state " + t.sha.substr(0, 16) + " instead of " + std::string(gld.sha).substr(0, 16) : "exit " + std::to_string(t.exitCode) + " " + t.err);
      fs::remove(sp, ec);
    }
    R.check(sec, "D1", "the default trainer writes the states of 5.9 (SHA-256 of the saved state against the hashes recorded from the unchanged 5.9 program; one deal per update and frozen batches on three threads)", same == total && total > 0,
            std::to_string(same) + " of " + std::to_string(total) + " states identical" + (detail.empty() ? "" : "; " + detail));
  }
  { // D2
    std::string why; const std::string sp = fixture("flop3-kings-detailed", "", "d2", why);
    if (sp.empty()) R.add(sec, "D2", "the Detailed key cache of the default trainer", "untested", why);
    else {
      const Trained a = train(self, work, sp, 6000, 1, state("d2a")), b = train(self, work, sp, 6000, 1, state("d2b"), "", "512", {{"EIGHTMAX_KEYCACHE_MIB", "0"}});
      const std::string spb = fixture("flop3-kings-detailed", BATCH, "d2b", why);
      const Trained c = train(self, work, spb, 100, 3, state("d2c"), "", "512", fixed), e = train(self, work, spb, 100, 3, state("d2d"), "", "512", {{"EIGHTMAX_THREAD_CHOICE", "fixed"}, {"EIGHTMAX_KEYCACHE_MIB", "0"}});
      Doc da(a.out); const double hits = num(get(get(get(da.v, "handGroups"), "keyCache"), "hits"), -1);
      R.check(sec, "D2", "Detailed hand groups: the 5.10 key cache of the default trainer on and off gives the same state (one deal per update; frozen batches on three threads)", a.ok && b.ok && c.ok && e.ok && a.sha == b.sha && c.sha == e.sha && hits > 0,
              "one deal per update: " + (a.ok && b.ok ? std::string(a.sha == b.sha ? "identical" : "DIFFERENT") : "run failed: " + a.err + b.err) + "; frozen batches: " + (c.ok && e.ok ? std::string(c.sha == e.sha ? "identical" : "DIFFERENT") : "run failed: " + c.err + e.err) + "; cache hits with the cache on: " + fmt(hits));
      fs::remove(sp, ec); fs::remove(spb, ec);
    }
  }
  const char *RB = "\"estimator\":\"rbes\"";
  { // R1, R2
    struct F { const char *name; long long updates, batchUpdates; };
    const F fx[] = {{"flop3-kings-small", 9000, 150}, {"flop6-jack-small", 6000, 90}, {"icm8-bb-call-small", 9000, 150}, {"flop3-kings", 1500, 30}};
    int ok1 = 0, n1 = 0, ok2 = 0, n2 = 0; std::string d1, d2;
    for (const F &f : fx) {
      std::string why; const std::string sp = fixture(f.name, RB, "r1", why), spb = fixture(f.name, std::string(RB) + "," + BATCH, "r1b", why);
      if (sp.empty() || spb.empty()) { n1++; n2++; d1 += std::string(f.name) + ": " + why + "; "; continue; }
      const Trained a = train(self, work, sp, f.updates, 1, state("r1a")), a2 = train(self, work, sp, f.updates, 1, state("r1b")), noCache = train(self, work, sp, f.updates, 1, state("r1n"), "", "512", {{"EIGHTMAX_RBES_KEYCACHE_MIB", "0"}});
      const Trained b1 = train(self, work, spb, f.batchUpdates, 1, state("r1c"), "", "512", fixed), b3 = train(self, work, spb, f.batchUpdates, 3, state("r1d"), "", "512", fixed),
                    legacy = train(self, work, spb, f.batchUpdates, 3, state("r1e"), "", "512", {{"EIGHTMAX_LEGACY_BATCH", "1"}});
      n1++; const bool same = a.ok && a2.ok && noCache.ok && b1.ok && b3.ok && legacy.ok && a.sha == a2.sha && a.sha == noCache.sha && b1.sha == b3.sha && b1.sha == legacy.sha; ok1 += same;
      if (!same) d1 += std::string(f.name) + ": repeat " + (a.sha == a2.sha ? "same" : "DIFFERENT") + ", cache off " + (a.sha == noCache.sha ? "same" : "DIFFERENT") + ", 3 threads " + (b1.sha == b3.sha ? "same" : "DIFFERENT") + ", 5.6 batch " + (b1.sha == legacy.sha ? "same" : "DIFFERENT") + " " + a.err + b1.err + "; ";
      const long long third = f.updates / 3; const Trained p = train(self, work, sp, third, 1, state("r2p")), c = p.ok ? train(self, work, sp, f.updates - third, 1, state("r2c"), state("r2p")) : Trained{};
      const long long bthird = f.batchUpdates / 3; const Trained bp = train(self, work, spb, bthird, 2, state("r2bp"), "", "512", fixed), bc = bp.ok ? train(self, work, spb, f.batchUpdates - bthird, 3, state("r2bc"), state("r2bp"), "512", fixed) : Trained{};
      n2++; const bool cont = p.ok && c.ok && bp.ok && bc.ok && c.sha == a.sha && bc.sha == b1.sha; ok2 += cont;
      if (!cont) d2 += std::string(f.name) + ": one deal per update " + (c.sha == a.sha ? "same" : "DIFFERENT") + ", frozen batches " + (bc.sha == b1.sha ? "same" : "DIFFERENT") + " " + p.err + c.err + bp.err + bc.err + "; ";
      fs::remove(sp, ec); fs::remove(spb, ec);
    }
    R.check(sec, "R1", "rbes: two runs give the same state; with the key cache switched off the same state; a frozen batch gives the same state on 1 and 3 threads and with the 5.6 batch update", ok1 == n1 && n1 > 0, std::to_string(ok1) + " of " + std::to_string(n1) + " fixtures (exact cards, six players, ICM preflop, Compact hand groups)" + (d1.empty() ? "" : "; " + d1));
    R.check(sec, "R2", "rbes: stopped after a third and continued = uninterrupted, byte for byte (one deal per update; frozen batches stopped on 2 threads and continued on 3)", ok2 == n2 && n2 > 0, std::to_string(ok2) + " of " + std::to_string(n2) + " fixtures" + (d2.empty() ? "" : "; " + d2));
  }
  { // R3
    int same = 0, total = 0; std::string detail;
    for (const Golden &gld : GOLDEN510) {
      total++; std::string why; const std::string sp = fixture(gld.fixture, std::string(RB) + (gld.batch ? std::string(",") + BATCH : ""), "r3", why);
      if (sp.empty()) { detail += std::string(gld.fixture) + ": " + why + "; "; continue; }
      const Trained t = train(self, work, sp, gld.updates, gld.batch ? 3 : 1, state("r3"), "", "512", fixed);
      if (t.ok && t.sha == gld.sha) same++; else detail += std::string(gld.fixture) + (gld.batch ? " (batch)" : "") + ": " + (t.ok ? "state " + t.sha.substr(0, 16) + " instead of " + std::string(gld.sha).substr(0, 16) : "exit " + std::to_string(t.exitCode) + " " + t.err) + "; ";
      fs::remove(sp, ec);
    }
    R.check(sec, "R3", "rbes: the saved states have the SHA-256 recorded from the Linux build of this release (the estimator is deterministic across platforms and compilers of the release)", same == total && total > 0, std::to_string(same) + " of " + std::to_string(total) + " states identical" + (detail.empty() ? "" : "; " + detail));
  }
  { // R4
    int okc = 0, total = 0; std::string detail;
    for (const Reference &ref : REFERENCE510) {
      total++; std::string why; const std::string sd = fixture(ref.fixture, "", "r4d", why), sr = fixture(ref.fixture, RB, "r4r", why);
      if (sd.empty() || sr.empty()) { detail += std::string(ref.fixture) + ": " + why + "; "; continue; }
      const Trained a = train(self, work, sd, ref.updates, 1, state("r4d")), b = train(self, work, sr, ref.updates, 1, state("r4r"));
      double nd = NAN, nr = NAN; if (a.ok) nd = exactNashConv(self, work, sd, state("r4d"), why); if (b.ok) nr = exactNashConv(self, work, sr, state("r4r"), why);
      auto close = [](double x, double y) { return std::isfinite(x) && std::isfinite(y) && std::fabs(x - y) <= 1e-9 * std::max({1.0, std::fabs(x), std::fabs(y)}); };
      const bool good = close(nd, ref.nashDefault) && close(nr, ref.nashRbes); okc += good;
      detail += std::string(ref.fixture) + " after " + std::to_string(ref.updates) + " deals: exact NashConv default " + sci(nd) + ", rbes " + sci(nr) + (good ? "" : " (recorded " + sci(ref.nashDefault) + ", " + sci(ref.nashRbes) + ") " + why) + "; ";
      fs::remove(sd, ec); fs::remove(sr, ec);
    }
    R.check(sec, "R4", "reference fixtures: the exact NashConv of the strategy trained by the default trainer and by rbes after a fixed budget equals the value recorded at release (a regression check of both trainers; the numbers are one seed each and no convergence claim)", okc == total && total > 0,
            std::to_string(okc) + " of " + std::to_string(total) + " fixtures reproduce both recorded values; " + detail);
  }
  { // R5: trained response of an rbes state
    std::string why; const std::string sp = fixture("flop3-kings-small", RB, "r5", why);
    if (sp.empty()) R.add(sec, "R5", "the trained response of a state trained by rbes", "untested", why);
    else {
      const Trained a = train(self, work, sp, 20000, 1, state("r5")); const std::string q = (fs::path(work) / "r5-request.json").string();
      writeText(q, "{\"responseDeals\":20000,\"samples\":102400,\"seed\":510,\"exact\":true}");
      const ckpt::Run r = a.ok ? ckpt::spawn({self, "--response", sp, state("r5"), q, "512"}, work, 1800) : ckpt::Run{};
      Doc d(r.out); const JV *S = get(d.v, "summary"), *ag = get(S, "againstExact"), *seats = get(d.v, "seats");
      const bool holds = isTrue(get(ag, "simultaneousHolds")) && isTrue(get(ag, "simultaneousNashConvBoundHolds")) && isTrue(get(ag, "pooledAllSeatsHolds")) && isTrue(get(ag, "pooledBestSubsetHolds"));
      R.check(sec, "R5", "the trained response (5.8/5.9) of a state trained by rbes runs, and every confidence statement holds against the exact values of the same responses", a.ok && r.exitCode == 0 && seats && seats->type == J_ARR && seats->n == 3 && holds,
              a.ok ? "exit " + std::to_string(r.exitCode) + "; exact NashConv " + sci(num(get(S, "exactNashConv"))) + "; simultaneous bound " + sci(num(get(get(S, "simultaneous"), "nashConvLowerBound"))) + "; statements hold: " + (holds ? "yes" : "NO") + " " + r.err.substr(0, 200) : "training failed: " + a.err);
      fs::remove(sp, ec); fs::remove(q, ec);
    }
  }
  { // R6: a study with the estimator
    const std::string fxp = (fs::path(studies) / "known-akq-river.emfix.json").string(), out = (fs::path(work) / "r6-study.json").string();
    const ckpt::Run r = ckpt::spawn({self, "--study", fxp, out, "seeds=2", "budgets=4000,20000", "estimator=rbes", "checkpoint=off", "quiet=1"}, work, 1800);
    const std::vector<unsigned char> b = slurp(out.c_str()); Doc d(std::string(b.begin(), b.end()));
    const std::string text(b.begin(), b.end()); const bool named = text.find("rbes-5.10-v1") != std::string::npos, complete = isTrue(get(get(d.v, "run"), "complete")) || text.find("\"complete\":true") != std::string::npos;
    R.check(sec, "R6", "a decision study with estimator=rbes completes and its result names the algorithm", r.exitCode == 0 && named && complete, "exit " + std::to_string(r.exitCode) + "; algorithm named in the result: " + (named ? "yes" : "NO") + "; complete: " + (complete ? "yes" : "NO") + " " + r.err.substr(0, 200));
    fs::remove(out, ec);
  }
  for (const char *t : {"d1", "d2a", "d2b", "d2c", "d2d", "r1a", "r1b", "r1n", "r1c", "r1d", "r1e", "r2p", "r2c", "r2bp", "r2bc", "r3", "r4d", "r4r", "r5"}) fs::remove(state(t), ec);
}
static void checkpointSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "checkpoint"; std::error_code ec; std::string why;
  const std::string base = specOf((fs::path(studies) / "flop3-kings-small.emfix.json").string(), why);
  if (base.empty()) { for (const char *id : {"C1", "C2", "C3"}) R.add(sec, id, "checkpoint rules of the estimator", "untested", why); return; }
  auto p = [&](const char *n) { return (fs::path(work) / n).string(); };
  const std::string sd = p("c-default.spec.json"), sr = p("c-rbes.spec.json"), ss = p("c-sampled.spec.json");
  writeText(sd, base); writeText(sr, withOptions(base, "\"estimator\":\"rbes\"")); writeText(ss, withOptions(base, "\"estimator\":\"rbes\",\"rbesOpponentTerminals\":\"sampled\""));
  const Trained d = train(self, work, sd, 3000, 1, p("c-default.state")), r = train(self, work, sr, 3000, 1, p("c-rbes.state")), s = train(self, work, ss, 3000, 1, p("c-sampled.state"));
  if (!d.ok || !r.ok || !s.ok) { for (const char *id : {"C1", "C2", "C3"}) R.add(sec, id, "checkpoint rules of the estimator", "untested", "training failed: " + d.err + r.err + s.err); return; }
  { // C1
    struct X { const char *what; std::string spec, in; const char *expect; };
    const X xs[] = {{"a default state under rbes", sr, p("c-default.state"), "default trainer"}, {"an rbes state under the default trainer", sd, p("c-rbes.state"), "experimental"},
                    {"an rbes state (exact terminal children) under the sampled variant", ss, p("c-rbes.state"), ""}, {"an rbes state (sampled) under the exact variant", sr, p("c-sampled.state"), ""}};
    int refused = 0; std::string detail;
    for (const X &x : xs) {
      const std::string out = p("c-refused.state"); fs::remove(out, ec);
      const Trained t = train(self, work, x.spec, 100, 1, out, x.in); const bool noFile = !fs::exists(out, ec);
      const bool good = !t.ok && t.exitCode == 1 && noFile && t.err.find("refused") != std::string::npos && (!*x.expect || t.err.find(x.expect) != std::string::npos || t.err.find("different") != std::string::npos);
      refused += good; detail += std::string(x.what) + ": exit " + std::to_string(t.exitCode) + (noFile ? ", nothing written" : ", A FILE WAS WRITTEN") + (good ? "" : " [" + t.err.substr(0, 160) + "]") + "; ";
    }
    R.check(sec, "C1", "a state continues only under the algorithm that trained it: every cross-algorithm continuation is refused with a reason, exit 1, and writes nothing", refused == 4, std::to_string(refused) + " of 4 refused; " + detail);
  }
  { // C2
    const ckpt::StateInfo a = ckpt::inspect(p("c-default.state")), b = ckpt::inspect(p("c-rbes.state")), c = ckpt::inspect(p("c-sampled.state"));
    const bool headers = a.validHeader && b.validHeader && c.validHeader && a.field("estimator").empty() && b.field("estimator") == "\"rbes-5.10-v1\"" && c.field("estimator") == "\"rbes-5.10-v1-sampled-terminals\"" &&
                         a.field("studyId") != b.field("studyId") && b.field("studyId") != c.field("studyId") && a.field("studyId") != c.field("studyId") && !a.field("studyId").empty();
    R.check(sec, "C2", "an rbes state names its algorithm in the header and carries its own study identifier (an earlier program version refuses it too); a default state has the 5.9 header", headers,
            "default: estimator field " + (a.field("estimator").empty() ? std::string("absent") : a.field("estimator")) + ", study " + a.field("studyId") + "; rbes: " + b.field("estimator") + ", study " + b.field("studyId") + "; sampled variant: " + c.field("estimator") + ", study " + c.field("studyId"));
  }
  { // C3
    const ckpt::Run z = ckpt::spawn({self, "--compress", p("c-rbes.state"), p("c-rbes.emz")}, work, 600);
    const Trained cont = z.exitCode == 0 ? train(self, work, sr, 3000, 1, p("c-cont.state"), p("c-rbes.emz")) : Trained{}, whole = train(self, work, sr, 6000, 1, p("c-whole.state"));
    R.check(sec, "C3", "a compressed (EMZ1) rbes state restores and continues to the state of the uninterrupted run", z.exitCode == 0 && cont.ok && whole.ok && cont.sha == whole.sha,
            "compress exit " + std::to_string(z.exitCode) + "; continued from the compressed state: " + (cont.ok && whole.ok ? std::string(cont.sha == whole.sha ? "identical to the uninterrupted run" : "DIFFERENT") : "run failed: " + cont.err + whole.err));
  }
  for (const char *n : {"c-default.spec.json", "c-rbes.spec.json", "c-sampled.spec.json", "c-default.state", "c-rbes.state", "c-sampled.state", "c-refused.state", "c-rbes.emz", "c-cont.state", "c-whole.state"}) fs::remove(p(n), ec);
}
static void limitsSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "limits"; std::error_code ec; std::string why;
  const std::string base = specOf((fs::path(studies) / "flop3-kings-small.emfix.json").string(), why), grouped = specOf((fs::path(studies) / "flop3-kings.emfix.json").string(), why);
  if (base.empty() || grouped.empty()) { for (const char *id : {"L1", "L2"}) R.add(sec, id, "limits of the estimator", "untested", why); return; }
  auto p = [&](const char *n) { return (fs::path(work) / n).string(); };
  { // L1
    const char *bad[] = {"\"estimator\":\"rbes\",\"weighting\":\"dcfr\"", "\"estimator\":\"rbes\",\"regretMatching\":\"plus\"", "\"estimator\":\"rbes\",\"ownHandEnumeration\":true", "\"estimator\":\"rbes\",\"opponentEnumeration\":\"river\"",
                         "\"estimator\":\"rbes\",\"terminalBaseline\":true", "\"estimator\":\"rbes\",\"chanceSampling\":\"latin\"", "\"estimator\":\"rbes\",\"opponentExploration\":0", "\"estimator\":\"rbes\",\"actionStreams\":\"deal\",\"batchDeals\":8,\"batchSchedule\":{\"start\":1,\"doubleEvery\":100}",
                         "\"estimator\":\"fast\"", "\"estimator\":7", "\"rbesOpponentTerminals\":\"sampled\"", "\"rbesWalk\":\"reference\"", "\"estimator\":\"rbes\",\"rbesOpponentTerminals\":\"some\""};
    int refused = 0, total = 0; std::string notRefused;
    for (const char *o : bad) {
      total++; const std::string sp = p("l1.spec.json"), out = p("l1.state"); fs::remove(out, ec);
      writeText(sp, withOptions(base, o));
      const Trained t = train(self, work, sp, 100, 1, out); const bool good = !t.ok && t.exitCode == 1 && !fs::exists(out, ec) && !t.err.empty();
      refused += good; if (!good) notRefused += std::string(notRefused.empty() ? "" : "; ") + o + " -> exit " + std::to_string(t.exitCode);
      fs::remove(sp, ec);
    }
    R.check(sec, "L1", "configurations the estimator was not validated for (DCFR, regret matching+, own-hand and river enumeration, terminal baseline, Latin deals, no opponent exploration, a batch schedule), an unknown estimator, and estimator options without the estimator are refused before anything is trained",
            refused == total, std::to_string(refused) + " of " + std::to_string(total) + " refused with exit 1 and no output" + (notRefused.empty() ? "" : "; NOT refused: " + notRefused));
  }
  { // L2: the three-player flop fixture with Compact groups outgrows a 6 MiB table within a few thousand deals
    const std::string sp = p("l2.spec.json"); writeText(sp, withOptions(grouped, "\"estimator\":\"rbes\""));
    const long long want = 6000;
    const Trained small = train(self, work, sp, want, 1, p("l2-small.state"), "", "6");
    const Trained rest = small.ok && small.limit && small.deals < want ? train(self, work, sp, want - small.deals, 1, p("l2-cont.state"), p("l2-small.state"), "512") : Trained{};
    const Trained whole = train(self, work, sp, want, 1, p("l2-whole.state"), "", "512");
    const bool good = small.ok && small.limit && small.deals > 0 && small.deals < want && rest.ok && whole.ok && !whole.limit && rest.sha == whole.sha;
    R.check(sec, "L2", "a table budget the rbes table outgrows: training stops at the limit with a valid state of committed updates only, and continuing it with a larger budget reaches the state of the uninterrupted run", good,
            small.ok ? "6 MiB: stopped after " + std::to_string(small.deals) + " of " + std::to_string(want) + " deals (" + std::to_string(small.rows) + " rows), limit reported: " + (small.limit ? "yes" : "NO") + "; continued with 512 MiB: " + (rest.ok && whole.ok ? std::string(rest.sha == whole.sha ? "identical to the uninterrupted run" : "DIFFERENT") : "run failed: " + rest.err + whole.err)
                     : "the run with the small budget failed: exit " + std::to_string(small.exitCode) + " " + small.err);
    for (const char *n : {"l2.spec.json", "l2-small.state", "l2-cont.state", "l2-whole.state"}) fs::remove(p(n), ec);
  }
}
static int run(int argc, char **argv) {
  if (argc < 4 || argc > 5) { std::fprintf(stderr, "usage: mwcli --selftest510 studies-dir work-dir [all|estimator|training|checkpoint|limits]\n"); return 2; }
  const std::string studies = argv[2], work = argv[3], section = argc > 4 ? argv[4] : "all";
  if (section != "all" && section != "estimator" && section != "training" && section != "checkpoint" && section != "limits") { std::fprintf(stderr, "error: the section must be all, estimator, training, checkpoint or limits\n"); return 2; }
  std::error_code ec; fs::create_directories(work, ec);
  if (!fs::is_directory(studies, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: studies-dir and work-dir must be directories\n"); return 2; }
  mw_study_identity(EM_VERSION, EM_BUILD_ID);
  Report R; const auto t0 = std::chrono::steady_clock::now(); const std::string S = fs::absolute(studies, ec).string(), W = fs::absolute(work, ec).string(), self = ckpt::selfPath(argv[0]);
  if (section == "all" || section == "estimator") estimatorSection(R, S);
  if (section == "all" || section == "training") trainingSection(R, S, W, self);
  if (section == "all" || section == "checkpoint") checkpointSection(R, S, W, self);
  if (section == "all" || section == "limits") limitsSection(R, S, W, self);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest510\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"" + section + "\",\"passed\":" + std::to_string(R.passed) + ",\"failed\":" + std::to_string(R.failed) +
                  ",\"untested\":" + std::to_string(R.untested) + ",\"seconds\":" + fmt(secs) + ",\"checks\":[";
  for (size_t i = 0; i < R.checks.size(); i++) { const st58::Check &c = R.checks[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}";
  const std::string report = (fs::path(work) / "selftest510.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest510\",\"build\":\"%s\",\"section\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"report\":%s}\n", EM_BUILD_ID, section.c_str(), R.passed, R.failed, R.untested, mwa::jsonEsc(report).c_str());
  return R.failed || R.untested ? 1 : 0;
}
}
