// EightMax 5.12 (Phase 2, 6-max tournaments): mwcli --selftest512 <studies-dir> <work-dir> [all|fixtures|training|study]
//
// 5.12 changes no training code, no stream and no checkpoint format: --selftest57 ... --selftest511 pass with their
// recorded tables untouched, and that is the evidence that the trainers write the states of 5.11. This self-test
// covers what 5.12 ADDED that the native programs execute: the six six-handed study fixtures.
//
//   fixtures    F1  the six 6-max fixtures are present and describe a six-handed table (6 players dealt in, 0.1 BB
//                   ante each, 2.1 BB before voluntary action); every variant's native specification is accepted by
//                   the engine; three seats play and the antes of the other three are in the pot;
//               F2  the engine reaches the advertised decision of every variant: following the fixture's action
//                   path, the hero seat is to act, the pot is the advertised pot and the legal actions are the
//                   advertised ones (names and amounts);
//               F3  the ten fixtures of 5.11 are present beside them and still describe an eight-handed table
//                   (their training is the subject of --selftest510 and --selftest511).
//   training    T1  the state trained from each 6-max fixture's baseline specification has the SHA-256 recorded
//                   from the Linux build of this release: 5.10 streams and philox64, one deal per update and frozen
//                   batches of 64 on three threads (deterministic across platforms and compilers of the release);
//               T2  frozen batches: 1 thread = 3 threads; stopped after a third and continued = uninterrupted
//                   (philox64 and the 5.10 streams, the three small companions);
//               T3  exact NashConv of the two companions small enough for exact evaluation after a fixed budget
//                   equals the value recorded at release (a regression check: one seed, no convergence claim).
//   study       S1  a decision study of each small companion completes; the result names the fixture, the hero
//                   decision with the advertised legal actions, and the training streams;
//               S2  the same study twice gives the same measurements (action frequencies and EVs, bit for bit).
//
// Everything is written inside <work-dir>. Statuses as in --selftest58: passed, failed, untested (never counted as
// passed). The report is <work-dir>/selftest512.json. Exit status: 0 every check passed, 1 a check failed or is
// untested, 2 usage or unreadable fixtures.
//   mwcli --selftest512 studies work record     writes selftest512_golden.hpp and selftest512_reference.hpp into the
//                                               work directory from THIS build (used once, on Linux, at release).
#pragma once
namespace st512 {
namespace fs = std::filesystem;
using st58::Report; using st58::fmt; using st58::sci; using st58::get; using st58::num; using st58::str; using st58::Doc; using st58::take; using st58::specOf;
using st510::isTrue; using st510::withOptions; using st510::writeText; using st510::Trained; using st510::train; using st510::exactNashConv; using st510::BATCH;
static const char *WIDE = "\"trainingStreams\":\"philox64\"";
static const char *const SIX[] = {"btn25-open-6max", "btn25-open-6max-small", "flop3-queens-6max", "flop3-queens-6max-small", "icm6-bb-call", "icm6-bb-call-small"};
static const char *const EIGHT[] = {"btn25-open", "btn25-open-small", "flop3-kings", "flop3-kings-detailed", "flop3-kings-small", "flop6-jack", "flop6-jack-small", "icm8-bb-call", "icm8-bb-call-small", "known-akq-river"};
// {fixture, updates, frozen batch on 3 threads, philox64, sha}: recorded from the 5.12 Linux build.
struct Golden512 { const char *fixture; long long updates; bool batch, wide; const char *sha; };
static const Golden512 GOLDEN512[] = {
#include "selftest512_golden.hpp"
};
// {fixture, updates, philox64, exact NashConv}: recorded from the 5.12 Linux build.
struct Reference512 { const char *fixture; long long updates; bool wide; double nash; };
static const Reference512 REFERENCE512[] = {
#include "selftest512_reference.hpp"
};
static std::string readText(const std::string &path) { const std::vector<unsigned char> b = slurp(path.c_str()); const size_t skip = b.size() >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF ? 3 : 0; return std::string(b.begin() + skip, b.end()); }
static std::string join(const std::string &a, const std::string &b) { return a.empty() ? b : b.empty() ? a : a + "," + b; }
static std::string optionsOf(bool wide, bool batch) { return join(wide ? WIDE : "", batch ? BATCH : ""); }

static void fixturesSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "fixtures"; std::error_code ec;
  int ok1 = 0, n1 = 0, ok2 = 0, n2 = 0, variantsAll = 0; std::string d1, d2;
  for (const char *id : SIX) {
    n1++; const std::string text = readText((fs::path(studies) / (std::string(id) + ".emfix.json")).string()); Doc fx(text);
    const JV *table = get(fx.v, "table"), *vs = get(fx.v, "variants");
    if (!fx.v || !vs || vs->type != J_ARR || vs->n == 0) { d1 += std::string(id) + ": missing or unreadable; "; n2++; continue; }
    bool good = str(get(fx.v, "id")) == id && num(get(table, "players")) == 6 && num(get(table, "antePerPlayer")) == 0.1 && num(get(table, "startingPotBeforeVoluntaryAction")) == 2.1 && num(get(table, "smallBlind")) == 0.5 && num(get(table, "bigBlind")) == 1;
    std::string bad;
    for (int v = 0; v < vs->n; v++) {
      variantsAll++; const JV *sp = get(vs->items[v], "nativeSpec"), *game = get(vs->items[v], "game"); const std::string name = str(get(vs->items[v], "name"));
      const std::string spec = sp ? jvText(sp) : ""; char err[512] = "";
      MW *m = spec.empty() ? nullptr : mw_create(spec.c_str(), spec.size(), 512, err, sizeof err);
      // six 0.1 BB antes: three belong to the playing seats (rules.ownAnte); a preflop study starts with all six in the pot
      // (rules.pot0 = 0.6), a flop study carries them as chips nobody can win back (rules.common = 0.6)
      const JV *rules = get(sp, "rules"), *own = get(rules, "ownAnte"); double antes = 0; if (own && own->type == J_ARR) for (int i = 0; i < own->n; i++) antes += num(own->items[i], 0);
      const bool preflop = get(game, "preflop") != nullptr; const double all = num(get(rules, preflop ? "pot0" : "common"));
      const bool six = num(get(game, "dealt")) == 6 && num(get(sp, "n")) == 3 && own && own->type == J_ARR && own->n == 3 && std::fabs(antes - 0.3) < 1e-9 && std::fabs(all - 0.6) < 1e-9;
      if (!m || !six) { good = false; bad += name + (m ? ": not a six-handed three-seat specification" : std::string(": refused by the engine: ") + err) + ", "; }
      if (m) mw_free(m);
      // F2: the decision
      n2++; const JV *dec = get(vs->items[v], "decision"), *path = get(dec, "path"), *acts = get(dec, "actions");
      const std::string sf = (fs::path(work) / "f2.spec.json").string(), stf = (fs::path(work) / "f2.state").string(), qf = (fs::path(work) / "f2.request.json").string();
      if (spec.empty() || !path || path->type != J_ARR || !acts || acts->type != J_ARR || !writeText(sf, spec)) { d2 += std::string(id) + "/" + name + ": no decision in the fixture; "; continue; }
      const Trained t = train(self, work, sf, 1, 1, stf, "", "1024");
      writeText(qf, "{\"path\":" + jvText(path) + ",\"board\":[],\"limit\":1326}");
      const ckpt::Run r = t.ok ? ckpt::spawn({self, "--node", sf, stf, qf, "1024"}, work, 600) : ckpt::Run{}; Doc d(r.out);
      const JV *node = get(d.v, "node"), *got = get(d.v, "actions");
      bool same = t.ok && r.exitCode == 0 && str(get(node, "kind")) == "decision" && num(get(node, "actor"), -1) == num(get(dec, "seat"), -2) && std::fabs(num(get(node, "pot")) - num(get(dec, "potBB"))) < 1e-9 && got && got->type == J_ARR && got->n == acts->n;
      for (int a = 0; same && a < acts->n; a++) same = str(get(got->items[a], "name")) == str(get(acts->items[a], "name")) && num(get(got->items[a], "slot"), -1) == num(get(acts->items[a], "slot"), -2) && std::fabs(num(get(got->items[a], "to"), 0) - num(get(acts->items[a], "to"), 0)) < 1e-9;
      ok2 += same; if (!same) d2 += std::string(id) + "/" + name + ": " + (t.ok ? (r.exitCode ? "exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 160) : "the engine's node differs from the fixture's decision") : "one update could not be trained: " + t.err) + "; ";
      fs::remove(sf, ec); fs::remove(stf, ec); fs::remove(qf, ec);
    }
    ok1 += good; if (!good) d1 += std::string(id) + ": " + (bad.empty() ? "the table is not six-handed as specified" : bad) + "; ";
  }
  R.check(sec, "F1", "the six 6-max fixtures describe a six-handed table (6 players dealt in, 0.1 BB ante each, 2.1 BB before voluntary action) and every variant's native specification is accepted by the engine: three seats play, three antes are theirs and three are in the pot", ok1 == n1 && n1 == 6,
          std::to_string(ok1) + " of " + std::to_string(n1) + " fixtures, " + std::to_string(variantsAll) + " variants" + (d1.empty() ? "" : "; " + d1));
  R.check(sec, "F2", "the engine reaches the advertised decision of every variant: on the fixture's action path the hero seat is to act, the pot is the advertised pot, and the legal actions are the advertised ones (names, slots, amounts)", ok2 == n2 && n2 > 0,
          std::to_string(ok2) + " of " + std::to_string(n2) + " variants" + (d2.empty() ? "" : "; " + d2));
  { int ok3 = 0; std::string d3;
    for (const char *id : EIGHT) { const std::string text = readText((fs::path(studies) / (std::string(id) + ".emfix.json")).string()); Doc fx(text); std::string why;
      const bool good = fx.v && str(get(fx.v, "id")) == id && num(get(get(fx.v, "table"), "players")) == 8 && num(get(get(fx.v, "table"), "startingPotBeforeVoluntaryAction")) == 2.3 && !specOf((fs::path(studies) / (std::string(id) + ".emfix.json")).string(), why).empty();
      ok3 += good; if (!good) d3 += std::string(id) + " "; }
    R.check(sec, "F3", "the ten fixtures of 5.11 are present beside them and describe an eight-handed table (2.3 BB before voluntary action)", ok3 == 10, std::to_string(ok3) + " of 10" + (d3.empty() ? "" : "; not as expected: " + d3)); }
}
static void trainingSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "training"; std::error_code ec;
  auto fixture = [&](const std::string &name, const std::string &options, const std::string &tag, std::string &why) -> std::string {
    const std::string spec = specOf((fs::path(studies) / (name + ".emfix.json")).string(), why); if (spec.empty()) return "";
    const std::string path = (fs::path(work) / (name + "-" + tag + ".spec.json")).string(); if (!writeText(path, withOptions(spec, options))) { why = "cannot write " + path; return ""; } return path;
  };
  auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); };
  const std::vector<std::pair<std::string, std::string>> fixed = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
  { // T1
    int same = 0, total = 0; std::string detail;
    for (const Golden512 &g : GOLDEN512) {
      total++; std::string why; const std::string sp = fixture(g.fixture, optionsOf(g.wide, g.batch), "t1", why);
      if (sp.empty()) { detail += std::string(g.fixture) + ": " + why + "; "; continue; }
      const Trained t = train(self, work, sp, g.updates, g.batch ? 3 : 1, state("t1"), "", "512", fixed);
      if (t.ok && t.sha == g.sha) same++; else detail += std::string(g.fixture) + (g.wide ? " philox64" : " 5.10 streams") + (g.batch ? " (batch)" : "") + ": " + (t.ok ? "state " + t.sha.substr(0, 16) + " instead of " + std::string(g.sha).substr(0, 16) : "exit " + std::to_string(t.exitCode) + " " + t.err) + "; ";
      fs::remove(sp, ec);
    }
    R.check(sec, "T1", "6-max fixtures: the saved states have the SHA-256 recorded from the Linux build of this release (5.10 streams and philox64; one deal per update and frozen batches of 64 on three threads)", same == total && total > 0, std::to_string(same) + " of " + std::to_string(total) + " states identical" + (detail.empty() ? "" : "; " + detail));
  }
  { // T2
    struct F { const char *name; long long updates, batchUpdates; };
    const F fx[] = {{"btn25-open-6max-small", 6000, 90}, {"flop3-queens-6max-small", 9000, 150}, {"icm6-bb-call-small", 9000, 150}};
    int good = 0, n = 0; std::string detail;
    for (const F &f : fx) for (const bool wide : {false, true}) {
      n++; std::string why; const std::string sp = fixture(f.name, optionsOf(wide, false), "t2", why), spb = fixture(f.name, optionsOf(wide, true), "t2b", why);
      if (sp.empty() || spb.empty()) { detail += std::string(f.name) + ": " + why + "; "; continue; }
      const Trained a = train(self, work, sp, f.updates, 1, state("t2a")); const long long third = f.updates / 3;
      const Trained p = train(self, work, sp, third, 1, state("t2p")), c = p.ok ? train(self, work, sp, f.updates - third, 1, state("t2c"), state("t2p")) : Trained{};
      const Trained b1 = train(self, work, spb, f.batchUpdates, 1, state("t2d"), "", "512", fixed), b3 = train(self, work, spb, f.batchUpdates, 3, state("t2e"), "", "512", fixed); const long long bthird = f.batchUpdates / 3;
      const Trained bp = train(self, work, spb, bthird, 2, state("t2f"), "", "512", fixed), bc = bp.ok ? train(self, work, spb, f.batchUpdates - bthird, 3, state("t2g"), state("t2f"), "512", fixed) : Trained{};
      const bool ok = a.ok && c.ok && b1.ok && b3.ok && bc.ok && c.sha == a.sha && b1.sha == b3.sha && bc.sha == b1.sha; good += ok;
      if (!ok) detail += std::string(f.name) + (wide ? " philox64" : " 5.10 streams") + ": continued " + (c.sha == a.sha ? "same" : "DIFFERENT") + ", 3 threads " + (b1.sha == b3.sha ? "same" : "DIFFERENT") + ", batch continued " + (bc.sha == b1.sha ? "same" : "DIFFERENT") + " " + a.err + p.err + c.err + b1.err + b3.err + bp.err + bc.err + "; ";
      fs::remove(sp, ec); fs::remove(spb, ec);
    }
    R.check(sec, "T2", "6-max companions: a frozen batch gives the same state on 1 and 3 threads; stopped after a third and continued = uninterrupted, byte for byte (one deal per update; frozen batches stopped on 2 threads and continued on 3); 5.10 streams and philox64", good == n && n > 0, std::to_string(good) + " of " + std::to_string(n) + " configurations" + (detail.empty() ? "" : "; " + detail));
  }
  { // T3
    int okc = 0, total = 0; std::string detail;
    for (const Reference512 &ref : REFERENCE512) {
      total++; std::string why; const std::string sp = fixture(ref.fixture, optionsOf(ref.wide, false), "t3", why);
      if (sp.empty()) { detail += std::string(ref.fixture) + ": " + why + "; "; continue; }
      const Trained a = train(self, work, sp, ref.updates, 1, state("t3")); double nc = NAN; if (a.ok) nc = exactNashConv(self, work, sp, state("t3"), why);
      const bool good = std::isfinite(nc) && std::fabs(nc - ref.nash) <= 1e-9 * std::max({1.0, std::fabs(nc), std::fabs(ref.nash)}); okc += good;
      detail += std::string(ref.fixture) + (ref.wide ? " philox64" : " 5.10 streams") + " after " + std::to_string(ref.updates) + " deals: exact NashConv " + sci(nc) + (good ? "" : " (recorded " + sci(ref.nash) + ") " + why + a.err) + "; ";
      fs::remove(sp, ec);
    }
    R.check(sec, "T3", "6-max companions: the exact NashConv of the trained strategy after a fixed budget equals the value recorded at release (a regression check; the numbers are one seed each and no convergence claim; the ICM game is in percent of the prize pool, the flop game in BB)", okc == total && total > 0, std::to_string(okc) + " of " + std::to_string(total) + " reproduce the recorded value; " + detail);
  }
  for (const char *t : {"t1", "t2a", "t2p", "t2c", "t2d", "t2e", "t2f", "t2g", "t3"}) fs::remove(state(t), ec);
}
// The measurements of a study that must not depend on the run: per variant and budget, every action's mean frequency and mean EV.
static std::string measurements(const JV *doc) {
  std::string o; const JV *vs = get(doc, "variants"); if (!vs || vs->type != J_ARR) return "";
  for (int v = 0; v < vs->n; v++) { const JV *bs = get(vs->items[v], "budgets"); if (!bs || bs->type != J_ARR) return "";
    for (int b = 0; b < bs->n; b++) { const JV *as = get(bs->items[b], "actions"); if (!as || as->type != J_ARR) return "";
      for (int a = 0; a < as->n; a++) { const double f = num(get(get(as->items[a], "frequency"), "mean")), e = num(get(get(as->items[a], "ev"), "mean")); char h[48]; unsigned long long x, y; std::memcpy(&x, &f, 8); std::memcpy(&y, &e, 8); std::snprintf(h, sizeof h, "%016llx%016llx;", x, y); o += h; } } }
  return o;
}
static void studySection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "study"; std::error_code ec; int good = 0, same = 0, n = 0; std::string d1, d2;
  for (const char *id : {"btn25-open-6max-small", "flop3-queens-6max-small", "icm6-bb-call-small"}) {
    n++; const std::string fxp = (fs::path(studies) / (std::string(id) + ".emfix.json")).string(); Doc fx(readText(fxp));
    const JV *vs0 = get(fx.v, "variants"); const JV *want = vs0 && vs0->type == J_ARR && vs0->n ? get(get(vs0->items[0], "decision"), "actions") : nullptr;
    std::string first;
    for (int run = 0; run < 2; run++) {
      const std::string out = (fs::path(work) / "s1-study.json").string(); fs::remove(out, ec);
      const ckpt::Run r = ckpt::spawn({self, "--study", fxp, out, "variants=baseline", "seeds=2", "budgets=2000,8000", "checkpoint=off", "quiet=1", "threads=1"}, work, 1800);
      const std::string text = readText(out); Doc d(text); const JV *vs = get(d.v, "variants"); const JV *v0 = vs && vs->type == J_ARR && vs->n ? vs->items[0] : nullptr;
      const JV *acts = get(get(v0, "decision"), "actions"); const std::string streams = str(get(get(get(d.v, "run"), "trainingStreams"), "streams")), m = measurements(d.v);
      if (run == 0) {
        bool ok = r.exitCode == 0 && str(get(get(d.v, "fixture"), "id")) == id && text.find("\"complete\":true") != std::string::npos && acts && want && acts->type == J_ARR && want->type == J_ARR && acts->n == want->n && !streams.empty() && !m.empty();
        for (int a = 0; ok && a < acts->n; a++) ok = str(get(acts->items[a], "label")) == str(get(want->items[a], "label"));
        good += ok; first = m;
        d1 += std::string(id) + ": " + (ok ? std::to_string(acts->n) + " legal actions, streams " + streams : "exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 200)) + "; ";
      } else { const bool eq = r.exitCode == 0 && !m.empty() && m == first; same += eq; if (!eq) d2 += std::string(id) + ": the second run differs; "; }
      fs::remove(out, ec);
    }
  }
  R.check(sec, "S1", "a decision study of each small 6-max companion completes (baseline, two seeds, budgets 2,000 and 8,000 deals); the result names the fixture, the hero decision with the advertised legal actions, and the training streams", good == n, std::to_string(good) + " of " + std::to_string(n) + " studies; " + d1);
  R.check(sec, "S2", "the same study run twice gives the same measurements: every action's mean frequency and mean EV at every budget, bit for bit", same == n, std::to_string(same) + " of " + std::to_string(n) + " studies" + (d2.empty() ? "" : "; " + d2));
}
static int record(const std::string &studies, const std::string &work, const std::string &self) {
  std::error_code ec; std::string golden, reference, why; int bad = 0, count = 0;
  auto p = [&](const char *n) { return (fs::path(work) / n).string(); };
  const std::vector<std::pair<std::string, std::string>> fixed = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
  struct G { const char *fixture; long long updates, batchUpdates; };
  const G plan[] = {{"btn25-open-6max-small", 6000, 90}, {"flop3-queens-6max-small", 9000, 150}, {"icm6-bb-call-small", 9000, 150}, {"btn25-open-6max", 1500, 30}, {"flop3-queens-6max", 1500, 30}, {"icm6-bb-call", 1500, 30}};
  for (const G &g : plan) for (const bool wide : {false, true}) for (const bool batch : {false, true}) {
    const std::string spec = specOf((fs::path(studies) / (std::string(g.fixture) + ".emfix.json")).string(), why), sp = p("record.spec.json");
    writeText(sp, withOptions(spec, optionsOf(wide, batch))); const long long updates = batch ? g.batchUpdates : g.updates;
    const Trained t = spec.empty() ? Trained{} : train(self, work, sp, updates, batch ? 3 : 1, p("record.state"), "", "512", fixed); bad += !t.ok; count++;
    golden += std::string("{\"") + g.fixture + "\", " + std::to_string(updates) + ", " + (batch ? "true" : "false") + ", " + (wide ? "true" : "false") + ", \"" + (t.ok ? t.sha : "FAILED") + "\"},\n";
  }
  for (const char *id : {"flop3-queens-6max-small", "icm6-bb-call-small"}) for (const bool wide : {false, true}) {
    const std::string spec = specOf((fs::path(studies) / (std::string(id) + ".emfix.json")).string(), why), sp = p("record.spec.json"); const long long updates = 20000;
    writeText(sp, withOptions(spec, optionsOf(wide, false)));
    const Trained t = spec.empty() ? Trained{} : train(self, work, sp, updates, 1, p("record.state")); const double nc = t.ok ? exactNashConv(self, work, sp, p("record.state"), why) : NAN; bad += !std::isfinite(nc); count++;
    reference += std::string("{\"") + id + "\", " + std::to_string(updates) + ", " + (wide ? "true" : "false") + ", " + fmt(nc) + "},\n";
  }
  fs::remove(p("record.spec.json"), ec); fs::remove(p("record.state"), ec);
  writeText(p("selftest512_golden.hpp"), golden); writeText(p("selftest512_reference.hpp"), reference);
  std::printf("{\"recorded\":%d,\"failed\":%d}\n", count, bad);
  return bad ? 1 : 0;
}
static int run(int argc, char **argv) {
  if (argc < 4 || argc > 5) { std::fprintf(stderr, "usage: mwcli --selftest512 studies-dir work-dir [all|fixtures|training|study]\n"); return 2; }
  const std::string studies = argv[2], work = argv[3], section = argc > 4 ? argv[4] : "all";
  if (section == "record") { std::error_code e2; fs::create_directories(work, e2); mw_study_identity(EM_VERSION, EM_BUILD_ID); return record(fs::absolute(studies, e2).string(), fs::absolute(work, e2).string(), ckpt::selfPath(argv[0])); }
  if (section != "all" && section != "fixtures" && section != "training" && section != "study") { std::fprintf(stderr, "error: the section must be all, fixtures, training or study\n"); return 2; }
  std::error_code ec; fs::create_directories(work, ec);
  if (!fs::is_directory(studies, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: studies-dir and work-dir must be directories\n"); return 2; }
  mw_study_identity(EM_VERSION, EM_BUILD_ID);
  Report R; const auto t0 = std::chrono::steady_clock::now(); const std::string S = fs::absolute(studies, ec).string(), W = fs::absolute(work, ec).string(), self = ckpt::selfPath(argv[0]);
  if (section == "all" || section == "fixtures") fixturesSection(R, S, W, self);
  if (section == "all" || section == "training") trainingSection(R, S, W, self);
  if (section == "all" || section == "study") studySection(R, S, W, self);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest512\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"" + section + "\",\"studyDefaultStreams\":\"" + (mw_study_default_wide() ? MW_STREAMS511 : "5.10 (32-bit)") + "\",\"passed\":" + std::to_string(R.passed) + ",\"failed\":" + std::to_string(R.failed) +
                  ",\"untested\":" + std::to_string(R.untested) + ",\"seconds\":" + fmt(secs) + ",\"checks\":[";
  for (size_t i = 0; i < R.checks.size(); i++) { const st58::Check &c = R.checks[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}";
  const std::string report = (fs::path(work) / "selftest512.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest512\",\"build\":\"%s\",\"section\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"report\":%s}\n", EM_BUILD_ID, section.c_str(), R.passed, R.failed, R.untested, mwa::jsonEsc(report).c_str());
  return R.failed || R.untested ? 1 : 0;
}
}
