// EightMax 5.10 (experimental): Rao-Blackwellised external sampling, the traversal. Members of Walker (included
// inside the struct by mw_es_impl.hpp); the estimator and its two rules (R1, R2) are stated in es_rbes510.hpp.
//
// One call of runRB serves one (deal, updating seat). Vector position x stands for one hand of the updating seat's
// range that is compatible with the sampled board and the opponents' sampled hands; positions are ordered by
// showdown score, so the terminal payoff of all hands is written as a few constant runs (the payoff depends on the
// hand only through its comparisons with the live opponents' scores).
RbDeal *rbDeal = nullptr; const RbSeat *rb = nullptr; int rbStreet[6] = {0, 0, 0, 0, 0, 0};
std::vector<int32_t> rbMap; std::vector<std::pair<int, int>> rbOrder;
long long rbExactTerminals = 0, rbSampled = 0, rbUnsampled = 0, rbRowsWritten = 0, rbHandsCarried = 0, rbSeatWalks = 0;
// Validation only (tests/rbes510.cpp): when set, the sampled action of every opponent decision is taken from this
// script instead of the random stream, and the probability of the scripted outcome is accumulated, so a test can
// enumerate EVERY outcome of the sampling of one traversal and form the exact expectation of what the traversal
// writes. Never set by the trainer.
struct RbScript { std::vector<int> choice, options; size_t at = 0; double prob = 1; } *rbScript = nullptr;
// The action sampled among the non-terminal children (term[b] false) with probability q[b] / qN.
int rbPick(const double *q, const bool *term, int k, double qN, int lastN) {
  if (rbScript) {
    int cand[8], nc = 0; for (int b = 0; b < k; b++) if (!term[b]) cand[nc++] = b;
    RbScript &sc = *rbScript; if (sc.at == sc.choice.size()) { sc.choice.push_back(0); sc.options.push_back(nc); }
    sc.options[sc.at] = nc; const int a = cand[sc.choice[sc.at++]]; sc.prob *= q[a] / qN; return a;
  }
  const double value = rng->next(); double cumulative = 0;
  for (int b = 0; b < k; b++) if (!term[b]) { cumulative += q[b] / qN; if (value < cumulative) return b; }
  return lastN;
}

// Compatible hands of `seat`, their conditional weights and scores, ordered by score; per street the row of each.
void rbBuildSeat(const Unit &unit, int seat, RbDeal &rd) {
  RbSeat &S = rd.seat[seat];
  uint8_t used[52] = {0};
  for (int i = 0; i < 5; i++) used[unit.w.cards[i]] = 1;
  for (int j = 0; j < m.n; j++) if (j != seat) { const Hand &h = m.hands[(size_t)j][(size_t)unit.w.seat[j]]; used[h.a] = used[h.b] = 1; }
  const auto &range = m.hands[(size_t)seat];
  double tot = 0; int H = 0;
  if (const RbScores *sc = rd.scores[seat]) {
    // cached: the range in score order; keep the hands that share no card with the opponents' hands
    const size_t no = sc->order.size(); S.hand.resize(no); S.score.resize(no); S.cw.resize(no);
    for (size_t o = 0; o < no; o++) {
      const int i = sc->order[o]; const Hand &h = range[(size_t)i]; if (used[h.a] || used[h.b]) continue;
      S.hand[(size_t)H] = i; S.score[(size_t)H] = sc->score[(size_t)i]; S.cw[(size_t)H] = h.w; tot += h.w; H++;
    }
    S.hand.resize((size_t)H); S.score.resize((size_t)H); S.cw.resize((size_t)H);
    for (int x = 0; x < H; x++) S.cw[(size_t)x] /= tot;
  } else {
    rbOrder.clear();
    for (size_t i = 0; i < range.size(); i++) {
      const Hand &h = range[i]; if (used[h.a] || used[h.b] || !(h.w > 0)) continue;
      rbOrder.emplace_back(m.startLen == 5 ? h.riverScore : evalSeven(unit.w.cards, h.a, h.b), (int)i); tot += h.w;
    }
    std::sort(rbOrder.begin(), rbOrder.end());
    H = (int)rbOrder.size();
    S.hand.resize((size_t)H); S.score.resize((size_t)H); S.cw.resize((size_t)H);
    for (int x = 0; x < H; x++) { S.score[(size_t)x] = rbOrder[(size_t)x].first; S.hand[(size_t)x] = rbOrder[(size_t)x].second; S.cw[(size_t)x] = range[(size_t)rbOrder[(size_t)x].second].w / tot; }
  }
  S.H = H;
  const int nli = g.groups.on ? g.groups.nl : 1;
  for (int li = 0; li < nli; li++) {
    const RbEntry &e = *rd.entry[seat][li];
    if (rbMap.size() < e.hand.size()) rbMap.resize(e.hand.size(), -1);
    S.slot[li].resize((size_t)H); S.slotCode[li].clear(); S.slotHand[li].clear(); S.mass[li].clear(); S.parent[li].clear(); int ns = 0;
    for (int x = 0; x < H; x++) {
      const uint16_t ei = e.idx[(size_t)S.hand[(size_t)x]];
      if (rbMap[ei] < 0) {
        rbMap[ei] = ns++; S.slotHand[li].push_back(e.hand[ei]); S.slotCode[li].push_back(e.code.empty() ? 0u : e.code[ei]);
        S.mass[li].push_back(0.0); S.parent[li].push_back(li ? S.slot[li - 1][(size_t)x] : (uint16_t)0);
      }
      S.slot[li][(size_t)x] = (uint16_t)rbMap[ei]; S.mass[li][(size_t)rbMap[ei]] += S.cw[(size_t)x];
    }
    for (int x = 0; x < H; x++) rbMap[e.idx[(size_t)S.hand[(size_t)x]]] = -1;
    S.ns[li] = ns; S.identity[li] = ns == H;   // slots are numbered in position order, so ns == H means slot[x] == x
  }
}
// Payoff of every position at terminal state t. A folded seat's payoff does not depend on its hand. Otherwise the
// payoff is a function of how the hand's score compares with each live opponent's score, so it is constant on the
// runs of positions between (and at) the opponents' scores; each run is evaluated once by the scalar seatPayoff.
void rbTerminal(const BS &t, uint64_t key, const TermRec *rec, double *out) {
  const int H = vH;
  if (!t.live[player]) { const double v = seatPayoff(t, key, rec); std::fill_n(out, H, v); return; }
  int os[8], mo = 0;
  for (int p = 0; p < m.n; p++) if (p != player && t.live[p]) os[mo++] = u->w.score[p];
  std::sort(os, os + mo); mo = (int)(std::unique(os, os + mo) - os);
  const int *sc = rb->score.data(); const int keep = u->w.score[player]; int j = 0, pos = 0;
  while (pos < H) {
    const int s = sc[pos]; while (j < mo && os[j] < s) j++;
    int end = pos + 1;
    if (j < mo && os[j] == s) { while (end < H && sc[end] == s) end++; }
    else { const int lim = j < mo ? os[j] : INT_MAX; while (end < H && sc[end] < lim) end++; }
    u->w.score[player] = s; const double v = seatPayoff(t, key, rec);
    std::fill(out + pos, out + end, v); pos = end;
  }
  u->w.score[player] = keep;
}
// The child of action a when it is terminal (its state, edge key and link record); false for a non-terminal child.
// No betting state is created: a non-terminal child that is not traversed leaves no trace in the tables.
bool rbTerminalChild(int d, int ref, const BS &t, int a, const BS *&c, uint64_t &key, const TermRec *&rec) {
  if (ref >= 0 && (size_t)ref < g.links.size()) {
    const int32_t kid = g.links[(size_t)ref].kid[a];
    if (kid >= 0) return false;
    if (kid <= -2) { rec = &g.terms[(size_t)(-(kid + 2))]; c = &rec->state; key = edgeKey(ref, a); return true; }
  }
  BS &x = st[(size_t)d + 1]; advance(ref, t, a, x);
  if (x.kind != 2) return false;
  c = &x; key = edgeKey(ref, a); rec = nullptr; return true;
}
// ---- the reference form: one value vector per node, the own reach carried per hand, every step written out. Kept
// for validation (spec "rbesWalk":"reference"; mwcli --selftest510 compares it with the production walk below on the
// same deals): the production walk computes the same increments with fewer passes over the vectors.
const double *learnRBref(int d, int ref, const double *own, double opp, double sp) {
  u->visits++;
  const BS &t = *cur[(size_t)d]; const int H = vH;
  if (t.kind == 2) {
    double *out = frame(d, (size_t)H);
    rbTerminal(t, ref == TERMINAL_REF ? terminalKey : UINT64_MAX, ref == TERMINAL_REF ? terminalRec : nullptr, out); return out;
  }
  if (d + 1 >= MAX_DEPTH || u->overflow) { u->overflow = true; double *out = frame(d, (size_t)H); std::fill_n(out, H, 0.0); return out; }
  if (t.kind == 1) { const int r = descendP(d, ref, t, CHANCE_SLOT); return learnRBref(d + 1, r, own, opp, sp); }
  const int k = t.k;
  if (k == 1) { const int r = descendP(d, ref, t, 0); return learnRBref(d + 1, r, own, opp, sp); }
  if (t.actor != player) {
    double *s = &sig[(size_t)d * 8], *q = &samp[(size_t)d * 8];
    const int physical = u->w.seat[t.actor];
    int hand = m.hands[(size_t)t.actor][(size_t)physical].strategyHand; uint32_t code = u->code[t.length];
    if (g.groups.on) { hand = 0; code = u->gk[t.length][t.actor]; }
    policy(ref, k, hand, code, s);
    for (int b = 0; b < k; b++) q[b] = g.exploreKeep * s[b] + g.exploreMix / k;
    double *out = frame(d, 2 * (size_t)H), *tmp = out + H;
    bool term[8]; int nT = 0, lastN = -1; double qN = 0;
    for (int a = 0; a < k; a++) {
      const BS *c = nullptr; uint64_t key = UINT64_MAX; const TermRec *rec = nullptr;
      term[a] = g.rbTerminals && rbTerminalChild(d, ref, t, a, c, key, rec);
      if (!term[a]) { qN += q[a]; lastN = a; continue; }
      if (!nT++) std::fill_n(out, H, 0.0);
      if (s[a] == 0) continue;   // contributes sigma(a) * payoff = 0: not evaluated
      u->visits++; rbExactTerminals++;
      rbTerminal(*c, key, rec, tmp);
      const double sa = s[a]; for (int x = 0; x < H; x++) out[x] += sa * tmp[x];
    }
    if (lastN < 0) { rbUnsampled++; return out; }   // every child is terminal: the exact expectation, nothing sampled
    const int a = rbPick(q, term, k, qN, lastN);
    const double p = q[a] / qN, ratio = s[a] / p;
    rbSampled++;
    const int r = descendP(d, ref, t, a);
    const double *v = learnRBref(d + 1, r, own, opp * s[a], sp * p);
    out = frame(d, 2 * (size_t)H);
    if (nT) for (int x = 0; x < H; x++) out[x] += ratio * v[x];
    else for (int x = 0; x < H; x++) out[x] = ratio * v[x];
    return out;
  }
  const RbSeat &R = *rb; const int li = rbStreet[t.length], G = R.ns[li]; const uint16_t *slot = R.slot[li].data();
  const size_t need = (size_t)H * (2 + (size_t)k) + (size_t)G * (2 * (size_t)k + 1);
  double *f = frame(d, need), *out = f, *CO = f + H, *V = CO + H, *S = V + (size_t)H * k, *RG = S + (size_t)G * k, *A = RG + (size_t)G * k;
  long long *rowOf = rowFrame(d, (size_t)G);
  const bool grouped = g.groups.on; const uint32_t streetCode = u->code[t.length];
  const uint16_t *slotHand = R.slotHand[li].data(); const uint32_t *slotCode = R.slotCode[li].data();
  for (int sl = 0; sl < G; sl++) rowOf[sl] = policy(ref, k, slotHand[sl], grouped ? slotCode[sl] : streetCode, S + (size_t)sl * k);
  if (!u->room(0, (size_t)G, 2 * (size_t)k * G, g.unitLimitBytes)) { u->overflow = true; std::fill_n(out, H, 0.0); return out; }
  for (int a = 0; a < k; a++) {
    for (int x = 0; x < H; x++) CO[x] = own[x] * S[(size_t)slot[x] * k + a];
    const int r = descendP(d, ref, t, a);
    const double *v = learnRBref(d + 1, r, CO, opp, sp);
    std::copy_n(v, H, V + (size_t)a * H);
  }
  std::fill_n(RG, (size_t)G * k, 0.0); std::fill_n(A, G, 0.0);
  const double *cw = R.cw.data();
  for (int x = 0; x < H; x++) {
    const double *sx = S + (size_t)slot[x] * k; double mean = 0;
    for (int a = 0; a < k; a++) mean += sx[a] * V[(size_t)a * H + x];
    out[x] = mean;
    double *rg = RG + (size_t)slot[x] * k; const double c = cw[x];
    for (int a = 0; a < k; a++) rg[a] += c * (V[(size_t)a * H + x] - mean);
    A[slot[x]] += c * own[x];
  }
  const double rw = step * opp / sp, aw = avgStep / sp;
  for (int sl = 0; sl < G; sl++) {
    const size_t off = u->vals.size(); u->vals.resize(off + 2 * (size_t)k);
    u->incs.push_back({ref, grouped ? slotCode[sl] : streetCode, off, (int32_t)rowOf[sl], slotHand[sl], (uint8_t)k}); newRows += rowOf[sl] < 0;
    double *x = &u->vals[off]; const double *sg = S + (size_t)sl * k, *rg = RG + (size_t)sl * k; const double as = aw * A[sl];
    for (int a = 0; a < k; a++) { x[a] = rw * rg[a]; x[k + a] = as * sg[a]; }
  }
  rbRowsWritten += G;
  return out;
}
// ---- the production form ----
// Three observations remove most passes over the hand vectors:
//  * a node writes `mult * value` straight into the buffer of the node that needs it (`target`, assigned or added
//    to), so an opponent node costs no pass at all: it only multiplies `mult` by sigma(a*)/p(a*) and hands the
//    buffer on, and terminal children add their runs to it;
//  * the children of an own node write into that node's per-action block, so nothing is copied;
//  * hands that share a row at a node shared a row at every earlier node of the same seat (a row key contains the
//    previous street's key; in the exact abstraction a row is a hand), so the seat's own reach is one number per
//    row, carried per row and expanded through the row-to-previous-street map when the street changes.
// The table rows of an own node are looked up together: all hash slots are computed and prefetched before the first
// is read, then all row records, then all value blocks, so the cache misses of one node overlap instead of following
// one another. The values read, and the regret matching applied to them, are those of policy().
std::vector<size_t> rbSlotAt; std::vector<double> rbRoot;
void rbPolicies(int ref, int k, int G, const uint16_t *hands, const uint32_t *codes, uint32_t streetCode, bool grouped, double *S, long long *rowOf) {
  if (ref < 0 || m.hkeys.empty()) { for (int sl = 0; sl < G; sl++) { rowOf[sl] = -1; std::fill_n(S + (size_t)sl * k, k, 1.0 / k); } return; }
  if (rbSlotAt.size() < (size_t)G) rbSlotAt.resize((size_t)G);
  const size_t mask = m.hkeys.size() - 1; const int64_t *hk = m.hkeys.data(); const int32_t *hr = m.hrow.data();
  for (int sl = 0; sl < G; sl++) {
    const size_t i = MW::mix(rowKey((uint32_t)ref, hands[sl], grouped ? codes[sl] : streetCode)) & mask;
    rbSlotAt[(size_t)sl] = i; __builtin_prefetch(hk + i); __builtin_prefetch(hr + i);
  }
  for (int sl = 0; sl < G; sl++) {
    const uint64_t key = rowKey((uint32_t)ref, hands[sl], grouped ? codes[sl] : streetCode); size_t i = rbSlotAt[(size_t)sl]; long long r = -1;
    while (hk[i] != -1) { if ((uint64_t)hk[i] == key) { r = hr[i]; break; } i = (i + 1) & mask; }
    rowOf[sl] = r; if (r >= 0) __builtin_prefetch(&m.rows[(size_t)r]);
  }
  for (int sl = 0; sl < G; sl++) if (rowOf[sl] >= 0) __builtin_prefetch(m.vals.data() + m.rows[(size_t)rowOf[sl]].off);
  for (int sl = 0; sl < G; sl++) {
    double *s = S + (size_t)sl * k; const long long r = rowOf[sl];
    if (r < 0) { std::fill_n(s, k, 1.0 / k); continue; }
    const double *regrets = m.vals.data() + m.rows[(size_t)r].off; double tot = 0;
    for (int a = 0; a < k; a++) { s[a] = jsMax0(regrets[a]); tot += s[a]; }
    for (int a = 0; a < k; a++) s[a] = tot ? s[a] / tot : 1.0 / k;
  }
}
// target[x] (=|+=) mult * payoff of position x at terminal t (see rbTerminal for the runs).
void rbTerminalInto(const BS &t, uint64_t key, const TermRec *rec, double *target, double mult, bool add) {
  const int H = vH;
  if (!t.live[player]) { const double v = mult * seatPayoff(t, key, rec); if (add) for (int x = 0; x < H; x++) target[x] += v; else std::fill_n(target, H, v); return; }
  int os[8], mo = 0;
  for (int p = 0; p < m.n; p++) if (p != player && t.live[p]) os[mo++] = u->w.score[p];
  std::sort(os, os + mo); mo = (int)(std::unique(os, os + mo) - os);
  const int *sc = rb->score.data(); const int keep = u->w.score[player]; int j = 0, pos = 0;
  while (pos < H) {
    const int s = sc[pos]; while (j < mo && os[j] < s) j++;
    int end = pos + 1;
    if (j < mo && os[j] == s) { while (end < H && sc[end] == s) end++; }
    else { const int lim = j < mo ? os[j] : INT_MAX; while (end < H && sc[end] < lim) end++; }
    u->w.score[player] = s; const double v = mult * seatPayoff(t, key, rec);
    if (add) for (int x = pos; x < end; x++) target[x] += v; else std::fill(target + pos, target + end, v);
    pos = end;
  }
  u->w.score[player] = keep;
}
// own: the seat's own reach per row of street index ownLi (ownLi < 0: no own decision yet, reach 1 everywhere).
void learnRB(int d, int ref, const double *own, int ownLi, double opp, double sp, double *target, double mult, bool add) {
  u->visits++;
  const BS &t = *cur[(size_t)d]; const int H = vH;
  if (t.kind == 2) { rbTerminalInto(t, ref == TERMINAL_REF ? terminalKey : UINT64_MAX, ref == TERMINAL_REF ? terminalRec : nullptr, target, mult, add); return; }
  if (d + 1 >= MAX_DEPTH || u->overflow) { u->overflow = true; if (!add) std::fill_n(target, H, 0.0); return; }
  if (t.kind == 1) { const int r = descendP(d, ref, t, CHANCE_SLOT); learnRB(d + 1, r, own, ownLi, opp, sp, target, mult, add); return; }
  const int k = t.k;
  if (k == 1) { const int r = descendP(d, ref, t, 0); learnRB(d + 1, r, own, ownLi, opp, sp, target, mult, add); return; }
  if (t.actor != player) {
    double *s = &sig[(size_t)d * 8], *q = &samp[(size_t)d * 8];
    const int physical = u->w.seat[t.actor];
    int hand = m.hands[(size_t)t.actor][(size_t)physical].strategyHand; uint32_t code = u->code[t.length];
    if (g.groups.on) { hand = 0; code = u->gk[t.length][t.actor]; }
    policy(ref, k, hand, code, s);
    for (int b = 0; b < k; b++) q[b] = g.exploreKeep * s[b] + g.exploreMix / k;
    bool term[8]; int lastN = -1; double qN = 0;
    for (int a = 0; a < k; a++) {
      const BS *c = nullptr; uint64_t key = UINT64_MAX; const TermRec *rec = nullptr;
      term[a] = g.rbTerminals && rbTerminalChild(d, ref, t, a, c, key, rec);
      if (!term[a]) { qN += q[a]; lastN = a; continue; }
      if (s[a] == 0) continue;   // contributes sigma(a) * payoff = 0: not evaluated
      u->visits++; rbExactTerminals++;
      rbTerminalInto(*c, key, rec, target, mult * s[a], add); add = true;
    }
    if (lastN < 0) { rbUnsampled++; return; }   // every child is terminal: the exact expectation, nothing sampled
    const int a = rbPick(q, term, k, qN, lastN);
    const double p = q[a] / qN, ratio = s[a] / p;
    rbSampled++;
    const int r = descendP(d, ref, t, a);
    learnRB(d + 1, r, own, ownLi, opp * s[a], sp * p, target, mult * ratio, add);
    return;
  }
  const RbSeat &R = *rb; const int li = rbStreet[t.length], G = R.ns[li]; const uint16_t *slot = R.slot[li].data();
  const size_t need = (size_t)H * (size_t)k + (size_t)G * (2 * (size_t)k + 2);
  double *f = frame(d, need), *OW = f, *CO = OW + G, *S = CO + G, *RG = S + (size_t)G * k, *V = RG + (size_t)G * k;
  long long *rowOf = rowFrame(d, (size_t)G);
  const bool grouped = g.groups.on; const uint32_t streetCode = u->code[t.length];
  const uint16_t *slotHand = R.slotHand[li].data(); const uint32_t *slotCode = R.slotCode[li].data();
  if (ownLi < 0) std::fill_n(OW, G, 1.0);
  else if (ownLi == li) std::copy_n(own, G, OW);
  else for (int sl = 0; sl < G; sl++) { int p = sl; for (int j = li; j > ownLi; j--) p = R.parent[j][(size_t)p]; OW[sl] = own[p]; }
  rbPolicies(ref, k, G, slotHand, slotCode, streetCode, grouped, S, rowOf);
  if (!u->room(0, (size_t)G, 2 * (size_t)k * G, g.unitLimitBytes)) { u->overflow = true; if (!add) std::fill_n(target, H, 0.0); return; }
  for (int a = 0; a < k; a++) {
    for (int sl = 0; sl < G; sl++) CO[sl] = OW[sl] * S[(size_t)sl * k + a];
    const int r = descendP(d, ref, t, a);
    learnRB(d + 1, r, CO, li, opp, sp, V + (size_t)a * H, 1.0, false);
  }
  const double *cw = R.cw.data();
  const double rw = step * opp / sp, aw = avgStep / sp; const double *mass = R.mass[li].data();
  const size_t off0 = u->vals.size(); u->vals.resize(off0 + 2 * (size_t)k * G);
  if (R.identity[li]) {
    // every position has its own row: the increments are written directly (the general form below with one hand per row)
    for (int x = 0; x < H; x++) {
      const double *sx = S + (size_t)x * k; double mean = 0;
      for (int a = 0; a < k; a++) mean += sx[a] * V[(size_t)a * H + x];
      if (add) target[x] += mult * mean; else target[x] = mult * mean;
      double *o = &u->vals[off0 + 2 * (size_t)k * x]; const double c = cw[x], as = aw * (OW[x] * mass[x]);
      for (int a = 0; a < k; a++) { o[a] = rw * (0.0 + c * (V[(size_t)a * H + x] - mean)); o[k + a] = as * sx[a]; }
    }
  } else {
    std::fill_n(RG, (size_t)G * k, 0.0);
    for (int x = 0; x < H; x++) {
      const size_t sl = slot[x]; const double *sx = S + sl * k; double mean = 0;
      for (int a = 0; a < k; a++) mean += sx[a] * V[(size_t)a * H + x];
      if (add) target[x] += mult * mean; else target[x] = mult * mean;
      double *rg = RG + sl * k; const double c = cw[x];
      for (int a = 0; a < k; a++) rg[a] += c * (V[(size_t)a * H + x] - mean);
    }
    for (int sl = 0; sl < G; sl++) {
      double *x = &u->vals[off0 + 2 * (size_t)k * sl]; const double *sg = S + (size_t)sl * k, *rg = RG + (size_t)sl * k; const double as = aw * (OW[sl] * mass[sl]);
      for (int a = 0; a < k; a++) { x[a] = rw * rg[a]; x[k + a] = as * sg[a]; }
    }
  }
  for (int sl = 0; sl < G; sl++) {
    u->incs.push_back({ref, grouped ? slotCode[sl] : streetCode, off0 + 2 * (size_t)k * sl, (int32_t)rowOf[sl], slotHand[sl], (uint8_t)k}); newRows += rowOf[sl] < 0;
  }
  rbRowsWritten += G;
}
void runRB(Unit &unit, int seat, Rng &r, double stp, double avgStp) {
  u = &unit; rng = &r; player = seat; step = stp; avgStep = avgStp;
  if (!vres) vres = vhand.get_allocator().resource();
  rbBuildSeat(unit, seat, *rbDeal); rb = &rbDeal->seat[seat]; vH = rb->H;
  if (g.groups.on) for (int li = 0; li < g.groups.nl; li++) rbStreet[g.groups.lengths[li]] = li;
  rbSeatWalks++; rbHandsCarried += vH;
  cur[0] = &g.rootState;
  if (g.rbReference) { vone.assign((size_t)vH, 1.0); learnRBref(0, 0, vone.data(), 1, 1); return; }
  if (rbRoot.size() < (size_t)vH) rbRoot.resize((size_t)vH);
  learnRB(0, 0, nullptr, -1, 1, 1, rbRoot.data(), 1.0, false);
}
