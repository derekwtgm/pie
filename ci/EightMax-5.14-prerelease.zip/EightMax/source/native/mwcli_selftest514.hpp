// EightMax 5.14 (Phase 4, faster multiway convergence): mwcli --selftest514 <studies-dir> <work-dir> [all|pruning|merge]
//
//   pruning   the two experimental pruning algorithms nrp-5.14-v1 and nrpc-5.14-v1 (Game::prune in mw_es.hpp):
//               P1  recorded states (SHA-256 from the Linux build of this release): four small fixtures, both
//                   algorithms, 5.10 streams and philox64, one deal per update and frozen batches on three threads;
//               P2  pruning prunes: on a three-street fixture the trainer reports candidates and skipped actions,
//                   visits fewer states than the default trainer for the same deals, and nrpc reports walks with the
//                   correction;
//               P3  a frozen batch writes the same state on 1 and 3 threads; stopped after a third and continued =
//                   uninterrupted, byte for byte; both algorithms, both kinds of streams;
//               P4  a pruned state names its algorithm, threshold, evidence and skip probability in the header (a default
//                   state names none) and is refused, with the reason, exit 1 and nothing written, by the default
//                   trainer, by the other algorithm and by another threshold; a default state is refused by pruning;
//               P5  what is refused before training: an unknown identifier, pruning with rbes, with DCFR, with regret
//                   matching+, with own-hand enumeration, and a pruning parameter without pruning;
//               P6  exact NashConv of two small games after a fixed budget, as recorded (a regression check; one seed
//                   each, no convergence claim), and "pruning":"none" writes the state of the default trainer.
//   merge     G1  the 5.14 merge of a frozen batch (increments grouped by merging thread): one state for 1, 2, 3 and
//                 4 threads with every update spread over the threads, default trainer and rbes, equal to the state
//                 recorded from the Linux build.
// Report: <work-dir>/selftest514.json. Exit status: 0 every check passed, 1 a check failed or is untested, 2 usage.
//   mwcli --selftest514 studies work record   writes selftest514_golden.hpp and selftest514_reference.hpp from THIS
//                                             build (once, on Linux, at release).
#pragma once
namespace st514 {
namespace fs = std::filesystem;
using st58::Report; using st58::fmt; using st58::sci; using st58::get; using st58::num; using st58::str; using st58::Doc;
using st510::writeText; using st510::Trained; using st510::train; using st510::exactNashConv;
using st512::join; using st512::optionsOf; using st513::Fx; using st513::fixtureOf;
static const char *const ALGS[] = {"nrp-5.14-v1", "nrpc-5.14-v1"};
static std::string pruneOption(const char *alg) { return std::string("\"pruning\":\"") + alg + "\""; }
struct Golden514 { const char *fixture, *alg; long long updates; bool batch, wide; const char *sha; };
static const Golden514 GOLDEN514[] = {
#include "selftest514_golden.hpp"
};
struct Reference514 { const char *fixture, *alg; long long updates; double nash; };
static const Reference514 REFERENCE514[] = {
#include "selftest514_reference.hpp"
};
static const char *const BATCH16 = "\"batchDeals\":16,\"actionStreams\":\"deal\"";
static const std::vector<std::pair<std::string, std::string>> FIXED = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
static std::string headOf(const std::string &path) { const std::vector<unsigned char> raw = slurp(path.c_str()); return std::string(raw.begin(), raw.begin() + std::min<size_t>(raw.size(), 900)); }
static void pruningSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "pruning"; std::error_code ec; auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); };
  { int same = 0, total = 0; std::string detail;
    for (const Golden514 &g : GOLDEN514) { if (!*g.alg || !std::strcmp(g.alg, "merge-default") || !std::strcmp(g.alg, "merge-rbes")) continue; total++; std::string why;
      const Fx f = fixtureOf(studies, work, g.fixture, join(optionsOf(g.wide, g.batch), pruneOption(g.alg)), "p1", why); if (f.path.empty()) { detail += std::string(g.fixture) + ": " + why + "; "; continue; }
      const Trained t = train(self, work, f.path, g.updates, g.batch ? 3 : 1, state("p1"), "", "512", FIXED);
      if (t.ok && t.sha == g.sha) same++; else detail += std::string(g.fixture) + " " + g.alg + (g.wide ? " philox64" : " 5.10 streams") + (g.batch ? " (batch)" : "") + ": " + (t.ok ? "state " + t.sha.substr(0, 16) + " instead of " + std::string(g.sha).substr(0, 16) : "exit " + std::to_string(t.exitCode) + " " + t.err) + "; ";
      fs::remove(f.path, ec); }
    R.check(sec, "P1", "pruning: the saved states have the SHA-256 recorded from the Linux build of this release (four small fixtures; nrp-5.14-v1 and nrpc-5.14-v1; 5.10 streams and philox64; one deal per update and frozen batches of 64 on three threads)", same == total && total > 0, std::to_string(same) + " of " + std::to_string(total) + " states identical" + (detail.empty() ? "" : "; " + detail)); }
  { std::string why, detail; bool ok = true; const Fx d = fixtureOf(studies, work, "flop3-kings-small", "", "p2d", why); const Trained base = d.path.empty() ? Trained{} : train(self, work, d.path, 30000, 1, state("p2"));
    Doc bd(base.out); const double baseVisits = num(get(bd.v, "stateVisits"), 0); ok = base.ok && baseVisits > 0; detail = "default: " + fmt(baseVisits) + " state visits; ";
    for (const char *alg : ALGS) { const Fx f = fixtureOf(studies, work, "flop3-kings-small", pruneOption(alg), "p2", why); const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 30000, 1, state("p2"));
      Doc td(t.out); const JV *pr = get(get(td.v, "trainer"), "pruning"); const double visits = num(get(td.v, "stateVisits"), 0), cand = num(get(pr, "candidates"), 0), skipped = num(get(pr, "skipped"), 0), walked = num(get(pr, "walked"), 0);
      const bool good = t.ok && pr && str(get(pr, "identifier")) == alg && cand > 0 && skipped > 0 && walked > 0 && cand == skipped + walked && visits < baseVisits && str(get(get(td.v, "trainer"), "algorithm")).rfind(alg, 0) == 0;
      ok = ok && good; detail += std::string(alg) + ": " + fmt(visits) + " state visits, " + fmt(cand) + " candidates, " + fmt(skipped) + " skipped, " + fmt(walked) + " walked" + (good ? "" : " NOT AS EXPECTED " + t.err) + "; "; if (!f.path.empty()) fs::remove(f.path, ec); }
    R.check(sec, "P2", "pruning prunes: on flop3-kings-small (three betting streets) after 30,000 deals both algorithms report candidates, skipped actions and candidates that were walked (candidates = skipped + walked), visit fewer states than the default trainer, and the trainer names the algorithm with its parameters", ok, detail + base.err);
    if (!d.path.empty()) fs::remove(d.path, ec); }
  { int good = 0, n = 0; std::string detail;
    for (const char *alg : ALGS) for (const bool wide : {false, true}) {
      n++; std::string why; const Fx f = fixtureOf(studies, work, "flop3-kings-small", join(optionsOf(wide, false), pruneOption(alg)), "p3", why), fb = fixtureOf(studies, work, "flop6-jack-small", join(optionsOf(wide, true), pruneOption(alg)), "p3b", why);
      if (f.path.empty() || fb.path.empty()) { detail += why + "; "; continue; }
      const Trained a = train(self, work, f.path, 9000, 1, state("p3a")), p = train(self, work, f.path, 3000, 1, state("p3p")), c = p.ok ? train(self, work, f.path, 6000, 1, state("p3c"), state("p3p")) : Trained{};
      const Trained b1 = train(self, work, fb.path, 150, 1, state("p3d"), "", "512", FIXED), b3 = train(self, work, fb.path, 150, 3, state("p3e"), "", "512", FIXED), bp = train(self, work, fb.path, 50, 2, state("p3f"), "", "512", FIXED), bc = bp.ok ? train(self, work, fb.path, 100, 3, state("p3g"), state("p3f"), "512", FIXED) : Trained{};
      const bool ok = a.ok && c.ok && b1.ok && b3.ok && bc.ok && c.sha == a.sha && b1.sha == b3.sha && bc.sha == b1.sha; good += ok;
      if (!ok) detail += std::string(alg) + (wide ? " philox64" : " 5.10 streams") + ": continued " + (c.sha == a.sha ? "same" : "DIFFERENT") + ", 3 threads " + (b1.sha == b3.sha ? "same" : "DIFFERENT") + ", batch continued " + (bc.sha == b1.sha ? "same" : "DIFFERENT") + " " + a.err + c.err + b1.err + "; ";
      fs::remove(f.path, ec); fs::remove(fb.path, ec); }
    R.check(sec, "P3", "pruning: a frozen batch gives the same state on 1 and 3 threads; stopped after a third and continued = uninterrupted, byte for byte (the skip decisions are drawn from the training streams, so they do not depend on threads or on where a training was stopped); both algorithms, 5.10 streams and philox64", good == n && n > 0, std::to_string(good) + " of " + std::to_string(n) + " configurations" + (detail.empty() ? "" : "; " + detail));
    for (const char *t : {"p3a", "p3p", "p3c", "p3d", "p3e", "p3f", "p3g"}) fs::remove(state(t), ec); }
  { std::string why; const Fx d = fixtureOf(studies, work, "flop3-kings-small", "", "p4d", why), a = fixtureOf(studies, work, "flop3-kings-small", pruneOption(ALGS[0]), "p4a", why), c = fixtureOf(studies, work, "flop3-kings-small", pruneOption(ALGS[1]), "p4c", why),
      o = fixtureOf(studies, work, "flop3-kings-small", pruneOption(ALGS[0]) + ",\"pruneThreshold\":0.5", "p4o", why);
    if (d.path.empty() || a.path.empty() || c.path.empty() || o.path.empty()) R.add(sec, "P4", "checkpoint rules of pruning", "untested", why);
    else {
      const Trained td = train(self, work, d.path, 2000, 1, state("p4d")), ta = train(self, work, a.path, 2000, 1, state("p4a"));
      const std::string ha = headOf(state("p4a")), hd = headOf(state("p4d"));
      const bool named = ha.find("\"estimator\":\"nrp-5.14-v1;threshold=0.02;evidence=50;skip=0.94999999999999996\"") != std::string::npos, plain = hd.find("\"estimator\"") == std::string::npos;
      struct Try { const std::string *spec; const char *in, *want; }; const Try tries[] = {{&d.path, "p4a", "experimental training algorithm"}, {&c.path, "p4a", "other pruning settings"}, {&o.path, "p4a", "other pruning settings"}, {&a.path, "p4d", "cannot be continued with pruning"}};
      int refused = 0; std::string detail;
      for (const Try &t : tries) { const std::string out = state("p4no"); fs::remove(out, ec); const Trained r = train(self, work, *t.spec, 5, 1, out, state(t.in)); const bool ok = !r.ok && r.exitCode == 1 && r.err.find(t.want) != std::string::npos && !fs::exists(out, ec); refused += ok;
        if (!ok) detail += std::string(t.in) + ": exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 160) + "; "; }
      R.check(sec, "P4", "a pruned state names its algorithm, threshold, evidence and skip probability in the header (a default state names none) and is refused, with the reason, exit 1 and nothing written, by the default trainer, by the other pruning algorithm and by another threshold; a default state is refused by pruning", td.ok && ta.ok && named && plain && refused == 4,
              std::string("header: ") + (named ? "names nrp-5.14-v1 with threshold, evidence and skip" : "DOES NOT name the algorithm") + "; default header: " + (plain ? "no algorithm" : "NAMES ONE") + "; refused " + std::to_string(refused) + " of 4" + (detail.empty() ? "" : "; " + detail) + td.err + ta.err);
    }
    for (const std::string &x : {d.path, a.path, c.path, o.path}) if (!x.empty()) fs::remove(x, ec);
    for (const char *t : {"p4d", "p4a", "p4no"}) fs::remove(state(t), ec); }
  { struct Bad { const char *options, *want; }; const Bad bad[] = {{"\"pruning\":\"nrp-9\"", "Unknown pruning"}, {"\"pruning\":\"nrp-5.14-v1\",\"estimator\":\"rbes\"", "default estimator only"}, {"\"pruning\":\"nrp-5.14-v1\",\"weighting\":\"dcfr\"", "Pruning (experimental) needs"},
      {"\"pruning\":\"nrpc-5.14-v1\",\"regretMatching\":\"plus\"", "Pruning (experimental) needs"}, {"\"pruning\":\"nrp-5.14-v1\",\"ownHandEnumeration\":true", "default estimator only"}, {"\"pruneThreshold\":0.01", "needs pruning"}, {"\"pruneEvidence\":10", "needs pruning"}, {"\"pruning\":\"nrp-5.14-v1\",\"pruneSkip\":1", "pruneSkip"}};
    int refused = 0, n = 0; std::string detail, why;
    for (const Bad &b : bad) { n++; const Fx f = fixtureOf(studies, work, "flop3-kings-small", b.options, "p5", why); const std::string out = state("p5"); fs::remove(out, ec);
      const Trained r = f.path.empty() ? Trained{} : train(self, work, f.path, 5, 1, out); const bool ok = !r.ok && r.exitCode == 1 && r.err.find(b.want) != std::string::npos && !fs::exists(out, ec); refused += ok;
      if (!ok) detail += std::string(b.options) + ": exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 140) + "; "; if (!f.path.empty()) fs::remove(f.path, ec); }
    R.check(sec, "P5", "refused before anything is trained, with the reason, exit 1 and nothing written: an unknown pruning identifier; pruning with estimator rbes, with DCFR, with regret matching+ and with own-hand enumeration; a pruning threshold or evidence without pruning; a skip probability of 1", refused == n, std::to_string(refused) + " of " + std::to_string(n) + " refused" + (detail.empty() ? "" : "; " + detail)); }
  { int okc = 0, total = 0; std::string detail, why;
    for (const Reference514 &ref : REFERENCE514) { total++; const Fx f = fixtureOf(studies, work, ref.fixture, pruneOption(ref.alg), "p6", why); if (f.path.empty()) { detail += why + "; "; continue; }
      const Trained a = train(self, work, f.path, ref.updates, 1, state("p6")); double nc = NAN; if (a.ok) nc = exactNashConv(self, work, f.path, state("p6"), why);
      const bool good = std::isfinite(nc) && std::fabs(nc - ref.nash) <= 1e-9 * std::max({1.0, std::fabs(nc), std::fabs(ref.nash)}); okc += good;
      detail += std::string(ref.fixture) + " " + ref.alg + ": exact NashConv " + sci(nc) + (good ? "" : " (recorded " + sci(ref.nash) + ") " + why + a.err) + "; "; fs::remove(f.path, ec); }
    const Fx d = fixtureOf(studies, work, "flop3-kings-small", "", "p6d", why), nn = fixtureOf(studies, work, "flop3-kings-small", "\"pruning\":\"none\"", "p6n", why);
    const Trained td = d.path.empty() ? Trained{} : train(self, work, d.path, 3000, 1, state("p6")), tn = nn.path.empty() ? Trained{} : train(self, work, nn.path, 3000, 1, state("p6n")); const bool none = td.ok && tn.ok && td.sha == tn.sha;
    R.check(sec, "P6", "pruning: the exact NashConv of the trained strategy of two small games after a fixed budget equals the value recorded at release (a regression check; one seed each, no convergence claim); \"pruning\":\"none\" writes the state of the default trainer", okc == total && total > 0 && none,
            std::to_string(okc) + " of " + std::to_string(total) + " reproduce the recorded value; " + detail + "pruning none " + (none ? "= default state" : "DIFFERS FROM the default state"));
    for (const std::string &x : {d.path, nn.path}) if (!x.empty()) fs::remove(x, ec); fs::remove(state("p6"), ec); fs::remove(state("p6n"), ec); }
  fs::remove(state("p1"), ec); fs::remove(state("p2"), ec);
}
static void mergeSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "merge"; std::error_code ec; int good = 0, n = 0; std::string detail, why; const std::string st = (fs::path(work) / "g1.state").string();
  for (const Golden514 &g : GOLDEN514) { const bool rb = !std::strcmp(g.alg, "merge-rbes"); if (!rb && std::strcmp(g.alg, "merge-default")) continue; n++;
    const Fx f = fixtureOf(studies, work, g.fixture, join(join(optionsOf(g.wide, false), BATCH16), rb ? "\"estimator\":\"rbes\"" : ""), "g1", why); if (f.path.empty()) { detail += why + "; "; continue; }
    bool ok = true; std::string shas;
    for (int threads : {1, 2, 3, 4}) { const Trained t = train(self, work, f.path, g.updates, threads, st, "", "512", FIXED); ok = ok && t.ok && t.sha == g.sha; shas += (t.ok ? t.sha.substr(0, 12) : "exit " + std::to_string(t.exitCode) + " " + t.err.substr(0, 80)) + " "; }
    good += ok; if (!ok) detail += std::string(g.fixture) + (rb ? " rbes" : " default") + ": " + shas + "(recorded " + std::string(g.sha).substr(0, 12) + "); "; fs::remove(f.path, ec); }
  fs::remove(st, ec);
  R.check(sec, "G1", "the 5.14 merge of a frozen batch (the increments of every deal grouped by merging thread): frozen batches of 16 with every update spread over the threads give, on 1, 2, 3 and 4 threads, the state recorded from the Linux build; default trainer and rbes, 5.10 streams and philox64", good == n && n > 0, std::to_string(good) + " of " + std::to_string(n) + " configurations, four thread counts each" + (detail.empty() ? "" : "; " + detail));
}
static int record(const std::string &studies, const std::string &work, const std::string &self) {
  std::error_code ec; std::string golden, reference, why; int bad = 0, count = 0; auto p = [&](const char *n) { return (fs::path(work) / n).string(); };
  struct G { const char *fixture; long long updates, batchUpdates; }; const G plan[] = {{"flop3-kings-small", 9000, 150}, {"flop6-jack-small", 9000, 150}, {"icm6-bb-call-small", 9000, 150}, {"flop3-queens-6max-small", 9000, 150}};
  for (const G &g : plan) for (const char *alg : ALGS) for (const bool wide : {false, true}) for (const bool batch : {false, true}) {
    const Fx f = fixtureOf(studies, work, g.fixture, join(optionsOf(wide, batch), pruneOption(alg)), "record", why); const long long updates = batch ? g.batchUpdates : g.updates;
    const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, updates, batch ? 3 : 1, p("record.state"), "", "512", FIXED); bad += !t.ok; count++;
    golden += std::string("{\"") + g.fixture + "\", \"" + alg + "\", " + std::to_string(updates) + ", " + (batch ? "true" : "false") + ", " + (wide ? "true" : "false") + ", \"" + (t.ok ? t.sha : "FAILED") + "\"},\n"; if (!f.path.empty()) fs::remove(f.path, ec); }
  for (const char *fixture : {"flop3-kings-small", "flop6-jack-small"}) for (const bool rb : {false, true}) for (const bool wide : {false, true}) {
    const Fx f = fixtureOf(studies, work, fixture, join(join(optionsOf(wide, false), BATCH16), rb ? "\"estimator\":\"rbes\"" : ""), "record", why);
    const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 400, 1, p("record.state"), "", "512", FIXED); bad += !t.ok; count++;
    golden += std::string("{\"") + fixture + "\", \"" + (rb ? "merge-rbes" : "merge-default") + "\", 400, true, " + (wide ? "true" : "false") + ", \"" + (t.ok ? t.sha : "FAILED") + "\"},\n"; if (!f.path.empty()) fs::remove(f.path, ec); }
  for (const char *id : {"known-akq-river", "icm6-bb-call-small"}) for (const char *alg : ALGS) {
    const Fx f = fixtureOf(studies, work, id, pruneOption(alg), "record", why); const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 20000, 1, p("record.state")); const double nc = t.ok ? exactNashConv(self, work, f.path, p("record.state"), why) : NAN; bad += !std::isfinite(nc); count++;
    reference += std::string("{\"") + id + "\", \"" + alg + "\", 20000, " + fmt(nc) + "},\n"; if (!f.path.empty()) fs::remove(f.path, ec); }
  fs::remove(p("record.state"), ec);
  writeText(p("selftest514_golden.hpp"), golden); writeText(p("selftest514_reference.hpp"), reference);
  std::printf("{\"recorded\":%d,\"failed\":%d%s}\n", count, bad, why.empty() ? "" : (",\"note\":" + mwa::jsonEsc(why)).c_str()); return bad ? 1 : 0;
}
static int run(int argc, char **argv) {
  if (argc < 4 || argc > 5) { std::fprintf(stderr, "usage: mwcli --selftest514 studies-dir work-dir [all|pruning|merge]\n"); return 2; }
  const std::string studies = argv[2], work = argv[3], section = argc > 4 ? argv[4] : "all"; std::error_code ec; fs::create_directories(work, ec); mw_study_identity(EM_VERSION, EM_BUILD_ID);
  if (section == "record") return record(fs::absolute(studies, ec).string(), fs::absolute(work, ec).string(), ckpt::selfPath(argv[0]));
  if (section != "all" && section != "pruning" && section != "merge") { std::fprintf(stderr, "error: the section must be all, pruning or merge\n"); return 2; }
  if (!fs::is_directory(studies, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: studies-dir and work-dir must be directories\n"); return 2; }
  Report R; const auto t0 = std::chrono::steady_clock::now(); const std::string S = fs::absolute(studies, ec).string(), W = fs::absolute(work, ec).string(), self = ckpt::selfPath(argv[0]);
  if (section == "all" || section == "pruning") pruningSection(R, S, W, self);
  if (section == "all" || section == "merge") mergeSection(R, S, W, self);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest514\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"" + section + "\",\"pruningAlgorithms\":[\"nrp-5.14-v1\",\"nrpc-5.14-v1\"],\"passed\":" + std::to_string(R.passed) + ",\"failed\":" + std::to_string(R.failed) + ",\"untested\":" + std::to_string(R.untested) + ",\"seconds\":" + fmt(secs) + ",\"checks\":[";
  for (size_t i = 0; i < R.checks.size(); i++) { const st58::Check &c = R.checks[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}"; const std::string report = (fs::path(work) / "selftest514.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest514\",\"build\":\"%s\",\"section\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"report\":%s}\n", EM_BUILD_ID, section.c_str(), R.passed, R.failed, R.untested, mwa::jsonEsc(report).c_str());
  return R.failed || R.untested ? 1 : 0;
}
}
