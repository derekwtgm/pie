// EightMax 5.9: confidence statements of the trained-response measure (response58.hpp, response59.hpp).
// Self-contained: only the C++ standard library. Included by the engine (mw.cpp) and by mwcli.
// Proofs, assumptions and the experiments against exact values: MATHEMATICAL-VALIDATION-5.9.md, sections 2 to 4;
// the meaning of every output field: STATISTICAL-CHANGES-5.9.md.
//
// WHAT WAS WRONG IN 5.8. `summary.sumOfSeatLowerBounds95` added, over the seats, max(0, mean_i - 1.645 SE_i): per-seat
// ONE-SIDED NORMAL-APPROXIMATION bounds. Two defects. (1) The normal approximation has no finite-sample guarantee and
// fails where a frozen strategy takes rare actions with large consequences (5.8 measured 193 of 960 estimates more
// than four reported standard errors from the exact value). (2) Even with exact per-seat 95% bounds, the event "all k
// bounds hold" is only guaranteed with probability 1 - k * 0.05, so the sum was not a 95% statement. The field said
// so in prose; it was still easy to read as one.
//
// WHAT IS REPORTED NOW. Notation: seat i has N_i evaluation samples d_i1..d_iN (i.i.d. given the fixed response R_i,
// each inside an interval of proven width W_i), mean m_i, unbiased sample variance V_i, true mean g_i = gain_i(R_i).
// b_i >= max(0, g_i) is the seat's best-response gain; NashConv = sum over ALL seats of b_i.
//
// (A) PER SEAT, one-sided, distribution-free (Maurer & Pontil 2009, Theorem 4, applied to (hi - d) / W): for every
//     delta in (0, 1), with probability at least 1 - delta,
//         g_i >= m_i - h(V_i, W_i, N_i, delta),   h = sqrt(2 V ln(2/delta) / N) + 7 W ln(2/delta) / (3 (N - 1)).
//     Conditions: i.i.d. samples, equal weights, a true bound W on the range, N fixed before any value is seen, and R_i
//     fixed before the evaluation samples are drawn. (5.8's `bounded` interval is the two-sided form, ln(4/delta).)
//
// (B) SIMULTANEOUS over a family F of k seats (the recommended statement; `simultaneous`): give seat i the error
//     budget delta_i = alpha / k. By the union bound (Boole's inequality) all k statements (A) hold together with
//     probability at least 1 - sum_i delta_i = 1 - alpha. NO independence between the seats is used: the bound is
//     valid under any dependence between the seats' evaluations. On that event
//         sum_{i in F} g_i   >=  sum_{i in F} L_i                      L_i = m_i - h(V_i, W_i, N_i, alpha / k)
//         NashConv >= sum_{i in F} b_i >= sum_{i in F} max(0, g_i) >= sum_{i in F} max(0, L_i).
//     The floor at 0 is valid seat by seat because b_i >= 0 holds without any measurement (the seat may keep sigma).
//     A seat whose evaluation did not complete contributes the trivial bound 0 to the NashConv statement (and makes the
//     statement about sum g_i unavailable); this is valid because the event "seat i completed and L_i > g_i" is
//     contained in the event "L_i > g_i", whose probability is at most delta_i whatever decides the completion.
//     `analyses` > 1 divides alpha further (Bonferroni) for a family of that many PRESPECIFIED response analyses of
//     which the largest bound will be reported (several response budgets or seeds).
//
// (C) POOLED over independent seats (`pooledIndependent`; tighter for sums of several seats, one more assumption):
//     if the seats' evaluation samples are mutually independent, Bernstein's inequality for independent bounded
//     variables (Boucheron, Lugosi & Massart 2013, Theorem 2.10; the form of Maurer & Pontil's Theorem 3) gives, for
//     a set B of seats, with probability at least 1 - delta1,
//         sum_{i in B} (g_i - m_i) >= - sqrt(2 ln(1/delta1) * sum_{i in B} s_i^2 / N_i) - max_{i in B} (W_i / N_i) ln(1/delta1) / 3
//     where s_i^2 is the TRUE variance of seat i's samples. Maurer & Pontil's Theorem 10 bounds it from the sample:
//     with probability at least 1 - delta2, s_i <= sqrt(V_i) + W_i sqrt(2 ln(1/delta2) / (N_i - 1)).
//     The family is every non-empty subset B of the k planned seats (2^k - 1 Bernstein events) and the k variance
//     events: delta2 = alpha / (2 k), delta1 = alpha / (2 (2^k - 1)), so everything holds together with probability at
//     least 1 - alpha and the LARGEST subset bound may be reported: NashConv >= sum_{i in B} b_i >= sum_{i in B} g_i
//     for every B. Subsets matter because a response can be worse than sigma (g_i < 0): such a seat lowers the sum
//     over all seats, and choosing the seats after seeing the data is only valid when every choice was covered.
//
// (B) and (C) are two separate statements at level alpha. Reading the larger of the two is a statement at level
// 2 alpha; to report max(B, C) at 95%, request confidence 0.975 (STATISTICAL-CHANGES-5.9.md, section 5).
//
// NEVER AN UPPER BOUND. Every number here bounds NashConv from below, inside the study's betting abstraction. A small
// value shows that these responses found little, not that nothing can be found.
#pragma once
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
namespace stats59 {
constexpr const char *CALC_SEAT = "response-5.9-eb-one-sided-v1";
constexpr const char *CALC_SIMULTANEOUS = "response-5.9-simultaneous-union-v1";
constexpr const char *CALC_POOLED = "response-5.9-pooled-bernstein-subsets-v1";
constexpr const char *METHOD_SEAT = "empirical Bernstein, one-sided (Maurer-Pontil 2009, Theorem 4): distribution-free for i.i.d. samples of proven bounded range and a sample count fixed in advance";

// One-sided half-width of (A): P(true mean < sample mean - h) <= delta. Never larger than the range itself.
inline double ebOneSidedHalf(double sampleVariance, double width, double n, double delta) {
  if (!(n >= 2 && width >= 0 && delta > 0 && delta < 1 && sampleVariance >= 0) || !std::isfinite(width) || !std::isfinite(sampleVariance)) return NAN;
  const double L = std::log(2 / delta);
  return std::min(width, std::sqrt(2 * sampleVariance * L / n) + 7 * width * L / (3 * (n - 1)));
}
// Upper confidence bound of the true standard deviation (Maurer-Pontil 2009, Theorem 10): P(s > result) <= delta.
inline double sdUpper(double sampleVariance, double width, double n, double delta) {
  if (!(n >= 2 && width >= 0 && delta > 0 && delta < 1 && sampleVariance >= 0) || !std::isfinite(width) || !std::isfinite(sampleVariance)) return NAN;
  return std::min(width / 2, std::sqrt(sampleVariance) + width * std::sqrt(2 * std::log(1 / delta) / (n - 1)));   // a variable of range W has standard deviation <= W / 2 (Popoviciu)
}

// One seat's evaluation as the summary needs it. `available`: the evaluation completed with its planned sample count.
// `within`: every sample lay inside the proven range (a violation withdraws every calibrated statement).
struct Seat { int seat = -1; bool available = false, within = false; double mean = NAN, variance = NAN, n = 0, width = NAN; };

struct SeatBound { int seat = -1; bool available = false; double delta = NAN, half = NAN, lower = NAN, floored = 0; };
struct Simultaneous {
  bool calibrated = false, complete = false; std::string reason;   // reason: why no calibrated statement is made ("" when calibrated)
  double alpha = NAN, alphaPerAnalysis = NAN; int analyses = 1, family = 0, evaluated = 0;
  std::vector<SeatBound> seats;
  double sumOfGainsLower = NAN;      // lower bound of sum_{i in F} gain_i(R_i); NAN unless every seat of the family was evaluated
  double bestResponseSumLower = NAN; // lower bound of sum_{i in F} b_i, hence of NashConv: sum of max(0, L_i), 0 for a seat without evaluation
};
// (B). alpha: the familywise error probability (1 - confidence). analyses: number of prespecified response analyses
// among which the largest bound will be reported (>= 1).
inline Simultaneous simultaneous(const std::vector<Seat> &S, double alpha, int analyses = 1) {
  Simultaneous r; r.alpha = alpha; r.analyses = analyses; r.family = (int)S.size();
  if (S.empty()) { r.reason = "noSeats"; return r; }
  if (!(alpha > 0 && alpha < 1) || analyses < 1) { r.reason = "badLevel"; return r; }
  r.alphaPerAnalysis = alpha / analyses; const double delta = r.alphaPerAnalysis / (double)S.size();
  double sum = 0, floored = 0; bool all = true;
  for (const Seat &s : S) {
    SeatBound b; b.seat = s.seat; b.delta = delta; b.available = s.available;
    if (s.available) {
      if (!s.within) { r.reason = "payoffBoundViolated"; r.seats.clear(); return r; }
      b.half = ebOneSidedHalf(s.variance, s.width, s.n, delta);
      if (!std::isfinite(b.half) || !std::isfinite(s.mean)) { r.reason = s.n >= 2 ? "evaluationErrorUnavailable" : "tooFewSamples"; r.seats.clear(); return r; }
      b.lower = s.mean - b.half; b.floored = std::max(0.0, b.lower); sum += b.lower; floored += b.floored; r.evaluated++;
    } else all = false;
    r.seats.push_back(b);
  }
  r.calibrated = true; r.complete = all; r.bestResponseSumLower = floored; if (all) r.sumOfGainsLower = sum;
  return r;
}

struct Pooled {
  bool calibrated = false, complete = false; std::string reason;
  double alpha = NAN, alphaPerAnalysis = NAN, deltaBernstein = NAN, deltaVariance = NAN; int analyses = 1, family = 0, evaluated = 0; long long subsets = 0;
  double allSeatsLower = NAN;        // lower bound of sum_{i in F} gain_i(R_i) (the subset "all seats"); NAN unless every seat was evaluated
  double bestSubsetLower = NAN;      // the largest subset bound (can be negative when every subset bound is)
  double bestResponseSumLower = NAN; // max(0, bestSubsetLower): lower bound of NashConv
  std::vector<int> bestSubset;       // seat numbers of that subset
  std::vector<double> sdUpper;       // per evaluated seat, in the order of the input
};
// (C). Requires mutually independent evaluation samples between the seats (separate random streams) in addition to the
// conditions of (A). At most 16 seats (EightMax has at most 8).
inline Pooled pooledIndependent(const std::vector<Seat> &S, double alpha, int analyses = 1) {
  Pooled r; r.alpha = alpha; r.analyses = analyses; r.family = (int)S.size();
  if (S.empty() || S.size() > 16) { r.reason = S.empty() ? "noSeats" : "tooManySeats"; return r; }
  if (!(alpha > 0 && alpha < 1) || analyses < 1) { r.reason = "badLevel"; return r; }
  const int k = (int)S.size(); r.alphaPerAnalysis = alpha / analyses; r.subsets = (1LL << k) - 1;
  r.deltaVariance = r.alphaPerAnalysis / (2.0 * k); r.deltaBernstein = r.alphaPerAnalysis / (2.0 * (double)r.subsets);
  std::vector<double> v((size_t)k, NAN), scale((size_t)k, NAN); bool all = true;
  for (int i = 0; i < k; i++) {
    const Seat &s = S[(size_t)i];
    if (!s.available) { all = false; continue; }
    if (!s.within) { r.reason = "payoffBoundViolated"; return r; }
    const double sd = sdUpper(s.variance, s.width, s.n, r.deltaVariance);
    if (!std::isfinite(sd) || !std::isfinite(s.mean)) { r.reason = s.n >= 2 ? "evaluationErrorUnavailable" : "tooFewSamples"; return r; }
    v[(size_t)i] = sd * sd / s.n; scale[(size_t)i] = s.width / s.n; r.sdUpper.push_back(sd); r.evaluated++;
  }
  if (!r.evaluated) { r.calibrated = true; r.complete = false; r.bestResponseSumLower = 0; return r; }   // nothing evaluated: only the trivial bound
  const double L1 = std::log(1 / r.deltaBernstein); double best = -INFINITY; unsigned bestMask = 0;
  for (unsigned mask = 1; mask < (1u << k); mask++) {
    double mean = 0, var = 0, b = 0; bool ok = true;
    for (int i = 0; i < k && ok; i++) if (mask >> i & 1) { if (!S[(size_t)i].available) ok = false; else { mean += S[(size_t)i].mean; var += v[(size_t)i]; b = std::max(b, scale[(size_t)i]); } }
    if (!ok) continue;
    const double lower = mean - std::sqrt(2 * L1 * var) - b * L1 / 3;
    if (lower > best) { best = lower; bestMask = mask; }
    if (mask == (1u << k) - 1) r.allSeatsLower = lower;
  }
  r.calibrated = true; r.complete = all; r.bestSubsetLower = best; r.bestResponseSumLower = std::max(0.0, best);
  for (int i = 0; i < k; i++) if (bestMask >> i & 1) r.bestSubset.push_back(S[(size_t)i].seat);
  return r;
}
inline const char *reasonText(const std::string &code) {
  if (code.empty()) return "";
  if (code == "payoffBoundViolated") return "an evaluated sample lay outside the proven payoff bound; every distribution-free statement is withdrawn";
  if (code == "tooFewSamples") return "fewer than two evaluation samples";
  if (code == "evaluationErrorUnavailable") return "an evaluation mean or variance is unavailable";
  if (code == "noSeats") return "no seat was requested";
  if (code == "badLevel") return "the confidence level or the number of analyses is out of range";
  if (code == "tooManySeats") return "more than 16 seats";
  return "no calibrated statement is available";
}

// ---- exact coverage on two-point distributions (used by the self-test and by tools/independent_stats59.py) ----
// For samples that take the value `width` with probability p and 0 otherwise, the sample mean and variance are functions
// of the number K of large samples, K ~ Binomial(n, p). The probability that a lower bound EXCEEDS the true mean p*width
// is therefore a finite sum of binomial probabilities: no simulation, no sampling error.
//   kind 0: the one-sided empirical-Bernstein bound (A) at level delta
//   kind 1: the 5.8 normal-approximation bound, mean - z * SE with z = 1.6448536269514722 (one-sided 95%)
inline double twoPointMiss(long long n, double p, double delta, int kind) {
  if (n < 2 || !(p > 0 && p < 1)) return NAN;
  const double N = (double)n, truth = p; double miss = 0;
  const double lp = std::log(p), lq = std::log1p(-p);
  // Bounds are monotone in K only piecewise, so every K with non-negligible probability is examined: K within
  // 60 standard deviations of the mean (the remaining mass is below 1e-300) and K = 0.
  const double mu = N * p, sd = std::sqrt(N * p * (1 - p));
  const long long lo = (long long)std::max(0.0, std::floor(mu - 60 * sd - 60)), hi = (long long)std::min(N, std::ceil(mu + 60 * sd + 60));
  for (long long K = lo; K <= hi; K++) {
    const double k = (double)K, mean = k / N, var = k * (N - k) / (N * (N - 1));   // unbiased sample variance of K ones and n-K zeros (width 1)
    const double lower = kind == 0 ? mean - ebOneSidedHalf(var, 1.0, N, delta) : mean - 1.6448536269514722 * std::sqrt(var / N);
    if (lower > truth) miss += std::exp(std::lgamma(N + 1) - std::lgamma(k + 1) - std::lgamma(N - k + 1) + k * lp + (N - k) * lq);
  }
  return miss;
}
}
