// EightMax 5.2: decision studies in the desktop host (routes under /api/study/).
// A study owns its own engines (study52.hpp creates and frees them); it never touches the study that is open
// in the Multiway tab. One study runs at a time, on a background thread.
//   POST /api/study/start   {"fixture": <EightMax study fixture>, "options": {variants?, seeds?, budgets?, threads?, memoryMiB?, timeLimitSeconds?}}
//   GET  /api/study/status  {running, hasResult, error, progress, elapsedSeconds, stopRequested}
//   GET  /api/study/result  the "EightMax study result" document of the last finished study (404 if none)
//   POST /api/study/stop    asks the running study to stop; the measurements completed so far are reported
// 5.5: automatic study checkpoints and resumption without the command line.
//   Every desktop study is checkpointed into <Documents>/EightMax/studies/<checkpointId>/ (study_checkpoint55.hpp) and
//   its request (fixture and options) is stored beside the manifest as request.json, so an interrupted study can be
//   resumed after the application was closed or the process was killed.
//   POST /api/study/start        also accepts "checkpointId" (letters, digits, '-', '_', 1-80) and "checkpoint": false
//   GET  /api/study/checkpoints  [{id, status, fixtureId, title, pointsCompleted, pointsRequested, savedAtUnixSeconds,
//                                 elapsedSeconds, resumable, hasRequest}] newest first
//   POST /api/study/resume       {"checkpointId": id, "options": {threads?, timeLimitSeconds?, processMemoryMiB?}}
//   POST /api/study/discard      {"checkpointId": id}  deletes that checkpoint folder (never the running one)
// 5.9: a study that the engine REFUSES (an unsupported budget, an invalid configuration) no longer leaves a folder.
//   Through 5.8 the host created <studies>/<id>/ and wrote request.json before the engine had seen the request; a
//   refusal left that folder behind, unlisted, holding only request.json (FINAL-REPORT-5.8.md). Now:
//   - the folder is created only after the request passed the host's own checks (another study running, an existing
//     checkpoint with that id), under the study mutex, and the host remembers whether THIS request created the
//     folder and whether it created request.json;
//   - when the study ends with an error, and likewise when the request cannot be stored or the study thread cannot
//     be started, study_undo_refused() removes what this request created - and only that: request.json if this
//     request created it, then the folder if this request created it AND it is now empty. Nothing at all is removed
//     when the folder holds a manifest (a checkpoint exists), or when a folder this request created holds anything
//     but request.json (something unexpected is there). No folder is ever removed recursively;
//   - a folder that existed before the request is never removed and the files in it are never touched, except the
//     request.json this request itself wrote into it; a request.json that existed before is kept;
//   - the undo runs under the study mutex while the study still counts as running, so no other study request, list
//     or discard can run beside it;
//   - a removal that fails (a read-only folder, a file held open) leaves the files and is reported:
//     GET /api/study/status gains "refusedStudyFolder": null | "removed" | "kept: <reason>". The refusal message in
//     "error" is unchanged.
#ifndef EM_STUDY_JOBS_H
#define EM_STUDY_JOBS_H
static pthread_mutex_t STUDY_MU = PTHREAD_MUTEX_INITIALIZER;
static volatile int STUDY_RUNNING = 0, STUDY_STOP = 0;
static char *STUDY_RESULT = NULL; static size_t STUDY_RESULT_LEN = 0;
static char STUDY_ERR[768], *STUDY_PROGRESS = NULL; static double STUDY_T0 = 0, STUDY_ELAPSED = 0;
static char STUDY_CKPT_ID[96] = "";   /* checkpoint of the running or last study ("" when it had none) */
static int study_id_ok(const char *id) { size_t n = id ? strlen(id) : 0; if (n < 1 || n > 80) return 0; for (size_t i = 0; i < n; i++) { const char c = id[i]; if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_')) return 0; } return 1; }
static void study_root(char *out, size_t n) {
#ifdef _WIN32
  snprintf(out, n, "%s\\studies", SAVE_DIR);
#else
  snprintf(out, n, "%s/studies", SAVE_DIR);
#endif
}
static void study_dir(char *out, size_t n, const char *id) {
  char root[1100]; study_root(root, sizeof root);
#ifdef _WIN32
  snprintf(out, n, "%s\\%s", root, id);
#else
  snprintf(out, n, "%s/%s", root, id);
#endif
}
static char *study_slurp(const char *path, size_t *len) {
  FILE *f = fopen(path, "rb"); if (!f) return NULL; char *buf = NULL; size_t n = 0, cap = 0;
  for (;;) { if (n + 65536 + 1 > cap) { cap = cap ? cap * 2 : 131072; char *nb = (char *)realloc(buf, cap); if (!nb) { free(buf); fclose(f); return NULL; } buf = nb; } size_t r = fread(buf + n, 1, 65536, f); n += r; if (r < 65536) break; }
  fclose(f); buf[n] = 0; if (len) *len = n; return buf;
}
static int study_write_file(const char *path, const char *data, size_t n) {   /* temporary sibling, then rename */
  char tmp[1500]; snprintf(tmp, sizeof tmp, "%s.tmp", path); FILE *f = fopen(tmp, "wb"); if (!f) return 0;
  const int ok = fwrite(data, 1, n, f) == n; if (fclose(f)) { remove(tmp); return 0; } if (!ok) { remove(tmp); return 0; }
  remove(path); if (rename(tmp, path)) { remove(tmp); return 0; } return 1;
}
/* One checkpoint folder as a JSON object (appended to b). Returns 0 if the folder holds no readable manifest. */
static int study_describe(JB *b, const char *id) {
  char dir[1300], file[1500]; study_dir(dir, sizeof dir, id); size_t len = 0; char *text = NULL; int usedPrev = 0;
  snprintf(file, sizeof file, "%s/manifest.json", dir); text = study_slurp(file, &len);
  char err[128] = ""; JV *v = text ? json_parse(text, len, err, sizeof err) : NULL;
  if (!v) { free(text); snprintf(file, sizeof file, "%s/manifest.prev.json", dir); text = study_slurp(file, &len); v = text ? json_parse(text, len, err, sizeof err) : NULL; usedPrev = 1; }
  if (!v) { free(text); return 0; }
  const JV *body = jget(v, "body"), *plan = body ? jget(body, "plan") : NULL, *jobs = body ? jget(body, "jobs") : NULL;
  if (!body || body->type != J_OBJ || !jobs || jobs->type != J_ARR) { json_free(v); free(text); return 0; }
  double done = 0, budgets = plan && jget(plan, "budgetsDeals") && jget(plan, "budgetsDeals")->type == J_ARR ? jget(plan, "budgetsDeals")->n : 0; int states = 0;
  for (int i = 0; i < jobs->n; i++) { const JV *pts = jget(jobs->items[i], "points"), *st = jget(jobs->items[i], "state"); if (pts && pts->type == J_ARR) done += pts->n; if (st && st->type == J_OBJ) states++; }
  snprintf(file, sizeof file, "%s/request.json", dir); FILE *rq = fopen(file, "rb"); const int hasRequest = rq != NULL; if (rq) fclose(rq);
  const char *status = jstr(jget(body, "status")); const int complete = status && !strcmp(status, "complete");
  jb_puts(b, "{\"id\":"); jb_str(b, id); jb_puts(b, ",\"status\":"); jb_str(b, status ? status : "unknown"); jb_puts(b, ",\"statusReason\":"); jb_str(b, jstr(jget(body, "statusReason")) ? jstr(jget(body, "statusReason")) : "");
  jb_puts(b, ",\"fixtureId\":"); jb_str(b, plan && jstr(jget(plan, "fixtureId")) ? jstr(jget(plan, "fixtureId")) : ""); jb_puts(b, ",\"preset\":"); jb_str(b, plan && jstr(jget(plan, "preset")) ? jstr(jget(plan, "preset")) : "");
  jb_printf(b, ",\"pointsCompleted\":%.0f,\"pointsRequested\":%.0f,\"seedsWithEngineState\":%d,\"savedAtUnixSeconds\":%.0f,\"elapsedSeconds\":", done, (double)jobs->n * budgets, states, jnum(jget(body, "savedAtUnixSeconds"), 0));
  jb_num(b, jnum(jget(body, "elapsedSeconds"), 0), 3); jb_printf(b, ",\"commits\":%.0f,\"resumeCount\":%.0f", jnum(jget(body, "sequence"), 0), jnum(jget(body, "resumeCount"), 0));
  jb_puts(b, ",\"build\":"); jb_str(b, jstr(jget(body, "build")) ? jstr(jget(body, "build")) : "");
  jb_printf(b, ",\"sameBuild\":%s,\"readFromPreviousManifest\":%s,\"hasRequest\":%s,\"complete\":%s,\"resumable\":%s}", jstr(jget(body, "build")) && !strcmp(jstr(jget(body, "build")), EM_BUILD_ID) ? "true" : "false", usedPrev ? "true" : "false", hasRequest ? "true" : "false", complete ? "true" : "false",
            hasRequest && !complete && jstr(jget(body, "build")) && !strcmp(jstr(jget(body, "build")), EM_BUILD_ID) ? "true" : "false");
  json_free(v); free(text); return 1;
}
typedef struct { char id[96]; double t; } StudyEntry;
static int study_entry_cmp(const void *a, const void *b) { const double x = ((const StudyEntry *)a)->t, y = ((const StudyEntry *)b)->t; return x < y ? 1 : x > y ? -1 : strcmp(((const StudyEntry *)a)->id, ((const StudyEntry *)b)->id); }
static int study_list(StudyEntry *out, int cap) {
  char root[1100]; study_root(root, sizeof root); int n = 0;
#ifdef _WIN32
  char pat[1200]; snprintf(pat, sizeof pat, "%s\\*", root); WIN32_FIND_DATAA fd; HANDLE h = FindFirstFileA(pat, &fd);
  if (h != INVALID_HANDLE_VALUE) { do { if ((fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && study_id_ok(fd.cFileName) && n < cap) { ULARGE_INTEGER ft; ft.LowPart = fd.ftLastWriteTime.dwLowDateTime; ft.HighPart = fd.ftLastWriteTime.dwHighDateTime; snprintf(out[n].id, sizeof out[n].id, "%s", fd.cFileName); out[n].t = (double)(ft.QuadPart / 10000000ULL) - 11644473600.0; n++; } } while (FindNextFileA(h, &fd)); FindClose(h); }
#else
  DIR *d = opendir(root); if (d) { struct dirent *e; while ((e = readdir(d))) { if (!study_id_ok(e->d_name) || n >= cap) continue; char full[1500]; snprintf(full, sizeof full, "%s/%s/manifest.json", root, e->d_name); struct stat stt; if (stat(full, &stt)) { snprintf(full, sizeof full, "%s/%s", root, e->d_name); if (stat(full, &stt) || !S_ISDIR(stt.st_mode)) continue; } snprintf(out[n].id, sizeof out[n].id, "%s", e->d_name); out[n].t = (double)stt.st_mtime; n++; } closedir(d); }
#endif
  qsort(out, (size_t)n, sizeof *out, study_entry_cmp); return n;
}
static int study_discard(const char *id) {   /* removes the files this application writes there, then the folder */
  char dir[1300]; study_dir(dir, sizeof dir, id); int left = 0;
#ifdef _WIN32
  char pat[1400]; snprintf(pat, sizeof pat, "%s\\*", dir); WIN32_FIND_DATAA fd; HANDLE h = FindFirstFileA(pat, &fd);
  if (h != INVALID_HANDLE_VALUE) { do { if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue; char full[1700]; snprintf(full, sizeof full, "%s\\%s", dir, fd.cFileName); if (remove(full)) left++; } while (FindNextFileA(h, &fd)); FindClose(h); }
  return !left && _rmdir(dir) == 0;
#else
  DIR *d = opendir(dir); if (!d) return 0; struct dirent *e;
  while ((e = readdir(d))) { if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue; char full[1700]; snprintf(full, sizeof full, "%s/%s", dir, e->d_name); if (remove(full)) left++; }
  closedir(d); return !left && rmdir(dir) == 0;
#endif
}
/* 5.9: what the last refused study left of its folder (see the header): "" none, else "removed" or "kept: ...". */
static char STUDY_REFUSED_FOLDER[400] = "";
/* 1: this call created the directory. 0: it already existed. -1: it could not be created. */
static int study_make_dir(const char *d) {
#ifdef _WIN32
  if (CreateDirectoryA(d, NULL)) return 1;
  return GetLastError() == ERROR_ALREADY_EXISTS ? 0 : -1;
#else
  if (!mkdir(d, 0755)) return 1;
  if (errno != EEXIST) return -1;
  struct stat st; return !stat(d, &st) && S_ISDIR(st.st_mode) ? 0 : -1;
#endif
}
static int study_file_exists(const char *path) { FILE *f = fopen(path, "rb"); if (!f) return 0; fclose(f); return 1; }
/* Number of entries of a directory other than "." and "..", or -1 when it cannot be read. `only`, if not NULL,
   receives 1 when every entry is named `name` (an empty directory counts). */
static int study_count_entries(const char *dir, const char *name, int *only) {
  int n = 0, same = 1;
#ifdef _WIN32
  char pat[1400]; snprintf(pat, sizeof pat, "%s\\*", dir); WIN32_FIND_DATAA fd; HANDLE h = FindFirstFileA(pat, &fd); if (h == INVALID_HANDLE_VALUE) return -1;
  do { if (!strcmp(fd.cFileName, ".") || !strcmp(fd.cFileName, "..")) continue; n++; if (!name || _stricmp(fd.cFileName, name)) same = 0; } while (FindNextFileA(h, &fd)); FindClose(h);
#else
  DIR *d = opendir(dir); if (!d) return -1; struct dirent *e;
  while ((e = readdir(d))) { if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue; n++; if (!name || strcmp(e->d_name, name)) same = 0; }
  closedir(d);
#endif
  if (only) *only = same; return n;
}
/* Undoes what a refused study request created, and only that. Called with STUDY_MU held; writes the outcome to
   STUDY_REFUSED_FOLDER. The rules, in order:
     1. nothing of this request to undo (it created neither the folder nor request.json): nothing is touched;
     2. the folder holds a manifest: a checkpoint exists there, nothing is touched;
     3. this request created the folder and the folder holds anything but request.json: something unexpected is
        there, nothing is touched;
     4. request.json is removed if this request created it;
     5. the folder is removed if this request created it and it is now empty (rmdir removes only an empty folder).
   EIGHTMAX_TEST_UNDO_FAILS=1 makes every removal fail (tests of the failure report; never set in normal use). */
static void study_undo_refused(const char *dir, int createdDir, int createdRequest) {
  STUDY_REFUSED_FOLDER[0] = 0;
  if (!dir || !dir[0] || (!createdDir && !createdRequest)) return;
  const char *sim = getenv("EIGHTMAX_TEST_UNDO_FAILS"); const int failing = sim && *sim && *sim != '0';
  char file[1500]; int only = 0;
  snprintf(file, sizeof file, "%s/manifest.json", dir); const int manifest = study_file_exists(file); snprintf(file, sizeof file, "%s/manifest.prev.json", dir);
  if (manifest || study_file_exists(file)) { snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, "kept: the folder holds a study checkpoint; nothing was removed"); return; }
  const int entries = study_count_entries(dir, "request.json", &only);
  if (entries < 0) { snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, "kept: the folder could not be read"); return; }
  if (createdDir && !only) { snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, "kept: the folder holds other files (%d entries); nothing was removed", entries); return; }
  snprintf(file, sizeof file, "%s/request.json", dir);
  if (createdRequest && study_file_exists(file)) {
    if (failing || remove(file)) { snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, "kept: request.json could not be removed (%s)", failing ? "simulated failure" : strerror(errno)); return; }
  }
  if (!createdDir) { snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, createdRequest ? "kept: the folder existed before this request; the request written into it was removed" : "kept: the folder and its request.json existed before this request"); return; }
  if (!createdRequest && entries) { snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, "kept: request.json was there before this request"); return; }
#ifdef _WIN32
  if (failing || _rmdir(dir)) { snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, "kept: the empty folder could not be removed (%s)", failing ? "simulated failure" : strerror(errno)); return; }
#else
  if (failing || rmdir(dir)) { snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, "kept: the empty folder could not be removed (%s)", failing ? "simulated failure" : strerror(errno)); return; }
#endif
  snprintf(STUDY_REFUSED_FOLDER, sizeof STUDY_REFUSED_FOLDER, "removed");
}
typedef struct { char *fixture; size_t flen; char *options; size_t olen; char dir[1300]; int createdDir, createdRequest; } StudyArgs;
static void study_jv_write(JB *o, const JV *v) {
  if (!v || v->type == J_NULL) { jb_puts(o, "null"); return; }
  if (v->type == J_BOOL) { jb_puts(o, v->num != 0 ? "true" : "false"); return; }
  if (v->type == J_NUM) { jb_printf(o, "%.17g", v->num); return; }
  if (v->type == J_STR) { jb_str(o, v->str); return; }
  jb_putc(o, v->type == J_ARR ? '[' : '{');
  for (int i = 0; i < v->n; i++) { if (i) jb_putc(o, ','); if (v->type == J_OBJ) { jb_str(o, v->keys[i]); jb_putc(o, ':'); } study_jv_write(o, v->items[i]); }
  jb_putc(o, v->type == J_ARR ? ']' : '}');
}
static void study_progress(void *ctx, const char *json) {
  (void)ctx;
  // Publish an entire JSON document atomically. Truncation corrupts /status.
  // On allocation failure retain the previous complete progress snapshot.
  const size_t n = strlen(json); char *next = (char *)malloc(n + 1);
  if (next) memcpy(next, json, n + 1);
  pthread_mutex_lock(&STUDY_MU);
  if (next) { free(STUDY_PROGRESS); STUDY_PROGRESS = next; }
  STUDY_ELAPSED = now_s() - STUDY_T0;
  pthread_mutex_unlock(&STUDY_MU);
}
static void *study_job(void *a) {
  pthread_mutex_lock(&STUDY_MU); pthread_mutex_unlock(&STUDY_MU);   // wait until the starter has published the job
  StudyArgs *A = (StudyArgs *)a; JB out; jb_init(&out); char err[768] = "";
  const int st = mw_study_run(A->fixture, A->flen, A->options, A->olen, &out, err, sizeof err, &STUDY_STOP, study_progress, NULL);
  pthread_mutex_lock(&STUDY_MU);
  if (st == 200 && !out.failed) { free(STUDY_RESULT); STUDY_RESULT = out.s; STUDY_RESULT_LEN = out.n; out.s = NULL; STUDY_ERR[0] = 0; }
  else {
    snprintf(STUDY_ERR, sizeof STUDY_ERR, "%s", err[0] ? err : "The study failed");
    /* 5.9: a study that ended with an error before it committed anything leaves no folder (see the header). The
       study still counts as running here, so no other request can touch the folder meanwhile. */
    study_undo_refused(A->dir, A->createdDir, A->createdRequest);
    if (!strcmp(STUDY_REFUSED_FOLDER, "removed")) STUDY_CKPT_ID[0] = 0;   /* that checkpoint id names nothing any more */
  }
  STUDY_ELAPSED = now_s() - STUDY_T0; STUDY_RUNNING = 0;
  pthread_mutex_unlock(&STUDY_MU);
  jb_free(&out); free(A->fixture); free(A->options); free(A);
  return NULL;
}
// Returns 1 when the route was handled.
static int study_api(sock_t s, const char *method, const char *path, const char *body, size_t blen) {
  if (strncmp(path, "/api/study/", 11)) return 0;
  const char *r = path + 11; const int post = !strcmp(method, "POST");
  if (!strcmp(r, "status") && !post) {
    JB b; jb_init(&b); pthread_mutex_lock(&STUDY_MU);
    jb_printf(&b, "{\"running\":%s,\"hasResult\":%s,\"stopRequested\":%s,\"elapsedSeconds\":", STUDY_RUNNING ? "true" : "false", STUDY_RESULT ? "true" : "false", STUDY_STOP ? "true" : "false");
    jb_num(&b, STUDY_RUNNING ? now_s() - STUDY_T0 : STUDY_ELAPSED, 3); jb_puts(&b, ",\"error\":"); if (STUDY_ERR[0]) jb_str(&b, STUDY_ERR); else jb_puts(&b, "null");
    jb_puts(&b, ",\"checkpointId\":"); if (STUDY_CKPT_ID[0]) jb_str(&b, STUDY_CKPT_ID); else jb_puts(&b, "null");
    jb_puts(&b, ",\"refusedStudyFolder\":"); if (STUDY_REFUSED_FOLDER[0]) jb_str(&b, STUDY_REFUSED_FOLDER); else jb_puts(&b, "null");   /* 5.9 */
    jb_puts(&b, ",\"progress\":"); jb_puts(&b, STUDY_PROGRESS ? STUDY_PROGRESS : "null"); jb_putc(&b, '}');
    pthread_mutex_unlock(&STUDY_MU); respond_json(s, 200, &b); jb_free(&b); return 1;
  }
  if (!strcmp(r, "result") && !post) {
    pthread_mutex_lock(&STUDY_MU);
    if (!STUDY_RESULT) { pthread_mutex_unlock(&STUDY_MU); respond_err(s, 404, "No study result yet"); return 1; }
    JB b; jb_init(&b); jb_putn(&b, STUDY_RESULT, STUDY_RESULT_LEN); pthread_mutex_unlock(&STUDY_MU);
    respond_json(s, 200, &b); jb_free(&b); return 1;
  }
  if (!strcmp(r, "stop") && post) { __atomic_store_n(&STUDY_STOP, 1, __ATOMIC_RELAXED); respond_ok(s); return 1; }
  if (!strcmp(r, "checkpoints") && !post) {
    static StudyEntry list[256]; pthread_mutex_lock(&STUDY_MU); const int n = study_list(list, 256);
    JB b; jb_init(&b); jb_puts(&b, "{\"directory\":"); { char root[1100]; study_root(root, sizeof root); jb_str(&b, root); } jb_puts(&b, ",\"running\":"); if (STUDY_RUNNING && STUDY_CKPT_ID[0]) jb_str(&b, STUDY_CKPT_ID); else jb_puts(&b, "null");
    jb_puts(&b, ",\"checkpoints\":["); int k = 0; for (int i = 0; i < n; i++) { JB one; jb_init(&one); if (study_describe(&one, list[i].id) && !one.failed) { if (k++) jb_putc(&b, ','); jb_putn(&b, one.s, one.n); } jb_free(&one); }
    jb_puts(&b, "]}"); pthread_mutex_unlock(&STUDY_MU); respond_json(s, 200, &b); jb_free(&b); return 1;
  }
  if (!strcmp(r, "discard") && post) {
    char err[256] = ""; JV *v = json_parse(body ? body : "", body ? blen : 0, err, sizeof err); const char *id = v ? jstr(jget(v, "checkpointId")) : NULL;
    if (!id || !study_id_ok(id)) { if (v) json_free(v); respond_err(s, 400, "checkpointId must be 1 to 80 letters, digits, '-' or '_'"); return 1; }
    pthread_mutex_lock(&STUDY_MU); const int busy = STUDY_RUNNING && !strcmp(STUDY_CKPT_ID, id); const int ok = !busy && study_discard(id); pthread_mutex_unlock(&STUDY_MU); json_free(v);
    if (busy) respond_err(s, 409, "That study is running; stop it before discarding its checkpoint"); else if (!ok) respond_err(s, 404, "The checkpoint folder could not be removed (missing, or it holds files this application did not write)"); else respond_ok(s);
    return 1;
  }
  const int resume = !strcmp(r, "resume") && post;
  if ((!strcmp(r, "start") && post) || resume) {
    char err[512] = ""; JV *v = json_parse(body ? body : "", body ? blen : 0, err, sizeof err);
    if (!v || v->type != J_OBJ) { if (v) json_free(v); respond_err(s, 400, err[0] ? err : "The request must be a JSON object"); return 1; }
    char id[96] = "", dir[1300] = "", reqPath[1500] = ""; JV *stored = NULL; char *storedText = NULL;
    const JV *fx = jget(v, "fixture"), *op = jget(v, "options"), *over = NULL; const char *given = jstr(jget(v, "checkpointId"));
    const JV *cko = jget(v, "checkpoint"); const int useCk = resume || !(cko && cko->type == J_BOOL && cko->num == 0);
    if (given && !study_id_ok(given)) { json_free(v); respond_err(s, 400, "checkpointId must be 1 to 80 letters, digits, '-' or '_'"); return 1; }
    if (resume) {
      if (!given) { json_free(v); respond_err(s, 400, "checkpointId is required"); return 1; }
      snprintf(id, sizeof id, "%s", given); study_dir(dir, sizeof dir, id); snprintf(reqPath, sizeof reqPath, "%s/request.json", dir);
      size_t len = 0; storedText = study_slurp(reqPath, &len); stored = storedText ? json_parse(storedText, len, err, sizeof err) : NULL;
      if (!stored || stored->type != J_OBJ || !jget(stored, "fixture")) { if (stored) json_free(stored); free(storedText); json_free(v); respond_err(s, 404, "That checkpoint has no stored study request (request.json); it cannot be resumed from the desktop"); return 1; }
      over = op; fx = jget(stored, "fixture"); op = jget(stored, "options");
    }
    if (!fx || fx->type != J_OBJ || (op && op->type != J_OBJ) || (over && over->type != J_OBJ)) { if (stored) json_free(stored); free(storedText); json_free(v); respond_err(s, 400, "fixture must be an object and options, if present, an object"); return 1; }
    if (useCk && !resume) {
      if (given) snprintf(id, sizeof id, "%s", given);
      else { const char *fid = jstr(jget(fx, "id")); char clean[48]; size_t k = 0; for (const char *c = fid ? fid : "study"; *c && k < sizeof clean - 1; c++) clean[k++] = ((*c >= 'a' && *c <= 'z') || (*c >= 'A' && *c <= 'Z') || (*c >= '0' && *c <= '9') || *c == '-' || *c == '_') ? *c : '_'; clean[k] = 0; snprintf(id, sizeof id, "%s-%.0f", k ? clean : "study", now_s() * 1000.0); }
      study_dir(dir, sizeof dir, id); snprintf(reqPath, sizeof reqPath, "%s/request.json", dir);   /* 5.9: the folder itself is created below, once the request is accepted */
    }
    /* options handed to the engine: the caller's (or the stored ones, with a few session overrides on resume) plus the checkpoint */
    JB f, o; jb_init(&f); jb_init(&o); study_jv_write(&f, fx); jb_putc(&o, '{'); int first = 1;
    for (int i = 0; op && i < op->n; i++) { const char *key = op->keys[i]; if (!strcmp(key, "checkpoint") || !strcmp(key, "resume") || !strcmp(key, "replaceCheckpoint")) continue;
      const JV *val = op->items[i]; if (over && (!strcmp(key, "threads") || !strcmp(key, "timeLimitSeconds") || !strcmp(key, "processMemoryMiB") || !strcmp(key, "evaluationMemoryMiB") || !strcmp(key, "parallelSeeds") || !strcmp(key, "checkpointSeconds")) && jget(over, key)) continue;
      if (!first) jb_putc(&o, ','); first = 0; jb_str(&o, key); jb_putc(&o, ':'); study_jv_write(&o, val); }
    for (int i = 0; over && i < over->n; i++) { const char *key = over->keys[i]; if (strcmp(key, "threads") && strcmp(key, "timeLimitSeconds") && strcmp(key, "processMemoryMiB") && strcmp(key, "evaluationMemoryMiB") && strcmp(key, "parallelSeeds") && strcmp(key, "checkpointSeconds")) continue;
      if (!first) jb_putc(&o, ','); first = 0; jb_str(&o, key); jb_putc(&o, ':'); study_jv_write(&o, over->items[i]); }
    JB plain; jb_init(&plain); jb_putn(&plain, o.s, o.n); jb_putc(&plain, '}');   /* the request as stored: no directory, no resume flag */
    if (useCk) { if (!first) jb_putc(&o, ','); jb_puts(&o, "\"checkpoint\":"); jb_str(&o, dir); jb_printf(&o, ",\"resume\":%s", resume ? "true" : "false"); }
    jb_putc(&o, '}');
    StudyArgs *A = (StudyArgs *)calloc(1, sizeof *A);
    if (!A || f.failed || o.failed || plain.failed) { free(A); jb_free(&f); jb_free(&o); jb_free(&plain); if (stored) json_free(stored); free(storedText); json_free(v); respond_err(s, 503, "Out of memory"); return 1; }
    A->fixture = f.s; A->flen = f.n; A->options = o.s; A->olen = o.n;
    if (useCk && !resume) snprintf(A->dir, sizeof A->dir, "%s", dir);   /* 5.9: a resumed study never has its folder undone */
    pthread_mutex_lock(&STUDY_MU);
    if (STUDY_RUNNING) { pthread_mutex_unlock(&STUDY_MU); free(A->fixture); free(A->options); free(A); jb_free(&plain); if (stored) json_free(stored); free(storedText); json_free(v); respond_err(s, 409, "A study is already running; stop it first"); return 1; }
    if (useCk && !resume) {   /* never overwrite an existing checkpoint: a fresh id is required */
      char man[1500]; snprintf(man, sizeof man, "%s/manifest.json", dir); FILE *ex = fopen(man, "rb");
      if (ex) { fclose(ex); pthread_mutex_unlock(&STUDY_MU); free(A->fixture); free(A->options); free(A); jb_free(&plain); json_free(v); respond_err(s, 409, "A study checkpoint with that id already exists; resume it or choose another id"); return 1; }
      /* 5.9: only now, with no study running and no checkpoint of that id, is anything created; what is created is
         remembered so that a refusal can undo exactly that. */
      { char root[1100]; study_root(root, sizeof root); ensure_dir(root); }
      A->createdDir = study_make_dir(dir) == 1; A->createdRequest = !study_file_exists(reqPath);
      JB rq; jb_init(&rq); jb_puts(&rq, "{\"format\":\"EightMax study request\",\"formatVersion\":1,\"fixture\":"); jb_putn(&rq, A->fixture, A->flen); jb_puts(&rq, ",\"options\":"); jb_putn(&rq, plain.s, plain.n); jb_putc(&rq, '}');
      const int wrote = !rq.failed && study_write_file(reqPath, rq.s, rq.n); jb_free(&rq);
      if (!wrote) { study_undo_refused(A->dir, A->createdDir, A->createdRequest); pthread_mutex_unlock(&STUDY_MU); free(A->fixture); free(A->options); free(A); jb_free(&plain); json_free(v); respond_err(s, 500, "The study request could not be stored in the checkpoint folder"); return 1; }
    }
    jb_free(&plain);
    if (launch_thread(study_job, A, 16 << 20)) { study_undo_refused(A->dir, A->createdDir, A->createdRequest); pthread_mutex_unlock(&STUDY_MU); free(A->fixture); free(A->options); free(A); if (stored) json_free(stored); free(storedText); json_free(v); respond_err(s, 503, "Could not start a study thread"); return 1; }
    __atomic_store_n(&STUDY_STOP, 0, __ATOMIC_RELAXED); STUDY_RUNNING = 1; STUDY_ERR[0] = 0; STUDY_REFUSED_FOLDER[0] = 0; free(STUDY_PROGRESS); STUDY_PROGRESS = NULL; STUDY_T0 = now_s(); STUDY_ELAPSED = 0;
    snprintf(STUDY_CKPT_ID, sizeof STUDY_CKPT_ID, "%s", useCk ? id : "");
    pthread_mutex_unlock(&STUDY_MU);
    if (stored) json_free(stored); free(storedText); json_free(v);
    JB ok; jb_init(&ok); jb_puts(&ok, "{\"ok\":true,\"checkpointId\":"); if (useCk) jb_str(&ok, id); else jb_puts(&ok, "null"); jb_printf(&ok, ",\"resumed\":%s}", resume ? "true" : "false"); respond_json(s, 200, &ok); jb_free(&ok); return 1;
  }
  respond_err(s, 404, "Not found"); return 1;
}
#endif
