#!/usr/bin/env python3
"""EightMax 5.13: independent checks of the satellite-field payoff model (native/satfield513.hpp, satfield-5.13-v1).

  independent_satfield513.py check <mwcli> [out.json]      rules A, C and the sum check of validation/5.13/plan.json
  independent_satfield513.py summary <mwcli> [out.json]    rule D: a real stack list against "count x average" (information)

Nothing here shares code with the program. Three independent computations of the Malmuth-Harville probability of
finishing in the top N:
  brute(stacks, N)       exact rational arithmetic: the finishing-set recursion written out (small fields)
  reference(...)         the exponential-race integral by composite Simpson in the variable y = t / (t + scale) with
                         the library exponential and 200,000 or more intervals, checked by halving the step
  monte_carlo(...)       sampled finishing orders (exponential clocks), a sanity check of the mathematics
The program's values come from `mwcli --satfield request.json` (17 significant digits)."""
import sys, json, math, random, subprocess, tempfile, os, time
from fractions import Fraction

def program(cli, seats, table, groups):
    with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f: json.dump({'seats': seats, 'table': table, 'field': groups}, f); name = f.name
    try:
        p = subprocess.run([cli, '--satfield', name], capture_output=True, text=True)
        if p.returncode: raise RuntimeError(p.stderr.strip())
        return json.loads(p.stdout)
    finally: os.unlink(name)

def brute(stacks, N):
    n = len(stacks); S = [Fraction(str(s)) for s in stacks]; total = sum(S); prob = {0: Fraction(1)}; res = [Fraction(0)] * n
    for _ in range(N):
        nxt = {}
        for mask, p in prob.items():
            rem = total - sum(S[i] for i in range(n) if mask >> i & 1)
            for i in range(n):
                if mask >> i & 1: continue
                q = p * S[i] / rem; res[i] += q; nxt[mask | 1 << i] = nxt.get(mask | 1 << i, 0) + q
        prob = nxt
    return [float(x) for x in res]

def reference(table, groups, N):
    """The integrand of P(top N) for each table player in the variable y = t / (t + scale), t = scale y / (1 - y),
    scale = the time by which N field players are expected to have finished. Smooth and bounded on [0, 1); it
    vanishes at y = 1. (A first version of this reference integrated in u = exp(-t/scale); its own two step sizes
    differed by 2e-8, more than the rule allows the PROGRAM, so it was replaced. The program was not changed.)"""
    others = [(s, c) for s, c in groups]; mean = sum(s * c for s, c in others) / sum(c for s, c in others)
    lo, hi = 0.0, 1.0
    f = lambda t: sum(c * (1 - math.exp(-s / mean * t)) for s, c in others)
    while f(hi) < N: hi *= 2
    for _ in range(200): mid = (lo + hi) / 2; lo, hi = (mid, hi) if f(mid) < N else (lo, mid)
    scale = hi; rates = [x / mean for x in table]; n = len(table)
    def integrand(y):
        if y >= 1.0: return [0.0] * n
        t = scale * y / (1 - y); jac = scale / (1 - y) ** 2
        d = [0.0] * N; d[0] = 1.0; top = 0
        for s, c in others:
            miss = math.exp(-s / mean * t); hit = 1 - miss
            if c > 8 and top + c < N:            # c identical indicators at once: convolution with a binomial
                b = [math.comb(c, k) * hit ** k * miss ** (c - k) for k in range(c + 1)]; e = [0.0] * N
                for a in range(top + 1):
                    if d[a]:
                        for k in range(c + 1): e[a + k] += d[a] * b[k]
                d = e; top += c
            else:
                for _ in range(c):
                    up = min(top + 1, N - 1)
                    for k in range(up, 0, -1): d[k] = d[k] * miss + d[k - 1] * hit
                    d[0] *= miss; top = up
        out = []
        for i in range(n):
            e = d[:]; top2 = min(top, N - 1)
            for j in range(n):
                if j == i: continue
                miss = math.exp(-rates[j] * t); hit = 1 - miss; up = min(top2 + 1, N - 1)
                for k in range(up, 0, -1): e[k] = e[k] * miss + e[k - 1] * hit
                e[0] *= miss; top2 = up
            out.append(rates[i] * math.exp(-rates[i] * t) * sum(e) * jac)
        return out
    return integrand, n

def simpson(integrand, n, intervals, a=0.0, b=1.0):
    h = (b - a) / intervals; acc = [0.0] * n
    for k in range(intervals + 1):
        w = 1 if k in (0, intervals) else 4 if k % 2 else 2
        v = integrand(a + k * h)
        for i in range(n): acc[i] += w * v[i]
    return [x * h / 3 for x in acc]

def reference_values(table, groups, N):
    """Composite Simpson on y, refined near both ends (very large and very small stacks put their mass there):
    [0, 1e-3], [1e-3, 1 - 1e-3], [1 - 1e-3, 1]. Returned with the largest change when every step is halved."""
    integrand, n = reference(table, groups, N); cost = sum(c for s, c in groups) * N
    m = 1000 if cost > 400000 else 4000 if cost > 20000 else 40000
    def total(m):
        parts = [simpson(integrand, n, m, 0.0, 1e-3), simpson(integrand, n, 4 * m, 1e-3, 1 - 1e-3), simpson(integrand, n, m, 1 - 1e-3, 1.0)]
        return [sum(p[i] for p in parts) for i in range(n)]
    a = total(m); b = total(m // 2)
    return a, max(abs(x - y) for x, y in zip(a, b)), 6 * m

def monte_carlo(table, groups, N, samples, seed):
    import numpy as np
    rng = np.random.default_rng(seed); stacks = np.array(list(table) + [s for s, c in groups for _ in range(c)], dtype=float); n = len(table); hits = np.zeros(n); done = 0
    while done < samples:
        b = min(20000, samples - done); T = rng.exponential(1.0, size=(b, len(stacks))) / stacks
        kth = np.partition(T, N - 1, axis=1)[:, N - 1]          # the N-th smallest clock: top N are those <= it
        hits += (T[:, :n] <= kth[:, None]).sum(axis=0); done += b
    p = hits / samples; return p.tolist(), [3.29 * math.sqrt(max(x * (1 - x), 1e-12) / samples) for x in p]

def main():
    mode, cli = sys.argv[1], sys.argv[2]; out = sys.argv[3] if len(sys.argv) > 3 else None; t0 = time.time(); R = random.Random(513)
    if mode == 'check':
        rep = {'what': 'independent checks of satfield-5.13-v1 (rules A and C of validation/5.13/plan.json)', 'program': subprocess.run([cli, '--build-id'], capture_output=True, text=True).stdout.strip()}
        # ---- A: exact rational brute force, at most 12 players in all
        worst = 0.0; cases = 0; bad = []
        QUICK = os.environ.get('SATFIELD_QUICK') == '1'   # a short run for the regression suite: rule A on 40 cases, two large fields, one Monte Carlo case
        for it in range(40 if QUICK else 240):
            n = R.randint(1, 5); K = R.randint(2, 12 - n); N = R.randint(1, K - 1)
            table = [round(R.choice([0.4, 2, 7, 15, 30, 80]) * R.uniform(0.5, 1.5), 2) for _ in range(n)]
            field = [round(R.choice([0.6, 5, 12, 25, 50, 120]) * R.uniform(0.3, 2), 2) for _ in range(K)]
            ex = brute(table + field, N)[:n]; got = program(cli, N, table, [[s, 1] for s in field])['values']
            e = max(abs(a - b) for a, b in zip(got, ex)); worst = max(worst, e); cases += 1
            if e > 1e-9: bad.append({'seats': N, 'table': table, 'field': field, 'program': got, 'exact': ex})
        rep['A'] = {'rule': 'at most 1e-9 from exact rational Malmuth-Harville values, at most 12 players in all', 'cases': cases, 'largestDifference': worst, 'above1e-9': len(bad), 'failures': bad[:5], 'passed': not bad and cases >= (40 if QUICK else 200)}
        print('A', cases, 'cases, largest difference', worst, flush=True)
        # ---- C: large fields against the independent quadrature; the sum check; Monte Carlo
        shapes = []
        for K, frac in [(50, 0.02), (50, 0.5), (60, 0.95), (120, 0.1), (120, 0.6), (300, 0.05), (300, 0.33), (300, 0.9), (800, 0.25), (800, 0.7), (2000, 0.1), (2000, 0.5), (5000, 0.02), (5000, 0.3)]:
            N = max(1, min(K - 1, round(K * frac)))
            if K * N > 2000000: N = 2000000 // K
            shapes.append((K, N))
        if QUICK: shapes = [(50, 25), (300, 99)]
        Ccases = []; worstC = 0.0; worstSum = 0.0
        for idx, (K, N) in enumerate(shapes):
            for kind in ('equal', 'geometric', 'extremes'):
                if kind == 'equal': groups = [[25.0, K]]
                elif kind == 'geometric': g = 8; groups = [[round(4.0 * 1.6 ** j, 3), K // g + (1 if j < K % g else 0)] for j in range(g)]
                else: groups = [[0.5, max(1, K // 20)], [20.0, K - max(1, K // 20) - max(1, K // 50)], [400.0, max(1, K // 50)]]
                groups = [x for x in groups if x[1] > 0]
                table = [0.3, 6.0, 22.0, 75.0, 900.0] if kind == 'extremes' else [3.0, 14.0, 25.0, 61.0]
                got = program(cli, N, table, groups); ref, selfErr, m = reference_values(table, groups, N)
                e = max(abs(a - b) for a, b in zip(got['values'], ref)); worstC = max(worstC, e)
                # sum over ALL players equals N: table values plus the field's, the field evaluated group by group through the program
                total = sum(got['values']); 
                for gi, (s, c) in enumerate(groups):
                    rest = [[a, b - (1 if j == gi else 0)] for j, (a, b) in enumerate(groups)]; rest = [x for x in rest if x[1] > 0]
                    v = program(cli, N, table + [s], rest)['values'][-1] if sum(x[1] for x in rest) > N else None
                    if v is None: total = None; break
                    total += c * v
                sumErr = None if total is None else abs(total - N) / N
                if sumErr is not None: worstSum = max(worstSum, sumErr)
                Ccases.append({'fieldPlayers': K, 'seats': N, 'stacks': kind, 'table': table, 'program': got['values'], 'reference': ref, 'difference': e, 'referenceSelfDifference': selfErr, 'referenceIntervals': m, 'nodes': got['nodes'], 'sumOverAllPlayersRelativeError': sumErr})
                print('C', K, N, kind, 'difference', e, 'reference self', selfErr, 'sum', sumErr, flush=True)
        rep['C'] = {'rule': 'at most 1e-8 from an independent quadrature (composite Simpson in y = t/(t+scale), library exponential); all values add up to the seats within 1e-7 relative', 'cases': len(Ccases), 'largestDifference': worstC, 'largestSumError': worstSum,
                    'largestReferenceSelfDifference': max(c['referenceSelfDifference'] for c in Ccases), 'rows': Ccases}
        rep['C']['passed'] = len(Ccases) >= (6 if QUICK else 40) and worstC <= 1e-8 and worstSum <= 1e-7
        mc = []
        for seed, (K, N, table) in enumerate([(40, 9, [5.0, 30.0])] if QUICK else [(40, 9, [5.0, 30.0]), (150, 60, [2.0, 25.0, 90.0]), (400, 40, [10.0, 60.0]), (90, 80, [1.0, 12.0]), (1000, 500, [25.0, 3.0])]):
            groups = [[8.0, K // 3], [25.0, K - 2 * (K // 3)], [70.0, K // 3]]; got = program(cli, N, table, groups)['values']; p, half = monte_carlo(table, groups, N, 200000 if QUICK else 1000000, 5130 + seed)
            mc.append({'fieldPlayers': K, 'seats': N, 'table': table, 'program': got, 'monteCarlo': p, 'halfWidth999': half, 'inside': all(abs(a - b) <= h for a, b, h in zip(got, p, half))}); print('MC', K, N, got, p, flush=True)
        rep['monteCarlo'] = {'rule': '1,000,000 sampled finishing orders; the program value inside the 99.9% interval', 'cases': mc, 'passed': all(c['inside'] for c in mc)}
        rep['seconds'] = round(time.time() - t0, 1); rep['passed'] = rep['A']['passed'] and rep['C']['passed'] and rep['monteCarlo']['passed']
    else:
        # ---- D: what "count x average" costs (information)
        rows = []
        for it in range(36):
            K = R.choice([40, 90, 200, 500]); frac = R.choice([0.1, 0.25, 0.5, 0.8]); N = max(1, min(K - 2, round(K * frac)))
            shape = R.choice(['lognormal-wide', 'lognormal-narrow', 'two-camps'])
            if shape == 'two-camps': field = [R.uniform(3, 9) for _ in range(K // 2)] + [R.uniform(35, 70) for _ in range(K - K // 2)]
            else: sig = 0.9 if shape == 'lognormal-wide' else 0.4; field = [25 * math.exp(R.gauss(0, sig) - sig * sig / 2) for _ in range(K)]
            field = sorted(round(x, 2) for x in field); mean = sum(field) / K; table = [round(mean * f, 2) for f in (0.2, 0.5, 1.0, 2.0, 4.0)]
            true = program(cli, N, table, [[s, 1] for s in field])['values']; avg = program(cli, N, table, [[round(mean, 6), K]])['values']
            third = K // 3; parts = [field[:third], field[third:K - third], field[K - third:]]; three = program(cli, N, table, [[round(sum(p) / len(p), 6), len(p)] for p in parts])['values']
            rows.append({'fieldPlayers': K, 'seats': N, 'shape': shape, 'meanStack': round(mean, 3), 'tableStacksInAverages': [0.2, 0.5, 1.0, 2.0, 4.0], 'trueList': true, 'countTimesAverage': avg, 'threeGroups': three,
                         'differenceAverage': [a - b for a, b in zip(avg, true)], 'differenceThreeGroups': [a - b for a, b in zip(three, true)]})
        da = sorted(abs(x) for r in rows for x in r['differenceAverage']); dt = sorted(abs(x) for r in rows for x in r['differenceThreeGroups'])
        rep = {'what': 'rule D (information): seat probability of a table stack when the players at other tables are entered as a true list, as count x average, and as three groups', 'cases': len(rows),
               'countTimesAverage': {'largestAbsoluteDifference': da[-1], 'median': da[len(da) // 2]}, 'threeGroups': {'largestAbsoluteDifference': dt[-1], 'median': dt[len(dt) // 2]},
               'byTableStack': {str(f): {'average': max(abs(r['differenceAverage'][i]) for r in rows), 'threeGroups': max(abs(r['differenceThreeGroups'][i]) for r in rows)} for i, f in enumerate([0.2, 0.5, 1.0, 2.0, 4.0])}, 'rows': rows, 'seconds': round(time.time() - t0, 1)}
        print(json.dumps({k: rep[k] for k in ('cases', 'countTimesAverage', 'threeGroups', 'byTableStack')}, indent=1))
    if out: open(out, 'w').write(json.dumps(rep, indent=1) + '\n')
    if mode == 'check': print(json.dumps({'A': rep['A']['passed'], 'C': rep['C']['passed'], 'monteCarlo': rep['monteCarlo']['passed'], 'largestA': rep['A']['largestDifference'], 'largestC': rep['C']['largestDifference'], 'sum': rep['C']['largestSumError'], 'seconds': rep['seconds']})); sys.exit(0 if rep['passed'] else 1)
main()
