// EightMax 5.2: study fixtures (Requirement 1).
//
// Every fixture is generated through the application's own workflow: a Multiway form state ("spot", what the
// Multiway tab holds) -> EM.multiwaySpotConfig(spot) -> EM.MultiwayGame(cfg).nativeSpec(), i.e. the same code
// the desktop application runs when Solve is pressed. The decision (public action history -> action slots,
// hero hand -> index in the acting seat's range, legal actions and amounts) is then resolved by asking the
// native engine itself (mwcli --node), so a fixture can only be written if the engine reaches the advertised
// decision with the advertised legal actions.
//
//   node tools/fixtures52.js <mwcli> <out-dir> [id ...]      writes <id>.emfix.json (default: every fixture)
//   node tools/fixtures52.js <mwcli> --check <dir>           regenerates every fixture in memory and compares
'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), { execFileSync } = require('node:child_process');
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river', 'lib_river_ui']) require('../web/' + l);
const RANKS = '23456789TJQKA', SUITS = 'cdhs', cardName = c => RANKS[c >> 2] + SUITS[c & 3];
const TABLE = { players: 8, smallBlind: 0.5, bigBlind: 1, antePerPlayer: 0.1, startingPotBeforeVoluntaryAction: 2.3, unit: 'BB' };
// ---- range helpers ----
// 169 classes ordered by a simple strength score (pairs, high cards, suitedness, connectedness).
const CLASSES = (() => { const out = []; for (let a = 12; a >= 0; a--) for (let b = a; b >= 0; b--) { if (a === b) out.push({ name: RANKS[a] + RANKS[b], score: 30 + 2 * (a + 2) }); else for (const s of ['s', 'o']) out.push({ name: RANKS[a] + RANKS[b] + s, score: (a + 2) + (b + 2) / 2 + (s === 's' ? 2 : 0) + (a - b <= 2 ? 1 : 0) }); } return out.sort((x, y) => y.score - x.score || (x.name < y.name ? -1 : 1)); })();
// "Bunching": after five folds the remaining deck is richer in high cards, so the blinds (and the button) hold
// strong classes slightly more often than weak ones. Modelled by three weight tiers over the strength order.
const bunched = (top, mid, low) => CLASSES.map((c, i) => c.name + ':' + (i < 56 ? top : i < 113 ? mid : low)).join(',');
const uniformAll = () => CLASSES.map(c => c.name).join(',');
// ---- fixtures ----
const spotBase = (n, start) => ({ ...E.multiwayExample(n, start, 8), privateMode: 'sampled', traversal: 'external', batchDeals: 1, privateSeed: 1, engine: 'native', measured: false, processingMode: 'cpu', maxIter: 20000 });
const seat = (name, stack, range, prior = '0') => ({ name, stack: String(stack), prior: String(prior), range, lead: true });
const tree = (flop, turn, river) => ({ flop: { bets: flop[0], raises: flop[1] || '', maxBets: flop[2] || 1 }, turn: { bets: turn[0], raises: turn[1] || '', maxBets: turn[2] || 1 }, river: { bets: river[0], raises: river[1] || '', maxBets: river[2] || 1 } });
const FIXTURES = {};
const def = (id, f) => { FIXTURES[id] = f; };

// ---------- 1. 25 BB button, folded to the button, eight-handed ----------
{
  const blindsWeighted = bunched(1, 0.95, 0.9);
  const mk = (o = {}) => ({ ...spotBase(3, 'Preflop'), study: 'linked', abstraction: 'compact', memoryMiB: o.memoryMiB || 2048, preOpen: o.opens || '2.2', preRaises: 'a', preCap: 2, preLimps: false, others: '24.9,24.9,24.9,24.9,24.9',
    tree: tree(['50'], ['66'], ['75']), notes: 'EightMax 5.2 study fixture: 25 BB button, folded to the button.',
    seats: [seat('BTN', 25, o.btn || uniformAll()), seat('SB', 25, o.blinds || blindsWeighted), seat('BB', 25, o.blinds || blindsWeighted)] });
  def('btn25-open', {
    title: '25 BB button open, folded to the button (eight-handed MTT)', kind: 'realistic', companion: 'btn25-open-small',
    hero: { seat: 0, position: 'BTN', hand: 'Kd8c' }, history: [],
    description: {
      effectiveStacksBB: 25, stacksBB: { BTN: 25, SB: 25, BB: 25 }, positions: 'eight-handed: UTG, UTG+1, MP, HJ, CO folded (their antes are in the pot); BTN, SB, BB live',
      actionHistory: 'UTG, UTG+1, MP, HJ and CO fold. Button to act.', board: 'none (preflop)',
      betSizes: { preflop: 'button: fold or raise to 2.2 BB; blinds: fold, call or 3-bet all-in; button facing a 3-bet: fold or call', flop: 'bet 50% pot, no raises', turn: 'bet 66% pot, no raises', river: 'bet 75% pot, no raises' },
      utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the hand (the 0.1 BB ante is sunk: folding = -0.1 BB)' },
      abstraction: 'Compact hand groups (169 preflop classes; made-hand and draw strength groups after the flop). Deals, blockers, showdowns and pots use the physical cards.',
      continuation: 'Linked postflop continuation: one bet size per street, no postflop raises. Every seat plays the trained average strategy; where a deal reaches an information set that training never visited, the evaluator substitutes uniform play and reports the share (fallbackShare).',
      rangeWeights: 'Button: every hand, weight 1. Small and big blind: every hand, weighted for bunching after five folds: the 56 strongest of the 169 classes weight 1.00, the next 57 weight 0.95, the weakest 56 weight 0.90 (an assumption, not a measurement).',
      assumptions: ['The five folded seats are not modelled beyond their antes and the bunching weights.', 'No limping, one open size, 3-bets are all-in only.', 'Postflop bet sizes are a coarse abstraction of real play.'] },
    study: { seeds: [5201, 5202, 5203, 5204, 5205], budgetsDeals: [250000, 1000000, 4000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 200000, seed: 52 }, quality: { method: 'sampled', samples: 20000, selectionSamples: 200, seed: 52, budgets: 'last' }, tolerance: { evGap: 0.05, frequency: 0.05, frequencyShift: 0.15 } },
    variants: [
      { name: 'baseline', change: '', spot: mk() },
      { name: 'wider-range', change: 'Blind ranges without the bunching weights: every hand of both blinds at weight 1 (weak hands are 11% more frequent than in the baseline).', spot: mk({ blinds: uniformAll() }) },
      { name: 'added-size', change: 'The button may also open all-in (25 BB) in addition to raising to 2.2 BB.', spot: mk({ opens: '2.2,a' }) },
    ] });
  // companion: exact cards, ten weighted hands per seat, no postflop betting
  const small = (o = {}) => ({ ...spotBase(3, 'Preflop'), study: 'linked', abstraction: 'exact', memoryMiB: 256, preOpen: o.opens || '2.2', preRaises: 'a', preCap: 2, preLimps: false, others: '24.9,24.9,24.9,24.9,24.9',
    tree: tree([''], [''], ['']), notes: 'EightMax 5.2 study fixture (small companion of btn25-open).',
    seats: [seat('BTN', 25, 'AsKd:0.5,Kd8c,Jc9c,6d6s:0.75'), seat('SB', 25, o.sb || 'AhAd:0.25,JhJd:0.5,Ks4s,Th8h,7c2d,9s3s'), seat('BB', 25, o.bb || 'KhKc:0.25,AdTh:0.5,QdJd,9h6h,8d4d,5c2c')] });
  def('btn25-open-small', {
    title: '25 BB button open, small companion (short weighted ranges, exact cards, no postflop betting)', kind: 'companion', companionOf: 'btn25-open',
    hero: { seat: 0, position: 'BTN', hand: 'Kd8c' }, history: [],
    description: {
      effectiveStacksBB: 25, stacksBB: { BTN: 25, SB: 25, BB: 25 }, positions: 'as btn25-open', actionHistory: 'UTG, UTG+1, MP, HJ and CO fold. Button to act.', board: 'none (preflop)',
      betSizes: { preflop: 'button: fold or raise to 2.2 BB; blinds: fold, call or 3-bet all-in; button facing a 3-bet: fold or call', postflop: 'no betting: hands are checked down to showdown' },
      utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the hand (the 0.1 BB ante is sunk)' },
      abstraction: 'Exact cards (no hand grouping).', continuation: 'No postflop betting.',
      rangeWeights: 'Four listed hands for the button and six per blind, weights 0.25 to 1 (see variants[].ranges).',
      simplifiedFrom: 'btn25-open', simplifications: ['Ranges cut from every hand to four weighted hands for the button and six per blind.', 'Postflop betting removed (check-down).', 'Hand groups replaced by exact cards, so no information set is missing after training.', 'Evaluation stays SAMPLED (400,000 paired samples per evaluation): the exact evaluators walk every flop, turn and river of a called 2.2 BB raise and exceeded their work limit (2,000,000,000 visits) on this tree, measured on the 5.2 development machine. Only preflop all-in trees (see icm8-bb-call-small) are exact.'],
      assumptions: ['Small enough to converge quickly; it shows the method, not real-range strategy.'] },
    study: { seeds: [5201, 5202, 5203, 5204, 5205], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 256, ev: { method: 'sampled', samples: 400000, seed: 52 }, quality: { method: 'sampled', samples: 40000, selectionSamples: 2000, seed: 52 }, tolerance: { evGap: 0.03, frequency: 0.05, frequencyShift: 0.15 } },
    variants: [
      { name: 'baseline', change: '', spot: small() },
      { name: 'wider-range', change: 'The big blind range gains a weaker hand (Jh4h at weight 1).', spot: small({ bb: 'KhKc:0.25,AdTh:0.5,QdJd,9h6h,8d4d,5c2c,Jh4h' }) },
      { name: 'added-size', change: 'The button may also open all-in (25 BB).', spot: small({ opens: '2.2,a' }) },
    ] });
}
// ---------- 2. three-way flop ----------
{
  const SB = '99:0.5,88,77,66,55,44:0.5,AJs:0.5,ATs,A9s,A5s:0.5,KQs:0.5,KJs,KTs,QJs,QTs,JTs,T9s,98s,87s:0.5,AQo:0.5,AJo,KQo';
  const BB = '77:0.5,66,55,44,33,22,A9s:0.5,A8s,A7s,A6s,A5s,A4s,A3s,A2s,K9s,K8s,K7s,K6s,K5s,Q9s,Q8s,J9s,J8s,T8s,97s,86s,76s,75s,65s,64s,54s,ATo:0.5,A9o,A8o,A5o:0.5,KTo,K9o,K8o:0.5,QTo,Q9o:0.5,JTo,J9o:0.5,T9o,98o:0.5,87o:0.5';
  const BBW = BB + ',K7o,K6o:0.5,Q8o,J8o,T8o,97o,86o:0.5,76o,Q7s,J7s,T7s,96s,85s,74s:0.5,53s';
  const BTN = '22+,A2s+,K5s+,Q8s+,J8s+,T8s+,97s+,86s+,76s,65s,A7o+,A5o:0.5,K9o+,QTo+,JTo,T9o:0.5';
  const mk = (o = {}) => ({ ...spotBase(3, 'Flop'), study: 'postflop', abstraction: o.abstraction || 'compact', memoryMiB: 2048, board: 'Ks 8d 5h', common: '0', folded: '', others: '24.9,24.9,24.9,24.9,24.9',
    tree: tree([o.flop || '33,75'], ['66'], ['75']), notes: 'EightMax 5.2 study fixture: three-way flop.',
    seats: [seat('SB', 22.7, SB, 2.2), seat('BB', 22.7, o.bb || BB, 2.2), seat('BTN', 22.7, BTN, 2.2)] });
  def('flop3-kings', {
    title: 'Three-way flop K-8-5 rainbow, button with top pair after two checks', kind: 'realistic', companion: 'flop3-kings-small', overLimitVersion: 'flop3-kings-detailed',
    hero: { seat: 2, position: 'BTN', hand: 'KhJs' }, history: ['Check', 'Check'],
    description: {
      effectiveStacksBB: 22.7, stacksBB: { SB: 22.7, BB: 22.7, BTN: 22.7 }, positions: 'eight-handed, 25 BB starting stacks: the button raised to 2.2 BB, both blinds called; five seats folded (antes in the pot)',
      actionHistory: 'Preflop: BTN raises to 2.2, SB calls, BB calls (pot 7.4 BB). Flop Ks 8d 5h: SB checks, BB checks. Button to act.', board: 'Ks 8d 5h',
      betSizes: { flop: 'bet 33% or 75% pot, no raises', turn: 'bet 66% pot, no raises', river: 'bet 75% pot, no raises' },
      utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the study (the flop): chips collected minus chips put in from the flop on' },
      abstraction: 'Compact hand groups (made-hand and draw strength groups on every street). Deals, blockers, showdowns and pots use the physical cards. The same game with Detailed groups is kept as flop3-kings-detailed: it outgrows the 2,048 MiB strategy table before its information sets are trained.',
      continuation: 'One bet size on the turn and one on the river, no raises on any street. Unvisited information sets are played uniformly by the evaluator (fallbackShare is reported).',
      rangeWeights: 'Weighted class ranges for a button open and two blind calls (see variants[].ranges for the exact text and combination counts).',
      assumptions: ['The preflop ranges are inputs, not solved.', 'No check-raises: the blinds can only call or fold to a bet.'] },
    study: { seeds: [5211, 5212, 5213, 5214, 5215], budgetsDeals: [250000, 1000000, 4000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 200000, seed: 52 }, quality: { method: 'sampled', samples: 40000, selectionSamples: 400, seed: 52, budgets: 'last' }, tolerance: { evGap: 0.05, frequency: 0.05, frequencyShift: 0.15 } },
    variants: [
      { name: 'baseline', change: '', spot: mk() },
      { name: 'wider-range', change: 'The big blind calls preflop with a wider range: 15 more offsuit and suited classes (K7o, K6o:0.5, Q8o, J8o, T8o, 97o, 86o:0.5, 76o, Q7s, J7s, T7s, 96s, 85s, 74s:0.5, 53s).', spot: mk({ bb: BBW }) },
      { name: 'added-size', change: 'A 125% pot overbet is added on the flop (33%, 75% and 125% pot).', spot: mk({ flop: '33,75,125' }) },
    ] });
  def('flop3-kings-detailed', {
    title: 'Three-way flop K-8-5, Detailed hand groups (kept as specified first: exceeds the memory budget)', kind: 'limit', companion: 'flop3-kings', smallerCompanion: 'flop3-kings-small',
    hero: { seat: 2, position: 'BTN', hand: 'KhJs' }, history: ['Check', 'Check'],
    description: {
      effectiveStacksBB: 22.7, stacksBB: { SB: 22.7, BB: 22.7, BTN: 22.7 }, positions: 'as flop3-kings', actionHistory: 'as flop3-kings: SB checks, BB checks, button to act on Ks 8d 5h (pot 7.4 BB).', board: 'Ks 8d 5h',
      betSizes: { flop: 'bet 33% or 75% pot, no raises', turn: 'bet 66% pot, no raises', river: 'bet 75% pot, no raises' },
      utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the study (the flop)' },
      abstraction: 'Detailed hand groups (the application default): far more information sets than Compact groups.',
      continuation: 'As flop3-kings. Unvisited information sets are played uniformly by the evaluator.',
      rangeWeights: 'Identical to flop3-kings.',
      limit: 'Measured on the 5.2 development machine: after 1,000,000 sampled deals the strategy table holds 7.1 million rows (676 MiB) and 55% to 85% of the hero\'s evaluation samples still reach an information set that was never trained; the table grows past the application\'s 2,048 MiB budget before 4,000,000 deals. The study plan below (two seeds) records where each seed stops. Use flop3-kings (Compact groups, same ranges and bets) or flop3-kings-small (exact) instead.',
      assumptions: ['Kept so the simplification to Compact groups is visible: only the hand grouping differs from flop3-kings.'] },
    study: { seeds: [5211, 5212], budgetsDeals: [1000000, 4000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 40000, seed: 52 }, quality: { method: 'none' }, tolerance: { evGap: 0.05, frequency: 0.05, frequencyShift: 0.15 } },
    variants: [{ name: 'baseline', change: '', spot: mk({ abstraction: 'detailed' }) }] });
  const small = (o = {}) => ({ ...spotBase(3, 'Flop'), study: 'postflop', abstraction: 'exact', memoryMiB: 512, board: 'Ks 8d 5h', common: '0', folded: '', others: '24.9,24.9,24.9,24.9,24.9',
    tree: tree([o.flop || '33,75'], [''], ['']), notes: 'EightMax 5.2 study fixture (small companion of flop3-kings).',
    seats: [seat('SB', 22.7, '8c8s:0.5,AcJc,KcQc:0.75,Tc9c,7s7h', 2.2), seat('BB', 22.7, o.bb || '5d5c:0.5,Kd9d,Ah8h,7d6d,QhTh:0.75', 2.2), seat('BTN', 22.7, 'KhJs,AdKc:0.5,9s9h,Qs8s:0.75,Jd Td'.replace('Jd Td', 'JdTd'), 2.2)] });
  def('flop3-kings-small', {
    title: 'Three-way flop K-8-5, small exact companion (five weighted hands per seat, flop betting only)', kind: 'companion', companionOf: 'flop3-kings',
    hero: { seat: 2, position: 'BTN', hand: 'KhJs' }, history: ['Check', 'Check'],
    description: {
      effectiveStacksBB: 22.7, stacksBB: { SB: 22.7, BB: 22.7, BTN: 22.7 }, positions: 'as flop3-kings', actionHistory: 'as flop3-kings: SB checks, BB checks, button to act on Ks 8d 5h (pot 7.4 BB).', board: 'Ks 8d 5h',
      betSizes: { flop: 'bet 33% or 75% pot, no raises', turnAndRiver: 'no betting: checked down' },
      utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the study (the flop)' },
      abstraction: 'Exact cards.', continuation: 'No turn or river betting.',
      rangeWeights: 'Five listed hands per seat with weights 0.5 to 1.',
      simplifiedFrom: 'flop3-kings', simplifications: ['Ranges cut to five weighted hands per seat.', 'Turn and river betting removed, so action EVs and best-response gains are exact inside this model.', 'Hand groups replaced by exact cards.'],
      assumptions: ['Small enough for exact evaluation; it shows the method, not real-range strategy.'] },
    study: { seeds: [5211, 5212, 5213, 5214, 5215], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 512, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.02, frequency: 0.05, quality: 0.02, frequencyShift: 0.15 } },
    variants: [
      { name: 'baseline', change: '', spot: small() },
      { name: 'wider-range', change: 'The big blind range gains two weaker hands (Jh9h and 6h4h at weight 1).', spot: small({ bb: '5d5c:0.5,Kd9d,Ah8h,7d6d,QhTh:0.75,Jh9h,6h4h' }) },
      { name: 'added-size', change: 'A 125% pot overbet is added on the flop.', spot: small({ flop: '33,75,125' }) },
    ] });
}
// ---------- 3. six-way flop ----------
{
  const R = {
    SB: '66,55,44:0.5,33:0.5,A8s,A4s:0.5,K9s:0.5,Q9s,J9s,T9s,98s,87s,76s:0.5,KJo:0.5,QJo',
    BB: '55,44,33,22,J7s,J6s:0.5,T8s,97s,86s,85s:0.5,75s,64s,84s:0.5,K8o:0.5,Q9o,J9o,J8o:0.5,T9o,98o,87o:0.5,A4o:0.5',
    UTG1: 'AA:0.5,KK:0.5,QQ,JJ,TT,99,AKs,AQs,AJs,KQs,KJs:0.5,AKo,AQo,AJo:0.5',
    HJ: '99:0.5,88,77,66,ATs,A9s:0.5,KTs,QJs,QTs,JTs,T9s:0.5,KQo:0.5',
    CO: '88:0.5,77,66,55,A9s,A5s,KJs:0.5,QTs,J9s,T9s,98s,87s,AJo:0.5,KJo',
    BTN: '77,66,55,44,33:0.5,A7s,A3s:0.5,K9s,Q9s,J8s:0.5,T8s,97s,86s,76s,ATo:0.5,QJo,JTo',
  };
  const BTNW = R.BTN + ',22,A6s,A2s,K8s,Q8s,J7s,T7s,96s,65s,54s:0.5,KTo,QTo,J9o,T9o:0.5,A9o:0.5';
  const names = ['SB', 'BB', 'UTG1', 'HJ', 'CO', 'BTN'];
  const mk = (o = {}) => ({ ...spotBase(6, 'Flop'), study: 'postflop', abstraction: 'compact', memoryMiB: 2048, board: 'Jh 8d 4c', common: '0', folded: '', others: '24.9,24.9',
    tree: tree([o.flop || '33,66'], ['66'], ['']), notes: 'EightMax 5.2 study fixture: six-way flop.',
    seats: names.map(n => seat(n === 'UTG1' ? 'UTG+1' : n, 22.9, n === 'BTN' && o.btn ? o.btn : R[n], 2)) });
  def('flop6-jack', {
    title: 'Six-way flop J-8-4 rainbow, preflop raiser with top pair top kicker after two checks', kind: 'realistic', companion: 'flop6-jack-small',
    hero: { seat: 2, position: 'UTG+1', hand: 'AdJs' }, history: ['Check', 'Check'],
    description: {
      effectiveStacksBB: 22.9, stacksBB: Object.fromEntries(names.map(n => [n === 'UTG1' ? 'UTG+1' : n, 22.9])), positions: 'eight-handed, 25 BB starting stacks: UTG+1 raised to 2 BB and HJ, CO, BTN, SB and BB all called; UTG and MP folded (antes in the pot)',
      actionHistory: 'Preflop: UTG folds, UTG+1 raises to 2, MP folds, HJ, CO, BTN, SB and BB call (pot 12.8 BB). Flop Jh 8d 4c: SB checks, BB checks. UTG+1 to act with three players behind.', board: 'Jh 8d 4c',
      betSizes: { flop: 'bet 33% or 66% pot, no raises', turn: 'bet 66% pot, no raises', river: 'no betting: checked down' },
      utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the study (the flop)' },
      abstraction: 'Compact hand groups (made-hand and draw strength groups). Deals, blockers, showdowns and side pots use the physical cards.',
      continuation: 'One turn bet size, no river betting, no raises. Unvisited information sets are played uniformly by the evaluator (fallbackShare is reported).',
      rangeWeights: 'Weighted class ranges per seat for a 2 BB raise and five callers (see variants[].ranges).',
      assumptions: ['The preflop ranges are inputs, not solved.', 'No check-raises and no river betting: the tree is far coarser than real six-way play.'] },
    study: { seeds: [5221, 5222, 5223, 5224, 5225], budgetsDeals: [250000, 1000000, 4000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 1000000, seed: 52 }, quality: { method: 'sampled', samples: 100000, selectionSamples: 400, seed: 52, budgets: 'last' }, tolerance: { evGap: 0.05, frequency: 0.05, frequencyShift: 0.15 } },
    variants: [
      { name: 'baseline', change: '', spot: mk() },
      { name: 'wider-range', change: 'The button (the last caller) holds a wider range: 15 more classes (22, A6s, A2s, K8s, Q8s, J7s, T7s, 96s, 65s, 54s:0.5, KTo, QTo, J9o, T9o:0.5, A9o:0.5).', spot: mk({ btn: BTNW }) },
      { name: 'added-size', change: 'A pot-size bet (100% pot) is added on the flop (33%, 66% and 100% pot).', spot: mk({ flop: '33,66,100' }) },
    ] });
  const S = { SB: 'Ac8c:0.5,9s9d,Td9d', BB: '4h4d:0.5,Jc7c,8s6s', UTG1: 'AdJs,QhQs:0.5,AsKs', HJ: '8h8c:0.5,KdJd,QcTc', CO: '7h7s,As5s:0.5,JdTs', BTN: '6h6d,Kh9h:0.5,9c8s' };
  const small = (o = {}) => ({ ...spotBase(6, 'Flop'), study: 'postflop', abstraction: 'exact', memoryMiB: 512, board: 'Jh 8d 4c', common: '0', folded: '', others: '24.9,24.9',
    tree: tree([o.flop || '33,66'], [''], ['']), notes: 'EightMax 5.2 study fixture (small companion of flop6-jack).',
    seats: names.map(n => seat(n === 'UTG1' ? 'UTG+1' : n, 22.9, n === 'BTN' && o.btn ? o.btn : S[n], 2)) });
  def('flop6-jack-small', {
    title: 'Six-way flop J-8-4, small exact companion (three weighted hands per seat, flop betting only)', kind: 'companion', companionOf: 'flop6-jack',
    hero: { seat: 2, position: 'UTG+1', hand: 'AdJs' }, history: ['Check', 'Check'],
    description: {
      effectiveStacksBB: 22.9, stacksBB: Object.fromEntries(names.map(n => [n === 'UTG1' ? 'UTG+1' : n, 22.9])), positions: 'as flop6-jack', actionHistory: 'as flop6-jack: SB checks, BB checks, UTG+1 to act on Jh 8d 4c (pot 12.8 BB).', board: 'Jh 8d 4c',
      betSizes: { flop: 'bet 33% or 66% pot, no raises', turnAndRiver: 'no betting: checked down' },
      utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the study (the flop)' },
      abstraction: 'Exact cards.', continuation: 'No turn or river betting.',
      rangeWeights: 'Three listed hands per seat with weights 0.5 to 1.',
      simplifiedFrom: 'flop6-jack', simplifications: ['Ranges cut to three weighted hands per seat.', 'Turn and river betting removed, so action EVs and best-response gains are exact inside this model.', 'Hand groups replaced by exact cards.'],
      assumptions: ['Small enough for exact evaluation; it shows the method, not real-range strategy.'] },
    study: { seeds: [5221, 5222, 5223, 5224, 5225], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 512, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.02, frequency: 0.05, quality: 0.05, frequencyShift: 0.15 } },
    variants: [
      { name: 'baseline', change: '', spot: small() },
      { name: 'wider-range', change: 'The button range gains a weaker hand (Tc7c at weight 1).', spot: small({ btn: '6h6d,Kh9h:0.5,9c8s,Tc7c' }) },
      { name: 'added-size', change: 'A pot-size bet (100% pot) is added on the flop.', spot: small({ flop: '33,66,100' }) },
    ] });
}
// ---------- 4. eight-handed final table, ICM ----------
{
  const PAY = '30,20,14,11,9,7,5,4', OTHERS = '21.9,8.9,30.9,13.9,26.9';
  const W = bunched(1, 0.95, 0.9);
  const mk = (o = {}) => ({ ...spotBase(3, 'Preflop'), study: 'linked', payoff: o.chip ? 'chip' : 'icm', payouts: PAY, others: OTHERS, abstraction: 'compact', memoryMiB: 2048, preOpen: o.opens || 'a', preRaises: 'a', preCap: 2, preLimps: false,
    tree: tree(['a'], [''], ['']), notes: 'EightMax 5.2 study fixture: eight-handed final table.',
    seats: [seat('BTN', 40, o.ranges || W), seat('SB', 12, o.ranges || W), seat('BB', 18, o.ranges || W)] });
  const descr = small => ({
    effectiveStacksBB: 18, stacksBB: { UTG: 22, 'UTG+1': 9, MP: 31, HJ: 14, CO: 27, BTN: 40, SB: 12, BB: 18 }, payouts: { unit: 'percent of the prize pool', places: [30, 20, 14, 11, 9, 7, 5, 4] },
    positions: 'eight players left, all paid: UTG 22, UTG+1 9, MP 31, HJ 14, CO 27 (folded; stacks shown before the 0.1 BB ante), BTN 40, SB 12, BB 18',
    actionHistory: 'UTG, UTG+1, MP, HJ and CO fold. BTN (40 BB) moves all-in, SB (12 BB) folds. Big blind (18 BB) to act: call or fold.', board: 'none (preflop)',
    betSizes: { preflop: 'button: fold or all-in; blinds: fold or call all-in' + (small ? '' : ' (the added-size variant also gives the button a raise to 2.2 BB)'), postflop: 'none in the baseline (every pot is all-in or folded); the added-size variant allows an all-in bet on the flop after a 2.2 BB raise is called' },
    utility: { model: 'icm', unit: 'percent of the prize pool', convention: 'Malmuth-Harville ICM value of the hero\'s final stack given the eight stacks, in percent of the prize pool. The chip-EV variant of the same spot reports BB instead; the two are never mixed in one comparison.' },
    abstraction: small ? 'Exact cards.' : 'Compact hand groups (169 preflop classes). Deals, blockers, showdowns, side pots and ICM use the physical cards and exact stacks.',
    continuation: 'All-in or fold preflop; no further decisions in the baseline.',
    rangeWeights: small ? 'Four or five listed hands per seat with weights 0.5 to 1.' : 'Every hand for BTN, SB and BB, weighted for bunching after five folds (56 strongest classes 1.00, next 57 0.95, weakest 56 0.90; an assumption).',
    assumptions: ['The five folded stacks only enter through ICM (they keep their stacks).', 'Push-or-fold abstraction for the button in the baseline.'] });
  def('icm8-bb-call', {
    title: 'Eight-handed final table: big blind (18 BB) facing a button all-in, ICM with a chip-EV comparison', kind: 'realistic', companion: 'icm8-bb-call-small',
    hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'],
    description: descr(false),
    study: { seeds: [5231, 5232, 5233, 5234, 5235], budgetsDeals: [500000, 2000000, 8000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 2000000, seed: 52 }, quality: { method: 'sampled', samples: 200000, selectionSamples: 1000, seed: 52 }, tolerance: { evGap: 0.05, frequency: 0.05, frequencyShift: 0.15 } },
    variants: [
      { name: 'baseline', change: '', spot: mk() },
      { name: 'wider-range', change: 'No bunching weights: every hand of BTN, SB and BB at weight 1 (weak hands 11% more frequent).', spot: mk({ ranges: uniformAll() }) },
      { name: 'added-size', change: 'The button may also raise to 2.2 BB instead of moving all-in (blinds can call or re-raise all-in; one all-in bet on the flop).', spot: mk({ opens: '2.2,a' }) },
      { name: 'chip-ev', change: 'Same stacks, ranges and actions, but utilities are chips (BB) instead of ICM prize share.', spot: mk({ chip: true }) },
    ] });
  const small = (o = {}) => ({ ...spotBase(3, 'Preflop'), study: 'linked', payoff: o.chip ? 'chip' : 'icm', payouts: PAY, others: OTHERS, abstraction: 'exact', memoryMiB: 256, preOpen: o.opens || 'a', preRaises: 'a', preCap: 2, preLimps: false,
    tree: tree([''], [''], ['']), notes: 'EightMax 5.2 study fixture (small companion of icm8-bb-call).',
    seats: [seat('BTN', 40, o.btn || 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5'), seat('SB', 12, 'TsTh:0.5,Kd9d,Qc6c:0.75,5h4h'), seat('BB', 18, 'AdTc,6s6c,Kh8h:0.75,9c3d')] });
  def('icm8-bb-call-small', {
    title: 'Eight-handed final table, small exact companion (four or five weighted hands per seat)', kind: 'companion', companionOf: 'icm8-bb-call',
    hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'],
    description: { ...descr(true), simplifiedFrom: 'icm8-bb-call', simplifications: ['Ranges cut from every hand to four or five weighted hands per seat.', 'Hand groups replaced by exact cards; action EVs and best-response gains are exact inside this model.', 'The added-size variant gives the button a 2.2 BB raise with no postflop betting (check-down).'] },
    study: { seeds: [5231, 5232, 5233, 5234, 5235], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 256, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.02, frequency: 0.05, quality: 0.02, frequencyShift: 0.15 } },
    variants: [
      { name: 'baseline', change: '', spot: small() },
      { name: 'wider-range', change: 'The button range gains a weaker hand (Jc6c at weight 1).', spot: small({ btn: 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5,Jc6c' }) },
      { name: 'added-size', change: 'The button may also raise to 2.2 BB instead of moving all-in (postflop checked down). The quality metric of this variant is sampled: exact best response exceeds the work limit once a 2.2 BB raise can reach the flop.', spot: small({ opens: '2.2,a' }), quality: { method: 'sampled', samples: 40000, selectionSamples: 2000, seed: 52 } },
      { name: 'chip-ev', change: 'Same spot with chip utilities (BB) instead of ICM prize share.', spot: small({ chip: true }) },
    ] });
}
// ---------- known small game (tests): A-K-Q river with a closed-form mixed equilibrium ----------
def('known-akq-river', {
  title: 'Known small game: A-K-Q river (closed-form mixed equilibrium)', kind: 'test',
  hero: { seat: 1, position: 'Seat 2', hand: 'KhKd' }, history: ['All-in'],
  description: {
    effectiveStacksBB: 10, stacksBB: { 'Seat 1': 10, 'Seat 2': 10 }, positions: 'heads-up river; no antes are added (dealt 2)', actionHistory: 'River 2c 3d 7h 8s 9c, pot 10 BB (9.8 BB plus two 0.1 BB antes). Seat 1 (aces or queens, equally likely) bets 10 BB (pot). Seat 2 (kings) to act: call or fold.', board: '2c 3d 7h 8s 9c',
    betSizes: { river: 'one pot-size bet (which is all-in), no raises' }, utility: { model: 'chip', unit: 'BB', convention: 'net chips from the start of the study' },
    abstraction: 'Exact cards.', continuation: 'none', rangeWeights: 'Seat 1: AhAd and QhQd at weight 1. Seat 2: KhKd.',
    knownSolution: 'Pot P = 10, bet B = 10. Seat 1 bets aces always and bluffs queens with probability B/(P+B) = 1/2; seat 2 calls with probability P/(P+B) = 1/2 and is exactly indifferent: EV(call) = EV(fold) = 0 BB from the start of the study. Seat 1 is indifferent between betting and checking queens (both 0 BB) and strictly prefers betting aces (+15 BB against +10 BB for checking).',
    assumptions: ['A textbook polarised-range game used to test the study report against a closed form.'] },
  study: { seeds: [1, 2, 3, 4, 5, 6], budgetsDeals: [1000, 10000, 100000, 1000000, 4000000], memoryMiB: 64, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.05, frequency: 0.05, quality: 0.02, frequencyShift: 0.15 } },
  variants: [{ name: 'baseline', change: '', spot: { ...spotBase(3, 'River'), dealt: 2, others: '', study: 'postflop', abstraction: 'exact', memoryMiB: 64, board: '2c 3d 7h 8s 9c', common: '9.8', folded: '', tree: tree([''], [''], ['100']), seats: [seat('Seat 1', 10, 'AhAd,QhQd'), seat('Seat 2', 10, 'KhKd')] } }],
});
// ---------- 5.12: six-handed fixtures (definitions in tools/fixtures512.js) ----------
require('./fixtures512')({ E, def, seat, tree, bunched, uniformAll });
// ---------- 5.13: satellite fixtures (definitions in tools/fixtures513.js) ----------
require('./fixtures513')({ E, def, seat, tree, bunched, uniformAll });
// ---- generation ----
function label(a) { return a.to > 0 && a.name !== 'Fold' && a.name !== 'Check' ? a.name + ' ' + (+a.to.toFixed(4)) : a.name; }
function build(id, cli) {
  const f = FIXTURES[id]; if (!f) throw new Error('unknown fixture ' + id);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em52-fix-'));
  try {
    const variants = f.variants.map(v => {
      const cfg = { ...E.multiwaySpotConfig(v.spot), engine: 'native' }, game = E.MultiwayGame(cfg);
      const why = game.nativeSupport(); if (why) throw new Error(id + '/' + v.name + ': not eligible for native training: ' + why);
      const spec = game.nativeSpec(), specFile = path.join(dir, 'spec.json'), st = path.join(dir, 'state'), q = path.join(dir, 'q.json');
      fs.writeFileSync(specFile, JSON.stringify(spec));
      execFileSync(cli, [specFile, 1, 1, st, 1024], { encoding: 'utf8' });
      const node = p => { fs.writeFileSync(q, JSON.stringify({ path: p, board: [], limit: 1326 })); return JSON.parse(execFileSync(cli, ['--node', specFile, st, q, 1024], { encoding: 'utf8', maxBuffer: 64 << 20 })); };
      const pathSlots = [], trail = []; let cur = node([]);
      for (const want of f.history) {
        const a = cur.actions.find(x => label(x) === want || x.name === want); if (!a) throw new Error(id + '/' + v.name + ': action "' + want + '" is not legal after [' + trail.join(', ') + ']; legal: ' + cur.actions.map(label).join(', '));
        trail.push({ seat: cur.node.actor, seatName: v.spot.seats[cur.node.actor].name, action: label(a) }); pathSlots.push(a.slot); cur = node(pathSlots);
        if (cur.node.kind !== 'decision') throw new Error(id + '/' + v.name + ': the history leaves the street or ends the hand');
      }
      if (cur.node.actor !== f.hero.seat) throw new Error(id + '/' + v.name + ': the decision belongs to seat ' + cur.node.actor + ', not the hero seat ' + f.hero.seat);
      const hi = spec.hands[f.hero.seat].findIndex(h => { const n = [cardName(h[1]), cardName(h[2])]; return n.join('') === f.hero.hand || n.reverse().join('') === f.hero.hand; });
      if (hi < 0) throw new Error(id + '/' + v.name + ': the hero hand ' + f.hero.hand + ' is not in the hero range');
      // 5.13: a satellite's EV is a probability of winning a seat; a fixture or a variant names its own unit
      const utility = !cfg.icm ? { model: 'chip', unit: 'BB' } : v.utility || f.utility || { model: 'icm', unit: 'percent of the prize pool' };
      return { name: v.name, change: v.change, utility, ...(v.ev ? { ev: v.ev } : {}), ...(v.quality ? { quality: v.quality } : {}), spot: v.spot, game: cfg, nativeSpec: spec,
        ranges: v.spot.seats.map((s, i) => ({ seat: i, name: s.name, text: s.range, combinations: spec.hands[i].length, weightSum: +spec.hands[i].reduce((a, h) => a + h[3], 0).toFixed(4) })),
        decision: { path: pathSlots, board: [], seat: f.hero.seat, seatName: v.spot.seats[f.hero.seat].name, hand: f.hero.hand, handIndex: hi, handWeight: spec.hands[f.hero.seat][hi][3], history: trail, street: cur.node.street, stateId: cur.node.stateId,
          potBB: cur.node.pot, toCallBB: cur.node.price ?? 0, behindBB: cur.node.behind, committedBB: cur.node.committed,
          actions: cur.actions.map(a => ({ slot: a.slot, name: a.name, to: a.to, label: label(a), ...(a.to > 0 && /^Bet/.test(a.name) ? { potFraction: +(a.to / cur.node.pot).toFixed(4) } : {}) })) } };
    });
    return { format: 'EightMax study fixture', formatVersion: 1, id, title: f.title, kind: f.kind, ...(f.companion ? { companion: f.companion } : {}), ...(f.companionOf ? { companionOf: f.companionOf } : {}), table: f.table || TABLE,
      description: { heroSeat: f.hero.seat, heroPosition: f.hero.position, heroHand: f.hero.hand, ...f.description, legalActions: variants[0].decision.actions.map(a => a.label) },
      howToOpen: 'Windows application: Study tab > "Open study fixture" (or pick it from the built-in list) > "Open in Multiway tab" to see the game in the normal form, or "Run study". Command line: mwcli.exe --study <this file> result.json',
      study: f.study, variants };
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
module.exports = { FIXTURES, build, label };
if (require.main === module) {
  const [cliArg, outArg, ...ids] = process.argv.slice(2);
  if (!cliArg || !outArg) { console.error('usage: node tools/fixtures52.js <mwcli> <out-dir> [id ...] | <mwcli> --check <dir>'); process.exit(2); }
  const cli = path.resolve(cliArg);
  if (outArg === '--check') {
    let bad = 0; const dir = path.resolve(ids[0]);
    for (const file of fs.readdirSync(dir).filter(x => x.endsWith('.emfix.json')).sort()) { const have = fs.readFileSync(path.join(dir, file), 'utf8'), id = file.replace('.emfix.json', ''); const want = JSON.stringify(build(id, cli), null, 1) + '\n'; const same = have === want; if (!same) bad++; console.log((same ? 'identical  ' : 'DIFFERENT  ') + file); }
    process.exit(bad ? 1 : 0);
  }
  fs.mkdirSync(path.resolve(outArg), { recursive: true });
  for (const id of ids.length ? ids : Object.keys(FIXTURES)) {
    const fx = build(id, cli), file = path.join(path.resolve(outArg), id + '.emfix.json'); fs.writeFileSync(file, JSON.stringify(fx, null, 1) + '\n');
    console.log(id.padEnd(22), fx.variants.map(v => v.name + ': pot ' + v.decision.potBB + ', ' + v.decision.actions.map(a => a.label).join(' / ') + ' [' + v.ranges.map(r => r.combinations).join(',') + ']').join('\n' + ' '.repeat(23)));
  }
}
