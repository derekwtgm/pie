// EightMax 5.13: the satellite controls in a browser (Chromium through Playwright).
//   node tools/sat_ui513.js <5.13 EightMax-Offline.html> <out.json> [screenshot-dir]
'use strict';
const fs = require('node:fs'), path = require('node:path'), { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');
const [page513, outFile, shotDir] = process.argv.slice(2);
if (!page513 || !outFile) { console.error('usage: node sat_ui513.js <page> <out.json> [screenshot-dir]'); process.exit(2); }
const checks = [], errors = [];
const check = (name, ok, detail) => { checks.push({ name, passed: !!ok, ...(detail !== undefined ? { detail } : {}) }); console.log((ok ? 'ok      ' : 'FAILED  ') + name + (ok || detail === undefined ? '' : '  ' + JSON.stringify(detail).slice(0, 300))); };
(async () => {
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 900, height: 1300 } }), p = await ctx.newPage();
  p.on('pageerror', e => errors.push(String(e))); p.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await p.goto(pathToFileURL(path.resolve(page513)).href); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForSelector('#v-preflop .grid13');
  await p.click('[data-tab="icm"]'); await p.waitForSelector('#sat-card');
  // the card: six table stacks, 82 players with 25 bb elsewhere, 40 seats
  const shown = await p.$$eval('#sat-table-out tbody tr', rows => rows.map(r => [...r.children].map(c => c.textContent)));
  const want = await p.evaluate(() => Array.from(EM.satelliteField(40, [[25, 82]]).evaluate([25, 18, 40, 12, 31, 22])));
  check('ICM tab: the satellite card lists the six table stacks with the seat probabilities of the satellite-field model', shown.length === 6 && shown.every((r, i) => Math.abs(parseFloat(r[3]) - 100 * want[i]) < 0.006), { shown: shown.map(r => r[3]), want: want.map(x => +(100 * x).toFixed(2)) });
  check('ICM tab: the card says how many players and seats, and that it is the field model', /88 players left, 40 seats/.test(await p.$eval('#sat-card', e => e.textContent)) && /field model/.test(await p.$eval('#sat-card', e => e.textContent)));
  // a field of at most 16 players: the exact recursion is shown beside the model and agrees
  await p.fill('#sat-fd', '8, 14, 22, 31, 40'); await p.fill('#sat-st', '3'); await p.fill('#sat-tb', '10, 25');
  const small = await p.$$eval('#sat-table-out tbody tr', rows => rows.map(r => [...r.children].map(c => c.textContent)));
  check('ICM tab: with at most 16 players the exact recursion is shown beside the model, the same to two decimals', small.length === 2 && small.every(r => r.length === 6 && r[3] === r[4]), small);
  await p.fill('#sat-st', '9');
  check('ICM tab: more seats than players at other tables is refused with the reason', /more players than there are seats/.test(await p.$eval('#sat-card .err', e => e.textContent)));
  await p.fill('#sat-st', '3'); await p.fill('#sat-fd', '82x25'); await p.fill('#sat-tb', '25, 18, 40, 12, 31, 22'); await p.fill('#sat-st', '40');
  // the ordinary calculator: "satellite 4"
  await p.fill('#ic-st', '30, 9, 16, 22, 14'); await p.fill('#ic-pay', 'satellite 4');
  const rows = await p.$$eval('#v-icm .card:first-child table tbody tr', r => r.map(x => [...x.children].map(c => c.textContent)));
  const exact = await p.evaluate(() => Array.from(EM.icmRaw([30, 9, 16, 22, 14], [1, 1, 1, 1])));
  check('ICM tab: "satellite 4" as the payouts gives each stack its probability of a seat', rows.length === 5 && rows.every((r, i) => Math.abs(parseFloat(r[3]) - exact[i]) < 0.006), { rows: rows.map(r => r[3]), exact });
  if (shotDir) { fs.mkdirSync(shotDir, { recursive: true }); await p.screenshot({ path: path.join(shotDir, 'satellite-icm-tab.png'), fullPage: true }); }
  await p.reload(); await p.click('[data-tab="icm"]'); await p.waitForSelector('#sat-card');
  check('the satellite card keeps its entries across a reload', await p.$eval('#sat-st', e => e.value) === '40' && await p.$eval('#sat-fd', e => e.value) === '82x25');
  // Multiway: the payoff
  await p.click('[data-tab="river"]'); await p.waitForSelector('#rv-payoff');
  const opts = await p.$$eval('#rv-payoff option', o => o.map(x => x.value));
  check('Multiway: the payoff list offers Chip EV, Tournament ICM and Satellite, large field', JSON.stringify(opts) === JSON.stringify(['chip', 'icm', 'satfield']));
  check('Multiway: the satellite settings are hidden until the payoff is chosen', await p.$eval('#rv-sat-settings', e => e.hidden) === true);
  await p.selectOption('#rv-payoff', 'satfield');
  check('Multiway: choosing it shows seats and the field, and hides the ICM payout fields', await p.$eval('#rv-sat-settings', e => e.hidden) === false && await p.$eval('#rv-icm-settings', e => e.hidden) === true && await p.$eval('#rv-satSeats', e => e.value) === '40' && await p.$eval('#rv-satField', e => e.value) === '82x25');
  // Study: a group of satellites
  await p.click('[data-tab="study"]'); await p.waitForSelector('#sd-pick');
  const groups = await p.$$eval('#sd-pick optgroup', g => g.map(x => ({ label: x.label, n: x.children.length })));
  check('Study: the list has a group "Satellites" with six fixtures after the two tables', groups.length === 3 && groups[2].label === 'Satellites' && groups[2].n === 6 && groups[0].n + groups[1].n === 16, groups);
  const idx = await p.$$eval('#sd-pick option', o => o.findIndex(x => /124 left and 40 seats: big blind/.test(x.textContent) && !/small/.test(x.textContent))); await p.selectOption('#sd-pick', { index: idx });
  const card = await p.$eval('#v-study', e => e.textContent);
  check('Study: the large-field satellite fixture opens and names its payoff model and unit', /satfield-bb-call/.test(card) && /probability of winning a seat/.test(card), card.slice(0, 200));
  check('no script error and no console error', errors.length === 0, errors.slice(0, 5));
  await browser.close();
  const passed = checks.filter(c => c.passed).length, failed = checks.length - passed;
  fs.writeFileSync(outFile, JSON.stringify({ what: 'EightMax 5.13 satellite controls, Chromium', passed, failed, checks }, null, 1) + '\n'); console.log(passed + ' passed, ' + failed + ' failed'); process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
