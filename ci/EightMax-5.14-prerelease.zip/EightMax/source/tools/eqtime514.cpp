// EightMax 5.14: equal-training-time experiments on the machine they run on (eqtime / eqtime.exe).
//
// Built by native/build.sh from the engine of this release (the same mw.o as mwcli). mwcli has no training mode that
// is stopped by the clock; this tool trains until the clock says stop and then computes the exact NashConv in the
// same process. It uses no GPU.
//
//   eqtime pruning [options]     default trainer against the two pruning algorithms of 5.14 (20 games, exact NashConv)
//   eqtime threads [options]     rbes on one thread against rbes with frozen batches on several threads (6 games)
//   eqtime scaling [options]     deals per second by batch size and thread count on two shipped fixtures (no verdict)
//   eqtime all [options]         the three, one after the other
//   eqtime analyze DIR           summary.json and summary.txt again from the rows of a pruning or threads directory
//   eqtime reference DIR         (development) writes the equal-deals reference values
//   options: --quick (a trial of a few minutes, never a result)  --jobs N  --threads N  --times a,b  --out DIR
//
// Each part has a plan (question, games, seeds, budgets, statistic, rule): the text returned by planText(). It is
// written to <out>/plan.json before the first unit starts; a directory that holds another plan is refused. A run that
// was interrupted is continued by starting it again.
#include "mw.h"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include <cpuid.h>
#ifdef _WIN32
#include <windows.h>
#include <direct.h>
#else
#include <sched.h>
#include <sys/stat.h>
#include <unistd.h>
#endif
using Clock = std::chrono::steady_clock;
#ifndef EM_BUILD_ID
#define EM_BUILD_ID "unknown"
#endif
static const char *FEW[] = {"hu-river", "hu-turn", "river3-chip", "turn4", "flop6", "final8", "bubble4"};
static const char *RANGES[] = {"rg-hu-river", "rg-river3", "rg-hu-turn", "rg-turn3", "rg-turn4", "rg-icm3-river", "rg-bubble4", "rg-flop6c"};
static const char *TOURN[] = {"early3-flop", "mid3-turn", "short8-push", "bubble5-icm", "sidepot3-icm"};
// WIDE: the largest range of a seat has at least 10 hands (counted in the specs)
static const char *WIDE[] = {"rg-hu-river", "rg-river3", "rg-hu-turn", "rg-turn3", "rg-turn4", "rg-icm3-river"};
static bool in(const char *const *a, size_t n, const std::string &g) { for (size_t i = 0; i < n; i++) if (g == a[i]) return true; return false; }
#define INSET(A, g) in(A, sizeof A / sizeof *A, g)
struct Arm { std::string name, add; int batch, threads; };
struct Config {
  std::string part; bool quick = false; std::vector<std::string> games; std::vector<int> seeds; std::vector<double> times; long long checkDeals = 20000;
  std::vector<Arm> arms; size_t baseline = 0; std::vector<size_t> candidates; bool serial = false; int N = 1;
};
static int threadsFor(unsigned logical) { return logical >= 16 ? 8 : logical >= 4 ? 4 : 2; }
static Config config(const std::string &part, bool quick, int N, const std::vector<double> &times) {
  Config c; c.part = part; c.quick = quick; c.N = N;
  const char *P = "\"trainingStreams\":\"philox64\",";
  if (part == "pruning") {
    c.arms = {{"default", P, 1, 1}, {"nrp", std::string(P) + "\"pruning\":\"nrp-5.14-v1\",", 1, 1}, {"nrpc", std::string(P) + "\"pruning\":\"nrpc-5.14-v1\",", 1, 1}};
    c.candidates = {1, 2};
    if (quick) { c.games = {"hu-river", "rg-turn4", "mid3-turn"}; c.seeds = {9001, 9002, 9003}; c.times = {0.2, 0.6}; c.checkDeals = 2000; }
    else { for (auto g : FEW) c.games.push_back(g); for (auto g : RANGES) c.games.push_back(g); for (auto g : TOURN) c.games.push_back(g);
      for (int s = 5141; s <= 5160; s++) c.seeds.push_back(s); c.times = times.empty() ? std::vector<double>{4.0, 16.0} : times; }
  } else {   // threads
    const std::string R = std::string(P) + "\"estimator\":\"rbes\",";
    c.arms = {{"rbes-b1-t1", R, 1, 1}, {"rbes-b" + std::to_string(N) + "-t" + std::to_string(N), R, N, N}, {"rbes-b" + std::to_string(4 * N) + "-t" + std::to_string(N), R, 4 * N, N}, {"default-b1-t1", P, 1, 1}};
    c.candidates = {1, 2}; c.serial = true;
    if (quick) { c.games = {"rg-turn4"}; c.seeds = {9001, 9002, 9003}; c.times = {0.5}; c.checkDeals = 2000; }
    else { for (auto g : WIDE) c.games.push_back(g); for (int s = 5141; s <= 5152; s++) c.seeds.push_back(s); c.times = times.empty() ? std::vector<double>{4.0} : times; }
  }
  return c;
}
static std::string timesText(const Config &c) { std::string t; for (double x : c.times) { char b[32]; std::snprintf(b, sizeof b, "%s%g s", t.empty() ? "" : ", ", x); t += b; } return t; }
static std::string planText(const Config &c) {
  std::string t = "EightMax 5.14 (engine build " EM_BUILD_ID "), equal training time, part " + c.part + ". ";
  if (c.part == "pruning") t +=
    "QUESTION: do the two pruning algorithms of 5.14 reach a lower EXACT NashConv than the default trainer in the same wall-clock training time? "
    "ARMS: default (the spec as generated), nrp (pruning nrp-5.14-v1: a candidate action is skipped with probability 0.95 and nothing is corrected) and nrpc (pruning nrpc-5.14-v1: the same skip with the importance correction that makes the increments unbiased); both with the settings of the release (threshold 0.02 of the utility scale, evidence 50). The rule and its settings were fixed after pilots on other seeds (7001 to 7015, six games, 0.5 to 4 s) and before this plan was written; the pilots are reported with the result. All arms use the 64-bit training streams, one thread, table limit 512 MiB. "
    "GAMES: the 20 reference games of the 5.10 experiment (tools/games510.js), each small enough for an exact best response of every seat: few hands (7), ranges (8), tournament (5). "
    "SEEDS: 5141 to 5160, the same for every arm (paired); not used by an earlier experiment. "
    "BUDGETS: " + timesText(c) + " of training, each a fresh run stopped at the first 64-update boundary after the deadline; the clock starts after the engine is built. "
    "MEASURE: exact NashConv of the average strategy (the sum over the seats of the exact best-response gain). For more than two seats NashConv is not exploitability. "
    "STATISTIC: per game, budget and candidate the mean over seeds of ln(NashConv candidate / NashConv default), paired by seed, Student-t interval; a NashConv below 1e-12 counts as 1e-12. "
    "PRIMARY family: the longest budget, one interval per game and candidate (40), each at level 0.05/40. SECONDARY family: every budget, each interval at level 0.05/(40 x number of budgets). Verdicts: better (whole interval below 1), worse (above 1), unresolved. "
    "RULE, fixed before measuring. Q1: the equal-deals check passes (after 20,000 sampled deals of the first seed every arm reproduces, in every game, the NashConv recorded from the Linux build, to the last bit); otherwise the run measures another program and nothing counts. "
    "Q2: at least 18 of 20 seeds valid for every game and arm; otherwise incomplete. "
    "Q3: a pruning algorithm is RECOMMENDED (still opt-in) for a class of games when it is better in the primary family on at least half of the games of the class and worse in no secondary interval of the class. "
    "Q4: it is NOT RECOMMENDED when it is worse in any interval of either family; the games are named. Otherwise it stays EXPERIMENTAL with no resolved benefit. "
    "Q5: no outcome of this experiment changes a default: the default trainer keeps writing the states it wrote before, and pruning is never chosen automatically in 5.14. "
    "LIMITS: small games with exact evaluation only, with one to three bet sizes a street; pruning saves most where a decision has many actions, which these games do not have. Nothing follows for the shipped fixtures with hand groups, where no exact NashConv exists. Several units run at once, each bound to its own processor; the arms of a unit run one after the other on the same processor in an order that rotates with the seed.";
  else t +=
    "QUESTION: does the estimator rbes with frozen batches on N threads reach a lower EXACT NashConv than rbes on one thread (one deal per update) in the same wall-clock training time on this machine? N = " + std::to_string(c.N) + ". "
    "ARMS: rbes-b1-t1 (the baseline), rbes with batchDeals N on N threads, rbes with batchDeals 4N on N threads (per-deal action streams, as frozen batches need), and default-b1-t1 for reference. 64-bit training streams, table limit 512 MiB. "
    "GAMES: the six WIDE reference games (the largest range of a seat has at least 10 hands): rg-hu-river, rg-river3, rg-hu-turn, rg-turn3, rg-turn4, rg-icm3-river. "
    "SEEDS: 5141 to 5152, paired. BUDGET: " + timesText(c) + " of training. Units run one at a time, so that the threaded arms have the machine to themselves; the order of the arms rotates with the seed. "
    "MEASURE and STATISTIC as in part pruning; baseline rbes-b1-t1; one interval per game and threaded arm (12), each at level 0.05/12. "
    "RULE, fixed before measuring. T1: the equal-deals check passes (20,000 sampled deals of the first seed, every arm, every game, to the last bit; a frozen batch writes the same state for every thread count). "
    "T2: at least 11 of 12 seeds valid for every game and arm. "
    "T3: a threaded arm is RECOMMENDED for rbes on wide games on this machine when it is better on at least 4 of the 6 games and worse on none. T4: it is NOT RECOMMENDED when it is worse on any game. Otherwise unresolved. "
    "T5: no outcome changes a default in 5.14. "
    "LIMITS: these games are small: one deal costs microseconds, so a batch of a few deals is little work to share and the fixed cost of handing it to threads weighs most here. The result does not carry over to large games, for which no exact NashConv exists; part scaling measures deals per second there and says nothing about quality.";
  return t;
}
static std::string slurp(const std::string &p) { std::ifstream f(p, std::ios::binary); return std::string{std::istreambuf_iterator<char>(f), {}}; }
static bool exists(const std::string &p) { std::ifstream f(p); return f.good(); }
static void makeDir(const std::string &p) {
#ifdef _WIN32
  _mkdir(p.c_str());
#else
  mkdir(p.c_str(), 0777);
#endif
}
static std::string cpuName() {
  unsigned a, b, c, d; char s[49] = {}; if (__get_cpuid_max(0x80000000u, nullptr) < 0x80000004u) return "unknown";
  for (unsigned i = 0; i < 3; i++) { __get_cpuid(0x80000002u + i, &a, &b, &c, &d); std::memcpy(s + 16 * i, &a, 4); std::memcpy(s + 16 * i + 4, &b, 4); std::memcpy(s + 16 * i + 8, &c, 4); std::memcpy(s + 16 * i + 12, &d, 4); }
  std::string r = s; while (!r.empty() && r.front() == ' ') r.erase(r.begin()); while (!r.empty() && r.back() == ' ') r.pop_back(); return r;
}
static void bindCpu(int cpu) {
  if (cpu < 0) return;
#ifdef _WIN32
  SetProcessAffinityMask(GetCurrentProcess(), (DWORD_PTR)1 << cpu);
#else
  cpu_set_t s; CPU_ZERO(&s); CPU_SET(cpu, &s); sched_setaffinity(0, sizeof s, &s);
#endif
}
static std::string exePath(const char *argv0) {
#ifdef _WIN32
  char buf[4096]; DWORD n = GetModuleFileNameA(nullptr, buf, sizeof buf); (void)argv0; return std::string(buf, n);
#else
  char buf[4096]; ssize_t n = readlink("/proc/self/exe", buf, sizeof buf); return n > 0 ? std::string(buf, n) : std::string(argv0);
#endif
}
static std::string dirOf(const std::string &p) { size_t k = p.find_last_of("/\\"); return k == std::string::npos ? "." : p.substr(0, k); }
// the spec files: next to the program, or in source/tools of a release folder
static std::string specDir(const std::string &dir) {
  for (const char *rel : {"/eqtime-specs", "/source/tools/eqtime-specs", "/../../source/tools/eqtime-specs", "/../tools/eqtime-specs"}) if (exists(dir + rel + "/hu-river-9001.json")) return dir + rel;
  return dir + "/eqtime-specs";
}
// ---- one training run and its exact NashConv ----
struct Deadline { Clock::time_point end; volatile int stop; bool timed; };
static void tick(void *ctx, long long, long long) { auto &d = *static_cast<Deadline *>(ctx); if (d.timed && Clock::now() >= d.end) d.stop = 1; }
static bool replaceOnce(std::string &s, const std::string &a, const std::string &b) { size_t p = s.find(a); if (p == std::string::npos) return false; s.replace(p, a.size(), b); return true; }
static bool armSpec(std::string &spec, const Arm &arm, std::string &why) {
  if (arm.batch > 1) {
    if (!replaceOnce(spec, "\"batchDeals\":1,", "\"batchDeals\":" + std::to_string(arm.batch) + ",") || !replaceOnce(spec, "\"actionStreams\":\"shared\"", "\"actionStreams\":\"deal\"")) { why = "spec: no batchDeals 1 / shared action streams to replace"; return false; }
  }
  size_t k = spec.find('{'); spec = spec.substr(0, k + 1) + arm.add + spec.substr(k + 1); return true;
}
static double fieldOf(const std::string &doc, const char *key, size_t from = 0) {
  std::string k = std::string("\"") + key + "\":"; size_t p = doc.find(k, from); if (p == std::string::npos) return NAN; return em_parse_double(doc.c_str() + p + k.size(), nullptr);
}
struct Run { bool ok = false; std::string error, info; double seconds = 0, nashConv = 0; long long iterations = 0, deals = 0; bool limit = false; double gainSeconds = 0; };
static Run runOne(std::string spec, const Arm &arm, double seconds, long long deals, double memoryMiB, bool gain) {
  Run r; char err[512] = "";
  if (!armSpec(spec, arm, r.error)) return r;
  MW *m = mw_create(spec.data(), spec.size(), memoryMiB, err, sizeof err);
  if (!m) { r.error = std::string("create: ") + err; return r; }
  const auto begin = Clock::now(); Deadline d{begin + std::chrono::microseconds((long long)(seconds * 1e6)), 0, deals == 0};
  if (!mw_train(m, deals ? deals / arm.batch : mw_max_updates(m), arm.threads, &d.stop, tick, &d, err, sizeof err)) { r.error = std::string("train: ") + err; mw_free(m); return r; }
  r.seconds = std::chrono::duration<double>(Clock::now() - begin).count();
  JB info; jb_init(&info); mw_info(m, &info); r.info.assign(info.s, info.n); jb_free(&info);
  r.iterations = (long long)fieldOf(r.info, "iterations"); r.deals = (long long)fieldOf(r.info, "trainingDeals"); r.limit = r.info.find("\"limitReached\":true") != std::string::npos;
  if (!gain) { mw_free(m); r.ok = true; return r; }
  const char *q = "{\"method\":\"exact\",\"policy\":\"average\",\"device\":\"cpu\",\"threads\":1,\"timeLimitMs\":3600000,\"maxVisits\":2000000000,\"memoryMiB\":2048}";
  JB out; jb_init(&out); volatile int cancel = 0; const auto g0 = Clock::now();
  const int status = mw_response_gain(m, q, std::strlen(q), &out, err, sizeof err, &cancel);
  r.gainSeconds = std::chrono::duration<double>(Clock::now() - g0).count();
  if (status != 200) { r.error = std::string("gain: ") + err; jb_free(&out); mw_free(m); return r; }
  std::string doc(out.s, out.n); jb_free(&out); mw_free(m);
  size_t p = doc.find("\"seats\":["); if (p == std::string::npos) { r.error = "gain: no seats"; return r; }
  double sum = 0; int n = 0;
  for (;;) {
    size_t b = doc.find("\"bestResponseValue\":", p); if (b == std::string::npos) break;
    size_t open = doc.rfind('{', b), close = doc.find('}', b); size_t v = doc.find("\"policyValue\":", open);
    if (v == std::string::npos || v > close) { r.error = "gain: seat without policyValue"; return r; }
    sum += em_parse_double(doc.c_str() + b + 20, nullptr) - em_parse_double(doc.c_str() + v + 14, nullptr); n++; p = b + 20;
  }
  if (!n || !std::isfinite(sum)) { r.error = "gain: no values"; return r; }
  r.nashConv = sum; r.ok = true; return r;
}
static std::string hex(double v) { unsigned long long u; std::memcpy(&u, &v, 8); char b[20]; std::snprintf(b, sizeof b, "%016llx", u); return b; }
static std::string row(const std::string &game, int seed, const std::string &arm, const char *kind, double budget, const Run &r) {
  char b[900];
  if (!r.ok) std::snprintf(b, sizeof b, "{\"game\":\"%s\",\"seed\":%d,\"arm\":\"%s\",\"kind\":\"%s\",\"budget\":%g,\"error\":\"%s\"}", game.c_str(), seed, arm.c_str(), kind, budget, r.error.c_str());
  else std::snprintf(b, sizeof b, "{\"game\":\"%s\",\"seed\":%d,\"arm\":\"%s\",\"kind\":\"%s\",\"budget\":%g,\"nashConv\":%.17g,\"bits\":\"%s\",\"trainSeconds\":%.4f,\"iterations\":%lld,\"deals\":%lld,\"limitReached\":%s,\"gainSeconds\":%.3f}",
                     game.c_str(), seed, arm.c_str(), kind, budget, r.nashConv, hex(r.nashConv).c_str(), r.seconds, r.iterations, r.deals, r.limit ? "true" : "false", r.gainSeconds);
  return b;
}
static int unit(const std::string &dir, const Config &c, const std::string &game, int seed, int cpu, const std::string &out) {
  bindCpu(cpu);
  std::string spec = slurp(specDir(dir) + "/" + game + "-" + std::to_string(seed) + ".json");
  if (spec.empty()) { std::fprintf(stderr, "no spec for %s seed %d in %s\n", game.c_str(), seed, specDir(dir).c_str()); return 2; }
  std::string rows; const size_t A = c.arms.size();
  if (seed == c.seeds[0]) for (size_t a = 0; a < A; a++) rows += row(game, seed, c.arms[a].name, "deals", (double)c.checkDeals, runOne(spec, c.arms[a], 0, c.checkDeals, 512, true)) + "\n";
  for (double t : c.times) for (size_t k = 0; k < A; k++) { const size_t a = (k + (size_t)seed) % A; rows += row(game, seed, c.arms[a].name, "time", t, runOne(spec, c.arms[a], t, 0, 512, true)) + "\n"; }
  std::string f = out + "/units/" + game + "-" + std::to_string(seed) + ".jsonl", tmp = f + ".tmp";
  { std::ofstream o(tmp, std::ios::binary); o << rows; if (!o.good()) return 3; }
  std::remove(f.c_str()); return std::rename(tmp.c_str(), f.c_str()) ? 3 : 0;
}
// ---- statistics ----
static double betacf(double a, double b, double x) {
  double qab = a + b, qap = a + 1, qam = a - 1, c = 1, d = 1 - qab * x / qap; d = 1 / (std::fabs(d) > 1e-300 ? d : 1e-300); double h = d;
  for (int m = 1; m < 400; m++) {
    int m2 = 2 * m; double aa = m * (b - m) * x / ((qam + m2) * (a + m2)); d = 1 + aa * d; d = 1 / (std::fabs(d) > 1e-300 ? d : 1e-300); c = 1 + aa / c; if (std::fabs(c) < 1e-300) c = 1e-300; h *= d * c;
    aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2)); d = 1 + aa * d; d = 1 / (std::fabs(d) > 1e-300 ? d : 1e-300); c = 1 + aa / c; if (std::fabs(c) < 1e-300) c = 1e-300; double de = d * c; h *= de;
    if (std::fabs(de - 1) < 1e-15) break;
  }
  return h;
}
static double tCdf(double t, double df) {
  double x = df / (df + t * t), a = df / 2, b = 0.5;
  double bt = x > 0 && x < 1 ? std::exp(std::lgamma(a + b) - std::lgamma(a) - std::lgamma(b) + a * std::log(x) + b * std::log(1 - x)) : 0;
  double ib = x < (a + 1) / (a + b + 2) ? bt * betacf(a, b, x) / a : 1 - bt * betacf(b, a, 1 - x) / b;
  return t >= 0 ? 1 - ib / 2 : ib / 2;
}
static double tQuantile(double p, double df) { double lo = 0, hi = 1000; for (int i = 0; i < 200; i++) { double mid = (lo + hi) / 2; (tCdf(mid, df) < p ? lo : hi) = mid; } return (lo + hi) / 2; }
struct Cell { double nc = NAN; long long deals = 0; bool limit = false, ok = false; std::string bits; };
struct Contrast { int n = 0; double ratio = NAN, lo = NAN, hi = NAN; std::string verdict = "no data"; int lower = 0, higher = 0; double medBase = NAN, medCand = NAN, dealRatio = NAN; };
static double median(std::vector<double> v) { if (v.empty()) return NAN; std::sort(v.begin(), v.end()); size_t n = v.size(); return n % 2 ? v[n / 2] : (v[n / 2 - 1] + v[n / 2]) / 2; }
static std::string stringAt(const std::string &l, const char *key) { std::string k = std::string("\"") + key + "\":\""; size_t p = l.find(k); if (p == std::string::npos) return ""; size_t e = l.find('"', p + k.size()); return l.substr(p + k.size(), e - p - k.size()); }
static std::string num(double v) { char b[40]; std::snprintf(b, sizeof b, "%.6g", v); return std::isfinite(v) ? b : "null"; }
static int analyze(const std::string &dir, const std::string &out, const Config &c) {
  std::map<std::string, Cell> cells; int rowsN = 0, errors = 0; std::string raw, errorText;
  for (auto &g : c.games) for (int s : c.seeds) {
    std::ifstream f(out + "/units/" + g + "-" + std::to_string(s) + ".jsonl"); std::string l;
    while (std::getline(f, l)) { if (l.size() < 5) continue; raw += l + "\n"; rowsN++;
      std::string key = g + "|" + std::to_string(s) + "|" + stringAt(l, "arm") + "|" + stringAt(l, "kind") + "|" + std::to_string(fieldOf(l, "budget"));
      Cell x; if (l.find("\"error\"") != std::string::npos) { errors++; if (errorText.size() < 1500) errorText += l + "\n"; }
      else { x.ok = true; x.nc = fieldOf(l, "nashConv"); x.deals = (long long)fieldOf(l, "deals"); x.limit = l.find("\"limitReached\":true") != std::string::npos; x.bits = stringAt(l, "bits"); }
      cells[key] = x; }
  }
  { std::ofstream o(out + "/raw.jsonl", std::ios::binary); o << raw; }
  auto cell = [&](const std::string &g, int s, const std::string &arm, const char *kind, double b) -> const Cell * { auto it = cells.find(g + "|" + std::to_string(s) + "|" + arm + "|" + kind + "|" + std::to_string(b)); return it == cells.end() || !it->second.ok ? nullptr : &it->second; };
  std::string ref = slurp(specDir(dir) + (c.quick ? "/reference-quick.json" : "/reference.json")); int checked = 0, same = 0; std::string differing;
  for (auto &g : c.games) for (auto &arm : c.arms) {
    const Cell *x = cell(g, c.seeds[0], arm.name, "deals", (double)c.checkDeals);
    // the reference names a threaded arm without its thread count: a frozen batch writes one state for every thread count
    std::string key = "\"" + g + " " + arm.name.substr(0, arm.name.rfind("-t") == std::string::npos ? arm.name.size() : arm.name.rfind("-t")) + "\":\""; size_t p = ref.find(key);
    checked++; if (p == std::string::npos) { differing += g + "/" + arm.name + "(no reference) "; continue; }
    std::string want = ref.substr(p + key.size(), 16);
    if (x && x->bits == want) same++; else differing += g + "/" + arm.name + " ";
  }
  const bool check = same == checked;
  const size_t K = c.candidates.size(); const double primary = *std::max_element(c.times.begin(), c.times.end());
  const double levelP = 0.05 / (c.games.size() * K), levelS = 0.05 / (c.games.size() * K * c.times.size());
  auto contrast = [&](const std::string &g, double b, const Arm &cand, const Arm &base, double level) {
    Contrast r; std::vector<double> d, nb, ncv, dr;
    for (int s : c.seeds) { const Cell *x = cell(g, s, cand.name, "time", b), *y = cell(g, s, base.name, "time", b); if (!x || !y) continue;
      d.push_back(std::log(std::max(x->nc, 1e-12) / std::max(y->nc, 1e-12))); nb.push_back(y->nc); ncv.push_back(x->nc); if (y->deals > 0) dr.push_back((double)x->deals / y->deals); }
    r.n = (int)d.size(); if (r.n < 3) return r;
    double mean = 0; for (double v : d) mean += v; mean /= r.n; double ss = 0; for (double v : d) ss += (v - mean) * (v - mean); double sd = std::sqrt(ss / (r.n - 1)), se = sd / std::sqrt((double)r.n);
    double q = sd > 0 ? tQuantile(1 - level / 2, r.n - 1) : 0, lo = mean - q * se, hi = mean + q * se;
    r.ratio = std::exp(mean); r.lo = std::exp(lo); r.hi = std::exp(hi); r.verdict = sd == 0 && mean == 0 ? "identical" : hi < 0 ? "better" : lo > 0 ? "worse" : "unresolved";
    for (double v : d) { r.lower += v < 0; r.higher += v > 0; } r.medBase = median(nb); r.medCand = median(ncv); r.dealRatio = median(dr); return r;
  };
  const Arm &base = c.arms[c.baseline]; char b[900]; std::string txt, js;
  js = "{\"tool\":\"eqtime514\",\"part\":\"" + c.part + "\",\"engineBuild\":\"" EM_BUILD_ID "\",\"quick\":" + (c.quick ? "true" : "false") + ",\"rows\":" + std::to_string(rowsN) + ",\"errors\":" + std::to_string(errors) +
       ",\"equalDealsCheck\":{\"compared\":" + std::to_string(checked) + ",\"identical\":" + std::to_string(same) + ",\"passed\":" + (check ? "true" : "false") + ",\"differing\":\"" + differing + "\"},\"baseline\":\"" + base.name + "\",\"contrasts\":[";
  std::snprintf(b, sizeof b, "EightMax 5.14 equal training time, part %s%s\nEngine build %s. Processor: %s (%u logical).\nRows %d, errors %d.\nEqual-deals check (the program is the program that was validated): %d of %d values identical to the Linux build: %s\n",
                c.part.c_str(), c.quick ? "  [QUICK TRIAL - NOT A RESULT]" : "", EM_BUILD_ID, cpuName().c_str(), std::thread::hardware_concurrency(), rowsN, errors, same, checked, check ? "PASSED" : "FAILED");
  txt += b; if (!differing.empty()) txt += "  differing: " + differing + "\n"; if (!errorText.empty()) txt += "First error rows:\n" + errorText;
  std::snprintf(b, sizeof b, "\nRatio = geometric mean over seeds of NashConv(candidate) / NashConv(%s); below 1 favours the candidate.\nPrimary family: %g s, level 0.05/%d. Secondary: every budget, level 0.05/%d.\n\n%-14s %-10s %-14s %6s %5s %8s %19s %-10s %-10s %9s %11s %11s\n",
                base.name.c_str(), primary, (int)(c.games.size() * K), (int)(c.games.size() * K * c.times.size()), "game", "class", "candidate", "budget", "seeds", "ratio", "primary interval", "primary", "secondary", "deals c/b", "NC base", "NC cand");
  txt += b; bool first = true;
  struct Tally { int games = 0, better = 0, worseP = 0, worseS = 0, unresolved = 0, minSeeds = 1000; std::string worse; };
  std::map<std::string, std::map<std::string, Tally>> tally; std::map<std::string, int> limitOnly;
  for (size_t ci : c.candidates) { const Arm &cand = c.arms[ci];
    for (auto &g : c.games) {
      const char *cls = INSET(FEW, g) ? "few hands" : INSET(RANGES, g) ? "ranges" : "tournament"; const bool wide = INSET(WIDE, g);
      for (double t : c.times) {
        Contrast s = contrast(g, t, cand, base, levelS), p = t == primary ? contrast(g, t, cand, base, levelP) : Contrast();
        for (int sd : c.seeds) { const Cell *x = cell(g, sd, cand.name, "time", t), *y = cell(g, sd, base.name, "time", t); if (x && x->limit && !(y && y->limit)) limitOnly[cand.name]++; }
        for (const char *k : {cls, wide ? "WIDE" : "", "all games"}) { if (!*k) continue; Tally &T = tally[cand.name][k];
          if (t == primary) { T.games++; T.better += p.verdict == "better"; T.worseP += p.verdict == "worse"; T.unresolved += p.verdict == "unresolved"; T.minSeeds = std::min(T.minSeeds, p.n); }
          if (s.verdict == "worse" || p.verdict == "worse") { T.worseS += s.verdict == "worse"; char w[60]; std::snprintf(w, sizeof w, "%s@%gs ", g.c_str(), t); T.worse += w; } }
        char iv[40] = "-"; if (t == primary) std::snprintf(iv, sizeof iv, "[%.3f, %.3f]", p.lo, p.hi);
        std::snprintf(b, sizeof b, "%-14s %-10s %-14s %5gs %5d %8.3f %19s %-10s %-10s %9.3f %11.3g %11.3g\n", g.c_str(), wide ? "WIDE" : cls, cand.name.c_str(), t, s.n, s.ratio, iv, t == primary ? p.verdict.c_str() : "", s.verdict.c_str(), s.dealRatio, s.medBase, s.medCand); txt += b;
        js += std::string(first ? "" : ",") + "{\"game\":\"" + g + "\",\"class\":\"" + cls + "\",\"wide\":" + (wide ? "true" : "false") + ",\"candidate\":\"" + cand.name + "\",\"budget\":" + num(t) + ",\"seeds\":" + std::to_string(s.n) + ",\"ratio\":" + num(s.ratio) +
              ",\"secondary\":{\"interval\":[" + num(s.lo) + "," + num(s.hi) + "],\"verdict\":\"" + s.verdict + "\"},\"lowerInSeeds\":" + std::to_string(s.lower) + ",\"higherInSeeds\":" + std::to_string(s.higher) +
              ",\"medianNashConvBaseline\":" + num(s.medBase) + ",\"medianNashConvCandidate\":" + num(s.medCand) + ",\"medianDealsRatio\":" + num(s.dealRatio);
        if (t == primary) js += ",\"primary\":{\"interval\":[" + num(p.lo) + "," + num(p.hi) + "],\"verdict\":\"" + p.verdict + "\"}";
        js += "}"; first = false;
      }
    }
    txt += "\n";
  }
  js += "],\"decisions\":{"; first = true; const int needSeeds = c.quick ? 3 : (int)c.seeds.size() - (c.part == "pruning" ? 2 : 1);
  for (size_t ci : c.candidates) { const Arm &cand = c.arms[ci]; std::string decision, lines;
    for (auto &kv : tally[cand.name]) { const Tally &T = kv.second;
      std::snprintf(b, sizeof b, "  %-14s %-10s: %d games; primary better %d, unresolved %d, worse %d; secondary worse %d; fewest valid seeds %d\n", cand.name.c_str(), kv.first.c_str(), T.games, T.better, T.unresolved, T.worseP, T.worseS, T.minSeeds); lines += b; }
    const Tally &all = tally[cand.name]["all games"];
    if (c.quick) decision = "QUICK TRIAL: no decision.";
    else if (!check) decision = "the equal-deals check FAILED: nothing is decided.";
    else if (all.minSeeds < needSeeds) decision = "incomplete (too few valid seeds): nothing is decided.";
    else if (c.part == "pruning") {
      if (all.worseP + all.worseS > 0) decision = "NOT RECOMMENDED (rule Q4): worse in " + all.worse;
      else { std::string rec; for (const char *k : {"few hands", "ranges", "tournament"}) { const Tally &T = tally[cand.name][k]; if (2 * T.better >= T.games && T.worseS == 0 && T.games) rec += std::string(rec.empty() ? "" : ", ") + k; }
        decision = rec.empty() ? "EXPERIMENTAL, no resolved benefit (rule Q4): better on " + std::to_string(all.better) + " of " + std::to_string(all.games) + " games, worse on none." : "RECOMMENDED as an opt-in (rule Q3) for: " + rec + "."; }
    } else {
      if (all.worseP + all.worseS > 0) decision = "NOT RECOMMENDED on this machine (rule T4): worse in " + all.worse;
      else if (all.better >= 4) decision = "RECOMMENDED for rbes on wide games on this machine (rule T3): better on " + std::to_string(all.better) + " of " + std::to_string(all.games) + " games, worse on none.";
      else decision = "unresolved: better on " + std::to_string(all.better) + " of " + std::to_string(all.games) + " games, worse on none.";
    }
    txt += lines + "  DECISION for " + cand.name + ": " + decision + "\n\n";
    js += std::string(first ? "" : ",") + "\"" + cand.name + "\":{\"decision\":\"" + decision + "\",\"tableLimitOnlyInCandidate\":" + std::to_string(limitOnly[cand.name]) + "}"; first = false;
  }
  txt += "No default changes in 5.14 whatever the outcome. No percentage of GTO follows from any of this.\n";
  js += "},\"processor\":\"" + cpuName() + "\",\"logicalProcessors\":" + std::to_string(std::thread::hardware_concurrency()) + "}\n";
  { std::ofstream o(out + "/summary.json", std::ios::binary); o << js; } { std::ofstream o(out + "/summary.txt", std::ios::binary); o << txt; }
  std::printf("\n%s", txt.c_str()); std::fflush(stdout); return 0;
}
// ---- part scaling: deals per second by batch size and thread count (no quality measure) ----
static int scaling(const std::string &dir, const std::string &out, bool quick) {
  const unsigned logical = std::max(1u, std::thread::hardware_concurrency()); makeDir(out);
  std::vector<int> T; for (int t : {1, 2, 4, 8, 12, 16, 24, 32}) if ((unsigned)t <= logical) T.push_back(t); if ((unsigned)T.back() != logical && logical <= 64) T.push_back((int)logical);
  const double seconds = quick ? 0.5 : 3.0; std::string js = "{\"tool\":\"eqtime514\",\"part\":\"scaling\",\"engineBuild\":\"" EM_BUILD_ID "\",\"quick\":" + std::string(quick ? "true" : "false") + ",\"processor\":\"" + cpuName() + "\",\"logicalProcessors\":" + std::to_string(logical) + ",\"secondsPerRun\":" + num(seconds) + ",\"rows\":[";
  std::string txt = "EightMax 5.14, part scaling: sampled deals per second" + std::string(quick ? "  [QUICK TRIAL]" : "") + "\nEngine build " EM_BUILD_ID ". Processor: " + cpuName() + " (" + std::to_string(logical) + " logical). " + num(seconds) + " s per run; table limit 2048 MiB.\nA frozen batch writes the same state for every thread count; more deals per second is not better quality per second.\n\n";
  char b[400]; std::snprintf(b, sizeof b, "%-12s %-8s %6s %7s %12s %8s   %s\n", "fixture", "trainer", "batch", "threads", "deals/s", "x 1 thr", "seconds by stage: deal, traverse, merge"); txt += b; std::printf("%s", txt.c_str()); std::fflush(stdout); bool first = true;
  for (const char *fx : {"flop6-jack", "flop3-kings"}) {
    std::string spec = slurp(specDir(dir) + "/fixture-" + fx + ".json"); if (spec.empty()) { std::fprintf(stderr, "no spec for %s\n", fx); return 2; }
    for (int rb = 0; rb < 2; rb++) {
      for (int B : {1, 16, 64}) { double one = 0;
        for (int t : T) { if (B == 1 && t > 1) break; if (quick && t > 4) break;
          Arm arm{rb ? "rbes" : "default", std::string("\"trainingStreams\":\"philox64\",") + (rb ? "\"estimator\":\"rbes\"," : ""), B, t};
          Run r = runOne(spec, arm, seconds, 0, 2048, false); std::string line;
          if (!r.ok) { std::snprintf(b, sizeof b, "%-12s %-8s %6d %7d   ERROR %s\n", fx, arm.name.c_str(), B, t, r.error.c_str()); line = b; }
          else { const double rate = r.deals / r.seconds; if (t == 1) one = rate; size_t sp = r.info.find("\"seconds\":{");
            std::snprintf(b, sizeof b, "%-12s %-8s %6d %7d %12.0f %8.2f   %.2f, %.2f, %.2f\n", fx, arm.name.c_str(), B, t, rate, one > 0 ? rate / one : 0.0, fieldOf(r.info, "deal", sp), fieldOf(r.info, "traverse", sp), fieldOf(r.info, "merge", sp)); line = b;
            js += std::string(first ? "" : ",") + "{\"fixture\":\"" + fx + "\",\"trainer\":\"" + arm.name + "\",\"batchDeals\":" + std::to_string(B) + ",\"threads\":" + std::to_string(t) + ",\"threadsUsed\":" + num(fieldOf(r.info, "threads")) + ",\"dealsPerSecond\":" + num(rate) + ",\"deals\":" + std::to_string(r.deals) + ",\"seconds\":" + num(r.seconds) + "}"; first = false; }
          txt += line; std::printf("%s", line.c_str()); std::fflush(stdout);
        } } } }
  js += "]}\n"; { std::ofstream o(out + "/scaling.json", std::ios::binary); o << js; } { std::ofstream o(out + "/scaling.txt", std::ios::binary); o << txt; } return 0;
}
static int runPart(const std::string &exe, const Config &c, int jobs, const std::string &out) {
  const std::string dir = dirOf(exe); const unsigned logical = std::max(1u, std::thread::hardware_concurrency());
  if (c.serial) jobs = 1; else if (jobs <= 0) jobs = (int)std::max(1u, std::min(6u, logical / 4)); if (jobs > 16) jobs = 16;
  makeDir(out); makeDir(out + "/units");
  std::string plan = "{\"tool\":\"eqtime514\",\"part\":\"" + c.part + "\",\"engineBuild\":\"" EM_BUILD_ID "\",\"quick\":" + (c.quick ? "true" : "false") + ",\"plan\":\"" + planText(c) + "\"}\n";
  if (exists(out + "/plan.json")) { if (slurp(out + "/plan.json") != plan) { std::fprintf(stderr, "%s holds another plan (other part, budgets, thread count or program): not continued. Choose another --out.\n", out.c_str()); return 1; } }
  else { std::ofstream o(out + "/plan.json", std::ios::binary); o << plan; }
  struct U { std::string g; int s; }; std::vector<U> todo; int have = 0;
  for (int s : c.seeds) for (auto &g : c.games) { if (exists(out + "/units/" + g + "-" + std::to_string(s) + ".jsonl")) have++; else todo.push_back({g, s}); }
  double perUnit = 0; for (double t : c.times) perUnit += c.arms.size() * t;
  std::printf("EightMax 5.14 equal training time, part %s%s\nProcessor: %s, %u logical processors; %d unit(s) at a time%s.\n%d units done earlier, %d to run; about %.0f minutes of training plus the exact evaluations (which take about as long again).\nResults: %s\n\n",
              c.part.c_str(), c.quick ? " (QUICK TRIAL)" : "", cpuName().c_str(), logical, jobs, c.part == "threads" ? (", N = " + std::to_string(c.N) + " threads").c_str() : "", have, (int)todo.size(), todo.size() * perUnit / jobs / 60.0, out.c_str()); std::fflush(stdout);
  { std::ofstream o(out + "/machine.txt", std::ios::app); o << "processor: " << cpuName() << "; logical processors: " << logical << "; jobs: " << jobs << "; N: " << c.N << "; units to run: " << todo.size() << "\n"; }
  std::atomic<size_t> next{0}; std::atomic<int> done{0}, failed{0}; std::mutex io; const auto t0 = Clock::now(); std::vector<std::thread> pool;
  std::string timesArg; for (double t : c.times) { char b[32]; std::snprintf(b, sizeof b, "%s%g", timesArg.empty() ? "" : ",", t); timesArg += b; }
  for (int j = 0; j < jobs; j++) pool.emplace_back([&, j] {
    for (;;) { size_t i = next++; if (i >= todo.size()) return;
      const int cpu = c.serial || (jobs == 1 && logical < 4) ? -1 : (2 * j < (int)logical && jobs * 2 <= (int)logical ? 2 * j : j);
      std::string cmd = "\"" + exe + "\" --unit " + c.part + " " + todo[i].g + " " + std::to_string(todo[i].s) + " " + std::to_string(cpu) + " \"" + out + "\" " + (c.quick ? "1" : "0") + " " + std::to_string(c.N) + " " + timesArg;
#ifdef _WIN32
      cmd = "\"" + cmd + "\"";
#endif
      const int rc = std::system(cmd.c_str()); if (rc) failed++; const int d = ++done;
      std::lock_guard<std::mutex> l(io); const double el = std::chrono::duration<double>(Clock::now() - t0).count();
      std::printf("  %4d / %d  %-14s seed %d%s   elapsed %.1f min, about %.1f min left\n", d, (int)todo.size(), todo[i].g.c_str(), todo[i].s, rc ? "  FAILED TO RUN" : "", el / 60, el / d * (todo.size() - d) / 60); std::fflush(stdout); }
  });
  for (auto &t : pool) t.join();
  if (failed) std::printf("\n%d unit(s) did not run. Start it again to retry them.\n", failed.load());
  const int rc = analyze(dir, out, c); return failed ? 1 : rc;
}
static std::vector<double> parseTimes(const char *s) { std::vector<double> v; const char *p = s; while (*p) { char *e; double x = std::strtod(p, &e); if (e == p) break; if (x > 0 && x <= 3600) v.push_back(x); p = *e == ',' ? e + 1 : e; } return v; }
int main(int argc, char **argv) {
  const std::string exe = exePath(argv[0]), dir = dirOf(exe);
  if (argc == 10 && !std::strcmp(argv[1], "--unit")) { Config c = config(argv[2], std::atoi(argv[7]) != 0, std::atoi(argv[8]), parseTimes(argv[9])); return unit(dir, c, argv[3], std::atoi(argv[4]), std::atoi(argv[5]), argv[6]); }
  if (argc == 2 && !std::strcmp(argv[1], "--build-id")) { std::puts("EightMaxBuild=" EM_BUILD_ID); return 0; }
  if (argc >= 3 && !std::strcmp(argv[1], "reference")) {   // development: the values of the equal-deals checks, every arm that any N can ask for
    const std::string P = "\"trainingStreams\":\"philox64\",", R = P + "\"estimator\":\"rbes\",";
    for (int quick = 0; quick < 2; quick++) { std::string t; Config pc = config("pruning", quick, 4, {}), tc = config("threads", quick, 4, {});
      std::vector<Arm> arms = pc.arms; arms.push_back({"rbes-b1", R, 1, 1}); arms.push_back({"default-b1", P, 1, 1}); for (int B : {2, 4, 8, 16, 32}) arms.push_back({"rbes-b" + std::to_string(B), R, B, 2});
      std::vector<std::string> games = pc.games; for (auto &g : tc.games) if (std::find(games.begin(), games.end(), g) == games.end()) games.push_back(g);
      for (auto &g : games) { std::string spec = slurp(specDir(dir) + "/" + g + "-" + std::to_string(pc.seeds[0]) + ".json"); const bool inP = std::find(pc.games.begin(), pc.games.end(), g) != pc.games.end(), inT = std::find(tc.games.begin(), tc.games.end(), g) != tc.games.end();
        for (size_t a = 0; a < arms.size(); a++) { if (a < 3 ? !inP : !inT) continue; Run r = runOne(spec, arms[a], 0, pc.checkDeals, 512, true); if (!r.ok) { std::fprintf(stderr, "%s %s: %s\n", g.c_str(), arms[a].name.c_str(), r.error.c_str()); return 1; }
          t += std::string(t.empty() ? "{\n" : ",\n") + "\"" + g + " " + arms[a].name + "\":\"" + hex(r.nashConv) + "\""; std::printf("%s %s %s\n", g.c_str(), arms[a].name.c_str(), hex(r.nashConv).c_str()); std::fflush(stdout); } }
      std::ofstream o(std::string(argv[2]) + (quick ? "/reference-quick.json" : "/reference.json"), std::ios::binary); o << t << "\n}\n"; }
    return 0;
  }
  const std::string cmd = argc >= 2 ? argv[1] : "";
  if (cmd != "pruning" && cmd != "threads" && cmd != "scaling" && cmd != "all" && cmd != "analyze") { std::fprintf(stderr, "usage: eqtime pruning|threads|scaling|all [--quick] [--jobs N] [--threads N] [--times a,b] [--out DIR]\n       eqtime analyze DIR\n       eqtime --build-id\n"); return 2; }
  bool quick = false; int jobs = 0, N = 0; std::string out; std::vector<double> times;
  for (int i = 2; i < argc; i++) { if (!std::strcmp(argv[i], "--quick")) quick = true; else if (!std::strcmp(argv[i], "--jobs") && i + 1 < argc) jobs = std::atoi(argv[++i]); else if (!std::strcmp(argv[i], "--threads") && i + 1 < argc) N = std::atoi(argv[++i]);
    else if (!std::strcmp(argv[i], "--times") && i + 1 < argc) times = parseTimes(argv[++i]); else if (!std::strcmp(argv[i], "--out") && i + 1 < argc) out = argv[++i]; else if (cmd == "analyze" && out.empty()) out = argv[i]; else { std::fprintf(stderr, "unknown argument %s\n", argv[i]); return 2; } }
  if (N != 2 && N != 4 && N != 8) N = threadsFor(std::max(1u, std::thread::hardware_concurrency()));
  if (cmd == "analyze") {   // the part, the budgets and N are read from the stored plan
    std::string plan = slurp(out + "/plan.json"); if (plan.empty()) { std::fprintf(stderr, "no plan.json in %s\n", out.c_str()); return 1; }
    const std::string part = stringAt(plan, "part"); const bool q = plan.find("\"quick\":true") != std::string::npos;
    for (int n : {2, 4, 8}) for (const std::vector<double> &tt : {std::vector<double>{}, std::vector<double>{1, 4}, std::vector<double>{4}, std::vector<double>{4, 16}, std::vector<double>{1, 4, 16}, std::vector<double>{1}, std::vector<double>{16}}) {
      Config c = config(part, q, n, tt); if ("{\"tool\":\"eqtime514\",\"part\":\"" + c.part + "\",\"engineBuild\":\"" EM_BUILD_ID "\",\"quick\":" + (c.quick ? "true" : "false") + ",\"plan\":\"" + planText(c) + "\"}\n" == plan) return analyze(dir, out, c); }
    std::fprintf(stderr, "the plan in %s is not one this program writes\n", out.c_str()); return 1;
  }
  const std::string base = out.empty() ? dir + (quick ? "/equal-time-quick" : "/equal-time-results") : out; int rc = 0;
  if (cmd == "all") makeDir(base);
  if (cmd == "pruning" || cmd == "all") rc |= runPart(exe, config("pruning", quick, N, times), jobs, cmd == "all" || out.empty() ? (makeDir(base), base + "/pruning") : out);
  if (cmd == "threads" || cmd == "all") rc |= runPart(exe, config("threads", quick, N, cmd == "all" ? std::vector<double>{} : times), jobs, cmd == "all" || out.empty() ? (makeDir(base), base + "/threads") : out);
  if (cmd == "scaling" || cmd == "all") rc |= scaling(dir, cmd == "all" || out.empty() ? (makeDir(base), base + "/scaling") : out, quick);
  return rc;
}
