#!/usr/bin/env python3
"""EightMax 5.8: independent check of the TRAINED RESPONSE measure (source/native/response58.hpp).

`mwcli --response` trains, for one seat, a response strategy R against the other seats' average strategies and
reports gain(R) = V_seat(R, sigma_-seat) - V_seat(sigma), a lower bound of the seat's best-response gain. With
"saveStates" it writes one state file per seat in which
    the AVERAGE slot holds (R for the seat, sigma for the others)   and   the REGRET slot holds sigma
(regret matching over the stored non-negative numbers plays sigma).

This script shares no code with the engine. It reuses the betting rules, side-pot settlement and seven-card evaluator
of independent_br48.py (which are themselves independent of the engine) and adds its own reader of both table slots
and its own tree walk. For postflop chip-EV studies it checks, for every seat:

  1. FROZEN OPPONENTS  the other seats' strategies in the response state equal those of the original trained state
                       (every stored row, every probability, to 1e-12); the seat's "current" strategy in the response
                       state equals its original average strategy;
  2. VALUES            V_seat(sigma), V_seat(R, sigma_-seat) and the exact best-response value against sigma_-seat,
                       computed here by enumerating every deal, every card and every action, agree with the engine's
                       exact figures (relative tolerance 1e-9);
  3. DIRECTION         gain(R) <= best-response gain (tolerance 1e-9), from this script's own numbers;
  4. SAMPLED ESTIMATE  the engine's estimate from independent deals lies within its distribution-free interval of
                       this script's exact gain(R), and its distance in standard errors is recorded.

usage: independent_response58.py <mwcli> <spec.json> <trained.state> <work dir> [responseDeals=200000] [samples=204800] [seed=58]
prints a JSON report; exit 0 when every check holds for every seat.
"""
import importlib.util, itertools, json, os, pathlib, struct, subprocess, sys

here = pathlib.Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location('independent_br48', here / 'independent_br48.py')
ib = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(ib)   # definitions only; its main() is not run
CHANCE = ib.CHANCE

def read_slots(path):
    """{(betting path, range index, public cards): (average strategy, regret-matching strategy)} of an EMMW4 file."""
    b = open(path, 'rb').read(); assert b[:8] == b'EMMW4\0\0\0', 'not an EMMW4 state'
    hl = struct.unpack_from('<I', b, 8)[0]; h = json.loads(b[12:12 + hl]); o = 12 + hl
    if h.get('rowKeys'): raise SystemExit('grouped studies are not supported')
    sc = struct.unpack_from('<I', b, o)[0]; o += 4; parent = []; slot = []; length = []
    for i in range(sc): parent.append(struct.unpack_from('<I', b, o)[0]); slot.append(b[o + 4]); length.append(b[o + 7]); o += 9
    def path_of(i):
        p = []
        while i != 0 and i != 0xffffffff: p.append(slot[i]); i = parent[i]
        return tuple(reversed(p))
    rc = struct.unpack_from('<I', b, o)[0]; o += 4; rows = {}
    for _ in range(rc):
        st, hand = struct.unpack_from('<IH', b, o); cards = [c - 1 for c in b[o + 6:o + 11]]; o += 11; k = b[o]; o += 1
        vals = struct.unpack_from('<%dd' % (2 * k), b, o); o += 16 * k
        if h.get('rowSync'): o += 4
        L = length[st]; pub = tuple(sorted(cards[:3])) + tuple(cards[3:L]) if L >= 3 else ()
        reg = [x if x > 0 else 0.0 for x in vals[:k]]; avg = list(vals[k:]); ta = sum(avg); tr = sum(reg)
        rows[(path_of(st), hand, pub)] = ([x / ta for x in avg] if ta > 0 else None,      # None: no stored average -> uniform (the evaluator's fallback)
                                          [x / tr for x in reg] if tr > 0 else [1.0 / k] * k)
    return rows, h

def main():
    cli, spec_path, state, work = sys.argv[1:5]
    rdeals = int(sys.argv[5]) if len(sys.argv) > 5 else 200000; samples = int(sys.argv[6]) if len(sys.argv) > 6 else 204800; seed = int(sys.argv[7]) if len(sys.argv) > 7 else 58
    work = pathlib.Path(work); work.mkdir(parents=True, exist_ok=True)
    spec = json.load(open(spec_path)); g = ib.Game(spec); n = g.n
    hands = [[(h[1], h[2], h[3]) for h in seat] for seat in spec['hands']]; board0 = list(spec['board'])
    original, _ = read_slots(state)
    rq = work / 'request.json'; rq.write_text(json.dumps({'responseDeals': rdeals, 'samples': samples, 'seed': seed, 'exact': True, 'saveStates': str(work / 'response-seat')}))
    eng = json.loads(subprocess.run([cli, '--response', spec_path, state, str(rq), '256'], capture_output=True, text=True, check=True).stdout)
    deals = []
    for tup in itertools.product(*[range(len(s)) for s in hands]):
        cards = [c for p, i in enumerate(tup) for c in hands[p][i][:2]]
        if len(set(cards + board0)) != len(cards) + len(board0): continue
        w = 1.0
        for p, i in enumerate(tup): w *= hands[p][i][2]
        if w > 0: deals.append((tup, w))
    Z = sum(w for _, w in deals)
    mask_of = lambda tup: frozenset(c for p in range(n) for c in hands[p][tup[p]][:2])
    pubkey = lambda board: tuple(sorted(board[:3])) + tuple(board[3:])
    def acting(s):   # next state with a decision, a chance move or a terminal; forced single actions are skipped
        path = ()
        while True:
            p = g.actor(s)
            if p < 0: return s, None, None, None, path
            tos, facing = g.actions(s, p)
            if len(tos) > 1: return s, p, tos, facing, path
            s = g.advance(s, p, 0, tos, facing); path += (0,)
    report = []; ok = True
    for seat in range(n):
        rows, _ = read_slots(str(work / ('response-seat%d.state' % seat)))
        # 1. frozen opponents / preserved sigma. A row belongs to the seat that acts at its betting path.
        actor_of = {}
        def actor_at(path):
            if path in actor_of: return actor_of[path]
            s = g.root()
            for a in path:
                if a == CHANCE: s = g.next_street(s); continue
                p = g.actor(s); tos, facing = g.actions(s, p); s = g.advance(s, p, a, tos, facing)
            actor_of[path] = g.actor(s); return actor_of[path]
        worst_opp = worst_own = 0.0; missing = 0; own_rows = opp_rows = 0
        for key, (avg0, _) in original.items():
            if key not in rows: missing += 1; continue
            avg1, cur1 = rows[key]; k = len(cur1); ref = avg0 if avg0 is not None else [1.0 / k] * k
            if actor_at(key[0]) == seat: own_rows += 1; worst_own = max(worst_own, max(abs(x - y) for x, y in zip(cur1, ref)))
            else:
                opp_rows += 1; got = avg1 if avg1 is not None else [1.0 / k] * k
                worst_opp = max(worst_opp, max(abs(x - y) for x, y in zip(got, ref)), max(abs(x - y) for x, y in zip(cur1, ref)))
        extra_opp = sum(1 for key in rows if key not in original and actor_at(key[0]) != seat)
        frozen = missing == 0 and worst_opp <= 1e-12 and worst_own <= 1e-12 and extra_opp == 0
        def strat(key_path, p, hand, board, k, which):
            r = rows.get((key_path, hand, pubkey(board)))
            if r is None: return [1.0 / k] * k
            v = r[1] if p == seat and which == 'S' else r[0]   # the seat following sigma: regret slot; everything else: average slot
            if v is None: v = [1.0 / k] * k
            assert len(v) == k; return v
        def walk(own, s, path, board, weighted, mode):
            """sum over opponent tuples of weight * value(seat); mode 'R' | 'S' (follow a strategy) | 'B' (best response)."""
            if not weighted: return 0.0
            s, p, tos, facing, skipped = acting(s); path = path + skipped
            if p is None:
                if sum(s.live) <= 1 or s.blen == 5:
                    return sum(w * g.payoff(s, board, [hands[q][t[q]][:2] for q in range(n)])[seat] for t, w in weighted)
                t2 = g.next_street(s); d = 52 - s.blen - 2 * n; out = 0.0
                for x in range(52):
                    if x in board or x in hands[seat][own][:2]: continue
                    nw = [(t, w / d) for t, w in weighted if x not in mask_of(t)]
                    if nw: out += walk(own, t2, path + (CHANCE,), board + [x], nw, mode)
                return out
            k = len(tos)
            if p == seat:
                kids = [walk(own, g.advance(s, p, a, tos, facing), path + (a,), board, weighted, mode) for a in range(k)] if mode == 'B' else None
                if mode == 'B': return max(kids)
                sg = strat(path, p, own, board, k, mode)
                return sum(sg[a] * walk(own, g.advance(s, p, a, tos, facing), path + (a,), board, weighted, mode) for a in range(k) if sg[a] > 0)
            out = 0.0
            for a in range(k):
                nw = [(t, w * strat(path, p, t[p], board, k, mode)[a]) for t, w in weighted]; nw = [(t, w) for t, w in nw if w > 0]
                if nw: out += walk(own, g.advance(s, p, a, tos, facing), path + (a,), board, nw, mode)
            return out
        vs = vr = vb = 0.0
        for h in range(len(hands[seat])):
            mine = [(t, w) for t, w in deals if t[seat] == h]
            if not mine: continue
            vs += walk(h, g.root(), (), board0, mine, 'S'); vr += walk(h, g.root(), (), board0, mine, 'R'); vb += walk(h, g.root(), (), board0, mine, 'B')
        vs /= Z; vr /= Z; vb /= Z
        e = eng['seats'][seat]; ex = e['exact']; sm = e['sampled']
        scale = max(1.0, abs(vb))
        d_exact = max(abs(vs - ex['policyValue']), abs(vr - ex['responseValue']), abs(vb - ex['bestResponseValue']), abs(vb - ex['bestResponseValueFromResponseProfile']), abs((vr - vs) - ex['gain']))
        values_agree = d_exact <= 1e-9 * scale
        direction = (vr - vs) <= (vb - vs) + 1e-9 * scale
        gm = sm['gain']['mean']; se = sm['gain']['stdErr']; half = sm['bounded']['half']
        inside = sm['bounded']['withinBounds'] and half is not None and abs(gm - (vr - vs)) <= half
        z = (gm - (vr - vs)) / se if se and se > 0 else (0.0 if abs(gm - (vr - vs)) <= 1e-12 else float('inf'))
        seat_ok = frozen and values_agree and direction and inside; ok &= seat_ok
        report.append({'seat': seat, 'ok': seat_ok,
                       'frozenOpponents': {'ok': frozen, 'opponentRowsCompared': opp_rows, 'ownRowsCompared': own_rows, 'rowsMissingInResponseState': missing, 'opponentRowsAdded': extra_opp,
                                           'largestOpponentProbabilityDifference': worst_opp, 'largestOwnSigmaDifference': worst_own},
                       'independent': {'policyValue': vs, 'responseValue': vr, 'bestResponseValue': vb, 'responseGain': vr - vs, 'bestResponseGain': vb - vs, 'shareOfBestResponseGain': (vr - vs) / (vb - vs) if vb - vs > 0 else None},
                       'engineExact': {'policyValue': ex['policyValue'], 'responseValue': ex['responseValue'], 'bestResponseValue': ex['bestResponseValue'], 'gain': ex['gain'], 'bestResponseGain': ex['bestResponseGain']},
                       'largestExactDifference': d_exact, 'exactValuesAgree': values_agree, 'directionHolds': direction,
                       'engineSampled': {'mean': gm, 'stdErr': se, 'boundedHalf': half, 'opponentActions': sm.get('opponentActions'), 'samples': sm['samples'], 'standardErrorsFromExact': z, 'exactInsideBoundedInterval': inside}})
    print(json.dumps({'tool': 'independent_response58', 'spec': spec_path, 'state': state, 'players': n, 'deals': len(deals), 'responseDeals': rdeals, 'samples': samples, 'seed': seed,
                      'engineBuild': eng.get('build'), 'ok': ok, 'seats': report}, indent=1))
    sys.exit(0 if ok else 1)

if __name__ == '__main__': main()
