#!/usr/bin/env python3
"""EightMax 5.10: records the reference values of `mwcli --selftest510` (source/native/selftest510_*.hpp).

Usage: make_golden510.py <release root> <5.9 mwcli> <5.10 mwcli> <work dir>

  selftest510_golden59.hpp    SHA-256 of the states the UNCHANGED 5.9 program writes for shipped fixtures with the
                              default trainer (one deal per update; 64 deals per update on three threads). The 5.10
                              program must write the same bytes (check D1).
  selftest510_golden510.hpp   SHA-256 of the states the 5.10 program writes with {"estimator":"rbes"} (check R3: the
                              estimator is deterministic across the platforms of the release).
  tests/fixtures/golden510.json  SHA-256 of the states of the unchanged 5.9 program on the 20 reference games of the 5.10
                              experiment and on five fixtures, also with frozen batches (tests/v510.test.js).
  selftest510_reference.hpp   exact NashConv (mwcli --gain, method exact) after a fixed budget, default trainer and
                              rbes, one seed (the fixture's): a regression check of both trainers (check R4).

The 5.10 program used here must have been built from the same sources apart from these three files (they are part
of the source fingerprint, so the build identifier changes when they are written; the states do not depend on it).
Run only to re-record after an intended change of the estimator; a change of the default trainer's hashes is a defect.
"""
import sys, json, subprocess, pathlib, hashlib, os
BATCH = {'batchDeals': 64, 'actionStreams': 'deal'}; RB = {'estimator': 'rbes'}
GOLDEN59 = [('known-akq-river', 20000, False), ('flop3-kings-small', 20000, False), ('flop6-jack-small', 10000, False), ('icm8-bb-call-small', 20000, False), ('btn25-open-small', 20000, False),
            ('flop6-jack', 3000, False), ('flop3-kings', 6000, False), ('flop3-kings-detailed', 3000, False), ('icm8-bb-call', 6000, False), ('btn25-open', 3000, False),
            ('flop6-jack', 60, True), ('flop3-kings-detailed', 60, True), ('icm8-bb-call-small', 300, True), ('flop3-kings-small', 300, True)]
GOLDEN510 = [('known-akq-river', 9000, False), ('flop3-kings-small', 9000, False), ('flop6-jack-small', 6000, False), ('icm8-bb-call-small', 9000, False), ('btn25-open-small', 6000, False),
             ('flop3-kings', 1500, False), ('flop6-jack', 600, False), ('flop3-kings-detailed', 600, False), ('icm8-bb-call', 150, False),
             ('flop3-kings', 30, True), ('flop6-jack-small', 90, True), ('icm8-bb-call-small', 150, True)]
REFERENCE = [('known-akq-river', 20000), ('flop3-kings-small', 20000), ('icm8-bb-call-small', 20000), ('flop6-jack-small', 10000)]
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def spec(root, fixture, extra, path):
    s = json.loads((root / f'source/studies/{fixture}.emfix.json').read_text(encoding='utf-8-sig'))['variants'][0]['nativeSpec']; s.update(extra); path.write_text(json.dumps(s))
def train(cli, sp, updates, threads, out):
    env = dict(os.environ); env['EIGHTMAX_THREAD_CHOICE'] = 'fixed'
    p = subprocess.run([cli, str(sp), str(updates), str(threads), str(out), '512'], capture_output=True, text=True, env=env)
    if p.returncode: sys.exit(f'{cli} {sp}: {p.stderr[-300:]}')
def nashconv(cli, sp, st, q):
    q.write_text(json.dumps({'method': 'exact', 'policy': 'average', 'device': 'cpu', 'threads': 1, 'timeLimitMs': 1800000, 'maxVisits': 2000000000, 'memoryMiB': 512}))
    p = subprocess.run([cli, '--gain', str(sp), str(st), str(q), '512'], capture_output=True, text=True)
    if p.returncode: sys.exit('gain: ' + p.stderr[-300:])
    return sum(s['bestResponseValue'] - s['policyValue'] for s in json.loads(p.stdout)['seats'])
if __name__ == '__main__':
    if len(sys.argv) != 5: print(__doc__); sys.exit(2)
    root = pathlib.Path(sys.argv[1]).resolve(); old, new = str(pathlib.Path(sys.argv[2]).resolve()), str(pathlib.Path(sys.argv[3]).resolve()); work = pathlib.Path(sys.argv[4]).resolve(); work.mkdir(parents=True, exist_ok=True)
    sp, st, q = work / 'g.json', work / 'g.state', work / 'q.json'; native = root / 'source/native'
    lines = []
    for fx, upd, batch in GOLDEN59:
        spec(root, fx, BATCH if batch else {}, sp); train(old, sp, upd, 3 if batch else 1, st); lines.append('{"%s", %d, %s, "%s"},' % (fx, upd, 'true' if batch else 'false', sha(st)))
    (native / 'selftest510_golden59.hpp').write_text('\n'.join(lines) + '\n')
    lines = []
    for fx, upd, batch in GOLDEN510:
        spec(root, fx, {**RB, **(BATCH if batch else {})}, sp); train(new, sp, upd, 3 if batch else 1, st); lines.append('{"%s", %d, %s, "%s"},' % (fx, upd, 'true' if batch else 'false', sha(st)))
    (native / 'selftest510_golden510.hpp').write_text('\n'.join(lines) + '\n')
    lines = []
    for fx, upd in REFERENCE:
        spec(root, fx, {}, sp); train(new, sp, upd, 1, st); a = nashconv(new, sp, st, q)
        spec(root, fx, RB, sp); train(new, sp, upd, 1, st); b = nashconv(new, sp, st, q)
        lines.append('{"%s", %d, %s, %s},' % (fx, upd, repr(a), repr(b)))
    (native / 'selftest510_reference.hpp').write_text('\n'.join(lines) + '\n')
    # tests/fixtures/golden510.json: the states of the unchanged 5.9 program on the reference games of the 5.10 experiment
    # (tools/games510.js) and on shipped fixtures, for tests/v510.test.js.
    games = ['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'flop6', 'final8', 'bubble4', 'rg-hu-river', 'rg-river3', 'rg-hu-turn', 'rg-turn3', 'rg-turn4', 'rg-icm3-river', 'rg-bubble4', 'rg-flop6c',
             'early3-flop', 'mid3-turn', 'short8-push', 'bubble5-icm', 'sidepot3-icm']
    states = []
    for g in games:
        subprocess.run(['node', str(root / 'source/tools/games510.js'), 'spec', g, str(sp), '510'], check=True); per = json.loads(sp.read_text())['batchDeals']
        train(old, sp, 20000 // per, 1, st); states.append({'game': g, 'seed': 510, 'updates': 20000 // per, 'sha256': sha(st)})
    for g in ('rg-turn3', 'flop6', 'rg-flop6c', 'early3-flop'):
        subprocess.run(['node', str(root / 'source/tools/games510.js'), 'spec', g, str(sp), '510', json.dumps({'batchDeals': 16, 'actionStreams': 'deal'})], check=True)
        train(old, sp, 400, 3, st); states.append({'game': g, 'seed': 510, 'updates': 400, 'threads': 3, 'extra': {'batchDeals': 16, 'actionStreams': 'deal'}, 'sha256': sha(st)})
    for fx, upd in (('flop6-jack', 4000), ('flop3-kings', 8000), ('flop3-kings-detailed', 4000), ('icm8-bb-call', 8000), ('btn25-open', 4000)):
        spec(root, fx, {}, sp); train(old, sp, upd, 1, st); states.append({'fixture': fx, 'updates': upd, 'sha256': sha(st)})
    for fx, upd in (('flop3-kings-detailed', 50), ('flop6-jack', 50)):
        spec(root, fx, BATCH, sp); train(old, sp, upd, 3, st); states.append({'fixture': fx, 'updates': upd, 'threads': 3, 'extra': BATCH, 'sha256': sha(st)})
    build = subprocess.run([old, '--build-id'], capture_output=True, text=True).stdout.strip().split('=')[-1]
    (root / 'source/tests/fixtures/golden510.json').write_text(json.dumps({'what': 'SHA-256 of the states the unchanged 5.9 program writes with the default trainer; the 5.10 program must write the same bytes (tests/v510.test.js)', 'recordedFrom': {'version': '5.9', 'build': build, 'binarySha256': sha(old)}, 'recordedBy': 'tools/make_golden510.py', 'states': states}, indent=1) + '\n')
    for f in (sp, st, q): f.unlink(missing_ok=True)
    print('recorded', len(GOLDEN59), 'states of 5.9,', len(GOLDEN510), 'states of rbes,', len(REFERENCE), 'reference values,', len(states), 'states for tests/fixtures/golden510.json')
