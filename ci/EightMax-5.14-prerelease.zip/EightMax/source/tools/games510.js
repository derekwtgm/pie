// EightMax 5.10: reference games with RANGES, added to the games of tools/games48.js and tools/games58.js.
//
// The earlier reference games give a seat one to six hands, so that an exact best response is cheap. That is too few
// to say anything about an estimator whose point is the updating seat's RANGE (the 5.10 experimental estimator
// "rbes" carries every compatible hand of that seat through one traversal): with two hands a seat there is almost
// nothing to enumerate. These games give a seat 10 to 60 hands (written as hand classes with weights, as a user
// writes a range) and are still small enough for an EXACT best response of every seat inside their abstraction
// (mwcli --gain, method exact), so exact NashConv exists for each of them. Two of them use the Compact hand groups of
// the shipped study fixtures (three betting streets; six players), where a table row is shared by several hands.
//
// They are CONTROLLED FIXTURES, not models of real play: one or two bet sizes a street, no raises beyond an all-in,
// nothing before the first decision but the chips already in the pot. What each represents and leaves out is in its
// `stage` and `abstraction` entries, which the reports print beside its results.
//
//   node tools/games510.js list
//   node tools/games510.js spec <key> <out.json> [seed] [extra-json]     (keys of games48/games58 are accepted too)
//   node tools/games510.js describe
'use strict';
const path = require('node:path'), fs = require('node:fs');
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river']) require('../web/' + l);
const g58 = require('./games58.js');
const base = g58.base;
// [key, title, options, tournament stage, abstraction and assumptions]
const added = [
  ['rg-hu-river', 'Heads-up river, ranges of about 58 hands a seat, half-pot bet or all-in and an all-in raise, chip EV',
    { board: 'Ks8d5h2c2s', common: 10, stacks: [20, 20],
      ranges: ['AA,KK:0.5,AKs,AKo:0.5,KQs,KJs,88,55:0.5,QJs,JTs,T9s:0.5,76s,A5s:0.5,QQ:0.25', 'KK:0.25,AKo,KQo:0.5,KTs,K9s,22,87s,A8s,JJ,TT:0.5,QTs,J9s:0.5,65s,A2s:0.5'],
      streets: { river: { bets: '50,a', raises: 'a', maxBets: 2 } } },
    'any stage, heads-up', 'River only. Weighted ranges of 14 hand classes a seat (about 58 combinations each after card removal). Two-player chip EV: NashConv / 2 is exploitability.'],
  ['rg-river3', 'Three-player river, ranges of about 30 hands a seat, unequal stacks, side pots, chip EV',
    { board: 'Ks8d5h2c2s', common: 6, stacks: [4, 12, 30],
      ranges: ['AKs,KQs,88:0.5,JTs,76s,AQs:0.5,QQ:0.5', 'AKo:0.5,KJs,55,87s,AQs,JTs:0.5,TT:0.5', 'K9s,QQ:0.5,77,A5s,T9s,JJ:0.5,KTs:0.5'],
      streets: { river: { bets: '75,a', raises: 'a', maxBets: 2 } } },
    'multiway pot with side pots', 'Three seats on the river with 4, 12 and 30 BB behind (a call by the short stack builds a side pot). Three-quarter-pot bet or all-in, all-in raise. Seven weighted hand classes a seat. Chip EV.'],
  ['rg-hu-turn', 'Heads-up turn and river, ranges of about 30 hands a seat, chip EV',
    { board: 'Ks8d5h2c', common: 8, stacks: [12, 12],
      ranges: ['AKs,KQs,88:0.5,JTs,QJs,AQs:0.5,76s,T9s:0.5', 'AKo:0.5,55,87s,JTs:0.5,KJs,A5s,QTs:0.5,99'],
      streets: { turn: { bets: 'a', raises: '', maxBets: 1 }, river: { bets: '50', raises: '', maxBets: 1 } } },
    'any stage, heads-up', 'Turn (all-in or check) and river (half-pot bet): two streets with a sampled river card. Eight weighted hand classes a seat. Two-player chip EV.'],
  ['rg-turn3', 'Three-player turn and river, ranges of about 22 hands a seat, unequal stacks, two turn bet sizes and an all-in raise, chip EV',
    { board: 'Js8s3d2c', dealt: 8, common: 1.5, stacks: [22, 30, 14], prior: Array(3).fill(4),
      ranges: ['AJs,88:0.5,T9s,KQs:0.75,QJs,A5s:0.5', 'KJs,AA:0.25,97s,QTs:0.75,JTs,76s', 'JTs:0.75,33:0.5,A5s,76s,KJs:0.5,T9s'],
      streets: { turn: { bets: '50,a', raises: 'a', maxBets: 2 }, river: { bets: '66', raises: '', maxBets: 1 } } },
    'middle stage (14 to 30 BB behind after 4 BB each)', 'Three seats on the turn with unequal stacks (an all-in creates a side pot): check, bet half the pot or all-in, all-in raise; river: one bet of two thirds of the pot. Six weighted hand classes a seat. Chip EV.'],
  ['rg-turn4', 'Four-player turn and river, ranges of about 11 hands a seat, unequal stacks (6 to 40 BB), chip EV',
    { board: 'Qd9s4c3h', dealt: 6, common: 4, stacks: [10, 25, 6, 40], prior: Array(4).fill(2), folded: [1],
      ranges: ['AQs,99:0.5,KJs', 'KQs,T8s,JTs:0.5', 'JJ,A4s,QTs:0.5', 'QJs,76s,AA:0.25'],
      streets: { turn: { bets: 'a', raises: '', maxBets: 1 }, river: { bets: '50', raises: '', maxBets: 1 } } },
    'middle stage, four-way pot', 'Four seats on the turn with unequal stacks: all-in or check/fold on the turn, half-pot river bet. Three weighted hand classes a seat. Chip EV.'],
  ['rg-icm3-river', 'Final three: river with ranges of about 30 hands a seat, unequal stacks and side pots (ICM, three prizes)',
    { board: 'Ks8d5h2c2s', common: 6, stacks: [4, 12, 30],
      ranges: ['AKs,KQs,88:0.5,JTs,76s,AQs:0.5,QQ:0.5', 'AKo:0.5,KJs,55,87s,AQs,JTs:0.5,TT:0.5', 'K9s,QQ:0.5,77,A5s,T9s,JJ:0.5,KTs:0.5'],
      streets: { river: { bets: '75,a', raises: 'a', maxBets: 2 } }, icm: { payouts: [50, 30, 20] } },
    'final table, three left (prizes 50, 30, 20 units)', 'The game rg-river3 with prize-equity utility (Malmuth-Harville ICM of the final chip counts). Future hands are not modelled.'],
  ['rg-bubble4', 'Bubble: four players, three paid, push or fold, five weighted hands a seat (ICM)',
    { preflop: { mode: 'shove' }, dealt: 4, common: 0, board: '', stacks: [12, 7, 20, 4],
      ranges: ['AsAh,7c2d:0.5,KcQc,9h8h:0.5,5s5d', 'KsKh:0.75,8c3d,AdJd,6s5s:0.5,Tc9c', 'QsQh,6d5d,AcTc:0.5,KdJd,4h4c', 'JsJh:0.5,9s8s,Ah4h,Td9d:0.5,KhQd'],
      icm: { payouts: [50, 30, 20] }, batchDeals: 4, actionStreams: 'deal' },
    'bubble (four players, prizes 50, 30, 20 units)', 'Four-handed push or fold (blinds 0.5/1, ante 0.1 each); every showdown runs out five cards. Five weighted hands a seat. ICM utility.'],
  ['rg-flop3c', 'Three-player flop, turn and river with Compact hand groups, ranges of 14 to 19 hands a seat, chip EV',
    { abstraction: 'compact', board: 'Kh9d4c', dealt: 8, common: 1.5, stacks: [22.7, 22.7, 22.7], prior: Array(3).fill(2.5),
      ranges: ['AKs,99:0.5,JTs:0.5,76s', 'KJs,AKo:0.5,T9s,87s', 'KTs,QQ:0.5,J9s,A4s'],
      streets: { flop: { bets: '50', raises: '', maxBets: 1 }, turn: { bets: '66', raises: '', maxBets: 1 }, river: { bets: '', raises: '', maxBets: 1 } } },
    'middle stage (22.7 BB behind after 2.5 BB each)', 'Three seats see a flop: half-pot bet on the flop, two-thirds bet on the turn, the river is checked down. Three betting streets follow one another with sampled turn and river cards. Table rows are COMPACT HAND GROUPS (strength category, top rank, flush and straight draws; a row is shared by several hands), as in the shipped study fixtures. Chip EV.'],
  ['rg-flop6c', 'Six-player flop with Compact hand groups, three or four hands a seat, half-pot bet or all-in, side pots, chip EV',
    { abstraction: 'compact', board: 'Td7c2h', dealt: 8, common: 1.5, stacks: [20, 35, 8, 50, 14, 6], prior: Array(6).fill(2.5), folded: [1, 2.5],
      ranges: ['AhTh,7s7d:0.5,KcQc:0.75,9s8s', 'KdTs,9c8c,AcJc:0.5,6h6d', 'QsQd,Ac7h:0.5,5h5d,JdTd', 'JhTc,6s5s:0.75,Kh9h,AsQs', 'AdKc:0.5,2s2d,Js9s,8c7s', '8h8d,As2c:0.5,QhJd,KsJs'],
      streets: { flop: { bets: '50,a', raises: '', maxBets: 1 } } },
    'multiway pot, unequal stacks (6 to 50 BB)', 'Six seats on the flop: check, bet half the pot or all-in; no later betting (the board runs out). Layered side pots. Compact hand groups. Three or four weighted hands a seat: the six-player game with the largest ranges for which the exact best response of every seat finishes in seconds.'],
];
const games = [...g58.games, ...added.map(g => ({ key: g[0], title: g[1], options: g[2], stage: g[3], abstraction: g[4], from: '5.10', zeroSum: g[0] === 'rg-hu-river' || g[0] === 'rg-hu-turn' }))];
const byKey = Object.fromEntries(games.map(g => [g.key, g]));
function spec(key, seed = 1, extra = {}) {
  const g = byKey[key]; if (!g) throw new Error('unknown game ' + key);
  return E.MultiwayGame({ ...base, ...g.options, privateSeed: seed }).nativeSpec();
}
module.exports = { games, byKey, spec, base, added: added.map(g => g[0]) };
if (require.main === module) {
  const [cmd, key, out, seed, extra] = process.argv.slice(2);
  if (cmd === 'list') for (const g of games) console.log(g.key.padEnd(14), g.title);
  else if (cmd === 'describe') console.log(JSON.stringify(games.map(g => { const s = spec(g.key); return { key: g.key, title: g.title, stage: g.stage, abstraction: g.abstraction, addedIn: g.from, players: s.n, startCards: s.board.length, utility: s.icm ? 'ICM prize equity' : 'chip EV (BB)', rowKeys: s.groupKeys ? 'Compact hand groups' : 'exact cards', handsPerSeat: s.hands.map(h => h.length), stacks: s.rules.stacks, potBeforeFirstAction: s.rules.pot0 + s.rules.posted.reduce((a, b) => a + b, 0) }; }), null, 1));
  // extra-json is merged into the native spec (trainer options such as {"estimator":"rbes"}), not into the game options
  else if (cmd === 'spec') fs.writeFileSync(path.resolve(out), JSON.stringify({ ...spec(key, +(seed || 1)), ...(extra ? JSON.parse(extra) : {}) }));
  else { console.error('usage: node tools/games510.js list | describe | spec <key> <out.json> [seed] [extra-json]'); process.exit(2); }
}
