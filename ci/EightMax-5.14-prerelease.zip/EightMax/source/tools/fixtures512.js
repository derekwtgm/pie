// EightMax 5.12 (Phase 2): six-handed study fixtures.
//
// Definitions only. They are registered with the 5.2 generator (tools/fixtures52.js), which builds every fixture
// through the application's own workflow and asks the native engine for the decision, exactly as it does for
// the eight-handed fixtures. What differs from the 5.2 fixtures: six seats are dealt (0.6 BB of antes, 2.1 BB in
// the pot before voluntary action), and three seats instead of five have folded in front of the button.
//
//   node tools/fixtures52.js <mwcli> <out-dir> [id ...]      also writes these
//   node tools/fixtures52.js <mwcli> --check <dir>           also checks these
'use strict';
module.exports = function ({ E, def, seat, tree, bunched, uniformAll }) {
  const TABLE6 = { players: 6, smallBlind: 0.5, bigBlind: 1, antePerPlayer: 0.1, startingPotBeforeVoluntaryAction: 2.1, unit: 'BB' };
  const spotBase6 = (n, start) => ({ ...E.multiwayExample(n, start, 6), privateMode: 'sampled', traversal: 'external', batchDeals: 1, privateSeed: 1, engine: 'native', measured: false, processingMode: 'cpu', maxIter: 20000 });
  // Three folds in front of the button remove fewer weak hands from the deck than five do. The tiers of the 5.2
  // fixtures (1.00 / 0.95 / 0.90 after five folds) are scaled to three folds: 1.00 / 0.97 / 0.94. An assumption.
  const W6 = bunched(1, 0.97, 0.94);

  // ---------- 1. 25 BB button, folded to the button, six-handed ----------
  {
    const mk = (o = {}) => ({ ...spotBase6(3, 'Preflop'), study: 'linked', abstraction: 'compact', memoryMiB: o.memoryMiB || 2048, preOpen: o.opens || '2.2', preRaises: 'a', preCap: 2, preLimps: false, others: '24.9,24.9,24.9',
      tree: tree(['50'], ['66'], ['75']), notes: 'EightMax 5.12 study fixture: 25 BB button, folded to the button, six-handed.',
      seats: [seat('BTN', 25, o.btn || uniformAll()), seat('SB', 25, o.blinds || W6), seat('BB', 25, o.blinds || W6)] });
    def('btn25-open-6max', {
      table: TABLE6,
      title: '25 BB button open, folded to the button (six-handed MTT)', kind: 'realistic', companion: 'btn25-open-6max-small',
      hero: { seat: 0, position: 'BTN', hand: 'Kd8c' }, history: [],
      description: {
        effectiveStacksBB: 25, stacksBB: { BTN: 25, SB: 25, BB: 25 }, positions: 'six-handed: MP, HJ, CO folded (their antes are in the pot); BTN, SB, BB live',
        actionHistory: 'MP, HJ and CO fold. Button to act.', board: 'none (preflop)',
        betSizes: { preflop: 'button: fold or raise to 2.2 BB; blinds: fold, call or 3-bet all-in; button facing a 3-bet: fold or call', flop: 'bet 50% pot, no raises', turn: 'bet 66% pot, no raises', river: 'bet 75% pot, no raises' },
        utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the hand (the 0.1 BB ante is sunk: folding = -0.1 BB)' },
        abstraction: 'Compact hand groups (169 preflop classes; made-hand and draw strength groups after the flop). Deals, blockers, showdowns and pots use the physical cards.',
        continuation: 'Linked postflop continuation: one bet size per street, no postflop raises. Every seat plays the trained average strategy; where a deal reaches an information set that training never visited, the evaluator substitutes uniform play and reports the share (fallbackShare).',
        rangeWeights: 'Button: every hand, weight 1. Small and big blind: every hand, weighted for bunching after three folds: the 56 strongest of the 169 classes weight 1.00, the next 57 weight 0.97, the weakest 56 weight 0.94 (an assumption, not a measurement; the eight-handed fixture uses 1.00 / 0.95 / 0.90 after five folds).',
        sixHanded: 'The game of btn25-open with six dealt seats instead of eight: 0.6 BB of antes instead of 0.8 BB (2.1 BB in the pot before the button acts instead of 2.3 BB), three folded seats instead of five, weaker bunching weights. It is a different game; its numbers are not comparable hand for hand with btn25-open.',
        assumptions: ['The three folded seats are not modelled beyond their antes and the bunching weights.', 'No limping, one open size, 3-bets are all-in only.', 'Postflop bet sizes are a coarse abstraction of real play.'] },
      study: { seeds: [5121, 5122, 5123, 5124, 5125], budgetsDeals: [250000, 1000000, 4000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 200000, seed: 512 }, quality: { method: 'sampled', samples: 20000, selectionSamples: 200, seed: 512, budgets: 'last' }, tolerance: { evGap: 0.05, frequency: 0.05, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk() },
        { name: 'wider-range', change: 'Blind ranges without the bunching weights: every hand of both blinds at weight 1 (weak hands are 6% more frequent than in the baseline).', spot: mk({ blinds: uniformAll() }) },
        { name: 'added-size', change: 'The button may also open all-in (25 BB) in addition to raising to 2.2 BB.', spot: mk({ opens: '2.2,a' }) },
      ] });
    const small = (o = {}) => ({ ...spotBase6(3, 'Preflop'), study: 'linked', abstraction: 'exact', memoryMiB: 256, preOpen: o.opens || '2.2', preRaises: 'a', preCap: 2, preLimps: false, others: '24.9,24.9,24.9',
      tree: tree([''], [''], ['']), notes: 'EightMax 5.12 study fixture (small companion of btn25-open-6max).',
      seats: [seat('BTN', 25, 'AsKd:0.5,Kd8c,Jc9c,6d6s:0.75'), seat('SB', 25, o.sb || 'AhAd:0.25,JhJd:0.5,Ks4s,Th8h,7c2d,9s3s'), seat('BB', 25, o.bb || 'KhKc:0.25,AdTh:0.5,QdJd,9h6h,8d4d,5c2c')] });
    def('btn25-open-6max-small', {
      table: TABLE6,
      title: '25 BB button open six-handed, small companion (short weighted ranges, exact cards, no postflop betting)', kind: 'companion', companionOf: 'btn25-open-6max',
      hero: { seat: 0, position: 'BTN', hand: 'Kd8c' }, history: [],
      description: {
        effectiveStacksBB: 25, stacksBB: { BTN: 25, SB: 25, BB: 25 }, positions: 'as btn25-open-6max', actionHistory: 'MP, HJ and CO fold. Button to act.', board: 'none (preflop)',
        betSizes: { preflop: 'button: fold or raise to 2.2 BB; blinds: fold, call or 3-bet all-in; button facing a 3-bet: fold or call', postflop: 'no betting: hands are checked down to showdown' },
        utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the hand (the 0.1 BB ante is sunk)' },
        abstraction: 'Exact cards (no hand grouping).', continuation: 'No postflop betting.',
        rangeWeights: 'Four listed hands for the button and six per blind, weights 0.25 to 1 (see variants[].ranges): the hands of btn25-open-small.',
        simplifiedFrom: 'btn25-open-6max', simplifications: ['Ranges cut from every hand to four weighted hands for the button and six per blind.', 'Postflop betting removed (check-down).', 'Hand groups replaced by exact cards, so no information set is missing after training.',
          'Evaluation stays SAMPLED (400,000 paired samples per evaluation), as for btn25-open-small: the exact evaluators walk every flop, turn and river of a called 2.2 BB raise and exceed their work limit on this tree.'],
        assumptions: ['Small enough to converge quickly; it shows the method, not real-range strategy.'] },
      study: { seeds: [5121, 5122, 5123, 5124, 5125], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 256, ev: { method: 'sampled', samples: 400000, seed: 512 }, quality: { method: 'sampled', samples: 40000, selectionSamples: 2000, seed: 512 }, tolerance: { evGap: 0.02, frequency: 0.05, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: small() },
        { name: 'wider-range', change: 'The big blind range gains a weaker hand (Jh4h at weight 1).', spot: small({ bb: 'KhKc:0.25,AdTh:0.5,QdJd,9h6h,8d4d,5c2c,Jh4h' }) },
        { name: 'added-size', change: 'The button may also open all-in (25 BB).', spot: small({ opens: '2.2,a' }) },
      ] });
  }
  // ---------- 2. three-way flop after a cutoff open, six-handed, 30 BB ----------
  {
    const BB = '99:0.5,88,77,66,55,44,33,22,ATs:0.5,A9s,A8s,A7s,A6s,A5s,A4s,A3s,A2s,KTs:0.5,K9s,K8s,K7s,K6s,K5s,Q9s,Q8s,J9s,J8s,T8s,T7s,97s,96s,86s,85s,76s,75s,65s,64s,54s,53s,AJo:0.5,ATo,A9o,A8o:0.5,KJo,KTo,QJo,QTo,JTo,T9o:0.5,98o:0.5';
    const BBW = BB + ',K4s,K3s,K2s,Q7s,Q6s,J7s,T6s,95s,74s:0.5,43s,A7o,A5o:0.5,K9o,Q9o,J9o:0.5';
    const CO = '22+,A2s+,K6s+,Q8s+,J8s+,T8s+,97s+,87s,76s,65s,ATo+,A9o:0.5,KTo+,QTo+,JTo';
    const BTN = 'TT:0.5,99,88,77,66,55,44:0.5,AQs:0.5,AJs,ATs,A9s:0.5,A5s:0.5,KQs,KJs,KTs,QJs,QTs,JTs,T9s,98s,87s:0.5,AQo:0.5,AJo:0.5,KQo';
    const mk = (o = {}) => ({ ...spotBase6(3, 'Flop'), study: 'postflop', abstraction: 'compact', memoryMiB: 2048, board: 'Qs 7d 3h', common: '0', folded: '0.5', others: '29.9,29.9,29.4',
      tree: tree([o.flop || '33,75'], ['66'], ['75']), notes: 'EightMax 5.12 study fixture: three-way flop after a cutoff open, six-handed.',
      seats: [seat('BB', 27.7, o.bb || BB, 2.2), seat('CO', 27.7, CO, 2.2), seat('BTN', 27.7, BTN, 2.2)] });
    const common = {
      effectiveStacksBB: 27.7, stacksBB: { BB: 27.7, CO: 27.7, BTN: 27.7 }, board: 'Qs 7d 3h',
      utility: { model: 'chip', unit: 'BB', convention: 'net chips of the hero from the start of the study (the flop): chips collected minus chips put in from the flop on' } };
    def('flop3-queens-6max', {
      table: TABLE6,
      title: 'Three-way flop Q-7-3 rainbow six-handed, cutoff raiser with top pair top kicker after the big blind checks', kind: 'realistic', companion: 'flop3-queens-6max-small',
      hero: { seat: 1, position: 'CO', hand: 'AhQc' }, history: ['Check'],
      description: {
        ...common, positions: 'six-handed, 30 BB starting stacks: MP and HJ folded, the cutoff raised to 2.2 BB, the button called, the small blind folded, the big blind called (six antes and the small blind are in the pot)',
        actionHistory: 'Preflop: MP and HJ fold, CO raises to 2.2, BTN calls, SB folds, BB calls (pot 7.7 BB: 6.6 + 0.5 + 0.6). Flop Qs 7d 3h: BB checks. Cutoff to act with the button behind.',
        betSizes: { flop: 'bet 33% or 75% pot, no raises', turn: 'bet 66% pot, no raises', river: 'bet 75% pot, no raises' },
        abstraction: 'Compact hand groups (made-hand and draw strength groups on every street). Deals, blockers, showdowns and pots use the physical cards.',
        continuation: 'One bet size on the turn and one on the river, no raises on any street. Unvisited information sets are played uniformly by the evaluator (fallbackShare is reported).',
        rangeWeights: 'Weighted class ranges for a cutoff open, a button call and a big blind call (see variants[].ranges for the exact text and combination counts). They were written by hand for this fixture; they are not taken from the 6-max chart library and are not solved.',
        assumptions: ['The preflop ranges are inputs, not solved.', 'No check-raises: a player who has checked can only call or fold to a bet.'] },
      study: { seeds: [5131, 5132, 5133, 5134, 5135], budgetsDeals: [250000, 1000000, 4000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 200000, seed: 512 }, quality: { method: 'sampled', samples: 40000, selectionSamples: 400, seed: 512, budgets: 'last' }, tolerance: { evGap: 0.05, frequency: 0.05, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk() },
        { name: 'wider-range', change: 'The big blind calls preflop with a wider range: 15 more classes (K4s, K3s, K2s, Q7s, Q6s, J7s, T6s, 95s, 74s:0.5, 43s, A7o, A5o:0.5, K9o, Q9o, J9o:0.5).', spot: mk({ bb: BBW }) },
        { name: 'added-size', change: 'A 125% pot overbet is added on the flop (33%, 75% and 125% pot).', spot: mk({ flop: '33,75,125' }) },
      ] });
    const small = (o = {}) => ({ ...spotBase6(3, 'Flop'), study: 'postflop', abstraction: 'exact', memoryMiB: 512, board: 'Qs 7d 3h', common: '0', folded: '0.5', others: '29.9,29.9,29.4',
      tree: tree([o.flop || '33,75'], [''], ['']), notes: 'EightMax 5.12 study fixture (small companion of flop3-queens-6max).',
      seats: [seat('BB', 27.7, o.bb || '7c7s:0.5,Qd9d,Ah7h,6d5d,KhTh:0.75', 2.2), seat('CO', 27.7, 'AhQc,AdKc:0.5,9s9h,JsTs:0.75,KdQh', 2.2), seat('BTN', 27.7, '3c3s:0.5,QhJh,8d8c,Ac5c:0.75,Td9d', 2.2)] });
    def('flop3-queens-6max-small', {
      table: TABLE6,
      title: 'Three-way flop Q-7-3 six-handed, small exact companion (five weighted hands per seat, flop betting only)', kind: 'companion', companionOf: 'flop3-queens-6max',
      hero: { seat: 1, position: 'CO', hand: 'AhQc' }, history: ['Check'],
      description: {
        ...common, positions: 'as flop3-queens-6max', actionHistory: 'as flop3-queens-6max: BB checks, cutoff to act on Qs 7d 3h (pot 7.7 BB).',
        betSizes: { flop: 'bet 33% or 75% pot, no raises', turnAndRiver: 'no betting: checked down' },
        abstraction: 'Exact cards.', continuation: 'No turn or river betting.',
        rangeWeights: 'Five listed hands per seat with weights 0.5 to 1.',
        simplifiedFrom: 'flop3-queens-6max', simplifications: ['Ranges cut to five weighted hands per seat.', 'Turn and river betting removed, so action EVs and best-response gains are exact inside this model.', 'Hand groups replaced by exact cards.'],
        assumptions: ['Small enough for exact evaluation; it shows the method, not real-range strategy.'] },
      study: { seeds: [5131, 5132, 5133, 5134, 5135], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 512, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.02, frequency: 0.05, quality: 0.02, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: small() },
        { name: 'wider-range', change: 'The big blind range gains two weaker hands (Jh9h and 5h4h at weight 1).', spot: small({ bb: '7c7s:0.5,Qd9d,Ah7h,6d5d,KhTh:0.75,Jh9h,5h4h' }) },
        { name: 'added-size', change: 'A 125% pot overbet is added on the flop.', spot: small({ flop: '33,75,125' }) },
      ] });
  }
  // ---------- 3. six-handed final table, ICM ----------
  {
    const PAY = '35,24,16,11,8,6', OTHERS = '21.9,8.9,30.9';
    const mk = (o = {}) => ({ ...spotBase6(3, 'Preflop'), study: 'linked', payoff: o.chip ? 'chip' : 'icm', payouts: PAY, others: OTHERS, abstraction: 'compact', memoryMiB: 2048, preOpen: o.opens || 'a', preRaises: 'a', preCap: 2, preLimps: false,
      tree: tree(['a'], [''], ['']), notes: 'EightMax 5.12 study fixture: six-handed final table.',
      seats: [seat('BTN', 40, o.ranges || W6), seat('SB', 12, o.ranges || W6), seat('BB', 18, o.ranges || W6)] });
    const descr = small => ({
      effectiveStacksBB: 18, stacksBB: { MP: 22, HJ: 9, CO: 31, BTN: 40, SB: 12, BB: 18 }, payouts: { unit: 'percent of the prize pool', places: [35, 24, 16, 11, 8, 6] },
      positions: 'six players left, all paid: MP 22, HJ 9, CO 31 (folded; stacks shown before the 0.1 BB ante), BTN 40, SB 12, BB 18',
      actionHistory: 'MP, HJ and CO fold. BTN (40 BB) moves all-in, SB (12 BB) folds. Big blind (18 BB) to act: call or fold.', board: 'none (preflop)',
      betSizes: { preflop: 'button: fold or all-in; blinds: fold or call all-in' + (small ? '' : ' (the added-size variant also gives the button a raise to 2.2 BB)'), postflop: 'none in the baseline (every pot is all-in or folded); the added-size variant allows an all-in bet on the flop after a 2.2 BB raise is called' },
      utility: { model: 'icm', unit: 'percent of the prize pool', convention: 'Malmuth-Harville ICM value of the hero\'s final stack given the six stacks, in percent of the prize pool. The chip-EV variant of the same spot reports BB instead; the two are never mixed in one comparison.' },
      abstraction: small ? 'Exact cards.' : 'Compact hand groups (169 preflop classes). Deals, blockers, showdowns, side pots and ICM use the physical cards and exact stacks.',
      continuation: 'All-in or fold preflop; no further decisions in the baseline.',
      rangeWeights: small ? 'Four or five listed hands per seat with weights 0.5 to 1: the hands of icm8-bb-call-small.' : 'Every hand for BTN, SB and BB, weighted for bunching after three folds (56 strongest classes 1.00, next 57 0.97, weakest 56 0.94; an assumption).',
      sixHanded: 'The stacks of the six seats nearest the button of icm8-bb-call, with a six-place payout table (35 / 24 / 16 / 11 / 8 / 6). A different game from icm8-bb-call: fewer players, other prizes, two antes less.',
      assumptions: ['The three folded stacks only enter through ICM (they keep their stacks).', 'Push-or-fold abstraction for the button in the baseline.', 'The payout table is an example, not a standard.'] });
    def('icm6-bb-call', {
      table: TABLE6,
      title: 'Six-handed final table: big blind (18 BB) facing a button all-in, ICM with a chip-EV comparison', kind: 'realistic', companion: 'icm6-bb-call-small',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'],
      description: descr(false),
      study: { seeds: [5141, 5142, 5143, 5144, 5145], budgetsDeals: [500000, 2000000, 8000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 2000000, seed: 512 }, quality: { method: 'sampled', samples: 200000, selectionSamples: 1000, seed: 512 }, tolerance: { evGap: 0.05, frequency: 0.05, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk() },
        { name: 'wider-range', change: 'No bunching weights: every hand of BTN, SB and BB at weight 1 (weak hands 6% more frequent).', spot: mk({ ranges: uniformAll() }) },
        { name: 'added-size', change: 'The button may also raise to 2.2 BB instead of moving all-in (blinds can call or re-raise all-in; one all-in bet on the flop).', spot: mk({ opens: '2.2,a' }) },
        { name: 'chip-ev', change: 'Same stacks, ranges and actions, but utilities are chips (BB) instead of ICM prize share.', spot: mk({ chip: true }) },
      ] });
    const small = (o = {}) => ({ ...spotBase6(3, 'Preflop'), study: 'linked', payoff: o.chip ? 'chip' : 'icm', payouts: PAY, others: OTHERS, abstraction: 'exact', memoryMiB: 256, preOpen: o.opens || 'a', preRaises: 'a', preCap: 2, preLimps: false,
      tree: tree([''], [''], ['']), notes: 'EightMax 5.12 study fixture (small companion of icm6-bb-call).',
      seats: [seat('BTN', 40, o.btn || 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5'), seat('SB', 12, 'TsTh:0.5,Kd9d,Qc6c:0.75,5h4h'), seat('BB', 18, 'AdTc,6s6c,Kh8h:0.75,9c3d')] });
    def('icm6-bb-call-small', {
      table: TABLE6,
      title: 'Six-handed final table, small exact companion (four or five weighted hands per seat)', kind: 'companion', companionOf: 'icm6-bb-call',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'],
      description: { ...descr(true), simplifiedFrom: 'icm6-bb-call', simplifications: ['Ranges cut from every hand to four or five weighted hands per seat.', 'Hand groups replaced by exact cards; action EVs and best-response gains are exact inside this model.', 'The added-size variant gives the button a 2.2 BB raise with no postflop betting (check-down).'] },
      study: { seeds: [5141, 5142, 5143, 5144, 5145], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 256, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.02, frequency: 0.05, quality: 0.02, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: small() },
        { name: 'wider-range', change: 'The button range gains a weaker hand (Jc6c at weight 1).', spot: small({ btn: 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5,Jc6c' }) },
        { name: 'added-size', change: 'The button may also raise to 2.2 BB instead of moving all-in (postflop checked down). The quality metric of this variant is sampled: exact best response exceeds the work limit once a 2.2 BB raise can reach the flop.', spot: small({ opens: '2.2,a' }), quality: { method: 'sampled', samples: 40000, selectionSamples: 2000, seed: 512 } },
        { name: 'chip-ev', change: 'Same spot with chip utilities (BB) instead of ICM prize share.', spot: small({ chip: true }) },
      ] });
  }
};
