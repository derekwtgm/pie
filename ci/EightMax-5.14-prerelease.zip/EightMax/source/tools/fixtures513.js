// EightMax 5.13 (Phase 3): satellite study fixtures. Definitions only; built by tools/fixtures52.js like every fixture.
//
//   sat5-bubble-bb-call(-small)   five left, four seats: the ordinary ICM with four equal prizes (payouts "satellite 4")
//   satfield-bb-call(-small)      a large field (124 left, 40 seats): the satellite-field payoff model, satfield-5.13-v1
//   known-sat-akq-river           closed-form mixed equilibrium with satellite values (three left, two seats)
//   sat3-fold-aces                closed-form action values: the big blind folds aces on the bubble
// In a satellite a seat is worth 1, so every EV of these fixtures is a probability of winning a seat.
'use strict';
module.exports = function ({ E, def, seat, tree }) {
  const base = (n, start, dealt) => ({ ...E.multiwayExample(n, start, dealt), privateMode: 'sampled', traversal: 'external', batchDeals: 1, privateSeed: 1, engine: 'native', measured: false, processingMode: 'cpu', maxIter: 20000 });
  const SEAT = { model: 'icm', unit: 'probability of winning a seat (a seat is worth 1)' };
  // ---------- 1. five left, four seats ----------
  {
    const TABLE5 = { players: 5, smallBlind: 0.5, bigBlind: 1, antePerPlayer: 0.1, startingPotBeforeVoluntaryAction: 2, unit: 'BB' };
    const ALL = E.CLASS_NAMES.join(',');
    const mk = (o = {}) => ({ ...base(3, 'Preflop', 5), study: 'linked', payoff: o.chip ? 'chip' : 'icm', payouts: o.payouts || 'satellite 4', others: '21.9,13.9', abstraction: 'compact', memoryMiB: 2048, preOpen: 'a', preRaises: 'a', preCap: 2, preLimps: false,
      tree: tree(['a'], [''], ['']), notes: 'EightMax 5.13 study fixture: satellite bubble, five left, four seats.',
      seats: [seat('BTN', 30, ALL), seat('SB', 9, ALL), seat('BB', 16, ALL)] });
    const descr = small => ({
      effectiveStacksBB: 16, stacksBB: { HJ: 22, CO: 14, BTN: 30, SB: 9, BB: 16 }, payouts: { unit: 'seats', places: [1, 1, 1, 1], satellite: 'four equal seats; fifth place gets nothing' },
      positions: 'five players left, four win a seat: HJ 22 and CO 14 folded (stacks before the 0.1 BB ante), BTN 30, SB 9, BB 16',
      actionHistory: 'HJ and CO fold. BTN (30 BB) moves all-in, SB (9 BB) folds. Big blind (16 BB) to act: call or fold.', board: 'none (preflop)',
      betSizes: { preflop: 'button: fold or all-in; blinds: fold or call all-in', postflop: 'none (every pot is all-in or folded)' },
      utility: { model: 'icm', unit: 'probability of winning a seat', convention: 'Malmuth-Harville ICM with four equal prizes of 1: the value of a stack is the probability of not finishing fifth. This is the ordinary ICM of the program (exact finishing-set recursion); nothing satellite-specific is computed.' },
      abstraction: small ? 'Exact cards.' : 'Compact hand groups (169 preflop classes). Deals, blockers, showdowns, side pots and ICM use the physical cards and exact stacks.',
      continuation: 'All-in or fold preflop; no further decisions.',
      rangeWeights: small ? 'Four or five listed hands per seat with weights 0.5 to 1.' : 'Every hand for BTN, SB and BB at weight 1.',
      assumptions: ['The two folded stacks only enter through ICM (they keep their stacks).', 'Push-or-fold abstraction.', 'One hand of a tournament: later hands are represented by the ICM model only.'] });
    def('sat5-bubble-bb-call', {
      table: TABLE5, utility: SEAT,
      title: 'Satellite bubble, five left and four seats: big blind (16 BB) facing a button all-in', kind: 'realistic', companion: 'sat5-bubble-bb-call-small',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'], description: descr(false),
      study: { seeds: [5301, 5302, 5303, 5304, 5305], budgetsDeals: [500000, 2000000, 8000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 2000000, seed: 513 }, quality: { method: 'sampled', samples: 200000, selectionSamples: 1000, seed: 513 }, tolerance: { evGap: 0.005, frequency: 0.05, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk() },
        { name: 'regular-prizes', change: 'The same five stacks with a regular payout table 40 / 27 / 18 / 15 (percent) instead of four equal seats: the EV unit is then percent of the prize pool, not comparable with the baseline number for number.', spot: mk({ payouts: '40,27,18,15' }), utility: { model: 'icm', unit: 'percent of the prize pool' } },
        { name: 'chip-ev', change: 'Same stacks, ranges and actions, but utilities are chips (BB).', spot: mk({ chip: true }) },
      ] });
    const small = (o = {}) => ({ ...base(3, 'Preflop', 5), study: 'linked', payoff: o.chip ? 'chip' : 'icm', payouts: 'satellite 4', others: '21.9,13.9', abstraction: 'exact', memoryMiB: 256, preOpen: 'a', preRaises: 'a', preCap: 2, preLimps: false,
      tree: tree([''], [''], ['']), notes: 'EightMax 5.13 study fixture (small companion of sat5-bubble-bb-call).',
      seats: [seat('BTN', 30, o.btn || 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5'), seat('SB', 9, 'TsTh:0.5,Kd9d,Qc6c:0.75,5h4h'), seat('BB', 16, 'AdTc,6s6c,Kh8h:0.75,9c3d')] });
    def('sat5-bubble-bb-call-small', {
      table: TABLE5, utility: SEAT,
      title: 'Satellite bubble, five left and four seats: small exact companion (four or five weighted hands per seat)', kind: 'companion', companionOf: 'sat5-bubble-bb-call',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'],
      description: { ...descr(true), simplifiedFrom: 'sat5-bubble-bb-call', simplifications: ['Ranges cut from every hand to four or five weighted hands per seat.', 'Hand groups replaced by exact cards; action EVs and best-response gains are exact inside this model.'] },
      study: { seeds: [5301, 5302, 5303, 5304, 5305], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 256, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.002, frequency: 0.05, quality: 0.002, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: small() },
        { name: 'wider-range', change: 'The button range gains a weaker hand (Jc6c at weight 1).', spot: small({ btn: 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5,Jc6c' }) },
        { name: 'chip-ev', change: 'Same spot with chip utilities (BB).', spot: small({ chip: true }) },
      ] });
  }
  // ---------- 2. a large field: 124 left, 40 seats ----------
  {
    const TABLE6 = { players: 6, smallBlind: 0.5, bigBlind: 1, antePerPlayer: 0.1, startingPotBeforeVoluntaryAction: 2.1, unit: 'BB' };
    const ALL = E.CLASS_NAMES.join(',');
    // players at other tables (118) and the three seats of this table that folded: 121 stacks that do not change in this hand
    const FIELD = '24x8, 38x18, 34x30, 22x52, 21.9, 8.9, 30.9', SUMMARY = '121x25.63';
    const mk = (o = {}) => ({ ...base(3, 'Preflop', 6), study: 'linked', payoff: o.chip ? 'chip' : 'satfield', satSeats: String(o.seats || 40), satField: o.field || FIELD, others: '', abstraction: 'compact', memoryMiB: 2048, preOpen: 'a', preRaises: 'a', preCap: 2, preLimps: false,
      tree: tree(['a'], [''], ['']), notes: 'EightMax 5.13 study fixture: satellite, large field.',
      seats: [seat('BTN', 40, ALL), seat('SB', 12, ALL), seat('BB', 18, ALL)] });
    const U = { model: 'satellite-field', unit: 'probability of winning a seat (satfield-5.13-v1)' };
    const descr = small => ({
      effectiveStacksBB: 18, stacksBB: { MP: 22, HJ: 9, CO: 31, BTN: 40, SB: 12, BB: 18 }, payouts: { unit: 'seats', satellite: '40 equal seats for a field of 124 players left' },
      field: { playersLeft: 124, seats: 40, atOtherTables: '24 players with 8 BB, 38 with 18 BB, 34 with 30 BB, 22 with 52 BB (118 players, an invented field)', foldedAtThisTable: 'MP 21.9, HJ 8.9, CO 30.9 after their antes', text: FIELD },
      positions: 'six-handed table of a satellite with 124 players left and 40 seats: MP 22, HJ 9, CO 31 folded, BTN 40, SB 12, BB 18',
      actionHistory: 'MP, HJ and CO fold. BTN (40 BB) moves all-in, SB (12 BB) folds. Big blind (18 BB) to act: call or fold.', board: 'none (preflop)',
      betSizes: { preflop: 'button: fold or all-in; blinds: fold or call all-in', postflop: 'none (every pot is all-in or folded)' },
      utility: { model: 'satellite-field', identifier: 'satfield-5.13-v1', unit: 'probability of winning a seat', convention: 'Probability under the Malmuth-Harville model that the seat finishes among the top 40 of the 124 players, after the hand, with the 121 players who are not in the hand holding their stacks. Computed by a quadrature of the exponential-race integral (MATHEMATICAL-VALIDATION-5.13.md). A player who loses all chips gets 0.' },
      abstraction: small ? 'Exact cards.' : 'Compact hand groups (169 preflop classes). Deals, blockers, showdowns, side pots and the payoff model use the physical cards and exact stacks.',
      continuation: 'All-in or fold preflop; no further decisions.',
      rangeWeights: small ? 'Four or five listed hands per seat with weights 0.5 to 1.' : 'Every hand for BTN, SB and BB at weight 1.',
      assumptions: ['The field is invented. In play the stacks at other tables are known at best approximately; the "average-only" variant shows what knowing only their number and average changes.', 'Players at other tables do not change stacks during this hand.', 'Push-or-fold abstraction.', 'One hand: later hands are represented by the ICM model only.'] });
    def('satfield-bb-call', {
      table: TABLE6, utility: U,
      title: 'Satellite, 124 left and 40 seats: big blind (18 BB) facing a button all-in (large-field model)', kind: 'realistic', companion: 'satfield-bb-call-small',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'], description: descr(false),
      study: { seeds: [5311, 5312, 5313, 5314, 5315], budgetsDeals: [500000, 2000000, 8000000], memoryMiB: 2048, ev: { method: 'sampled', samples: 2000000, seed: 513 }, quality: { method: 'sampled', samples: 200000, selectionSamples: 1000, seed: 513 }, tolerance: { evGap: 0.005, frequency: 0.05, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: mk() },
        { name: 'average-only', change: 'The 121 other players entered as 121 players with the average stack (25.63 BB) instead of their stacks: what the result becomes when only the number of players and the average stack are known.', spot: mk({ field: SUMMARY }) },
        { name: 'fewer-seats', change: '30 seats instead of 40 for the same field (further from the bubble).', spot: mk({ seats: 30 }) },
        { name: 'chip-ev', change: 'Same stacks, ranges and actions, but utilities are chips (BB).', spot: mk({ chip: true }) },
      ] });
    const small = (o = {}) => ({ ...base(3, 'Preflop', 6), study: 'linked', payoff: o.chip ? 'chip' : 'satfield', satSeats: '40', satField: o.field || FIELD, others: '', abstraction: 'exact', memoryMiB: 256, preOpen: 'a', preRaises: 'a', preCap: 2, preLimps: false,
      tree: tree([''], [''], ['']), notes: 'EightMax 5.13 study fixture (small companion of satfield-bb-call).',
      seats: [seat('BTN', 40, 'KhQh,Ac9c:0.5,7s7d,JdTd,AsQs:0.5'), seat('SB', 12, 'TsTh:0.5,Kd9d,Qc6c:0.75,5h4h'), seat('BB', 18, 'AdTc,6s6c,Kh8h:0.75,9c3d')] });
    def('satfield-bb-call-small', {
      table: TABLE6, utility: U,
      title: 'Satellite, 124 left and 40 seats: small exact companion (four or five weighted hands per seat)', kind: 'companion', companionOf: 'satfield-bb-call',
      hero: { seat: 2, position: 'BB', hand: 'AdTc' }, history: ['All-in', 'Fold'],
      description: { ...descr(true), simplifiedFrom: 'satfield-bb-call', simplifications: ['Ranges cut from every hand to four or five weighted hands per seat.', 'Hand groups replaced by exact cards; action EVs and best-response gains are exact inside this model.'] },
      study: { seeds: [5311, 5312, 5313, 5314, 5315], budgetsDeals: [20000, 200000, 2000000], memoryMiB: 256, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.002, frequency: 0.05, quality: 0.002, frequencyShift: 0.15 } },
      variants: [
        { name: 'baseline', change: '', spot: small() },
        { name: 'average-only', change: 'The 121 other players entered as 121 players with 25.63 BB.', spot: small({ field: SUMMARY }) },
        { name: 'chip-ev', change: 'Same spot with chip utilities (BB).', spot: small({ chip: true }) },
      ] });
  }
  // ---------- 3. closed form: A-K-Q river with satellite values (three left, two seats) ----------
  def('known-sat-akq-river', {
    utility: SEAT,
    title: 'Known small game: A-K-Q river with satellite values (three left, two seats; closed-form mixed equilibrium)', kind: 'test',
    hero: { seat: 1, position: 'Seat 2', hand: 'KhKd' }, history: ['All-in'],
    description: {
      effectiveStacksBB: 10, stacksBB: { 'Seat 1': 10, 'Seat 2': 10, 'third player (not in the hand)': 12 }, payouts: { unit: 'seats', places: [1, 1] }, positions: 'heads-up river; a third player with 12 BB is not in the hand; three left, two win a seat',
      actionHistory: 'River 2c 3d 7h 8s 9c, pot 10 BB. Seat 1 (aces one time in five, queens four times in five) bets 10 BB (all-in). Seat 2 (kings) to act: call or fold.', board: '2c 3d 7h 8s 9c',
      betSizes: { river: 'one pot-size bet (which is all-in), no raises' }, utility: { model: 'icm', unit: 'probability of winning a seat', convention: 'Malmuth-Harville ICM with two equal prizes of 1 among three players (the ordinary ICM of the program).' },
      abstraction: 'Exact cards.', continuation: 'none', rangeWeights: 'Seat 1: AhAd at weight 0.25 and QhQd at weight 1. Seat 2: KhKd.',
      knownSolution: 'Write v(a, b) for the seat probability of a player with a BB when the other player of the hand has b BB and the third player 12 BB (v = 0 without chips; v = 1 when the other player of the hand has none, because two players are then left for two seats). Seat 1 holds queens four times as often as aces. Seat 2 (kings) is indifferent between calling and folding when the queens bet with probability q, where 4q / (1 + 4q) = F / W, F = v(10, 20) (fold), W = 1 (call and win); calling and losing is worth 0. So q = F / (4 (1 - F)). Seat 1 is indifferent with queens when the kings call with probability c = 1 - C / B, B = v(20, 10) (the bluff works), C = v(10, 20) (queens check and lose the pot). Aces always bet. tests/v513.test.js computes q and c with an independent ICM and compares the trained frequencies with them. In the chip game with these ranges q = 1/4 and c = 1/2; with satellite values both move, because losing all chips costs more than winning them gains. (With queens and aces equally likely the satellite game has no mixing at all: the kings fold even to a bettor who always bluffs.)',
      assumptions: ['A textbook polarised-range game with tournament values, used to test the study report against a closed form.'] },
    study: { seeds: [1, 2, 3, 4, 5, 6], budgetsDeals: [1000, 10000, 100000, 1000000, 4000000], memoryMiB: 64, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.005, frequency: 0.05, quality: 0.002, frequencyShift: 0.15 } },
    variants: [{ name: 'baseline', change: '', spot: { ...base(3, 'River', 2), dealt: 2, payoff: 'icm', payouts: 'satellite 2', others: '12', study: 'postflop', abstraction: 'exact', memoryMiB: 64, board: '2c 3d 7h 8s 9c', common: '9.8', folded: '', tree: tree([''], [''], ['100']), seats: [seat('Seat 1', 10, 'AhAd:0.25,QhQd'), seat('Seat 2', 10, 'KhKd')] } }],
  });
  // ---------- 4. closed form: folding aces on the bubble (three left, two seats) ----------
  def('sat3-fold-aces', {
    table: { players: 3, smallBlind: 0.5, bigBlind: 1, antePerPlayer: 0.1, startingPotBeforeVoluntaryAction: 1.8, unit: 'BB' }, utility: SEAT,
    title: 'Known small game: folding aces on the satellite bubble (three left, two seats, a button with 2 BB)', kind: 'test',
    hero: { seat: 1, position: 'BB', hand: 'AsAh' }, history: ['All-in'],
    description: {
      effectiveStacksBB: 25, stacksBB: { BTN: 2, SB: 30, BB: 25 }, payouts: { unit: 'seats', places: [1, 1] }, positions: 'three left, two win a seat: BTN 2 BB (folded), SB 30, BB 25',
      actionHistory: 'BTN (2 BB) folds. SB (30 BB) moves all-in with kings. Big blind (25 BB, aces) to act: call or fold.', board: 'none (preflop)',
      betSizes: { preflop: 'small blind: fold or all-in; big blind: fold or call' }, utility: { model: 'icm', unit: 'probability of winning a seat', convention: 'Malmuth-Harville ICM with two equal prizes of 1 among three players.' },
      abstraction: 'Exact cards.', continuation: 'none', rangeWeights: 'SB: KdKc. BB: AsAh.',
      knownSolution: 'EV(fold) = the seat probability of 23.9 BB against 31.2 and 1.9 BB. EV(call) = P(aces win) x v(win) + P(tie) x v(tie) + P(aces lose) x 0, with the all-in equity of AsAh against KdKc. Both are computed independently in tests/v513.test.js. Folding is worth more than calling although the aces win about 82% of the time: a seat is nearly certain after a fold and nothing more is won by calling.',
      assumptions: ['The small blind holds one hand; the point of the fixture is the two action values of the big blind, which do not depend on how often the small blind moves in.'] },
    study: { seeds: [1, 2, 3], budgetsDeals: [1000, 10000, 100000], memoryMiB: 64, ev: { method: 'exact' }, quality: { method: 'exact' }, tolerance: { evGap: 0.005, frequency: 0.05, quality: 0.002, frequencyShift: 0.15 } },
    variants: [{ name: 'baseline', change: '', spot: { ...base(2, 'Preflop', 3), study: 'linked', payoff: 'icm', payouts: 'satellite 2', others: '1.9', abstraction: 'exact', memoryMiB: 64, preOpen: 'a', preRaises: 'a', preCap: 2, preLimps: false, tree: tree([''], [''], ['']), seats: [seat('SB', 30, 'KdKc'), seat('BB', 25, 'AsAh')] } }],
  });
};
