// EightMax 5.12: what the 6-max preflop library is, measured from the shipped files.
//   node tools/library512.js <out.json>
// For every chart: its size, the generator's record, the exploitability recomputed from the 6-bit values the
// interface loads (push/fold: inside the push/fold game; 15-100 BB: inside the preflop model game), and the first-in
// frequencies per position beside the 8-max chart of the same depth. Nothing here is a distance to the equilibrium
// of full poker and no percentage of GTO is derived from it. No chart is changed.
'use strict';
process.env.EXTRA_LIBS = 'lib_deep.js,lib_charts.js,lib_charts6.js,lib_deeplib.js,lib_deeplib6.js';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const E = require('./loadlib.js');
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname, '../web', f))).digest('hex');
const unrle = (L, s) => s.replace(/\.(.)(.)/g, (_, c, n) => c.repeat(L.alph.indexOf(n) + 4));
function pushFold(C) {
  const n = C.n, pos = E.pfPositions(n), rows = [];
  for (const S of C.stacks) {
    const str = C.data[S], f = k => Float64Array.from({ length: 169 }, (_, h) => C.alph.indexOf(str[k * 169 + h]) / 63);
    const jam = [], call = []; let k = 0;
    for (let i = 0; i < n - 1; i++) jam.push(f(k++));
    for (let i = 0; i < n - 1; i++) { call.push(Array(n).fill(null)); for (let j = i + 1; j < n; j++) call[i][j] = f(k++); }
    const s = E.PushFold({ n, stacks: Array(n).fill(S), anteType: C.anteType, ante: C.ante }); s.load({ jam, call }); const r = s.results();
    rows.push({ stackBB: S, values: str.length, expectedValues: 169 * (n - 1 + n * (n - 1) / 2), generatorIterations: C.meta[S].it, generatorExploitabilityBB: C.meta[S].ex, exploitabilityAfterQuantisationBB: r.exploit,
      firstInJamPct: Object.fromEntries(pos.slice(0, n - 1).map((p, i) => [p, +r.jam[i].pct.toFixed(2)])) });
  }
  return rows;
}
function deep(L) {
  const n = L.base.n, pos = E.pfPositions(n), rows = [];
  for (const S of L.depths) {
    const m = E.DeepTree({ ...L.base, stack: S }), packed = unrle(L, L.data[S]); m.load(packed);
    const ex = m.exploitability(); m.evaluate();
    const first = {}; for (let seat = 0; seat < n - 1; seat++) { const v = m.view(m.firstIn(seat)); first[pos[seat]] = { raisePct: +v.actions.filter(a => a.kind >= 2).reduce((x, a) => x + a.pct, 0).toFixed(2), limpPct: +v.actions.filter(a => a.kind === 1).reduce((x, a) => x + a.pct, 0).toFixed(2) }; }
    rows.push({ stackBB: S, packedValues: packed.length, expectedValues: m.pack().length, generatorIterations: L.meta[S].it, publishedModelExploitabilityBB: L.meta[S].ex, modelExploitabilityRecomputedBB: ex, sizes: m.sizes, firstIn: first });
  }
  return rows;
}
const out = {
  what: 'EightMax 5.12 preflop library, measured from the shipped files by tools/library512.js',
  meaning: 'push/fold exploitability is the largest gain of one seat\'s best response inside the push/fold game (BB per hand); the 15-100 BB value is the same inside the preflop model game with fitted flop values. Neither is a distance to the equilibrium of full poker.',
  files: Object.fromEntries(['lib_charts.js', 'lib_deeplib.js', 'lib_charts6.js', 'lib_deeplib6.js'].map(f => [f, { bytes: fs.statSync(path.join(__dirname, '../web', f)).size, sha256: sha(f) }])),
  sixMax: { base: { n: E.CHARTS6.n, anteType: E.CHARTS6.anteType, ante: E.CHARTS6.ante }, positions: E.pfPositions(6), pushFold: pushFold(E.CHARTS6), deep: deep(E.DEEP_LIB6) },
  eightMax: { base: { n: E.CHARTS.n, anteType: E.CHARTS.anteType, ante: E.CHARTS.ante }, positions: E.pfPositions(8), pushFold: pushFold(E.CHARTS), deep: deep(E.DEEP_LIB) },
};
const worst = rows => Math.max(...rows.map(r => r.exploitabilityAfterQuantisationBB ?? r.modelExploitabilityRecomputedBB));
out.summary = { sixMax: { pushFoldCharts: out.sixMax.pushFold.length, largestGeneratorExploitabilityBB: Math.max(...out.sixMax.pushFold.map(r => r.generatorExploitabilityBB)), largestPushFoldExploitabilityAfterQuantisationBB: worst(out.sixMax.pushFold), deepCharts: out.sixMax.deep.length, largestModelExploitabilityBB: worst(out.sixMax.deep) },
  eightMax: { pushFoldCharts: out.eightMax.pushFold.length, largestGeneratorExploitabilityBB: Math.max(...out.eightMax.pushFold.map(r => r.generatorExploitabilityBB)), largestPushFoldExploitabilityAfterQuantisationBB: worst(out.eightMax.pushFold), deepCharts: out.eightMax.deep.length, largestModelExploitabilityBB: worst(out.eightMax.deep) } };
// six against eight, same position name and depth (information)
const cmp = [];
for (const r6 of out.sixMax.pushFold) { const r8 = out.eightMax.pushFold.find(r => r.stackBB === r6.stackBB); for (const p of Object.keys(r6.firstInJamPct)) cmp.push({ chart: 'push/fold', stackBB: r6.stackBB, position: p, sixMaxPct: r6.firstInJamPct[p], eightMaxPct: r8.firstInJamPct[p], difference: +(r6.firstInJamPct[p] - r8.firstInJamPct[p]).toFixed(2) }); }
for (const r6 of out.sixMax.deep) { const r8 = out.eightMax.deep.find(r => r.stackBB === r6.stackBB); for (const p of Object.keys(r6.firstIn)) cmp.push({ chart: '15-100 BB, first-in raise', stackBB: r6.stackBB, position: p, sixMaxPct: r6.firstIn[p].raisePct, eightMaxPct: r8.firstIn[p].raisePct, difference: +(r6.firstIn[p].raisePct - r8.firstIn[p].raisePct).toFixed(2) }); }
out.sixAgainstEight = { note: 'INFORMATION. Different games: two antes less six-handed. Expected, not proven: equal or slightly tighter for the same position name.', rows: cmp,
  widerSixHanded: cmp.filter(r => r.difference > 0.005).length, tighterSixHanded: cmp.filter(r => r.difference < -0.005).length, largestWider: Math.max(...cmp.map(r => r.difference)), largestTighter: Math.min(...cmp.map(r => r.difference)) };
fs.writeFileSync(process.argv[2], JSON.stringify(out, null, 1) + '\n');
console.log(JSON.stringify(out.summary)); console.log(JSON.stringify({ wider: out.sixAgainstEight.widerSixHanded, tighter: out.sixAgainstEight.tighterSixHanded, largestWider: out.sixAgainstEight.largestWider, largestTighter: out.sixAgainstEight.largestTighter }));
for (const S of [5, 10, 15, 20]) { const r = out.sixMax.pushFold.find(x => x.stackBB === S), r8 = out.eightMax.pushFold.find(x => x.stackBB === S); console.log('push/fold', S, 'bb  6-max', JSON.stringify(r.firstInJamPct), ' 8-max', JSON.stringify(Object.fromEntries(Object.entries(r8.firstInJamPct).slice(2)))); }
for (const S of [25, 100]) { const r = out.sixMax.deep.find(x => x.stackBB === S), r8 = out.eightMax.deep.find(x => x.stackBB === S); console.log('deep', S, '6-max', JSON.stringify(Object.fromEntries(Object.entries(r.firstIn).map(([k, v]) => [k, v.raisePct]))), ' 8-max', JSON.stringify(Object.fromEntries(Object.entries(r8.firstIn).slice(2).map(([k, v]) => [k, v.raisePct])))); }
