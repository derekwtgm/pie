'use strict';
// EightMax 5.12: the 6-max charts beside two other solvers of this program. INFORMATION ONLY: no chart is changed or
// rejected by it (validation/5.12/plan.json, written before anything was measured, says why: the other solvers play
// other games, and their results are sampled).
//   node tools/chart_validation512.js <mwcli> <out.json> [--deals=2000000] [--updates=20000] [--only=native|linked]
// 1. Push/fold chart against the NATIVE multiway engine: the six-handed shove/call game at 8 and 15 BB, Compact hand
//    groups (169 classes before the flop), sampled deals with the counter-based streams, seeds 601 and 602. The
//    engine deals real cards to all six seats and lets several players call; the chart ends the action heads-up
//    after the first caller and removes cards by pairs. First-in all-in frequency per position.
// 2. 15-100 BB chart against the LINKED preflop-to-river JavaScript solver (as tools/chart_validation29.js did for
//    8-max): six seats, 15 and 25 BB, seeds 17 and 29, one bet size per street, real cards instead of the chart's
//    fitted realization values. First-in raise frequency per position.
process.env.EXTRA_LIBS = 'lib_deep.js,lib_charts6.js,lib_deeplib6.js';
const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), cp = require('node:child_process');
const E = require('./loadlib.js'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river', 'lib_river_ui']) require(path.join(__dirname, '../web', l + '.js'));
const [cliArg, out] = process.argv.slice(2), opt = (k, d) => { const a = process.argv.find(x => x.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3) : d; };
if (!cliArg || !out) { console.error('usage: node tools/chart_validation512.js <mwcli> <out.json> [--deals=N] [--updates=N] [--only=native|linked]'); process.exit(2); }
const cli = path.resolve(cliArg), deals = +opt('deals', 2000000), updates = +opt('updates', 20000), only = opt('only', ''), N = 6, pos = E.pfPositions(N);
const report = { what: 'EightMax 5.12: 6-max charts beside the native shove/call engine and the linked JavaScript solver', rule: 'INFORMATION ONLY (validation/5.12/plan.json): no chart is changed or rejected. A first-in difference above 5 points (push/fold) or 10 points (15-100 BB) is listed as unresolved.',
  cpu: os.cpus()[0].model, logicalProcessors: os.cpus().length, pushFold: [], deep: [], unresolved: [] };
const save = () => fs.writeFileSync(out, JSON.stringify(report, null, 1) + '\n');
if (only !== 'linked') {
  const C = E.CHARTS6, dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em512-cv-'));
  for (const S of [8, 15]) {
    const str = C.data[S], chart = pos.slice(0, N - 1).map((p, i) => { let w = 0, t = 0; for (let h = 0; h < 169; h++) { const c = E.CLASS_NCOMBOS[h]; w += c * C.alph.indexOf(str[i * 169 + h]) / 63; t += c; } return 100 * w / t; });
    const seeds = [];
    for (const seed of [601, 602]) {
      const spot = { ...E.multiwayExample(N, 'Shove / call', N), privateMode: 'sampled', traversal: 'external', batchDeals: 1, privateSeed: seed, engine: 'native', measured: false, processingMode: 'cpu', abstraction: 'compact', memoryMiB: 1024, others: '' };
      spot.seats = pos.map(name => ({ name, stack: String(S), prior: '0', range: 'random', lead: true }));
      const game = E.MultiwayGame({ ...E.multiwaySpotConfig(spot), engine: 'native' }), why = game.nativeSupport(); if (why) throw new Error(why);
      const spec = { ...game.nativeSpec(), trainingStreams: 'philox64' }, sf = path.join(dir, 'spec.json'), st = path.join(dir, 'state'), q = path.join(dir, 'q.json'); fs.writeFileSync(sf, JSON.stringify(spec));
      const t0 = Date.now(), info = JSON.parse(cp.execFileSync(cli, [sf, String(deals), '1', st, '1024'], { encoding: 'utf8', maxBuffer: 64 << 20 }));
      const freq = [], p = [];
      for (let seat = 0; seat < N - 1; seat++) {
        fs.writeFileSync(q, JSON.stringify({ path: p, board: [], limit: 1 })); const n = JSON.parse(cp.execFileSync(cli, ['--node', sf, st, q, '1024'], { encoding: 'utf8', maxBuffer: 256 << 20 }));
        if (n.node.kind !== 'decision' || n.node.actor !== seat) throw new Error('seat ' + seat + ' is not to act after ' + seat + ' folds');
        const jam = n.actions.findIndex(a => a.name === 'All-in'), fold = n.actions.find(a => a.name === 'Fold'); freq.push(100 * n.aggregate.average[jam]); p.push(fold.slot);
      }
      seeds.push({ seed, deals: info.trainingDeals, rows: info.rows, seconds: (Date.now() - t0) / 1000, trainingStreams: info.trainingStreams, limitReached: !!info.limitReached, firstInJamPct: freq });
      process.stderr.write('push/fold ' + S + ' bb seed ' + seed + ': ' + ((Date.now() - t0) / 1000).toFixed(0) + ' s\n');
    }
    const rows = pos.slice(0, N - 1).map((position, i) => { const e = seeds.map(s => s.firstInJamPct[i]), mean = e.reduce((a, b) => a + b, 0) / e.length; return { position, chartPct: +chart[i].toFixed(2), enginePct: e.map(x => +x.toFixed(2)), difference: +(mean - chart[i]).toFixed(2), seedSpread: +(Math.max(...e) - Math.min(...e)).toFixed(2) }; });
    for (const r of rows) if (Math.abs(r.difference) > 5) report.unresolved.push({ chart: 'push/fold', stackBB: S, ...r });
    report.pushFold.push({ stackBB: S, dealsPerSeed: deals, game: 'six seats, shove or fold, every later seat may call or fold; Compact hand groups; chip EV; 0.1 BB ante each', rows, seeds: seeds.map(({ firstInJamPct, ...s }) => s) });
    console.log('\n' + S + ' bb first-in all-in %: chart | native engine (seeds 601, 602)'); for (const r of rows) console.log('  ' + r.position.padEnd(4) + ' chart ' + r.chartPct.toFixed(1).padStart(5) + '   engine ' + r.enginePct.map(x => x.toFixed(1)).join(' / ') + '   difference ' + (r.difference > 0 ? '+' : '') + r.difference.toFixed(1));
    save();
  }
  // 1b. A diagnostic ADDED AFTER the first results were seen (not part of the plan written beforehand; information):
  // the largest difference of part 1 is the small blind's. The same engine, the same stacks and antes, but only the
  // small blind and the big blind are dealt cards (the other four seats are folded seats without cards). What is
  // left of the difference then is not caused by the cards of the folded players.
  for (const S of [8, 15]) {
    const str = C.data[S]; let w = 0, t = 0; for (let h = 0; h < 169; h++) { const c = E.CLASS_NCOMBOS[h]; w += c * C.alph.indexOf(str[4 * 169 + h]) / 63; t += c; } const chartPct = 100 * w / t, e = [];
    for (const seed of [601, 602]) {
      const spot = { ...E.multiwayExample(2, 'Shove / call', N), privateMode: 'sampled', traversal: 'external', batchDeals: 1, privateSeed: seed, engine: 'native', measured: false, processingMode: 'cpu', abstraction: 'compact', memoryMiB: 1024, others: Array(N - 2).fill(S - 0.1).join(',') };
      spot.seats = ['SB', 'BB'].map(name => ({ name, stack: String(S), prior: '0', range: 'random', lead: true }));
      const game = E.MultiwayGame({ ...E.multiwaySpotConfig(spot), engine: 'native' }), why = game.nativeSupport(); if (why) throw new Error(why);
      const sf = path.join(dir, 'hu.json'), st = path.join(dir, 'hu.state'), q = path.join(dir, 'q.json'); fs.writeFileSync(sf, JSON.stringify({ ...game.nativeSpec(), trainingStreams: 'philox64' }));
      cp.execFileSync(cli, [sf, String(deals), '1', st, '1024'], { encoding: 'utf8', maxBuffer: 64 << 20 }); fs.writeFileSync(q, JSON.stringify({ path: [], board: [], limit: 1 }));
      const n = JSON.parse(cp.execFileSync(cli, ['--node', sf, st, q, '1024'], { encoding: 'utf8', maxBuffer: 256 << 20 })); if (Math.abs(n.node.pot - 2.1) > 1e-9 || n.node.actor !== 0) throw new Error('not the small blind first in with 2.1 BB in the pot');
      e.push(100 * n.aggregate.average[n.actions.findIndex(a => a.name === 'All-in')]);
    }
    const six = report.pushFold.find(x => x.stackBB === S).rows.find(r => r.position === 'SB');
    (report.smallBlindDiagnostic = report.smallBlindDiagnostic || { addedAfterSeeingPart1: true, what: 'small blind first in, all-in or fold, against the big blind; six antes; 1: all six seats dealt real cards and four fold (part 1); 2: only the two blinds are dealt cards', rows: [] }).rows.push(
      { stackBB: S, chartPct: +chartPct.toFixed(2), engineSixSeatsDealtPct: six.enginePct, engineOnlyBlindsDealtPct: e.map(x => +x.toFixed(2)), dealsPerSeed: deals });
    console.log('\n' + S + ' bb small blind first in, all-in %: chart ' + chartPct.toFixed(1) + ' | engine, six seats dealt ' + six.enginePct.map(x => x.toFixed(1)).join(' / ') + ' | engine, only the blinds dealt ' + e.map(x => x.toFixed(1)).join(' / '));
    save();
  }
  fs.rmSync(dir, { recursive: true, force: true });
}
if (only !== 'native') {
  const L = E.DEEP_LIB6, un = s => s.replace(/\.(.)(.)/g, (_, c, n) => c.repeat(L.alph.indexOf(n) + 4));
  for (const S of [15, 25]) {
    const m = E.DeepTree({ ...L.base, stack: S }); m.load(un(L.data[S]));
    const chart = pos.slice(0, N - 1).map((p, seat) => { const v = m.view(m.firstIn(seat)); return { position: p, raisePct: v.actions.filter(a => a.kind >= 2).reduce((x, a) => x + a.pct, 0), limpPct: v.actions.filter(a => a.kind === 1).reduce((x, a) => x + a.pct, 0) }; });
    const sizes = E.deepDefaultSizes(S), seeds = [];
    for (const seed of [17, 29]) {
      const cfg = { preflop: { mode: 'linked', opens: String(sizes.open) + ',' + String(sizes.sbOpen), raises: '3x,a', maxBets: 3, limps: false }, board: '', dealt: N, common: 0, stacks: Array(N).fill(S), ranges: Array(N).fill('random'),
        streets: { flop: { bets: '50', raises: '', maxBets: 1 }, turn: { bets: '75', raises: '', maxBets: 1 }, river: { bets: '100', raises: '', maxBets: 1 } }, privateMode: 'sampled', evaluationDeals: 2048, privateSeed: seed, batchDeals: 4, strategyBudgetMiB: 256 };
      const g = E.MultiwayGame(cfg), t0 = Date.now();
      const read = () => { const freq = []; let p = []; for (let seat = 0; seat < N - 1; seat++) { const v = g.view(p); if (v.kind !== 'player' || v.seat !== seat) break; const fold = v.actions.findIndex(a => a.label === 'Fold');
        freq.push({ raisePct: 100 * v.actions.filter(a => /^Raise|^All-in|^Bet/.test(a.label)).reduce((x, a) => x + a.frequency, 0), limpPct: 100 * v.actions.filter(a => /^Call|^Check/.test(a.label)).reduce((x, a) => x + a.frequency, 0) }); p = [...p, fold]; } return freq; };
      g.iterate(updates); seeds.push({ seed, seconds: (Date.now() - t0) / 1000, freq: read(), completedUpdates: g.iterations, memoryBudgetReached: g.limitReached, strategyMiB: g.strategyMiB });
      process.stderr.write('linked ' + S + ' bb seed ' + seed + ': ' + ((Date.now() - t0) / 1000).toFixed(0) + ' s\n');
    }
    const rows = chart.map((c, i) => { const e = seeds.map(s => s.freq[i] ? s.freq[i].raisePct : NaN), mean = e.reduce((a, b) => a + b, 0) / e.length; return { position: c.position, chartRaisePct: +c.raisePct.toFixed(2), chartLimpPct: +c.limpPct.toFixed(2), linkedRaisePct: e.map(x => +x.toFixed(2)), linkedLimpPct: seeds.map(s => s.freq[i] ? +s.freq[i].limpPct.toFixed(2) : null), difference: +(mean - c.raisePct).toFixed(2) }; });
    for (const r of rows) if (!(Math.abs(r.difference) <= 10)) report.unresolved.push({ chart: '15-100 BB', stackBB: S, ...r });
    report.deep.push({ stackBB: S, sizes, requestedUpdates: updates, game: 'linked preflop-to-river solver: six seats, opens of the chart sizes, 3x or all-in raises, no limps, one bet size per street, Detailed hand groups, sampled', rows, seeds: seeds.map(({ freq, ...s }) => s) });
    console.log('\n' + S + ' bb first-in raise %: chart [limp] | linked solver (seeds 17, 29)'); for (const r of rows) console.log('  ' + r.position.padEnd(4) + ' chart ' + r.chartRaisePct.toFixed(1).padStart(5) + ' [' + r.chartLimpPct.toFixed(1) + ']   linked ' + r.linkedRaisePct.map(x => x.toFixed(1)).join(' / ') + '   difference ' + (r.difference > 0 ? '+' : '') + r.difference.toFixed(1));
    save();
  }
}
report.note = 'Both references are independent of the chart generator but approximate themselves (sampled training; other rules of the game). Differences show where the models disagree; they are not corrections.';
save(); console.log('\nunresolved by the rule written beforehand: ' + report.unresolved.length);
