// EightMax 5.8: controlled tournament reference games, added to the games of tools/games48.js.
//
// Every game is small enough for an EXACT best response of every seat inside its abstraction (mwcli --gain method
// exact), so exact NashConv exists for it and the sampled, restricted and trained-response measures can be compared
// with the truth. They are CONTROLLED FIXTURES, not models of real tournament play: ranges are a handful of hands, bet
// sizes are a coarse menu, and nothing before the first decision is modelled beyond the chips already in the pot.
// What each one represents and what it leaves out is stated in its `stage` and `abstraction` entries, which the
// reports print next to its results.
//
// Tournament structure of the preflop games (unchanged defaults): small blind 0.5 BB, big blind 1 BB, ante 0.1 BB per
// player (eight-handed: 2.3 BB in the pot before the first action); no big-blind ante.
//
//   node tools/games58.js list
//   node tools/games58.js spec <key> <out.json> [seed] [extra-json]
//   node tools/games58.js describe          (JSON: key, title, stage, abstraction, players, utility of every game)
'use strict';
const path = require('node:path'), fs = require('node:fs');
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river']) require('../web/' + l);
const g48 = require('./games48.js');
const base = g48.base;
// [key, title, options, tournament stage, abstraction and assumptions]
const added = [
  ['early3-flop', 'Early stage, deep stacks: three-player flop, two flop bet sizes, turn and river bets, weighted ranges, chip EV',
    { board: 'Kh9d4c', dealt: 8, common: 1.5, stacks: [97.5, 97.5, 97.5], prior: Array(3).fill(2.5),
      ranges: ['AsKs,9h9c:0.5,JdTd,7s6s:0.75', 'KdQd,AhJh:0.75,4d4h:0.5,8c7c', 'KcJc:0.75,AdAc:0.25,QsTs,6h5h'],
      streets: { flop: { bets: '33,75', raises: '', maxBets: 1 }, turn: { bets: '66', raises: '', maxBets: 1 }, river: { bets: '75', raises: '', maxBets: 1 } } },
    'early stage (100 BB stacks; 2.5 BB each already in, the blinds (1.5 BB) and eight antes (0.8 BB) dead in the middle: 9.8 BB pot)',
    'Three seats see a flop with about 97 BB behind. Four hands a seat, weighted. Flop: check, bet a third or three quarters of the pot; turn: bet two thirds; river: bet three quarters; no raises. Three streets of betting follow one another (a multi-street continuation). The five folded seats are represented only by the dead money.'],
  ['mid3-turn', 'Medium stacks: three-player turn and river, two turn bet sizes and an all-in raise, weighted ranges, unequal stacks, chip EV',
    { board: 'Js8s3d2c', dealt: 8, common: 1.5, stacks: [22, 30, 14], prior: Array(3).fill(4),
      ranges: ['AsJd,8h8d:0.5,Ts9s,KdQd:0.75', 'KsJh,AhAd:0.25,9d7d,QsTd:0.75', 'JcTc:0.75,3s3h:0.5,Ac5c,7s6s'],
      streets: { turn: { bets: '50,a', raises: 'a', maxBets: 2 }, river: { bets: '66', raises: '', maxBets: 1 } } },
    'middle stage (14 to 30 BB behind after 4 BB each; with the dead blinds and antes a 14.3 BB pot)',
    'Three seats on the turn with unequal stacks, so an all-in creates a side pot. Turn: check, bet half the pot or all-in, and an all-in raise over a bet; river: one bet of two thirds of the pot. Four weighted hands a seat.'],
  ['short8-push', 'Short stacks: eight-handed push or fold, unequal stacks of 5 to 15 BB, weighted two-hand ranges, chip EV',
    { preflop: { mode: 'shove' }, board: '', dealt: 8, common: 0, stacks: [12, 8, 15, 6, 10, 5, 9, 14],
      ranges: ['AsKh,7c6c:0.5', 'QsQh,Kd9d:0.5', 'AdJd,5s5h:0.5', 'KsKc,Tc9c:0.5', 'AhQc,8d7d:0.5', 'JsJh,Ac4c:0.5', 'TsTd,Kh8h:0.5', '9s9d,Qd6d:0.5'],
      batchDeals: 4, actionStreams: 'deal' },
    'late stage, short stacks (5 to 15 BB), no payout pressure modelled',
    'Eight seats, blinds 0.5/1 and a 0.1 BB ante each (2.3 BB before the first action). Every decision is all-in or fold, so several all-ins give layered side pots. Two hands a seat, the second at half weight. Chip EV: no prize structure.'],
  ['bubble5-icm', 'Bubble: five players, four paid, unequal stacks, weighted two-hand ranges, push or fold (ICM)',
    { preflop: { mode: 'shove' }, board: '', dealt: 5, common: 0, stacks: [18, 9, 26, 5, 12],
      ranges: ['AsAh,8c7c:0.5', 'KsKh:0.75,Ad3d', 'QsQh,7d6d:0.5', 'JsJh:0.5,Ks9s', 'TsTh,Ac5c:0.75'], icm: { payouts: [40, 27, 19, 14] },
      batchDeals: 4, actionStreams: 'deal' },
    'bubble (five players, four prizes of 40, 27, 19 and 14 units)',
    'Five-handed table (blinds 0.5/1, ante 0.1 each), push or fold. Utility is the Malmuth-Harville prize equity of the final chip counts (ICM); the short stack is the bubble risk. Two weighted hands a seat. Future hands and position changes are not modelled (ICM never does).'],
  ['sidepot3-icm', 'Final three: river with unequal stacks and side pots, two bet sizes and an all-in raise (ICM, three prizes)',
    { board: 'Ks8d5h2c2s', common: 6, stacks: [4, 12, 30], ranges: ['AhKh,KdQd,8s8h,JsTs,7s6s,AcQc', 'AsKd,KcJc,5d5c,8h7h,AdQd,JdTd', 'Kc9c,QsQc,7d7c,Ah5s,Td9d,JhJc'],
      streets: { river: { bets: '75,a', raises: 'a', maxBets: 2 } }, icm: { payouts: [50, 30, 20] } },
    'final table, three left (prizes 50, 30, 20 units)',
    'Three seats on the river with 4, 12 and 30 BB behind: a call by the short stack builds a side pot between the other two. River: check, bet three quarters of the pot or all-in, all-in raise. Utility is the prize equity of the final chip counts (ICM). Six hands a seat.'],
];
const meta48 = {
  'hu-river': ['any stage, heads-up', 'River only, six hands a seat, half-pot bet or all-in and an all-in raise. Two-player chip EV: NashConv / 2 is exploitability.'],
  'hu-turn': ['any stage, heads-up', 'Turn (all-in or check) and river (half-pot bet), four hands a seat. Two-player chip EV.'],
  'river3-chip': ['multiway pot with side pots', 'Three seats on the river, stacks 4, 12 and 30 BB, three-quarter-pot bet or all-in and an all-in raise, six hands a seat. Chip EV.'],
  'turn4': ['middle stage, four-way pot', 'Four seats on the turn with unequal stacks (6 to 40 BB): all-in or check/fold on the turn, half-pot river bet. Two hands a seat. Chip EV.'],
  'flop6': ['multiway all-in with side pots', 'Six seats on the flop, stacks 3 to 50 BB, all-in or fold, two hands a seat. Chip EV.'],
  'final8': ['final table', 'Eight-handed push or fold with one fixed hand a seat; ICM with eight prizes.'],
  'bubble4': ['bubble', 'Four players, three paid, push or fold, weighted two-hand ranges; ICM.'],
  'flop5': ['multiway all-in with side pots', 'Five seats on the flop, stacks 4 to 40 BB, all-in or fold, two hands a seat. Chip EV.'],
  'flop6w': ['multiway pot, two bet sizes', 'Six seats on the flop, weighted three-hand ranges, half-pot bet or all-in. Chip EV.'],
  'final8w': ['final table', 'Eight-handed push or fold with weighted two-hand ranges; ICM with eight prizes.'],
};
const games = [...g48.games.map(g => ({ key: g[0], title: g[1], options: g[2], stage: (meta48[g[0]] || ['', ''])[0], abstraction: (meta48[g[0]] || ['', ''])[1], from: '4.8', zeroSum: g[4] })),
               ...added.map(g => ({ key: g[0], title: g[1], options: g[2], stage: g[3], abstraction: g[4], from: '5.8', zeroSum: false }))];
const byKey = Object.fromEntries(games.map(g => [g.key, g]));
function spec(key, seed = 1, extra = {}) {
  const g = byKey[key]; if (!g) throw new Error('unknown game ' + key);
  return E.MultiwayGame({ ...base, ...g.options, ...extra, privateSeed: seed }).nativeSpec();
}
module.exports = { games, byKey, spec, base };
if (require.main === module) {
  const [cmd, key, out, seed, extra] = process.argv.slice(2);
  if (cmd === 'list') for (const g of games) console.log(g.key.padEnd(14), g.title);
  else if (cmd === 'describe') console.log(JSON.stringify(games.map(g => { const s = spec(g.key); return { key: g.key, title: g.title, stage: g.stage, abstraction: g.abstraction, addedIn: g.from, players: s.n, startCards: s.board.length, utility: s.icm ? 'ICM prize equity' : 'chip EV (BB)', handsPerSeat: s.hands.map(h => h.length), stacks: s.rules.stacks, potBeforeFirstAction: s.rules.pot0 + s.rules.posted.reduce((a, b) => a + b, 0) }; }), null, 1));
  else if (cmd === 'spec') fs.writeFileSync(path.resolve(out), JSON.stringify(spec(key, +(seed || 1), extra ? JSON.parse(extra) : {})));
  else { console.error('usage: node tools/games58.js list | describe | spec <key> <out.json> [seed] [extra-json]'); process.exit(2); }
}
