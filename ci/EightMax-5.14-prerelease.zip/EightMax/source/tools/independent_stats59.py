#!/usr/bin/env python3
"""EightMax 5.9: an independent implementation of what 5.9 added to the trained-response measure.

It shares no code with the engine (Python integers and floats, the standard library only) and checks:

  philox      Philox4x64-10 written from the published description with arbitrary-precision integers: the three
              known-answer vectors of the reference implementation (Random123), numpy.random.Philox when numpy is
              installed (optional), and the numbers mwcli --streams59 prints for a list of stream addresses.
  bounds      the one-sided empirical-Bernstein bound of a seat, the simultaneous (union-bound) statement and the pooled
              statement over independent seats, recomputed from the per-seat sample statistics that mwcli --response
              prints, and compared with the numbers mwcli printed.
  coverage    EXACT miss probabilities of the one-sided bounds on two-point distributions (a finite sum of binomial
              probabilities; no simulation), for the distribution-free bound and for the 5.8 normal-approximation bound.

Usage:
  independent_stats59.py selfcheck [mwcli]             prints a JSON report; exit 0 when every check passes
  independent_stats59.py check <response.json> [...]   recomputes summary.simultaneous / summary.pooledIndependent
  independent_stats59.py coverage                      the two-point table as JSON
"""
import sys, json, math, itertools, subprocess

M64 = (1 << 64) - 1
M0, M1 = 0xD2E7470EE14C6C93, 0xCA5A826395121157          # Philox4x64 multipliers
W0, W1 = 0x9E3779B97F4A7C15, 0xBB67AE8584CAA73B          # Weyl key increments (golden ratio, sqrt(3) - 1)
DOMAIN59 = 0x45694D6178353959                              # second key word of every 5.9 evaluation stream


def philox4x64_10(counter, key):
    """One block: 4 x 64 output bits of a 4 x 64-bit counter under a 2 x 64-bit key."""
    c = list(counter); k = list(key)
    for r in range(10):
        if r:
            k[0] = (k[0] + W0) & M64; k[1] = (k[1] + W1) & M64
        p0 = M0 * c[0]; p1 = M1 * c[2]                     # 128-bit products
        c = [(p1 >> 64) ^ c[1] ^ k[0], p1 & M64, (p0 >> 64) ^ c[3] ^ k[1], p0 & M64]
    return c


KAT = [  # Random123 kat_vectors, "philox4x64 10"
    ((0, 0, 0, 0), (0, 0), (0x16554D9ECA36314C, 0xDB20FE9D672D0FDC, 0xD7E772CEE186176B, 0x7E68B68AEC7BA23B)),
    ((M64,) * 4, (M64,) * 2, (0x87B092C3013FE90B, 0x438C3C67BE8D0224, 0x9CC7D7C69CD777B6, 0xA09CAEBF594F0BA0)),
    ((0x243F6A8885A308D3, 0x13198A2E03707344, 0xA4093822299F31D0, 0x082EFA98EC4E6C89), (0x452821E638D01377, 0xBE5466CF34E90C6C),
     (0xA528F45403E61D95, 0x38C72DBD566E9788, 0xA5A1610E72FD18B5, 0x57BD43B5E52B7FE6)),
]


def stream59(seed, seat, block, purpose, count):
    """The first `count` 64-bit numbers of the 5.9 evaluation stream with this address."""
    out = []; j = 0
    while len(out) < count:
        out += philox4x64_10((j, block, seat, purpose), (seed, DOMAIN59)); j += 1
    return out[:count]


def to_unit(bits):
    return (bits >> 11) * (1.0 / 9007199254740992.0)


# ---- bounds (written from MATHEMATICAL-VALIDATION-5.9.md, section 2, not from the C++) ----
def eb_one_sided_half(variance, width, n, delta):
    L = math.log(2.0 / delta)
    return min(width, math.sqrt(2.0 * variance * L / n) + 7.0 * width * L / (3.0 * (n - 1.0)))


def sd_upper(variance, width, n, delta):
    return min(width / 2.0, math.sqrt(variance) + width * math.sqrt(2.0 * math.log(1.0 / delta) / (n - 1.0)))


def simultaneous(seats, alpha, analyses=1):
    """seats: list of dicts {available, mean, variance, n, width} or None for a seat without evaluation."""
    k = len(seats); delta = alpha / analyses / k; lowers = []; floored = 0.0
    for s in seats:
        if s is None: lowers.append(None); continue
        lo = s['mean'] - eb_one_sided_half(s['variance'], s['width'], s['n'], delta); lowers.append(lo); floored += max(0.0, lo)
    return {'perSeatAlpha': delta, 'lower': lowers, 'sumOfResponseGainsLowerBound': math.fsum(lowers) if all(x is not None for x in lowers) else None, 'nashConvLowerBound': floored}


def pooled(seats, alpha, analyses=1):
    k = len(seats); a = alpha / analyses; d_var = a / (2.0 * k); d_bern = a / (2.0 * (2 ** k - 1)); L1 = math.log(1.0 / d_bern)
    have = [i for i, s in enumerate(seats) if s is not None]; best = None; best_set = (); all_lower = None
    term = {i: (sd_upper(seats[i]['variance'], seats[i]['width'], seats[i]['n'], d_var) ** 2 / seats[i]['n'], seats[i]['width'] / seats[i]['n']) for i in have}
    for size in range(1, len(have) + 1):
        for sub in itertools.combinations(have, size):
            lower = sum(seats[i]['mean'] for i in sub) - math.sqrt(2.0 * L1 * sum(term[i][0] for i in sub)) - max(term[i][1] for i in sub) * L1 / 3.0
            if best is None or lower > best: best, best_set = lower, sub
            if len(sub) == k: all_lower = lower
    return {'deltaBernstein': d_bern, 'deltaVariance': d_var, 'allSeatsLower': all_lower, 'bestSubsetLower': best, 'bestSubset': list(best_set), 'nashConvLowerBound': max(0.0, best) if best is not None else 0.0}


# ---- exact coverage on two-point distributions ----
def two_point_miss(n, p, delta, kind):
    """P(lower bound > true mean) when each of n samples is 1 with probability p and 0 otherwise (range 1).
    kind 'eb': the one-sided empirical-Bernstein bound at level delta. kind 'normal': mean - 1.6448536269514722 SE."""
    mu = n * p; sd = math.sqrt(n * p * (1 - p)); lo = max(0, math.floor(mu - 60 * sd - 60)); hi = min(n, math.ceil(mu + 60 * sd + 60)); miss = 0.0
    lp, lq = math.log(p), math.log1p(-p)
    for K in range(lo, hi + 1):
        mean = K / n; var = K * (n - K) / (n * (n - 1.0))
        lower = mean - eb_one_sided_half(var, 1.0, n, delta) if kind == 'eb' else mean - 1.6448536269514722 * math.sqrt(var / n)
        if lower > p: miss += math.exp(math.lgamma(n + 1) - math.lgamma(K + 1) - math.lgamma(n - K + 1) + K * lp + (n - K) * lq)
    return miss


def coverage_table():
    rows = []
    for n in (1024, 20480, 204800):
        for p in (1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 0.1, 0.5, 0.9, 0.99, 1 - 1e-3, 1 - 1e-4, 1 - 1e-5, 1 - 1e-6):
            for delta in (0.05, 0.05 / 8, 0.001):
                rows.append({'n': n, 'p': p, 'delta': delta, 'missEmpiricalBernstein': two_point_miss(n, p, delta, 'eb'), 'missNormal95': two_point_miss(n, p, 0.05, 'normal') if delta == 0.05 else None})
    return rows


def close(a, b, tol=1e-11):
    if a is None or b is None: return a is None and b is None
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


def check_response(doc):
    """Recomputes the confidence statements of one mwcli --response result. Returns a list of differences."""
    S = doc['summary']; sim = S['simultaneous']; alpha = sim['alpha']; analyses = sim['analyses']; seats = []; problems = []
    for s in doc['seats']:
        x = s.get('sampled') or {}; st = x.get('statistics')
        if not st or x.get('available') is False: seats.append(None); continue
        if not st['withinProvenRange']: return ['a sample lay outside the proven range: the statements must be withdrawn'] if sim['calibrated'] else []
        seats.append({'mean': st['mean'], 'variance': st['sampleVariance'], 'n': float(st['samples']), 'width': st['provenSampleRange']})
        lb = x['lowerBound']; half = eb_one_sided_half(st['sampleVariance'], st['provenSampleRange'], float(st['samples']), lb['alpha'])
        if not close(half, lb['half']): problems.append('seat %d: lowerBound.half %r, recomputed %r' % (s['seat'], lb['half'], half))
        if not close(max(0.0, st['mean'] - half), lb['bestResponseGain']): problems.append('seat %d: lowerBound.bestResponseGain' % s['seat'])
    mine = simultaneous(seats, alpha, analyses)
    if not close(mine['perSeatAlpha'], sim['perSeatAlpha'], 1e-14): problems.append('perSeatAlpha %r, recomputed %r' % (sim['perSeatAlpha'], mine['perSeatAlpha']))
    for row, lo in zip(sim['seats'], mine['lower']):
        if not close(row['responseGainLowerBound'], lo): problems.append('seat %d: simultaneous responseGainLowerBound %r, recomputed %r' % (row['seat'], row['responseGainLowerBound'], lo))
    if not close(sim['sumOfResponseGainsLowerBound'], mine['sumOfResponseGainsLowerBound']): problems.append('simultaneous.sumOfResponseGainsLowerBound')
    if not close(sim['nashConvLowerBound'], mine['nashConvLowerBound']): problems.append('simultaneous.nashConvLowerBound %r, recomputed %r' % (sim['nashConvLowerBound'], mine['nashConvLowerBound']))
    po = S['pooledIndependent']; mp = pooled(seats, alpha, analyses)
    if not close(po['allocation']['perSubsetBernstein'], mp['deltaBernstein'], 1e-14) or not close(po['allocation']['perSeatVariance'], mp['deltaVariance'], 1e-14): problems.append('pooledIndependent.allocation')
    if not close(po['sumOfResponseGainsLowerBound'], mp['allSeatsLower']): problems.append('pooledIndependent.sumOfResponseGainsLowerBound %r, recomputed %r' % (po['sumOfResponseGainsLowerBound'], mp['allSeatsLower']))
    if not close(po['bestSubset']['sumOfResponseGainsLowerBound'], mp['bestSubsetLower']): problems.append('pooledIndependent.bestSubset %r, recomputed %r' % (po['bestSubset']['sumOfResponseGainsLowerBound'], mp['bestSubsetLower']))
    if not close(po['nashConvLowerBound'], mp['nashConvLowerBound']): problems.append('pooledIndependent.nashConvLowerBound')
    # the legacy number keeps its 5.8 definition
    if 'sumOfSeatLowerBounds95' in S:
        legacy = sum(max(0.0, s['sampled']['gain']['mean'] - 1.6448536269514722 * s['sampled']['gain']['stdErr']) for s in doc['seats'])
        if not close(S['sumOfSeatLowerBounds95'], legacy) or S['sumOfSeatLowerBounds95'] != S['sumOfNormalApproximationLowerBounds95']: problems.append('the 5.8 field sumOfSeatLowerBounds95 changed its value')
    return problems


def selfcheck(cli=None):
    checks = []
    def add(name, ok, detail): checks.append({'name': name, 'passed': bool(ok), 'detail': detail})
    bad = sum(1 for c, k, w in KAT if tuple(philox4x64_10(c, k)) != w)
    add('Philox4x64-10 (Python integers) reproduces the three known-answer vectors', bad == 0, '%d of 3 vectors differ' % bad)
    try:
        import numpy as np
        mism = 0; cases = [(c, k) for c, k, _ in KAT] + [((j, 7, 3, 1), (59, DOMAIN59)) for j in range(50)]
        for c, k in cases:
            # numpy increments the 256-bit counter before it generates a block: start one below the wanted counter
            v = (sum(x << (64 * i) for i, x in enumerate(c)) - 1) % (1 << 256); start = [(v >> (64 * i)) & M64 for i in range(4)]
            g = np.random.Philox(counter=np.array(start, dtype=np.uint64), key=np.array(k, dtype=np.uint64))
            mism += [int(x) for x in g.random_raw(4)] != philox4x64_10(c, k)
        add('numpy.random.Philox agrees with the Python implementation', mism == 0, '%d of %d blocks differ (numpy %s)' % (mism, len(cases), np.__version__))
    except ImportError:
        checks.append({'name': 'numpy.random.Philox agrees with the Python implementation', 'passed': None, 'detail': 'numpy is not installed: not checked'})
    if cli:
        addresses = [(1, 0, 0, 0), (1, 0, 0, 1), (58, 7, 195, 1), (4294967295, 3, 976562, 0), (59, 5, 12345, 1)]; diff = 0; n = 0
        for seed, seat, block, purpose in addresses:
            got = json.loads(subprocess.run([cli, '--streams59', str(seed), str(seat), str(block), str(purpose), '37'], capture_output=True, text=True, check=True).stdout)
            want = stream59(seed, seat, block, purpose, 37); n += 37
            diff += sum(1 for a, b in zip(got['bits'], want) if int(a, 16) != b) + sum(1 for a, b in zip(got['unit'], want) if a != to_unit(b))
        add('the engine draws the stream of an address as defined (mwcli --streams59)', diff == 0, '%d differences in %d numbers of %d addresses' % (diff, n, len(addresses)))
    rows = coverage_table(); worst = max(r['missEmpiricalBernstein'] / r['delta'] for r in rows); bad = [r for r in rows if r['missEmpiricalBernstein'] > r['delta']]
    add('two-point distributions: the one-sided empirical-Bernstein bound never misses more often than its level (exact binomial sums)', not bad, '%d cases; largest miss probability / level = %.3g' % (len(rows), worst))
    nb = max((r for r in rows if r['missNormal95'] is not None), key=lambda r: r['missNormal95'])
    add('two-point distributions: the 5.8 normal-approximation bound does miss far more often than 5% (the reason it is not a confidence statement)', nb['missNormal95'] > 0.5,
        'n = %d, P(large value) = 1 - %.0e: the bound exceeds the true mean with probability %.3f' % (nb['n'], 1 - nb['p'], nb['missNormal95']))
    return checks


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else ''
    if cmd == 'selfcheck':
        checks = selfcheck(sys.argv[2] if len(sys.argv) > 2 else None); print(json.dumps({'tool': 'independent_stats59', 'checks': checks}, indent=1))
        sys.exit(0 if all(c['passed'] is not False for c in checks) else 1)
    elif cmd == 'check':
        failed = 0
        for path in sys.argv[2:]:
            problems = check_response(json.load(open(path, encoding='utf-8-sig'))); failed += bool(problems)
            print(path + ': ' + ('agrees' if not problems else '; '.join(problems)))
        sys.exit(1 if failed else 0)
    elif cmd == 'coverage': print(json.dumps(coverage_table(), indent=1))
    else: print(__doc__); sys.exit(2)
