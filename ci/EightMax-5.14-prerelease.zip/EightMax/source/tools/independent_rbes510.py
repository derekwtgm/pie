#!/usr/bin/env python3
"""EightMax 5.10: the EXACT expected increments of the experimental RB-ES estimator against an INDEPENDENT
implementation of their target.

Usage: independent_rbes510.py spec.json exact-dump.json [more-dumps.json ...] > report.json

exact-dump.json is written by `source/tests/rbes510.cpp total`: for a frozen table, the expectation of what one
RB-ES update writes into every table entry, formed by the estimator's own code over EVERY deal (hand tuple and board
completion, with its probability) and EVERY outcome of the sampled opponent actions (with the probability the
traversal used). It is a number without sampling error.

This script computes what that number must be: the counterfactual regret and the reach-weighted strategy of the
sampled-chance CFR update for the same frozen table,

  regret target(a)  = step * sum over deals in A of P(deal) * prod_{i != p} pi_i(h) * (v_p(h,a) - v_p(h))
  average target(a) = step * sum over deals in A of P(deal) * pi_p(h) * sigma(a)

(A: the deals in which seat p holds the row's hand and the row's public cards are on the board), with the
implementation of tools/independent_cfr56.py: Python, its own betting rules, side pots and seven-card evaluator
(tools/independent_br48.py), regret matching on the frozen regrets, every compatible hand tuple and every remaining
board card enumerated. It shares no code with the engine and knows nothing of vectors of hands, conditional weights,
exact terminal children or importance weights: it is the definition, evaluated directly.

A row the frozen table does not hold plays uniformly in both programs (the engine's rule for a new row).

PASS: every entry of the dump agrees with its target within 1e-9 * step * (chips in play), and every entry with a
nonzero target is in the dump. Supported games: postflop chip-EV studies with the exact abstraction (the games the
independent implementation plays); ICM, preflop and grouped-key games are checked exactly by `rbes510 conditional`
against a brute-force walk inside the engine's rules instead (MATHEMATICAL-VALIDATION-5.10.md)."""
import sys, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from independent_cfr56 import targets

def keyof(r):
    L = r['length']; c = r['cards']
    return (tuple(r['path']), r['hand'], (tuple(sorted(c[:3])) + tuple(c[3:L])) if L >= 3 else ())

def main():
    spec = json.load(open(sys.argv[1])); reports = []; ok = True
    chips = 1 + sum(spec['rules']['stacks']) + spec['rules']['pot0']
    for path in sys.argv[2:]:
        d = json.load(open(path))
        if not d.get('exact'): raise SystemExit(path + ': not an exact dump (use rbes510 total)')
        frozen = {keyof(r): r['frozen'] for r in d['rows'] if r['frozen'] is not None}
        reg, avg, ndeals = targets(spec, frozen); step, astep = d['step'], d['averageStep']; scale = step * chips
        worst = {'regret': 0.0, 'average': 0.0}; worst_at = {'regret': None, 'average': None}; entries = 0; seen = set(); nonzero = 0
        for r in d['rows']:
            key = keyof(r); k = r['k']; seen.add(key)
            for a in range(2 * k):
                kind = 'regret' if a < k else 'average'
                target = step * reg.get(key, [0.0] * k)[a] if a < k else astep * avg.get(key, [0.0] * k)[a - k]
                diff = abs(r['mean'][a] - target) / scale; entries += 1; nonzero += target != 0
                if diff > worst[kind]: worst[kind] = diff; worst_at[kind] = {'path': r['path'], 'seat': r['seat'], 'hand': r['hand'], 'action': a % k, 'engine': r['mean'][a], 'independent': target}
        missing = [k for k in set(reg) | set(avg) if k not in seen and (any(x != 0 for x in reg.get(k, [])) or any(x != 0 for x in avg.get(k, [])))]
        passed = max(worst.values()) <= 1e-9 and not missing and entries > 0; ok &= passed
        reports.append({'dump': os.path.basename(path), 'estimator': d['estimator'], 'dealsEnumeratedByTheEngine': d['dealsEnumerated'], 'handTuplesEnumeratedIndependently': ndeals,
                        'traversalOutcomesEnumerated': d['traversalOutcomesEnumerated'], 'entriesCompared': entries, 'entriesWithNonzeroTarget': nonzero, 'rowsHeldByTheFrozenTable': len(frozen), 'rowsNotHeld': len(d['rows']) - len(frozen),
                        'step': step, 'scale': scale, 'largestRegretDifferenceOverScale': worst['regret'], 'largestAverageDifferenceOverScale': worst['average'], 'tolerance': 1e-9,
                        'worstRegretEntry': worst_at['regret'], 'worstAverageEntry': worst_at['average'], 'targetEntriesMissingFromTheDump': len(missing),
                        'engineBruteForceDifferenceOverScale': d.get('largestDifferenceFromTheBruteForceWalkOverScale'), 'passed': passed})
    print(json.dumps({'tool': 'independent_rbes510', 'spec': os.path.basename(sys.argv[1]), 'players': spec['n'], 'startCards': len(spec['board']), 'allPassed': ok, 'checks': reports}, indent=1))
    sys.exit(0 if ok else 1)

if __name__ == '__main__': main()
