// EightMax 5.10: the experimental RB-ES estimator (native/es_rbes510.hpp) against the quantities it must estimate.
//
//   rbes510 conditional spec.json prefixUpdates deals out.json
//   rbes510 total       spec.json prefixUpdates out.json
//   rbes510 mc          spec.json prefixUpdates trials out-default.json out-rbes.json
//   rbes510 pick        spec.json prefixUpdates draws
//
// The spec selects the estimator ("estimator":"rbes", optionally "rbesOpponentTerminals" and "rbesWalk"). One engine
// is trained for `prefixUpdates` updates and its tables are FROZEN: nothing is merged afterwards, so every traversal
// reads the same table and the quantities below are defined for that table.
//
// conditional  EXACT, for any game the engine plays (chip EV or ICM, any start street, exact or grouped keys). For each
//              of `deals` sampled deals and each updating seat p:
//                estimate = sum over EVERY outcome of the traversal's sampled opponent actions of
//                           P(outcome) * (the increments the traversal writes)        [the estimator's own code;
//                           the outcomes are enumerated through Walker::rbScript, their probabilities are the ones
//                           the traversal used, and they must sum to 1]
//                target   = sum over the hands x of p compatible with the board and the opponents' hands of
//                           c(x) * [ regret:  step * prod_{i != p} pi_i(h) * (v_p(h,a) - v_p(h))
//                                    average: step * pi_p(h) * sigma(a) ]
//                           computed by a brute-force walk of the WHOLE betting tree for the deal (x, opponents'
//                           hands, board): no sampling, no vectors, no shared values, the default trainer's row
//                           keys (worldGroups) and the engine's all-seat payoff. c(x) = w(x) / sum of w over the
//                           compatible hands, computed here.
//              The two must agree to rounding for every table entry of every deal: this is the statement
//              "E[RB-ES increment | board, opponents' hands] = E[default target | board, opponents' hands]",
//              checked without statistics. Each traversal outcome is also run through the reference walk
//              (learnRBref) and the production walk (learnRB) and their increments are compared entry by entry.
// total        EXACT, small postflop games: every deal (hand tuple and every board completion) with its probability;
//              writes the exact expected increment per sampled deal of every table entry in the format of
//              tests/enum56.cpp, for tools/independent_rbes510.py (Python, own betting rules, pots and evaluator).
// mc           Monte Carlo, games too large for the above: `trials` independent deals traversed by the default
//              estimator and by RB-ES against the same frozen table; per entry the mean, standard error and the
//              number of deals with a nonzero increment of both (two enum56-format files), and the variance of the
//              increments of both. With a seventh argument N only the rows with an entry that received a nonzero
//              increment in at least N deals of BOTH estimators are written (large tables).
// pick         The sampler itself. Walker::rbPick draws the action of an opponent decision among its non-terminal
//              children with the production random stream; the exact checks above replace that stream by a
//              script and take the probabilities the traversal claims. Here the claim is tested directly: for a
//              fixed list of decisions (2 to 6 actions, every mask of terminal children that leaves two or more
//              to sample among, probabilities from 0.9 sigma + 0.1 / k with sigma from near-pure to uniform)
//              `draws` actions are drawn and counted. The counts and the claimed probabilities are printed; the
//              caller tests them (chi-square). A terminal child must never be drawn.
#include "../native/mw.cpp"
#include <fstream>
#include <iterator>
using namespace es;
namespace {
typedef RbCheck Harness;
int fail(const char *msg) { std::fprintf(stderr, "%s\n", msg); return 3; }
}
int main(int argc, char **argv) {
  const std::string mode = argc > 1 ? argv[1] : "";
  if (!((mode == "conditional" && argc == 6) || (mode == "total" && argc == 5) || (mode == "mc" && (argc == 7 || argc == 8)) || (mode == "pick" && argc == 5))) {
    std::fprintf(stderr, "usage: rbes510 conditional spec.json prefixUpdates deals out.json\n       rbes510 total spec.json prefixUpdates out.json\n       rbes510 mc spec.json prefixUpdates trials out-default.json out-rbes.json [minimumNonzeroDeals]\n       rbes510 pick spec.json prefixUpdates draws\n"); return 2; }
  std::ifstream file(argv[2]); std::string spec{std::istreambuf_iterator<char>(file), {}};
  const long long prefix = std::atoll(argv[3]); char error[512] = {};
  MW *m = mw_create(spec.data(), spec.size(), 1024, error, sizeof error);
  if (!m) { std::fprintf(stderr, "%s\n", error); return 1; }
  if (!m->es || !m->es->rbes) return fail("the spec must select \"estimator\":\"rbes\"");
  if (!(m->es->exploreMix > 0)) return fail("opponent exploration must be positive (every sampled action needs a positive probability)");
  if (!mw_train(m, prefix, 1, nullptr, nullptr, nullptr, error, sizeof error)) { std::fprintf(stderr, "%s\n", error); return 1; }
  Harness H(m); H.freeze(); Game &g = H.g; const size_t N = H.N; const int n = m->n;
  const char *walk = g.rbReference ? "reference" : "production", *terms = g.rbTerminals ? "exact" : "sampled";
  if (mode == "conditional") {
    const long long deals = std::atoll(argv[4]);
    double seconds = now();
    if (!H.conditional(deals, 0x510u)) return fail("a traversal overflowed its buffers, or the key dictionary does not fit the table budget");
    const long double worst = H.worst, worstRel = H.worstRel; const long long entries = H.entries, seatDeals = H.seatDeals, hands = H.hands;
    seconds = now() - seconds;
    const bool ok = H.passed();
    FILE *out = std::fopen(argv[5], "w"); if (!out) return fail("cannot write the output file");
    std::fprintf(out, "{\"test\":\"conditional\",\"estimator\":\"%s\",\"walk\":\"%s\",\"opponentTerminalChildren\":\"%s\",\"prefixUpdates\":%lld,\"deals\":%lld,\"seatDeals\":%lld,\"handsPerSeatDeal\":%.4f,\"traversalOutcomesEnumerated\":%lld,\"entriesCompared\":%lld,\"step\":%.17g,\"scale\":%.17g,"
                      "\"largestDifferenceOverScale\":%.6Lg,\"largestRelativeDifference\":%.6Lg,\"largestProductionReferenceDifferenceOverScale\":%.6Lg,\"largestOutcomeProbabilityError\":%.6g,\"tolerance\":1e-11,\"rows\":%zu,\"players\":%d,\"seconds\":%.3f,\"passed\":%s}\n",
                 Game::rbesId(g.rbTerminals), walk, terms, prefix, deals, seatDeals, (double)hands / (double)std::max<long long>(1, seatDeals), H.scripts, entries, H.step, H.scale, worst, worstRel, H.worstPair, H.worstProb, m->rows.size(), n, seconds, ok ? "true" : "false");
    std::fclose(out); mw_free(m); return ok ? 0 : 1;
  }
  if (mode == "total") {
    if (g.groups.on) return fail("total needs the exact abstraction (the independent implementation identifies a row by hand and public cards)");
    Harness::Acc est, tgt; std::vector<int> tup((size_t)n, 0); long long dealCount = 0; long double Z = 0, worst = 0, worstRel = 0; long long entries = 0;
    // every compatible hand tuple with weight prod w, and every ordered completion of the board
    std::vector<std::pair<std::vector<int>, double>> tuples;
    std::function<void(int, uint64_t, double)> rec = [&](int p, uint64_t used, double w) {
      if (p == n) { tuples.emplace_back(tup, w); Z += w; return; }
      for (size_t i = 0; i < m->hands[(size_t)p].size(); i++) { const Hand &h = m->hands[(size_t)p][i]; const uint64_t mk = (1ULL << h.a) | (1ULL << h.b); if ((used & mk) || !(h.w > 0)) continue; tup[(size_t)p] = (int)i; rec(p + 1, used | mk, w * h.w); }
    };
    uint64_t boardMask = 0; for (int i = 0; i < m->startLen; i++) boardMask |= 1ULL << m->board[i];
    rec(0, boardMask, 1.0);
    const int need = 5 - m->startLen; if (need > 2) return fail("total supports flop, turn and river starts");
    for (const auto &tw : tuples) {
      uint64_t used = boardMask; for (int p = 0; p < n; p++) { const Hand &h = m->hands[(size_t)p][(size_t)tw.first[(size_t)p]]; used |= (1ULL << h.a) | (1ULL << h.b); }
      std::vector<int> rest; for (int c = 0; c < 52; c++) if (!((used >> c) & 1)) rest.push_back(c);
      const double boards = need == 0 ? 1.0 : need == 1 ? (double)rest.size() : (double)rest.size() * (double)(rest.size() - 1);
      const size_t n1 = need >= 1 ? rest.size() : 1, n2 = need == 2 ? rest.size() : 1;
      for (size_t i1 = 0; i1 < n1; i1++) for (size_t i2 = 0; i2 < n2; i2++) {
        if (need == 2 && i1 == i2) continue;
        H.u.clear(); for (int p = 0; p < n; p++) H.u.w.seat[p] = tw.first[(size_t)p];
        for (int i = 0; i < m->startLen; i++) H.u.w.cards[i] = m->board[i];
        if (need >= 1) H.u.w.cards[m->startLen] = rest[i1];
        if (need == 2) H.u.w.cards[m->startLen + 1] = rest[i2];
        if (!H.prepare(H.u, true)) return fail("the key dictionary does not fit the table budget");
        const double w = tw.second / (double)Z / boards; dealCount++;
        for (int p = 0; p < n; p++) {
          int compatible = 0;
          if (!H.expectation(p, w, est, false)) return fail("a traversal overflowed its buffers");
          if (!H.target(p, w, tgt, compatible)) return fail("the key dictionary does not fit the table budget");
        }
      }
    }
    H.compare(est, tgt, worst, worstRel, entries);
    FILE *out = std::fopen(argv[4], "w"); if (!out) return fail("cannot write the output file");
    std::fprintf(out, "{\"estimator\":\"%s (%s walk), exact expectation over every deal and every sampling outcome\",\"exact\":true,\"prefixDeals\":%lld,\"trials\":%lld,\"dealsEnumerated\":%lld,\"traversalOutcomesEnumerated\":%lld,\"step\":%.17g,\"averageStep\":%.17g,\"scale\":%.17g,\"entries\":%lld,\"largestDifferenceFromTheBruteForceWalkOverScale\":%.6Lg,\"stateVisitsPerDeal\":0,\"secondsPerDeal\":0,\"rows\":[\n",
                 Game::rbesId(g.rbTerminals), walk, prefix, dealCount, dealCount, H.scripts, H.step, H.avgStep, H.scale, entries, worst);
    // one row per entry of the estimate: path, hand, public cards (decoded from the code), the frozen values when the table holds the row
    bool first = true;
    for (const auto &e : est) {
      const size_t b1 = e.first.find('|'), b2 = e.first.find('|', b1 + 1); const std::string ph = e.first.substr(0, b1); const int hand = std::atoi(e.first.substr(b1 + 1, b2 - b1 - 1).c_str()); const uint32_t code = (uint32_t)std::strtoul(e.first.substr(b2 + 1).c_str(), nullptr, 10);
      // street length and seat of the state: replay the path through the rules
      BS t = g.rootState, c1; int ref = 0; for (char ch : ph) { const int a = ch - '0'; if (a == CHANCE_SLOT) g.rules.nextStreet(t, c1); else g.rules.advance(t, a, c1); ref = ref < 0 ? -1 : g.states.find((uint32_t)ref, a); t = c1; }
      uint8_t cards[5] = {0, 0, 0, 0, 0}; decodeCards(code, t.length, cards); const int k = (int)e.second.size() / 2;
      std::fprintf(out, "%s{\"path\":[", first ? "" : ",\n"); first = false;
      for (size_t i = 0; i < ph.size(); i++) std::fprintf(out, "%s%d", i ? "," : "", ph[i] - '0');
      std::fprintf(out, "],\"seat\":%d,\"hand\":%d,\"length\":%d,\"cards\":[%d,%d,%d,%d,%d],\"k\":%d,\"frozen\":", t.actor, hand, t.length, cards[0] - 1, cards[1] - 1, cards[2] - 1, cards[3] - 1, cards[4] - 1, k);
      const long long row = ref < 0 ? -1 : m->findRow(rowKey((uint32_t)ref, hand, code));
      if (row < 0) std::fprintf(out, "null"); else { std::fprintf(out, "["); for (int a = 0; a < 2 * k; a++) std::fprintf(out, "%s%.17g", a ? "," : "", m->vals[m->rows[(size_t)row].off + (size_t)a]); std::fprintf(out, "]"); }
      std::fprintf(out, ",\"mean\":["); for (int a = 0; a < 2 * k; a++) std::fprintf(out, "%s%.17Lg", a ? "," : "", e.second[(size_t)a]);
      std::fprintf(out, "],\"standardError\":["); for (int a = 0; a < 2 * k; a++) std::fprintf(out, "%s0", a ? "," : "");
      std::fprintf(out, "]}");
    }
    std::fprintf(out, "\n]}\n"); std::fclose(out); mw_free(m); return worst <= 1e-11L ? 0 : 1;
  }
  if (mode == "pick") {
    const long long draws = std::atoll(argv[4]); Rng actions{study53::mix(0x510a11u)}; H.walker.rng = &actions; H.walker.rbScript = nullptr;
    Rng make{study53::mix(0x510b22u)}; long long cases = 0, terminalDrawn = 0;
    std::printf("{\"test\":\"pick\",\"draws\":%lld,\"exploreKeep\":%.17g,\"exploreMix\":%.17g,\"cases\":[", draws, g.exploreKeep, g.exploreMix);
    for (int k = 2; k <= 6; k++) for (int shape = 0; shape < 4; shape++) for (int mask = 0; mask < (1 << k); mask++) {
      int nonTerminal = 0; for (int b = 0; b < k; b++) nonTerminal += !((mask >> b) & 1);
      if (nonTerminal < 2) continue;                      // one candidate: nothing to test
      if (k >= 5 && (mask % 5) != shape) continue;         // a fixed subset of the masks of the larger decisions
      // sigma: 0 near-pure on one action, 1 two actions, 2 random, 3 uniform; q as the trainer forms it
      double sg[8], q[8], tot = 0;
      for (int b = 0; b < k; b++) { sg[b] = shape == 0 ? (b == mask % k ? 1.0 : 0.0) : shape == 1 ? (b == mask % k || b == (mask + 1) % k ? 0.5 : 0.0) : shape == 2 ? make.next() * make.next() + 1e-9 : 1.0; tot += sg[b]; }
      bool term[8]; double qN = 0; int lastN = -1; long long count[8] = {0, 0, 0, 0, 0, 0, 0, 0};
      for (int b = 0; b < k; b++) { sg[b] /= tot; q[b] = g.exploreKeep * sg[b] + g.exploreMix / k; term[b] = (mask >> b) & 1; if (!term[b]) { qN += q[b]; lastN = b; } }
      for (long long i = 0; i < draws; i++) { const int a = H.walker.rbPick(q, term, k, qN, lastN); if (a < 0 || a >= k || term[a]) terminalDrawn++; else count[a]++; }
      std::printf("%s\n{\"k\":%d,\"terminalMask\":%d,\"sigmaShape\":%d,\"claimed\":[", cases++ ? "," : "", k, mask, shape);
      for (int b = 0; b < k; b++) std::printf("%s%.17g", b ? "," : "", term[b] ? 0.0 : q[b] / qN);
      std::printf("],\"count\":["); for (int b = 0; b < k; b++) std::printf("%s%lld", b ? "," : "", count[b]); std::printf("]}");
    }
    std::printf("\n],\"terminalChildrenDrawn\":%lld}\n", terminalDrawn); mw_free(m); return terminalDrawn ? 1 : 0;
  }
  // ---- mc ----
  const long long trials = std::atoll(argv[4]); const long long minimumHits = argc == 8 ? std::atoll(argv[7]) : 0;
  std::vector<long double> add(N, 0), sum[2], sq[2]; std::vector<long long> hits[2]; long long visits[2] = {0, 0}, outside[2] = {0, 0}; double seconds[2] = {0, 0};
  for (int e = 0; e < 2; e++) { sum[e].assign(N, 0); sq[e].assign(N, 0); hits[e].assign(N, 0); }
  std::vector<uint8_t> mark(N, 0); std::vector<size_t> touched;   // the entries one deal wrote (large tables: do not scan them all per deal)
  for (long long s = 0; s < trials; s++) {
    for (int e = 0; e < 2; e++) {   // e = 0: the default estimator, e = 1: RB-ES; independent deals and action streams
      const uint32_t seed = study53::mix((uint32_t)(s * 4 + e) + 0x510u);
      m->rng.state = seed; Rng actions{study53::mix(seed ^ 0xabcdef01u)};
      H.u.clear(); if (!m->deal(H.u.w, 0)) return fail("deal failed");
      if (!H.prepare(H.u, e == 1)) return fail("the key dictionary does not fit the table budget");
      g.rbes = e == 1; H.walker.rbDeal = &H.rd; const double t0 = now();
      for (int p = 0; p < n; p++) {
        H.u.pending.clear(); H.u.incs.clear(); H.u.vals.clear();
        H.walker.run(H.u, p, actions, H.step, H.avgStep);
        if (H.u.overflow) { g.rbes = true; return fail("a traversal overflowed its buffers"); }
        for (const Inc &inc : H.u.incs) {
          const long long r = H.rowOf(inc); if (r < 0) { outside[e]++; continue; }   // a row the frozen table does not hold: not compared
          const size_t o = m->rows[(size_t)r].off;
          for (int a = 0; a < 2 * inc.k; a++) { if (!mark[o + (size_t)a]) { mark[o + (size_t)a] = 1; touched.push_back(o + (size_t)a); } add[o + (size_t)a] += H.u.vals[inc.off + (size_t)a]; }
        }
        visits[e] += H.u.visits; H.u.visits = 0;
      }
      seconds[e] += now() - t0; g.rbes = true;
      for (size_t i : touched) { if (add[i] != 0) { sum[e][i] += add[i]; sq[e][i] += add[i] * add[i]; hits[e][i]++; } add[i] = 0; mark[i] = 0; }
      touched.clear();
    }
  }
  // variance of the increments per deal (sum over the entries), separately for regrets and averages
  long double var[2][2] = {{0, 0}, {0, 0}};
  for (const auto &r : m->rows) for (int a = 0; a < 2 * r.k; a++) for (int e = 0; e < 2; e++) {
    const long double mean = sum[e][r.off + (size_t)a] / trials; long double v = (sq[e][r.off + (size_t)a] - trials * mean * mean) / (trials - 1); if (v < 0) v = 0; var[e][a >= r.k] += v; }
  for (int e = 0; e < 2; e++) {
    FILE *out = std::fopen(argv[5 + e], "w"); if (!out) return fail("cannot write the output file");
    std::fprintf(out, "{\"estimator\":\"%s\",\"prefixDeals\":%lld,\"trials\":%lld,\"step\":%.17g,\"averageStep\":%.17g,\"stateVisitsPerDeal\":%.4f,\"secondsPerDeal\":%.9g,\"sumOfRegretVariances\":%.17Lg,\"sumOfAverageVariances\":%.17Lg,\"rows\":[\n",
                 e ? Game::rbesId(g.rbTerminals) : "default external sampling", prefix, trials, H.step, H.avgStep, (double)visits[e] / trials, seconds[e] / trials, var[e][0], var[e][1]);
    bool first = true;
    for (const auto &r : m->rows) {
      if (minimumHits > 0) { bool keep = false; for (int a = 0; a < 2 * r.k; a++) keep |= hits[0][r.off + (size_t)a] >= minimumHits && hits[1][r.off + (size_t)a] >= minimumHits; if (!keep) continue; }
      std::fprintf(out, "%s", first ? "" : ",\n"); first = false; H.describeRow(out, r);
      std::fprintf(out, ",\"mean\":["); for (int a = 0; a < 2 * r.k; a++) std::fprintf(out, "%s%.17Lg", a ? "," : "", sum[e][r.off + (size_t)a] / trials);
      std::fprintf(out, "],\"standardError\":[");
      for (int a = 0; a < 2 * r.k; a++) { const long double mean = sum[e][r.off + (size_t)a] / trials; long double v = (sq[e][r.off + (size_t)a] - trials * mean * mean) / (trials - 1); if (v < 0) v = 0; std::fprintf(out, "%s%.17Lg", a ? "," : "", sqrtl(v / trials)); }
      std::fprintf(out, "],\"nonzeroDeals\":["); for (int a = 0; a < 2 * r.k; a++) std::fprintf(out, "%s%lld", a ? "," : "", hits[e][r.off + (size_t)a]);
      std::fprintf(out, "]}");
    }
    std::fprintf(out, "\n]}\n"); std::fclose(out);
  }
  std::printf("{\"test\":\"mc\",\"trials\":%lld,\"regretVarianceRatioRbesOverDefault\":%.6Lg,\"averageVarianceRatioRbesOverDefault\":%.6Lg,\"secondsPerDealDefault\":%.9g,\"secondsPerDealRbes\":%.9g,\"visitsPerDealDefault\":%.3f,\"visitsPerDealRbes\":%.3f,\"incrementsToRowsOutsideTheFrozenTableDefault\":%lld,\"incrementsToRowsOutsideTheFrozenTableRbes\":%lld}\n",
              trials, var[0][0] > 0 ? var[1][0] / var[0][0] : 0, var[0][1] > 0 ? var[1][1] / var[0][1] : 0, seconds[0] / trials, seconds[1] / trials, (double)visits[0] / trials, (double)visits[1] / trials, outside[0], outside[1]);
  mw_free(m); return 0;
}
