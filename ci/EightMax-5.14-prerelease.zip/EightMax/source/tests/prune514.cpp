// EightMax 5.14: the two pruning algorithms against the default estimator on a FROZEN table (Monte Carlo).
//
//   prune514 spec.json prefixUpdates trials out.json
//
// The spec is a default-trainer spec (no "pruning"). One engine is trained for `prefixUpdates` updates by the default
// trainer and its tables are frozen: nothing is merged afterwards, so every traversal reads the same table and the
// expected increment of every table entry is a fixed number. Three estimators then traverse `trials` independent
// deals each (their own deals and action streams): the default one, nrpc-5.14-v1 (skip with the importance
// correction) and nrp-5.14-v1 (skip without it), with the threshold (0.02), the evidence (50) and the skip probability (0.95) of the release.
//
// CLAIM TESTED: nrpc is unbiased, so its mean increment of every entry must agree with the default's within sampling
// error. The comparison is made on entries whose Kish effective sample size is at least 2,000 for both estimators
// (the rule of validation/5.10/estimator510.py, for the same reason: importance weights make a few hundred nonzero
// deals worth a few dozen); z = difference of the means / sqrt(se1^2 + se2^2); one statement at 0.05 for all entries
// compared (Bonferroni). nrp is reported the same way and is EXPECTED to differ: it is biased by construction, on
// the regrets of the actions it skips and of the decisions below them.
#include "../native/mw.cpp"
#include <fstream>
#include <iterator>
using namespace es;
static double normalTwoSidedCritical(double alpha) { double lo = 0, hi = 40; for (int i = 0; i < 200; i++) { const double mid = (lo + hi) / 2; (std::erfc(mid / std::sqrt(2.0)) > alpha ? lo : hi) = mid; } return (lo + hi) / 2; }
int main(int argc, char **argv) {
  if (argc != 5) { std::fprintf(stderr, "usage: prune514 spec.json prefixUpdates trials out.json\n"); return 2; }
  std::ifstream file(argv[1]); std::string spec{std::istreambuf_iterator<char>(file), {}}; const long long prefix = std::atoll(argv[2]), trials = std::atoll(argv[3]); char error[512] = {};
  MW *m = mw_create(spec.data(), spec.size(), 1024, error, sizeof error);
  if (!m) { std::fprintf(stderr, "%s\n", error); return 1; }
  if (!m->es || m->es->prune || m->es->rbes) { std::fprintf(stderr, "the spec must be a default external-sampling spec\n"); return 3; }
  if (!mw_train(m, prefix, 1, nullptr, nullptr, nullptr, error, sizeof error)) { std::fprintf(stderr, "%s\n", error); return 1; }
  RbCheck H(m); H.freeze(); Game &g = H.g; const size_t N = H.N; const int n = m->n; g.pruneScale = pruneScaleOf(*m, g);
  const char *names[3] = {"default", "nrpc-5.14-v1", "nrp-5.14-v1"}; const double theta[3] = {0, 0.02, 0.02};
  std::vector<long double> add(N, 0), sum[3], sq[3]; long long visits[3] = {0, 0, 0}, cand[3] = {0, 0, 0}, skipped[3] = {0, 0, 0}; double seconds[3] = {0, 0, 0};
  for (int e = 0; e < 3; e++) { sum[e].assign(N, 0); sq[e].assign(N, 0); }
  std::vector<uint8_t> mark(N, 0); std::vector<size_t> touched;
  for (long long s = 0; s < trials; s++) for (int e = 0; e < 3; e++) {
    const uint32_t seed = study53::mix((uint32_t)(s * 4 + e) + 0x514u); m->rng.state = seed; Rng actions{study53::mix(seed ^ 0xabcdef01u)};
    H.u.clear(); if (!m->deal(H.u.w, 0)) { std::fprintf(stderr, "deal failed\n"); return 3; }
    if (!H.prepare(H.u, false)) { std::fprintf(stderr, "the key dictionary does not fit\n"); return 3; }
    g.prune = e > 0; g.pruneCorrect = e == 1; g.pruneTheta = theta[e]; g.pruneEvidence = 50; g.prunePart = 0.95;
    const long long c0 = H.walker.pruneCandidates, k0 = H.walker.pruneSkipped; const double t0 = now();
    for (int p = 0; p < n; p++) {
      H.u.pending.clear(); H.u.incs.clear(); H.u.vals.clear(); H.walker.run(H.u, p, actions, H.step, H.avgStep);
      if (H.u.overflow) { std::fprintf(stderr, "a traversal overflowed its buffers\n"); return 3; }
      for (const Inc &inc : H.u.incs) { const long long r = H.rowOf(inc); if (r < 0) continue; const size_t o = m->rows[(size_t)r].off;
        for (int a = 0; a < 2 * inc.k; a++) { if (!mark[o + (size_t)a]) { mark[o + (size_t)a] = 1; touched.push_back(o + (size_t)a); } add[o + (size_t)a] += H.u.vals[inc.off + (size_t)a]; } }
      visits[e] += H.u.visits; H.u.visits = 0;
    }
    seconds[e] += now() - t0; cand[e] += H.walker.pruneCandidates - c0; skipped[e] += H.walker.pruneSkipped - k0; g.prune = false;
    for (size_t i : touched) { if (add[i] != 0) { sum[e][i] += add[i]; sq[e][i] += add[i] * add[i]; } add[i] = 0; mark[i] = 0; }
    touched.clear();
  }
  FILE *out = std::fopen(argv[4], "w"); if (!out) return 3;
  std::fprintf(out, "{\"test\":\"prune514\",\"prefixUpdates\":%lld,\"trials\":%lld,\"rows\":%zu,\"players\":%d,\"utilityScale\":%.17g,\"step\":%.17g,\"estimators\":[", prefix, trials, m->rows.size(), n, g.pruneScale, H.step);
  bool unbiasedOk = true;
  for (int e = 0; e < 3; e++) {
    long long compared = 0, comparedRegret = 0; double worst = 0; long double var[2] = {0, 0}; std::vector<double> zs;
    for (const auto &r : m->rows) for (int a = 0; a < 2 * r.k; a++) { const size_t i = r.off + (size_t)a; long double mean[2], se2[2]; double kish[2];
      for (int x = 0; x < 2; x++) { const int w = x ? e : 0; mean[x] = sum[w][i] / trials; long double v = (sq[w][i] - trials * mean[x] * mean[x]) / (trials - 1); if (v < 0) v = 0; se2[x] = v / trials;
        kish[x] = sq[w][i] > 0 ? (double)(sum[w][i] * sum[w][i] / sq[w][i]) : 0; if (x) var[a >= r.k] += v; }
      if (e == 0 || kish[0] < 2000 || kish[1] < 2000 || se2[0] + se2[1] <= 0) continue;
      const double z = (double)((mean[1] - mean[0]) / sqrtl(se2[0] + se2[1])); compared++; comparedRegret += a < r.k; worst = std::max(worst, std::fabs(z)); zs.push_back(std::fabs(z)); }
    const double critical = compared ? normalTwoSidedCritical(0.05 / compared) : 0; long long above = 0; for (double z : zs) above += z > critical;
    const bool agree = e == 0 || (compared >= 10 && worst <= critical); if (e == 1) unbiasedOk = agree;
    std::fprintf(out, "%s{\"estimator\":\"%s\",\"threshold\":%.17g,\"stateVisitsPerDeal\":%.4f,\"secondsPerDeal\":%.9g,\"candidatesPerDeal\":%.4f,\"skippedPerDeal\":%.4f,\"sumOfRegretVariances\":%.9Lg,\"sumOfAverageVariances\":%.9Lg",
                 e ? "," : "", names[e], theta[e], (double)visits[e] / trials, seconds[e] / trials, (double)cand[e] / trials, (double)skipped[e] / trials, var[0], var[1]);
    if (e) std::fprintf(out, ",\"entriesCompared\":%lld,\"regretEntriesCompared\":%lld,\"largestAbsZ\":%.4f,\"bonferroniCritical\":%.4f,\"entriesAboveCritical\":%lld,\"meansAgreeWithDefault\":%s", compared, comparedRegret, worst, critical, above, agree ? "true" : "false");
    std::fprintf(out, "}");
  }
  std::fprintf(out, "],\"claim\":\"nrpc-5.14-v1 agrees with the default estimator (at least 10 entries compared, none above the critical value)\",\"passed\":%s}\n", unbiasedOk ? "true" : "false"); std::fclose(out);
  std::printf("{\"test\":\"prune514\",\"passed\":%s}\n", unbiasedOk ? "true" : "false"); mw_free(m); return unbiasedOk ? 0 : 1;
}
