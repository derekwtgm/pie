@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.8 focused validation on this Windows PC: what 5.8 added (trained response, large-study limit, ICM cache).
echo No GPU test, no throughput benchmark. Nothing is installed. This takes about 3 to 8 minutes.
echo Saved studies are not touched: everything is written to a temporary folder, which is removed at the end.
echo Reports are written into this folder:
echo   Windows-selftest58-5.8.json           the checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-focused-validation-5.8.json   every check, with its status and its evidence
echo   Windows-focused-validation-5.8.txt    the same as text
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest58-5.8.json" del /q "Windows-selftest58-5.8.json"
if exist "Windows-focused-validation-5.8.json" del /q "Windows-focused-validation-5.8.json"
if exist "Windows-focused-validation-5.8.txt" del /q "Windows-focused-validation-5.8.txt"
echo Step 1 of 2: mwcli.exe --selftest58
set "em_st=%TEMP%\EightMax-5.8-selftest58-%RANDOM%%RANDOM%"
mwcli.exe --selftest58 "studies" "%em_st%" all
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest58.json" copy /y "%em_st%\selftest58.json" "Windows-selftest58-5.8.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.8: every check passed.) else (echo Self-test 5.8: exit status %selftest_result%: a check failed or could not be made. See Windows-selftest58-5.8.json.)
if not exist "Windows-selftest58-5.8.json" echo NOTE: Windows-selftest58-5.8.json was not written.
echo.
echo Step 2 of 2: the validation script, focused mode
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows58.ps1" -Focused %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-focused-validation-5.8.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.8 parts have not run on Windows before this release; please keep the report files and the text above. The self-test result of step 1 stands on its own.
if not exist "Windows-focused-validation-5.8.json" echo NOTE: Windows-focused-validation-5.8.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
