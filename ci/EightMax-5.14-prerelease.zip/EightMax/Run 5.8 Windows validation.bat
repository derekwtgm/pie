@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.8 validation on this Windows PC. Nothing is installed. This takes 15 to 50 minutes.
echo Reports are written into this folder:
echo   Windows-selftest-5.8.json        the 5.7 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest571-5.8.json     the checkpoint and memory checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-selftest58-5.8.json      the 5.8 checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-validation-5.8.json      every check, with its status: passed, failed, skipped or untested
echo   Windows-validation-5.8.txt       the same as text
echo   hardware-validation.json         written by the GPU section when an NVIDIA GPU answers
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest-5.8.json" del /q "Windows-selftest-5.8.json"
if exist "Windows-selftest571-5.8.json" del /q "Windows-selftest571-5.8.json"
if exist "Windows-selftest58-5.8.json" del /q "Windows-selftest58-5.8.json"
if exist "Windows-validation-5.8.json" del /q "Windows-validation-5.8.json"
if exist "Windows-validation-5.8.txt" del /q "Windows-validation-5.8.txt"
echo Step 1 of 4: mwcli.exe --selftest57
set "em_st=%TEMP%\EightMax-5.8-selftest-%RANDOM%%RANDOM%"
mwcli.exe --selftest57 "validation\5.7\fixtures" "%em_st%"
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest57.json" copy /y "%em_st%\selftest57.json" "Windows-selftest-5.8.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.7: every check passed.) else (echo Self-test 5.7: exit status %selftest_result%. See Windows-selftest-5.8.json.)
echo.
echo Step 2 of 4: mwcli.exe --selftest571 (checkpoint integrity and the process memory budget)
set "em_st2=%TEMP%\EightMax-5.8-selftest571-%RANDOM%%RANDOM%"
mwcli.exe --selftest571 "studies" "%em_st2%" all
set "selftest571_result=%errorlevel%"
if exist "%em_st2%\selftest571.json" copy /y "%em_st2%\selftest571.json" "Windows-selftest571-5.8.json" >nul
if exist "%em_st2%" rmdir /s /q "%em_st2%"
if "%selftest571_result%"=="0" (echo Self-test 5.7.1: every check passed.) else (echo Self-test 5.7.1: exit status %selftest571_result%: a check failed or could not be made. See Windows-selftest571-5.8.json.)
echo.
echo Step 3 of 4: mwcli.exe --selftest58 (trained response, large-study limit, ICM cache)
set "em_st3=%TEMP%\EightMax-5.8-selftest58-%RANDOM%%RANDOM%"
mwcli.exe --selftest58 "studies" "%em_st3%" all
set "selftest58_result=%errorlevel%"
if exist "%em_st3%\selftest58.json" copy /y "%em_st3%\selftest58.json" "Windows-selftest58-5.8.json" >nul
if exist "%em_st3%" rmdir /s /q "%em_st3%"
if "%selftest58_result%"=="0" (echo Self-test 5.8: every check passed.) else (echo Self-test 5.8: exit status %selftest58_result%: a check failed or could not be made. See Windows-selftest58-5.8.json.)
echo.
echo Step 4 of 4: the validation script
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows58.ps1" %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-validation-5.8.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed. Skipped checks, if any, are listed above with their reason.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.8 parts have not run on Windows before this release; please keep the report files and the text above. The self-test results of steps 1 to 3 stand on their own.
if not exist "Windows-validation-5.8.json" echo NOTE: Windows-validation-5.8.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest571_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
if not "%selftest58_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
