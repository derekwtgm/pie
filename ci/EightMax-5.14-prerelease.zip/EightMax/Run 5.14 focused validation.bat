@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.14 focused validation on this Windows PC: pruning, the merge of frozen batches, the equal-time tool,
echo and the checks of 5.11 to 5.13.
echo   - the two pruning algorithms: recorded states, thread counts, stop and continue, checkpoint rules, refusals
echo   - frozen batches spread over 1 to 4 threads: the state recorded from the Linux build
echo   - eqtime.exe: it names this build; two quick trials reproduce the Linux values bit for bit (trials, not results)
echo   - unchanged, and run here because 5.14 must not have changed them: the satellite checks of 5.13, the 6-max
echo     checks of 5.12, the philox64 checks of 5.11, and the trainer against the recorded states of 5.10
echo The GPU is used by Hybrid and GPU-Preferred if it answers; the separate CUDA validation is in the full run.
echo Nothing is installed. This takes about 15 to 30 minutes.
echo Saved studies are not touched: everything is written to a temporary folder, which is removed at the end.
echo Reports are written into this folder:
echo   Windows-selftest514-5.14.json          the checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-focused-validation-5.14.json   every check, with its status and its evidence
echo   Windows-focused-validation-5.14.txt    the same as text
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest514-5.14.json" del /q "Windows-selftest514-5.14.json"
if exist "Windows-focused-validation-5.14.json" del /q "Windows-focused-validation-5.14.json"
if exist "Windows-focused-validation-5.14.txt" del /q "Windows-focused-validation-5.14.txt"
echo Step 1 of 2: mwcli.exe --selftest514
set "em_st=%TEMP%\EightMax-5.14-selftest514-%RANDOM%%RANDOM%"
mwcli.exe --selftest514 "studies" "%em_st%" all
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest514.json" copy /y "%em_st%\selftest514.json" "Windows-selftest514-5.14.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.14: every check passed.) else (echo Self-test 5.14: exit status %selftest_result%: a check failed or could not be made. See Windows-selftest514-5.14.json.)
rem A self-test that ends with status 0 but wrote no report has not shown anything: that is not a pass.
if not exist "Windows-selftest514-5.14.json" if "%selftest_result%"=="0" set "selftest_result=2"
if not exist "Windows-selftest514-5.14.json" echo NOTE: Windows-selftest514-5.14.json was not written.
echo.
echo Step 2 of 2: the validation script, focused mode
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows514.ps1" -Focused %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-focused-validation-5.14.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.11 to 5.14 sections have not run on a physical Windows PC before this release; please keep the report files and the text above. The self-test result of step 1 stands on its own.
if not exist "Windows-focused-validation-5.14.json" echo NOTE: Windows-focused-validation-5.14.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
