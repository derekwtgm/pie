@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.12 focused validation on this Windows PC: 6-max, and the trainer checks of 5.11.
echo   - the six 6-max study fixtures: six-handed tables, the engine reaches every advertised decision,
echo     training to the states of the Linux build, exact NashConv of two companions, complete studies
echo   - the delivered interface carries the 6-max library and the table-size switch, and EightMax.exe serves it
echo   - two six-handed studies with 1, 2, 4, 8 and all logical processors and with every processing mode
echo     (CPU Only, Automatic, Hybrid, GPU-Preferred): one state each, the state of the Linux build
echo   - unchanged from 5.11, and run here because 5.12 must not have changed them: the trainer with the
echo     5.10 streams against the recorded states of 5.10, and the 26 checks and the philox64 section of 5.11
echo The GPU is used by Hybrid and GPU-Preferred if it answers; the separate CUDA validation is in the full run.
echo Nothing is installed. This takes about 8 to 20 minutes.
echo Saved studies are not touched: everything is written to a temporary folder, which is removed at the end.
echo Reports are written into this folder:
echo   Windows-selftest512-5.12.json          the checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-focused-validation-5.12.json   every check, with its status and its evidence
echo   Windows-focused-validation-5.12.txt    the same as text
echo.
rem Reports of an earlier run are removed first, so that a file found afterwards was written by this run.
if exist "Windows-selftest512-5.12.json" del /q "Windows-selftest512-5.12.json"
if exist "Windows-focused-validation-5.12.json" del /q "Windows-focused-validation-5.12.json"
if exist "Windows-focused-validation-5.12.txt" del /q "Windows-focused-validation-5.12.txt"
echo Step 1 of 2: mwcli.exe --selftest512
set "em_st=%TEMP%\EightMax-5.12-selftest512-%RANDOM%%RANDOM%"
mwcli.exe --selftest512 "studies" "%em_st%" all
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest512.json" copy /y "%em_st%\selftest512.json" "Windows-selftest512-5.12.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test 5.12: every check passed.) else (echo Self-test 5.12: exit status %selftest_result%: a check failed or could not be made. See Windows-selftest512-5.12.json.)
rem A self-test that ends with status 0 but wrote no report has not shown anything: that is not a pass.
if not exist "Windows-selftest512-5.12.json" if "%selftest_result%"=="0" set "selftest_result=2"
if not exist "Windows-selftest512-5.12.json" echo NOTE: Windows-selftest512-5.12.json was not written.
echo.
echo Step 2 of 2: the validation script, focused mode
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows512.ps1" -Focused %*
set "eightmax_result=%errorlevel%"
rem A script that ends with status 0 but wrote no report has not validated anything: that is not a pass.
if not exist "Windows-focused-validation-5.12.json" if "%eightmax_result%"=="0" set "eightmax_result=2"
echo.
if "%eightmax_result%"=="0" echo Every required check of the script passed.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). Its 5.11 and 5.12 sections have not run on a physical Windows PC before this release; please keep the report files and the text above. The self-test result of step 1 stands on its own.
if not exist "Windows-focused-validation-5.12.json" echo NOTE: Windows-focused-validation-5.12.json was not written, so nothing of the script is counted as passed.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
echo Overall exit status: %eightmax_result% ^(0 = every required check passed^)
if not defined EIGHTMAX_NO_PAUSE pause
exit /b %eightmax_result%
