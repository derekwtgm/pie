'use strict';
// EightMax 5.14 regression tests (Phase 4: faster multiway convergence).
//   5.14 adds two experimental pruning algorithms for the default estimator (spec "pruning": "nrp-5.14-v1" skips
//   candidate actions without a correction, "nrpc-5.14-v1" with the importance correction that keeps the increments
//   unbiased), a merge of frozen batches that groups the increments by merging thread (the states are unchanged) and
//   a fourth program, eqtime, for equal-training-time experiments. The default trainer writes the states of 5.13.
//   Tested here:
//     - the engine: what pruning accepts and refuses, the state header, the trainer information, continuation rules,
//       and the unchanged 5.13 program (it refuses a pruned state; it trains the default trainer to the same bytes,
//       one deal per update and frozen batches spread over threads, default estimator and rbes);
//     - a study with pruning through mwcli --study;
//     - tests/prune514.cpp: the pruned estimators against the default one on a frozen table (short form);
//     - eqtime: its build identifier, usage, spec and reference files, a quick trial with its equal-deals check, the
//       refusal of a directory that holds another plan;
//     - mwcli --selftest514; the Windows validation script of 5.14, its launchers and the workflow.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
const build = require('./native_build');
const src = path.resolve(__dirname, '..'), root = path.resolve(src, '..'), studies = path.join(src, 'studies'), native = path.join(src, 'native');
const cli = () => process.env.EM_TEST_MWCLI || build.cli().cli;
const tmp = t => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em514-')); t.after(() => fs.rmSync(d, { recursive: true, force: true })); return d; };
const run = (args, env = {}, exe = null) => cp.spawnSync(exe || cli(), args.map(String), { encoding: 'utf8', timeout: 1800000, maxBuffer: 256 << 20, env: { ...process.env, ...env } });
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const IDS = ['pruning P1', 'pruning P2', 'pruning P3', 'pruning P4', 'pruning P5', 'pruning P6', 'merge G1'];
const specOf = (id, extra = {}) => ({ ...JSON.parse(fs.readFileSync(path.join(studies, id + '.emfix.json'), 'utf8').replace(/^﻿/, '')).variants[0].nativeSpec, ...extra });
const write = (dir, name, spec) => { const f = path.join(dir, name); fs.writeFileSync(f, JSON.stringify(spec)); return f; };
const header = f => fs.readFileSync(f).subarray(0, 900).toString('latin1');
const old513 = () => process.env.EM_TEST_MWCLI_513 || path.join(root, 'validation/5.13/linux-bin/mwcli');
const eqtime = () => { for (const f of [process.env.EM_TEST_EQTIME, path.join(root, 'build/linux/eqtime')]) if (f && fs.existsSync(f)) return f; return null; };

test('5.14 pruning: both algorithms train, name themselves with their parameters in the information and in the state header, continue to the uninterrupted state, and prune', { timeout: 1800000 }, t => {
  const dir = tmp(t), base = run([write(dir, 'd.json', specOf('flop3-kings-small')), 20000, 1, path.join(dir, 'd.state'), 512]); assert.equal(base.status, 0, base.stderr);
  const visits = JSON.parse(base.stdout).stateVisits; assert.ok(!header(path.join(dir, 'd.state')).includes('"estimator"'), 'a default state names no algorithm');
  for (const [alg, theta, corrected] of [['nrp-5.14-v1', 0.02, false], ['nrpc-5.14-v1', 0.02, true]]) {
    const spec = write(dir, alg + '.json', specOf('flop3-kings-small', { pruning: alg })), full = path.join(dir, alg + '.state');
    const r = run([spec, 20000, 1, full, 512]); assert.equal(r.status, 0, r.stderr); const info = JSON.parse(r.stdout), p = info.trainer.pruning;
    assert.equal(p.identifier, alg); assert.equal(p.corrected, corrected); assert.equal(p.threshold, theta); assert.equal(p.evidence, 50); assert.equal(p.skip, 0.95); assert.equal(p.utilityScale, 22.7, 'the largest stack behind at the root');
    assert.ok(p.candidates > 0 && p.skipped > 0 && p.walked > 0 && p.candidates === p.skipped + p.walked, JSON.stringify(p)); assert.ok(Math.abs(p.skipped / p.candidates - 0.95) < 0.05, 'about 95% of the candidates are skipped');
    assert.ok(info.stateVisits < visits, 'fewer state visits than the default trainer'); assert.equal(info.trainer.experimentalPruning, true); assert.equal(info.trainer.validatedDefault, false);
    assert.ok(info.trainer.algorithm.startsWith(alg + ';threshold='), info.trainer.algorithm); assert.ok(header(full).includes('"estimator":"' + info.trainer.algorithm + '"'), 'the header names the algorithm with its parameters');
    const a = path.join(dir, 'a.state'), b = path.join(dir, 'b.state'); assert.equal(run([spec, 7000, 1, a, 512]).status, 0); const c = run([spec, 13000, 1, b, 512, a]); assert.equal(c.status, 0, c.stderr); assert.equal(sha(b), sha(full), 'stopped and continued = uninterrupted');
    assert.notEqual(sha(full), sha(path.join(dir, 'd.state')));
  }
  const none = run([write(dir, 'none.json', specOf('flop3-kings-small', { pruning: 'none' })), 20000, 1, path.join(dir, 'none.state'), 512]); assert.equal(none.status, 0, none.stderr); assert.equal(sha(path.join(dir, 'none.state')), sha(path.join(dir, 'd.state')), '"pruning":"none" is the default trainer');
});
test('5.14 pruning: what is refused before training, and which states continue under which settings', { timeout: 1800000 }, t => {
  const dir = tmp(t), out = path.join(dir, 'no.state');
  for (const [extra, want] of [[{ pruning: 'nrp' }, /Unknown pruning/], [{ pruning: 'nrp-5.14-v1', estimator: 'rbes' }, /default estimator only/], [{ pruning: 'nrpc-5.14-v1', weighting: 'dcfr' }, /Pruning \(experimental\) needs/], [{ pruning: 'nrp-5.14-v1', regretMatching: 'plus' }, /Pruning \(experimental\) needs/],
    [{ pruning: 'nrp-5.14-v1', ownHandEnumeration: true }, /default estimator only/], [{ pruning: 'nrp-5.14-v1', opponentEnumeration: 'river' }, /default estimator only/], [{ pruneThreshold: 0.01 }, /needs pruning/], [{ pruneSkip: 0.5 }, /needs pruning/], [{ pruneEvidence: 5 }, /needs pruning/], [{ pruning: 'nrp-5.14-v1', pruneEvidence: 0.5 }, /pruneEvidence/],
    [{ pruning: 'nrp-5.14-v1', pruneThreshold: 0 }, /pruneThreshold/], [{ pruning: 'nrp-5.14-v1', pruneThreshold: -1 }, /pruneThreshold/], [{ pruning: 'nrp-5.14-v1', pruneSkip: 1 }, /pruneSkip/], [{ pruning: 'nrp-5.14-v1', pruneSkip: 0 }, /pruneSkip/], [{ pruning: 7 }, /Unknown pruning/]]) {
    const r = run([write(dir, 'bad.json', specOf('flop3-kings-small', extra)), 10, 1, out, 512]); assert.equal(r.status, 1, JSON.stringify(extra)); assert.match(r.stderr, want, JSON.stringify(extra)); assert.ok(!fs.existsSync(out));
  }
  const d = write(dir, 'd.json', specOf('flop3-kings-small')), a = write(dir, 'a.json', specOf('flop3-kings-small', { pruning: 'nrp-5.14-v1' })), c = write(dir, 'c.json', specOf('flop3-kings-small', { pruning: 'nrpc-5.14-v1' })),
    a2 = write(dir, 'a2.json', specOf('flop3-kings-small', { pruning: 'nrp-5.14-v1', pruneThreshold: 0.01 })), a3 = write(dir, 'a3.json', specOf('flop3-kings-small', { pruning: 'nrp-5.14-v1', pruneSkip: 0.5 })), a4 = write(dir, 'a4.json', specOf('flop3-kings-small', { pruning: 'nrp-5.14-v1', pruneThreshold: 0.02, pruneEvidence: 50, pruneSkip: 0.95 })), a5 = write(dir, 'a5.json', specOf('flop3-kings-small', { pruning: 'nrp-5.14-v1', pruneEvidence: 10 }));
  const sd = path.join(dir, 'd.state'), sa = path.join(dir, 'a.state'); assert.equal(run([d, 500, 1, sd, 512]).status, 0); assert.equal(run([a, 500, 1, sa, 512]).status, 0);
  for (const [spec, state, want] of [[d, sa, /experimental training algorithm/], [c, sa, /other pruning settings/], [a2, sa, /other pruning settings/], [a3, sa, /other pruning settings/], [a5, sa, /other pruning settings/], [a, sd, /cannot be continued with pruning/], [c, sd, /cannot be continued with pruning/]]) {
    const r = run([spec, 5, 1, out, 512, state]); assert.equal(r.status, 1); assert.match(r.stderr, /409/); assert.match(r.stderr, want); assert.ok(!fs.existsSync(out)); }
  const same = run([a4, 5, 1, out, 512, sa]); assert.equal(same.status, 0, 'the defaults written out are the same settings: ' + same.stderr);
});
test('5.14 against the unchanged 5.13 program: the default trainer and rbes write the same bytes (one deal per update; frozen batches spread over 1 to 4 threads); 5.13 refuses a pruned state and ignores a pruning setting it does not know', { timeout: 1800000 }, t => {
  const old = old513(); if (!fs.existsSync(old)) return t.skip('no 5.13 program at ' + old);
  const dir = tmp(t), fixed = { EIGHTMAX_THREAD_CHOICE: 'fixed' }; let n = 0;
  for (const [id, extra, updates, threads] of [['flop3-kings-small', {}, 6000, [1]], ['flop6-jack-small', { trainingStreams: 'philox64' }, 6000, [1]], ['flop3-kings-small', { estimator: 'rbes' }, 3000, [1]], ['icm6-bb-call-small', {}, 6000, [1]], ['satfield-bb-call-small', {}, 3000, [1]],
    ['flop6-jack-small', { batchDeals: 16, actionStreams: 'deal' }, 300, [1, 2, 3, 4]], ['flop3-kings-small', { batchDeals: 16, actionStreams: 'deal', estimator: 'rbes', trainingStreams: 'philox64' }, 300, [1, 2, 3, 4]], ['flop6-jack-small', { batchDeals: 64, actionStreams: 'deal', estimator: 'rbes' }, 100, [1, 4]],
    ['flop3-queens-6max-small', { batchDeals: 8, actionStreams: 'deal', trainingStreams: 'philox64' }, 400, [1, 3]]]) {
    const spec = write(dir, 'i.json', specOf(id, extra)), ref = path.join(dir, 'old.state'); const o = run([spec, updates, 1, ref, 512], fixed, old); assert.equal(o.status, 0, o.stderr);
    for (const th of threads) { const st = path.join(dir, 'new.state'); const r = run([spec, updates, th, st, 512], fixed); assert.equal(r.status, 0, r.stderr); assert.equal(sha(st), sha(ref), id + ' ' + JSON.stringify(extra) + ' on ' + th + ' thread(s)'); n++; }
  }
  assert.equal(n, 17);
  const pr = write(dir, 'p.json', specOf('flop3-kings-small', { pruning: 'nrp-5.14-v1' })), d = write(dir, 'd.json', specOf('flop3-kings-small')), sp = path.join(dir, 'p.state'), out = path.join(dir, 'x.state');
  assert.equal(run([pr, 500, 1, sp, 512]).status, 0);
  for (const spec of [pr, d]) { const r = run([spec, 5, 1, out, 512, sp], {}, old); assert.equal(r.status, 1, 'the 5.13 program refuses a pruned state'); assert.match(r.stderr, /409/); assert.ok(!fs.existsSync(out)); }
  // a 5.13 program does not know the key "pruning" and trains the default trainer; what it writes says so, and 5.14 does not continue it with pruning
  const o = run([pr, 500, 1, out, 512], {}, old); assert.equal(o.status, 0); assert.ok(!header(out).includes('"estimator"')); assert.equal(run([d, 500, 1, path.join(dir, 'dd.state'), 512]).status, 0); assert.equal(sha(out), sha(path.join(dir, 'dd.state')));
  const back = run([pr, 5, 1, path.join(dir, 'y.state'), 512, out]); assert.equal(back.status, 1); assert.match(back.stderr, /cannot be continued with pruning/);
});
test('5.14 study with pruning: mwcli --study takes pruning=..., the result names the algorithm, an unknown value is a usage error', { timeout: 1800000 }, t => {
  const dir = tmp(t), fx = path.join(studies, 'flop3-kings-small.emfix.json'), out = path.join(dir, 'study.json');
  const r = run(['--study', fx, out, 'variants=baseline', 'seeds=2', 'budgets=2000,6000', 'checkpoint=off', 'quiet=1', 'pruning=nrp-5.14-v1']); assert.equal(r.status, 0, r.stderr.slice(-400));
  const doc = JSON.parse(fs.readFileSync(out, 'utf8')), text = JSON.stringify(doc); assert.ok(text.includes('"identifier":"nrp-5.14-v1"'), 'the trainer of the result names the pruning algorithm'); assert.ok(text.includes('"experimentalPruning":true'));
  const bad = run(['--study', fx, path.join(dir, 'no.json'), 'pruning=fast']); assert.equal(bad.status, 2); assert.match(bad.stderr, /pruning must be none, nrp-5.14-v1 or nrpc-5.14-v1/); assert.ok(!fs.existsSync(path.join(dir, 'no.json')));
});
test('5.14 pruned estimators on a frozen table (tests/prune514.cpp, short form): nrpc-5.14-v1 agrees with the default estimator entry by entry; both algorithms skip candidates and visit fewer states', { timeout: 1800000 }, t => {
  if (process.platform === 'win32') return t.skip('needs a C++ compiler');
  const dir = tmp(t), exe = path.join(dir, 'prune514');
  cp.execFileSync('gcc', ['-O2', '-c', path.join(native, 'json.c'), '-o', path.join(dir, 'json.o')]);
  cp.execFileSync(process.env.EM_TEST_CXX || 'g++', ['-std=c++20', '-O2', '-march=x86-64', '-ffp-contract=off', '-I' + native, path.join(__dirname, 'prune514.cpp'), path.join(dir, 'json.o'), '-lpthread', '-ldl', '-o', exe], { stdio: 'ignore' });
  const spec = path.join(dir, 's.json'); assert.equal(cp.spawnSync('node', [path.join(src, 'tools/games510.js'), 'spec', 'rg-turn3', spec, '5140']).status, 0);
  const out = path.join(dir, 'o.json'), r = cp.spawnSync(exe, [spec, '200000', '400000', out], { encoding: 'utf8', timeout: 1700000 }); assert.equal(r.status, 0, r.stdout + r.stderr);
  const d = JSON.parse(fs.readFileSync(out, 'utf8')), [def, c, u] = d.estimators; assert.equal(d.passed, true); assert.equal(c.estimator, 'nrpc-5.14-v1'); assert.equal(u.estimator, 'nrp-5.14-v1');
  assert.ok(c.entriesCompared >= 10 && c.largestAbsZ <= c.bonferroniCritical, JSON.stringify(c)); assert.ok(c.skippedPerDeal > 0 && u.skippedPerDeal > 0, 'both skip candidates on this table');
  assert.ok(c.stateVisitsPerDeal < def.stateVisitsPerDeal && u.stateVisitsPerDeal < def.stateVisitsPerDeal); assert.ok(c.sumOfRegretVariances > def.sumOfRegretVariances, 'the correction costs variance: that is its price');
  const bad = cp.spawnSync(exe, [write(dir, 'p.json', { ...JSON.parse(fs.readFileSync(spec, 'utf8')), pruning: 'nrp-5.14-v1' }), '10', '10', out], { encoding: 'utf8' }); assert.equal(bad.status, 3, 'the harness wants a default spec');
});
test('5.14 eqtime: spec and reference files are complete; the program names the build, refuses bad usage, runs a quick trial whose equal-deals check passes, and refuses a directory that holds another plan', { timeout: 1800000 }, t => {
  const specs = path.join(src, 'tools/eqtime-specs'), files = fs.readdirSync(specs); const games = ['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'flop6', 'final8', 'bubble4', 'rg-hu-river', 'rg-river3', 'rg-hu-turn', 'rg-turn3', 'rg-turn4', 'rg-icm3-river', 'rg-bubble4', 'rg-flop6c', 'early3-flop', 'mid3-turn', 'short8-push', 'bubble5-icm', 'sidepot3-icm'];
  for (const g of games) for (let s = 5141; s <= 5160; s++) assert.ok(files.includes(g + '-' + s + '.json'), g + ' ' + s);
  for (const g of ['hu-river', 'rg-turn4', 'mid3-turn']) for (const s of [9001, 9002, 9003]) assert.ok(files.includes(g + '-' + s + '.json'));
  assert.equal(files.length, 400 + 9 + 2 + 2); for (const f of ['fixture-flop6-jack.json', 'fixture-flop3-kings.json']) assert.equal(JSON.parse(fs.readFileSync(path.join(specs, f), 'utf8')).protocol, 4);
  const one = JSON.parse(fs.readFileSync(path.join(specs, 'rg-turn3-5141.json'), 'utf8')), two = JSON.parse(fs.readFileSync(path.join(specs, 'rg-turn3-5142.json'), 'utf8')); assert.notEqual(one.actionSeed, two.actionSeed); assert.equal(one.batchDeals, 1); assert.equal(one.actionStreams, 'shared'); assert.equal(one.estimator, undefined); assert.equal(one.pruning, undefined);
  const ref = JSON.parse(fs.readFileSync(path.join(specs, 'reference.json'), 'utf8')), quick = JSON.parse(fs.readFileSync(path.join(specs, 'reference-quick.json'), 'utf8'));
  const wide = ['rg-hu-river', 'rg-river3', 'rg-hu-turn', 'rg-turn3', 'rg-turn4', 'rg-icm3-river'];
  for (const g of games) for (const a of ['default', 'nrp', 'nrpc']) assert.match(ref[g + ' ' + a], /^[0-9a-f]{16}$/, g + ' ' + a);
  for (const g of wide) for (const a of ['rbes-b1', 'default-b1', 'rbes-b2', 'rbes-b4', 'rbes-b8', 'rbes-b16', 'rbes-b32']) assert.match(ref[g + ' ' + a], /^[0-9a-f]{16}$/, g + ' ' + a);
  assert.equal(Object.keys(ref).length, 60 + 42); assert.equal(Object.keys(quick).length, 9 + 7); for (const g of wide) assert.equal(ref[g + ' default'], ref[g + ' default-b1'], 'one program, one value');
  const exe = eqtime(); if (!exe) return t.skip('no eqtime program (build/linux/eqtime or EM_TEST_EQTIME)');
  const dir = tmp(t), q = a => cp.spawnSync(exe, a, { encoding: 'utf8', timeout: 1700000 });
  assert.match(q(['--build-id']).stdout, /^EightMaxBuild=[0-9a-f]{16}\n$/); for (const a of [[], ['fast'], ['pruning', '--nope']]) assert.equal(q(a).status, 2);
  const out = path.join(dir, 'th'), r = q(['threads', '--quick', '--threads', '2', '--out', out]); assert.equal(r.status, 0, r.stdout.slice(-600) + r.stderr);
  const sum = JSON.parse(fs.readFileSync(path.join(out, 'summary.json'), 'utf8')), plan = JSON.parse(fs.readFileSync(path.join(out, 'plan.json'), 'utf8'));
  assert.equal(sum.part, 'threads'); assert.equal(sum.quick, true); assert.equal(sum.errors, 0); assert.equal(sum.equalDealsCheck.passed, true); assert.equal(sum.equalDealsCheck.compared, 4); assert.equal(sum.baseline, 'rbes-b1-t1');
  assert.deepEqual([...new Set(sum.contrasts.map(c => c.candidate))], ['rbes-b2-t2', 'rbes-b8-t2']); assert.match(sum.decisions['rbes-b2-t2'].decision, /QUICK TRIAL/); assert.match(plan.plan, /RULE, fixed before measuring/); assert.match(r.stdout, /No default changes in 5\.14/);
  for (const f of ['raw.jsonl', 'summary.txt', 'machine.txt']) assert.ok(fs.statSync(path.join(out, f)).size > 0);
  const rows = fs.readFileSync(path.join(out, 'raw.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l)); assert.equal(rows.length, 3 * 4 + 4); assert.ok(rows.every(x => x.nashConv >= 0 && /^[0-9a-f]{16}$/.test(x.bits)));
  const again = q(['threads', '--quick', '--threads', '2', '--out', out]); assert.equal(again.status, 0); assert.match(again.stdout, /3 units done earlier, 0 to run/);
  const other = q(['threads', '--quick', '--threads', '4', '--out', out]); assert.equal(other.status, 1); assert.match(other.stderr, /holds another plan/);
  const an = q(['analyze', out]); assert.equal(an.status, 0, an.stderr); assert.match(an.stdout, /QUICK TRIAL/);
});
test('5.14 self-test: mwcli --selftest514 passes every check under two sections; a section alone; usage errors; without fixtures nothing passes', { timeout: 1800000 }, t => {
  const dir = tmp(t), r = run(['--selftest514', studies, path.join(dir, 'w'), 'all']); assert.equal(r.status, 0, r.stdout + r.stderr.slice(0, 400));
  const doc = JSON.parse(fs.readFileSync(path.join(dir, 'w/selftest514.json'), 'utf8')); assert.equal(doc.failed, 0); assert.equal(doc.untested, 0); assert.equal(doc.passed, 7);
  assert.deepEqual(doc.checks.map(c => c.section + ' ' + c.id), IDS); assert.deepEqual(doc.pruningAlgorithms, ['nrp-5.14-v1', 'nrpc-5.14-v1']);
  const m = run(['--selftest514', studies, path.join(dir, 'm'), 'merge']); assert.equal(m.status, 0); assert.equal(JSON.parse(m.stdout).passed, 1);
  assert.equal(run(['--selftest514']).status, 2); assert.equal(run(['--selftest514', studies, path.join(dir, 'x'), 'everything']).status, 2);
  const empty = path.join(dir, 'empty'); fs.mkdirSync(empty); const e = run(['--selftest514', empty, path.join(dir, 'e'), 'all']); assert.equal(e.status, 1); const d2 = JSON.parse(fs.readFileSync(path.join(dir, 'e/selftest514.json'), 'utf8')); assert.equal(d2.passed, 0);
  const golden = fs.readFileSync(path.join(native, 'selftest514_golden.hpp'), 'utf8').trim().split('\n'); assert.equal(golden.length, 32 + 8); assert.ok(golden.every(l => /"[0-9a-f]{64}"\},$/.test(l)), 'every recorded state is a SHA-256');
});
test('5.14 Windows validation: the script keeps every section of the 5.13 script, plans and imports every 5.14 check, the launchers run the self-tests first, the equal-time launchers start eqtime.exe, the build verifies four programs', () => {
  const file = path.join(src, 'tools/validate_windows514.ps1'), ps = fs.readFileSync(file, 'utf8'), version = fs.readFileSync(path.join(src, 'VERSION'), 'utf8').trim();
  assert.ok(['5.14', '5.15'].includes(version), version); assert.match(ps, /\$Release = '5\.14'/);   // 5.15: the 5.14 script is kept as it ran; validate_windows515.ps1 is the current one
  assert.match(ps, /tool = 'validate_windows514\.ps1'/); assert.ok(!/[^\x00-\x7f]/.test(ps), 'the script is ASCII'); assert.ok(ps.includes('$count -gt 1000'));
  for (const s of ["Run-Section 'self-test 5.14'", "Run-Section 'equal time 5.14'", "Run-Section 'self-test 5.13'", "Run-Section 'satellite 5.13'", "Run-Section 'GPU'", "'--selftest514', $studies, $dir, 'all'", "'eqtime.exe'", "'--quick'"]) assert.ok(ps.includes(s), s);
  for (const id of IDS) assert.ok(ps.includes("'" + id + "'"), 'expected check ' + id);
  const plans = [...ps.matchAll(/^Plan '([^']+)' '([^']+)' '([^']+)'/gm)];
  for (const name of ['mwcli --selftest514 ran and wrote its report', 'every expected 5.14 check is in the report', 'the 5.14 report agrees with the exit status of mwcli', 'eqtime.exe is present and names this build', 'thread scaling of frozen batches on this PC (quick)']) {
    assert.equal(plans.filter(p => p[2] === name).length, 1, 'planned once: ' + name); const sec = plans.find(p => p[2] === name)[1]; assert.ok(ps.includes("Check '" + sec + "' '" + name + "'") || ps.includes("Add-Check '" + sec + "' '" + name + "'"), 'planned but never recorded: ' + name); }
  for (const part of ['pruning', 'threads']) assert.equal(plans.filter(p => p[2] === 'eqtime quick trial of the ' + part + ' experiment').length, 1);
  const focus = /\$focusSections = @\(([^)]*)\)/.exec(ps)[1]; for (const s of ["'self-test 5.14'", "'equal time 5.14'", "'self-test 5.13'", "'satellite 5.13'", "'golden states'", "'integrity'"]) assert.ok(focus.includes(s), 'focused: ' + s);
  const sections = text => [...text.matchAll(/^Run-Section '([^']+)'/gm)].map(m => m[1]), before = sections(fs.readFileSync(path.join(src, 'tools/validate_windows513.ps1'), 'utf8')), now = sections(ps);
  assert.deepEqual(now.filter(s => before.includes(s)), before); assert.deepEqual(now.filter(s => !before.includes(s)), ['self-test 5.14', 'equal time 5.14']);
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (py) { const r = cp.spawnSync(py, [path.join(src, 'tools/ps_lint571.py'), file], { encoding: 'utf8' }); assert.equal(r.status, 0, r.stdout + r.stderr); }
  for (const [name, needs] of [['Run 5.14 Windows validation.bat', ['mwcli.exe --selftest57 ', 'mwcli.exe --selftest513 ', 'mwcli.exe --selftest514 ', 'validate_windows514.ps1" %*', 'Windows-selftest514-5.14.json', 'Windows-validation-5.14.json', 'Step 10 of 10', 'if not "%selftest514_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"']],
    ['Run 5.14 focused validation.bat', ['mwcli.exe --selftest514 ', 'validate_windows514.ps1" -Focused %*', 'Windows-focused-validation-5.14.json', 'Windows-selftest514-5.14.json']],
    ['Run 5.14 equal-time comparison.bat', ['eqtime.exe all %*', 'cd /d "%~dp0"', 'equal-time-results', 'if not defined EIGHTMAX_NO_PAUSE pause']], ['Run 5.14 equal-time quick trial.bat', ['eqtime.exe all --quick %*', 'never a result']]]) {
    const f = path.join(root, name); if (!fs.existsSync(f)) continue;
    const text = fs.readFileSync(f).toString('latin1'); assert.ok(!/[^\x00-\x7f]/.test(text), name + ' is ASCII'); assert.ok(!/[^\r]\n/.test(text), name + ' has CRLF line ends'); for (const n of needs) assert.ok(text.includes(n), name + ': ' + n); assert.match(text, /exit \/b %\w+%\r\n$/);
    assert.ok(!text.includes('-5.13.json') && !text.includes('validate_windows513'), name + ' writes 5.14 reports only');
  }
  const vb = fs.readFileSync(path.join(src, 'tools/verify_build.js'), 'utf8'); assert.ok(vb.includes("'eqtime.exe'")); const bs = fs.readFileSync(path.join(native, 'build.sh'), 'utf8'); assert.ok(bs.includes('../tools/eqtime514.cpp') && bs.includes('"$dest/eqtime.exe"') && bs.includes('"$dest/eqtime"'));
  const wf = path.join(root, '.github/workflows/windows.yml');
  if (fs.existsSync(wf)) { const y = fs.readFileSync(wf, 'utf8'); for (const s of ['--selftest514 source/studies', version === '5.14' ? 'validate_windows514.ps1 -Root' : 'validate_windows515.ps1 -Root', version === '5.14' ? 'Windows-validation-5.14.json' : 'Windows-validation-5.15.json', 'windows-selftest514.json', 'source/tests/v514.test.js', 'eqtime.exe']) assert.ok(y.includes(s), s); }
});
