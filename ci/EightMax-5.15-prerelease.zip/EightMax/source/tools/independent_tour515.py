#!/usr/bin/env python3
"""EightMax 5.15: an independent implementation of the tournament payoff model tour-5.15-v1.

Written from the definition of the model (MATHEMATICAL-VALIDATION-5.15.md), sharing no code with native/tour515.hpp or
web/lib_tour515.js. It shares one piece of DATA with them: the table of preflop all-in equities by hand class
(web/lib_eqdata.js), which this release did not compute and does not re-derive.

  python3 independent_tour515.py check <mwcli> <requests.json> <report.json>

For every request (the format of `mwcli --tour515`) it asks the program for its values and, when future hands are
simulated, for the solution of the first future hand, and checks:

  A  no future hands: every value = ICM (own recursion over finishing orders) + bounty cash + pool rule, within 1e-9
  B  future hands: (1) with exactly one future hand, the worth of every outcome of that hand (the program's
     foldValues / showdownValues) = the same formula applied to the stacks this script derives from the posting rules,
     within 1e-9; (2) the program's values of the hand = the expected values of the reported strategies, recomputed here
     from the reported outcome values, within 1e-9; (3) the most any player gains by deviating at his decisions,
     recomputed here (reported; the bound is 1e-3 of the unit)
  C  when every player is a study seat: the values sum to prizes paid plus bounties, within 1e-9

Exit 0 when every bound holds, 1 otherwise.
"""
import base64, itertools, json, os, re, struct, subprocess, sys, tempfile

RANKS = '23456789TJQKA'
HERE = os.path.dirname(os.path.abspath(__file__))


def class_name(a, b):
    ra, rb = a // 4, b // 4
    if ra == rb:
        return RANKS[ra] * 2
    hi, lo = max(ra, rb), min(ra, rb)
    return RANKS[hi] + RANKS[lo] + ('s' if a % 4 == b % 4 else 'o')


class Tables:
    """Class probabilities, the conditional distribution of an opponent's class, and win / tie by class pair."""

    def __init__(self, names):
        self.names = names
        self.n = n = len(names)
        index = {x: i for i, x in enumerate(names)}
        text = open(os.path.join(HERE, '..', 'web', 'lib_eqdata.js')).read()
        raw = base64.b64decode(re.search(r"EQ_B64\s*=\s*'([^']+)'", text).group(1))
        u = struct.unpack('<%dH' % (len(raw) // 2), raw)
        self.W = [[0.0] * n for _ in range(n)]
        self.T = [[0.0] * n for _ in range(n)]
        k = 0
        for a in range(n):
            for b in range(a, n):
                w, t = u[k] / 65535, u[k + 1] / 65535
                k += 2
                self.W[a][b], self.T[a][b] = w, t
                if a != b:
                    self.W[b][a], self.T[b][a] = max(0.0, 1 - w - t), t
        hands = [(a, b) for a in range(52) for b in range(a + 1, 52)]
        cls = [index[class_name(a, b)] for a, b in hands]
        self.combos = [0] * n
        for c in cls:
            self.combos[c] += 1
        pairs = [[0] * n for _ in range(n)]
        for i, (a, b) in enumerate(hands):
            for j, (c, d) in enumerate(hands):
                if a != c and a != d and b != c and b != d:
                    pairs[cls[i]][cls[j]] += 1
        self.pi = [self.combos[c] / 1326 for c in range(n)]
        # cond[a][b]: probability that an opponent holds class b when I hold one combination of class a
        self.cond = [[pairs[a][b] / (self.combos[a] * 1225) for b in range(n)] for a in range(n)]


def icm(stacks, prizes):
    """Malmuth-Harville: value of every stack, by recursion over who takes the next place."""
    n = len(stacks)
    out = [0.0] * n

    def go(left, place, prob):
        if place >= len(prizes) or not left:
            return
        total = sum(stacks[i] for i in left)
        if total <= 1e-12:
            return
        for i in left:
            p = prob * stacks[i] / total
            if p == 0:
                continue
            out[i] += p * prizes[place]
            go([j for j in left if j != i], place + 1, p)

    go(list(range(n)), 0, 1.0)
    return out


def icm_with_busts(final, start, prizes):
    n = len(final)
    alive = [i for i in range(n) if final[i] > 1e-9]
    busted = sorted((i for i in range(n) if final[i] <= 1e-9), key=lambda i: -start[i])
    res = [0.0] * n
    eq = icm([final[i] for i in alive], prizes[:len(alive)])
    for k, i in enumerate(alive):
        res[i] = eq[k]
    k = 0
    while k < len(busted):
        end = k + 1
        while end < len(busted) and abs(start[busted[end]] - start[busted[k]]) < 1e-9:
            end += 1
        pool = sum(prizes[len(alive) + j] for j in range(k, end) if len(alive) + j < len(prizes))
        for j in range(k, end):
            res[busted[j]] = pool / (end - k)
        k = end
    return res


def v0(x, start, heads, other_stack, other_head, prizes, bounty):
    """Table players: ICM with the bust rule plus the pool rule."""
    nt = len(x)
    res = icm_with_busts(list(x) + other_stack, list(start) + other_stack, prizes)[:nt]
    if bounty:
        pool = sum(heads[i] for i in range(nt) if x[i] > 1e-9) + sum(other_head)
        chips = sum(x) + sum(other_stack)
        res = [res[i] + x[i] / chips * pool for i in range(nt)]
    return res


def post(stacks, sb, bb, ante_type, ante):
    n = len(stacks)
    a, b = [0.0] * n, [0.0] * n
    for p in range(n):
        bl = bb if p == n - 1 else sb if p == n - 2 else 0.0
        if ante_type == 'classic':
            a[p] = min(ante, stacks[p]); b[p] = min(bl, stacks[p] - a[p])
        elif ante_type == 'bba':
            b[p] = min(bl, stacks[p]); a[p] = min(ante, stacks[p] - b[p]) if p == n - 1 else 0.0
        else:
            b[p] = min(bl, stacks[p])
    return a, b


def outcomes_of_hand(stacks, sb, bb, ante_type, ante):
    """Every outcome of the push/fold hand: ('fold', i) -> stacks; ('show', i, j, r) -> stacks, r = 0 i wins, 1 j wins, 2 tie."""
    n = len(stacks)
    a, b = post(stacks, sb, bb, ante_type, ante)
    if any(stacks[p] - a[p] - b[p] <= 1e-9 for p in range(n)):
        return None
    dead = sum(a) + sum(b)
    base = [stacks[p] - a[p] - b[p] for p in range(n)]
    out = {}
    for i in range(n):
        v = base[:]; v[i] += dead; out[('fold', i)] = v
    for i in range(n):
        for j in range(i + 1, n):
            m = min(stacks[i] - a[i], stacks[j] - a[j])
            pot = 2 * m + dead - b[i] - b[j]
            for r in range(3):
                v = base[:]; v[i] = stacks[i] - a[i] - m; v[j] = stacks[j] - a[j] - m
                if r == 0: v[i] += pot
                elif r == 1: v[j] += pot
                else: v[i] += pot / 2; v[j] += pot / 2
                out[('show', i, j, r)] = v
    return out


def evaluate_hand(T, n, jam, call, VF, VS):
    """Values and deviation gains of the push/fold hand from the definition.
    jam[i][c], call[(i,j)][c]; VF[i][p]; VS[(i,j)][r][p] with r = 0 jammer wins, 1 caller wins, 2 tie."""
    NC, pi, cond, W, Tt = T.n, T.pi, T.cond, T.W, T.T
    pjam = [sum(pi[c] * jam[i][c] for c in range(NC)) for i in range(n - 1)]
    reach = [1.0] * (n - 1)
    for i in range(1, n - 1):
        reach[i] = reach[i - 1] * (1 - pjam[i - 1])
    stage = {}      # stage[i][j0][p]: value to p when i has jammed and the seats i+1 .. j0-1 have folded (average over i's jamming hands)
    ev_jam = {}     # ev_jam[i][c]: value to i of jamming class c
    pass_prob = {}  # pass_prob[i][j]: probability that seat j folds to i's jam (average over i's jamming hands)
    for i in range(n - 1):
        acc = {j0: [0.0] * n for j0 in range(i + 1, n + 1)}
        called = {j0: 0.0 for j0 in range(i + 1, n)}
        wsum = 0.0
        ev_jam[i] = [0.0] * NC
        # for the jammer holding c: probability that seat j calls, and that the jammer then wins / ties
        pc = {j: [sum(cond[c][h] * call[(i, j)][h] for h in range(NC)) for c in range(NC)] for j in range(i + 1, n)}
        pw = {j: [sum(cond[c][h] * call[(i, j)][h] * W[c][h] for h in range(NC)) for c in range(NC)] for j in range(i + 1, n)}
        pt = {j: [sum(cond[c][h] * call[(i, j)][h] * Tt[c][h] for h in range(NC)) for c in range(NC)] for j in range(i + 1, n)}
        for c in range(NC):
            w = pi[c] * (jam[i][c] + 1e-9)   # the definition mixes 1e-9 of every hand into a jamming range when it is averaged
            wsum += w
            cur = list(VF[i])
            for p in range(n): acc[n][p] += w * cur[p]
            for j in range(n - 1, i, -1):
                win, tie = pw[j][c], pt[j][c]; lose = pc[j][c] - win - tie; nf = 1 - pc[j][c]
                vs = VS[(i, j)]
                cur = [win * vs[0][p] + tie * vs[2][p] + lose * vs[1][p] + nf * cur[p] for p in range(n)]
                for p in range(n): acc[j][p] += w * cur[p]
                called[j] += w * pc[j][c]
            ev_jam[i][c] = cur[i]
        stage[i] = {j0: [x / wsum for x in acc[j0]] for j0 in acc}
        pass_prob[i] = {j: 1 - called[j] / wsum for j in called}
    after = {n - 2: list(VF[n - 1])}   # after[k]: values when the seats 0 .. k have folded
    for k in range(n - 2, 0, -1):
        after[k - 1] = [pjam[k] * stage[k][k + 1][p] + (1 - pjam[k]) * after[k][p] for p in range(n)]
    values = [pjam[0] * stage[0][1][p] + (1 - pjam[0]) * after[0][p] for p in range(n)]
    gains = [0.0] * n
    for i in range(n - 1):
        fold = after[i][i]
        g = sum(pi[c] * (max(ev_jam[i][c], fold) - (jam[i][c] * ev_jam[i][c] + (1 - jam[i][c]) * fold)) for c in range(NC))
        gains[i] += reach[i] * g
    for i in range(n - 1):
        fr = 1.0
        for j in range(i + 1, n):
            vs = VS[(i, j)]
            fold_value = stage[i][j + 1][j]
            g = 0.0
            for h in range(NC):
                rj = sum(cond[h][c] * jam[i][c] for c in range(NC))
                wj = sum(cond[h][c] * jam[i][c] * W[h][c] for c in range(NC))
                tj = sum(cond[h][c] * jam[i][c] * Tt[h][c] for c in range(NC))
                a = wj * vs[1][j] + tj * vs[2][j] + (rj - wj - tj) * vs[0][j]
                b = rj * fold_value
                s = call[(i, j)][h]
                g += pi[h] * (max(a, b) - (s * a + (1 - s) * b))
            gains[j] += reach[i] * fr * g
            fr *= pass_prob[i][j]
    return values, gains


def run(cli, req):
    with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f:
        json.dump(req, f); name = f.name
    try:
        r = subprocess.run([cli, '--tour515', name], capture_output=True, text=True)
    finally:
        os.unlink(name)
    if r.returncode:
        raise RuntimeError('mwcli --tour515: ' + r.stderr.strip())
    return json.loads(r.stdout)


def check(cli, requests):
    report = {'tool': 'independent_tour515.py', 'cases': [], 'largest': {'A': 0.0, 'B1': 0.0, 'B2': 0.0, 'gainOverUnit': 0.0, 'C': 0.0}, 'counts': {'A': 0, 'B1': 0, 'B2': 0, 'C': 0}, 'failed': []}
    T = None
    for q in requests:
        name = q.get('name', '?')
        n = q['seats']; start = q['start']; prizes = q['prizes']; N = len(start)
        bo = q.get('bounty'); share = bo['share'] if bo else 0.0; heads = bo['heads'] if bo else [0.0] * N
        fg = q.get('fgs'); depth = fg['depth'] if fg else 0
        got = run(cli, dict(q, nextHand=True))
        case = {'name': name, 'depth': depth, 'bounty': bool(bo), 'outcomes': len(q['outcomes'])}
        table = fg['table'] if fg else list(range(n))
        outside = [g for g in range(N) if g not in table] if fg else list(range(n, N))
        other_stack = [start[g] for g in outside]; other_head = [heads[g] for g in outside]
        for o, res in zip(q['outcomes'], got['outcomes']):
            fin = o['final']; won = o.get('won') or [0] * n
            cash = [0.0] * n; h = list(heads); lost = 0.0
            if bo:
                for p in range(n):
                    if fin[p] <= 1e-9 and heads[p] > 0:
                        ws = [e for e in range(n) if e != p and (won[p] >> e) & 1] if p < len(won) else []
                        h[p] = 0.0
                        lost += share * heads[p] if ws else heads[p]
                        for e in ws:
                            cash[e] += share * heads[p] / len(ws); h[e] += (1 - share) * heads[p] / len(ws)
            if not depth:
                x = list(fin) + start[n:]
                base = icm_with_busts(x, start, prizes)
                chips = sum(x); pool = sum(heads) - lost
                want = [base[p] + cash[p] + fin[p] / chips * pool for p in range(n)]
                d = max(abs(want[p] - res['values'][p]) for p in range(n))
                report['largest']['A'] = max(report['largest']['A'], d); report['counts']['A'] += 1
                if d > 1e-9: report['failed'].append('%s: A differs by %.3g' % (name, d))
                if N == n:
                    paid = sum(prizes[:N])
                    # bounties still to be paid or paid in this hand: every head minus the heads nobody could collect
                    unclaimed = sum(heads[p] for p in range(n) if fin[p] <= 1e-9 and heads[p] > 0 and not any((won[p] >> e) & 1 for e in range(n) if e != p))
                    total = paid + sum(heads) - unclaimed
                    c = abs(sum(res['values']) - total)
                    report['largest']['C'] = max(report['largest']['C'], c); report['counts']['C'] += 1
                    if c > 1e-9: report['failed'].append('%s: C sum differs by %.3g' % (name, c))
                continue
            nh = res.get('nextHand')
            if not nh or not nh.get('played'):
                continue
            if T is None: T = Tables(got['classes'])
            ids = nh['players']; m = len(ids); NC = T.n
            # the players of the next hand as this script derives them: button one seat on, busted players gone
            order = [table[k % len(table)] for k in range(1, len(table) + 1)]
            mine = [g for g in order if (fin[g] if g < n else start[g]) > 1e-9]
            if mine != ids: report['failed'].append('%s: players of the next hand differ' % name); continue
            stacks = [fin[g] if g < n else start[g] for g in ids]
            if max(abs(stacks[k] - nh['stacks'][k]) for k in range(m)) > 0: report['failed'].append('%s: stacks of the next hand differ' % name); continue
            hh = [h[g] if g < n else heads[g] for g in ids]
            fv = nh['foldValues']; sv = nh['showdownValues']
            VF = [[fv[i * m + p] for p in range(m)] for i in range(m)]
            VS = {(i, j): [[sv[((i * m + j) * 3 + r) * m + p] for p in range(m)] for r in range(3)] for i in range(m) for j in range(i + 1, m)}
            if depth == 1:
                outs = outcomes_of_hand(stacks, fg.get('smallBlind', 0.5), fg.get('bigBlind', 1), fg.get('anteType', 'none'), fg.get('ante', 0))
                left = m + len(other_stack); pays = prizes[:min(len(prizes), left)]
                d1 = 0.0
                for key, v in outs.items():
                    h2 = list(hh); extra = [0.0] * m
                    if key[0] == 'show' and key[3] < 2:
                        w, l = (key[1], key[2]) if key[3] == 0 else (key[2], key[1])
                        if bo and v[l] <= 1e-9:
                            extra[w] = share * hh[l]; h2[w] += (1 - share) * hh[l]; h2[l] = 0.0
                    want = v0(v, stacks, h2, other_stack, other_head, pays, bool(bo))
                    want = [want[p] + extra[p] for p in range(m)]
                    have = VF[key[1]] if key[0] == 'fold' else VS[(key[1], key[2])][key[3]]
                    d1 = max(d1, max(abs(want[p] - have[p]) for p in range(m)))
                report['largest']['B1'] = max(report['largest']['B1'], d1); report['counts']['B1'] += 1
                if d1 > 1e-9: report['failed'].append('%s: B1 outcome values differ by %.3g' % (name, d1))
            jam = [nh['jam'][i * NC:(i + 1) * NC] for i in range(m - 1)]
            call = {}; k = 0
            for i in range(m - 1):
                for j in range(i + 1, m):
                    call[(i, j)] = nh['call'][k * NC:(k + 1) * NC]; k += 1
            values, gains = evaluate_hand(T, m, jam, call, VF, VS)
            d2 = max(abs(values[p] - nh['values'][p]) for p in range(m))
            g = max(gains) / nh['unit']
            report['largest']['B2'] = max(report['largest']['B2'], d2); report['counts']['B2'] += 1
            report['largest']['gainOverUnit'] = max(report['largest']['gainOverUnit'], g)
            if d2 > 1e-9: report['failed'].append('%s: B2 values differ by %.3g' % (name, d2))
            if g > 1e-3: report['failed'].append('%s: a player gains %.3g of the unit by deviating' % (name, g))
            if abs(max(gains) - nh['exploitability']) > 1e-9: report['failed'].append('%s: reported deviation gain differs from the recomputed one by %.3g' % (name, abs(max(gains) - nh['exploitability'])))
            case.setdefault('nextHands', []).append({'players': m, 'valueDifference': d2, 'largestGainOverUnit': g, 'iterations': nh['iterations']})
        report['cases'].append(case)
    report['passed'] = not report['failed']
    return report


if __name__ == '__main__':
    if len(sys.argv) != 5 or sys.argv[1] != 'check':
        print(__doc__); sys.exit(2)
    rep = check(os.path.abspath(sys.argv[2]), json.load(open(sys.argv[3]))['requests'])
    json.dump(rep, open(sys.argv[4], 'w'), indent=1)
    print(json.dumps({'passed': rep['passed'], 'largest': rep['largest'], 'counts': rep['counts'], 'failed': rep['failed'][:10]}))
    sys.exit(0 if rep['passed'] else 1)
