// EightMax 5.15 (Phase 5, ICM and bounty formats): mwcli --selftest515 <studies-dir> <work-dir> [all|model|training|checkpoint]
//
//   model       the tournament payoff model tour-5.15-v1 (tour515.hpp), in this process:
//                 M1  the values of a fixed set of requests (bounties, one to three future hands, both, players at
//                     other tables, a hand that cannot be played) have the bits recorded from the Linux build;
//                 M2  when every player is a study seat the values sum to the prizes paid plus the bounties that
//                     somebody can still collect or collected in the hand;
//                 M3  closed forms: heads-up, the winner of everything gets the first prize plus both bounties; without
//                     a bust the value is ICM plus the chip share of the bounties; a knockout pays the winner the whole
//                     bounty where a progressive knockout pays half; a split pot splits the bounty;
//                 M4  where no future hand can be played (a player cannot post) the value is the plain ICM of this
//                     program, to the bit;
//                 M5  requests that are refused, with the reason: more future-hand solutions than the limit, a table
//                     without a study seat, a negative bounty, a share above 1, neither bounties nor future hands.
//   training    T1  recorded states (SHA-256 from the Linux build): the two small fixtures of 5.15, two variants each,
//                     5.10 streams and philox64, one deal per update and frozen batches on three threads;
//                 T2  a frozen batch writes the same state on 1 and 3 threads; stopped after a third and continued =
//                     uninterrupted, byte for byte;
//                 T3  exact NashConv after a fixed budget, as recorded (a regression check; no convergence claim);
//                 T4  the trainer names the payoff model, its key and the number of future hands it solved.
//   checkpoint  C1  a state trained under the model names "payoffModel":"tour-5.15-v1" and a "payoffKey" in its header;
//                     a plain ICM state names neither;
//                 C2  refused with the reason, exit 1 and nothing written: a model state continued by the plain ICM
//                     study, a plain ICM state continued under the model, a progressive-knockout state continued as a
//                     knockout, a two-future-hands state continued with one;
//                 C3  specs refused before training: the prizes under "payouts", an unknown model name, future hands
//                     beyond the limit, a table that leaves out a study seat, a bounty list of the wrong length.
// Report: <work-dir>/selftest515.json. Exit status: 0 every check passed, 1 a check failed or is untested, 2 usage.
//   mwcli --selftest515 studies work record   writes selftest515_values.hpp, selftest515_golden.hpp and
//                                             selftest515_reference.hpp from THIS build (once, on Linux, at release).
#pragma once
namespace st515 {
namespace fs = std::filesystem;
using st58::Report; using st58::fmt; using st58::sci; using st58::get; using st58::num; using st58::str; using st58::Doc;
using st510::writeText; using st510::Trained; using st510::train; using st510::exactNashConv;
using st512::join; using st512::optionsOf; using st513::Fx; using st513::fixtureOf;
static const char *const VALUES515[] = {
#include "selftest515_values.hpp"
};
struct Golden515 { const char *fixture; int variant; long long updates; bool batch, wide; const char *sha; };
static const Golden515 GOLDEN515[] = {
#include "selftest515_golden.hpp"
};
struct Reference515 { const char *fixture; int variant; long long updates; double nash; };
static const Reference515 REFERENCE515[] = {
#include "selftest515_reference.hpp"
};
static const std::vector<std::pair<std::string, std::string>> FIXED = {{"EIGHTMAX_THREAD_CHOICE", "fixed"}};
// the requests of M1 (mwcli --tour515 format); total: the sum M2 expects, or -1 when players sit elsewhere
struct Req { const char *name, *json; double total; };
#define FG(d, t, at, an) "\"fgs\":{\"depth\":" #d ",\"table\":[" t "],\"smallBlind\":0.5,\"bigBlind\":1,\"ante\":" #an ",\"anteType\":\"" at "\"}"
static const Req REQUESTS[] = {
  {"pko4", "{\"seats\":4,\"start\":[4,20,15,11],\"prizes\":[50,30,20],\"bounty\":{\"share\":0.5,\"heads\":[10,10,25,5]},\"outcomes\":[{\"final\":[4,20,15,11]},{\"final\":[0,24,15,11],\"won\":[2]},{\"final\":[0,22,17,11],\"won\":[6]},{\"final\":[0,0,39,11],\"won\":[4,4]}]}", 150},
  {"ko4", "{\"seats\":4,\"start\":[4,20,15,11],\"prizes\":[50,30,20],\"bounty\":{\"share\":1,\"heads\":[10,10,25,5]},\"outcomes\":[{\"final\":[0,24,15,11],\"won\":[2]},{\"final\":[0,0,39,11],\"won\":[4,4]}]}", 150},
  {"pko3-of-5", "{\"seats\":3,\"start\":[4,20,15,11,30],\"prizes\":[50,30,20],\"bounty\":{\"share\":0.5,\"heads\":[10,10,25,5,8]},\"outcomes\":[{\"final\":[0,24,15],\"won\":[2]},{\"final\":[9,15,15]}]}", -1},
  {"fgs1-4", "{\"seats\":4,\"start\":[4,20,15,11],\"prizes\":[50,30,20]," FG(1, "0,1,2,3", "bba", 1) ",\"outcomes\":[{\"final\":[4,20,15,11]},{\"final\":[0,24,15,11],\"won\":[2]},{\"final\":[8.5,20,15,6.5]}]}", 100},
  {"fgs1-hu", "{\"seats\":2,\"start\":[12,8],\"prizes\":[70,30]," FG(1, "0,1", "none", 0) ",\"outcomes\":[{\"final\":[12,8]},{\"final\":[4,16]}]}", 100},
  {"fgs1-6-classic", "{\"seats\":6,\"start\":[10,25,14,8,30,18],\"prizes\":[40,25,15,10,6,4]," FG(1, "0,1,2,3,4,5", "classic", 0.1) ",\"outcomes\":[{\"final\":[10,25,14,8,30,18]}]}", 100},
  {"fgs1-folded-seat-first", "{\"seats\":3,\"start\":[15,20,11,3.9],\"prizes\":[50,30,20]," FG(1, "3,0,1,2", "classic", 0.1) ",\"outcomes\":[{\"final\":[14.9,19.4,11.6]},{\"final\":[26.8,19.4,0],\"won\":[0,0,1]}]}", -1},
  {"pko+fgs1-4", "{\"seats\":4,\"start\":[4,20,15,11],\"prizes\":[50,30,20],\"bounty\":{\"share\":0.5,\"heads\":[10,10,25,5]}," FG(1, "0,1,2,3", "bba", 1) ",\"outcomes\":[{\"final\":[4,20,15,11]},{\"final\":[0,24,15,11],\"won\":[2]}]}", 150},
  {"fgs2-3", "{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20]," FG(2, "0,1,2", "bba", 1) ",\"outcomes\":[{\"final\":[6,12,9]},{\"final\":[0,18,9],\"won\":[2]}]}", 100},
  {"pko+fgs2-3", "{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20],\"bounty\":{\"share\":0.5,\"heads\":[10,10,25]}," FG(2, "0,1,2", "bba", 1) ",\"outcomes\":[{\"final\":[6,12,9]}]}", 145},
  {"fgs3-hu", "{\"seats\":2,\"start\":[12,8],\"prizes\":[70,30]," FG(3, "0,1", "none", 0) ",\"outcomes\":[{\"final\":[12,8]},{\"final\":[4,16]}]}", 100},
  {"fgs2-2-of-5", "{\"seats\":2,\"start\":[6,12,9,14,22],\"prizes\":[50,30,20]," FG(2, "3,0,2,1", "classic", 0.1) ",\"outcomes\":[{\"final\":[6,12]},{\"final\":[12,6]}]}", -1},
};
struct Answer { bool ok = false; std::string why; std::vector<std::vector<double>> values; std::vector<std::string> bits; };
static Answer ask(const char *json) {
  Answer a; std::string out; if (tq515::answer(json, out, a.why)) return a;
  Doc d(out); const JV *os = get(d.v, "outcomes"); if (!os || os->type != J_ARR) { a.why = "no outcomes"; return a; }
  for (int i = 0; i < os->n; i++) { const JV *v = get(os->items[i], "values"), *b = get(os->items[i], "bits"); a.values.emplace_back();
    for (int k = 0; v && k < v->n; k++) { a.values.back().push_back(num(v->items[k])); a.bits.push_back(str(b->items[k])); } }
  a.ok = true; return a;
}
static void modelSection(Report &R) {
  const std::string sec = "model";
  { size_t at = 0, same = 0, total = 0; const size_t have = sizeof VALUES515 / sizeof *VALUES515; std::string detail; double worstSum = 0; int sums = 0;
    for (const Req &q : REQUESTS) { const Answer a = ask(q.json); if (!a.ok) { detail += std::string(q.name) + ": " + a.why + "; "; continue; }
      for (const std::string &b : a.bits) { total++; if (at < have && b == VALUES515[at]) same++; else if (detail.size() < 400) detail += std::string(q.name) + ": " + b + " instead of " + (at < have ? VALUES515[at] : "(nothing recorded)") + "; "; at++; }
      if (q.total >= 0) for (const auto &v : a.values) { double s = 0; for (double x : v) s += x; worstSum = std::max(worstSum, std::fabs(s - q.total)); sums++; } }
    R.check(sec, "M1", "the values of the payoff model tour-5.15-v1 for a fixed set of requests (knockout and progressive bounties, one to three future hands, both together, players at other tables) have the bits recorded from the Linux build of this release", same == total && total == have && total > 0, std::to_string(same) + " of " + std::to_string(total) + " values identical (" + std::to_string(have) + " recorded)" + (detail.empty() ? "" : "; " + detail));
    R.check(sec, "M2", "when every player is a study seat, the values of an outcome sum to the prizes plus the bounties (nothing is created or lost by the model)", sums > 0 && worstSum <= 1e-9, std::to_string(sums) + " outcomes, largest difference " + sci(worstSum)); }
  { std::string detail; bool ok = true; auto same12 = [&](const char *what, double got, double want) { const bool good = std::fabs(got - want) <= 1e-12 * std::max(1.0, std::fabs(want)); ok = ok && good; detail += std::string(what) + " " + fmt(got) + (good ? "" : " (expected " + fmt(want) + ")") + "; "; };
    const Answer hu = ask("{\"seats\":2,\"start\":[12,8],\"prizes\":[70,30],\"bounty\":{\"share\":0.5,\"heads\":[10,20]},\"outcomes\":[{\"final\":[20,0],\"won\":[0,1]},{\"final\":[12,8]},{\"final\":[0,20],\"won\":[2,0]}]}");
    if (!hu.ok) { ok = false; detail += hu.why; } else { same12("heads-up, seat 0 wins everything:", hu.values[0][0], 100); same12("the loser:", hu.values[0][1], 30); same12("no bust, seat 0 (ICM 54 + 0.6 x 30):", hu.values[1][0], 72); same12("seat 1 (46 + 0.4 x 30):", hu.values[1][1], 58); same12("seat 1 wins everything:", hu.values[2][1], 100); }
    const char *three = "{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20],\"bounty\":{\"share\":%s,\"heads\":[10,10,25]},\"outcomes\":[{\"final\":[0,18,9],\"won\":[2]},{\"final\":[0,15,12],\"won\":[6]}]}"; char b1[400], b2[400]; snprintf(b1, sizeof b1, three, "1"); snprintf(b2, sizeof b2, three, "0.5");
    const Answer ko = ask(b1), pko = ask(b2);
    if (!ko.ok || !pko.ok) { ok = false; detail += ko.why + pko.why; } else {
      // seat 1 busts seat 0 (head 10): knockout pays 10, progressive 5; the pool afterwards holds 35 against 40; chip share 18/27
      same12("knockout minus progressive, the winner (5 x (1 - 18/27)):", ko.values[0][1] - pko.values[0][1], 5.0 * (1 - 18.0 / 27));
      same12("knockout minus progressive, a bystander (-5 x 9/27):", ko.values[0][2] - pko.values[0][2], -5.0 * 9 / 27);
      // split pot: seats 1 and 2 each get half of the cash; with equal cash the difference of their values is ICM and chip share only
      Answer plain = ask("{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20],\"bounty\":{\"share\":1,\"heads\":[0,10,25]},\"outcomes\":[{\"final\":[0,15,12],\"won\":[6]}]}");
      if (!plain.ok) { ok = false; detail += plain.why; } else { same12("split pot, knockout: seat 1 is worth half of the bounty of 10 more than with no bounty on the busted player:", ko.values[1][1] - plain.values[0][1], 5.0); same12("seat 2 likewise:", ko.values[1][2] - plain.values[0][2], 5.0); } }
    R.check(sec, "M3", "closed forms of the bounty rules: heads-up the winner of everything gets the first prize and both bounties; without a bust a stack is worth ICM plus its chip share of the bounties; a knockout pays the whole bounty where a progressive knockout pays half; a split pot splits the bounty", ok, detail); }
  { const char *q = "{\"seats\":3,\"start\":[1.6,10,10],\"prizes\":[50,30,20]," FG(1, "0,1,2", "bba", 1) ",\"outcomes\":[{\"final\":[0.25,10.675,10.675]},{\"final\":[0,0,21.6],\"won\":[4,4]}]}";
    const Answer a = ask(q); Tournament T; T.start = {1.6, 10, 10}; T.payout = {50, 30, 20}; Tournament::Workspace ws; T.prepare(ws, 1048576.0); bool ok = a.ok; std::string detail = a.why;
    const double fin[2][3] = {{0.25, 10.675, 10.675}, {0, 0, 21.6}};
    for (int o = 0; ok && o < 2; o++) { double c[8] = {fin[o][0], fin[o][1], fin[o][2]}; T.evaluate(c, 3, ws); for (int p = 0; p < 3; p++) { const bool same = std::bit_cast<uint64_t>(c[p]) == std::bit_cast<uint64_t>(a.values[(size_t)o][(size_t)p]); ok = ok && same; if (!same) detail += "outcome " + std::to_string(o) + " seat " + std::to_string(p) + ": " + fmt(a.values[(size_t)o][(size_t)p]) + " instead of " + fmt(c[p]) + "; "; } }
    R.check(sec, "M4", "where the next hand cannot be played (a player would be all-in from posting, or one player is left with all but one busted) the value is the plain ICM of this program, to the bit", ok, ok ? "2 outcomes, 6 values identical to the ICM recursion" : detail); }
  { struct Bad { const char *json, *want; }; const Bad bad[] = {
      {"{\"seats\":4,\"start\":[4,20,15,11],\"prizes\":[50,30,20]," FG(4, "0,1,2,3", "bba", 1) ",\"outcomes\":[]}", "at most 3 hands at this table size"},
      {"{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20]," FG(1, "0,1", "bba", 1) ",\"outcomes\":[]}", "must contain every study seat"},
      {"{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20],\"bounty\":{\"share\":1.5,\"heads\":[10,10,25]},\"outcomes\":[]}", "at most 1"},
      {"{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20],\"bounty\":{\"share\":0.5,\"heads\":[10,10]},\"outcomes\":[]}", "one bounty for every player"},
      {"{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20],\"bounty\":{\"share\":0.5,\"heads\":[0,0,0]},\"outcomes\":[]}", "at least one bounty"},
      {"{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20],\"outcomes\":[]}", "\"bounty\", \"fgs\" or both"},
      {"{\"seats\":3,\"start\":[6,12,9],\"prizes\":[50,30,20]," FG(1, "0,1,1", "bba", 1) ",\"outcomes\":[]}", "a different index"}};
    int refused = 0, n = 0; std::string detail;
    for (const Bad &b : bad) { n++; std::string out, why; const int rc = tq515::answer(b.json, out, why); const bool ok = rc == 1 && why.find(b.want) != std::string::npos; refused += ok; if (!ok) detail += "rc " + std::to_string(rc) + " \"" + why.substr(0, 120) + "\" (expected \"" + b.want + "\"); "; }
    R.check(sec, "M5", "requests refused with the reason: more future-hand solutions than the limit of 2,000 for one outcome, a table without a study seat, a share above 1, a bounty list of the wrong length, no bounty above 0, neither bounties nor future hands, a player listed twice", refused == n, std::to_string(refused) + " of " + std::to_string(n) + " refused" + (detail.empty() ? "" : "; " + detail)); }
}
static std::string headOf(const std::string &path) { const std::vector<unsigned char> raw = slurp(path.c_str()); return std::string(raw.begin(), raw.begin() + std::min<size_t>(raw.size(), 900)); }
struct Case { const char *fixture; int variant; const char *what; };
static const Case CASES[] = {{"pko6-bb-call-small", 0, "progressive knockout"}, {"pko6-bb-call-small", 1, "knockout"}, {"fgs4-bubble-bb-call-small", 0, "two future hands"}, {"fgs4-bubble-bb-call-small", 1, "one future hand"}};
static void trainingSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "training"; std::error_code ec; auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); };
  { int same = 0, total = 0; std::string detail;
    for (const Golden515 &g : GOLDEN515) { total++; std::string why; const Fx f = fixtureOf(studies, work, g.fixture, optionsOf(g.wide, g.batch), "t1", why, g.variant); if (f.path.empty()) { detail += std::string(g.fixture) + ": " + why + "; "; continue; }
      const Trained t = train(self, work, f.path, g.updates, g.batch ? 3 : 1, state("t1"), "", "512", FIXED);
      if (t.ok && t.sha == g.sha) same++; else detail += std::string(g.fixture) + " variant " + std::to_string(g.variant) + (g.wide ? " philox64" : " 5.10 streams") + (g.batch ? " (batch)" : "") + ": " + (t.ok ? "state " + t.sha.substr(0, 16) + " instead of " + std::string(g.sha).substr(0, 16) : "exit " + std::to_string(t.exitCode) + " " + t.err) + "; ";
      fs::remove(f.path, ec); }
    R.check(sec, "T1", "training under tour-5.15-v1: the saved states have the SHA-256 recorded from the Linux build of this release (pko6-bb-call-small as progressive knockout and as knockout, fgs4-bubble-bb-call-small with two and with one future hand; 5.10 streams and philox64; one deal per update and frozen batches of 64 on three threads)", same == total && total > 0, std::to_string(same) + " of " + std::to_string(total) + " states identical" + (detail.empty() ? "" : "; " + detail)); }
  { int good = 0, n = 0; std::string detail;
    for (const Case &c : CASES) for (const bool wide : {false, true}) {
      n++; std::string why; const Fx f = fixtureOf(studies, work, c.fixture, optionsOf(wide, false), "t2", why, c.variant), fb = fixtureOf(studies, work, c.fixture, optionsOf(wide, true), "t2b", why, c.variant);
      if (f.path.empty() || fb.path.empty()) { detail += why + "; "; continue; }
      const Trained a = train(self, work, f.path, 9000, 1, state("t2a")), p = train(self, work, f.path, 3000, 1, state("t2p")), k = p.ok ? train(self, work, f.path, 6000, 1, state("t2c"), state("t2p")) : Trained{};
      const Trained b1 = train(self, work, fb.path, 150, 1, state("t2d"), "", "512", FIXED), b3 = train(self, work, fb.path, 150, 3, state("t2e"), "", "512", FIXED), bp = train(self, work, fb.path, 50, 2, state("t2f"), "", "512", FIXED), bc = bp.ok ? train(self, work, fb.path, 100, 3, state("t2g"), state("t2f"), "512", FIXED) : Trained{};
      const bool ok = a.ok && k.ok && b1.ok && b3.ok && bc.ok && k.sha == a.sha && b1.sha == b3.sha && bc.sha == b1.sha; good += ok;
      if (!ok) detail += std::string(c.what) + (wide ? " philox64" : " 5.10 streams") + ": continued " + (k.sha == a.sha ? "same" : "DIFFERENT") + ", 3 threads " + (b1.sha == b3.sha ? "same" : "DIFFERENT") + ", batch continued " + (bc.sha == b1.sha ? "same" : "DIFFERENT") + " " + a.err + k.err + b1.err + "; ";
      fs::remove(f.path, ec); fs::remove(fb.path, ec); }
    R.check(sec, "T2", "under tour-5.15-v1 a frozen batch gives the same state on 1 and 3 threads, and a training stopped after a third and continued equals the uninterrupted one, byte for byte (the value of an outcome is a function of the outcome alone, whichever thread solves the future hands first); four model variants, 5.10 streams and philox64", good == n && n > 0, std::to_string(good) + " of " + std::to_string(n) + " configurations" + (detail.empty() ? "" : "; " + detail));
    for (const char *t : {"t2a", "t2p", "t2c", "t2d", "t2e", "t2f", "t2g"}) fs::remove(state(t), ec); }
  { int okc = 0, total = 0; std::string detail, why;
    for (const Reference515 &ref : REFERENCE515) { total++; const Fx f = fixtureOf(studies, work, ref.fixture, "", "t3", why, ref.variant); if (f.path.empty()) { detail += why + "; "; continue; }
      const Trained a = train(self, work, f.path, ref.updates, 1, state("t3")); double nc = NAN; if (a.ok) nc = exactNashConv(self, work, f.path, state("t3"), why);
      const bool good = std::isfinite(nc) && std::fabs(nc - ref.nash) <= 1e-9 * std::max({1.0, std::fabs(nc), std::fabs(ref.nash)}); okc += good;
      detail += std::string(ref.fixture) + " variant " + std::to_string(ref.variant) + ": exact NashConv " + sci(nc) + (good ? "" : " (recorded " + sci(ref.nash) + ") " + why + a.err) + "; "; fs::remove(f.path, ec); }
    R.check(sec, "T3", "under tour-5.15-v1 the exact NashConv of the trained strategy after a fixed budget equals the value recorded at release (a regression check of trainer and exact evaluation together; one seed each, no convergence claim)", okc == total && total > 0, std::to_string(okc) + " of " + std::to_string(total) + " reproduce the recorded value; " + detail); fs::remove(state("t3"), ec); }
  { std::string why, detail; bool ok = true;
    for (const Case &c : CASES) { const Fx f = fixtureOf(studies, work, c.fixture, "", "t4", why, c.variant); const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 2000, 1, state("t4")); Doc d(t.out);
      const JV *tm = get(d.v, "tournamentModel"); const bool fg = std::strstr(c.fixture, "fgs") != nullptr; const double solved = num(get(tm, "futureHandsSolved"), -1), hands = num(get(tm, "futureHands"), -1), sh = num(get(tm, "bountyShare"), -1);
      const bool good = t.ok && str(get(d.v, "payoffModel")) == t515::MODEL && str(get(d.v, "payoffKey")).size() == 16 && tm && (fg ? hands == (c.variant ? 1 : 2) && solved > 0 && sh == 0 : hands == 0 && solved == 0 && sh == (c.variant ? 1 : 0.5));
      ok = ok && good; detail += std::string(c.what) + ": " + (good ? "named, " + fmt(solved) + " future hands solved" : "NOT AS EXPECTED " + t.err) + "; "; if (!f.path.empty()) fs::remove(f.path, ec); }
    R.check(sec, "T4", "the trainer reports the payoff model tour-5.15-v1, its 16-digit key, the bounty share, the number of future hands and how many future hands it solved", ok, detail); fs::remove(state("t4"), ec); }
}
// the spec with its "icm" object replaced (the object may hold nested objects)
static std::string withIcm(const std::string &spec, const std::string &icm) {
  const size_t at = spec.find("\"icm\":{"); if (at == std::string::npos) return ""; size_t i = at + 6; int depth = 0;
  for (; i < spec.size(); i++) { if (spec[i] == '{') depth++; else if (spec[i] == '}' && !--depth) break; }
  return i < spec.size() ? spec.substr(0, at) + "\"icm\":" + icm + spec.substr(i + 1) : "";
}
static std::string icmOf(const std::string &spec) {
  const size_t at = spec.find("\"icm\":{"); if (at == std::string::npos) return ""; size_t i = at + 6; int depth = 0;
  for (; i < spec.size(); i++) { if (spec[i] == '{') depth++; else if (spec[i] == '}' && !--depth) break; }
  return i < spec.size() ? spec.substr(at + 6, i - at - 5) : "";
}
static void checkpointSection(Report &R, const std::string &studies, const std::string &work, const std::string &self) {
  const std::string sec = "checkpoint"; std::error_code ec; auto state = [&](const std::string &tag) { return (fs::path(work) / (tag + ".state")).string(); }; std::string why;
  // pko6-bb-call-small: variant 0 progressive, 1 knockout, 2 without bounties; fgs4-bubble-bb-call-small: 0 two hands, 1 one hand
  const Fx pko = fixtureOf(studies, work, "pko6-bb-call-small", "", "c-pko", why, 0), ko = fixtureOf(studies, work, "pko6-bb-call-small", "", "c-ko", why, 1), plain = fixtureOf(studies, work, "pko6-bb-call-small", "", "c-plain", why, 2),
    two = fixtureOf(studies, work, "fgs4-bubble-bb-call-small", "", "c-two", why, 0), one = fixtureOf(studies, work, "fgs4-bubble-bb-call-small", "", "c-one", why, 1);
  if (pko.path.empty() || ko.path.empty() || plain.path.empty() || two.path.empty() || one.path.empty()) { R.add(sec, "C1", "checkpoint rules of the payoff model", "untested", why); return; }
  const Trained tp = train(self, work, pko.path, 2000, 1, state("c-pko")), tn = train(self, work, plain.path, 2000, 1, state("c-plain")), t2 = train(self, work, two.path, 2000, 1, state("c-two"));
  { const std::string hp = headOf(state("c-pko")), hn = headOf(state("c-plain")), h2 = headOf(state("c-two"));
    const bool named = hp.find("\"payoffModel\":\"tour-5.15-v1\",\"payoffKey\":\"") != std::string::npos && h2.find("\"payoffModel\":\"tour-5.15-v1\",\"payoffKey\":\"") != std::string::npos, none = hn.find("payoffModel") == std::string::npos && hn.find("payoffKey") == std::string::npos;
    R.check(sec, "C1", "a state trained under the model names \"payoffModel\":\"tour-5.15-v1\" and a \"payoffKey\" in its header (bounties; future hands); a plain ICM state of the same spot names neither", tp.ok && tn.ok && t2.ok && named && none, std::string(named ? "model states name the model and a key" : "A MODEL STATE DOES NOT NAME THE MODEL") + "; plain ICM state: " + (none ? "no payoff model" : "NAMES ONE") + " " + tp.err + tn.err + t2.err); }
  { struct Try { const std::string *spec; const char *in, *want; }; const Try tries[] = {{&plain.path, "c-pko", "cannot be continued by a study without it"}, {&pko.path, "c-plain", "was not trained under the payoff model tour-5.15-v1"}, {&ko.path, "c-pko", "other bounties or another future-game simulation"}, {&one.path, "c-two", "other bounties or another future-game simulation"}};
    int refused = 0; std::string detail;
    for (const Try &t : tries) { const std::string out = state("c-no"); fs::remove(out, ec); const Trained r = train(self, work, *t.spec, 5, 1, out, state(t.in)); const bool ok = !r.ok && r.exitCode == 1 && r.err.find(t.want) != std::string::npos && !fs::exists(out, ec); refused += ok;
      if (!ok) detail += std::string(t.in) + ": exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 200) + "; "; }
    // and the allowed continuation: the same model continues its own state
    const Trained c = train(self, work, pko.path, 5, 1, state("c-yes"), state("c-pko"));
    R.check(sec, "C2", "refused with the reason, exit 1 and nothing written: a bounty state continued by the plain ICM study, a plain ICM state continued under the model, a progressive-knockout state continued as a knockout, a state of two future hands continued with one; the model continues its own state", refused == 4 && c.ok, "refused " + std::to_string(refused) + " of 4; own state " + (c.ok ? "continued" : "NOT CONTINUED " + c.err) + (detail.empty() ? "" : "; " + detail)); fs::remove(state("c-yes"), ec); fs::remove(state("c-no"), ec); }
  { const std::string icm = icmOf(pko.spec), icm2 = icmOf(two.spec); struct Bad { std::string icm; const char *want; }; std::vector<Bad> bad; auto sub = [](std::string s, const std::string &a, const std::string &b) { const size_t p = s.find(a); if (p != std::string::npos) s.replace(p, a.size(), b); return s; };
    bad.push_back({sub(icm, "\"prizes\"", "\"payouts\""), "takes \"start\", \"others\" and \"prizes\""});
    bad.push_back({sub(icm, "\"tour-5.15\"", "\"tour-9\""), "Unknown icm.model"});
    bad.push_back({sub(icm2, "\"depth\":2", "\"depth\":4"), "at most 3 hands at this table size"});
    bad.push_back({sub(icm2, "\"table\":[3,0,1,2]", "\"table\":[3,0,1]"), "must contain every study seat"});
    bad.push_back({sub(icm, "\"heads\":[", "\"heads\":[1,"), "one bounty for every player"});
    bad.push_back({sub(icm, "\"share\":0.5", "\"share\":0"), "above 0 and at most 1"});
    int refused = 0, n = 0; std::string detail;
    for (const Bad &b : bad) { n++; const std::string text = withIcm(b.icm.find("\"depth\"") != std::string::npos ? two.spec : pko.spec, b.icm), path = (fs::path(work) / "c3.spec.json").string(), out = state("c3"); fs::remove(out, ec); writeText(path, text);
      const Trained r = text.empty() ? Trained{} : train(self, work, path, 5, 1, out); const bool ok = !r.ok && r.exitCode == 1 && r.err.find(b.want) != std::string::npos && !fs::exists(out, ec); refused += ok;
      if (!ok) detail += std::string("expected \"") + b.want + "\": exit " + std::to_string(r.exitCode) + " " + r.err.substr(0, 160) + "; "; fs::remove(path, ec); }
    R.check(sec, "C3", "specs refused before anything is trained, with the reason, exit 1 and nothing written: the prizes under \"payouts\" (the key the programs before 5.13 read), an unknown model name, four future hands at a table of four, a table that leaves out a study seat, one bounty too many, a bounty share of 0", refused == n, std::to_string(refused) + " of " + std::to_string(n) + " refused" + (detail.empty() ? "" : "; " + detail)); }
  for (const Fx *f : {&pko, &ko, &plain, &two, &one}) fs::remove(f->path, ec);
  for (const char *t : {"c-pko", "c-plain", "c-two"}) fs::remove(state(t), ec);
}
static int record(const std::string &studies, const std::string &work, const std::string &self) {
  std::error_code ec; std::string values, golden, reference, why; int bad = 0, count = 0; auto p = [&](const char *n) { return (fs::path(work) / n).string(); };
  for (const Req &q : REQUESTS) { const Answer a = ask(q.json); bad += !a.ok; if (!a.ok) why += std::string(q.name) + ": " + a.why + "; "; for (const std::string &b : a.bits) { values += "\"" + b + "\",\n"; count++; } }
  for (const Case &c : CASES) for (const bool wide : {false, true}) for (const bool batch : {false, true}) {
    const Fx f = fixtureOf(studies, work, c.fixture, optionsOf(wide, batch), "record", why, c.variant); const long long updates = batch ? 150 : 9000;
    const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, updates, batch ? 3 : 1, p("record.state"), "", "512", FIXED); bad += !t.ok; count++;
    golden += std::string("{\"") + c.fixture + "\", " + std::to_string(c.variant) + ", " + std::to_string(updates) + ", " + (batch ? "true" : "false") + ", " + (wide ? "true" : "false") + ", \"" + (t.ok ? t.sha : "FAILED") + "\"},\n"; if (!f.path.empty()) fs::remove(f.path, ec); }
  for (const Case &c : CASES) {
    const Fx f = fixtureOf(studies, work, c.fixture, "", "record", why, c.variant); const Trained t = f.path.empty() ? Trained{} : train(self, work, f.path, 20000, 1, p("record.state")); const double nc = t.ok ? exactNashConv(self, work, f.path, p("record.state"), why) : NAN; bad += !std::isfinite(nc); count++;
    reference += std::string("{\"") + c.fixture + "\", " + std::to_string(c.variant) + ", 20000, " + fmt(nc) + "},\n"; if (!f.path.empty()) fs::remove(f.path, ec); }
  fs::remove(p("record.state"), ec);
  writeText(p("selftest515_values.hpp"), values); writeText(p("selftest515_golden.hpp"), golden); writeText(p("selftest515_reference.hpp"), reference);
  std::printf("{\"recorded\":%d,\"failed\":%d%s}\n", count, bad, why.empty() ? "" : (",\"note\":" + mwa::jsonEsc(why)).c_str()); return bad ? 1 : 0;
}
static int run(int argc, char **argv) {
  if (argc < 4 || argc > 5) { std::fprintf(stderr, "usage: mwcli --selftest515 studies-dir work-dir [all|model|training|checkpoint]\n"); return 2; }
  const std::string studies = argv[2], work = argv[3], section = argc > 4 ? argv[4] : "all"; std::error_code ec; fs::create_directories(work, ec); mw_study_identity(EM_VERSION, EM_BUILD_ID);
  if (section == "record") return record(fs::absolute(studies, ec).string(), fs::absolute(work, ec).string(), ckpt::selfPath(argv[0]));
  if (section != "all" && section != "model" && section != "training" && section != "checkpoint") { std::fprintf(stderr, "error: the section must be all, model, training or checkpoint\n"); return 2; }
  if (!fs::is_directory(studies, ec) || !fs::is_directory(work, ec)) { std::fprintf(stderr, "error: studies-dir and work-dir must be directories\n"); return 2; }
  Report R; const auto t0 = std::chrono::steady_clock::now(); const std::string S = fs::absolute(studies, ec).string(), W = fs::absolute(work, ec).string(), self = ckpt::selfPath(argv[0]);
  if (section == "all" || section == "model") modelSection(R);
  if (section == "all" || section == "training") trainingSection(R, S, W, self);
  if (section == "all" || section == "checkpoint") checkpointSection(R, S, W, self);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::string o = std::string("{\"tool\":\"mwcli selftest515\",\"version\":\"") + EM_VERSION + "\",\"build\":\"" + EM_BUILD_ID + "\",\"section\":\"" + section + "\",\"payoffModel\":\"" + t515::MODEL + "\",\"passed\":" + std::to_string(R.passed) + ",\"failed\":" + std::to_string(R.failed) + ",\"untested\":" + std::to_string(R.untested) + ",\"seconds\":" + fmt(secs) + ",\"checks\":[";
  for (size_t i = 0; i < R.checks.size(); i++) { const st58::Check &c = R.checks[i]; o += std::string(i ? "," : "") + "{\"section\":" + mwa::jsonEsc(c.section) + ",\"id\":" + mwa::jsonEsc(c.id) + ",\"name\":" + mwa::jsonEsc(c.name) + ",\"status\":" + mwa::jsonEsc(c.status) + ",\"detail\":" + mwa::jsonEsc(c.detail) + "}"; }
  o += "]}"; const std::string report = (fs::path(work) / "selftest515.json").string();
  { FILE *f = std::fopen(report.c_str(), "wb"); if (f) { std::fwrite(o.data(), 1, o.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest515\",\"build\":\"%s\",\"section\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"report\":%s}\n", EM_BUILD_ID, section.c_str(), R.passed, R.failed, R.untested, mwa::jsonEsc(report).c_str());
  return R.failed || R.untested ? 1 : 0;
}
}
