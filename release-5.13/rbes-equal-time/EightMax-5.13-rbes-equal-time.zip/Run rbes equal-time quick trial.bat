@echo off
cd /d "%~dp0"
echo EightMax 5.13: a two-minute trial of the equal-time tool (not a result).
eqtime513.exe run --quick %*
echo.
echo Exit status: %ERRORLEVEL%
pause
