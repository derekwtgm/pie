@echo off
cd /d "%~dp0"
echo EightMax 5.13: rbes against the default trainer at equal training time.
echo This takes about one and a half to two hours. Close other heavy programs and leave the PC alone.
echo It can be interrupted: start it again and it continues.
echo.
eqtime513.exe run %*
echo.
echo Exit status: %ERRORLEVEL%
echo Send back the folder rbes-equal-time-results (summary.txt, summary.json, raw.jsonl, plan.json, machine.txt).
pause
