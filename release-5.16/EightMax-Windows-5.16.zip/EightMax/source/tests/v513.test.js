'use strict';
// EightMax 5.13 regression tests (Phase 3: satellites).
//   A satellite with at most 16 players is the ordinary ICM with equal prizes ("satellite N" in a payout field). For
//   larger fields 5.13 adds a payoff model, satfield-5.13-v1 (native/satfield513.hpp, mirrored in web/lib_icm.js):
//   the Malmuth-Harville probability of finishing in the top N of the whole field. Tested here:
//     - the JavaScript mirror against the native program, bit for bit, and against the exact recursion;
//     - the independent Python implementation (exact rational brute force, another quadrature, Monte Carlo), short form;
//     - the payout shorthand and the field text; the multiway form state and the native specification;
//     - the engine: what it refuses, the header of a satellite-field state, the unchanged 5.12 program (it refuses a
//       satellite-field spec and trains the ordinary-ICM satellite fixtures to the same bytes);
//     - six fixtures; two closed forms computed here independently (an ICM written out; all-in equity by enumeration
//       with the JavaScript evaluator);
//     - mwcli --selftest513; the Windows validation script of 5.13, its launchers and reference files.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
const build = require('./native_build');
const src = path.resolve(__dirname, '..'), root = path.resolve(src, '..'), studies = path.join(src, 'studies');
const E = require('../tools/loadlib.js'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river', 'lib_river_ui']) require('../web/' + l);
const cli = () => process.env.EM_TEST_MWCLI || build.cli().cli;
const tmp = t => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em513-')); t.after(() => fs.rmSync(d, { recursive: true, force: true })); return d; };
const run = (args, env = {}, exe = null) => cp.spawnSync(exe || cli(), args.map(String), { encoding: 'utf8', timeout: 1800000, maxBuffer: 256 << 20, env: { ...process.env, ...env } });
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const bits = x => { const b = Buffer.alloc(8); b.writeDoubleBE(x); return b.toString('hex'); };
const SAT = ['known-sat-akq-river', 'sat3-fold-aces', 'sat5-bubble-bb-call', 'sat5-bubble-bb-call-small', 'satfield-bb-call', 'satfield-bb-call-small'];
const IDS = ['model M1', 'model M2', 'model M3', 'model M4', 'model M5', 'fixtures F1', 'fixtures F2', 'training T1', 'training T2', 'training T3', 'closed K1', 'closed K2', 'closed K3', 'checkpoint C1'];
const fixture = id => JSON.parse(fs.readFileSync(path.join(studies, id + '.emfix.json'), 'utf8'));
const satfield = (dir, q) => { const f = path.join(dir, 'q.json'); fs.writeFileSync(f, JSON.stringify(q)); const r = run(['--satfield', f]); assert.equal(r.status, 0, r.stderr); return JSON.parse(r.stdout); };
// an ICM written out for this file: probability of finishing in the top `seats`, by recursion over who finishes next
function topN(stacks, seats, i) { const live = stacks.map((s, k) => k).filter(k => stacks[k] > 0); if (!(stacks[i] > 0)) return 0; if (live.length <= seats) return 1;
  const go = (left, k) => { if (k === 0) return 0; const total = left.reduce((a, j) => a + stacks[j], 0); let p = 0; for (const j of left) { const q = stacks[j] / total; p += j === i ? q : q * go(left.filter(x => x !== j), k - 1); } return p; }; return go(live, seats); }

test('5.13 payoff model: the JavaScript mirror prints the bits of the native program (small, large and extreme fields), and both agree with the exact recursion for small fields', t => {
  const dir = tmp(t); let s = 513; const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
  const cases = [{ seats: 3, table: [10, 20], field: [[15, 4]] }, { seats: 40, table: [39.9, 12, 18], field: [[8, 24], [18, 38], [30, 34], [52, 22], [21.9, 1], [8.9, 1], [30.9, 1]] }, { seats: 500, table: [3, 14, 25, 61, 120, 0.5, 44, 75], field: [[4, 500], [12, 500], [25, 500], [70, 500]] }, { seats: 1, table: [0.3, 900], field: [[25, 50]] }, { seats: 57, table: [1, 12, 0], field: [[0.5, 3], [20, 56], [400, 1]] }];
  for (let k = 0; k < 25; k++) { const n = 1 + Math.floor(rnd() * 6), K = 2 + Math.floor(rnd() * 9), seats = 1 + Math.floor(rnd() * (K - 1)); cases.push({ seats, table: Array.from({ length: n }, () => +(0.3 + 90 * rnd() * rnd()).toFixed(2)), field: Array.from({ length: K }, () => [+(0.5 + 120 * rnd() * rnd()).toFixed(2), 1]) }); }
  let worst = 0;
  for (const c of cases) {
    const native = satfield(dir, c), F = E.satelliteField(c.seats, c.field), js = Array.from(F.evaluate(c.table));
    assert.deepEqual(js.map(bits), native.bits, JSON.stringify(c).slice(0, 120)); assert.equal(native.model, 'satfield-5.13-v1'); assert.equal(native.nodes, F.nodes); assert.equal(bits(native.tau), bits(F.tau));
    const all = c.table.concat(c.field.flatMap(g => Array(g[1]).fill(g[0])));
    if (all.length <= 11) c.table.forEach((x, i) => { const e = Math.abs(js[i] - topN(all, c.seats, i)); worst = Math.max(worst, e); assert.ok(e < 1e-9, 'exact ' + topN(all, c.seats, i) + ' model ' + js[i]); });
    if (all.length <= 16 && c.table.every(x => x > 0)) { const ex = E.icmRawReference(all, Array(c.seats).fill(1)); c.table.forEach((x, i) => assert.ok(Math.abs(js[i] - ex[i]) < 1e-9)); }
  }
  assert.ok(worst < 1e-12, 'largest difference from the written-out ICM: ' + worst);
  assert.equal(E.satExp(0), 1); assert.equal(E.satExp(-701), 0); for (const x of [-1e-9, -0.5, -1, -37.25, -699.9]) assert.ok(Math.abs(E.satExp(x) - Math.exp(x)) <= 1e-15 * Math.exp(x), 'satExp(' + x + ')');
});
test('5.13 payoff model: what is refused, in the program and in the mirror; a seat without chips is worth 0; values lie in [0, 1] and grow with the stack', t => {
  const dir = tmp(t), f = path.join(dir, 'q.json');
  for (const [q, want] of [[{ seats: 0, table: [10], field: [[25, 9]] }, /seats must be/i], [{ seats: 9, table: [10], field: [[25, 9]] }, /more players than there are seats/], [{ seats: 3, table: [10], field: [] }, /1 to 5000/], [{ seats: 3, table: [10], field: [[25, 6000]] }, /1 to 5000/], [{ seats: 1900, table: [10], field: [[25, 4000]] }, /must not exceed/], [{ seats: 3, table: [10], field: [[-5, 9]] }, /positive stack/]]) {
    fs.writeFileSync(f, JSON.stringify(q)); const r = run(['--satfield', f]); assert.equal(r.status, 1, JSON.stringify(q)); assert.match(r.stderr, want); assert.throws(() => E.satelliteField(q.seats, q.field), want);
  }
  const F = E.satelliteField(40, [[25, 121]]); const v = Array.from(F.evaluate([0, 1, 5, 25, 60, 200, 2000])); assert.equal(v[0], 0); for (let i = 1; i < v.length; i++) assert.ok(v[i] > v[i - 1] && v[i] <= 1, v.join(' '));
  assert.ok(v[6] > 0.999999 && v[1] < 0.03);
});
test('5.13 payout shorthand and field text: "satellite 4" and "4 seats" are four equal prizes; "120x25, 30x60, 14" is a field; anything else is as before', () => {
  assert.deepEqual(E.parsePayouts('satellite 4'), [1, 1, 1, 1]); assert.deepEqual(E.parsePayouts(' 3 seats '), [1, 1, 1]); assert.deepEqual(E.parsePayouts('SAT:2'), [1, 1]); assert.deepEqual(E.parsePayouts('seats = 5'), [1, 1, 1, 1, 1]);
  assert.deepEqual(E.parsePayouts('50, 30, 20'), [50, 30, 20]); assert.deepEqual(E.parsePayouts('30 20 14'), E.parseNumberList('30 20 14')); assert.throws(() => E.parsePayouts('satellite 40'), /larger fields/); assert.throws(() => E.parsePayouts('satellite 0'));
  assert.deepEqual(E.parseField('120x25, 30x60, 14'), [[25, 120], [60, 30], [14, 1]]); assert.deepEqual(E.parseField('82 x 25'.replace(/ /g, '')), [[25, 82]]); assert.deepEqual(E.parseField('3×7.5'), [[7.5, 3]]); assert.throws(() => E.parseField('abc'), /not "count x stack"/); assert.throws(() => E.parseField('0x25'));
  // with equal prizes the ordinary ICM is the satellite: the value is the probability of a seat
  const eq = E.icmRaw([30, 9, 16, 22, 14], E.parsePayouts('satellite 4')); assert.ok(Math.abs(eq.reduce((a, b) => a + b, 0) - 4) < 1e-12); [30, 9, 16, 22, 14].forEach((s, i) => assert.ok(Math.abs(eq[i] - topN([30, 9, 16, 22, 14], 4, i)) < 1e-12));
});
test('5.13 multiway form: "Satellite, large field" becomes icm {model, seats, field}; the JavaScript game evaluates it and writes the native specification without a payout table; "satellite N" in the payouts of Tournament ICM is equal prizes', () => {
  const spot = { ...E.multiwayExample(3, 'Preflop', 6), study: 'shove', payoff: 'satfield', satSeats: '40', satField: '24x8, 38x18, 34x30, 22x52, 21.9, 8.9, 30.9', others: '', privateMode: 'sampled', traversal: 'external', engine: 'native', abstraction: 'compact' };
  const cfg = E.multiwaySpotConfig(spot); assert.deepEqual(cfg.icm, { model: 'satellite-field', seats: 40, field: [[8, 24], [18, 38], [30, 34], [52, 22], [21.9, 1], [8.9, 1], [30.9, 1]] });
  const g = E.MultiwayGame({ ...cfg, engine: 'native' }); assert.equal(g.nativeSupport(), null); const spec = g.nativeSpec();
  assert.equal(spec.icm.model, 'satellite-field'); assert.equal(spec.icm.seats, 40); assert.equal(spec.icm.start.length, 3); assert.equal(spec.icm.payouts, undefined); assert.equal(spec.icm.others, undefined); assert.equal(spec.icm.field.reduce((a, x) => a + x[1], 0), 121);
  const ord = E.multiwaySpotConfig({ ...spot, payoff: 'icm', payouts: 'satellite 4', others: '21.9,13.9' }); assert.deepEqual(ord.icm.payouts, [1, 1, 1, 1]);
  assert.deepEqual(E.multiwaySpotConfig({ ...spot, payoff: 'icm', payouts: '50,30,20', others: '21.9,13.9,30' }).icm.payouts, [50, 30, 20]);
  assert.throws(() => E.MultiwayGame({ ...cfg, icm: { ...cfg.icm, model: 'nonsense' } }), /Unknown ICM model/); assert.throws(() => E.MultiwayGame({ ...cfg, icm: { ...cfg.icm, payouts: [1] } }), /not payouts/);
});
test('5.13 independent implementation (short form): exact rational brute force, another quadrature with the library exponential, and sampled finishing orders agree with the program (tools/independent_satfield513.py)', { timeout: 1800000 }, t => {
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import numpy, sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (!py) { t.skip('needs Python 3.8+ with numpy'); return; }
  const dir = tmp(t), out = path.join(dir, 'check.json'), r = cp.spawnSync(py, [path.join(src, 'tools/independent_satfield513.py'), 'check', cli(), out], { encoding: 'utf8', timeout: 1700000, env: { ...process.env, SATFIELD_QUICK: '1' } });
  assert.equal(r.status, 0, r.stdout.slice(-600) + r.stderr.slice(-600)); const d = JSON.parse(fs.readFileSync(out, 'utf8'));
  assert.ok(d.A.passed && d.A.cases === 40 && d.A.largestDifference <= 1e-9); assert.ok(d.C.passed && d.C.largestDifference <= 1e-8 && d.C.largestSumError <= 1e-7); assert.ok(d.monteCarlo.passed);
});
test('5.13 engine: a satellite-field spec trains, names its payoff model in the information and in the state header, is refused in every malformed form, and is refused by the unchanged 5.12 program; the ordinary-ICM satellite fixtures train to the same bytes in 5.12 and 5.13', { timeout: 1800000 }, t => {
  const dir = tmp(t), spec = fixture('satfield-bb-call-small').variants[0].nativeSpec, sf = path.join(dir, 's.json'), st = path.join(dir, 's.state'); fs.writeFileSync(sf, JSON.stringify(spec));
  const r = run([sf, 2000, 1, st, 256]); assert.equal(r.status, 0, r.stderr); const info = JSON.parse(r.stdout); assert.equal(info.payoffModel, 'satfield-5.13-v1'); assert.deepEqual([info.satellite.seats, info.satellite.fieldPlayers], [40, 121]); assert.ok(info.satellite.quadratureNodes > 500);
  const b = fs.readFileSync(st), head = JSON.parse(b.subarray(12, 12 + b.readUInt32LE(8)).toString('utf8')); assert.equal(head.payoffModel, 'satfield-5.13-v1'); assert.equal(head.satelliteSeats, 40); assert.equal(head.satelliteFieldPlayers, 121); assert.notEqual(head.studyId, spec.studyId, 'a derived study identifier');
  const bad = (change, want) => { const s = JSON.parse(JSON.stringify(spec)); change(s); const f = path.join(dir, 'bad.json'), o = path.join(dir, 'bad.state'); fs.writeFileSync(f, JSON.stringify(s)); const x = run([f, 10, 1, o, 256]); assert.notEqual(x.status, 0); assert.match(x.stderr, want); assert.ok(!fs.existsSync(o)); };
  bad(s => { s.icm.model = 'something'; }, /Unknown icm.model/); bad(s => { s.icm.payouts = [1]; }, /not "payouts" or "others"/); bad(s => { s.icm.seats = 121; }, /more players than there are seats/); bad(s => { s.icm.seats = 2.5; }, /whole number/);
  bad(s => { s.icm.field = []; }, /list of \[stack, count\] groups/); bad(s => { s.icm.field[0] = [8, 0]; }, /every group is/); bad(s => { s.icm.start = [40, 12]; }, /hand-start stack of every seat/);
  // another payoff model, seats or field: refused for the header, nothing written
  for (const [change, want] of [[s => { s.icm.seats = 39; }, /another satellite/], [s => { s.icm.field[0][1] = 23; }, /another satellite/]]) { const s = JSON.parse(JSON.stringify(spec)); change(s); const f = path.join(dir, 'o.json'), o = path.join(dir, 'o.state'); fs.writeFileSync(f, JSON.stringify(s)); const x = run([f, 10, 1, o, 256, st]); assert.equal(x.status, 1); assert.match(x.stderr, want); assert.ok(!fs.existsSync(o)); }
  const old = process.env.EM_TEST_MWCLI_512 || path.join(root, 'validation/5.12/linux-bin/mwcli');
  if (process.platform !== 'linux' || !fs.existsSync(old)) { t.diagnostic('the 5.12 Linux mwcli is not in this tree: the comparison with 5.12 was not made'); return; }
  const exe = path.join(dir, 'mwcli512'); fs.copyFileSync(old, exe); fs.chmodSync(exe, 0o755); assert.equal(cp.spawnSync(exe, ['--build-id'], { encoding: 'utf8' }).stdout.trim(), 'EightMaxBuild=913dc2280e5088ae');
  const x = run([sf, 10, 1, path.join(dir, 'old.state'), 256], {}, exe); assert.notEqual(x.status, 0); assert.match(x.stderr, /Invalid ICM configuration/); assert.ok(!fs.existsSync(path.join(dir, 'old.state')));
  for (const id of ['sat5-bubble-bb-call-small', 'known-sat-akq-river', 'sat3-fold-aces', 'sat5-bubble-bb-call']) for (const wide of [false, true]) {
    const s = { ...fixture(id).variants[0].nativeSpec, ...(wide ? { trainingStreams: 'philox64' } : {}) }, f = path.join(dir, 'p.json'); fs.writeFileSync(f, JSON.stringify(s)); const n = /small|known|sat3/.test(id) ? 4000 : 600;
    const a = run([f, n, 1, path.join(dir, 'a.state'), 512]), c = run([f, n, 1, path.join(dir, 'b.state'), 512], {}, exe); assert.equal(a.status, 0, a.stderr); assert.equal(c.status, 0, c.stderr); assert.equal(sha(path.join(dir, 'a.state')), sha(path.join(dir, 'b.state')), id + (wide ? ' philox64' : ''));
  }
});
test('5.13 fixtures: six satellite fixtures with their tables, units and payoff models; the two large-field fixtures carry the satellite-field model in every non-chip variant', () => {
  const files = fs.readdirSync(studies).filter(f => f.endsWith('.emfix.json')).map(f => f.replace('.emfix.json', '')).filter(id => /^(sat|known-sat)/.test(id)).sort(); assert.deepEqual(files, SAT);
  assert.equal(fs.readdirSync(studies).filter(f => f.endsWith('.emfix.json')).length, 26);   // 5.15: four fixtures for bounties and future hands joined the 22 of 5.13
  for (const id of SAT) { const f = fixture(id); assert.equal(f.id, id); for (const v of f.variants) { const icm = v.nativeSpec.icm; assert.ok(v.decision.actions.length === 2);
      if (v.name === 'chip-ev') { assert.equal(icm, undefined); assert.equal(v.utility.model, 'chip'); continue; }
      if (id.startsWith('satfield')) { assert.equal(icm.model, 'satellite-field'); assert.equal(icm.payouts, undefined); assert.equal(icm.start.length, 3); assert.equal(icm.field.reduce((a, g) => a + g[1], 0), 121); assert.equal(v.utility.model, 'satellite-field'); assert.equal(icm.seats, v.name === 'fewer-seats' ? 30 : 40); }
      else { assert.equal(icm.model, undefined); if (v.name !== 'regular-prizes') { assert.ok(icm.payouts.every(x => x === 1)); assert.match(v.utility.unit, /seat/); } else assert.deepEqual(icm.payouts, [40, 27, 18, 15]); } } }
  assert.deepEqual(fixture('sat5-bubble-bb-call').table.players, 5); assert.equal(fixture('sat5-bubble-bb-call').variants[0].nativeSpec.icm.payouts.length, 4); assert.equal(fixture('satfield-bb-call').table.players, 6);
  assert.deepEqual(fixture('satfield-bb-call').variants[1].nativeSpec.icm.field, [[25.63, 121]]);
  // the average-only field holds the chips of the listed field
  const chips = g => g.reduce((a, x) => a + x[0] * x[1], 0); assert.ok(Math.abs(chips(fixture('satfield-bb-call').variants[0].nativeSpec.icm.field) - chips([[25.63, 121]])) < 1);
});
test('5.13 closed form, a mixed river spot with satellite values: folding is worth F exactly; the kings call with the closed-form frequency; with equal weights the game would not mix at all', { timeout: 1800000 }, t => {
  const dir = tmp(t), f = fixture('known-sat-akq-river'), v = f.variants[0], sf = path.join(dir, 's.json'), st = path.join(dir, 's.state'), q = path.join(dir, 'q.json'); fs.writeFileSync(sf, JSON.stringify(v.nativeSpec));
  const F = topN([10, 20, 12], 2, 0), B = topN([20, 10, 12], 2, 0), W = topN([30, 0, 12], 2, 0), c = 1 - F / B, bluff = F / (4 * (1 - F));
  assert.equal(W, 1); assert.ok(bluff > 0 && bluff < 1 && c > 0 && c < 1); assert.ok(0.5 * W < F, 'with aces and queens equally likely a caller who always faces a bet wins half the time: 0.5 < F, so kings always fold');
  assert.equal(run([sf, 2000000, 1, st, 64]).status, 0); fs.writeFileSync(q, JSON.stringify({ path: v.decision.path, board: [], hands: [v.decision.handIndex], method: 'exact', policy: 'average' }));
  const r = run(['--ev', sf, st, q, 64]); assert.equal(r.status, 0, r.stderr); const h = JSON.parse(r.stdout).hands[0];
  assert.ok(Math.abs(h.ev[0] - F) < 1e-12, 'fold ' + h.ev[0] + ' against ' + F); assert.ok(Math.abs(h.strategy[1] - c) < 0.02, 'call frequency ' + h.strategy[1] + ' against ' + c); assert.ok(Math.abs(h.ev[1] - F) < 0.005);
  // the bettor: queens bet with the closed-form frequency, aces always
  fs.writeFileSync(q, JSON.stringify({ path: [], board: [], limit: 10 })); const n = JSON.parse(run(['--node', sf, st, q, 64]).stdout), bet = n.actions.findIndex(a => /Bet|All-in/.test(a.name));
  const hand = rank => n.hands.items.find(x => (x.cards[0] >> 2) === rank);   // 12 = ace, 10 = queen
  assert.ok(Math.abs(hand(10).average[bet] - bluff) < 0.03, 'queens bet ' + hand(10).average[bet] + ' against ' + bluff); assert.ok(hand(12).average[bet] > 0.97, 'aces bet ' + hand(12).average[bet]);
});
test('5.13 closed form, folding aces on the bubble: both action values against an ICM written out here and an all-in equity enumerated with the JavaScript evaluator; folding is worth more', { timeout: 1800000 }, t => {
  const dir = tmp(t), f = fixture('sat3-fold-aces'), v = f.variants[0], sf = path.join(dir, 's.json'), st = path.join(dir, 's.state'), q = path.join(dir, 'q.json'); fs.writeFileSync(sf, JSON.stringify(v.nativeSpec));
  assert.equal(run([sf, 100, 1, st, 64]).status, 0); fs.writeFileSync(q, JSON.stringify({ path: v.decision.path, board: [], hands: [v.decision.handIndex], method: 'exact', policy: 'average' }));
  const h = JSON.parse(run(['--ev', sf, st, q, 64]).stdout).hands[0];
  // AsAh against KdKc over all 1,712,304 boards
  const card = s => E.parseBoard(s)[0], hero = [card('As'), card('Ah')], vill = [card('Kd'), card('Kc')], dead = new Set([...hero, ...vill]), deck = []; for (let c = 0; c < 52; c++) if (!dead.has(c)) deck.push(c);
  let win = 0, tie = 0, total = 0;
  for (let a = 0; a < 48; a++) for (let b = a + 1; b < 48; b++) for (let c = b + 1; c < 48; c++) for (let d = c + 1; d < 48; d++) for (let e = d + 1; e < 48; e++) {
    const board = [deck[a], deck[b], deck[c], deck[d], deck[e]], x = E.evalCards([...hero, ...board]), y = E.evalCards([...vill, ...board]); total++; if (x > y) win++; else if (x === y) tie++; }
  assert.equal(total, 1712304); const pw = win / total, pt = tie / total;
  // chips: 57 BB in play. Fold: BB 23.9, SB 31.2, BTN 1.9. Call and win: SB keeps the 5 BB the big blind does not cover. Tie: the pot is split and the button's ante goes with it.
  const fold = topN([23.9, 31.2, 1.9], 2, 0), winV = topN([50.1, 5, 1.9], 2, 0), tieV = topN([25.05, 30.05, 1.9], 2, 0), call = pw * winV + pt * tieV;
  assert.ok(Math.abs(h.ev[0] - fold) < 1e-12, 'fold ' + h.ev[0] + ' against ' + fold); assert.ok(Math.abs(h.ev[1] - call) < 1e-9, 'call ' + h.ev[1] + ' against ' + call + ' (aces win ' + pw + ', tie ' + pt + ')');
  assert.ok(pw > 0.8 && fold > call + 0.1, 'aces win ' + pw + ' of the time and folding is still worth ' + (fold - call) + ' more');
});
test('5.13 self-test: mwcli --selftest513 passes every check under five sections; a section alone; usage errors; without fixtures nothing that needs them passes', { timeout: 1800000 }, t => {
  const dir = tmp(t), r = run(['--selftest513', studies, dir, 'all']); const doc = JSON.parse(fs.readFileSync(path.join(dir, 'selftest513.json'), 'utf8'));
  assert.equal(r.status, 0, r.stdout + r.stderr); assert.equal(doc.payoffModel, 'satfield-5.13-v1'); assert.deepEqual(doc.checks.map(c => c.section + ' ' + c.id), IDS); assert.ok(doc.checks.every(c => c.status === 'passed')); assert.equal(doc.passed, 14);
  const m = run(['--selftest513', studies, path.join(dir, 'm'), 'model']); assert.equal(m.status, 0); assert.equal(JSON.parse(fs.readFileSync(path.join(dir, 'm/selftest513.json'), 'utf8')).passed, 5);
  assert.equal(run(['--selftest513', studies, dir, 'nonsense']).status, 2); assert.equal(run(['--selftest513']).status, 2);
  const empty = path.join(dir, 'empty'); fs.mkdirSync(empty); const e = run(['--selftest513', empty, path.join(dir, 'w'), 'all']); assert.equal(e.status, 1);
  const d2 = JSON.parse(fs.readFileSync(path.join(dir, 'w/selftest513.json'), 'utf8')); assert.equal(d2.passed, 5, 'only the five model checks need no fixture'); assert.equal(d2.failed + d2.untested, 9);
});
test('5.13 Windows validation: the script keeps every section of the 5.12 script, plans and imports every 5.13 check, the launchers run the self-tests first, the reference files are complete', () => {
  const file = path.join(src, 'tools/validate_windows513.ps1'), ps = fs.readFileSync(file, 'utf8'), version = fs.readFileSync(path.join(src, 'VERSION'), 'utf8').trim();
  assert.ok(['5.13', '5.14', '5.15', '5.16'].includes(version), version); assert.match(ps, /\$Release = '5\.13'/);   // 5.14: the 5.13 script is kept as it ran; validate_windows514.ps1 is the current one
  // the manifest floor: 5.12 kept 3,000 entries while its archive had 1,949, and its check failed with every file matching
  assert.ok(ps.includes("($bad.Count -eq 0 -and $count -gt 1000)") && !ps.includes('$count -gt 3000'), 'the manifest check accepts an archive of about 2,000 files'); assert.match(ps, /tool = 'validate_windows513\.ps1'/); assert.ok(!/[^\x00-\x7f]/.test(ps), 'the script is ASCII');
  for (const s of ["Run-Section 'self-test 5.13'", "Run-Section 'satellite 5.13'", "Run-Section 'self-test 5.12'", "Run-Section 'table 5.12'", "Run-Section 'streams 5.11'", "Run-Section 'GPU'", "'--selftest513', $studies, $dir, 'all'", 'validation\\5.13\\windows\\satellite', "'--satfield'"]) assert.ok(ps.includes(s), s);
  for (const id of IDS) assert.ok(ps.includes("'" + id + "'"), 'expected check ' + id);
  const plans = [...ps.matchAll(/^Plan '([^']+)' '([^']+)' '([^']+)'/gm)];
  for (const name of ['mwcli --selftest513 ran and wrote its report', 'every expected 5.13 check is in the report', 'the 5.13 report agrees with the exit status of mwcli', 'mwcli --satfield prints the bits of the Linux build', 'the interface file carries the satellite card and the satellite fixtures', 'identical satellite state for every thread count', 'satellite state equals the Linux build', 'satellite: every processing mode writes the same state', 'satellite processing modes and times on this PC', '6-max state equals the Linux build']) {
    assert.equal(plans.filter(p => p[2] === name).length, 1, 'planned once: ' + name); const sec = plans.find(p => p[2] === name)[1]; assert.ok(ps.includes("Check '" + sec + "' '" + name + "'") || ps.includes("Add-Check '" + sec + "' '" + name + "'"), 'planned but never recorded: ' + name); }
  const focus = /\$focusSections = @\(([^)]*)\)/.exec(ps)[1]; for (const s of ["'self-test 5.13'", "'satellite 5.13'", "'self-test 5.12'", "'table 5.12'", "'self-test 5.11'", "'streams 5.11'", "'golden states'", "'integrity'"]) assert.ok(focus.includes(s), 'focused: ' + s);
  const sections = text => [...text.matchAll(/^Run-Section '([^']+)'/gm)].map(m => m[1]), before = sections(fs.readFileSync(path.join(src, 'tools/validate_windows512.ps1'), 'utf8')), now = sections(ps);
  assert.deepEqual(now.filter(s => before.includes(s)), before); assert.deepEqual(now.filter(s => !before.includes(s)), ['self-test 5.13', 'satellite 5.13']);
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (py) { const r = cp.spawnSync(py, [path.join(src, 'tools/ps_lint571.py'), file], { encoding: 'utf8' }); assert.equal(r.status, 0, r.stdout + r.stderr); }
  for (const [name, needs] of [['Run 5.13 Windows validation.bat', ['mwcli.exe --selftest57 ', 'mwcli.exe --selftest511 ', 'mwcli.exe --selftest512 ', 'mwcli.exe --selftest513 ', 'validate_windows513.ps1" %*', 'Windows-selftest513-5.13.json', 'Windows-validation-5.13.json', 'Step 9 of 9', 'if not "%selftest513_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"']],
    ['Run 5.13 focused validation.bat', ['mwcli.exe --selftest513 ', 'validate_windows513.ps1" -Focused %*', 'Windows-focused-validation-5.13.json', 'Windows-selftest513-5.13.json']]]) {
    const f = path.join(root, name); if (!fs.existsSync(f)) continue;
    const text = fs.readFileSync(f).toString('latin1'); assert.ok(!/[^\x00-\x7f]/.test(text), name + ' is ASCII'); assert.ok(!/[^\r]\n/.test(text), name + ' has CRLF line ends'); for (const n of needs) assert.ok(text.includes(n), name + ': ' + n); assert.match(text, /exit \/b %\w+%\r\n$/);
    assert.match(text, /if not exist "Windows-(focused-)?validation-5\.13\.json" if "%eightmax_result%"=="0" set "eightmax_result=2"/); assert.ok(!text.includes('-5.12.json') && !text.includes('validate_windows512'), name + ' writes 5.13 reports only');
  }
  const dir = path.join(root, 'validation/5.13/windows/satellite');
  if (fs.existsSync(dir)) { const ref = JSON.parse(fs.readFileSync(path.join(dir, 'reference.json'), 'utf8')); assert.equal(ref.cases.length, 2); assert.equal(ref.cases[0].payoffModel, 'satfield-5.13-v1'); assert.equal(ref.values.length, 3);
    for (const c of ref.cases) { assert.match(c.stateSha256, /^[0-9a-f]{64}$/); const spec = JSON.parse(fs.readFileSync(path.join(dir, c.spec), 'utf8')); assert.equal(spec.device, undefined); assert.equal(spec.trainingStreams, 'philox64'); }
    for (const v of ref.values) { assert.ok(fs.existsSync(path.join(dir, v.request))); const q = JSON.parse(fs.readFileSync(path.join(dir, v.request), 'utf8')); assert.deepEqual(Array.from(E.satelliteField(q.seats, q.field).evaluate(q.table)).map(bits), v.bits, 'the reference bits are the bits of the JavaScript mirror too'); } }
  const wf = path.join(root, '.github/workflows/windows.yml');
  if (fs.existsSync(wf)) { const y = fs.readFileSync(wf, 'utf8'); for (const s of ['--selftest513 source/studies', version === '5.13' ? 'validate_windows513.ps1 -Root' : version === '5.14' ? 'validate_windows514.ps1 -Root' : 'validate_windows516.ps1 -Root', version === '5.13' ? 'Windows-validation-5.13.json' : version === '5.14' ? 'Windows-validation-5.14.json' : 'Windows-validation-5.16.json', 'windows-selftest513.json', 'source/tests/v513.test.js']) assert.ok(y.includes(s), s); }
});
