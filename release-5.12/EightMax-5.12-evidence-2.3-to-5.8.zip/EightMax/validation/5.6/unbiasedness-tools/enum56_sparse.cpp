// EightMax 5.6 validation variant of source/tests/enum56.cpp (generated from it; kept outside the fingerprinted source).
// enum56 requires every table row a traversal reaches to exist in the frozen table. On a four-player two-street game
// that cannot be arranged: a river information set behind several low-probability opponent actions is reached a
// handful of times in millions of training deals, so some rows never exist (the engine then plays uniformly there).
// This variant accepts such rows: their increments are accumulated under the row key and written with an empty
// "frozen" list, which independent_cfr56.py reads as "no row: uniform strategy", exactly the engine's rule. The engine
// code that is exercised (mw.cpp and everything it includes) is the release source, unmodified.
// EightMax 5.6: expected increments of every external-sampling estimator against an INDEPENDENT exact target.
// Usage: enum56 spec.json prefixDeals trials MODE out.json     MODE: none | river | river-shared | river-cross
//        enum56 spec.json prefixDeals trials pair               (final-street games only)
//
// One engine is trained for `prefixDeals` updates with the default estimator and its tables are FROZEN. `trials`
// independent deals are then traversed with the estimator MODE exactly as es::train() drives it (deal, score, card
// codes, Walker::run per seat pass) but nothing is merged, so every traversal reads the same table. For every table
// entry the mean increment per deal and its standard error are written to out.json together with the entry's
// betting path, hand index and public cards, the frozen row values and the number of deals with a nonzero increment. source/tools/independent_cfr56.py recomputes
// the exact expected increment of every entry from the spec and these frozen values, in Python, with its own betting
// rules, pots, evaluator and chance enumeration, and compares. (enum55.cpp compared two estimators with each other;
// this compares each estimator with the quantity it is supposed to estimate.)
//
// "pair": on a game played entirely on the final street the 5.5 "river" estimator and the 5.6 "river-shared" estimator
// sample nothing after the deal, so for the same deal and table their increments must be EQUAL, not merely equal in
// expectation. Every trial deal is traversed with both and the largest absolute and relative difference is reported.
#include "mw.cpp"
#include <map>
#include <fstream>
#include <iterator>
static void setMode(es::Game &g, const std::string &mode) {
  g.enumerateFrom = mode == "none" ? 0 : 5; g.enumShare = mode == "river-shared" ? 1 : mode == "river-cross" ? 2 : 0;
}
int main(int argc, char **argv) {
  if (argc != 5 && argc != 6) { std::fprintf(stderr, "usage: enum56 spec.json prefixDeals trials none|river|river-shared|river-cross out.json | enum56 spec.json prefixDeals trials pair\n"); return 2; }
  const std::string mode = argv[4]; const bool pair = mode == "pair";
  if (!pair && argc != 6) { std::fprintf(stderr, "an output file is required\n"); return 2; }
  if (!pair && mode != "none" && mode != "river" && mode != "river-shared" && mode != "river-cross") { std::fprintf(stderr, "unknown mode\n"); return 2; }
  std::ifstream file(argv[1]); std::string spec{std::istreambuf_iterator<char>(file), {}};
  const long long prefix = std::atoll(argv[2]), trials = std::atoll(argv[3]); char error[512] = {};
  MW *m = mw_create(spec.data(), spec.size(), 256, error, sizeof error);
  if (!m) { std::fprintf(stderr, "%s\n", error); return 1; }
  if (m->batchDeals != 1) { std::fprintf(stderr, "use batchDeals 1\n"); return 2; }
  es::Game &g = *m->es; setMode(g, "none");
  if (g.ownHands || g.terminalBaseline || g.terminalExpectation || g.groups.on || !m->turnGroups.empty()) { std::fprintf(stderr, "use a spec without experimental options or hand groups\n"); return 2; }
  if (!mw_train(m, prefix, 1, nullptr, nullptr, nullptr, error, sizeof error)) { std::fprintf(stderr, "%s\n", error); return 1; }
  const size_t N = m->vals.size(); const long long it0 = m->iterations;
  ScratchBudget budget((size_t)64 << 20, g.scratchPeak); es::Walker walker(*m, g, budget); es::Unit u(budget);
  g.setStoreCap(m->budgetBytes); g.extendStore(m->stateVisits); g.unitLimitBytes = (size_t)16 << 20;
  const double step = m->linear ? (double)(it0 + 1) : 1.0, avgStep = step;
  std::vector<long double> add(N, 0), sum(N, 0), sq(N, 0); std::vector<long long> hits(N, 0); long long visits = 0; double seconds = 0;
  struct Virtual { size_t off; int k; uint32_t state; int hand; uint32_t code; }; std::map<uint64_t, Virtual> virt; size_t total = N;
  auto traverse = [&](const std::string &md, std::vector<long double> &into, Rng &actions) -> bool {
    setMode(g, md); const int passes = g.wholeGameEnumerated() ? 1 : m->n;
    for (int p = 0; p < passes; p++) {
      u.pending.clear(); u.incs.clear(); u.vals.clear();
      walker.run(u, p, actions, step, avgStep);
      if (u.overflow || !u.pending.empty()) { std::fprintf(stderr, "the traversal reached an unvisited state: use a longer prefix\n"); return false; }
      for (const es::Inc &inc : u.incs) {
        const long long r = m->findRow(es::rowKey((uint32_t)inc.ref, inc.hand, inc.code));
        if (inc.row >= 0 && inc.row != r) { std::fprintf(stderr, "row hint disagrees with the table\n"); return false; }
        size_t o;
        if (r < 0) {   // a row that does not exist in the frozen table: uniform strategy there; accumulate under its key
          const uint64_t key = es::rowKey((uint32_t)inc.ref, inc.hand, inc.code); auto f = virt.find(key);
          if (f == virt.end()) { f = virt.emplace(key, Virtual{total, (int)inc.k, (uint32_t)inc.ref, (int)inc.hand, inc.code}).first; total += 2 * (size_t)inc.k; add.resize(total, 0); sum.resize(total, 0); sq.resize(total, 0); hits.resize(total, 0); }
          o = f->second.off;
        } else o = m->rows[(size_t)r].off;
        if (into.size() < total) into.resize(total, 0);
        for (int a = 0; a < 2 * inc.k; a++) into[o + (size_t)a] += u.vals[inc.off + (size_t)a];
      }
      visits += u.visits; u.visits = 0;
    }
    return true;
  };
  if (pair) {
    setMode(g, "river-shared");
    if (!g.wholeGameEnumerated()) { std::fprintf(stderr, "pair needs a game played entirely on the final street\n"); return 2; }
    std::vector<long double> other(N, 0); long double maxAbs = 0, maxRel = 0; long long compared = 0;
    for (long long s = 0; s < trials; s++) {
      const uint32_t seed = study53::mix((uint32_t)s + 0x56u); m->rng.state = seed; Rng a1{1}, a2{2};
      u.clear(); if (!m->deal(u.w, 0)) { std::fprintf(stderr, "deal failed\n"); return 1; }
      m->score(u.w); es::codes(u, m->n);
      if (!traverse("river", add, a1) || !traverse("river-shared", other, a2)) return 3;
      for (size_t i = 0; i < N; i++) if (add[i] != 0 || other[i] != 0) {
        const long double d = fabsl(add[i] - other[i]), scale = std::max<long double>(1, std::max(fabsl(add[i]), fabsl(other[i])));
        maxAbs = std::max(maxAbs, d); maxRel = std::max(maxRel, d / scale); compared++; add[i] = other[i] = 0;
      }
    }
    std::printf("{\"test\":\"river vs river-shared, same deal, same frozen table\",\"prefixDeals\":%lld,\"trials\":%lld,\"entriesCompared\":%lld,\"maxAbsDifference\":%.6Lg,\"maxRelativeDifference\":%.6Lg,\"step\":%.17g,\"equalWithin1e-12\":%s}\n",
                prefix, trials, compared, maxAbs, maxRel, step, maxRel <= 1e-12L ? "true" : "false");
    mw_free(m); return maxRel <= 1e-12L ? 0 : 1;
  }
  for (long long s = 0; s < trials; s++) {
    const uint32_t seed = study53::mix((uint32_t)(s * 4) + 0x56u + (uint32_t)mode.size() * 977u);
    m->rng.state = seed; Rng actions{study53::mix(seed ^ 0xabcdef01u)};
    u.clear(); if (!m->deal(u.w, 0)) { std::fprintf(stderr, "deal failed\n"); return 1; }
    m->score(u.w); es::codes(u, m->n);
    const double t0 = es::now();
    if (!traverse(mode, add, actions)) return 3;
    seconds += es::now() - t0;
    for (size_t i = 0; i < total; i++) if (add[i] != 0) { sum[i] += add[i]; sq[i] += add[i] * add[i]; add[i] = 0; hits[i]++; }
  }
  FILE *out = std::fopen(argv[5], "w"); if (!out) { std::fprintf(stderr, "cannot write %s\n", argv[5]); return 1; }
  std::fprintf(out, "{\"estimator\":\"%s\",\"prefixDeals\":%lld,\"trials\":%lld,\"step\":%.17g,\"averageStep\":%.17g,\"stateVisitsPerDeal\":%.4f,\"secondsPerDeal\":%.9g,\"rows\":[\n", mode.c_str(), prefix, trials, step, avgStep, (double)visits / trials, seconds / trials);
  bool first = true;
  for (const auto &r : m->rows) {
    const uint32_t state = (uint32_t)(r.key >> 37); const int hand = (int)((r.key >> 26) & 2047); const uint32_t code = (uint32_t)(r.key & ((1u << 26) - 1));
    std::vector<int> path; for (uint32_t i = state; i != 0 && i != 0xffffffffu; i = g.states.parent[i]) path.push_back(g.states.slot[i]);
    uint8_t cards[5]; es::decodeCards(code, g.states.length[state], cards);
    std::fprintf(out, "%s{\"path\":[", first ? "" : ",\n"); first = false;
    for (size_t i = path.size(); i-- > 0;) std::fprintf(out, "%d%s", path[i], i ? "," : "");
    std::fprintf(out, "],\"seat\":%d,\"hand\":%d,\"length\":%d,\"cards\":[%d,%d,%d,%d,%d],\"k\":%d,\"frozen\":[", (int)g.states.actor[state], hand, (int)g.states.length[state], cards[0] - 1, cards[1] - 1, cards[2] - 1, cards[3] - 1, cards[4] - 1, r.k);
    for (int a = 0; a < 2 * r.k; a++) std::fprintf(out, "%s%.17g", a ? "," : "", m->vals[r.off + (size_t)a]);
    std::fprintf(out, "],\"mean\":[");
    for (int a = 0; a < 2 * r.k; a++) std::fprintf(out, "%s%.17Lg", a ? "," : "", sum[r.off + (size_t)a] / trials);
    std::fprintf(out, "],\"standardError\":[");
    for (int a = 0; a < 2 * r.k; a++) { const long double mean = sum[r.off + (size_t)a] / trials; long double v = (sq[r.off + (size_t)a] - trials * mean * mean) / (trials - 1); if (v < 0) v = 0; std::fprintf(out, "%s%.17Lg", a ? "," : "", sqrtl(v / trials)); }
    std::fprintf(out, "],\"nonzeroDeals\":[");
    for (int a = 0; a < 2 * r.k; a++) std::fprintf(out, "%s%lld", a ? "," : "", hits[r.off + (size_t)a]);
    std::fprintf(out, "]}");
  }
  for (const auto &kv : virt) {
    const Virtual &v = kv.second; std::vector<int> path; for (uint32_t i = v.state; i != 0 && i != 0xffffffffu; i = g.states.parent[i]) path.push_back(g.states.slot[i]);
    uint8_t cards[5]; es::decodeCards(v.code, g.states.length[v.state], cards);
    std::fprintf(out, "%s{\"path\":[", first ? "" : ",\n"); first = false;
    for (size_t i = path.size(); i-- > 0;) std::fprintf(out, "%d%s", path[i], i ? "," : "");
    std::fprintf(out, "],\"seat\":%d,\"hand\":%d,\"length\":%d,\"cards\":[%d,%d,%d,%d,%d],\"k\":%d,\"frozen\":[],\"mean\":[", (int)g.states.actor[v.state], v.hand, (int)g.states.length[v.state], cards[0] - 1, cards[1] - 1, cards[2] - 1, cards[3] - 1, cards[4] - 1, v.k);
    for (int a = 0; a < 2 * v.k; a++) std::fprintf(out, "%s%.17Lg", a ? "," : "", sum[v.off + (size_t)a] / trials);
    std::fprintf(out, "],\"standardError\":[");
    for (int a = 0; a < 2 * v.k; a++) { const long double mean = sum[v.off + (size_t)a] / trials; long double q = (sq[v.off + (size_t)a] - trials * mean * mean) / (trials - 1); if (q < 0) q = 0; std::fprintf(out, "%s%.17Lg", a ? "," : "", sqrtl(q / trials)); }
    std::fprintf(out, "],\"nonzeroDeals\":[");
    for (int a = 0; a < 2 * v.k; a++) std::fprintf(out, "%s%lld", a ? "," : "", hits[v.off + (size_t)a]);
    std::fprintf(out, "]}");
  }
  std::fprintf(stderr, "rows in the frozen table: %zu; rows reached that do not exist there: %zu\n", m->rows.size(), virt.size());
  std::fprintf(out, "\n]}\n"); std::fclose(out); mw_free(m); return 0;
}
