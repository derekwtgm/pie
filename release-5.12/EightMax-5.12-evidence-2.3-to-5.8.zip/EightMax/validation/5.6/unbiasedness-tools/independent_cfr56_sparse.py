#!/usr/bin/env python3
"""EightMax 5.6 validation variant of source/tools/independent_cfr56.py for dumps of enum56_sparse.cpp.
Usage: independent_cfr56_sparse.py spec.json dump.json [more-dumps.json ...] > report.json

The exact targets are computed by the SAME function as in the release tool (imported from it). Only the comparison
differs, in two ways that the four-player two-street game needs:
  * an entry no trial deal touched (nonzeroDeals == 0) is "not observed", not a deterministic mismatch: with thousands
    of rarely reached rows, many have a nonzero target and were simply not sampled;
  * an entry whose mean and target differ by less than 1e-9 x max(1, |target|, step) agrees numerically and is not
    z-tested. Where two actions have exactly the same value the target is 0 and the engine's increments are rounding
    noise of the order 1e-12 on regrets of the order 1e7; their tiny standard error turns that noise into z = 30.
Everything else (z statistic, 500 nonzero deals, Bonferroni limit) is as in the release tool."""
import sys, json, math, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'source', 'tools'))
import independent_cfr56 as base
from statistics import NormalDist
MIN_NONZERO = base.MIN_NONZERO
spec = json.load(open(sys.argv[1])); reports = []; ok = True; cache = None
for path in sys.argv[2:]:
    d = json.load(open(path)); frozen = {}
    def key(r):
        L = r['length']; c = r['cards']; return (tuple(r['path']), r['hand'], (tuple(sorted(c[:3])) + tuple(c[3:L])) if L >= 3 else ())
    for r in d['rows']: frozen[key(r)] = r['frozen']
    if cache is None or cache[0] != frozen: cache = (frozen, base.targets(spec, frozen))
    reg, avg, ndeals = cache[1]; step, astep = d['step'], d['averageStep']
    zs = {'regret': [], 'average': []}; few = {'regret': 0, 'average': 0}; unseen = {'regret': 0, 'average': 0}; numeric = {'regret': 0, 'average': 0}; det = 0; worst = {'regret': None, 'average': None}; missing = sum(1 for r in d['rows'] if not r['frozen'])
    seen = set()
    for r in d['rows']:
        k = r['k']; kk = key(r); seen.add(kk)
        for a in range(2 * k):
            kind = 'regret' if a < k else 'average'
            target = step * reg.get(kk, [0.0] * k)[a] if a < k else astep * avg.get(kk, [0.0] * k)[a - k]
            mean, se, hits = r['mean'][a], r['standardError'][a], r['nonzeroDeals'][a]
            if hits == 0: unseen[kind] += 1; continue
            if abs(mean - target) <= 1e-9 * max(1.0, abs(target), step): numeric[kind] += 1; continue
            if se == 0: det += 1; continue
            if hits < MIN_NONZERO: few[kind] += 1; continue
            z = (mean - target) / se; zs[kind].append(z)
            if worst[kind] is None or abs(z) > abs(worst[kind]['z']): worst[kind] = {'z': z, 'path': r['path'], 'hand': r['hand'], 'action': a % k, 'mean': mean, 'target': target, 'standardError': se, 'nonzeroDeals': hits}
    tested = len(zs['regret']) + len(zs['average']); crit = NormalDist().inv_cdf(1 - 0.05 / (2 * max(1, tested)))
    def summ(v): return {'tested': len(v), 'maxAbsZ': max((abs(x) for x in v), default=0.0), 'shareAbove1.96': sum(abs(x) > 1.959963984540054 for x in v) / max(1, len(v)), 'meanZ': sum(v) / max(1, len(v)), 'rmsZ': math.sqrt(sum(x * x for x in v) / max(1, len(v)))}
    sr, sa = summ(zs['regret']), summ(zs['average']); passed = det == 0 and max(sr['maxAbsZ'], sa['maxAbsZ']) < crit; ok &= passed
    reports.append({'dump': os.path.basename(path), 'estimator': d['estimator'], 'trials': d['trials'], 'prefixDeals': d['prefixDeals'], 'stateVisitsPerDeal': d['stateVisitsPerDeal'], 'secondsPerDeal': d['secondsPerDeal'], 'dealsEnumerated': ndeals, 'rows': len(d['rows']), 'rowsNotInTheFrozenTable': missing,
                    'rowsWithATargetNeverReachedByATrial': sum(1 for kk in reg if kk not in seen), 'regret': sr, 'average': sa, 'worstRegret': worst['regret'], 'worstAverage': worst['average'], 'deterministicMismatches': det, 'entriesNotObserved': unseen, 'entriesAgreeingNumerically': numeric,
                    'entriesNotTestedForFewNonzeroDeals': few, 'minimumNonzeroDeals': MIN_NONZERO, 'bonferroniCriticalZ': crit, 'passed': passed})
print(json.dumps({'tool': 'independent_cfr56_sparse (validation variant)', 'spec': os.path.basename(sys.argv[1]), 'players': spec['n'], 'startCards': len(spec['board']), 'allPassed': ok, 'estimators': reports}, indent=1))
sys.exit(0 if ok else 1)
