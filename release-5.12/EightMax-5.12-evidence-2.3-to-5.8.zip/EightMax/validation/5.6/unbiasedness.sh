#!/bin/sh
# Formal run of the expected-increment check of every estimator against the independent exact target.
# Usage: sh validation/5.6/unbiasedness.sh <release root> <out dir>
#   source/tests/enum56.cpp     frozen-table Monte Carlo means of the increments (C++, the shipped trainer code)
#   source/tools/independent_cfr56.py   exact expected increments (Python; shares no code with the engine)
# Plan (fixed before the run; every dump and report is kept in <out dir>):
#   game          prefix deals   estimators and deals per estimator
#   hu-river        5,000        none 20M, river 20M, river-shared 20M, river-cross 20M
#   river3-chip    20,000        none 10M, river 10M, river-cross 10M
#   hu-turn        20,000        none 30M, river 10M, river-cross 10M
#   turn4         300,000        none 10M, river 5M, river-cross 5M
#   pair (river vs river-shared, same deal): hu-river 1M deals, river3-chip 500k deals
# Pass rule (independent_cfr56.py): no deterministic mismatch and max |z| below the two-sided Bonferroni critical
# value at 0.05 over the entries tested, for every estimator. An estimator that fails is re-run ONCE with four times
# the deals and a different stream offset is not available, so the re-run is simply longer; a bias would double |z|.
# Both runs are kept and reported.
set -eu
root=$(cd "$1" && pwd); out=$2; mkdir -p "$out"; out=$(cd "$out" && pwd); tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
gcc -O2 -c "$root/source/native/json.c" -o "$tmp/json.o"
g++ -std=c++20 -O2 -march=x86-64 -ffp-contract=off -I"$root/source/native" "$root/source/tests/enum56.cpp" "$tmp/json.o" -lpthread -ldl -o "$tmp/enum56" 2>/dev/null
for g in hu-river river3-chip hu-turn turn4; do node "$root/source/tools/games48.js" spec $g "$out/$g.spec.json" 901 '{"batchDeals":1,"device":"cpu"}' >/dev/null; done
run() { g=$1; prefix=$2; trials=$3; mode=$4; "$tmp/enum56" "$out/$g.spec.json" $prefix $trials $mode "$out/$g.dump.$mode.json" 2> "$out/$g.dump.$mode.err" || echo "FAILED $g $mode" >> "$out/failures.txt"; }
: > "$out/failures.txt"
"$tmp/enum56" "$out/hu-river.spec.json" 5000 1000000 pair > "$out/pair.hu-river.json" &
"$tmp/enum56" "$out/river3-chip.spec.json" 20000 500000 pair > "$out/pair.river3-chip.json" &
run hu-river 5000 20000000 none & wait
run hu-river 5000 20000000 river & run hu-river 5000 20000000 river-shared & run hu-river 5000 20000000 river-cross & wait
run river3-chip 20000 10000000 none & run river3-chip 20000 10000000 river & run river3-chip 20000 10000000 river-cross & wait
run hu-turn 20000 30000000 none & run hu-turn 20000 10000000 river & run hu-turn 20000 10000000 river-cross & wait
run turn4 300000 10000000 none & run turn4 300000 5000000 river & run turn4 300000 5000000 river-cross & wait
for g in hu-river river3-chip hu-turn turn4; do
  python3 "$root/source/tools/independent_cfr56.py" "$out/$g.spec.json" "$out"/$g.dump.*.json > "$out/report.$g.json" || echo "report $g: not every estimator passed" >> "$out/failures.txt"
done
python3 - "$out" <<'P'
import json,sys,glob,os
o=sys.argv[1]; rows=[]
for f in sorted(glob.glob(o+'/report.*.json')):
    d=json.load(open(f))
    for e in d['estimators']: rows.append({'game':d['spec'].replace('.spec.json',''),'estimator':e['estimator'],'trials':e['trials'],'regretMaxAbsZ':e['regret']['maxAbsZ'],'regretRmsZ':e['regret']['rmsZ'],'averageMaxAbsZ':e['average']['maxAbsZ'],'averageRmsZ':e['average']['rmsZ'],
        'entriesTested':e['regret']['tested']+e['average']['tested'],'entriesNotTested':e['entriesNotTestedForFewNonzeroDeals'],'criticalZ':e['bonferroniCriticalZ'],'deterministicMismatches':e['deterministicMismatches'],'stateVisitsPerDeal':e['stateVisitsPerDeal'],'passed':e['passed']})
pairs={os.path.basename(f)[5:-5]:json.load(open(f)) for f in glob.glob(o+'/pair.*.json')}
json.dump({'estimators':rows,'pairs':pairs,'allPassed':all(r['passed'] for r in rows) and all(p['equalWithin1e-12'] for p in pairs.values())},open(o+'/summary.json','w'),indent=1)
for r in rows: print('%-12s %-13s trials %-9d regret max|z| %.2f rms %.2f  average max|z| %.2f rms %.2f  critical %.2f  %s'%(r['game'],r['estimator'],r['trials'],r['regretMaxAbsZ'],r['regretRmsZ'],r['averageMaxAbsZ'],r['averageRmsZ'],r['criticalZ'],'PASS' if r['passed'] else 'FAIL'))
for k,p in pairs.items(): print('pair',k,p['entriesCompared'],'entries, max relative difference',p['maxRelativeDifference'])
P
rm -f "$out"/*.none.json.tmp; cat "$out/failures.txt"
