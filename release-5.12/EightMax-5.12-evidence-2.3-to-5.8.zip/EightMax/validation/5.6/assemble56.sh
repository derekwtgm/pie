#!/bin/bash
# Assembles the release root from the final build and the recorded evidence, writes the documents, packages twice
# (the first archive supplies the smoke-test results that the documents quote; the second is the delivered archive,
# smoke-tested again by release56.py), and copies the deliverables.
# Usage: bash validation/5.6/assemble56.sh <release root> <output dir>
set -eu
root=$(cd "$1" && pwd); out=$2; mkdir -p "$out"; cd "$root"
cp build/windows/EightMax.exe build/windows/mwcli.exe build/windows/gpustress.exe .
cp build/EightMax-Offline.html . && cp build/build-info.json BUILD-INFO.json
mkdir -p validation/5.6/linux-bin && cp build/linux/mwcli build/linux/eightmax build/linux/gpustress validation/5.6/linux-bin/
node source/tools/verify_build.js .
docs() {
  python3 validation/5.6/write_build.py .
  python3 validation/5.6/write_convergence.py .
  python3 validation/5.6/write_statistics.py .
  python3 validation/5.6/write_performance.py .
  python3 validation/5.6/summarize.py . > /dev/null
  python3 validation/5.6/write_final.py . "${1:-}"
  python3 validation/5.6/write_validation.py . "${1:-}"
}
docs ""
rm -rf "$out/pass1"; python3 validation/5.6/release56.py . "$out/pass1" --wine > "$out/pass1.log" 2>&1 || { tail -5 "$out/pass1.log"; echo "packaging pass 1 failed"; exit 1; }
cp "$out/pass1/EightMax-Windows-5.6.identity.json" validation/5.6/release-smoke-first-archive.json
docs validation/5.6/release-smoke-first-archive.json
python3 validation/5.6/release56.py . "$out" --wine > "$out/pass2.log" 2>&1 || { tail -5 "$out/pass2.log"; echo "packaging pass 2 failed"; exit 1; }
cp FINAL-REPORT-5.6.md CONVERGENCE-5.6.md VALIDATION-5.6.md WINDOWS-TESTS-5.6.md "$out/"
rm -rf "$out/pass1"
ls -la "$out"; sha256sum "$out/EightMax-Windows-5.6.zip"
