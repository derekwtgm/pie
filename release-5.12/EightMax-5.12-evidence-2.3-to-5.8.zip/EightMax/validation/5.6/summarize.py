#!/usr/bin/env python3
"""Collects the recorded evidence into validation/5.6/validation-summary.json (machine-readable) and prints it.
Usage: python3 validation/5.6/summarize.py <release root>
Every item carries one of four classes:
  1 implemented and independently tested          (an independent implementation, an exact reference or the unchanged 5.5 binary agrees)
  2 implemented and verified by simulation or Wine (the project's own tests, simulations, the Windows programs under Wine)
  3 implemented, awaiting physical hardware       (written, not executed on Windows hardware or an NVIDIA GPU)
  4 not implemented or unsuccessful
Nothing is marked as passed unless the file that records it exists and says so."""
import sys, json, re, pathlib
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.6'
def J(p):
    p = V / p; return json.loads(p.read_text()) if p.exists() else None
def tap(p):
    p = V / p
    if not p.exists(): return None
    t = p.read_text(errors='replace'); g = lambda k: int(m.group(1)) if (m := re.search(r'^# %s (\d+)' % k, t, re.M)) else None
    fails = [m.group(1) for m in re.finditer(r'^not ok \d+ - (.*?)(?: # .*)?$', t, re.M)]; skips = [(m.group(1), m.group(2).strip()) for m in re.finditer(r'^ok \d+ - (.*?) # SKIP(.*)$', t, re.M)]
    return {'tests': g('tests'), 'passed': g('pass'), 'failed': g('fail'), 'skipped': g('skipped'), 'cancelled': g('cancelled'), 'failures': fails, 'skippedTests': [{'name': a, 'reason': b} for a, b in skips], 'complete': g('tests') is not None}
info = json.loads((root / 'BUILD-INFO.json').read_text()) if (root / 'BUILD-INFO.json').exists() else {}
S = {'release': '5.6', 'build': info.get('build'), 'classes': {'1': 'implemented and independently tested', '2': 'implemented and verified by simulation or Wine', '3': 'implemented, awaiting physical hardware validation', '4': 'not implemented or unsuccessful'}, 'items': []}
def item(area, name, cls, passed, detail, evidence): S['items'].append({'area': area, 'name': name, 'class': cls, 'passed': passed, 'detail': detail, 'evidence': evidence})
b = J('baseline/baseline-5.5.json')
if b: item('baseline', '5.5 archive, manifest, build identity and regression suite reproduced', 1, b['archiveSha256MatchesIdentityFile'] and b['manifestEntriesFailed'] == 0 and b['buildReproducedFromSource'] and b['regressionMatches55Report'], {'manifestEntriesVerified': b['manifestEntriesVerified'], 'build': b['build'], 'regression': b['regressionOnRebuiltLinuxBinaries']}, 'validation/5.6/baseline/')
r = tap('tests/full-regression.tap'); S['regression'] = r
if r: item('regression', 'full regression suite on the final Linux build', 2, r['failed'] == 0 and r['complete'], {k: r[k] for k in ('tests', 'passed', 'failed', 'skipped')} | {'skippedTests': r['skippedTests']}, 'validation/5.6/tests/full-regression.tap')
fc = J('final-checks.json')
if fc: item('trainer', 'final binary reproduces the convergence checkpoints (5.5 arms included) and the golden states', 1, fc['passed'], {'checkpointsChecked': fc['convergenceCheckpointsReproducedByFinalBinary']['checked'], 'differing': fc['convergenceCheckpointsReproducedByFinalBinary']['differing'], 'golden': fc['goldenStates'], 'trainerSourcesUnchangedSinceTheRun': fc['trainerSources']['allSame']}, 'validation/5.6/final-checks.json')
idn = J('identity/summary.json')
if idn: item('trainer', 'default trainer and 5.5 options: state bytes identical to the 5.5 binary (10 games x 17 configurations, one-part and two-part)', 1, idn['failures'] == 0, idn, 'validation/5.6/identity/')
xv = J('cross-version-continuation.json')
if xv: item('checkpoints', 'solver checkpoints continue across 5.5 and 5.6 in both directions', 1, xv['identical'] == xv['cases'], {'cases': xv['cases'], 'identical': xv['identical']}, 'validation/5.6/cross-version-continuation.json')
u = J('unbiasedness/summary.json')
if u: item('mathematics', 'expected regret and average-strategy increments of every estimator against an independent exact CFR update', 1, u['allPassed'], {'estimators': [{k: e[k] for k in ('game', 'estimator', 'trials', 'regretMaxAbsZ', 'averageMaxAbsZ', 'criticalZ', 'passed')} for e in u['estimators']], 'pairs': u['pairs']}, 'validation/5.6/unbiasedness/')
c = J('convergence/main/comparisons.json')
if c:
    d = c['decision']; item('convergence', 'fixed-plan comparison completed (exact NashConv, equal deals and equal time)', 1, d['complete'], {'checkpoints': d['checkpoints'], 'defaultBetterAtEqualTime': d['engine']['gamesBetterAtEqualTime'], 'defaultPrimaryVerdicts': d['engine']['primaryVerdictByGame'], 'equalDealIdentical': d['engine']['equalDealCheckpointsIdenticalByGame']}, 'validation/5.6/convergence/main/')
    item('convergence', 'candidate river-cross promoted to default', 4, False, {'P2': d['promotion']['P2_primaryVerdictByChangedGame'], 'P2met': d['promotion']['P2_met'], 'P3met': d['promotion']['P3_met'], 'P4met': d['promotion']['P4_met'], 'outcome': 'promotion rule not met; the candidate stays opt-in'}, 'CONVERGENCE-5.6.md')
st = J('statistics/formal/results.json')
if st: item('statistics', 'replication verdicts: formulas, refusal, null scenarios, adversarial training failures', 2, st['passed'], {'failures': st['failures'], 'scenarios': len(st['scenarios']), 'trials': st['protocol']['trials']}, 'validation/5.6/statistics/formal/')
for name in ('coverage.json', 'results.json'):
    o = J('statistics/v55-rerun/' + name)
    if o is not None:
        fails = o.get('failures', o.get('fails')); item('statistics', '5.5 bounded-payoff validation re-run against the 5.6 probe', 2, not fails, {'failures': fails}, 'validation/5.6/statistics/v55-rerun/'); break
sd = V / 'sanitizers'
if sd.exists():
    a = tap('sanitizers/v53-v56-asan-ubsan.tap'); counts = (sd / 'sanitizer-report-counts.txt').read_text().split() if (sd / 'sanitizer-report-counts.txt').exists() else []
    reports = sum(int(x.rsplit(':', 1)[1]) for x in counts if ':' in x and x.rsplit(':', 1)[1].isdigit())
    ext = (sd / 'asan-interrupted-study-extended.txt').read_text() if (sd / 'asan-interrupted-study-extended.txt').exists() else ''
    only_budget = a is not None and a['failed'] == 1 and 'interrupted and resumed' in a['failures'][0] and 'EQUIVALENT' in ext and 'sanitizer reports in these runs: 0' in ext
    if a: item('sanitizers', 'AddressSanitizer + UndefinedBehaviorSanitizer on the 5.3-5.6 regression files: no sanitizer report (%d of %d tests failed, on a time budget the instrumented build exceeds)' % (a['failed'], a['tests']), 2, a['complete'] and reports == 0 and (a['failed'] == 0 or only_budget), {k: a[k] for k in ('tests', 'passed', 'failed', 'skipped')} | {'sanitizerReports': reports, 'failures': a['failures'],
        'note': ('the one failing test allows 40 resumes of 0.4 s, which the instrumented build exceeds; the same scenario run to completion (%s resumes) equals the uninterrupted study with no sanitizer report' % (re.search(r'resumes needed: (\d+)', ext).group(1))) if only_budget else ''}, 'validation/5.6/sanitizers/')
    ts = (sd / 'tsan-summary.txt').read_text() if (sd / 'tsan-summary.txt').exists() else None
    if ts: m = re.search(r'ThreadSanitizer warnings: (\d+)', ts); exits = re.findall(r'exit (\d+)', ts); item('sanitizers', 'ThreadSanitizer: parallel studies, checkpoints, frozen-batch training, parallel exact best response', 2, bool(m) and m.group(1) == '0' and all(e == '0' for e in exits), {'warnings': int(m.group(1)) if m else None, 'runExitCodes': exits}, 'validation/5.6/sanitizers/tsan-summary.txt')
    le = (sd / 'leak-attempt.exit').read_text().strip() if (sd / 'leak-attempt.exit').exists() else None
    if le is not None: item('sanitizers', 'LeakSanitizer on one complete command-line study', 2 if le == '0' else 4, le == '0', {'exit': le}, 'validation/5.6/sanitizers/leak-attempt.log')
ui = J('ui/study-ui56.json')
if ui: item('interface', 'Study tab driven in Chromium against the desktop host (Linux build)', 2, ui['passed'], {'checksPassed': ui['checksPassed'], 'checksTotal': ui['checksTotal'], 'failed': [x['name'] for x in ui['checks'] if not x['passed']]}, 'validation/5.6/ui/')
for p in sorted((V / 'stability').glob('*.json')) if (V / 'stability').exists() else []:
    sb = json.loads(p.read_text())
    if 'passed' in sb: item('stability', 'long-running studies against the desktop host: pause/resume cycles, kills, memory readings', 2, sb['passed'], {k: sb[k] for k in ('checksPassed', 'checksTotal') if k in sb}, 'validation/5.6/stability/'); break
tb = J('performance/trainbench/summary.json')
if tb: item('performance', 'training throughput 5.5 vs 5.6 on the study fixtures', 2, all(f['stateIdentical'] for f in tb['fixtures']), {'speedupBest': {f['fixture']: round(f['speedupBest'], 2) for f in tb['fixtures']}}, 'validation/5.6/performance/trainbench/')
bn = J('performance/bench/summary.json')
if bn:
    ag = [r for r in bn['rows'] if r['section'] == 'agreement']; item('performance', 'complete studies 5.5 vs 5.6: same measurements', 1, all(r['pointsDiffering'] == 0 for r in ag), {'studies': len(ag), 'pointsCompared': sum(r['pointsCompared'] for r in ag), 'bitIdentical': sum(r['pointsBitIdentical'] for r in ag), 'within1e-9': sum(r['pointsWithin1e-9'] for r in ag), 'differing': sum(r['pointsDiffering'] for r in ag)}, 'validation/5.6/performance/bench/')
    ea = [r for r in bn['rows'] if r['section'] == 'evaluationAgreement']; item('evaluator', 'exact best response 5.5 vs 5.6: same NashConv', 1, all(r['bitIdentical'] or r['relativeDifference'] <= 1e-9 for r in ea), {'comparisons': len(ea), 'bitIdentical': sum(r['bitIdentical'] for r in ea), 'largestRelativeDifference': max((r['relativeDifference'] for r in ea), default=0)}, 'validation/5.6/performance/bench/')
th = J('performance/threads.json')
if th: item('cpu', 'frozen-batch training with 1, 2 and 4 threads: identical state for every thread count and both versions', 1, th['allIdentical'], {'games': sorted({r['game'] for r in th['rows']})}, 'validation/5.6/performance/threads.json')
br = J('build-reproducibility.json')
if br: item('build', 'Windows executables byte-reproducible (built twice)', 2, br['identical'], br['files'], 'validation/5.6/build-reproducibility.json')
wp = J('wine/per-file.json'); S['wineFiles'] = ({k: wp[k] for k in ('method', 'suite56', 'control55', 'categories', 'only56', 'only56WhenThreeFilesRanAtOnce', 'failing56NotRunIn55', 'reading')} if wp else None)
w = next((r for r in wp['perFile56'] if r['file'] == 'v56.test.js'), None) if wp else None; S['wineV56'] = w
if w: item('windows', '5.6 regression file against the Windows executables under Wine', 2, w['failed'] == 0 and w['complete'], {k: w[k] for k in ('tests', 'passed', 'failed', 'skipped')}, 'validation/5.6/wine/files/v56.test.js.56.tap')
if wp:
    s = wp['suite56']
    item('windows', 'whole regression suite against the Windows executables under Wine, file by file: no failure that the 5.5 Windows executables do not show as well (%d of %d tests fail under Wine with both)' % (s['failed'], s['tests']), 2, s['filesComplete'] == s['files'] and not wp['only56'] and not wp['failing56NotRunIn55'],
         s | {'control55': wp['control55'], 'failingWith56AndPassingWith55': wp['only56'], 'failingWith56WithoutA55Result': wp['failing56NotRunIn55'], 'causes': [{k: c[k] for k in ('cause', 'count56', 'alsoFailing55')} for c in wp['categories']]}, 'validation/5.6/wine/per-file.json')
pk = root.parent / 'output' / 'EightMax-Windows-5.6.identity.json'
for name, why in [('physical Windows 11 execution of the three executables', 'no Windows machine was available; run "Run 5.6 Windows validation.bat"'), ('NVIDIA RTX 4060 Ti (CUDA) execution and timings', 'no NVIDIA GPU was available; no CUDA code changed; the driver test double was used on Linux'),
                  ('validate_windows56.ps1 (the Windows validation script itself)', 'written for Windows PowerShell 5.1; never executed: no PowerShell was available to the development session'),
                  ('GitHub Actions Windows workflow with the 5.6 steps', 'updated; not run: no runner was reachable from the development session'), ('checkpoint durability under real power loss', 'never tested (as in 5.5)')]:
    item('hardware', name, 3, None, {'status': 'not executed', 'reason': why}, 'WINDOWS-TESTS-5.6.md')
S['counts'] = {'itemsPassed': sum(1 for i in S['items'] if i['passed'] is True), 'itemsFailedOrUnsuccessful': sum(1 for i in S['items'] if i['passed'] is False), 'itemsNotExecuted': sum(1 for i in S['items'] if i['passed'] is None)}
(V / 'validation-summary.json').write_text(json.dumps(S, indent=1))
for i in S['items']: print('[class %d] %-5s %s: %s' % (i['class'], {True: 'PASS', False: 'NO', None: '-'}[i['passed']], i['area'], i['name']))
print(json.dumps(S['counts']))
