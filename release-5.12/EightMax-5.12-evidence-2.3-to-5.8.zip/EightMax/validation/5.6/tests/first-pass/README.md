# First full regression pass (not the recorded result)

`regression-run1-build-15da3c3c.tap` is the first complete run of the suite during 5.6 development, on an earlier
build, while other jobs were running and while tests were still being added. 583 tests: 577 passed, 5 failed, 1 skipped.
It is kept because failures should not disappear. Each one and its cause:

| Test | Cause | Outcome on the final build |
|---|---|---|
| `interruption at rotation` (v35) | The desktop host answered 503 "insufficient RAM budget": a 4 GiB evaluator-cache comparison run and a 5.5 study were running beside the suite | passes (and passed alone at the time) |
| `HTTP streaming refuses oversized chunk` (v36) | Same 503 under memory pressure | passes |
| `4.8 Windows harness ...` (v48) | The test checks that every `RELEASE-x.y.md` the CI workflow copies exists; `RELEASE-5.6.md` had not been written yet | passes |
| `5.6 one process per study checkpoint ...` | The test was added after that binary was built (the binary had no lock) | passes |
| `5.6 a seed count beyond the fixture list ...` | Same: the feature was added after that binary was built | passes |

The recorded result is `../full-regression.tap`, made on the final build with three processors to itself (the convergence run was finishing on the fourth).

`regression-final-build-with-wine-suite-alongside.tap` is the first complete run on the final build (7ee054b4):
583 tests, 580 passed, 2 failed, 1 skipped, made while the same suite was running against the Windows programs under
Wine on the fourth processor.

| Test | What happened | Outcome when re-run |
|---|---|---|
| `HTTP streaming refuses missing declared bytes` (v36) | The desktop host answered 503 to the upload that precedes the check (its memory guard), where 200 is expected | see `../earlier-runs.json` and VALIDATION-5.6.md |
| `5.1 crossover inside one job ...` (v51) | A route choice that depends on measured scoring times used the CPU for every batch size | same |

Neither test touches code changed in 5.6. Both had passed in the previous complete run on the same engine sources.
