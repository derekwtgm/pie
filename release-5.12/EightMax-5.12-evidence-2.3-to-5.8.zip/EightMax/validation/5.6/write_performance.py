#!/usr/bin/env python3
"""Writes PERFORMANCE-5.6.md from the recorded benchmark data. Usage: python3 validation/5.6/write_performance.py <release root>
Reads validation/5.6/performance/{trainbench/summary.json, bench/summary.json, threads.json} and validation/5.6/profile/."""
import sys, json, pathlib, statistics
root = pathlib.Path(sys.argv[1]).resolve(); P = root / 'validation/5.6/performance'; PR = root / 'validation/5.6/profile'
TB = json.loads((P / 'trainbench/summary.json').read_text()); B = json.loads((P / 'bench/summary.json').read_text()); rows = B['rows']
TH = json.loads((P / 'threads.json').read_text()) if (P / 'threads.json').exists() else None
prof = json.loads((PR / 'profile.json').read_text()) if (PR / 'profile.json').exists() else None
o = []; w = o.append
def f(x, n=2): return 'n/a' if x is None else ('%.' + str(n) + 'f') % x
w('# Performance — EightMax 5.6\n')
w('Every figure here was measured on the development machine, a shared cloud container with four logical processors (%s, %.0f GiB), against the unchanged 5.5 Linux binary, alternating the two programs. **None of it was measured on Windows hardware or on the target Core i7 / RTX 4060 Ti**; `Run 5.6 Windows validation.bat` measures the same quantities on your PC. Ratios between versions carry over better than absolute times.\n' % (B['environment']['cpu'], B['environment']['memTotalKiB'] / 1048576))
w('5.5 made complete studies faster by running seeds side by side and enlarging the evaluator cache; its trainer was not faster. 5.6 makes the trainer and the exact evaluator themselves faster. Training throughput and study throughput are reported separately below.\n')
w('## 1. Where the time went (profile of 5.5)\n')
if prof:
    w('Instruction counts and simulated cache misses (Valgrind Callgrind, one training thread, 30,000 sampled deals):\n')
    w('| Fixture | Version | Instructions | D1 read miss | D1 write miss | Last-level data misses |\n|---|---|---|---|---|---|')
    for r in prof['cacheSimulation']: w('| %s | %s | %.2f billion | %.2f%% | %.2f%% | %.2f million |' % (r['fixture'], r['version'], r['instructions'] / 1e9, r['d1ReadMissPercent'], r['d1WriteMissPercent'], r['lastLevelDataMisses'] / 1e6))
    w('')
    w('5.6 executes about a third fewer instructions for the same deals and writes far less to memory (the 440-byte betting-state copies are gone). Last-level cache misses are essentially unchanged: they come from reading and updating the strategy table at random positions, which is the work itself.\n')
    w('Shares of the 5.5 trainer\'s instructions on small games (`validation/5.6/profile/callgrind-5.5-*.txt`): the traversal proper about 60%; merging increments 15-18%, of which most was allocating the per-update journal; finding child states and rebuilding terminal states about 20%; reading strategies 8-12%; dealing and scoring 3-6%; clock reads 2% of instructions and more of the time. On the grouped fixtures, building hand-group keys as text took 10% (three-way flop) to 47% (eight-handed ICM) of the instructions.\n')
    w('Throughput of the 5.6 default trainer by kind of work (one thread, 300,000 deals, instrumented development build of the same source):\n')
    w('| Fixture | Sampled deals / s | State visits / s | State visits per deal | Information-set updates per deal | Information-set updates / s | Regret and average values written / s | Row found when the strategy was read |\n|---|---|---|---|---|---|---|---|')
    for r in prof['updateThroughput']: w('| %s | %s | %s | %.1f | %.1f | %s | %s | %.1f%% |' % (r['fixture'], format(round(r['dealsPerSecond']), ','), format(round(r['visitsPerSecond']), ','), r['visitsPerDeal'], r['updatesPerDeal'], format(round(r['updatesPerSecond']), ','), format(round(r['valuesPerSecond']), ','), r['rowHintPercent']))
    w('')
    w('Each information-set update writes k regret increments and k average-strategy increments, so regret-update and average-update throughput are each half of the "values written" column. The last column is the share of updates whose table row was already known when the increment was merged (5.5 looked every one up a second time). These rates were measured while other work was running and are lower than the idle-machine figures of section 2.\n')
    w('Locks: with one deal per update (every study) the trainer takes no lock. With frozen batches the workers share one atomic counter and write to private buffers; merging is single-threaded by design, because it assigns state identifiers in deal order so that results do not depend on the thread count.\n')
w('## 2. Training throughput (default trainer, study fixtures)\n')
w('`source/tools/trainbench56.py`: variant 0 of every study fixture, one training thread (as a study trains a seed), %s sampled deals, %d repetitions alternating the two binaries. No evaluation is run.\n' % (format(TB['plan']['deals'], ','), TB['plan']['repetitions']))
w('| Fixture | Seats | Rows | Table MiB | 5.5 best / median seconds | 5.6 best / median seconds | Speed-up (best, median) | 5.6 sampled deals / s | 5.6 state visits / s | Same state bytes |\n|---|---|---|---|---|---|---|---|---|---|')
for s in TB['fixtures']:
    w('| %s | %s | %s | %.1f | %.2f / %.2f | %.2f / %.2f | **%.2fx**, %.2fx | %s | %s | %s |' % (s['fixture'], s['players'], format(s['rows'], ','), s['tableMiB'], s['v55']['minSeconds'], s['v55']['medianSeconds'], s['v56']['minSeconds'], s['v56']['medianSeconds'], s['speedupBest'], s['speedupMedian'],
      format(round(s['v56']['dealsPerSecondBest']), ','), format(round(s['v56']['visitsPerSecondBest']), ','), 'yes' if s['stateIdentical'] else '**NO**'))
sp = [s['speedupBest'] for s in TB['fixtures']]
w('')
w('Speed-up range %.2fx to %.2fx (median %.2fx). It is largest where a deal is cheap and the table small (bookkeeping dominated) and smallest where the table is hundreds of megabytes and most of the time is cache misses on the table itself. The saved states are byte-identical in every row, so this is the same training, sooner.\n' % (min(sp), max(sp), statistics.median(sp)))
if TH:
    w('### Thread scaling of frozen-batch training\n')
    w('Studies train one deal per update on one thread per seed and use the other processors for other seeds. The trainer itself uses several threads only with frozen batches (64 deals per update here, per-deal action streams). Best of three runs:\n')
    w('| Game | Version | 1 thread, s | 2 threads, s | 4 threads, s | 4-thread speed-up | State identical across thread counts and versions |\n|---|---|---|---|---|---|---|')
    for game in dict.fromkeys(r['game'] for r in TH['rows']):
        for ver in ('5.5', '5.6'):
            t = {r['threadsRequested']: r for r in TH['rows'] if r['game'] == game and r['version'] == ver}
            w('| %s | %s | %.3f | %.3f | %.3f | %.2fx | %s |' % (game, ver, t[1]['wallSeconds'], t[2]['wallSeconds'], t[4]['wallSeconds'], t[1]['wallSeconds'] / t[4]['wallSeconds'], 'yes' if t[1]['identicalAcrossThreadsAndVersions'] else '**NO**'))
    w('')
    w('5.6 did not change how batches are split among threads. 5.6 is faster than 5.5 at every thread count measured, but its gain is in the per-thread traversal, so the single-threaded merge is a larger share of what remains and the relative benefit of extra threads is smaller than in 5.5 (and on the smallest game both versions are slower with more threads). Thread scaling was not improved. More threads do not by themselves mean faster convergence: a frozen batch of 64 deals also makes fewer strategy updates per deal than one deal per update.\n')
w('## 3. Complete studies\n')
st = [r for r in rows if r['section'] == 'study' and 'error' not in r]
w('`source/tools/bench56.py`: identical options for both versions, %d threads, %d repetitions, checkpoints off. "Training", "action EV" and "quality" are sums over the study\'s points (seeds run side by side, so they exceed wall time).\n' % (B['environment']['threadsRequested'], B['environment']['repetitions']))
w('| Study | Version | Wall s (best) | Training s | Action-EV s | Quality s | Peak RSS MiB | Points |\n|---|---|---|---|---|---|---|---|')
ratios = []
for name in dict.fromkeys(r['workload'] for r in st):
    best = {}
    for ver in ('5.5', '5.6'):
        rs = [r for r in st if r['workload'] == name and r['version'] == ver]
        if not rs: continue
        b = min(rs, key=lambda r: r['wallSeconds']); best[ver] = b
        w('| %s | %s | %.2f | %.2f | %.2f | %.2f | %.0f | %d of %d |' % (name, ver, b['wallSeconds'], b['trainingSecondsSum'], b['actionEvSecondsSum'], b['qualitySecondsSum'], b['peakRssMiB'], b['pointsCompleted'], b['pointsRequested']))
    if len(best) == 2: ratios.append((name, best['5.5']['wallSeconds'] / best['5.6']['wallSeconds'], best['5.5']['trainingSecondsSum'] / max(1e-9, best['5.6']['trainingSecondsSum']), best['5.5']['peakRssMiB'], best['5.6']['peakRssMiB']))
w('')
w('| Study | Wall-time ratio 5.5 / 5.6 | Training-time ratio | Peak RSS 5.5 -> 5.6 MiB |\n|---|---|---|---|')
for n, a, b, m5, m6 in ratios: w('| %s | **%.2fx** | %.2fx | %.0f -> %.0f |' % (n, a, b, m5, m6))
w('')
ag = [r for r in rows if r['section'] == 'agreement']
w('**Same measurements.** Every per-seed measurement of the two versions was compared (action EVs, frequencies, standard errors, quality, deals, rows, evaluation seed):\n')
w('| Study | Points compared | Bit-identical | Within 1e-9 relative | Differing | Largest relative difference |\n|---|---|---|---|---|---|')
for r in ag: w('| %s | %d | %d | %d | %d | %s |' % (r['workload'], r['pointsCompared'], r['pointsBitIdentical'], r['pointsWithin1e-9'], r['pointsDiffering'], '%.1e' % r['largestRelativeDifference'] if r['largestRelativeDifference'] else '0'))
w('')
w('Sampled evaluations are bit-identical. Exact evaluations can differ in the last bits where 5.6 sums a passive runout through a showdown table instead of card by card (section 4); that is a different order of the same additions.\n')
w('## 4. Exact evaluation (multiway and ICM)\n')
ev = [r for r in rows if r['section'] == 'evaluation']
w('Exact all-seat best response (`mwcli --gain`) on a state trained once, one thread. A run that had not finished after %d s is shown as not finished.\n' % (max((r['seconds'] for r in ev if not r['finished']), default=0) or 0) if any(not r['finished'] for r in ev) else 'Exact all-seat best response (`mwcli --gain`) on a state trained once, one thread.\n')
w('| Game | Evaluator cache | 5.5 seconds | 5.6 seconds | Ratio | Peak RSS MiB, 5.5 / 5.6 | NashConv 5.6 | Agreement |\n|---|---|---|---|---|---|---|---|')
agr = {(r['game'], r['cacheMiB']): r for r in rows if r['section'] == 'evaluationAgreement'}
for game in dict.fromkeys(r['game'] for r in ev):
    for mem in (128, 1024):
        a = next((r for r in ev if r['game'] == game and r['cacheMiB'] == mem and r['version'] == '5.5'), None); b = next((r for r in ev if r['game'] == game and r['cacheMiB'] == mem and r['version'] == '5.6'), None)
        if not a or not b: continue
        x = agr.get((game, mem))
        w('| %s | %d MiB | %s | %s | %s | %s / %s | %s | %s |' % (game, mem, f(a['seconds']) if a['finished'] else 'not finished (%.0f s)' % a['seconds'], f(b['seconds']) if b['finished'] else 'not finished', ('**%.1fx**' % (a['seconds'] / b['seconds'])) if a['finished'] and b['finished'] else ('more than %.0fx' % (a['seconds'] / b['seconds'])) if b['finished'] else 'n/a',
          f(a['peakRssMiB'], 0), f(b['peakRssMiB'], 0), '%.6g' % b['nashConv'] if b['nashConv'] is not None else 'n/a', ('bit-identical' if x['bitIdentical'] else 'relative difference %.1e' % x['relativeDifference']) if x else '5.5 did not finish'))
w('')
w('Two changes, both in `source/native/action_ev.hpp`:\n')
w('- **Compact showdown tables.** A table of all seats\' scores on every board completion (up to 12 MiB for an eight-seat preflop deal) is read after its construction only through rank-pattern histograms. 5.5 kept the scores for the life of the table, so the cache held a few dozen tables, and an exact best response, which visits the table of every opponent-hand tuple at every terminal in turn, kept evicting and rebuilding them. 5.5\'s answer was a larger cache. 5.6 frees the scores once the histogram exists; a resident table is then a few kilobytes, the count cap of the shared cache is 4,096 instead of 64, and each table is built once. The histograms, and so every value, are unchanged.\n- **Passive runouts.** When no seat has a real decision after a chance node, 5.5 dealt the remaining cards one at a time and scored every seat on every completed board for every opponent-hand tuple. 5.6 evaluates the single terminal state through the deal\'s showdown table. Same expectation, a different order of additions (agreement column).\n')
w('The eight-handed ICM game with two-hand ranges (`final8w`, 256 hand tuples) is the case 5.5 could not evaluate: with its default 1,024 MiB cache the 5.5 binary stopped at its own 30-minute limit (`validation/5.6/performance/final8w-5.5-default.txt`); given 4,096 MiB and a raised table cap it needed 20.3 s and returned the value 5.6 returns in about the same time with a quarter of the memory.\n')
w('The ICM prize-equity kernel itself (`icm.hpp`) was profiled and left alone: it accounts for about 3.5% of training instructions on the eight-handed fixture, and its exact-key cache already serves the evaluator; the cost that mattered was table construction.\n')
mem = [r for r in rows if r['section'] == 'memory']
if mem:
    w('## 5. Memory\n')
    w('Peak resident memory of training alone, one thread, 1,000,000 sampled deals (measured by `tools/peak_rss.c`):\n')
    w('| Fixture | 5.5 peak RSS MiB | 5.6 peak RSS MiB | Difference | Table MiB | 5.6 link cache MiB | Training seconds 5.5 / 5.6 |\n|---|---|---|---|---|---|---|')
    for fx in dict.fromkeys(r['fixture'] for r in mem):
        a = next(r for r in mem if r['fixture'] == fx and r['version'] == '5.5'); b = next(r for r in mem if r['fixture'] == fx and r['version'] == '5.6')
        w('| %s | %.0f | %.0f | %+.0f | %.1f | %.1f | %.1f / %.1f |' % (fx, a['peakRssMiB'], b['peakRssMiB'], b['peakRssMiB'] - a['peakRssMiB'], b['tableMiB'], (b['linkCacheBytes'] or 0) / 1048576, a['trainingWallSeconds'], b['trainingWallSeconds']))
    w('')
    w('Training uses slightly more memory in 5.6: the child links and terminal records of the stored states (at most the state store\'s own allowance, 16 MiB per engine, not charged to the table budget) and the number index of Compact hand-group keys (16 bytes per slot, at most half full). Exact evaluation uses much less (section 4). Study peaks are in section 3. The process memory budget still defaults to 70% of installed memory (about 11 GB on a 16 GB PC); no default assumes more than that.\n')
w('## %d. What did not get faster\n' % (6 if mem else 5))
w('- Sampled evaluation (action EVs and the restricted quality measure) is unchanged; on the large sampled studies it is most of the wall time, which is why their study ratios are smaller than their training ratios.\n- Thread scaling of the trainer was not improved (section 2).\n- The largest tables are bound by memory latency, not by instructions; 5.6 gains least there.\n- No GPU code changed and no GPU was measured.\n')
(root / 'PERFORMANCE-5.6.md').write_text('\n'.join(o) + '\n'); print('PERFORMANCE-5.6.md written')
