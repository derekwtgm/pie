#!/usr/bin/env python3
"""Writes STATISTICAL-VALIDATION-5.6.md from validation/5.6/statistics/formal/results.json (and the 5.5 re-run).
Usage: python3 validation/5.6/write_statistics.py <release root>"""
import sys, json, pathlib
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.6/statistics'
R = json.loads((V / 'formal/results.json').read_text()); P = R['protocol']; F = R['formulas']; S = {s['scenario']: s for s in R['scenarios']}
old = None
for name in ('coverage.json', 'results.json'):
    p = V / 'v55-rerun' / name
    if p.exists(): old = json.loads(p.read_text()); break
def pct(x, n=2): return ('%.' + str(n) + 'f%%') % (100 * x)
def wil(d): return '%s [%s, %s]' % (pct(d['frequency']), pct(d['wilson95'][0]), pct(d['wilson95'][1]))
o = []; w = o.append
w('# Statistical validation — EightMax 5.6\n')
w('5.5 made the statement about the *measured* strategies calibrated: bounded-payoff intervals that hold for any payoff distribution, or no ranking at all. It left one thing open and said so: confidence across independent trainings. In its own adversarial scenario, where one training in twenty fails badly, a `ranked` verdict was issued in 79% of studies. Each such verdict was true for the five to ten strategies that had been measured and said nothing reliable about trainings in general.\n')
w('5.6 keeps the 5.5 intervals unchanged (`study-5.5-bounded-eb-v1`) and adds a second calculation, `study-5.6-replication-v1` (`source/native/study_stats56.hpp`), that answers a narrower question honestly: **what does this number of independent trainings support?**\n')
w('## 1. What is reported, and what each part means\n')
w('| Field (per variant and budget) | Meaning | Kind of statement |\n|---|---|---|')
w('| `confidence.evaluationKind` | `exact` or `sampled` | Declared by the evaluator, never inferred from a zero standard error |')
w('| `confidence.evaluationUncertainty` | How well each trained strategy\'s action values are known: standard error and calibrated half-width of the leading gap | Bounded-payoff (5.5), distribution-free given its assumptions; none for exact evaluation |')
w('| `confidence.trainingVariation` | How much the leading gap differs between independently trained strategies: standard deviation, minimum, maximum | Descriptive. With sampled evaluation the spread contains evaluation noise as well, and the field says so |')
w('| `confidence.replication` | Trainings run, trainings needed, per-training certificates, sign-test p-values, an order-statistic interval for the median gap, the undetectable failure rate, and a verdict | Distribution-free (see 2) |')
w('| `bestAction.declared` | True only when the measured-strategies verdict is `ranked` **and** the across-trainings verdict is `ranked` | The only place where the software recommends an action |')
w('| `statisticalWarnings` (study level) | Plain-language list of what the study does not establish | Always present when something is not established |')
w('| `verdict`, `gap.conditionalEvaluationCi95`, `gap.ci95` | As in 5.5: calibrated for the measured strategies; the interval for the mean over trainings is model-based (Student t) and labelled so | Unchanged |\n')
w('The quality figure is unchanged: exact inside the abstraction, or a sampled restricted response without a calibrated interval. It is never presented as a probability of being near equilibrium, and 5.6 adds a warning line whenever it is not calibrated.\n')
w('## 2. The across-trainings calculation\n')
w('Trainings with different seeds are independent draws from one unknown distribution of training outcomes. Nothing is assumed about that distribution: not normality, not a finite variance, not a bound.\n')
w('1. **Certificates.** For every trained strategy and every action other than the leader, the bounded-payoff interval of EV(leader) - EV(other) is computed at level 0.2 alpha\' / (n (k - 1)), where alpha\' = 0.05 / family, n is the number of trainings and k the number of actions. All of them hold together with probability at least 1 - 0.2 alpha\'. A training *certifies the leader by the margin* if every lower limit exceeds the declared EV margin, *a positive edge* if every lower limit exceeds zero, and *another action* if some upper limit is below zero. Exact evaluations are their own certificates.\n2. **Sign test.** If at most half of all trainings truly favoured the leader by the margin, the number of certified trainings among n would be stochastically smaller than Binomial(n, 1/2). The claim is made when P(Bin(n, 1/2) >= s) <= 0.4 alpha\'. The leader is chosen from the same data, which is why the level is 0.4 alpha\' and not 0.8 alpha\': a training can favour at most one action by a positive margin, so over all actions the error is at most twice the one-sided tail. Total error: 2 x 0.4 alpha\' + 0.2 alpha\' = alpha\'.\n3. **Minimum replication.** The smallest tail, all n trainings agreeing, is 2^-n. Below the n at which 2^-n <= 0.4 alpha\' no data can support the claim, and the verdict is `insufficientReplication`.\n4. **A training that disagrees.** If any training certifies another action, the verdict is `trainingsDisagree` and nothing is declared, however many others agree.\n5. **What could hide.** If a fraction f of trainings fails, the chance that none of n fails is (1 - f)^n. The report states u(n) = 1 - 0.05^(1/n): a failure mode rarer than that has more than a 1 in 20 chance of leaving no trace.\n')
w('The claim is about the **median** training: more than half of all trainings. It is not about the mean over trainings, which a single rare catastrophic training can move arbitrarily and which no method can bound from a handful of replications, and it is not a prediction for the next training.\n')
w('| Family (variant-budget cells) | ' + ' | '.join(F['minimumTrainingsByFamily'].keys()) + ' |\n|---|' + '---|' * len(F['minimumTrainingsByFamily']))
w('| Minimum trainings (all agreeing) | ' + ' | '.join(str(v) for v in F['minimumTrainingsByFamily'].values()) + ' |\n')
w('The family of this statement is the number of (variant, budget) cells of the study, because each cell can carry at most one declaration; the comparisons with the other actions inside a cell are covered by the certificates\' union bound and by the argument in step 2. (The 5.5 intervals keep their own, larger family, which counts every action value, pair and quality slot.) One variant at one budget needs 6 agreeing trainings, three variants at three budgets need 9. The Quick (2 trainings) and Standard (5) presets can never declare a best action; Deep (10) can for studies of up to 20 cells.\n')
w('| Trainings | ' + ' | '.join(F['undetectableFailureRateByTrainings'].keys()) + ' |\n|---|' + '---|' * len(F['undetectableFailureRateByTrainings']))
w('| A failure rarer than this probably leaves no trace | ' + ' | '.join(pct(v, 0) for v in F['undetectableFailureRateByTrainings'].values()) + ' |\n')
w('## 3. Protocol\n')
w('`source/tools/statistical_validation56.py`, run against `source/tests/study53_probe.cpp` compiled from the release source, so every verdict comes from the shipped aggregation code. Data and truths are generated with NumPy; reference probabilities come from SciPy. The protocol was written to `validation/5.6/statistics/formal/protocol.json` before the first trial.\n')
w('- Trials: %d per exact-evaluation scenario, %d per sampled-evaluation scenario. Seed %d. Margin %.2f. Payoffs in [-20, 20].' % (P['trials'], max(400, P['trials'] // 8), P['seed'], P['margin']))
w('- Truth for a declaration: ' + P['truthForDeclaration'] + '.')
for k, v in P['evaluationModels'].items(): w('- Evaluation model `%s`: %s.' % (k, v))
w('- Pass rules:')
for k in ('F', 'R', 'N', 'A', 'P'): w('  - **%s**: %s' % (k, P['passRules'][k]))
w('- Rule history (recorded before the formal run): ' + P['passRules']['ruleHistory'] + '\n')
w('## 4. Results\n')
w('**Overall: %s.**%s\n' % ('every pass rule held' if R['passed'] else 'NOT every pass rule held', '' if R['passed'] else ' Failures: ' + '; '.join(R['failures'])))
w('### F. Formulas\n')
w('Binomial tail against SciPy for 1 to 40 trainings: largest absolute difference %s. Minimum trainings, undetectable failure rate and order-statistic coverage agree with their reference values in every case.\n' % ('%.1e' % F['binomialTailMaxError']))
def tbl(group, cols):
    w('| Scenario | Trainings | Family | Evaluation | Trials | ' + ' | '.join(c[0] for c in cols) + ' |\n|---|---|---|---|---|' + '---|' * len(cols))
    for s in R['scenarios']:
        if s['group'] != group: continue
        sp = s['spec']; w('| %s | %d | %d | %s | %d | ' % (s['scenario'], sp['n'], sp['family'], sp['evaluation'], s['trials']) + ' | '.join(c[1](s) for c in cols) + ' |')
    w('')
w('### R. Refusal below the minimum\n')
tbl('R', [('Best action declared', lambda s: '%d of %d' % (s['counts']['declared'], s['trials'])), ('Verdict `insufficientReplication`', lambda s: '%d of %d' % (s['counts']['insufficient'], s['trials'])), ('5.5 verdict `ranked` (for comparison)', lambda s: pct(s['verdict55Ranked']['frequency']))])
w('With five agreeing trainings, or eight in a family of seven, 5.5\'s verdict was `ranked` in essentially every study; 5.6 keeps that verdict for the measured strategies and declares nothing.\n')
w('### N. The typical training does not favour the leader by the margin\n')
tbl('N', [('False declaration (95% Wilson)', lambda s: wil(s['falseDeclaration'])), ('False across-trainings `ranked`', lambda s: wil(s['falseAcrossRanked'])), ('`trainingsDisagree`', lambda s: pct(s['counts']['disagree'] / s['trials'])), ('5.5 `ranked`, false for the population mean', lambda s: pct(s['verdict55Ranked']['falseForPopulationMean']))])
w('The nominal level is 5% divided by the family. The scenarios with a Cauchy distribution of training outcomes have no mean at all; the sign test is unaffected. `N_majority_fail_n10` has 60% of trainings failing: the typical training is a failed one, and declaring the sound action would be false.\n')
w('### A. A fraction of trainings fails catastrophically\n')
tbl('A', [('A failure was drawn', lambda s: pct(s['counts']['failureObserved'] / s['trials'])), ('Failed and sound trainings both present', lambda s: '%d' % s['counts']['mixedObserved']), ('... and a best action declared', lambda s: '%d' % s['counts']['failureObservedAndDeclared']), ('... and not reported as `trainingsDisagree`', lambda s: '%d' % s['counts']['failureObservedNotReported']),
          ('Declared (no failure seen)', lambda s: pct(s['declared']['frequency'])), ('False declaration', lambda s: wil(s['falseDeclaration'])), ('Stated undetectable rate', lambda s: pct(s.get('undetectableFailureRate', 0), 0)), ('5.5 `ranked`, false for the population mean', lambda s: pct(s['verdict55Ranked']['falseForPopulationMean']))])
a6 = S.get('A_five_percent_fail_n6'); a20 = S.get('A_five_percent_fail_n20')
w('This is the scenario 5.5 could not resolve. What 5.6 does with it:\n')
w('- **Whenever a failed training is among the trainings together with sound ones, it is reported and nothing is declared** (zero exceptions in every scenario; with sampled evaluation the failed training is certified as favouring another action by its own interval).\n- **When no failure is drawn, a best action is declared, and that declaration is true**: with a 5%% failure rate, 95%% of all trainings do favour the leader. What used to be wrong was reading it as a statement about every training or about the average.%s\n- **The report says how much could be hidden.** With six trainings the stated rate is 39%%; with twenty, 14%%. A 5%% failure rate is far below either, and the result says so in words (`rareTrainingFailuresNotExcluded`). Detecting a 5%% failure rate with 95%% probability takes 59 trainings; no statistic computed from ten can do it.\n- The population mean in these scenarios is below the margin (one failure outweighs twenty successes). 5.5\'s `ranked`, whose second half is a model-based interval for that mean, was issued and false for the mean in the share of studies shown in the last column. 5.6 does not make a statement about the mean at all.\n' % (
    (' In %s of six-training studies and %s of twenty-training studies no failure was drawn.' % (pct(1 - a6['counts']['failureObserved'] / a6['trials'], 0), pct(1 - a20['counts']['failureObserved'] / a20['trials'], 0))) if a6 and a20 else ''))
w('### P. Power (descriptive)\n')
tbl('P', [('Best action declared', lambda s: pct(s['declared']['frequency'])), ('False declaration', lambda s: pct(s['falseDeclaration']['frequency']))])
w('A clear, consistent edge is declared as soon as the minimum number of trainings is reached, with exact evaluation and with sampled evaluation including a rare large payoff.\n')
w('## 5. The 5.5 intervals, re-tested\n')
if old is not None:
    fails = old.get('failures', old.get('fails'))
    w('`source/tools/statistical_validation55.py` (the complete 5.5 validation: formulas, the 13 scenarios of 5.4, 20 raw-sample scenarios, exact evaluation with non-Gaussian training variation) was run again against the probe built from the 5.6 source: %s. Its output is in `validation/5.6/statistics/v55-rerun/`. The 5.5 calculation identifier and code are unchanged; the probe now also emits the 5.6 fields, which that script ignores.\n' % ('all of its pass rules held' if not fails else 'failures: ' + json.dumps(fails)[:400]))
else:
    w('The 5.5 validation script was not re-run; see VALIDATION-5.6.md.\n')
w('## 6. What remains unresolved\n')
w('- **The mean over trainings.** Still model-based (Student t), still labelled so, still not calibrated. 5.6 does not improve it; it stops relying on it for the declaration and reports the median statement beside it.\n- **Rare training failures.** They cannot be excluded by a handful of trainings. 5.6 quantifies what could hide; it does not detect what is not in the sample.\n- **Sampled quality.** No calibrated interval; the figure is a restricted response measure, not exploitability, and not a probability of anything.\n- **Independence of trainings.** The sign test assumes trainings with different seeds are independent draws. They are by construction (separate random streams), but they share the abstraction, the fixture and the code: a defect common to all trainings is invisible to any replication-based method. Only an exact evaluation or an independent implementation can catch that.\n- **Multiplicity across budgets and variants.** The family is per budget, as in 5.5. A study that looks at many budgets and variants and reports the most favourable one is outside what these levels cover.\n- **Selection of the margin.** The EV margin is declared by the fixture before the study. Changing it after seeing results invalidates the levels.\n')
w('## References\n')
w('- Maurer, A. and Pontil, M. (2009). Empirical Bernstein bounds and sample variance penalization. COLT. (The per-training certificates; see STATISTICAL-VALIDATION-5.5.md.)\n- Dixon, W. J. and Mood, A. M. (1946). The statistical sign test. Journal of the American Statistical Association 41.\n- Bahadur, R. R. and Savage, L. J. (1956). The nonexistence of certain statistical procedures in nonparametric problems. Annals of Mathematical Statistics 27. (Why the mean has no distribution-free interval here.)\n')
(root / 'STATISTICAL-VALIDATION-5.6.md').write_text('\n'.join(o) + '\n'); print('STATISTICAL-VALIDATION-5.6.md written')
