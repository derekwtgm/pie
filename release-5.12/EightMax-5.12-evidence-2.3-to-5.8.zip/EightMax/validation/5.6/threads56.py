#!/usr/bin/env python3
"""EightMax 5.6: frozen-batch training with 1, 2 and 4 threads, 5.5 against 5.6.
Usage: python3 validation/5.6/threads56.py <release root> <5.5 mwcli> <5.6 mwcli> <out.json>
Games of tools/games48.js trained with 64 deals per update and per-deal action streams (the only mode in which the
trainer uses several threads; studies use one deal per update and run SEEDS side by side instead). For each game,
version and thread count: best wall time of three runs, sampled deals per second, and the SHA-256 of the saved state,
which must be the same for every thread count and both versions."""
import sys, json, subprocess, hashlib, pathlib, tempfile, os, platform
root, old, new, dest = pathlib.Path(sys.argv[1]).resolve(), sys.argv[2], sys.argv[3], sys.argv[4]; tmp = pathlib.Path(tempfile.mkdtemp(prefix='em56-thr-')); rows = []
for game, updates in [('flop6w', 3000), ('final8w', 3000), ('turn4', 6000), ('flop5', 4000)]:
    sp = tmp / 's.json'; subprocess.run(['node', str(root / 'source/tools/games48.js'), 'spec', game, str(sp), '977', json.dumps({'batchDeals': 64, 'actionStreams': 'deal', 'device': 'cpu'})], check=True, capture_output=True)
    hashes = set()
    for ver, cli in (('5.5', old), ('5.6', new)):
        for threads in (1, 2, 4):
            best = None
            for rep in range(3):
                r = subprocess.run([cli, str(sp), str(updates), str(threads), str(tmp / 's.state'), '256'], capture_output=True, text=True); assert r.returncode == 0, r.stderr[-300:]
                info = json.loads(r.stdout); best = info if best is None or info['wallSeconds'] < best['wallSeconds'] else best
            h = hashlib.sha256((tmp / 's.state').read_bytes()).hexdigest(); hashes.add(h)
            rows.append({'game': game, 'version': ver, 'threadsRequested': threads, 'threadsUsed': best['threads'], 'wallSeconds': best['wallSeconds'], 'dealsPerSecond': best['trainingDeals'] / best['wallSeconds'], 'trainingDeals': best['trainingDeals'], 'stateSha256': h, 'seconds': best['seconds']})
            print(game, ver, threads, round(best['wallSeconds'], 3), flush=True)
    for r in rows:
        if r['game'] == game: r['identicalAcrossThreadsAndVersions'] = len(hashes) == 1
json.dump({'environment': platform.platform(), 'logicalProcessors': os.cpu_count(), 'rows': rows, 'allIdentical': all(r['identicalAcrossThreadsAndVersions'] for r in rows)}, open(dest, 'w'), indent=1)
