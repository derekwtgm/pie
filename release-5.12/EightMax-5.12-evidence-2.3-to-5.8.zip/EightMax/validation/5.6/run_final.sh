#!/bin/bash
# The final validation chain on the final build. Usage: bash validation/5.6/run_final.sh <release root> <5.5 linux mwcli> <work dir>
# Logs go to <work dir>; evidence goes to validation/5.6/. Steps run even if an earlier one fails; exit codes are recorded.
# (The convergence run, the benchmarks and the Wine checks have their own commands: see VALIDATION-5.6.md.)
set -u
root=$(cd "$1" && pwd); old=$2; work=$3; mkdir -p "$work"; cd "$root"; S="$work/steps.txt"; : > "$S"
step() { name=$1; shift; echo "== $name $(date -u +%H:%M:%S)" | tee -a "$S"; "$@" > "$work/$name.log" 2>&1; echo "$name exit $?" | tee -a "$S"; }
mkdir -p validation/5.6/tests
EM_TEST_MWCLI="$root/build/linux/mwcli" EM_TEST_HOST="$root/build/linux/eightmax" ASAN_OPTIONS=detect_leaks=0 NODE_OPTIONS="--require=$root/validation/5.3/sanitizers/no-leaks.cjs" \
  node --test --test-concurrency=3 --test-reporter=tap source/tests/*.test.js > validation/5.6/tests/full-regression.tap 2> validation/5.6/tests/full-regression.stderr; echo "regression exit $?" | tee -a "$S"
tail -8 validation/5.6/tests/full-regression.tap | tr '\n' ' ' | tee -a "$S"; echo | tee -a "$S"
step final-checks python3 validation/5.6/final_checks.py . build/linux/mwcli "$old" validation/5.6/final-checks.json
rm -rf validation/5.6/identity; step identity python3 source/tools/identity56.py "$old" build/linux/mwcli validation/5.6/identity; rm -rf validation/5.6/identity/work
rm -rf validation/5.6/sanitizers; step sanitizers bash validation/5.6/sanitize56.sh . "$work/san"
rm -rf validation/5.6/unbiasedness; step unbiasedness sh validation/5.6/unbiasedness.sh . validation/5.6/unbiasedness
gcc -O2 -c source/native/json.c -o "$work/json.o" && g++ -std=c++20 -O2 -ffp-contract=off -ffunction-sections -fdata-sections -Wl,--gc-sections -Isource/native source/tests/study53_probe.cpp "$work/json.o" -o "$work/probe"
rm -rf validation/5.6/statistics/formal; step statistics56 python3 source/tools/statistical_validation56.py "$work/probe" validation/5.6/statistics/formal
rm -rf validation/5.6/statistics/v55-rerun; step statistics55 python3 source/tools/statistical_validation55.py "$work/probe" validation/5.6/statistics/v55-rerun
rm -rf validation/5.6/ui; mkdir -p validation/5.6/ui; step ui node source/tools/study_ui56.js build/linux/eightmax . validation/5.6/ui; rm -f validation/5.6/ui/reference.json
rm -rf validation/5.6/stability; step stability node source/tools/stability55.js build/linux/eightmax . validation/5.6/stability --minutes=6
echo "== done $(date -u +%H:%M:%S)" | tee -a "$S"
