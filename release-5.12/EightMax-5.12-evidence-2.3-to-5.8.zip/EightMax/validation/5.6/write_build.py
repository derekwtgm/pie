#!/usr/bin/env python3
"""Writes BUILD-5.6.md with the fingerprints of the files in the release root. Usage: python3 validation/5.6/write_build.py <release root>"""
import sys, json, hashlib, pathlib, subprocess
root = pathlib.Path(sys.argv[1]).resolve(); info = json.loads((root / 'BUILD-INFO.json').read_text())
sha = lambda n: hashlib.sha256((root / n).read_bytes()).hexdigest()
def ver(cmd):
    try: return subprocess.run(cmd, capture_output=True, text=True).stdout.splitlines()[0].strip()
    except Exception: return 'not available'
imports = 'not determined'
try:
    r = subprocess.run(['x86_64-w64-mingw32-objdump', '-p', str(root / 'EightMax.exe')], capture_output=True, text=True).stdout
    dlls = sorted({l.split(':')[1].strip() for l in r.splitlines() if 'DLL Name' in l}); imports = ', '.join('`%s`' % d for d in dlls)
except Exception: pass
rep = None
p = root / 'validation/5.6/build-reproducibility.json'
if p.exists(): rep = json.loads(p.read_text())
o = []; w = o.append
w('# Building EightMax 5.6\n')
w('Final source/build identifier: `%s`.' % info['build'])
w('Statistics identifiers: `study-5.5-bounded-eb-v1` (calibrated conditional intervals, unchanged), `study-5.6-replication-v1` (across-trainings verdicts, new) and `study-5.3-tfloor-bonferroni-v1` (model-based interval across trainings, unchanged).')
w('Study checkpoint format: `EightMax study checkpoint`, version 1 (unchanged; a checkpoint is tied to its build, so 5.5 study checkpoints are refused with the reason). Solver checkpoint formats are unchanged; a state trained by 5.5 with the default trainer continues under 5.6 to the same bytes.\n')
w('The complete source is included. The Windows programs are unsigned x64 PE executables with a statically linked language runtime and zlib; `EightMax.exe` imports only %s.\n' % imports)
w('## How the shipped executables were built\n')
w('They were **cross-compiled on Linux** and were **not** built or run on Windows.\n')
w('| Tool | Version used |\n|---|---|')
w('| Host | Ubuntu 24.04 container, x86-64, 4 logical processors, 16 GB |')
w('| Windows cross-compiler | %s (`g++-mingw-w64-x86-64-posix`, POSIX threads) |' % ver(['x86_64-w64-mingw32-g++-posix', '--version']))
w('| Windows zlib | `libz-mingw-w64-dev` 1.3.1 (static) |')
w('| Linux compiler | %s |' % ver(['gcc', '--version']))
w('| Node | %s |' % ver(['node', '--version']))
w('| Python | %s (NumPy and SciPy for the research and validation scripts only) |' % ver(['python3', '--version']))
w('| Wine (tests only) | %s |\n' % ver(['wine', '--version']))
w('This is the 5.5 toolchain. The compiler flags are those of 5.5: `-O2 -march=x86-64 -ffp-contract=off` for the multiway engine (strict IEEE arithmetic, no FMA contraction), AVX2 and SSE builds of the heads-up solver selected at run time.\n')
w('## Reproducing the build\n')
w('Requirements: Node, Python 3, GCC/G++ with C++20, zlib; a Linux host also needs the OpenSSL development libraries. For Windows binaries: MinGW-w64 with POSIX threads **and** its static zlib (`apt-get install mingw-w64 libz-mingw-w64-dev`; without the second package `mwcli.exe` does not link), or MSYS2 on Windows with `CC=gcc CXX=g++`. These are developer requirements. The Windows application needs none of them at run time.\n')
w('From the release root:\n')
w('```sh\nnode source/tools/build.js build\nsh source/native/build.sh linux "$PWD/build/native.html" "$PWD/build/linux"\nCC=x86_64-w64-mingw32-gcc-posix CXX=x86_64-w64-mingw32-g++-posix sh source/native/build.sh windows "$PWD/build/native.html" "$PWD/build/windows"\n```\n')
w('Then copy `build/windows/*.exe`, `build/EightMax-Offline.html` and `build/build-info.json` (as `BUILD-INFO.json`) to the release root, and the Linux programs to `validation/5.6/linux-bin`.\n')
w('```sh\nnode source/tools/verify_build.js .\n```\n')
w('must print `Verified the executables, interface and source: %s`.\n' % info['build'])
w('The fingerprint covers `source/native`, `web`, `wasm`, `tools`, `tests`, `studies` and the CI workflow, so editing a test or a tool also changes it. Documents in the release root and everything under `validation/` are outside it.\n')
if rep:
    w('**Reproducibility.** The three Windows executables were built a second time from the same tree into a different directory: %s.\n' % ('all three are byte-identical to the shipped files' if rep['identical'] else 'NOT byte-identical: ' + json.dumps(rep['files'])))
w('## Artifact fingerprints\n')
w('| File | SHA-256 |\n|---|---|')
for n in ['EightMax.exe', 'mwcli.exe', 'gpustress.exe', 'EightMax-Offline.html', 'BUILD-INFO.json']: w('| `%s` | `%s` |' % (n, sha(n)))
for n in ['mwcli', 'eightmax', 'gpustress']:
    if (root / 'validation/5.6/linux-bin' / n).exists(): w('| `validation/5.6/linux-bin/%s` | `%s` |' % (n, sha('validation/5.6/linux-bin/' + n)))
w('')
w('`SHA256SUMS.txt` lists every file of the archive except itself. The archive\'s own SHA-256 cannot be inside the archive; it is in `EightMax-Windows-5.6.identity.json`, delivered beside the ZIP, and in the final report.\n')
w('## Tests and packaging\n')
w('```sh\nbash validation/5.6/run_final.sh . <5.5 linux mwcli> /tmp/em56-final      # regression, final checks, identity matrix, sanitizers,\n                                                                      # expected increments, statistics, browser-driven UI, stability\npython3 source/tools/trainbench56.py <5.5 mwcli> build/linux/mwcli <fresh dir>   # on an idle machine\npython3 source/tools/bench56.py <5.5 mwcli> build/linux/mwcli <fresh dir>\npython3 validation/5.6/threads56.py . <5.5 mwcli> build/linux/mwcli <out.json>\npython3 validation/5.6/release56.py . output --wine                   # ZIP, clean extraction, manifest, smoke tests of the Windows programs under Wine\n```\n')
w('`release56.py` writes `SHA256SUMS.txt`, builds the ZIP, verifies its CRC, extracts that exact file into a new directory, checks every checksum and build identity there, and runs the smoke tests from the extracted copy.\n')
w('Wine note (unchanged from 5.5): in the development container Wine 9.0 aborts at start-up when given the session\'s very large environment. It runs normally with a minimal environment (`env -i HOME=... PATH=... WINEPREFIX=...`). The packaging smoke test also sets `LC_ALL=C.UTF-8`: without a UTF-8 locale Wine cannot create the Unicode-named temporary folder of one 4.9 self-test check, with the 5.5 and the 5.6 program alike. The wrappers used for the per-file regression run did not set it, which is why that self-test is among the Wine failures listed in VALIDATION-5.6.md while the packaged smoke test passes it. The regression suite was run against the Windows programs through small wrapper scripts that do this and pass on EightMax\'s own variables.\n')
w('The GitHub Actions workflow in `.github/workflows/windows.yml` builds and tests natively on a Windows runner. 5.6 adds two steps to it: `validate_windows56.ps1` and the whole regression suite on Windows. **The workflow was not run for 5.6** (no runner was reachable from the development session), so those two steps have never executed.\n')
w('## Reproducing the research\n')
w('- Convergence: `python3 source/tools/research56.py <5.5 mwcli> <5.6 mwcli> <fresh dir> --games ...` (one process per group of games), then `--analyze-only <dirs...> <out dir>`; `python3 validation/5.6/write_convergence.py .`.\n- Expected increments: `sh validation/5.6/unbiasedness.sh . <dir>`.\n- State identity with 5.5: `python3 source/tools/identity56.py <5.5 mwcli> <5.6 mwcli> <fresh dir>`.\n- Statistics: `python3 source/tools/statistical_validation56.py <probe> <fresh dir>`; `python3 validation/5.6/write_statistics.py .`.\n')
w('The unchanged 5.3, 5.4 and 5.5 Linux binaries are in `validation/5.3/linux-bin`, `validation/5.4/linux-bin` and `validation/5.5/linux-bin` (a ZIP does not keep the executable bit: `chmod +x` a copy). Each runner writes its plan before measuring and refuses to reuse an output directory.\n')
(root / 'BUILD-5.6.md').write_text('\n'.join(o) + '\n'); print('BUILD-5.6.md written')
