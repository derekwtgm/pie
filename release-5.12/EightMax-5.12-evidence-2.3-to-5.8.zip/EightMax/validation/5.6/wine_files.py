#!/usr/bin/env python3
"""Runs the regression suite against the Windows executables under Wine, ONE TEST FILE PER PROCESS with a time limit,
and then runs every file that had a failure or a timeout again with the 5.5 Windows executables through the same
wrappers (the control). A whole-suite run in one process was tried first and stalled inside one file; a per-file run
bounds that and records which file it was.
Usage: python3 validation/5.6/wine_files.py <release root> <wrappers 5.6 dir> <wrappers 5.5 dir> <out dir> [--limit seconds] [--jobs n]
Writes <out dir>/files/<name>.{56,55}.tap and <out dir>/per-file.json."""
import sys, re, json, subprocess, pathlib, os, time, signal
from concurrent.futures import ThreadPoolExecutor
root = pathlib.Path(sys.argv[1]).resolve(); w56, w55 = pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3]); out = pathlib.Path(sys.argv[4]); (out / 'files').mkdir(parents=True, exist_ok=True)
arg = lambda k, d: int(sys.argv[sys.argv.index(k) + 1]) if k in sys.argv else d
limit, jobs = arg('--limit', 600), arg('--jobs', 2)
src = root / 'source'; files = sorted(p.name for p in (src / 'tests').glob('*.test.js'))
def parse(t):
    res = {}
    for m in re.finditer(r'^(not ok|ok) \d+ - (.*?)(?: # (SKIP|TODO).*)?$', t, re.M): res[m.group(2)] = 'skip' if m.group(3) else ('pass' if m.group(1) == 'ok' else 'fail')
    err = {}
    for blk in re.split(r'\n(?=(?:not ok|ok) \d+ - )', t):
        m = re.match(r'not ok \d+ - (.*?)(?: # .*)?\n', blk)
        if m: e = re.search(r"error: (.*)", blk); err[m.group(1)] = (e.group(1) if e else '')[:240]
    return res, err, re.search(r'^# tests \d+', t, re.M) is not None
def run(f, wr, tag):
    env = dict(os.environ, EM_TEST_MWCLI=str(wr / 'mwcli-wine'), EM_TEST_HOST=str(wr / 'EightMax-wine')); tapf = out / 'files' / ('%s.%s.tap' % (f, tag)); t0 = time.time(); timed = False
    with open(tapf, 'w') as fo:
        p = subprocess.Popen(['node', '--test', '--test-concurrency=1', '--test-reporter=tap', str(src / 'tests' / f)], stdout=fo, stderr=subprocess.DEVNULL, env=env, cwd=str(src), start_new_session=True)
        try: p.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            timed = True; os.killpg(p.pid, signal.SIGKILL); p.wait()
    res, err, complete = parse(tapf.read_text(errors='replace'))
    r = {'file': f, 'seconds': round(time.time() - t0, 1), 'timedOut': timed, 'complete': complete and not timed, 'tests': len(res), 'passed': sum(v == 'pass' for v in res.values()), 'failed': sum(v == 'fail' for v in res.values()),
         'skipped': sum(v == 'skip' for v in res.values()), 'results': res, 'errors': err}
    print(tag, f, r['seconds'], 'TIMEOUT' if timed else '', r['tests'], r['passed'], r['failed'], flush=True); return r
def cause(name, e):
    if re.search(r'CUDA|GPU|device', name) or 'cuda' in e.lower(): return 'needs the Linux CUDA driver test double (a Linux library that a Windows program under Wine cannot load)'
    if 'C:\\\\users' in e or 'C:\\users' in e or 'ENOENT' in e: return 'the test reads or edits the host\'s save folder directly; under Wine the host reports a Windows path that the Linux test process cannot open'
    if 'cancelled' in e.lower() or 'timed out' in e.lower() or 'timeout' in e.lower(): return 'the test\'s own time limit, under the Wine process start-up cost'
    return 'other'
with ThreadPoolExecutor(jobs) as ex: r56 = list(ex.map(lambda f: run(f, w56, '56'), files))
bad = [r['file'] for r in r56 if r['failed'] or r['timedOut'] or not r['complete']]
with ThreadPoolExecutor(jobs) as ex: r55 = {r['file']: r for r in ex.map(lambda f: run(f, w55, '55'), bad)}
cats = {}; only56 = []; notin55 = []
for r in r56:
    c = r55.get(r['file'])
    for n, v in r['results'].items():
        if v != 'fail': continue
        k = cause(n, r['errors'].get(n, '')); d = cats.setdefault(k, {'cause': k, 'count56': 0, 'alsoFailing55': 0, 'tests': []}); d['count56'] += 1; d['tests'].append('%s: %s' % (r['file'], n))
        s = c['results'].get(n) if c else None
        if s == 'fail': d['alsoFailing55'] += 1
        elif s is None: notin55.append('%s: %s' % (r['file'], n))
        else: only56.append('%s: %s' % (r['file'], n))
tot = lambda rs, k: sum(r[k] for r in rs)
strip = lambda r: {k: v for k, v in r.items() if k not in ('results',)}
doc = {'method': 'one node --test process per test file, concurrency 1 inside the file, %d files at a time, %d s limit per file; Windows executables through Wine wrappers with a minimal environment' % (jobs, limit),
       'suite56': {'files': len(r56), 'filesComplete': sum(r['complete'] for r in r56), 'filesTimedOut': [r['file'] for r in r56 if r['timedOut']], 'tests': tot(r56, 'tests'), 'passed': tot(r56, 'passed'), 'failed': tot(r56, 'failed'), 'skipped': tot(r56, 'skipped')},
       'control55': {'files': sorted(r55), 'filesTimedOut': [f for f, r in r55.items() if r['timedOut']], 'tests': tot(r55.values(), 'tests'), 'passed': tot(r55.values(), 'passed'), 'failed': tot(r55.values(), 'failed'), 'skipped': tot(r55.values(), 'skipped')},
       'categories': list(cats.values()), 'only56': sorted(only56), 'failing56NotRunIn55': sorted(notin55),
       'perFile56': [strip(r) for r in r56], 'perFile55': [strip(r) for r in r55.values()]}
doc['reading'] = ('Every test that fails with the 5.6 Windows programs under Wine also fails with the 5.5 Windows programs under the same harness.' if not only56 and not notin55 else
                  '%d tests fail with 5.6 and pass with 5.5 under Wine; %d failing tests have no 5.5 result (new 5.6 tests, or the 5.5 file timed out).' % (len(only56), len(notin55)))
(out / 'per-file.json').write_text(json.dumps(doc, indent=1)); print(json.dumps({k: doc[k] for k in ('suite56', 'control55', 'only56', 'failing56NotRunIn55', 'reading')}, indent=1)); print([(c['cause'][:50], c['count56'], c['alsoFailing55']) for c in doc['categories']])
