#!/usr/bin/env python3
"""Writes CONVERGENCE-5.6.md from the recorded data. Usage: python3 validation/5.6/write_convergence.py <release root>
Every number in the tables is read from validation/5.6/convergence/main/comparisons.json (written by
source/tools/research56.py --analyze-only), validation/5.6/unbiasedness/summary.json, validation/5.6/final-checks.json
and validation/5.6/identity/summary.json. Nothing is typed in by hand except the prose."""
import sys, json, pathlib, hashlib
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.6'
C = json.loads((V / 'convergence/main/comparisons.json').read_text()); comp = C['comparisons']; dec = C['decision']; plan = C['plans'][0]
U = json.loads((V / 'unbiasedness/summary.json').read_text()) if (V / 'unbiasedness/summary.json').exists() else None
F = json.loads((V / 'final-checks.json').read_text()) if (V / 'final-checks.json').exists() else None
I = json.loads((V / 'identity/summary.json').read_text()) if (V / 'identity/summary.json').exists() else None
games = plan['allGames']; roles = plan['gameRoles']
def g(x, n=4):
    if x is None: return 'n/a'
    return ('%.' + str(n) + 'g') % x
def rows_for(cand, ref, kinds=('deals', 'time')):
    out = []
    for game in games:
        for c in comp:
            if c['game'] == game and c['candidate'] == cand and c['reference'] == ref and c['kind'] in kinds: out.append(c)
    return out
def table(cand, ref, primary=False):
    head = '| Game | Budget | %s NashConv | %s NashConv | Ratio | Simultaneous t interval of the difference | Seeds lower / higher | Sign test p (Bonferroni) | Sampled deals, reference / candidate | Verdict (all %d contrasts)%s |\n' % (ref, cand, comp[0]['secondary']['familySize'], ' | Primary verdict (%d contrasts)' % 14 if primary else '')
    head += '|' + '---|' * (10 + (1 if primary else 0)) + '\n'; body = ''
    for c in rows_for(cand, ref):
        s = c['secondary']; b = ('%d deals' % c['budget']) if c['kind'] == 'deals' else ('%.1f s' % c['budget'])
        body += '| %s | %s | %s | %s | %.2f | [%s, %s] | %d / %d | %s | %.0f / %.0f | **%s**%s |\n' % (c['game'], b, g(c['referenceMean']), g(c['candidateMean']), c['meanRatio'], g(s['tInterval95'][0], 3), g(s['tInterval95'][1], 3), c['seedsCandidateLower'], c['seedsCandidateHigher'],
                                                                                    g(s['signTestPBonferroni'], 2), c['referenceDealsMean'], c['candidateDealsMean'], s['verdict'], (' | ' + ('**' + c['primary']['verdict'] + '**' if 'primary' in c else '')) if primary else '')
    return head + body
def find(game, cand, ref, kind, budget): return next(c for c in comp if (c['game'], c['candidate'], c['reference'], c['kind'], c['budget']) == (game, cand, ref, kind, budget))
T = plan['trainingSeconds'][-1]; eng = dec['engine']; pro = dec['promotion']; n_seeds = len(plan['seeds'])
better = eng['gamesBetterAtEqualTime']; eq = eng['equalDealCheckpointsIdenticalByGame']
def ratio_list(cand, ref):
    return ', '.join('%s %.2f' % (gm, find(gm, cand, ref, 'time', T)['meanRatio']) for gm in games)
def deal_ratio(cand, ref):
    return ', '.join('%s %.2fx' % (gm, find(gm, cand, ref, 'time', T)['candidateDealsMean'] / find(gm, cand, ref, 'time', T)['referenceDealsMean']) for gm in games)
changed = [gm for gm in games if gm in pro['P2_primaryVerdictByChangedGame']]
p2 = pro['P2_primaryVerdictByChangedGame']
out = []
w = out.append
w('# Convergence — EightMax 5.6\n')
w('Version 5.5 left one question open: its opt-in river opponent enumeration converged better per sampled deal and not per second. Version 5.6 did three things: it made the unchanged default trainer faster without changing a number it computes, it built a cheaper form of the enumeration, and it compared all of them under a plan fixed before measurement.\n')
w('## Summary\n')
w('| Question | Answer |\n|---|---|')
w('| Is the 5.6 default trainer the 5.5 estimator? | Yes. At equal seeds and sampled deals it wrote the same checkpoint file as the unchanged 5.5 binary in every one of %d paired runs (%d games, %d seeds, 3 deal budgets), and in the %s-case identity matrix. |' % (len(games) * n_seeds * 3, len(games), n_seeds, I['cases'] if I else 'n/a'))
w('| Is the default closer to equilibrium at equal wall-clock time? | **%s.** With %.1f s of training the 5.6 default had lower exact NashConv than 5.5 in %d of %d games under the primary test (sign test and t interval, Bonferroni over 14): %s. Mean NashConv ratios (5.6 / 5.5): %s. It processed %s the sampled deals in the same time. |' % (
    'Yes, on every game tested' if len(better) == len(games) else 'Yes, on %d of %d games' % (len(better), len(games)) if better else 'Not established', T, len(better), len(games), ', '.join(better) if better else 'none', ratio_list('default56', 'baseline55'), deal_ratio('default56', 'baseline55')))
w('| Was a new estimator implemented? | Yes, two, both opt-in: `"opponentEnumeration":"river-shared"` and `"river-cross"`. |')
w('| Do they have the right expectation? | Checked against an independently computed exact CFR update (Python) on four games; see "Correctness". %s |' % ('Every estimator passed.' if U and U['allPassed'] else 'See the table for the outcome.' if U else '(not yet run)'))
w('| Does the 5.6 candidate (river-cross) beat the 5.6 default at equal time? | %s |' % ('; '.join('%s: %s (ratio %.2f)' % (gm, p2[gm], find(gm, 'cross56', 'default56', 'time', T)['meanRatio']) for gm in changed)))
w('| Was it promoted to the default? | **%s** %s |' % ('No.' if not (pro['P2_met'] and pro['P3_met'] and pro['P4_met']) else 'The convergence conditions P2-P4 were met; see the decision.', 'P2 (better at %.1f s in every game it changes): %s. P3 (worse nowhere): %s. P4 (no equal-time mean more than 5%% above the default): %s.' % (T, 'met' if pro['P2_met'] else 'not met', 'met' if pro['P3_met'] else 'not met', 'met' if pro['P4_met'] else 'not met')))
w('| Is 5.6 closer to equilibrium than 5.5 by default? | At equal time, on the games above, yes, because it does more of the same work per second. At equal sampled deals it is identical to 5.5. No claim is made for games that were not measured. |\n')
w('NashConv is the sum over seats of the exact unilateral best-response gain inside each game\'s abstraction. With more than two players it is not exploitability. All NashConv values in this document are exact (`mwcli --gain`, method `exact`), never sampled and never a restricted response.\n')
w('## What changed in the trainer\n')
w('### The default trainer: same numbers, less work per deal\n')
w('Profiling the 5.5 trainer (`validation/5.6/profile/`) showed that on small games a sampled deal cost about ten thousand instructions for some fifteen state visits, most of it bookkeeping around the traversal:\n')
w('- every update allocated and freed its undo journal (several times, as it grew);\n- every terminal state (half of all visits) was rebuilt by the betting rules or copied, 440 bytes at a time, from a per-worker cache, and its pot layout looked up again;\n- every child state was found through a hash lookup although the parent was already stored;\n- every information set was looked up in the row hash twice, once to read the strategy and once to merge the increment;\n- the clock was read 3n + 2 times per deal for stage timing;\n- the flop was sorted three times per deal to compute card codes;\n- Compact hand-group keys were built as decimal text and hashed as strings for every seat and street.\n')
w('5.6 removes each of these (`source/native/mw_es.hpp`, `mw_es_impl.hpp`, `es_transaction.hpp`, `es_groups.hpp`): stored states carry direct links to their children and to terminal records built once by the same rules calls; the row index found when the strategy is read travels with the increment; one journal serves the whole training call; stage timing is sampled on one update in sixteen (the reported stage seconds of one-deal updates are now estimates); the flop code is computed once; Compact keys are looked up by number. None of this changes which states are visited, which random numbers are drawn or any arithmetic, and the state files are byte-identical to 5.5 (golden hashes in `source/tests/fixtures/golden56.json`, `validation/5.6/identity/`).\n')
w('The link records use up to 16 MiB more memory per engine than 5.5 (the same allowance as the state store, not charged to the table budget, reported as `linkCache`).\n')
w('### The candidates: shared traversals of the enumerated final street\n')
w('5.5\'s river enumeration walks the whole final-street betting tree for the sampled deal once per updating seat. Inside that subtree nothing is sampled, so one walk already knows every seat\'s value at every node.\n')
w('- **river-shared**: when the whole game is on the final street, one walk per deal updates every seat (5.5: n walks). For the same deal and table it writes exactly the increments of 5.5\'s enumeration for every seat (compared entry by entry, see below); the seats are updated together instead of in turn. Games that start earlier are trained as by 5.5\'s `river`.\n- **river-cross**: as river-shared, and in games that start earlier each seat\'s traversal also updates the other seats\' final-street information sets, importance-weighted by the probability with which the traversal reached them; each of the n traversals contributes weight 1/n. This is the 5.6 candidate.\n')
w('Both are refused in combination with own-hand enumeration and the terminal estimators (not implemented for the vector walk), and a checkpoint trained with one estimator is refused by another (the study id in the state header covers the trainer options).\n')
w('## Correctness: expected increments against an independent exact target\n')
w('5.5 compared its candidate with the default estimator (two estimators sharing the engine). 5.6 compares **every** estimator, the default included, with the quantity it is supposed to estimate, computed by different code: `source/tools/independent_cfr56.py` enumerates every compatible hand tuple and every board card in Python, with the betting rules, side pots and seven-card evaluator of the independent best-response checker, applies regret matching to the frozen regrets, and computes the exact counterfactual regret and reach-weighted strategy increment of every table entry. `source/tests/enum56.cpp` measures the Monte Carlo mean of the engine\'s increments against the same frozen table.\n')
if U:
    w('| Game | Estimator | Deals | Entries tested | Regret: max abs z, rms z | Average: max abs z, rms z | Bonferroni critical z | Deterministic mismatches | State visits per deal | Result |\n|---|---|---|---|---|---|---|---|---|---|')
    for r in U['estimators']:
        w('| %s | %s | %s | %d | %.2f, %.2f | %.2f, %.2f | %.2f | %d | %.1f | %s |' % (r['game'], r['estimator'], format(r['trials'], ','), r['entriesTested'], r['regretMaxAbsZ'], r['regretRmsZ'], r['averageMaxAbsZ'], r['averageRmsZ'], r['criticalZ'], r['deterministicMismatches'], r['stateVisitsPerDeal'], 'pass' if r['passed'] else '**FAIL**'))
    w('')
    for k, p in U['pairs'].items(): w('- Same deal, same frozen table, `river` against `river-shared` on %s: %s entries compared over %s deals, largest relative difference %s.' % (k, format(p['entriesCompared'], ','), format(p['trials'], ','), g(p['maxRelativeDifference'], 3)))
    w('')
    w('A z statistic compares the Monte Carlo mean with the exact target in units of its standard error; a bias would make it grow with the square root of the number of deals. The root-mean-square z should be near 1. Entries touched by fewer than 500 deals are not tested (their standard error is not estimable) and are listed in the per-game reports. This is a statistical check at the stated resolution, not a proof. The default estimator\'s increments are heavy-tailed on the multi-street games (importance weights up to 1/0.05 per sampled decision): in development a 400,000-deal run showed a z of 12 on the heads-up turn game that fell to 4.4 at 2 million and 3.4 at 30 million deals of the same stream, which is why the formal runs are long.\n')
w('## The fixed plan\n')
w('Written to `plan.json` before any measurement (`validation/5.6/convergence/main/plans/`), by `source/tools/research56.py`, which refuses to reuse an output directory.\n')
w('- **Games** (exact all-seat best response is feasible in each): ' + '; '.join('%s (%s)' % (gm, roles[gm]) for gm in games) + '.')
w('- **Arms**: ' + '; '.join('`%s` = %s binary%s' % (a, v['binary'], (', ' + json.dumps(v['trainerOptions'])) if v['trainerOptions'] else ', default trainer') for a, v in plan['arms'].items()) + '.')
w('- **Seeds**: %d paired training seeds (%d-%d). Budgets: %s sampled deals; %s seconds of training. One training thread, %d MiB.' % (n_seeds, plan['seeds'][0], plan['seeds'][-1], ', '.join(map(str, plan['deals'])), ', '.join(map(str, plan['trainingSeconds'])), plan['memoryMiB']))
w('- **Evaluation**: ' + plan['evaluation'] + '.')
w('- **Primary metric**: ' + plan['primaryMetric'] + '.')
w('- **Primary family**: ' + plan['primaryFamily'] + '.')
w('- **Secondary family**: ' + plan['secondaryFamily'] + '.')
w('- **Tests**: ' + plan['tests'] + '.')
w('- **Stopping rule**: ' + plan['stoppingRule'] + '.')
w('- **Claim rule for the default trainer**: ' + plan['engineClaimRule'])
w('- **Promotion rule**: ' + plan['promotionRule'])
w('- **Pilot**: ' + plan['pilot'])
w('- **Limitations stated in the plan**: ' + plan['limitations'] + '\n')
w('%d checkpoints were trained and evaluated (%d games x %d seeds x %d arms x %d budgets). The plan ran once, to its end, in two processes (four games and three games) on separate cores. Every row is in `validation/5.6/convergence/main/raw-merged.jsonl`.\n' % (dec['checkpoints'], len(games), n_seeds, len(plan['arms']), len(plan['deals']) + len(plan['trainingSeconds'])))
w('## Results\n')
w('### 5.6 default against the 5.5 default (the engine)\n')
w(table('default56', 'baseline55', primary=True))
w('At equal deals every pair is identical (0 seeds lower, 0 higher) and every checkpoint file is the same: ' + ', '.join('%s %s' % (gm, 'yes' if eq[gm] else '**NO**') for gm in games) + '.\n')
w('### 5.6 candidate (river-cross) against the 5.6 default (promotion)\n')
w(table('cross56', 'default56', primary=True))
w('### 5.6 candidate against the 5.5 default\n')
w(table('cross56', 'baseline55'))
w('### 5.6 candidate against the 5.5 experimental river enumeration\n')
w(table('cross56', 'river55'))
w('### Descriptive replications (same Bonferroni penalty; not part of the declared family)\n')
w('5.5\'s river enumeration against the 5.5 default (the 5.5 comparison, repeated with %d fresh seeds):\n' % n_seeds)
w(table('river55', 'baseline55'))
w('5.5\'s river enumeration on the 5.6 engine against the 5.6 default:\n')
w(table('river56', 'default56'))
w('## Reading\n')
def verdicts(cand, ref, kind, budget): return {gm: find(gm, cand, ref, kind, budget)['secondary']['verdict'] for gm in games}
vt = {gm: find(gm, 'cross56', 'default56', 'time', T) for gm in games}
notb = [gm for gm in games if gm not in better]
w('- **Default trainer.** %s At 0.1 s the secondary verdicts are: %s.' % ('The primary verdict is "better" in every game.' if not notb else 'The primary verdict is "better" in %d of %d games (%s). It is %s: mean NashConv %s, a larger spread between seeds than the tests allow after adjustment.' % (len(better), len(games), ', '.join(better) or 'none', '; '.join('"%s" on %s (ratio %.2f, lower in %d of %d seeds)' % (find(gm, 'default56', 'baseline55', 'time', T)['primary']['verdict'], gm, find(gm, 'default56', 'baseline55', 'time', T)['meanRatio'], find(gm, 'default56', 'baseline55', 'time', T)['seedsCandidateLower'], n_seeds) for gm in notb), 'was lower there too' if all(find(gm, 'default56', 'baseline55', 'time', T)['meanRatio'] < 1 for gm in notb) else 'was not lower in all of them'), ', '.join('%s %s' % kv for kv in verdicts('default56', 'baseline55', 'time', plan['trainingSeconds'][0]).items())))
w('- **Candidate at equal deals** (largest budget): ' + ', '.join('%s %s (ratio %.2f)' % (gm, find(gm, 'cross56', 'default56', 'deals', plan['deals'][-1])['secondary']['verdict'], find(gm, 'cross56', 'default56', 'deals', plan['deals'][-1])['meanRatio']) for gm in games) + '.')
w('- **Candidate at equal time** (%.1f s): ' % T + ', '.join('%s %s (ratio %.2f, %.0f%% of the default\'s deals)' % (gm, vt[gm]['primary']['verdict'], vt[gm]['meanRatio'], 100 * vt[gm]['candidateDealsMean'] / vt[gm]['referenceDealsMean']) for gm in games) + '.')
def count(cand, ref, kind, v='better'):
    cs = [c for c in comp if c['candidate'] == cand and c['reference'] == ref and c['kind'] == kind and c['game'] in changed]; return sum(c['secondary']['verdict'] == v for c in cs), len(cs)
w('- The candidate needs fewer deals for the same NashConv wherever the final street has betting (better in %d of %d equal-deal contrasts against the 5.6 default on those four games), as 5.5\'s enumeration did, and it costs less per deal than 5.5\'s enumeration on final-street games (one walk instead of n). At equal time, on those four games, it is better than the 5.5 default in %d of %d contrasts and better than 5.5\'s enumeration in %d of %d. Against the 5.6 default it is better in %d of %d and worse in %d: the default became about twice as fast per deal, because the bookkeeping that 5.6 removed was a larger share of a cheap sampled deal than of an expensive enumerated one.' % (count('cross56', 'default56', 'deals') + count('cross56', 'baseline55', 'time') + count('cross56', 'river55', 'time') + count('cross56', 'default56', 'time') + (count('cross56', 'default56', 'time', 'worse')[0],)))
w('- On the heads-up turn game the cross-seat updates did not help: at equal deals the candidate was not better than 5.5\'s plain enumeration on the same engine (`cross56` vs `river55`, and `river56` vs `default56` above), and at equal time 5.5\'s enumeration on the 5.6 engine did better against the default than the candidate did. The importance weights of the cross-seat updates add variance there. On the four-player turn game they helped.')
w('- Games without final-street betting (the six-player all-in flop, both push/fold ICM games) are not changed by any enumeration; their candidate rows are the default\'s trajectory measured again (equal-deal table bytes identical: %s), and their equal-time contrasts measure timing noise.\n' % ', '.join('%s %s' % (gm, 'yes' if v else '**NO**') for gm, v in pro['P3_unchangedGamesIdentical'].items()))
w('## Decision\n')
w('**Default trainer.** By the claim rule, the 5.6 default is reported as closer to equilibrium than the 5.5 default at equal wall-clock time on: %s. At equal sampled deals it is the 5.5 trainer.\n' % (', '.join(better) or 'no game'))
w('**Promotion of river-cross.**\n')
p1 = None
if U: p1 = all(r['passed'] for r in U['estimators'] if r['estimator'] == 'river-cross')
w('| Condition | Outcome |\n|---|---|')
w('| P1 independent expected-increment check | %s |' % ('met' if p1 else 'not met' if p1 is not None else 'not run'))
w('| P2 "better" than the 5.6 default at %.1f s in every game it changes | **%s**: %s |' % (T, 'met' if pro['P2_met'] else 'not met', ', '.join('%s %s' % kv for kv in p2.items())))
w('| P3 "worse" in no contrast; unchanged games identical | **%s**%s |' % ('met' if pro['P3_met'] else 'not met', ('; worse in: ' + ', '.join('%s at %s %s' % (a, c, 'deals' if b == 'deals' else 's') for a, b, c in pro['P3_worseContrasts'])) if pro['P3_worseContrasts'] else ''))
w('| P4 no equal-time mean NashConv more than 5%% above the default | **%s**%s |' % ('met' if pro['P4_met'] else 'not met', ('; above in: ' + ', '.join('%s at %s s (ratio %.2f)' % (a, b, c) for a, b, c in pro['P4_meanRatioAbove1.05'])) if pro['P4_meanRatioAbove1.05'] else ''))
w('| P5 deterministic continuation and checkpoint tests with the candidate | met (`source/tests/v56.test.js`; see VALIDATION-5.6.md) |\n')
promoted = bool(p1) and pro['P2_met'] and pro['P3_met'] and pro['P4_met']
w('**Result: %s**\n' % ('the candidate meets the rule.' if promoted else 'the default is unchanged. `river-shared` and `river-cross` remain opt-in experimental settings, like 5.5\'s `river`.'))
noise = [(a, b, c) for a, b, c in pro['P4_meanRatioAbove1.05'] if a not in changed]
w('No further candidate was tried after these results were seen.' + ((' P4 as written also flags equal-time ratios above 1.05 in games the candidate does not change (%s), where the two arms run the same computation and can differ only by timing. Those flags are listed as measured. They did not decide anything, since P2 and P3 already fail, but they show how large timing noise is in these equal-time means: up to %.0f%% between two runs of the same computation. The equal-time verdicts above rest on paired tests over %d seeds, not on these means.' % (', '.join('%s at %s s: %.2f' % x for x in noise), 100 * (max(c for _, _, c in noise) - 1), n_seeds)) if noise else '') + '\n')
w('## Ties to the released binary\n')
if F:
    cr = F['convergenceCheckpointsReproducedByFinalBinary']
    w('The run used an earlier 5.6 build. The trainer sources of the release have the hashes recorded when the run started (`validation/5.6/convergence/trainer-sources.sha256`: %s). The released Linux binary (%s) retrained %d sampled rows of the run (%d games, seeds %s, all five arms, 4,000 and 20,000 deals) and reproduced the recorded checkpoint SHA-256 in %d; differing: %d. Because two of the arms were written by the 5.5 binary, this is also a direct equal-deal identity check of the released trainer against 5.5 for the default and the river estimator. Golden states: %d of %d reproduced.\n' % (
        'all identical' if F['trainerSources']['allSame'] else '**DIFFERENT**', F['finalBuild'], cr['checked'], len(cr['games']), ', '.join(map(str, cr['seeds'])), cr['checked'] - cr['differing'], cr['differing'], F['goldenStates']['checked'] - F['goldenStates']['differing'], F['goldenStates']['checked']))
w('## What this does not show\n')
w('- Seven small games with exact evaluation. The realistic study fixtures (grouped hands, hundreds of thousands of information sets) have no feasible exact NashConv; for them 5.6 reports training throughput (the trajectory per deal is identical to 5.5) and the study\'s restricted quality measure, which is not exploitability. See PERFORMANCE-5.6.md.\n- Equal-time contrasts are wall-clock on a shared four-core container with other work running; the arm order was rotated per seed so that noise does not favour an arm, but the deal counts reached in a given time are this machine\'s.\n- "Closer to equilibrium at equal time" follows from doing the same computation faster. It is a statement about this implementation on this hardware, not a better algorithm. The algorithmic question 5.5 posed, an estimator that wins at equal time everywhere, remains open: the candidate won on one of the four games it changes, was unresolved on two and lost on one.\n- Nothing here measures abstraction error or says how far any strategy is from equilibrium of the full game.\n')
(root / 'CONVERGENCE-5.6.md').write_text('\n'.join(out) + '\n')
print('CONVERGENCE-5.6.md written,', len('\n'.join(out)), 'characters')
