#!/usr/bin/env python3
"""Writes VALIDATION-5.6.md and RELEASE-5.6.md from the recorded evidence.
Usage: python3 validation/5.6/write_validation.py <release root> [<identity.json of the packaged archive>]"""
import sys, json, pathlib, subprocess, statistics
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.6'
ident = json.loads(pathlib.Path(sys.argv[2]).read_text()) if len(sys.argv) > 2 and pathlib.Path(sys.argv[2]).is_file() else None
J = lambda p: json.loads((V / p).read_text()) if (V / p).exists() else None
S = J('validation-summary.json'); info = json.loads((root / 'BUILD-INFO.json').read_text()); build = info['build']; reg = S['regression']
def ver(cmd):
    try: return subprocess.run(cmd, capture_output=True, text=True).stdout.splitlines()[0].strip()
    except Exception: return 'not available'
def first(pred): return next((i for i in S['items'] if pred(i)), None)
pre = J('tests/earlier-runs.json'); wf = S.get('wineFiles'); wv = S.get('wineV56'); smoke = ident['smokeTest'] if ident else None
TB = J('performance/trainbench/summary.json'); B = J('performance/bench/summary.json'); C = J('convergence/main/comparisons.json'); dec = C['decision']
o = []; w = o.append
w('# Validation — EightMax 5.6\n')
w('Build `%s`. What was executed, with which commands, where, and what was not. Classes: 1 independently tested; 2 verified by the project\'s tests, simulation or Wine; 3 written, awaiting physical hardware; 4 not implemented or unsuccessful. Machine-readable: `validation/5.6/validation-summary.json`.\n' % build)
w('## Environment\n')
w('| | |\n|---|---|')
w('| Machine | shared cloud container, 4 logical processors (Intel Xeon 2.1 GHz), 16 GB, Ubuntu 24.04, running as root |')
w('| Compilers | %s; %s |' % (ver(['gcc', '--version']), ver(['x86_64-w64-mingw32-g++-posix', '--version'])))
w('| Node, Python | %s; %s with NumPy and SciPy |' % (ver(['node', '--version']), ver(['python3', '--version'])))
w('| Windows execution | %s only. No Windows machine. |' % ver(['wine', '--version']))
w('| GPU | none. The CUDA driver test double (a simulated driver) on Linux only. |')
w('| Browser | Chromium through Playwright, for the Study tab |\n')
w('## Summary of every item\n')
w('| Area | Item | Class | Result |\n|---|---|---|---|')
for i in S['items']: w('| %s | %s | %d | %s |' % (i['area'], i['name'], i['class'], {True: 'passed', False: 'not passed / not met', None: 'not executed'}[i['passed']]))
w('')
w('## 1. Baseline (before any change)\n')
b = J('baseline/baseline-5.5.json')
w('```sh\nsha256sum EightMax-Windows-5.5.zip                 # %s = identity file\nunzip -q EightMax-Windows-5.5.zip && cd EightMax\nsha256sum -c SHA256SUMS.txt                        # %d OK, 0 failed\nnode source/tools/build.js build                   # EightMax 5.5 build %s\nsh source/native/build.sh linux "$PWD/build/native.html" "$PWD/build/linux"\nnode --test --test-concurrency=3 source/tests/*.test.js   # %d tests, %d passed, %d failed, %d skipped\n```\n' % (b['archiveSha256'], b['manifestEntriesVerified'], b['build'], b['regressionOnRebuiltLinuxBinaries']['tests'], b['regressionOnRebuiltLinuxBinaries']['pass'], b['regressionOnRebuiltLinuxBinaries']['fail'], b['regressionOnRebuiltLinuxBinaries']['skipped']))
w('The untouched extraction is kept read-only; its Linux and Windows 5.5 programs are the reference in every comparison below. Evidence: `validation/5.6/baseline/`. A first attempt at the baseline regression was started in the working copy and stopped when source edits began there; it is kept, marked aborted, and not used.\n')
w('## 2. Regression suite\n')
w('```sh\nEM_TEST_MWCLI=build/linux/mwcli EM_TEST_HOST=build/linux/eightmax node --test --test-concurrency=3 --test-reporter=tap source/tests/*.test.js\n```\n')
w('**Final build: %d tests, %d passed, %d failed, %d skipped.** `validation/5.6/tests/full-regression.tap`.\n' % (reg['tests'], reg['passed'], reg['failed'], reg['skipped']))
for s in reg['skippedTests']: w('- Skipped: "%s": %s. It needs a non-root account; the limitation is the container\'s.' % (s['name'][:150], s['reason'] or 'environment'))
for f in reg['failures']: w('- **Failed:** "%s"' % f)
w('')
if pre:
    w('Complete runs made before the recorded one are kept, with the cause of every failure:\n')
    w('| Run | Tests | Passed | Failed | Cause of the failures |\n|---|---|---|---|---|')
    for r in pre['runs']: w('| %s | %d | %d | %d | %s |' % (r['what'], r['tests'], r['passed'], r['failed'], r['cause']))
    w('')
w('New tests (`source/tests/v56.test.js`, 15): golden states of the 5.5 trainer with two-part continuation; identity with the archived 5.5 binary on fresh seeds and on grouped fixtures; the training report; the experimental estimators (options, refusals, effect on other games); deterministic continuation of the candidates and refusal of another trainer\'s state; shared walk against 5.5\'s enumeration, entry by entry; every estimator against the independent exact CFR update, including a deliberately biased dump that must fail; compact tables and passive runouts against the 5.5 code paths with 32 and 1,024 MiB caches; an exact study against the 5.5 evaluator paths; the replication formulas and verdicts; certificates with sampled evaluation; the study document, printed summary and interface helpers; interrupted and resumed study with a candidate, another build and another trainer refused; the checkpoint lock; seed counts beyond the fixture list.\n')
w('Existing tests edited: one. `v52.test.js` expected `seeds=99` to be refused with "seeds must be 1 to the number of seeds"; a count beyond the fixture\'s list is now allowed up to 64, so the expected message is "seeds must be a count from 1 to 64". No assertion was removed.\n')
w('| Required category | Where it is covered |\n|---|---|')
for a, c in [('Mathematical correctness', 'identity matrix and golden states against 5.5; `enum56.cpp` + `independent_cfr56.py`; `independent_br48.py` (4.8); 5.5 payoff-bound tests'), ('Training convergence', 'CONVERGENCE-5.6.md (fixed plan); `v56` candidate tests'), ('Independent evaluation', 'exact NashConv by `mwcli --gain`; Python best-response and CFR references'),
             ('Statistical calibration', '`statistical_validation56.py` and the re-run of `statistical_validation55.py`; probe tests in `v53`-`v56`'), ('ICM and multiway', '`v56` evaluator tests on four-player ICM, eight-player ICM, five- and six-player flops; `bench56.py` evaluation section; 4.5 ICM kernel tests'),
             ('CPU parallelism', 'identity matrix with 1-4 threads; `threads56.py`; ThreadSanitizer runs'), ('Checkpoint recovery', '`v55` and `v56` study checkpoint tests; `stability55.js`; cross-version continuation'), ('Memory limits', '1 MiB table budget in the identity matrix; process memory budget test (`v55`); compact tables with a 32 MiB cache'),
             ('File corruption handling', 'damaged manifests and states (`v55`, `v56`), hash-valid manifest of another build, 3.x-4.x checkpoint store fault injection'), ('Cross-platform reproducibility', 'golden states and the 5.6 test file under Wine; Windows and Linux states compared byte for byte'), ('Application startup', 'desktop host in the regression suite, in the browser-driven run and in the packaged smoke test under Wine'), ('Desktop host and command line', 'both drive `study52.hpp`; `v52`-`v56` use both')]: w('| %s | %s |' % (a, c))
w('')
w('## 3. Trainer identity, final-binary checks, expected increments\n')
fc = J('final-checks.json'); idn = J('identity/summary.json'); u = J('unbiasedness/summary.json')
w('```sh\npython3 source/tools/identity56.py <5.5 mwcli> build/linux/mwcli validation/5.6/identity      # %d cases, %d failures\npython3 validation/5.6/final_checks.py . build/linux/mwcli <5.5 mwcli> validation/5.6/final-checks.json   # %d checkpoints, %d differing; %d golden states, %d differing\nsh validation/5.6/unbiasedness.sh . validation/5.6/unbiasedness                                 # %s\n```\n' % (idn['cases'], idn['failures'], fc['convergenceCheckpointsReproducedByFinalBinary']['checked'], fc['convergenceCheckpointsReproducedByFinalBinary']['differing'], fc['goldenStates']['checked'], fc['goldenStates']['differing'], ('%d estimator-game runs, all passed' % len(u['estimators'])) if u and u['allPassed'] else 'see summary.json'))
w('The identity matrix records one bookkeeping difference from 5.5 and does not require it to match: the high-water mark of transient allocations (`scratchPeakBytes`) moves by up to a few kilobytes because the undo journal is now kept for the whole training call. The transient budget and the per-deal limit are unchanged. Tables are in CONVERGENCE-5.6.md.\n')
w('## 4. Convergence\n')
w('```sh\ntaskset -c 0 python3 source/tools/research56.py <5.5 mwcli> <5.6 mwcli> convA --games hu-river,hu-turn,river3-chip,turn4\ntaskset -c 1 python3 source/tools/research56.py <5.5 mwcli> <5.6 mwcli> convB --games flop6,final8,bubble4\npython3 source/tools/research56.py <5.5 mwcli> <5.6 mwcli> convA convB validation/5.6/convergence/main --analyze-only\n```\n')
w('%s checkpoints, plan complete: %s. The two processes ran while other development work used the other processors; the equal-time contrasts are paired by seed with rotated arm order. Result and decision: CONVERGENCE-5.6.md.\n' % (format(dec['checkpoints'], ','), 'yes' if dec['complete'] else 'NO'))
w('## 5. Statistics\n')
st = J('statistics/formal/results.json')
w('```sh\npython3 source/tools/statistical_validation56.py <probe built from the release source> validation/5.6/statistics/formal    # %s\npython3 source/tools/statistical_validation55.py <the same probe> validation/5.6/statistics/v55-rerun                  # %s\n```\n' % ('passed' if st and st['passed'] else 'see results.json', 'passed' if (first(lambda i: i['name'].startswith('5.5 bounded-payoff')) or {}).get('passed') else 'see the folder'))
w('Two development passes of the 5.6 script (800 trials) are kept in `validation/5.6/statistics/development-pass*`. They led to two corrections of the pass rules for the adversarial scenarios, recorded in the protocol under `ruleHistory`; no threshold was changed and no scenario removed. STATISTICAL-VALIDATION-5.6.md has the results.\n')
w('## 6. Sanitizers\n')
w('```sh\nbash validation/5.6/sanitize56.sh . <work dir>\n```\n')
for i in S['items']:
    if i['area'] == 'sanitizers': w('- %s: **%s** %s' % (i['name'], 'passed' if i['passed'] else 'not clean', json.dumps(i['detail'])[:400]))
w('')
w('Leak checking is limited to that one study, as in 5.5: LeakSanitizer needs process tracing, which this container restricts for the test harness.\n')
w('## 7. Interface and stability\n')
ui = first(lambda i: i['area'] == 'interface'); sb = first(lambda i: i['area'] == 'stability')
w('```sh\nnode source/tools/study_ui56.js build/linux/eightmax . validation/5.6/ui          # %s\nnode source/tools/stability55.js build/linux/eightmax . validation/5.6/stability --minutes=6   # %s\n```\n' % (('%d of %d checks' % (ui['detail']['checksPassed'], ui['detail']['checksTotal'])) if ui else 'not run', ('%s' % ('passed' if sb['passed'] else 'NOT passed')) if sb else 'not run'))
if ui and ui['detail']['failed']: w('Failed interface checks: ' + '; '.join(ui['detail']['failed']) + '\n')
w('The browser run starts a study in the Study tab, stops it, kills the host, resumes in a new host, compares with an uninterrupted command-line study, checks the 5.6 replication line and warnings in the panel, discards the study and opens a 5.4 result file. Linux host only; the Windows host was not driven by a browser.\n')
w('## 8. Performance measurements\n')
w('```sh\npython3 source/tools/trainbench56.py <5.5 mwcli> build/linux/mwcli validation/5.6/performance/trainbench\npython3 source/tools/bench56.py <5.5 mwcli> build/linux/mwcli validation/5.6/performance/bench --eval-timeout 300\npython3 validation/5.6/threads56.py . <5.5 mwcli> build/linux/mwcli validation/5.6/performance/threads.json\n```\n')
w('Results: PERFORMANCE-5.6.md. %s\n' % (J('performance/conditions.json') or {}).get('note', ''))
w('## 9. Windows programs (cross-compiled, run under Wine)\n')
w('```sh\nCC=x86_64-w64-mingw32-gcc-posix CXX=x86_64-w64-mingw32-g++-posix sh source/native/build.sh windows "$PWD/build/native.html" "$PWD/build/windows"\nEM_TEST_MWCLI=<wrapper: wine mwcli.exe> EM_TEST_HOST=<wrapper: wine EightMax.exe> node --test --test-concurrency=1 source/tests/*.test.js\npython3 validation/5.6/release56.py . output --wine\n```\n')
br = J('build-reproducibility.json')
if br: w('- Built twice from the same tree: %s.' % ('the three executables are byte-identical' if br['identical'] else 'NOT identical'))
if wv: w('- 5.6 test file against the Windows programs: %d tests, %d passed, %d failed (`validation/5.6/wine/`).' % (wv['tests'], wv['passed'], wv['failed']))
if wf:
    s = wf['suite56']; c = wf['control55']
    w('- Whole suite against the Windows programs, %s: %d of %d test files ran to completion%s; %d tests recorded, %d passed, %d failed, %d skipped.' % (wf['method'].split(';')[0], s['filesComplete'], s['files'], (' (timed out: ' + ', '.join('`%s`' % f for f in s['filesTimedOut']) + ')') if s['filesTimedOut'] else '', s['tests'], s['passed'], s['failed'], s['skipped']))
    w('- Control: the %d files with a failure or a timeout, run the same way with the **5.5** Windows programs: %d tests recorded, %d passed, %d failed%s. %s' % (len(c['files']), c['tests'], c['passed'], c['failed'], (' (timed out: ' + ', '.join('`%s`' % f for f in c['filesTimedOut']) + ')') if c['filesTimedOut'] else '', wf['reading']))
    if wf['categories']:
        w('\n| Cause of failure under Wine | Tests (5.6 programs) | Also failing with the 5.5 programs |\n|---|---|---|')
        for k in wf['categories']: w('| %s | %d | %d |' % (k['cause'], k['count56'], k['alsoFailing55']))
        w('')
    if wf.get('only56WhenThreeFilesRanAtOnce'): w('The %d failures without a 5.5 counterpart in the table are the `v37.test.js` tests explained above (isolated reruns: `validation/5.6/wine/isolated/`).\n' % len(wf['only56WhenThreeFilesRanAtOnce']))
    if wf['only56']: w('Failing with 5.6 and passing with 5.5 under Wine: ' + '; '.join(wf['only56']) + '\n')
    if wf['failing56NotRunIn55']: w('Failing with 5.6 and without a 5.5 result: ' + '; '.join(wf['failing56NotRunIn55']) + '\n')
    w('An earlier attempt ran the whole suite in one process; it stalled inside `v39.test.js` and was stopped (`validation/5.6/wine/suite-files-before-v39-then-stopped.tap`). These Wine results are a simulation of Windows, not Windows.\n')
if smoke:
    c56 = smoke.get('checks56', {})
    w('- Packaged archive, extracted into an empty folder, programs run under Wine: %s. Manifest %d entries verified; build ids %s; known game call frequency %.4f, EV gap %.4f BB (closed form 1/2 and 0); self-test %d passed, %d failed; host answered with build %s; study interrupted and resumed equals the uninterrupted one; golden states %s; candidates and refusal %s; exact evaluation %s; replication %s; checkpoint lock %s.' % (
        'passed' if smoke.get('passed') else 'NOT passed', ident['manifestEntries'], json.dumps(smoke['buildIds']), smoke['studyKnownGame']['callFrequency'], smoke['studyKnownGame']['evGapBB'], smoke['selftest49']['passed'], smoke['selftest49']['failed'], smoke['host']['build'],
        json.dumps(c56.get('goldenStatesIdenticalTo55')), json.dumps(c56.get('experimentalEstimators')), json.dumps(c56.get('exactEvaluation')), json.dumps(c56.get('replication')), json.dumps(c56.get('checkpointLock'))))
w('')
w('Wine is not Windows. It shows that the PE executables load, that the Windows code paths (file locking, process memory readings, sockets, threads) run, and that results equal the Linux build\'s. It does not show behaviour on NTFS, under Windows Defender, with real drivers, or on the target CPU.\n')
w('## 10. Not executed\n')
w('| Item | Why | What to do |\n|---|---|---|')
for i in S['items']:
    if i['passed'] is None: w('| %s | %s | %s |' % (i['name'], i['detail']['reason'], 'WINDOWS-TESTS-5.6.md'))
w('| Whole regression suite on real Windows | no runner reachable | the new CI step runs it |')
w('| Leak checking beyond one study | process tracing restricted in the container | run the ASan build with detect_leaks=1 on an unrestricted host |')
w('| The read-only-folder test | cannot fail as root | runs on any non-root account |')
w('| Browser-driven test of the Windows host | Chromium was run against the Linux host only | part of the manual steps |')
w('| Studies longer than a few minutes | time | Deep and Research presets on the target PC |\n')
w('## 11. Unresolved failures\n')
w(('None in the recorded Linux regression run.' if reg['failed'] == 0 else '%d in the recorded Linux regression run, listed in section 2.' % reg['failed']) + ' Under Wine, the failures listed in section 9 remain; each is attributed there.\n')
(root / 'VALIDATION-5.6.md').write_text('\n'.join(o) + '\n'); print('VALIDATION-5.6.md written')

# ------------------------------------------------------------------ RELEASE NOTES
better = dec['engine']['gamesBetterAtEqualTime']; games = C['plans'][0]['allGames']; sp = [f['speedupBest'] for f in TB['fixtures']] if TB else [0]
rows = B['rows'] if B else []
def best(workload, verx):
    rs = [r for r in rows if r['section'] == 'study' and r['workload'] == workload and r['version'] == verx and 'error' not in r]; return min(rs, key=lambda r: r['wallSeconds']) if rs else None
studies = list(dict.fromkeys(r['workload'] for r in rows if r['section'] == 'study')); sr = [best(n, '5.5')['wallSeconds'] / best(n, '5.6')['wallSeconds'] for n in studies if best(n, '5.5') and best(n, '5.6')] or [0]
o = []; w = o.append
w('# EightMax 5.6 — release report\n')
w('Build `%s`. Upgraded from 5.5 (`abe74607a4a0120b`), whose archive was verified first: archive hash, all 3,939 manifest entries, the source rebuilding to the same fingerprint, and its regression totals (567 passed, 1 skipped).\n' % build)
w('## Outcome by objective\n')
w('| Objective | Outcome |\n|---|---|')
w('| Actual GTO convergence at equal time | **Improved by speed, not by a new algorithm.** The default trainer computes what 5.5 computed, %.2fx to %.2fx faster on the study fixtures. Exact NashConv after equal wall-clock training was lower than 5.5\'s on %d of %d measured games (%s). |' % (min(sp), max(sp), len(better), len(games), 'unresolved on ' + ', '.join(g for g in games if g not in better) if len(better) < len(games) else 'all'))
w('| Opponent-enumeration candidate | **Built, validated, not promoted.** One shared walk of the final street for all seats, with cross-seat updates on earlier-street games. Correct in expectation; better than the 5.6 default at equal time on one of four games, worse on one, unresolved on two. Opt-in. |')
w('| Mathematical correctness | **Extended.** Every estimator, the default included, is now checked against an independently computed exact CFR update. No divergence found. |')
w('| Statistical confidence | **Scope made explicit.** New across-trainings verdict (exact sign test), minimum trainings, undetectable failure rate, warnings. A best action is declared only when supported for the measured strategies and for the typical training. |')
w('| Multiway and ICM evaluation | **Improved in the evaluator.** Compact showdown tables and passive runouts; values unchanged. |')
w('| Tournament functionality | **Preserved.** Rules, payoffs, fixtures, modes and formats unchanged; trainer output byte-identical to 5.5. |')
w('| Checkpoints | **Preserved and hardened.** Concurrent use refused; another build or trainer refused with the reason. |')
w('| CPU / GPU | CPU faster. **GPU untouched and untested**; no GPU figure is given. |')
w('| Regression testing | %d tests, %d passed, %d failed, %d skipped on Linux. The same suite was also run against the Windows programs under Wine. |' % (reg['tests'], reg['passed'], reg['failed'], reg['skipped']))
w('| Windows release | Built, byte-reproducible, smoke-tested under Wine from the packaged archive. **Not run on Windows.** |\n')
w('## What changed\n')
w('### Training (`CONVERGENCE-5.6.md`, `PERFORMANCE-5.6.md`)\n')
w('- Default trainer: direct child links and terminal records for stored betting states, row hints, one undo journal per call, sampled stage timing, one flop code per deal, number lookup for Compact keys. Same state bytes as 5.5.\n- New training report field `linkCache`. The `seconds` of one-deal training are estimates from one update in sixteen.\n- Experimental `opponentEnumeration`: `river-shared`, `river-cross` (command line and spec). Refused together with own-hand enumeration and the terminal estimators.\n')
w('### Exact evaluation\n')
w('- Showdown tables release their scores once their histogram is built; the shared table cap is 4,096.\n- Passive runouts use the showdown table.\n- `EM_EV_KEEP_SCORES=1` and `EM_EV_NO_PASSIVE=1` restore the 5.5 behaviour for comparison.\n')
w('### Statistics (`STATISTICAL-VALIDATION-5.6.md`)\n')
w('- `confidence.replication`, `confidence.evaluationKind`, `confidence.evaluationUncertainty`, `confidence.trainingVariation`, `bestAction`, `statisticalWarnings`, `replicationCalculation` in every study result. The 5.5 fields and their calculation are unchanged.\n- Headline: "Prefer X" only for a declared best action; otherwise "Leader among the measured trainings: X (no best action declared)".\n- `seeds=N` may exceed the fixture\'s list (up to 64).\n')
w('### Checkpoints\n')
w('- `study.lock` in a checkpoint directory while a study runs (operating-system lock; released when the process ends for any reason).\n')
w('### Windows validation\n')
w('- `Run 5.6 Windows validation.bat` / `source/tools/validate_windows56.ps1`; golden specs in `validation/5.6/windows/`.\n- CI workflow: the script and the whole regression suite on a Windows runner (not yet run).\n- Launchers: `Run 5.6 quick study.bat`, `Run 5.6 standard study.bat`, `Resume 5.6 standard study.bat`, `Run 5.6 replicated study.bat`.\n')
w('## Compatibility\n')
w('- Solver checkpoints (EMMW4, EMZ1) of 5.5 continue in 5.6 and the reverse, to the same bytes, for the trainers both versions have.\n- Study checkpoints are tied to their build: a saved 5.5 study is listed and refused with the reason; run it again.\n- Result files of 5.2 to 5.5 open as before. A 5.5 result keeps its 5.5 presentation; it carries no across-trainings verdict.\n- Study fixtures are unchanged. Defaults are unchanged: eight-handed, 0.5/1 blinds, 0.1 BB ante per player (2.3 BB starting pot), no big-blind-ante substitution.\n- The process memory budget still defaults to 70% of installed memory.\n')
w('## Known limits\n')
w('See FINAL-REPORT-5.6.md sections 10 and 11. In short: not run on Windows or a GPU; the Windows validation script is unexecuted; no estimator beats the default everywhere; exact NashConv only on small games; the mean over trainings is still model-based.\n')
(root / 'RELEASE-5.6.md').write_text('\n'.join(o) + '\n'); print('RELEASE-5.6.md written')
