#!/usr/bin/env python3
"""EightMax 5.6: ties the evidence recorded during development to the FINAL binaries.
Usage: python3 validation/5.6/final_checks.py <release root> <final linux mwcli> <5.5 linux mwcli> <out.json>

The convergence run used an earlier 5.6 build whose trainer sources are those of the release (their SHA-256 values are
recorded in validation/5.6/convergence/trainer-sources.sha256 and compared here). Training is deterministic, so:
  1. the trainer source files of the release have the recorded hashes;
  2. the final mwcli retrains sampled rows of the convergence run and reproduces their checkpoint SHA-256
     (every game, three seeds, the three 5.6 arms, two deal budgets);
  3. the final mwcli reproduces the 5.5 binary's checkpoints of the baseline55 and river55 arms for the same rows
     (table bytes; the header differs by build-independent study id only when options differ, so whole files match);
  4. the golden states of tests/fixtures/golden56.json are reproduced."""
import sys, json, subprocess, pathlib, hashlib, tempfile, shutil
root, new, old, dest = pathlib.Path(sys.argv[1]).resolve(), sys.argv[2], sys.argv[3], sys.argv[4]; V = root / 'validation/5.6'; tools = root / 'source/tools'
tmp = pathlib.Path(tempfile.mkdtemp(prefix='em56-final-')); sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
out = {'finalBuild': subprocess.run([new, '--build-id'], capture_output=True, text=True).stdout.strip(), 'finalSha256': sha(new)}
# 1
want = dict(l.split()[::-1] for l in (V / 'convergence/trainer-sources.sha256').read_text().splitlines() if l.strip()); src = {}
for name, h in want.items(): src[name] = {'recorded': h, 'release': sha(root / name), 'same': sha(root / name) == h}
out['trainerSources'] = {'files': src, 'allSame': all(v['same'] for v in src.values())}
# 2, 3
rows = [json.loads(l) for l in open(V / 'convergence/main/raw-merged.jsonl')]; idx = {(r['game'], r['seed'], r['arm'], r['kind'], r['budget']): r for r in rows}
plan = json.load(open(V / 'convergence/main/comparisons.json'))['plans'][0]; games = plan['allGames']; seeds = [plan['seeds'][0], plan['seeds'][len(plan['seeds']) // 2], plan['seeds'][-1]]
checked = bad = 0; detail = []
for game in games:
    for seed in seeds:
        for arm in plan['arms']:
            opts = plan['arms'][arm]['trainerOptions']; sp = tmp / 's.json'; st = tmp / 'state'; st.unlink(missing_ok=True); done = 0
            subprocess.run(['node', str(tools / 'games48.js'), 'spec', game, str(sp), str(seed), json.dumps({**opts, 'batchDeals': 1, 'device': 'cpu'})], check=True, capture_output=True)
            for budget in (4000, 20000):
                nxt = tmp / 'next'; r = subprocess.run([new, str(sp), str(budget - done), '1', str(nxt), '128'] + ([str(st)] if done else []), capture_output=True, text=True); assert r.returncode == 0, r.stderr[-300:]
                shutil.move(nxt, st); done = budget; rec = idx.get((game, seed, arm, 'deals', budget))
                if rec is None: detail.append([game, seed, arm, budget, 'no recorded row']); bad += 1; continue
                got = sha(st); checked += 1
                if got != rec['checkpointSha256']: bad += 1; detail.append([game, seed, arm, budget, 'differs'])
out['convergenceCheckpointsReproducedByFinalBinary'] = {'checked': checked, 'differing': bad, 'detail': detail, 'games': games, 'seeds': seeds, 'arms': list(plan['arms']), 'budgets': [4000, 20000],
    'note': 'the baseline55 and river55 rows were written by the 5.5 binary: reproducing them is the equal-deal identity of the 5.6 trainer with 5.5 for the default and the river estimator'}
# 4
g = json.load(open(root / 'source/tests/fixtures/golden56.json')); gb = 0
for i, c in enumerate(g['cases']):
    sp = tmp / 'g.json'; st = tmp / 'g.state'
    subprocess.run(['node', str(tools / 'games48.js'), 'spec', c['game'], str(sp), str(c['seed']), json.dumps({**c['options'], 'device': 'cpu'})], check=True, capture_output=True)
    r = subprocess.run([new, str(sp), str(c['updates']), str(c['threads']), str(st), str(c['memoryMiB'])], capture_output=True, text=True); gb += r.returncode != 0 or sha(st) != c['stateSha256']
out['goldenStates'] = {'checked': len(g['cases']), 'differing': gb}
out['passed'] = out['trainerSources']['allSame'] and bad == 0 and gb == 0
pathlib.Path(dest).write_text(json.dumps(out, indent=1)); shutil.rmtree(tmp, ignore_errors=True)
print(json.dumps({k: v for k, v in out.items() if k != 'trainerSources'}, indent=1)); sys.exit(0 if out['passed'] else 1)
