"""EightMax 5.5: one canonical release ZIP and the record that ties the shipped download to the tested artifact.

  python3 validation/5.5/release55.py <release root> <out dir> [--wine]

1. Builds the deterministic ZIP from the release root (same rules as package36.py, plus the studies folder):
   root *.md, *.bat, README.txt, BUILD-INFO.json, the three executables, EightMax-Offline.html and everything under
   source/, validation/, studies/ and .github/. SHA256SUMS.txt lists every member except itself.
2. Computes the SHA-256 of that exact file.
3. Extracts THAT file into a new empty directory and, from the extracted copy only: verifies every manifest entry
   and that nothing unlisted exists, verifies executables / interface / source fingerprint (verify_build.js),
   hashes the executables, and smoke-tests them (natively on Windows, with --wine elsewhere): the build id of each
   executable, a decision study through mwcli.exe, the 4.9 compressed-checkpoint self-test, and the desktop host
   answering /api/info with the same build.
4. Writes <out dir>/EightMax-Windows-<version>.identity.json: archive name, size, SHA-256, manifest entry count,
   executable hashes, build id and the smoke results. The record cannot be inside the archive it describes; it is
   delivered next to it.
"""
import hashlib, json, os, pathlib, shutil, socket, subprocess, sys, tempfile, time, urllib.request, zipfile
root = pathlib.Path(sys.argv[1]).resolve(); outdir = pathlib.Path(sys.argv[2]).resolve(); wine = '--wine' in sys.argv
outdir.mkdir(parents=True, exist_ok=True)
version = (root / 'source/VERSION').read_text().strip()
subprocess.run(['node', str(root / 'source/tools/verify_build.js'), str(root)], check=True)
ROOT_NAMES = {'README.txt', 'BUILD-INFO.json', 'EightMax.exe', 'mwcli.exe', 'gpustress.exe', 'EightMax-Offline.html'}
files = [p for p in root.iterdir() if p.is_file() and (p.suffix.lower() in {'.md', '.bat'} or p.name in ROOT_NAMES)]
for folder in ['source', 'validation', 'studies', '.github']:
    files.extend(p for p in (root / folder).rglob('*') if p.is_file() and not {'build', '__pycache__', 'node_modules'}.intersection(p.relative_to(root).parts) and p.suffix != '.pyc')
items = {p.relative_to(root).as_posix(): p for p in files}
def digest(p):
    with open(p, 'rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
hashes = {n: digest(p) for n, p in sorted(items.items())}
manifest = root / 'SHA256SUMS.txt'
manifest.write_bytes(''.join(h + '  ' + n + '\n' for n, h in hashes.items()).encode())
items[manifest.name] = manifest
zip_path = outdir / f'EightMax-Windows-{version}.zip'
tmp_zip = outdir / (zip_path.name + '.tmp')
with zipfile.ZipFile(tmp_zip, 'w') as z:
    for name, p in sorted(items.items()):
        info = zipfile.ZipInfo('EightMax/' + name, (2026, 11, 23, 0, 0, 0)); info.create_system = 3
        info.external_attr = (0o100755 if name.endswith(('.sh', '.exe')) else 0o100644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        with z.open(info, 'w') as dst, p.open('rb') as src: shutil.copyfileobj(src, dst, 1 << 20)
tmp_zip.replace(zip_path)
archive_sha = digest(zip_path)
# ---- everything below reads only the extracted copy of that file ----
clean = pathlib.Path(tempfile.mkdtemp(prefix='EightMax-release-check-'))
record = {'archive': zip_path.name, 'archiveBytes': zip_path.stat().st_size, 'archiveSha256': archive_sha, 'version': version}
try:
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        z.extractall(clean)
    assert digest(zip_path) == archive_sha
    x = clean / 'EightMax'
    listed = dict(line.split('  ', 1)[::-1] for line in (x / 'SHA256SUMS.txt').read_text().splitlines())
    present = {p.relative_to(x).as_posix() for p in x.rglob('*') if p.is_file()} - {'SHA256SUMS.txt'}
    assert present == set(listed), sorted(present ^ set(listed))[:10]
    bad = [n for n, h in listed.items() if digest(x / n) != h]
    assert not bad, bad[:10]
    subprocess.run(['node', str(x / 'source/tools/verify_build.js'), str(x)], check=True)
    info = json.loads((x / 'BUILD-INFO.json').read_text())
    record.update({'build': info['build'], 'manifestEntries': len(listed), 'archiveMembers': len(listed) + 1, 'manifestVerifiedInExtractedCopy': True,
                   'manifestSha256': digest(x / 'SHA256SUMS.txt'),
                   'executables': {n: {'bytes': (x / n).stat().st_size, 'sha256': digest(x / n)} for n in ['EightMax.exe', 'mwcli.exe', 'gpustress.exe']},
                   'interfaceSha256': digest(x / 'EightMax-Offline.html'), 'studyFixtures': sorted(p.name for p in (x / 'studies').glob('*.emfix.json'))})
    native = os.name == 'nt'
    linux = not native and not wine and (x/'validation/5.5/linux-bin/mwcli').exists()
    smoke = {'ran': native or wine or linux, 'how': 'natively on Windows' if native else ('Windows executables under Wine' if wine else 'Linux executables included in validation/5.5/linux-bin; Windows execution unavailable'), 'windowsExecution':native or wine}
    if native or wine or linux:
        env = dict(os.environ, WINEDEBUG='-all', EIGHTMAX_GPU='off')
        binaryRoot = x/'validation/5.5/linux-bin' if linux else x
        mapping={'mwcli.exe':'mwcli','EightMax.exe':'eightmax','gpustress.exe':'gpustress'}
        def executable(n):
            p=binaryRoot/(mapping[n] if linux else n)
            if linux:p.chmod(0o755)
            return p
        def run(args, **kw):
            args=list(args)
            if pathlib.Path(args[0]).name in mapping:args[0]=executable(pathlib.Path(args[0]).name)
            return subprocess.run((['wine'] if wine else []) + [str(a) for a in args], capture_output=True, text=True, env=env, cwd=str(x), **kw)
        ids = {}
        for n in ['mwcli.exe', 'EightMax.exe']:
            r = run([x / n, '--build-id']); ids[n] = r.stdout.strip(); assert ids[n] == 'EightMaxBuild=' + info['build'], (n, r.stdout, r.stderr)
        g = run([x / 'gpustress.exe']); ids['gpustress.exe'] = 'usage printed, exit ' + str(g.returncode); assert 'usage: gpustress' in (g.stdout + g.stderr)
        smoke['buildIds'] = ids
        work = clean / 'work'; work.mkdir()
        r = run([x / 'mwcli.exe', '--study', x / 'studies/known-akq-river.emfix.json', work / 'known.json', 'quiet=1', 'seeds=3', 'budgets=1000,100000,1000000']); assert r.returncode == 0, r.stderr
        doc = json.loads((work / 'known.json').read_text()); b = doc['variants'][0]['budgets'][-1]; call = [a for a in b['actions'] if a['label'] == 'Call 10'][0]
        assert doc['build'] == info['build'] and abs(call['frequency']['mean'] - 0.5) < 0.03 and abs(b['gap']['mean']) < 0.05, b
        smoke['studyKnownGame'] = {'build': doc['build'], 'callFrequency': call['frequency']['mean'], 'evGapBB': b['gap']['mean'], 'verdict': b['verdict'], 'closedForm': 'call 1/2, EV gap 0'}
        r = run([x / 'mwcli.exe', '--selftest49', x / 'validation/4.9/fixtures', work / 'st49']); st = json.loads(r.stdout.strip().splitlines()[-1]) if r.stdout.strip() else {}
        assert r.returncode == 0 and st.get('failed') == 0, (r.returncode, r.stdout[-400:], r.stderr[-400:])
        smoke['selftest49'] = {'passed': st['passed'], 'failed': st['failed'], 'build': st['build']}
        s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
        host = subprocess.Popen((['wine'] if wine else []) + [str(executable('EightMax.exe')), '--no-browser', f'--port={port}'], env=dict(env, USERPROFILE=str(work)), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=str(x))
        try:
            api = None
            for _ in range(400):
                try: api = json.loads(urllib.request.urlopen(f'http://127.0.0.1:{port}/api/info', timeout=2).read()); break
                except Exception: time.sleep(0.05)
            assert api and api['build'] == info['build'] and api['version'] == version and api.get('studyApi') == 1 and api.get('studyCheckpoints') == 1, api
            saved = json.loads(urllib.request.urlopen(f'http://127.0.0.1:{port}/api/study/checkpoints', timeout=5).read()); assert saved['checkpoints'] == [], saved
            page = urllib.request.urlopen(f'http://127.0.0.1:{port}/', timeout=5).read().decode()
            assert 'data-tab="study"' in page and info['build'] in page and 'Study accuracy and recovery' in page
            smoke['host'] = {'build': api['build'], 'version': api['version'], 'studyApi': api['studyApi'], 'studyCheckpoints': api['studyCheckpoints'], 'studyTabServed': True, 'recoveryPanelInPage': True, 'savedStudyListAnswered': True}
        finally:
            host.kill(); host.wait()
            if wine: subprocess.run(['wineserver', '-k'], capture_output=True)
        # ---- 5.5: calibration fields, automatic checkpoint, interruption and resume, through the SHIPPED executables ----
        opts = ['variants=baseline', 'seeds=101,102', 'budgets=4000,16000', 'evaluationSamples=1000', 'qualitySamples=128', 'threads=2', 'quiet=1']; fx6 = x / 'studies/flop6-jack.emfix.json'
        r = run([x / 'mwcli.exe', '--study', fx6, work / 'ref.json', *opts, 'checkpoint=off']); assert r.returncode == 0, r.stderr
        r = run([x / 'mwcli.exe', '--study', fx6, work / 'res.json', *opts, 'checkpoint=' + str(work / 'ck'), 'checkpointSeconds=0.05', 'timeLimitSeconds=0.5']); assert r.returncode == 0, r.stderr
        part = json.loads((work / 'res.json').read_text()); assert part['completion']['complete'] is False and part['run']['checkpoint']['resumable'] is True, part['completion']
        r = run([x / 'mwcli.exe', '--study', fx6, work / 'res.json', *opts, 'checkpoint=' + str(work / 'ck')]); assert r.returncode == 5, ('an existing checkpoint must be refused without resume', r.returncode)
        r = run([x / 'mwcli.exe', '--study', fx6, work / 'res.json', *opts, 'checkpoint=' + str(work / 'ck'), 'resume=1']); assert r.returncode == 0, r.stderr
        eqv = subprocess.run([sys.executable, str(x / 'source/tools/study_equivalence55.py'), str(work / 'ref.json'), str(work / 'res.json')], capture_output=True, text=True)
        res = json.loads((work / 'res.json').read_text()); bud = res['variants'][0]['budgets'][-1]
        assert eqv.returncode == 0, eqv.stdout[-600:]
        assert res['calculationVersion'] == 'study-5.5-bounded-eb-v1' and res['completion']['complete'] is True and res['run']['checkpoint']['resumed'] is True and res['run']['checkpoint']['warnings'] == [], res['run']['checkpoint']
        assert bud['confidence']['evaluationCalibrated'] is True and all(p['evSamplesWithinBound'] for s_ in res['variants'][0]['perSeed'] for p in s_['budgets'])
        smoke['study55'] = {'interruptedByTimeLimit': True, 'pointsBeforeResume': part['completion']['pointsCompleted'], 'resumedEqualsUninterrupted': True, 'canonicalSha256': eqv.stdout.split()[0], 'existingCheckpointRefusedWithoutResume': True,
                            'calculationVersion': res['calculationVersion'], 'evaluationCalibrated': True, 'verdict': bud['verdict'], 'engineStateWrites': res['run']['checkpoint']['engineStateWrites']}
        smoke['passed'] = True
    record['smokeTest'] = smoke
finally:
    shutil.rmtree(clean, ignore_errors=True)
record['note'] = 'Every check after the hash was made on a copy extracted from this exact file into a new empty directory.'
(outdir / f'EightMax-Windows-{version}.identity.json').write_text(json.dumps(record, indent=1) + '\n')
print(json.dumps(record, indent=1))
print(f'{archive_sha}  {zip_path.name}')
