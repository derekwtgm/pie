#!/bin/sh
# Formal run of the increment-level unbiasedness test (source/tests/enum55.cpp). Usage: sh unbiasedness.sh <release root> <out dir>
set -eu
root=$(cd "$1" && pwd); out=$2; mkdir -p "$out"; tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
gcc -O2 -c "$root/source/native/json.c" -o "$tmp/json.o"
g++ -std=c++20 -O2 -march=x86-64 -ffp-contract=off -I"$root/source/native" "$root/source/tests/enum55.cpp" "$tmp/json.o" -lpthread -ldl -o "$tmp/enum55" 2>/dev/null
for g in hu-river river3-chip; do node "$root/source/tools/games48.js" spec $g "$tmp/$g.json" 901 '{"batchDeals":1,"device":"cpu"}' >/dev/null; done
"$tmp/enum55" "$tmp/hu-river.json" 5000 60000000 > "$tmp/c1.json" &
"$tmp/enum55" "$tmp/river3-chip.json" 5000 20000000 > "$tmp/c2.json" &
"$tmp/enum55" "$tmp/hu-river.json" 5000 60000000 control > "$tmp/k1.json" &
wait
"$tmp/enum55" "$tmp/river3-chip.json" 5000 20000000 control > "$tmp/k2.json"
python3 - "$tmp" "$out" <<'P'
import json,sys
t,o=sys.argv[1],sys.argv[2]
def L(f,g): d=json.load(open(t+'/'+f)); d['game']=g; return d
json.dump({'tool':'source/tests/enum55.cpp','prefixDeals':5000,'candidate':[L('c1.json','hu-river'),L('c2.json','river3-chip')],'control':[L('k1.json','hu-river'),L('k2.json','river3-chip')]},open(o+'/enum55.json','w'),indent=1)
print(open(o+'/enum55.json').read()[:300])
P
