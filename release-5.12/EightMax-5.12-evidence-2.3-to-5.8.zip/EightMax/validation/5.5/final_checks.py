#!/usr/bin/env python3
"""EightMax 5.5: ties the evidence recorded during development to the FINAL binaries.
Usage: python3 validation/5.5/final_checks.py <release root> <5.4 linux mwcli> <final linux mwcli> <probe built from final source>
The statistics, convergence and performance runs were made with development builds whose engine code equals the final
source. Training and the statistical aggregation are deterministic, so the final build must reproduce them exactly:
  1. checkpoints of the convergence run: the final mwcli retrains sampled rows and must reproduce their SHA-256;
  2. the final default trainer writes the same state bytes as the unchanged 5.4 binary on six games;
  3. the statistical validation harness, rerun against a probe compiled from the final source, must reproduce the
     recorded coverage.json (every count; timing fields aside)."""
import sys, json, subprocess, pathlib, hashlib, tempfile, shutil
root, old, new, probe = pathlib.Path(sys.argv[1]).resolve(), sys.argv[2], sys.argv[3], sys.argv[4]; V = root / 'validation/5.5'; tools = root / 'source/tools'
tmp = pathlib.Path(tempfile.mkdtemp(prefix='em55-final-')); out = {'finalBuild': subprocess.run([new, '--build-id'], capture_output=True, text=True).stdout.strip()}
sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def spec(game, seed, extra, name):
    p = tmp / name; subprocess.run(['node', str(tools / 'games48.js'), 'spec', game, str(p), str(seed), json.dumps({**extra, 'batchDeals': 1, 'device': 'cpu'})], check=True, capture_output=True); return p
def train(cli, sp, deals, state, src=None):
    r = subprocess.run([cli, str(sp), str(deals), '1', str(state), '128'] + ([str(src)] if src else []), capture_output=True, text=True); assert r.returncode == 0, r.stderr[-300:]
# 1
rows = [json.loads(l) for l in open(V / 'convergence/main/raw.jsonl')]; idx = {(r['game'], r['seed'], r['arm'], r['kind'], r['budget']): r for r in rows}; plan = json.load(open(V / 'convergence/main/plan.json')); checked = bad = 0; detail = []
for game in plan['games']:
    for seed in (901, 910, 920):
        for arm in ('default55', 'river-enumeration'):
            sp = spec(game, seed, plan['arms'][arm], 's.json'); st = tmp / 'state'; done = 0
            for budget in (4000, 20000):
                nxt = tmp / 'next'; train(new, sp, budget - done, nxt, st if done else None); shutil.move(nxt, st); done = budget
                want = idx[(game, seed, arm, 'deals', budget)]['checkpointSha256']; got = sha(st); checked += 1; bad += got != want
                if got != want: detail.append([game, seed, arm, budget])
out['convergenceCheckpointsReproduced'] = {'checked': checked, 'differing': bad, 'detail': detail}
# 2
same = {}
for game in ['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'bubble4', 'flop6']:
    sp = spec(game, 901, {}, 'd.json'); train(old, sp, 20000, tmp / 'a'); train(new, sp, 20000, tmp / 'b'); same[game] = sha(tmp / 'a') == sha(tmp / 'b')
out['defaultTrainerStateIdenticalTo54'] = same
# 3
re = V / 'statistics/final-source-rerun'; shutil.rmtree(re, ignore_errors=True)
r = subprocess.run([sys.executable, str(tools / 'statistical_validation55.py'), probe, str(re)], capture_output=True, text=True); (re / 'coverage.log').write_text(r.stdout + r.stderr)
def strip(x):
    if isinstance(x, dict): return {k: strip(v) for k, v in x.items() if k not in ('aggregateMicrosecondsPerTrial', 'platform')}
    if isinstance(x, list): return [strip(v) for v in x]
    return x
a, b = strip(json.load(open(V / 'statistics/coverage.json'))), strip(json.load(open(re / 'coverage.json')))
out['statisticalValidationReproduced'] = {'identical': a == b, 'allPassRulesMet': b['allPassRulesMet'], 'passRuleFailures': b['passRuleFailures']}
out['passed'] = bad == 0 and all(same.values()) and a == b and b['allPassRulesMet']
(V / 'final-checks.json').write_text(json.dumps(out, indent=1) + '\n'); print(json.dumps(out, indent=1)); shutil.rmtree(tmp, ignore_errors=True); sys.exit(0 if out['passed'] else 1)
