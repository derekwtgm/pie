#!/bin/bash
# The final validation chain, in order, on the final build. Usage: bash validation/5.5/run_final.sh <release root> <5.4 linux mwcli> <work dir>
# Logs go to <work dir>; evidence goes to validation/5.5/. Steps run even if an earlier one fails; exit codes are recorded.
set -u
root=$(cd "$1" && pwd); old=$2; work=$3; mkdir -p "$work"; cd "$root"; S="$work/steps.txt"; : > "$S"
step() { name=$1; shift; echo "== $name $(date -u +%H:%M:%S)" | tee -a "$S"; "$@" > "$work/$name.log" 2>&1; echo "$name exit $?" | tee -a "$S"; }
mkdir -p validation/5.5/tests
EM_TEST_MWCLI="$root/build/linux/mwcli" EM_TEST_HOST="$root/build/linux/eightmax" ASAN_OPTIONS=detect_leaks=0 NODE_OPTIONS="--require=$root/validation/5.3/sanitizers/no-leaks.cjs" \
  node --test --test-concurrency=3 --test-reporter=tap source/tests/*.test.js > validation/5.5/tests/full-regression.tap 2> validation/5.5/tests/full-regression.stderr; echo "regression exit $?" | tee -a "$S"
tail -8 validation/5.5/tests/full-regression.tap | tr '\n' ' ' | tee -a "$S"; echo | tee -a "$S"
gcc -O2 -c source/native/json.c -o "$work/json.o" && g++ -std=c++20 -O2 -ffp-contract=off -ffunction-sections -fdata-sections -Wl,--gc-sections -Isource/native source/tests/study53_probe.cpp "$work/json.o" -o "$work/probe"
step final-checks python3 validation/5.5/final_checks.py . "$old" build/linux/mwcli "$work/probe"
rm -rf validation/5.5/sanitizers; step sanitizers bash validation/5.5/sanitize55.sh . "$work/san"
rm -rf validation/5.5/ui; mkdir -p validation/5.5/ui; step ui node source/tools/study_ui55.js build/linux/eightmax . validation/5.5/ui; rm -f validation/5.5/ui/reference.json
rm -rf validation/5.5/stability; step stability node source/tools/stability55.js build/linux/eightmax . validation/5.5/stability --minutes=6
rm -rf validation/5.5/convergence/unbiasedness; mkdir -p validation/5.5/convergence/unbiasedness; step unbiasedness sh validation/5.5/unbiasedness.sh . validation/5.5/convergence/unbiasedness
rm -rf validation/5.5/convergence/tournament; step tournament python3 source/tools/tournament55.py build/linux/mwcli validation/5.5/convergence/tournament
echo "== done $(date -u +%H:%M:%S)" | tee -a "$S"
