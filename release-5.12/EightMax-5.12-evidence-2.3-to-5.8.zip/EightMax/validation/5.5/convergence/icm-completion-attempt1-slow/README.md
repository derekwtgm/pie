# ICM completion, attempt 1 (stopped deliberately, retained)

Stopped after 20 checkpoints (seed 901, arms dcfr .. partially). Each exact evaluation took about 44 s, as 5.4 observed
(64-71 s on its host). Cause found: the plan's evaluation request used a 128 MiB evaluator cache. With that budget the
showdown tables of this game do not fit and are rebuilt over and over. The same evaluation takes 3.0 s with 256 MiB and
1.2 s with 1,024 MiB and returns the identical value (0.00021995727698118745 in the timing probe, same digits from the
5.4 and 5.5 binaries).

Attempt 2 (../icm-completion) changes ONLY the evaluator cache of the exact evaluation request (128 -> 1,024 MiB).
Games, seeds, arms, budgets, training memory (128 MiB), binaries, the 72-contrast family and the analysis are unchanged.
No result was inspected before this change; the 20 rows here are kept and are reproduced by attempt 2.
