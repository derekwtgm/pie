#!/usr/bin/env python3
"""Fills the @TOKEN@ fields of RELEASE-5.5.md, VALIDATION-5.5.md and BUILD-5.5.md from the recorded evidence.
Usage: python3 validation/5.5/finalize_docs.py <release root> [wine-smoke.json]"""
import json, pathlib, re, sys, hashlib
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.5'; build = json.loads((root / 'BUILD-INFO.json').read_text())['build']
tap = (V / 'tests/full-regression.tap').read_text(); num = lambda k: re.search(r'^# %s (\d+)' % k, tap, re.M).group(1)
S = V / 'sanitizers'; atap = (S / 'v53-v54-v55-asan-ubsan.tap').read_text(); an = lambda k: re.search(r'^# %s (\d+)' % k, atap, re.M).group(1)
reports = sum(int(l.rsplit(':', 1)[1]) for l in (S / 'sanitizer-report-counts.txt').read_text().split() if ':' in l)
tsan = (S / 'tsan-summary.txt').read_text(); tw = re.search(r'warnings: (\d+)', tsan).group(1); texits = re.findall(r'exit (\d+)', tsan); leak = (S / 'leak-attempt.exit').read_text().strip(); leaklog = (S / 'leak-attempt.log').read_text()
ui = json.loads((V / 'ui/study-ui55.json').read_text()); st = json.loads((V / 'stability/stability55.json').read_text())
wine = json.loads(pathlib.Path(sys.argv[2]).read_text()) if len(sys.argv) > 2 and pathlib.Path(sys.argv[2]).exists() else None
T = {'BUILD': build, 'REG_TESTS': num('tests'), 'REG_PASS': num('pass'), 'REG_FAIL': num('fail'), 'REG_SKIP': num('skipped'),
     'ASAN_LINE': f"{an('tests')} tests (5.3, 5.4, 5.5 files): {an('pass')} passed, {an('fail')} failed; {reports} sanitizer reports.",
     'ASAN_DETAIL': f"{an('pass')} of {an('tests')} tests passed against the instrumented build; {reports} AddressSanitizer or UndefinedBehaviorSanitizer reports in the test output and the host's standard error.",
     'TSAN_LINE': f"{tw} warnings; the checkpointed, cancelled and resumed studies ran to completion.", 'TSAN_DETAIL': f"{tw} ThreadSanitizer warnings; process exit codes {', '.join(texits)}; the cancelled-and-resumed study equalled the uninterrupted one.",
     'LEAK_LINE': ('LeakSanitizer ran on one complete command-line study: exit ' + leak + ', ' + ('no leak reported' if 'LeakSanitizer' not in leaklog else 'LEAKS REPORTED') + '. The desktop host was not leak-checked.'),
     'LEAK_DETAIL': ('the ASan CLI with `detect_leaks=1` on one complete study exited ' + leak + (' and reported no leak' if 'LeakSanitizer' not in leaklog else ' and REPORTED LEAKS') + '. LeakSanitizer was confirmed to work in this container with a deliberate leak. This covers one short command-line study only; the desktop host and long runs are unverified.'),
     'UI_LINE': f"{ui['checksPassed']} of {ui['checksTotal']} checks passed in {ui['browser']} against the Linux host (`validation/5.5/ui/`).",
     'STAB_LINE': f"{sum(c['passed'] for c in st['checks'])} of {len(st['checks'])} checks passed over {st['elapsedSeconds']/60:.1f} minutes in one host process (`validation/5.5/stability/`)."}
if wine:
    s = wine['smokeTest']; ok = s.get('passed') and s.get('windowsExecution')
    T['WINE_LINE'] = ('Smoke tests from the extracted final ZIP passed: build ids, known-game study, 4.9 self-test (' + str(s['selftest49']['passed']) + ' checks), interrupted-and-resumed study equal to uninterrupted, desktop host answering with the recovery panel.') if ok else 'Smoke tests did NOT pass; see the identity record.'
    T['WINE_DETAIL'] = (f"`mwcli.exe` and `EightMax.exe` report build `{wine['build']}`; the known A-K-Q study gives call frequency {s['studyKnownGame']['callFrequency']:.4f} (closed form 0.5) and EV gap {s['studyKnownGame']['evGapBB']:+.4f} BB (closed form 0); the 4.9 compressed-checkpoint self-test passes {s['selftest49']['passed']} checks with {s['selftest49']['failed']} failures; "
                        f"a study interrupted by its time limit after {s['study55']['pointsBeforeResume']} measurements is refused without `resume`, resumed, and equals the uninterrupted study (canonical SHA-256 `{s['study55']['canonicalSha256'][:16]}…`); `EightMax.exe` serves the application with the recovery panel and answers `/api/study/checkpoints`.") if ok else 'not completed.'
else:
    T['WINE_LINE'] = 'see the identity record delivered beside the ZIP.'; T['WINE_DETAIL'] = 'see the identity record delivered beside the ZIP.'
weq = V / 'windows/wine-vs-linux.json'
T['WINE_EQ'] = '`validation/5.5/windows/wine-vs-linux.json`' if weq.exists() else 'described under Windows below'
for name in ('RELEASE-5.5.md', 'VALIDATION-5.5.md', 'BUILD-5.5.md', 'FINAL-REPORT-5.5.md'):
    p = root / name; s = p.read_text()
    for k, v in T.items(): s = s.replace('@' + k + '@', v)
    if name == 'BUILD-5.5.md':
        s = re.sub(r'`[0-9a-f]{16}`(?=\.\nStatistics identifiers)', '`' + build + '`', s); s = re.sub(r'(interface and source: )[0-9a-f]{16}', r'\g<1>' + build, s)
        for f in ('EightMax.exe', 'mwcli.exe', 'gpustress.exe', 'EightMax-Offline.html', 'BUILD-INFO.json'):
            s = re.sub(r'(\| `' + re.escape(f) + r'` \| `)[0-9a-f]{64}', r'\g<1>' + hashlib.sha256((root / f).read_bytes()).hexdigest(), s)
    left = re.findall(r'@[A-Z_]+@', s); p.write_text(s); print(name, 'unfilled:', left)
