#!/bin/bash
# EightMax 5.5 sanitizer runs. Usage: bash validation/5.5/sanitize55.sh <release root> <work dir>
#  1. AddressSanitizer + UndefinedBehaviorSanitizer + float-cast-overflow build of the host and CLI (the 5.3 builder),
#     then the 5.3, 5.4 and 5.5 regression files against it (leak detection off: see 3).
#  2. ThreadSanitizer build of the CLI; a study with three seeds side by side, checkpoints every 50 ms, then a cancelled
#     and resumed study. Seed-level parallelism and the checkpoint mutex are new in 5.5.
#  3. Leak check attempt: the ASan CLI with detect_leaks=1 on a complete study. Its exit code and log are recorded.
set -u
root=$(cd "$1" && pwd); work=$2; out="$root/validation/5.5/sanitizers"; mkdir -p "$work" "$out"
bash "$root/validation/5.3/sanitizers/build-final.sh" "$root/source" "$root/build" "$work/asan" > "$out/build-asan-ubsan.log" 2>&1; echo "asan build exit $?" | tee "$out/build-asan-ubsan.exit"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax" EM_TEST_HOST_STDERR="$out/host-stderr.log" \
  node --test --test-concurrency=1 --test-reporter=tap "$root/source/tests/v53.test.js" "$root/source/tests/v54.test.js" "$root/source/tests/v55.test.js" > "$out/v53-v54-v55-asan-ubsan.tap" 2> "$out/v53-v54-v55-asan-ubsan.stderr"
echo "asan tests exit $?" | tee "$out/v53-v54-v55-asan-ubsan.exit"; tail -9 "$out/v53-v54-v55-asan-ubsan.tap"
grep -c -E 'ERROR: AddressSanitizer|runtime error:' "$out/v53-v54-v55-asan-ubsan.tap" "$out/v53-v54-v55-asan-ubsan.stderr" "$out/host-stderr.log" 2>/dev/null | tee "$out/sanitizer-report-counts.txt"
# 2
obj="$work/tsan"; mkdir -p "$obj"; printf '#define EM_VERSION "5.5"\n#define EM_BUILD_ID "tsan"\n' > "$obj/build_info.h"
( cd "$root/source/native" && g++ -std=c++20 -O1 -g1 -fsanitize=thread -fno-omit-frame-pointer -march=x86-64 -ffp-contract=off -I. -c mw.cpp -o "$obj/mw.o" && gcc -O1 -fsanitize=thread -c json.c -o "$obj/json.o" &&
  g++ -std=c++20 -O1 -g1 -fsanitize=thread -march=x86-64 -ffp-contract=off -I. -include "$obj/build_info.h" mwcli.cpp "$obj/mw.o" "$obj/json.o" -lpthread -ldl -lz -o "$obj/mwcli" ) > "$out/build-tsan.log" 2>&1; echo "tsan build exit $?" | tee "$out/build-tsan.exit"
F="$root/studies/flop6-jack.emfix.json"; O="variants=baseline seeds=101,102,103 budgets=3000,9000 evaluationSamples=256 qualitySamples=64 threads=3 parallelSeeds=3 quiet=1"
{ TSAN_OPTIONS=halt_on_error=0 "$obj/mwcli" --study "$F" "$work/t1.json" $O checkpoint="$work/tck1" checkpointSeconds=0.05; echo "study exit $?"
  TSAN_OPTIONS=halt_on_error=0 EM_STUDY_CANCEL_AFTER_MS=1500 "$obj/mwcli" --study "$F" "$work/t2.json" $O checkpoint="$work/tck2" checkpointSeconds=0.05; echo "cancelled study exit $?"
  TSAN_OPTIONS=halt_on_error=0 "$obj/mwcli" --study "$F" "$work/t2.json" $O checkpoint="$work/tck2" resume=1; echo "resumed study exit $?"
  TSAN_OPTIONS=halt_on_error=0 "$obj/mwcli" --study "$root/studies/known-akq-river.emfix.json" "$work/t3.json" seeds=4 budgets=500,3000 threads=4 parallelSeeds=4 quiet=1; echo "exact study exit $?"; } > "$out/tsan-parallel-study.log" 2>&1
echo "ThreadSanitizer warnings: $(grep -c 'WARNING: ThreadSanitizer' "$out/tsan-parallel-study.log")" | tee "$out/tsan-summary.txt"; grep -E 'exit [0-9]+' "$out/tsan-parallel-study.log" | tee -a "$out/tsan-summary.txt"
python3 "$root/source/tools/study_equivalence55.py" "$work/t1.json" "$work/t2.json" --quiet | tee -a "$out/tsan-summary.txt"
# 3
ASAN_OPTIONS=detect_leaks=1 "$work/asan/mwcli" --study "$root/studies/known-akq-river.emfix.json" "$work/leak.json" seeds=2 budgets=500 quiet=1 > "$out/leak-attempt.log" 2>&1; echo "$?" > "$out/leak-attempt.exit"
echo "leak attempt exit $(cat "$out/leak-attempt.exit")"; tail -3 "$out/leak-attempt.log" | cut -c1-200
