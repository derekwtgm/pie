#!/usr/bin/env python3
"""Builds the data-driven parts of the 5.5 reports from the recorded results (no number is typed by hand).
Usage: python3 validation/5.5/write_reports.py <release root>
  CONVERGENCE-5.5.md, PERFORMANCE-5.5.md, and the Part E table of STATISTICAL-VALIDATION-5.5.md."""
import json, pathlib, statistics, sys, collections
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.5'
J = lambda p: json.loads((V / p).read_text())
# ------------------------------------------------------------------ convergence
main = J('convergence/main/summary.json'); icm = J('convergence/icm-completion/summary.json'); en = J('convergence/unbiasedness/enum55.json')
def crow(c): return f"| {c['game']} | {c['kind']} | {c['budget']} | {c['baselineMean']:.6g} | {c['candidateMean']:.6g} | [{c['simultaneousTInterval95'][0]:+.4g}, {c['simultaneousTInterval95'][1]:+.4g}] | {c['seedsCandidateLower']} / {c['seedsCandidateHigher']} | {c['signTestPBonferroni']:.2g} | {c['baselineMeanDeals']:.0f} / {c['candidateMeanDeals']:.0f} | **{c['verdict']}** |"
cand = [c for c in main['comparisons'] if c['arm'] == 'river-enumeration']; dflt = [c for c in main['comparisons'] if c['arm'] == 'default55']
cnt = collections.Counter((c['kind'], c['verdict']) for c in cand)
icnt = collections.Counter(c['verdict'] for c in icm['comparisons'])
big = V / 'convergence/tournament/summary.json'
doc = f'''# Convergence — EightMax 5.5

Version 5.4 found no statistically supported improvement over its default trainer. Version 5.5 implemented and
evaluated **one** candidate, completed the ICM comparisons 5.4 left unfinished, and kept the default trainer unchanged.

## Summary

| Question | Answer |
|---|---|
| Is the 5.5 default trainer the 5.4 trainer? | Yes. At equal seeds and deals the 5.5 default produced the same exact NashConv as the unchanged 5.4 binary in all {sum(c['kind']=='deals' for c in dflt)} equal-deal contrasts ({'all identical' if main['promotion']['default55IdenticalToBaselineAtEqualDeals'] else 'NOT all identical'}); state files are byte-identical. |
| Was a new algorithm implemented? | Yes, one: river opponent enumeration (`"opponentEnumeration":"river"`), opt-in and experimental. |
| Is it mathematically correct? | Its regret and average-strategy increments have the same expectation as the default's (frozen-table test below). |
| Does it converge better at equal sampled deals? | Yes, with statistical support: better in {cnt[('deals','better')]} of {sum(c['kind']=='deals' for c in cand)} equal-deal contrasts, unresolved in {cnt[('deals','unresolved')]}, worse in {cnt[('deals','worse')]}. |
| Does it converge better at equal time? | Not established: better in {cnt[('time','better')]} of {sum(c['kind']=='time' for c in cand)} equal-time contrasts, unresolved in {cnt[('time','unresolved')]}, worse in {cnt[('time','worse')]}. On the three-player river game most seeds were worse at equal time. |
| Was it promoted to the default? | **No.** The promotion rule written before measurement was not met. |
| Did anything else improve on the default? | No. The completed 5.4 family has {icnt['better']} better, {icnt['worse']} worse and {icnt['unresolved']} unresolved ICM contrasts. |

No claim is made that EightMax is closer to equilibrium by default in 5.5 than in 5.4. With the opt-in candidate it
is closer per sampled deal on the tested river games, and not reliably closer per second.

## The candidate: river opponent enumeration

External-sampling MCCFR samples one action at every opponent decision and reweights it. On the final street
(river) the candidate instead traverses **every** opponent action and combines the child values with the opponent's
current strategy. This replaces a one-sample estimate of the sum over the opponent's river actions by the sum itself
(Rao–Blackwellisation). The sampling reach is unchanged at those nodes, so regret increments below action a are scaled
by the opponent's true probability of a, and average-strategy increments are scaled exactly as in the default.
Zero-probability actions are still traversed, because the average-strategy weight of the updating seat's information
sets must not depend on the opponent's strategy. Earlier streets, chance and the updating seat are sampled or
enumerated as before. Games without river betting are unaffected.

Code: `Walker::learn` and `Walker::learnVec` in `source/native/mw_es_impl.hpp`; option parsed in `mw.cpp`.

### Correctness: same expected increments

`source/tests/enum55.cpp` trains a table with the default estimator, freezes it, and traverses independent deals
with each estimator for every updating seat without merging anything. It compares the mean increment of every table
entry. (A first version of this test went through whole updates and showed a discrepancy; within one update the
second seat reads the first seat's freshly merged increments, so later seats legitimately differ at second order.
The test was rewritten to use a frozen table for every seat. Both versions are described in the source.)

| Game | Deals per estimator | Regret entries: largest abs(z), share above 1.96 | Average entries: largest abs(z), share above 1.96 | Regret-increment variance, candidate / default | Average-increment variance, candidate / default | State visits per deal, default / candidate |
|---|---|---|---|---|---|---|
''' + '\n'.join(f"| {r['game']} | {r['trials']:,} | {r['regret']['maxAbsZ']:.2f}, {100*r['regret']['shareAbove1.96']:.1f}% | {r['average']['maxAbsZ']:.2f}, {100*r['average']['shareAbove1.96']:.1f}% | {r['regret']['varianceRatio']:.3f} | {r['average']['varianceRatio']:.4f} | {r['stateVisitsPerUpdate'][0]:.1f} / {r['stateVisitsPerUpdate'][1]:.1f} |" for r in en['candidate']) + f'''

Control (default against default, different streams): ''' + '; '.join(f"{r['game']} at {r['trials']:,} deals: regret largest abs(z) {r['regret']['maxAbsZ']:.2f}, average largest abs(z) {r['average']['maxAbsZ']:.2f}" for r in en['control']) + f'''.

The z statistics do not grow with the number of deals (a bias would grow with its square root), and the control
behaves the same way. The average-strategy increments of the default estimator are heavy-tailed, so its z statistics
are not exactly normal; the control row shows the size of that effect. This is a statistical check at the stated
resolution, not a proof.

### Fixed-plan comparison against 5.4

`source/tools/research55.py`, plan `main`. Written before measurement (`validation/5.5/convergence/main/plan.json`):

- games: {', '.join(main['plan']['games'])} (exact all-seat best response is feasible in each);
- {len(main['plan']['seeds'])} paired training seeds ({main['plan']['seeds'][0]}–{main['plan']['seeds'][-1]}); budgets {', '.join(map(str, main['plan']['deals']))} sampled deals and {', '.join(map(str, main['plan']['trainingSeconds']))} seconds of training;
- arms: the unchanged 5.4 binary (baseline), the 5.5 default, the candidate; one training thread, 128 MiB;
- family: {main['plan']['family']} contrasts; a verdict needs BOTH an exact sign test (distribution-free for the median paired difference) and a paired Student-t interval, each Bonferroni-adjusted over the family;
- promotion rule: {main['plan']['promotionRule']}

{main['rows']} checkpoints were trained and evaluated. NashConv is exact inside each abstraction; with more than two
players it is not exploitability.

**Candidate against the 5.4 baseline**

| Game | Budget kind | Budget | 5.4 baseline NashConv | Candidate NashConv | Simultaneous t interval of the difference | Seeds lower / higher | Sign test p (Bonferroni) | Deals, baseline / candidate | Verdict |
|---|---|---|---|---|---|---|---|---|---|
''' + '\n'.join(crow(c) for c in cand) + f'''

**5.5 default against the 5.4 baseline** (equal deals: identical by construction and by measurement; equal time: timing noise only)

| Game | Budget kind | Budget | 5.4 baseline NashConv | 5.5 default NashConv | Simultaneous t interval of the difference | Seeds lower / higher | Sign test p (Bonferroni) | Deals, baseline / candidate | Verdict |
|---|---|---|---|---|---|---|---|---|---|
''' + '\n'.join(crow(c) for c in dflt) + f'''

Reading:

- At equal deals the candidate's NashConv was lower in every game and budget, with both tests agreeing in {cnt[('deals','better')]} of {sum(c['kind']=='deals' for c in cand)} contrasts.
- At equal time the candidate processes roughly half to a quarter as many deals. It was better on the heads-up turn-and-river game at 0.5 s, unresolved elsewhere, and on the three-player river game its mean NashConv was higher at both time budgets (not significant after adjustment).
- Decision: **{main['promotion']['decision']}**.
- Equal-time budgets are wall-clock on a shared four-core container; timing noise enters those contrasts.

An earlier attempt of this run stopped after three rows because the runner asked for more updates than `mwcli`
accepts in timed runs. It is kept in `validation/5.5/convergence/main-attempt1-harness-error/`.

## The ICM comparisons 5.4 could not finish

5.4 declared 72 contrasts and completed 48; the 24 four-player ICM (bubble) contrasts were abandoned because each exact
evaluation took 64–71 s. The cause is now known: the evaluation request used a 128 MiB evaluator cache, too small for
that game's showdown tables, which were rebuilt repeatedly. With 1,024 MiB the same evaluation takes about 1.2 s and
returns the identical value (`PERFORMANCE-5.5.md`).

`research55.py --plan icm` completed the family exactly as declared: same game, seeds 901–910, the six candidate arms,
the 5.3 binary as baseline, the 5.4 binary for candidates and evaluation, training memory 128 MiB, and the **original
72-contrast** Bonferroni penalty with the paired Student-t rule 5.4 declared. Only the evaluator cache changed.
{icm['rows']} checkpoints. The first attempt (128 MiB cache, stopped after 20 checkpoints) is kept in
`validation/5.5/convergence/icm-completion-attempt1-slow/`.

| Arm | Budget kind | Budget | 5.3 baseline NashConv | Candidate NashConv | Simultaneous t interval (family 72) | Seeds lower / higher | Verdict (5.4 rule) |
|---|---|---|---|---|---|---|---|
''' + '\n'.join(f"| {c['arm']} | {c['kind']} | {c['budget']} | {c['baselineMean']:.6g} | {c['candidateMean']:.6g} | [{c['simultaneousTInterval95'][0]:+.4g}, {c['simultaneousTInterval95'][1]:+.4g}] | {c['seedsCandidateLower']} / {c['seedsCandidateHigher']} | **{c['verdict']}** |" for c in icm['comparisons']) + f'''

With the 48 contrasts of 5.4 (20 worse, 28 unresolved) the completed family is: 0 better, {20 + icnt['worse']} worse,
{28 + icnt['unresolved']} unresolved of 72. DCFR, DCFR with cubic averaging and CFR+ were worse on ICM at every budget.
The terminal baseline had lower mean NashConv at every budget but the difference is unresolved. Uniform weighting was
higher in nearly every seed, also unresolved under the declared interval. No default change is supported.

The sign-test columns are reported for information; they decide nothing in this family.
'''
g5 = lambda x: 'not evaluated' if x is None else '%.5g' % x
if big.exists():
    b = json.loads(big.read_text())
    doc += f'''
## Larger tournament situations (restricted metrics)

Exact whole-game evaluation is not feasible for these configurations. `source/tools/tournament55.py` ran the shipped
study fixtures through the study runner with the default trainer and with the candidate, on the same seeds, and
recorded what each fixture can measure. **These are restricted measurements**: a sampled one-decision deviation gain
is a lower bound on what a seat could gain, it is not exploitability, and its uncertainty is not calibrated. They
describe one decision each, not the whole game.

Plan: `validation/5.5/convergence/tournament/plan.json` (written before measurement). {b['plan']['seeds']} seeds,
budgets {', '.join(map(str, b['plan']['budgets']))} deals, one variant per fixture.

| Fixture | Situation | River betting in the tree | Quality metric | Budget | Default: quality mean | Candidate: quality mean | Paired difference, seeds lower / higher | Default / candidate training s per seed | Leading action by EV, default / candidate |
|---|---|---|---|---|---|---|---|---|---|
''' + '\n'.join(f"| {r['fixture']} | {r['situation']} | {'yes' if r['riverBetting'] else 'no'} | {r['metric']} | {r['budget']} | {g5(r['defaultQuality'])} | {g5(r['candidateQuality'])} | {('%+.4g' % r['difference']) if r['qualityEvaluated'] else 'not evaluated at this budget'}, {r['lower']} / {r['higher']} | {r['defaultTrainSeconds']:.2f} / {r['candidateTrainSeconds']:.2f} | {r['defaultLeader']} / {r['candidateLeader']} |" for r in b['rows']) + f'''

{b['reading']}
'''
doc += '''
## What would establish stronger GTO accuracy

- A candidate that wins at equal time as well as equal deals across games, including ICM and linked streets.
- Exact or tightly bounded whole-game evaluation for the large tournament fixtures; today only one-decision
  restricted responses are available there.
- More training replications than 10–20 for the model-based comparisons, or exact evaluation with enough
  replications for distribution-free tests throughout.
- Evaluation of abstraction error (bet sizes, ranges, hand grouping), which none of these measurements address.
'''
(root / 'CONVERGENCE-5.5.md').write_text(doc)
# ------------------------------------------------------------------ Part E table
pk = J('statistics/poker/poker-calibration.json'); agg = collections.OrderedDict()
for c in pk['cells']:
    a = agg.setdefault((c['game'], c['samples']), dict(t=0, w=0, eb=0, mt=0, ebf=0, mtf=0, ebs=0, mts=0, hw=[], hm=[], bound=c['payoffBound'], util=c['utility']))
    a['t'] += c['trials']; a['w'] += c['samplesWithinBound']; a['eb'] += c['bounded']['simultaneousCoverage']['successes']; a['mt'] += c['normalApproximation']['simultaneousCoverage']['successes']
    a['ebf'] += c['bounded']['falseSupportedBest']; a['mtf'] += c['normalApproximation']['falseSupportedBest']; a['ebs'] += c['bounded']['supportedBest']; a['mts'] += c['normalApproximation']['supportedBest']; a['hw'].append(c['bounded']['meanLargestHalfWidth']); a['hm'].append(c['normalApproximation']['meanLargestHalfWidth'])
T = sum(a['t'] for a in agg.values()); tb = ['| Game | Utility, proven bound | Samples | Evaluations | All samples inside the bound | Bounded-payoff coverage | Normal-approximation (5.4 style) coverage | False "supported best": bounded / normal | "Supported best" stated: bounded / normal | Mean half-width: bounded / normal |', '|---|---|---|---|---|---|---|---|---|---|']
for (g, n), a in agg.items(): tb.append(f"| {g} | {a['util']} [{a['bound'][0]:g}, {a['bound'][1]:g}] | {n:,} | {a['t']} | {a['w']}/{a['t']} | {a['eb']}/{a['t']} | {a['mt']}/{a['t']} ({100*a['mt']/a['t']:.1f}%) | {a['ebf']} / {a['mtf']} | {a['ebs']} / {a['mts']} | {statistics.mean(a['hw']):.3f} / {statistics.mean(a['hm']):.3f} |")
tot = lambda k: sum(a[k] for a in agg.values())
partE = '\n'.join(tb) + f'''

Totals over {T:,} sampled evaluations ({len(pk['cells'])} game/hand/sample-count cells, {pk['plan']['evaluationSeeds']} seeds each):

- every sample and every exact EV lay inside the payoff bound derived from the betting rules ({tot('w'):,}/{T:,});
- the bounded-payoff simultaneous intervals covered the exact differences in {tot('eb'):,}/{T:,} evaluations; the pass rule (no cell with a Wilson upper limit below 95%) was met in every cell;
- the normal-approximation intervals covered in {tot('mt'):,}/{T:,} ({100*tot('mt')/T:.1f}%) and made {tot('mtf')} false "supported best" statements; the bounded intervals made {tot('ebf')};
- the cost is power at small sample counts: at 256 samples the bounded intervals supported a best action {sum(a['ebs'] for (g,n),a in agg.items() if n==256)} times, the normal approximation {sum(a['mts'] for (g,n),a in agg.items() if n==256)} times; at 20,000 samples {sum(a['ebs'] for (g,n),a in agg.items() if n==20000)} against {sum(a['mts'] for (g,n),a in agg.items() if n==20000)}.

An earlier run of this tool was interrupted on purpose because the binary it was using was about to be rebuilt; its
completed cells are kept in `validation/5.5/statistics/poker-interrupted-run1/`.'''
sv = root / 'STATISTICAL-VALIDATION-5.5.md'; text = sv.read_text()
if '<!--POKER-TABLE-->' in text: text = text.replace('<!--POKER-TABLE-->', '<!--POKER-TABLE-BEGIN-->\n' + partE + '\n<!--POKER-TABLE-END-->')
else: a, b = text.index('<!--POKER-TABLE-BEGIN-->'), text.index('<!--POKER-TABLE-END-->'); text = text[:a] + '<!--POKER-TABLE-BEGIN-->\n' + partE + '\n' + text[b:]
sv.write_text(text)
# ------------------------------------------------------------------ performance
pf = V / 'performance/runs.json'
if pf.exists():
    R = json.loads(pf.read_text()); env = J('performance/environment.json'); md = statistics.median
    def pick(**k): return [r for r in R if all(r.get(a) == b for a, b in k.items()) and 'error' not in r]
    out = f'''# Performance — EightMax 5.5

Measured with `source/tools/bench55.py` against the **unchanged 5.4 Linux binary**, on the development host:
{env['cpu']}, {env['logicalProcessors']} logical processors, {env['memTotalKiB']/1048576:.1f} GiB, {env['platform']}. This is a shared cloud
container, **not** the target Windows i7 / RTX 4060 Ti computer. No GPU was present. Every run is in
`validation/5.5/performance/runs.jsonl`; nothing here is a prediction for another machine.

## What changed

| Change | Effect on results |
|---|---|
| Seeds of a study train and evaluate side by side (`parallelSeeds`, automatic). 5.4 ran them one after another, and training a single-deal-batch study cannot use more than one thread. | None: results are identical (see agreement below). |
| The evaluator cache is sized from the process memory budget instead of being tied to the table budget. | None: an evaluation's value does not depend on its cache size. |
| Training chunks inside a study adapt (256 to 65,536 updates) instead of a fixed 256 whenever a limit exists. | None: `train(a)` then `train(b)` equals `train(a+b)`. |
| Process memory budget (70% of installed memory by default) bounds the seeds running together and stops a study that exceeds it. | None. |
| **Not changed:** the default trainer. Raw training throughput is the same code as 5.4. | — |

## Complete studies, {env['threadsRequested']} threads requested

Median of {env['repetitions']} runs each, binaries alternated. "Measurements" are completed of requested (variant x seed x budget).

| Workload | 5.4 wall s | 5.5 wall s | 5.4 / 5.5 | Measurements 5.4 / 5.5 | 5.4 train / EV / quality s (summed) | 5.5 train / EV / quality s (summed) | Peak RSS MiB 5.4 / 5.5 | Seeds side by side (5.5) | Evaluator cache MiB (5.5) |
|---|---|---|---|---|---|---|---|---|---|
'''
    names = []
    for r in R:
        if r['section'] == 'study' and r['workload'] not in names: names.append(r['workload'])
    for w in names:
        a, b = pick(section='study', workload=w, version='5.4'), pick(section='study', workload=w, version='5.5')
        if not a or not b: out += f"| {w} | failed | | | | | | | | |\n"; continue
        wa, wb = md([x['wallSeconds'] for x in a]), md([x['wallSeconds'] for x in b]); f = lambda xs, k: md([x[k] for x in xs])
        note = '' if all(x['pointsCompleted'] == x['pointsRequested'] for x in a + b) else ' (time limit reached: not a like-for-like duration)'
        out += f"| {w} | {wa:.2f} | {wb:.2f} | {wa/wb:.2f}x{note} | {a[0]['pointsCompleted']}/{a[0]['pointsRequested']} / {b[0]['pointsCompleted']}/{b[0]['pointsRequested']} | {f(a,'trainingSecondsSum'):.1f} / {f(a,'actionEvSecondsSum'):.1f} / {f(a,'qualitySecondsSum'):.1f} | {f(b,'trainingSecondsSum'):.1f} / {f(b,'actionEvSecondsSum'):.1f} / {f(b,'qualitySecondsSum'):.1f} | {f(a,'peakRssMiB'):.0f} / {f(b,'peakRssMiB'):.0f} | {b[0]['parallelSeeds']} | {b[0]['evaluationMemoryMiB']:.0f} |\n"
    ag = [r for r in R if r['section'] == 'agreement']
    out += f'''
The summed training, EV and quality seconds are per-seed times added up; with seeds running side by side they exceed
the wall time. Peak memory rises because several seeds are resident together and the evaluator cache is larger.

**Numerical agreement.** For every workload both versions' per-seed action EVs, frequencies, standard errors, quality
values, deal counts, row counts and evaluation seeds were compared wherever both completed the measurement:
{sum(a['pointsCompared'] for a in ag)} measurements compared, {sum(a['pointsDiffering'] for a in ag)} differing.

## Thread scaling of complete studies

| Workload | Threads | 5.4 wall s | 5.5 wall s | 5.4 speed-up vs 1 thread | 5.5 speed-up vs 1 thread | 5.5 seeds side by side | Measurements 5.4 / 5.5 |
|---|---|---|---|---|---|---|---|
'''
    for w in [x for x in names if pick(section='scaling', workload=x)]:
        b1 = {v: next((r['wallSeconds'] for r in pick(section='scaling', workload=w, version=v, threads=1)), None) for v in ('5.4', '5.5')}
        for th in (1, 2, 4, 8):
            a, b = pick(section='scaling', workload=w, version='5.4', threads=th), pick(section='scaling', workload=w, version='5.5', threads=th)
            if not a or not b: continue
            a, b = a[0], b[0]; out += f"| {w} | {th} | {a['wallSeconds']:.2f} | {b['wallSeconds']:.2f} | {b1['5.4']/a['wallSeconds']:.2f}x | {b1['5.5']/b['wallSeconds']:.2f}x | {b['parallelSeeds']} | {a['pointsCompleted']}/{a['pointsRequested']} / {b['pointsCompleted']}/{b['pointsRequested']} |\n"
    out += f'''
The host has {env['logicalProcessors']} logical processors, so 8 threads oversubscribe it; that row shows behaviour, not scaling.
Where 5.4's training-dominated studies do not speed up with threads, 5.5 does because whole seeds run in parallel.
Scaling is limited by the number of seeds that fit in the process memory budget and by memory bandwidth.

## Checkpoint overhead (six-player flop, Standard preset)

| Checkpointing | Wall s (median) | Commits | Engine states written | MiB written | Seconds writing |
|---|---|---|---|---|---|
'''
    for lab in ['off', 'default (60 s + stage boundaries)', 'every 1 s + stage boundaries']:
        x = pick(section='checkpoint', checkpointing=lab)
        if x: c = x[0]['checkpoint'] or {}; out += f"| {lab} | {md([r['wallSeconds'] for r in x]):.2f} | {c.get('commits', 0)} | {c.get('engineStateWrites', 0)} | {c.get('engineStateMiBWritten', 0):.1f} | {c.get('secondsWriting', 0):.2f} |\n"
    out += '''
## Raw training throughput (one thread, default trainer)

| Fixture | Deals | 5.4 deals/s (median of 3) | 5.5 deals/s (median of 3) | 5.5 / 5.4 | State files identical |
|---|---|---|---|---|---|
'''
    for fxn in dict.fromkeys(r['fixture'] for r in R if r['section'] == 'training'):
        a, b = pick(section='training', fixture=fxn, version='5.4'), pick(section='training', fixture=fxn, version='5.5'); da, db = md([x['dealsPerSecond'] for x in a]), md([x['dealsPerSecond'] for x in b])
        out += f"| {fxn} | {a[0]['deals']:,} | {da:,.0f} | {db:,.0f} | {db/da:.2f} | {'yes' if len({x['stateSha256'] for x in a + b}) == 1 else 'NO'} |\n"
    pr = V / 'performance/profile.md'
    out += f'''
The default trainer was not optimised in 5.5: the ratio is noise around 1. Deals per second of training did not improve.

## Exact evaluation and the evaluator cache

Single exact all-seat best-response evaluations (`mwcli --gain`, one thread), same state, same result to the last digit:

| Game | Evaluator cache 128 MiB | 256 MiB | 1,024 MiB |
|---|---|---|---|
| Four-player ICM bubble (research game `bubble4`) | 44.1 s | 3.0 s | 1.2 s |
| Eight-handed ICM, small companion fixture | 50.8 s | 26.5 s | 7.6 s |

(`validation/5.5/performance/evaluator-cache.md` holds the commands and outputs.) With a small cache the showdown
tables are evicted and rebuilt. This is why 5.4 measured 64–71 s per ICM checkpoint. 5.5 studies now give the
evaluator the unused share of the process budget; the research runner uses 1,024 MiB.

## Profile

{pr.read_text() if pr.exists() else ''}

## Equal-time strategy quality

The default trainer is unchanged, so default strategy quality at equal time is unchanged (the 5.5 default against the
5.4 baseline is unresolved in every equal-time contrast and identical at equal deals; `CONVERGENCE-5.5.md`). The
opt-in candidate is better per deal and not reliably better per second.

## Negative and inconclusive results

- Training throughput (deals per second): no improvement; none was attempted in the trainer's inner loop.
- The six-player exact response profile is dominated by terminal utility evaluation over joint opponent holdings; no
  restructuring was attempted, so a single exact six-player evaluation is as slow as in 5.4 apart from cache effects.
- The showdown scoring kernel (about 70% of exact eight-handed ICM evaluation with a large cache) was profiled but not
  rewritten.
- Peak memory is higher in 5.5 by design.
- No GPU was available: GPU and hybrid performance are unmeasured, and no CUDA kernel was added or changed.
- Windows timings were not measured.
'''
    (root / 'PERFORMANCE-5.5.md').write_text(out)
print('reports written')
