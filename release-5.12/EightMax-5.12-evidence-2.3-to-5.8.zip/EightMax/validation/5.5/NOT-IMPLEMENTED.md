# Explicit scope limits — EightMax 5.5

Implemented and tested items are in `RELEASE-5.5.md`. This file lists what was **not** done.

## Statistics

- No calibrated interval across independent trainings. `ci95` remains the model-based Student-t interval.
- No calibrated bound for sampled quality.
- No confidence sequences: optional stopping on observed values is not supported.
- No bootstrap procedure. It was considered and not adopted: with 2–10 replications and rare large payoffs its
  assumptions cannot be justified.
- No tighter per-pair payoff bound; differences use twice the single-action range.
- No selectable confidence level; 95% only.

## Training

- The default trainer is unchanged. River opponent enumeration is opt-in and experimental.
- No learned (stored) baseline, no outcome-dependent control variate beyond the existing terminal baseline, no new
  chance-sampling distribution, no stratification for card-conflict rejection. Only one candidate was built, as the
  brief required.
- No optimisation of the trainer's inner loop: allocation, information-set storage, synchronisation and
  card-conflict handling are as in 5.4.
- The candidate was not evaluated on exact ICM games with river betting (the exact ICM research games have none).

## Evaluation

- The exact best-response recursion and the showdown scoring kernel were profiled, not rewritten.
- No approximate evaluator was introduced.

## GPU

- No CUDA kernel was added or changed. No physical NVIDIA GPU was available; RTX 4060 Ti behaviour and performance
  are unverified. CPU, Automatic, Hybrid and GPU-preferred modes and the hardware validation utility are preserved
  as shipped in 5.4.

## Memory

- The process memory budget is a stop condition checked between training chunks and evaluations. It is not a hard
  cap on every allocation, and it does not cover memory used by the operating system's file cache.
- The number of seeds running together is derived from the declared budgets, not from measured use, so it is
  conservative for fixtures that declare a large table budget.

## Checkpoints

- Resume across different builds is refused.
- GPU-mode exact continuation was not tested.
- Power-loss durability and native Windows file semantics were not tested.

## Interface

- No continuously measured percentage inside one exact evaluation and no completion-time estimate.
- The Multiway (single-solve) tab is unchanged; automatic checkpoints apply to decision studies.

## Platform

- Native Windows execution was not physically tested. The Windows executables were cross-compiled and exercised
  under Wine only (see `VALIDATION-5.5.md`).
- Leak checking: see `VALIDATION-5.5.md`.

## Accuracy claims

- No certification of full eight-handed no-limit Hold'em equilibrium accuracy. Exact small abstractions do not
  certify the full game; sampled one-decision gains cannot certify even their own abstraction.
