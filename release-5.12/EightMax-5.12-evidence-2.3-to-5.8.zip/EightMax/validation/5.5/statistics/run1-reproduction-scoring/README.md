# Run 1 (retained, superseded)

First full run of `statistical_validation55.py`. Outcome: every coverage, false-ranking, refusal and formula rule passed, but the
**reproduction** rule failed for 12 of 13 Part A scenarios.

Cause: a scoring difference in the harness, not in the statistics. `statistical_validation54.py` counted a trial as covered when
all PAIRWISE conditional intervals covered. The 5.5 harness additionally requires every single-action EV interval to cover
(k more intervals), so its count for the unchanged 5.4 formula was lower (e.g. rare tail 2459/3000 instead of 2597/3000).
Population coverage, ranked counts and false-ranking counts reproduced exactly in all 13 scenarios.

Repair: the harness now reports both measures and the reproduction rule uses the pairs-only measure, which is the quantity 5.4
published. No change to study_stats53.hpp, study_stats55.hpp, the scenarios, seeds or trial counts. Run 2 is the result of record.
