Function-level profiles (`gprof`, `-O2 -pg`, one thread; instrumentation inflates absolute times):

| Workload | Where the time goes |
|---|---|
| Exact all-seat response, six-player flop companion fixture | `Evaluator::seatScore` 31%, `brRec` (best-response recursion) 24%, `Evaluator::scored` 22%, `utilityWithScores` 13%, betting-state construction 3%, hand ranking 4%. About 1.2 billion terminal utility evaluations over joint opponent holdings. |
| Exact all-seat response, eight-handed ICM companion fixture (256 MiB cache) | `Evaluator::scoreChunk` (showdown-table construction: board enumeration, rank patterns, histogram) 71%, `evalMasks` (seven-card ranking, 1.74 billion calls) 29%. ICM equity itself is negligible (3,969 calls). |
| A Standard study on the large sampled fixtures (5.4) | Training 74% on the six-player flop fixture; exact quality 75–91% on the small exact companions (time-limited). |
| Training inside a study | Single-threaded for every shipped fixture (single-deal batches with a shared action stream), which is why threads did not help 5.4 studies. |

Stages not separately profiled: chance sampling, card-conflict rejection, information-set lookup, regret and
average-strategy accumulation, memory allocation and thread synchronisation inside the trainer. The engine's own
stage timers for training are only populated on profiled updates and were not broken down further, because the
default trainer was left unchanged. Checkpoint serialisation is measured in the checkpoint-overhead table.
