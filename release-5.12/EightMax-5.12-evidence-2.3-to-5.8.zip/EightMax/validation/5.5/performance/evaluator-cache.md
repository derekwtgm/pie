# Exact evaluation time against the evaluator cache

Measured on the development host (4 logical processors, shared container), one evaluation thread, Linux builds.
Command: `mwcli --gain spec.json state request.json <loadMiB>` with request
`{"method":"exact","device":"cpu","threads":1,"timeLimitMs":1800000,"maxVisits":2000000000,"memoryMiB":<cache>}`.

| Game and state | Binary | Evaluator cache MiB | Wall s | NashConv returned |
|---|---|---|---|---|
| bubble4 (four-player ICM push/fold), 20,000 deals | 5.5 | 128 | 44.06 | 0.00021995727698118745 |
| bubble4, same state | 5.4 (unchanged) | 128 | 43.58 | 0.00021995727698118745 |
| bubble4, same state | 5.5 | 192 | 3.80 | 0.00021995727698118745 |
| bubble4, same state | 5.5 | 256 | 2.99 | 0.00021995727698118745 |
| bubble4, same state | 5.5 | 1,024 | 1.18 | 0.00021995727698118745 |
| bubble4, same state | 5.4 (unchanged) | 1,024 | 1.12 | 0.00021995727698118745 |
| icm8-bb-call-small (eight-handed ICM), 20,000 deals | 5.5 | 128 | 50.75 | 0.02612933673358991 |
| icm8-bb-call-small, same state | 5.5 | 256 | 26.50 | 0.02612933673358991 |
| icm8-bb-call-small, same state | 5.5 | 1,024 | 7.62 | 0.02612933673358991 |

Thread scaling of one exact evaluation, 256 MiB cache (another single-threaded job was running on the host):

| Game | 1 thread | 2 threads | 4 threads |
|---|---|---|---|
| icm8-bb-call-small | 25.96 s | 23.08 s | 14.43 s |
| flop6-jack-small (six-player flop) | 37.12 s | — | 14.18 s |

Conclusion: the 64–71 s per ICM checkpoint that stopped the 5.4 research was cache thrash. The value of an exact
evaluation does not depend on the cache size. The engine code of the evaluator was not changed; the study runner and
the research runner now give it more memory.
