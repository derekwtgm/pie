#!/usr/bin/env python3
"""Prints the Markdown tables of the 5.8 reports from the evidence files (so that no figure is copied by hand).
Usage: tables58.py <release root> response|realistic|convergence-main|convergence-flop6|train|eval|study|rng|icm|profile"""
import json, sys, pathlib, statistics
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.8'; what = sys.argv[2]
def J(p): return json.loads((V / p).read_text())
def f(x, d=3):
    if x is None: return 'n/a'
    return ('%.' + str(d) + 'f') % x
def sig(x, d=3):
    if x is None: return 'n/a'
    return ('%.' + str(d) + 'g') % x
TITLE = {'hu-river': 'heads-up river', 'hu-turn': 'heads-up turn and river', 'river3-chip': 'three-player river, side pots', 'turn4': 'four-player turn and river', 'flop6': 'six-player flop, all-in or fold',
         'final8': 'eight-handed ICM final table', 'bubble4': 'four-player ICM bubble', 'flop5': 'five-player flop', 'flop6w': 'six-player flop, weighted ranges, two bet sizes',
         'early3-flop': 'early stage: three-player flop, three streets of betting', 'mid3-turn': 'medium stacks: three-player turn and river', 'short8-push': 'short stacks: eight-handed push or fold (chip EV)',
         'bubble5-icm': 'five-player ICM bubble', 'sidepot3-icm': 'three-player river with side pots (ICM)'}
if what == 'response':
    s = J('convergence/response/summary.json'); p = J('convergence/response/plan.json'); big = 'trained%d' % p['responseDeals'][-1]; small = 'trained%d' % p['responseDeals'][0]
    print('| Game | Deals | Exact NashConv (mean) | Sampled (5.7): median (min to max) | Restricted (5.7): median (min to max) | Trained, %s response deals | Trained, %s response deals |' % ('{:,}'.format(p['responseDeals'][0]), '{:,}'.format(p['responseDeals'][-1])))
    print('|---|---|---|---|---|---|---|')
    def cell(st): return 'n/a' if not st else '%s (%s to %s)' % (f(st['median'], 2), f(st['min'], 2), f(st['max'], 2))
    for g in p['games']:
        for b in p['budgetsDeals']:
            c = s['games'][g][str(b)]; sh = c['shareOfExactNashConv']
            print('| %s | %s | %s | %s | %s | %s | %s |' % (TITLE.get(g, g), '{:,}'.format(b), sig(c['meanExactNashConv'], 4), cell(sh['sampled']), cell(sh['restricted']), cell(sh[small]), cell(sh[big])))
    print()
    print('| Measure | Seat gains checked | Above the exact gain | States | Median share | Smallest share | States below half | States at 90% or more |'); print('|---|---|---|---|---|---|---|---|')
    for n in ['sampled', 'restricted', small, big]:
        d = s['direction'][n]; o = s['overall'][n] or {}
        print('| %s | %d | %d | %s | %s | %s | %s | %s |' % (n, d['seatGainsChecked'], d['aboveExact'], o.get('states'), f(o.get('medianShare'), 2), f(o.get('minShare'), 2), o.get('statesBelowHalf'), o.get('statesAtLeast90Percent')))
    print(); e = s['estimate']; print('Estimate from independent deals: %d seat estimates; exact gain outside the distribution-free interval: %d; beyond 3 standard errors: %d; beyond 4: %d; largest distance %s standard errors; opponent actions enumerated in %d and sampled in %d; estimates with zero standard error that differ from the exact value: %d.' % (
        e['seats'], e['outsideBounded'], e['beyond3StdErr'], e['beyond4StdErr'], f(e['largestStdErrDistance'], 2), e['enumerated'], e['sampledActions'], e['zeroStdErrMismatch']))
    print(); print('| Game | Deals | Seconds: exact | sampled | restricted | trained %s | trained %s |' % (small[7:], big[7:])); print('|---|---|---|---|---|---|---|')
    for g in p['games']:
        b = p['budgetsDeals'][-1]; m = s['games'][g][str(b)]['medianSeconds']
        print('| %s | %s | %s | %s | %s | %s | %s |' % (TITLE.get(g, g), '{:,}'.format(b), f(m.get('exact'), 1), f(m.get('sampled'), 1), f(m.get('restricted'), 1), f(m.get(small), 1), f(m.get(big), 1)))
    errs = {(g, b): s['games'][g][b]['errors'] for g in s['games'] for b in s['games'][g] if s['games'][g][b]['errors']}
    if errs: print(); print('Errors recorded:', json.dumps({'%s %s' % k: v for k, v in errs.items()}))
elif what == 'realistic':
    s = J('convergence/realistic/summary.json'); p = J('convergence/realistic/plan.json'); raw = [json.loads(l) for l in (V / 'convergence/realistic/raw.jsonl').read_text().splitlines() if l.strip()]
    print('| Fixture | Deals | Table MiB | One-decision measure (5.7): mean of seeds (largest sum of the seats\' standard errors) | Trained response (5.8): mean of seeds | Trained, per seed (standard error) | Sum of the seats\' distribution-free 95% lower bounds: per seed | Seeds where trained is larger | Opponent actions | Seconds: one-decision / trained | Peak resident MiB of the trained-response run |'); print('|---|---|---|---|---|---|---|---|---|---|---|')
    for fx in p['fixtures']:
        for b in p['budgetsDeals']:
            c = s['fixtures'].get(fx, {}).get(str(b)); cell = [r for r in raw if r['fixture'] == fx and r['deals'] == b and 'sum' in r['trained']]
            if not c or not cell: continue
            per = ', '.join('%s (%s)' % (sig(x, 3), sig(se, 2)) for x, se in zip(c['trained']['perSeed'], c['trained']['perSeedStdErr']))
            print('| %s | %s | %s | %s (%s) | %s | %s | %s | %d of %d | %s | %s / %s | %s |' % (fx, '{:,}'.format(b), f(c['tableMiB'], 1), sig(c['sampled']['meanSum'], 3), sig(max(x for x in c['sampled']['perSeedStdErr'] if x is not None), 2), sig(c['trained']['meanSum'], 3), per,
                  ', '.join(sig(sum(r['trained']['seatBounded95']), 3) for r in cell), c['trainedLargerInSeeds'], c['seeds'], '/'.join(sorted({r['trained']['opponentActions'] for r in cell})), f(c['sampled']['medianSeconds'], 0), f(c['trained']['medianSeconds'], 0), f(max(r['trained']['peakRssMiB'] for r in cell), 0)))
    errs = [(r['fixture'], r['seed'], r['deals'], k, r[k]['error']) for r in raw for k in ('sampled', 'trained') if 'error' in r[k]]
    print(); print('Cells measured: %d of %d planned. Errors recorded: %s.' % (len(raw), len(p['fixtures']) * len(p['seeds']) * len(p['budgetsDeals']), json.dumps(errs) if errs else 'none'))
elif what.startswith('convergence-'):
    a = J('convergence/%s/analysis.json' % what.split('-', 1)[1])
    print('| Game | Budget | Contrast | Role | Mean NashConv: candidate / reference | Ratio | Seeds lower / higher / equal | Sign test p (Bonferroni) | t interval (Bonferroni) | Identical files | Verdict |'); print('|---|---|---|---|---|---|---|---|---|---|---|')
    for game, g in a['games'].items():
        for cell, c in g.items():
            for name, k in c['contrasts'].items():
                ti = k.get('tIntervalBonferroni'); files = ('%d of %d' % (k['identicalCheckpointFiles'], k['checkpointPairs'])) if 'checkpointPairs' in k else ''
                print('| %s | %s | %s | %s | %s / %s | %s | %s / %s / %s | %s | %s | %s | **%s** |' % (game, cell.replace('deals:', '').replace('time:', '') + (' deals' if cell.startswith('deals') else ' s'), name, k['role'], sig(k.get('meanCandidate'), 4), sig(k.get('meanReference'), 4), f(k.get('ratioOfMeans'), 3),
                      k.get('seedsLower'), k.get('seedsHigher'), k.get('seedsEqual'), sig(k.get('signTestPBonferroni'), 2), ('[%s, %s]' % (sig(ti[0], 3), sig(ti[1], 3))) if ti else '', files, k['verdict']))
    print(); print('| Game | Budget | Arm | Mean NashConv | Mean sampled deals |'); print('|---|---|---|---|---|')
    for game, g in a['games'].items():
        for cell, c in g.items():
            for arm, v in c['arms'].items(): print('| %s | %s | %s | %s | %s |' % (game, cell, arm, sig(v['meanNashConv'], 4), '{:,.0f}'.format(v['meanDeals'])))
elif what == 'rng':
    d = J('limits/rng-period.json')
    print('| Fixture | Seats | Numbers drawn per deal: deal stream | action stream | Share of a cycle at 10,000,000 deals: deal stream | action stream | Deals until the deal stream repeats | until the action stream repeats |'); print('|---|---|---|---|---|---|---|---|')
    for r in d['fixtures']:
        print('| %s | %d | %s | %s | %s | %s | %s | %s |' % (r['fixture'], r['players'], f(r['dealStreamDrawsPerDeal'], 2), f(r['actionStreamDrawsPerDeal'], 2), f(r['shareOfCycleAtTheLimit']['dealStream'], 3), f(r['shareOfCycleAtTheLimit']['actionStream'], 3),
              '{:,.0f}'.format(r['dealsUntilDealStreamRepeats']) if r['dealsUntilDealStreamRepeats'] else 'n/a', '{:,.0f}'.format(r['dealsUntilActionStreamRepeats']) if r['dealsUntilActionStreamRepeats'] else 'n/a'))
    print(); print('Largest share of a cycle at the limit with the default trainer: %s; the limit could grow by a factor of at most %s before a stream repeats on a shipped fixture.' % (f(d['largestShareOfACycleAtTheLimitWithTheDefaultTrainer'], 3), f(d['largestFactorTheLimitCouldGrowBeforeAStreamRepeats'], 1)))
elif what == 'icm':
    d = J('performance/icm-instructions.json')
    print('| Game | Updates | Table budget (ICM cache entries) | Instructions 5.7.1 | Instructions 5.8 | Ratio | Share of instructions in the ICM routine: 5.7.1 | 5.8 | Identical state |'); print('|---|---|---|---|---|---|---|---|---|')
    ent = {16: 4093, 256: 16381, 1024: 32749}
    for r in d['rows']:
        a, b = r['5.7.1'], r['5.8']
        print('| %s | %s | %d MiB (%s) | %s | %s | %s | %s | %s | %s |' % (r['game'], '{:,}'.format(r['updates']), r['tableMemoryMiB'], '{:,}'.format(ent[r['tableMemoryMiB']]) if r['icm'] else 'no ICM', '{:,}'.format(a['instructions']), '{:,}'.format(b['instructions']), f(r['ratio'], 4),
              f(a['inTournamentEvaluate'] / a['instructions'], 3), f(b['inTournamentEvaluate'] / b['instructions'], 3), 'yes' if r['identicalState'] else 'NO'))
elif what == 'profile':
    d = J('performance/profile.json')
    print('| Game | Seats | Table MiB | State visits per deal | Instructions per deal | per visit | First-level data-cache misses per deal | Last-level misses per deal | Largest shares of the instructions |'); print('|---|---|---|---|---|---|---|---|---|')
    short = lambda fn: fn.split('(')[0].replace('es::', '')
    for r in d['rows']:
        print('| %s | %d | %s | %s | %s | %s | %s | %s | %s |' % (r['game'], r['players'], f(r['tableMiB'], 1), f(r['visitsPerDeal'], 0), '{:,.0f}'.format(r['instructionsPerDeal']), f(r['instructionsPerVisit'], 0), f(r['d1MissesPerDeal'], 0), f(r['llMissesPerDeal'], 1),
              ', '.join('%s %d%%' % (short(x['function']), round(100 * x['share'])) for x in r['top'][:4])))
elif what == 'train':
    d = J('performance/train/summary.json')
    print('| Fixture | Seats | Deals | Table MiB | 5.7.1: best seconds (median) | 5.8: best seconds (median) | 5.8 deals per second (best) | Speed 5.8 / 5.7.1: best | median | Identical state |'); print('|---|---|---|---|---|---|---|---|---|---|')
    sb = []; sm = []
    for r in d['fixtures']:
        a, b = r['v55'], r['v56']; sb.append(r['speedupBest']); sm.append(r['speedupMedian'])
        print('| %s | %d | %s | %s | %s (%s) | %s (%s) | %s | %s | %s | %s |' % (r['fixture'], r['players'], '{:,}'.format(r['deals']), f(r['tableMiB'], 1), f(a['minSeconds'], 2), f(a['medianSeconds'], 2), f(b['minSeconds'], 2), f(b['medianSeconds'], 2), '{:,.0f}'.format(b['dealsPerSecondBest']),
              f(r['speedupBest'], 3), f(r['speedupMedian'], 3), ('yes' if r['stateIdentical'] else 'NO') + (' (table limit reached)' if r.get('limitReached') else '')))
    print(); print('Speed ratio 5.8 / 5.7.1 over the %d fixtures: best-of-repetitions %s to %s (median %s); median-of-repetitions %s to %s (median %s). %d repetitions per binary, order alternated.' % (len(sb), f(min(sb), 3), f(max(sb), 3), f(statistics.median(sb), 3), f(min(sm), 3), f(max(sm), 3), f(statistics.median(sm), 3), d['plan']['repetitions']))
elif what == 'eval':
    d = J('performance/eval/summary.json')
    print('| Case | Kind | 5.7.1: median seconds | 5.8: median seconds | Speed 5.8 / 5.7.1 (median) | Identical results (numbers compared) |'); print('|---|---|---|---|---|---|')
    sp = []
    for r in d['cases']:
        sp.append(r['speedupMedian']); print('| %s | %s | %s | %s | %s | %s (%s) |' % (r['case'], r['kind'], f(r['v56']['medianSeconds'], 2), f(r['v57']['medianSeconds'], 2), f(r['speedupMedian'], 3), 'yes' if r['identicalResults'] else 'NO', r.get('numbersCompared')))
    print(); print('Speed ratio 5.8 / 5.7.1 over the %d cases: %s to %s, median %s. ICM cases: %s.' % (len(sp), f(min(sp), 3), f(max(sp), 3), f(statistics.median(sp), 3), ', '.join(f(r['speedupMedian'], 3) for r in d['cases'] if 'ICM' in r['case'] or 'icm' in r['case']) or 'none'))
elif what == 'study':
    d = J('performance/study/summary.json')
    print('| Study | 5.7.1 wall seconds | 5.8 wall seconds | Ratio 5.7.1 / 5.8 | Identical measurements (numbers compared) |'); print('|---|---|---|---|---|')
    sp = []
    for r in d['studies']:
        sp.append(r['wallRatio56Over57']); print('| %s | %s | %s | %s | %s (%s) |' % (r['study'], f(r['v56']['wallSeconds'], 2), f(r['v57']['wallSeconds'], 2), f(r['wallRatio56Over57'], 3), 'yes' if r['identicalMeasurements'] else 'NO', r.get('numbersCompared')))
    print(); print('Wall-time ratio 5.7.1 / 5.8 over the %d studies: %s to %s, median %s (above 1: 5.8 faster). One run per binary per study.' % (len(sp), f(min(sp), 3), f(max(sp), 3), f(statistics.median(sp), 3)))
elif what == 'fixture-instr':
    d = J('performance/fixture-instructions.json')
    print('| Fixture | Seats | Instructions for 20,000 deals: 5.7.1 | 5.8 | Ratio 5.8 / 5.7.1 | Peak resident MiB after 300,000 deals: 5.7.1 / 5.8 | Table MiB | Identical states |'); print('|---|---|---|---|---|---|---|---|')
    rr = []
    for r in d['rows']:
        a, b = r['5.7.1'], r['5.8']; rr.append(r['instructionRatio'])
        print('| %s | %d | %s | %s | %s | %s / %s | %s | %s |' % (r['fixture'], r['players'], '{:,}'.format(a['instructions']), '{:,}'.format(b['instructions']), f(r['instructionRatio'], 4), f(a['processPeakRssMiB'], 1), f(b['processPeakRssMiB'], 1), f(b['tableMiB'], 1), 'yes' if r['identicalStates'] else 'NO'))
    print(); print('Instruction ratio 5.8 / 5.7.1 over the %d fixtures: %s to %s, median %s.' % (len(rr), f(min(rr), 4), f(max(rr), 4), f(statistics.median(rr), 4)))
else: sys.exit('unknown table ' + what)
