#!/bin/bash
# EightMax 5.8 sanitizer runs: the code 5.8 added or touched (the trained response and its evaluation, the one-seat
# switch of the trainer, the ICM cache, the early budget check) and the code they run through.
# Usage: bash validation/5.8/sanitize58.sh <release root> <work dir>
#  1. AddressSanitizer + UndefinedBehaviorSanitizer + float-cast-overflow build of the host and CLI (the 5.3 builder);
#     then the whole 5.8 regression file, the 5.5 and 5.6 files (study checkpoints, recovery, the lock), the
#     checkpoint tests of the 5.7.1 file, and mwcli --selftest58 (all sections) and --selftest571 (checkpoint mode).
#  2. ThreadSanitizer build of the CLI: responses of six seats side by side with frozen-batch response training on
#     four threads and four evaluation threads; an ICM game with parallel seats; a checkpointed study with seeds side
#     by side (ICM, each seed's own cache); mwcli --selftest58 (response and engine sections).
#  3. Leak check: the ASan CLI with detect_leaks=1 on a complete --response run with parallel seats and on a refused
#     over-limit study.
set -u
root=$(cd "$1" && pwd); work=$2; out="$root/validation/5.8/sanitizers"; rm -rf "$work" "$out"; mkdir -p "$work" "$out"
T="$root/source/tests"; R="$root/validation/5.8/windows/response"
bash "$root/validation/5.3/sanitizers/build-final.sh" "$root/source" "$root/build" "$work/asan" > "$out/build-asan-ubsan.log" 2>&1; echo "asan build exit $?" | tee "$out/build-asan-ubsan.exit"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax" EM_TEST_HOST_STDERR="$out/host-stderr.log" \
  node --test --test-concurrency=1 --test-reporter=tap "$T/v58.test.js" > "$out/v58-asan-ubsan.tap" 2> "$out/v58-asan-ubsan.stderr"
echo "asan tests (5.8 file) exit $?" | tee "$out/v58-asan-ubsan.exit"; tail -9 "$out/v58-asan-ubsan.tap"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax" EM_TEST_HOST_STDERR="$out/host-stderr.log" \
  node --test --test-concurrency=1 --test-reporter=tap "$T/v55.test.js" "$T/v56.test.js" > "$out/v55-v56-asan-ubsan.tap" 2> "$out/v55-v56-asan-ubsan.stderr"
echo "asan tests (5.5 and 5.6 files) exit $?" | tee "$out/v55-v56-asan-ubsan.exit"; tail -9 "$out/v55-v56-asan-ubsan.tap"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax" \
  node --test --test-concurrency=1 --test-reporter=tap --test-name-pattern='formatting is not corruption|altered data and altered checksums|damaged, truncated and missing|engine repair|EM_TEST_SAVE_FAULT_FILE' "$T/v571.test.js" > "$out/v571-asan-ubsan.tap" 2> "$out/v571-asan-ubsan.stderr"
echo "asan tests (5.7.1 file, the five checkpoint tests) exit $?" | tee "$out/v571-asan-ubsan.exit"; tail -9 "$out/v571-asan-ubsan.tap"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 "$work/asan/mwcli" --selftest58 "$root/studies" "$work/st58-asan" all > "$out/selftest58-asan.stdout" 2> "$out/selftest58-asan.stderr"; echo "asan selftest58 exit $?" | tee "$out/selftest58-asan.exit"
cp "$work/st58-asan/selftest58.json" "$out/selftest58-asan.json" 2>/dev/null
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 "$work/asan/mwcli" --selftest571 "$root/studies" "$work/st571-asan" checkpoint > "$out/selftest571-asan.stdout" 2> "$out/selftest571-asan.stderr"; echo "asan selftest571 (checkpoint mode) exit $?" | tee "$out/selftest571-asan.exit"
grep -c -E 'ERROR: AddressSanitizer|runtime error:' "$out"/*.tap "$out"/*.stderr "$out"/*.stdout "$out/host-stderr.log" 2>/dev/null | tee "$out/sanitizer-report-counts.txt"
# 2
obj="$work/tsan"; mkdir -p "$obj"; printf '#define EM_VERSION "5.8"\n#define EM_BUILD_ID "tsan"\n' > "$obj/build_info.h"
( cd "$root/source/native" && g++ -std=c++20 -O1 -g1 -fsanitize=thread -fno-omit-frame-pointer -march=x86-64 -ffp-contract=off -I. -c mw.cpp -o "$obj/mw.o" && gcc -O1 -fsanitize=thread -c json.c -o "$obj/json.o" &&
  g++ -std=c++20 -O1 -g1 -fsanitize=thread -march=x86-64 -ffp-contract=off -I. -include "$obj/build_info.h" mwcli.cpp "$obj/mw.o" "$obj/json.o" -lpthread -ldl -lz -o "$obj/mwcli" ) > "$out/build-tsan.log" 2>&1; echo "tsan build exit $?" | tee "$out/build-tsan.exit"
export TSAN_OPTIONS=halt_on_error=0
{ node "$root/source/tools/games58.js" spec flop6 "$work/f6.json" 7 '{"batchDeals":8,"actionStreams":"deal"}'
  "$obj/mwcli" "$work/f6.json" 600 4 "$work/f6.state" 128 > /dev/null; echo "frozen-batch training on four threads exit $?"
  echo '{"responseDeals":8000,"samples":4096,"seed":58,"exact":true,"parallelSeats":3,"threads":4}' > "$work/rq.json"
  "$obj/mwcli" --response "$work/f6.json" "$work/f6.state" "$work/rq.json" 128 > "$work/f6-response.json"; echo "six seats, three side by side, four threads each exit $?"
  "$obj/mwcli" "$R/bubble4.spec.json" 1500 4 "$work/b4.state" 128 > /dev/null; echo "ICM frozen-batch training exit $?"
  echo '{"responseDeals":8000,"samples":2048,"seed":58,"exact":true,"parallelSeats":4,"threads":2}' > "$work/rq4.json"
  "$obj/mwcli" --response "$R/bubble4.spec.json" "$work/b4.state" "$work/rq4.json" 128 > "$work/b4-response.json"; echo "ICM response, four seats side by side exit $?"
  "$obj/mwcli" --study "$root/studies/icm8-bb-call-small.emfix.json" "$work/t1.json" variants=baseline seeds=101,102,103 budgets=2000,6000 evaluationSamples=256 qualitySamples=64 threads=3 parallelSeeds=3 quiet=1 checkpoint="$work/tck1" checkpointSeconds=0.05; echo "ICM study, three seeds side by side exit $?"
  "$obj/mwcli" --selftest58 "$root/studies" "$work/st58-tsan" engine; echo "selftest58 (engine) exit $?"
  "$obj/mwcli" --selftest58 "$root/studies" "$work/st58-tsan-r" limits; echo "selftest58 (limits) exit $?"; } > "$out/tsan.log" 2>&1
echo "ThreadSanitizer warnings: $(grep -c 'WARNING: ThreadSanitizer' "$out/tsan.log")" | tee "$out/tsan-summary.txt"; grep -E 'exit [0-9]+' "$out/tsan.log" | tee -a "$out/tsan-summary.txt"
# the instrumented program computes what the release program computes: the same response bits for the six-player game
"$root/build/linux/mwcli" --response "$work/f6.json" "$work/f6.state" "$work/rq.json" 128 > "$work/f6-response-release.json" 2>/dev/null
python3 - "$work/f6-response.json" "$work/f6-response-release.json" <<'PY' | tee -a "$out/tsan-summary.txt"
import json, sys
a, b = (json.load(open(f)) for f in sys.argv[1:3]); bits = lambda d: [(s['seat'], s['sampled']['gain']['gainBits'], s['exact']['gainBits']) for s in d['seats']]
print('response bits of the instrumented program equal the release program:', bits(a) == bits(b), '(%d seats)' % len(a['seats']))
PY
# 3
echo '{"responseDeals":20000,"samples":4096,"seed":58,"exact":true,"parallelSeats":2}' > "$work/rql.json"
"$root/build/linux/mwcli" "$R/turn4.spec.json" 5000 1 "$work/t4.state" 128 > /dev/null
ASAN_OPTIONS=detect_leaks=1 "$work/asan/mwcli" --response "$R/turn4.spec.json" "$work/t4.state" "$work/rql.json" 128 > /dev/null 2> "$out/leak-response.log"; echo "$?" > "$out/leak-response.exit"
ASAN_OPTIONS=detect_leaks=1 "$work/asan/mwcli" --study "$root/studies/known-akq-river.emfix.json" "$work/over.json" quiet=1 seeds=1 budgets=10000001 > /dev/null 2> "$out/leak-refused-study.log"; echo "$?" > "$out/leak-refused-study.exit"
echo "leak check: --response with parallel seats exit $(cat "$out/leak-response.exit") (0 expected), refused over-limit study exit $(cat "$out/leak-refused-study.exit") (1 expected); LeakSanitizer reports: $(cat "$out/leak-response.log" "$out/leak-refused-study.log" | grep -c 'ERROR: LeakSanitizer')" | tee "$out/leak-summary.txt"
{ cat "$out"/build-asan-ubsan.exit "$out"/v58-asan-ubsan.exit "$out"/v55-v56-asan-ubsan.exit "$out"/v571-asan-ubsan.exit "$out"/selftest58-asan.exit "$out"/selftest571-asan.exit "$out"/build-tsan.exit
  for f in v58-asan-ubsan v55-v56-asan-ubsan v571-asan-ubsan; do grep -E '^# (tests|pass|fail|skipped)' "$out/$f.tap" | tr '\n' ' '; echo "($f)"; done
  echo "sanitizer reports (ERROR: AddressSanitizer / runtime error) in all outputs: $(awk -F: '{s+=$NF} END{print s+0}' "$out/sanitizer-report-counts.txt")"
  cat "$out/tsan-summary.txt" "$out/leak-summary.txt"; } > "$out/summary.txt"
