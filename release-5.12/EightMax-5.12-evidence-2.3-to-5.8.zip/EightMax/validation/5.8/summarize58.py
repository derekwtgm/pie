#!/usr/bin/env python3
"""Collects the evidence under validation/5.8 into validation/5.8/validation-summary.json (the machine-readable
validation status of the release; release58.py copies it into the identity file). Usage: summarize58.py <release root>
Every figure is read from an evidence file; a missing file gives null, never a default."""
import json, sys, pathlib, re
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.8'
def load(p):
    p = V / p; return json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else None
def text(p):
    p = V / p; return p.read_text(errors='replace') if p.exists() else None
def tap_totals(t):
    if t is None: return None
    g = lambda k: (lambda m: int(m.group(1)) if m else None)(re.search(r'^# %s (\d+)' % k, t, re.M))
    return {'tests': g('tests'), 'passed': g('pass'), 'failed': g('fail'), 'skipped': g('skipped'), 'failedTests': re.findall(r'^not ok \d+ - (.*)$', t, re.M), 'skippedTests': [m[0] for m in re.findall(r'^ok \d+ - (.*?) # SKIP(.*)$', t, re.M)]}
def selftest(p):
    d = load(p)
    if d is None: return None
    bad = [c.get('section', '') + ' ' + c.get('id', c.get('name', '')) for c in d['checks'] if not (c.get('status') == 'passed' or c.get('passed') is True)]
    return {'passed': d['passed'], 'failed': d['failed'], 'untested': d.get('untested'), 'build': d['build'], 'seconds': d.get('seconds'), 'checks': len(d['checks']), 'notPassed': bad}
def lines(p):
    t = text(p); return [l for l in t.splitlines() if l.strip()] if t else None
info = json.loads((root / 'BUILD-INFO.json').read_text())
S = {'release': info['version'], 'build': info['build'], 'successorOf': {'release': '5.7.1', 'build': '65e835e6b7060960'},
     'classes': {'1': 'independently mathematically validated (an independent implementation, an exact reference, or the unchanged 5.7.1 binary agrees)',
                 '2': 'tested on Linux, under Wine or by simulation (the project\'s own tests; the Windows programs under Wine)',
                 '3': 'implemented, awaiting physical Windows / GPU validation (never executed on Windows hardware or an NVIDIA GPU)',
                 '4': 'unsuccessful, incomplete, not implemented or not executed'}}
S['baseline571'] = load('baseline/baseline-5.7.1.json')
# ---- regression ----
reg = tap_totals(text('tests/full-regression.tap'))
if reg: reg['rerunAlone'] = lines('tests/rerun-alone.txt') or []; reg['failedAgainAlone'] = [l for l in reg['rerunAlone'] if l.startswith('FAILED AGAIN')]
S['regressionLinux'] = reg
S['selftest58Linux'] = selftest('selftest/selftest58-linux.json'); S['selftest571Linux'] = selftest('selftest/selftest571-linux.json'); S['selftest57Linux'] = selftest('selftest/selftest57-linux.json')
idn = load('identity/summary.json'); S['identityAgainst571'] = idn
S['mutations'] = (lambda d: None if d is None else {'mutants': d['mutants'], 'everyMutantDetectedAndTheControlClean': d['everyMutantDetectedAndTheControlClean'], 'rows': [{k: r.get(k) for k in ('mutant', 'what', 'section', 'exit', 'expectedToFail', 'kindsNotPassed', 'unexpectedKinds', 'detectedAsExpected')} for r in d['rows']]})(load('mutation58.json'))
S['sanitizers'] = {'summary': lines('sanitizers/summary.txt'), 'tsanWarnings': (lambda t: int(re.search(r'ThreadSanitizer warnings: (\d+)', t).group(1)) if t and re.search(r'ThreadSanitizer warnings: (\d+)', t) else None)(text('sanitizers/tsan-summary.txt')),
                   'asanUbsanReports': (lambda t: sum(int(l.rsplit(':', 1)[1]) for l in t.splitlines() if ':' in l and l.rsplit(':', 1)[1].strip().isdigit()) if t else None)(text('sanitizers/sanitizer-report-counts.txt')),
                   'v58': tap_totals(text('sanitizers/v58-asan-ubsan.tap')), 'v55v56': tap_totals(text('sanitizers/v55-v56-asan-ubsan.tap')), 'v571': tap_totals(text('sanitizers/v571-asan-ubsan.tap')),
                   'selftest58': selftest('sanitizers/selftest58-asan.json'), 'leak': lines('sanitizers/leak-summary.txt')}
S['hostCheckpointLock'] = {'readme': 'validation/5.8/host-lock/README.md', 'reproductionWithThe571Order': tap_totals(text('host-lock/reproduction-5.7.1-order.tap')), 'repairedHost': tap_totals(text('host-lock/repaired-host.tap'))}
# ---- experiments ----
def rs():
    s = load('convergence/response/summary.json'); p = load('convergence/response/plan.json')
    return None if s is None else {'plan': 'validation/5.8/convergence/response/plan.json', 'build': (p or {}).get('build'), 'states': s['states'], 'direction': s['direction'], 'estimate': s['estimate'], 'overall': s['overall']}
S['lowerBoundMeasuresAgainstExactNashConv'] = rs()
S['trainedResponseOnRealisticFixtures'] = load('convergence/realistic/summary.json')
S['estimateWithSampledOpponentActions'] = {'againstExactGains': load('convergence/sampled-actions/summary.json'), 'unbiasednessOnTheEightHandedIcmGame': load('convergence/unbiased/summary.json')}
S['independentPythonCheck'] = (lambda L: None if L is None else {'cases': len([l for l in L if ':' in l]), 'casesWithExit0': len([l for l in L if 'exit 0' in l]), 'summary': L})(lines('independent/summary.txt'))
def conv(name):
    a = load('convergence/%s/analysis.json' % name)
    if a is None: return None
    out = {'rows': a['rows'], 'contrasts': []}
    for game, g in a['games'].items():
        for cell, c in g.items():
            for cname, k in c['contrasts'].items():
                out['contrasts'].append({'game': game, 'budget': cell, 'contrast': cname, 'role': k['role'], 'verdict': k['verdict'], 'ratioOfMeans': k.get('ratioOfMeans'), 'seedsLower': k.get('seedsLower'), 'seedsHigher': k.get('seedsHigher'), 'seedsEqual': k.get('seedsEqual'),
                                         'identicalCheckpointFiles': k.get('identicalCheckpointFiles'), 'checkpointPairs': k.get('checkpointPairs')})
    return out
S['convergenceAgainst571'] = {'main': conv('main'), 'flop6': conv('flop6')}
S['performance'] = {'training': load('performance/train/summary.json'), 'evaluation': load('performance/eval/summary.json'), 'studies': load('performance/study/summary.json'), 'icmInstructionCounts': load('performance/icm-instructions.json'), 'fixtureInstructionCountsAndPeakMemory': load('performance/fixture-instructions.json'), 'profile': load('performance/profile.json')}
S['randomStreams'] = load('limits/rng-period.json')
S['experimentsNotAdopted'] = ['validation/5.8/experiments/compact-row-offsets.md']
# ---- Wine ----
wine = {'buildId': (text('wine/build-id.txt') or '').strip() or None, 'wineVersion': (text('wine/wine-version.txt') or '').strip() or None, 'selftest58': selftest('wine/selftest58-wine.json'), 'selftest571': selftest('wine/selftest571-wine.json'), 'selftest57': selftest('wine/selftest57-wine.json'),
        'referenceResponses': (lambda d: None if d is None else {k: d[k] for k in ('cases', 'allIdentical', 'recordedBy')})(load('wine/reference-responses-wine.json')), 'tests': {}}
for f in ('v58', 'v571', 'v57', 'v56', 'v55'): wine['tests'][f] = tap_totals(text('wine/%s.test.tap' % f))
wine['rerunAlone'] = lines('wine/rerun-alone.txt')
S['wine'] = wine
S['ui'] = load('ui/study-ui56.json'); S['stability'] = load('stability/stability58.json')
S['uiFirstRunWithThe571Driver'] = load('ui-first-run-with-the-5.7.1-driver/study-ui56.json'); S['stabilityFirstRunWithThe55Tool'] = load('stability-first-run-with-the-5.5-tool/stability55.json')
S['desktopHostRefusalOfAnOverLimitStudy'] = load('limits/host-refusal.json')
S['launchersUnderWineCmd'] = 'validation/5.8/wine/launchers-under-wine-cmd.md'
S['windows'] = {'class': 3, 'executedOnWindowsHardware': False, 'powershellScriptExecuted': False, 'ciWorkflowExecuted': False,
                'why': 'The development session had no Windows machine. Downloading and running PowerShell was refused by the session\'s permission policy, and so was push access to the repository, so validate_windows58.ps1 was checked statically only and the GitHub Actions workflow could not be started.',
                'staticChecks': load('powershell/static-checks.json'), 'launchers': ['Run 5.8 focused validation.bat', 'Run 5.8 Windows validation.bat', 'Run 5.8 response example.bat'], 'instructions': 'WINDOWS-TESTS-5.8.md',
                'expectedTotalsDerivedFromTheScriptNotFromARun': {'focused': 54, 'full': 151}}
S['gpu'] = {'class': 3, 'cudaCodeChangedIn58': False, 'executedOnAnNvidiaGpuFor58': False, 'evidenceOf57OnTheTargetPc': 'validation/5.7.1/windows-5.7-physical', 'analysis': 'PERFORMANCE-5.8.md, section 6'}
(V / 'validation-summary.json').write_text(json.dumps(S, indent=1)); print('written', V / 'validation-summary.json')
