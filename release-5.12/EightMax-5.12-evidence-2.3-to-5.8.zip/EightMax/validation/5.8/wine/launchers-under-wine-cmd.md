# The 5.8 launchers run by Wine's command interpreter

What this is: the three `.bat` files of 5.8 executed by `wine cmd /c` (Wine 9.0) in scratch copies of the release, with
`EIGHTMAX_NO_PAUSE=1`. Wine's `cmd` is not Windows' `cmd.exe`, and Wine has no real PowerShell: its `powershell.exe`
is a stub that does nothing and ends with status 0. So this is evidence (class 2) about the batch logic and about
the steps that need no PowerShell. It is not a Windows run, and the validation script itself did not execute.

| Launcher | Result | Files here |
|---|---|---|
| `Run 5.8 response example.bat` | exit 0; trained the fixture, wrote the result document (6 seats, exact share 0.835) | `response-example-bat.stdout`, `.exit`, `.result.json` |
| `Run 5.8 focused validation.bat`, as first written | step 1: 33 of 33, report file written. Step 2: the stub ended with status 0 and wrote nothing, and the launcher announced **"Every required check of the script passed"** and exit status 0 | `focused-launcher-before-correction.stdout` |
| `Run 5.8 focused validation.bat`, corrected, with a stale report file planted beforehand | step 1: 33 of 33. Step 2: the stale report is deleted at the start; no report after the script, so status 2: "The validation script itself did not finish ... nothing of the script is counted as passed" | `focused-launcher-after-correction.stdout`, `.exit`, `focused-launcher-selftest58.json` |
| `Run 5.8 Windows validation.bat`, corrected | steps 1 to 3: `--selftest57` 28 of 28, `--selftest571` 24 of 24, `--selftest58` 33 of 33, three report files written. Step 4: no report, status 2 | `full-launcher-after-correction.stdout`, `.exit`, `full-launcher-selftest57.json`, `full-launcher-selftest571.json`, `full-launcher-selftest58.json` |

## The defect this run found, and the correction

A launcher took the exit status of `powershell.exe` as the result of the validation. A PowerShell that ends with
status 0 without running the script (here: Wine's stub; on a Windows PC conceivably a policy that blocks the script
silently) was therefore announced as a pass, and a report file left by an earlier run would have looked like the
report of this one. Both launchers now

1. delete the script's report files of an earlier run at the start (as they already did for the self-test reports), and
2. set the result to 2 when the script's JSON report does not exist afterwards, whatever status PowerShell returned.

The launchers are in the release root and are not part of the source fingerprint; the build identifier is
unchanged. The launchers of 5.7.1 and earlier have the same weakness and were left as shipped.
