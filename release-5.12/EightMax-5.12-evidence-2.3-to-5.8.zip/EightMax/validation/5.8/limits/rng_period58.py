#!/usr/bin/env python3
"""EightMax 5.8: how many random numbers one sampled deal draws, and when a 32-bit stream has used its whole cycle.
Usage: rng_period58.py <release root> <mwcli> <out.json> [deals=200000]

The engine's deal stream and its shared action stream are generators of the form  state += 0x6d2b79f5 (mod 2^32);
output = hash(state).  The increment is odd, so the state visits all 2^32 values before it repeats: a stream that has
drawn 2^32 numbers repeats exactly. The engine reports both states after training ("rng", "actionRng"), and
    draws = (state_after - state_before) * inverse(0x6d2b79f5)   (mod 2^32)
is the exact number of draws when it is below 2^32. This script trains every shipped fixture (variant 0, the default
trainer: one deal per update) for a number of deals small enough for that, in two halves (the second half is the
steadier rate: early deals create betting states), and extrapolates to the 10,000,000-update limit and beyond.
With frozen batches the action streams are derived per (update, deal) and do not accumulate; the deal stream does."""
import sys, json, subprocess, pathlib, tempfile, os
root = pathlib.Path(sys.argv[1]).resolve(); cli = str(pathlib.Path(sys.argv[2]).resolve()); out = pathlib.Path(sys.argv[3]); deals = int(sys.argv[4]) if len(sys.argv) > 4 else 200000
INC = 0x6d2b79f5; INV = pow(INC, -1, 1 << 32); CYCLE = 1 << 32; LIMIT = 10000000
assert (INC * INV) % CYCLE == 1 and INC % 2 == 1
draws = lambda a, b: ((b - a) * INV) % CYCLE
rows = []; work = pathlib.Path(tempfile.mkdtemp())
for f in sorted((root / 'studies').glob('*.emfix.json')):
    fx = json.loads(f.read_text(encoding='utf-8-sig')); spec = fx['variants'][0]['nativeSpec']; sp = work / 'spec.json'; sp.write_text(json.dumps(spec)); st = work / 'state'
    a = json.loads(subprocess.run([cli, str(sp), str(deals // 2), '1', str(st), '2048'], capture_output=True, text=True, check=True).stdout)
    b = json.loads(subprocess.run([cli, str(sp), str(deals // 2), '1', str(st) + '2', '2048', str(st)], capture_output=True, text=True, check=True).stdout)
    r0, a0 = spec['state']['rng'], spec['state']['actionRng']
    dealPer = draws(a['rng'], b['rng']) / (deals // 2); actionPer = draws(a['actionRng'], b['actionRng']) / (deals // 2)
    assert draws(r0, a['rng']) < CYCLE // 4 and draws(a0, a['actionRng']) < CYCLE // 4, 'use fewer deals: a stream came near its cycle'
    rows.append({'fixture': f.name[:-len('.emfix.json')], 'players': spec['n'], 'startCards': len(spec['board']), 'actionStreams': spec.get('actionStreams', 'shared'),
                 'dealStreamDrawsPerDeal': dealPer, 'actionStreamDrawsPerDeal': actionPer, 'firstHalf': {'dealStream': draws(r0, a['rng']) / (deals // 2), 'actionStream': draws(a0, a['actionRng']) / (deals // 2)},
                 'dealsUntilDealStreamRepeats': CYCLE / dealPer if dealPer else None, 'dealsUntilActionStreamRepeats': CYCLE / actionPer if actionPer else None,
                 'shareOfCycleAtTheLimit': {'dealStream': LIMIT * dealPer / CYCLE, 'actionStream': LIMIT * actionPer / CYCLE},
                 'shareOfDealCycleAt640MillionDeals': 640000000 * dealPer / CYCLE})
    print(rows[-1]['fixture'], 'deal %.2f action %.2f per deal; cycle share at 10M deals: %.3f / %.3f' % (dealPer, actionPer, LIMIT * dealPer / CYCLE, LIMIT * actionPer / CYCLE), flush=True)
worst = max(max(r['shareOfCycleAtTheLimit'].values()) for r in rows)
out.write_text(json.dumps({'generator': 'state += 0x6d2b79f5 (mod 2^32); 2^32 states on one cycle', 'inverseOfIncrement': INV, 'dealsMeasured': deals, 'updateLimit': LIMIT, 'fixtures': rows,
    'largestShareOfACycleAtTheLimitWithTheDefaultTrainer': worst, 'defaultTrainerStaysInsideOneCycleAtTheLimit': worst < 1,
    'largestFactorTheLimitCouldGrowBeforeAStreamRepeats': 1 / worst if worst else None,
    'frozenBatchesOf64': 'at the same update limit a state holds up to 640,000,000 deals; shareOfDealCycleAt640MillionDeals above 1 means the deal stream repeats within that budget'}, indent=1))
