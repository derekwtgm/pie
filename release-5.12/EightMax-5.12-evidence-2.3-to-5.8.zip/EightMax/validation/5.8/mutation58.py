#!/usr/bin/env python3
"""EightMax 5.8: does the 5.8 self-test notice a broken engine?
Usage: mutation58.py <release root> <work dir> <out.json>

Each mutant is the engine with ONE behaviour of 5.8 broken by a one-line change of a copy of source/native. The mutant
is built as mwcli (the release flags) and runs the section of `--selftest58` that covers the behaviour. A mutant is
DETECTED when the checks named for it fail (and the exit status is 1); the other checks of the section are listed too,
so a check that fails for every mutant, or never, is visible. The unmodified engine is the control (nothing fails)."""
import sys, json, subprocess, pathlib, shutil, time
root = pathlib.Path(sys.argv[1]).resolve(); work = pathlib.Path(sys.argv[2]).resolve(); out = pathlib.Path(sys.argv[3]); work.mkdir(parents=True, exist_ok=True)
R = 'response58.hpp'
MUTANTS = [
 ('control', None, None, None, 'all', [], 'the unmodified engine'),
 ('opponents-not-frozen', R, 'for (int a = 0; a < k; a++) reg[a] = total > 0 ? avg[a] : 0.0;\n        otherRows++;', 'otherRows++;', 'response', ['R1', 'R2'],
  'mw_response_begin leaves the other seats\' regrets in place: the trainer no longer plays sigma for them'),
 ('every-seat-learns', R, 'g.onlySeat = seat; g.enumerateFrom = 0;', 'g.onlySeat = -1; g.enumerateFrom = 0;', 'response', ['R1', 'R2'],
  'the one-seat switch is not set: the response training updates every seat'),
 ('sigma-not-restored', R, 'for (int a = 0; a < k; a++) reg[a] = oldTotal > 0 ? old[a] : 0.0;\n  }', '}', 'response', ['R1'],
  'mw_response_end leaves the response training\'s regrets in the seat\'s regret slot: "current" is not sigma'),
 ('estimate-ignores-the-response', R, 'out.r += pr[a] * v.r; out.s += ps[a] * v.s;\n  }\n  return out;\n}\nstruct Block58', 'out.r += ps[a] * v.r; out.s += ps[a] * v.s;\n  }\n  return out;\n}\nstruct Block58', 'response', ['R4'],
  'the evaluation walk weights both values with sigma: the estimated gain is always 0'),
 ('estimate-biased-upward', R, 'const double d = v.r - v.s;', 'const double d = v.r - v.s + 0.25 * std::fabs(v.r);', 'response', ['R4'],
  'a quarter of the absolute response value is added to every sample'),
 ('threads-change-the-streams', R, 'Rng64 deals{seed58((uint64_t)seed, (uint64_t)seat, b, 0)}, actions{seed58((uint64_t)seed, (uint64_t)seat, b, 1)};', 'Rng64 deals{seed58((uint64_t)seed, (uint64_t)seat, b + (uint64_t)threads * 7919, 0)}, actions{seed58((uint64_t)seed, (uint64_t)seat, b, 1)};', 'response', ['R5'],
  'the deal stream of a block depends on the number of evaluation threads'),
 ('one-stream-for-every-block', R, 'r.s = r.bits() ^ ((block + 1) * 0xa0761d6478bd642fULL);', 'r.s = r.bits() ^ ((0 * block + 1) * 0xa0761d6478bd642fULL);', 'engine', ['E2'],
  'every block of an evaluation gets the same random stream'),
 ('icm-cache-returns-a-neighbour', 'icm.hpp', 'std::copy_n(ws.cache[base+w].value.begin(),n,chips); ws.hits++; return;', 'std::copy_n(ws.cache[base+(w+1)%ways].value.begin(),n,chips); ws.hits++; return;', 'engine', ['E3'],
  'an ICM cache hit returns the value stored in the next way of the set'),
 ('icm-places-shifted', 'icm.hpp', 'const double removed=removedOf[mask],pm=prob[mask],pay=payout[place];', 'const double removed=removedOf[mask],pm=prob[mask],pay=payout[(place+1)%paid];', 'engine', ['E4'],
  'the ICM recursion pays every place the next place\'s prize'),
 ('budget-check-removed', 'study52.hpp', 'if (need > MW_MAX_UPDATES) return failWith(400,', 'if (need > MW_MAX_UPDATES * 1000) return failWith(400,', 'limits', ['L1', 'L2'],
  'a study budget above the limit is accepted when the study is configured (the 5.7.1 behaviour)'),
]
obj = work / 'obj'; obj.mkdir(exist_ok=True); (obj / 'build_info.h').write_text('#define EM_VERSION "5.8"\n#define EM_BUILD_ID "mutant"\n')
subprocess.run(['gcc', '-O2', '-c', str(root / 'source/native/json.c'), '-o', str(obj / 'json.o')], check=True)
rows = []
for name, file, old, new, section, expect, what in MUTANTS:
    src = work / 'native'; shutil.rmtree(src, ignore_errors=True); shutil.copytree(root / 'source/native', src); t0 = time.time()
    if file:
        text = (src / file).read_text(); assert text.count(old) == 1, (name, 'the line to break was found %d times' % text.count(old)); (src / file).write_text(text.replace(old, new))
    exe = work / ('mwcli-' + name)
    b = subprocess.run(['g++', '-std=c++20', '-O2', '-march=x86-64', '-ffp-contract=off', '-I' + str(src), '-include', str(obj / 'build_info.h'), str(src / 'mwcli.cpp'), str(src / 'mw.cpp'), str(obj / 'json.o'), '-lpthread', '-ldl', '-lz', '-o', str(exe)], capture_output=True, text=True)
    if b.returncode: rows.append({'mutant': name, 'built': False, 'error': b.stderr[-400:]}); print(name, 'DID NOT BUILD', flush=True); continue
    d = work / ('st-' + name); shutil.rmtree(d, ignore_errors=True); d.mkdir()
    r = subprocess.run([str(exe), '--selftest58', str(root / 'studies'), str(d), section], capture_output=True, text=True, timeout=3600)
    try: doc = json.loads((d / 'selftest58.json').read_text())
    except Exception: doc = {'checks': [], 'passed': 0, 'failed': 0, 'untested': 0}
    notPassed = sorted(c['id'] for c in doc['checks'] if c['status'] != 'passed'); kinds = sorted({i.split()[-1] for i in notPassed})
    detected = (r.returncode == 1 and all(e in kinds for e in expect)) if expect else (r.returncode == 0 and not notPassed)
    rows.append({'mutant': name, 'what': what, 'file': file, 'section': section, 'built': True, 'exit': r.returncode, 'checks': len(doc['checks']), 'passed': doc['passed'], 'failed': doc['failed'], 'untested': doc['untested'],
                 'expectedToFail': expect, 'checksNotPassed': notPassed, 'kindsNotPassed': kinds, 'unexpectedKinds': [k for k in kinds if k not in expect], 'detectedAsExpected': detected, 'seconds': round(time.time() - t0, 1),
                 'firstFailure': next((c['id'] + ': ' + c['detail'][:240] for c in doc['checks'] if c['status'] != 'passed'), None)})
    print(name, 'exit', r.returncode, 'not passed:', kinds, 'as expected' if detected else 'NOT AS EXPECTED', flush=True)
    exe.unlink(missing_ok=True)
ok = all(r.get('detectedAsExpected') for r in rows)
out.write_text(json.dumps({'what': 'mwcli --selftest58 run by engines with one 5.8 behaviour broken', 'mutants': len(rows) - 1, 'everyMutantDetectedAndTheControlClean': ok, 'rows': rows}, indent=1)); sys.exit(0 if ok else 1)
