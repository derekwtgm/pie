#!/usr/bin/env python3
"""EightMax 5.8: instruction counts of ICM training and of an exact ICM evaluation, 5.7.1 against 5.8 (valgrind callgrind).
Usage: icm_instructions58.py <release root> <5.7.1 mwcli> <5.8 mwcli> <out.json>
Instruction counts are deterministic (no timing noise): the same program on the same input executes the same number of
instructions. They say how much work was removed, not how many seconds a particular machine saves. Each pair of runs
must also write the same state file."""
import sys, json, subprocess, pathlib, tempfile, hashlib, re
root = pathlib.Path(sys.argv[1]).resolve(); old, new = (str(pathlib.Path(x).resolve()) for x in sys.argv[2:4]); out = pathlib.Path(sys.argv[4]); work = pathlib.Path(tempfile.mkdtemp())
def count(cli, args):
    p = subprocess.run(['valgrind', '--tool=callgrind', '--callgrind-out-file=' + str(work / 'cg.out'), cli, *map(str, args)], capture_output=True, text=True)
    m = re.search(r'Collected : (\d+)', p.stderr); assert p.returncode == 0 and m, p.stderr[-300:]
    icm = 0
    a = subprocess.run(['callgrind_annotate', str(work / 'cg.out')], capture_output=True, text=True).stdout
    for line in a.splitlines():
        if 'Tournament::evaluate' in line: icm += int(line.split()[0].replace(',', ''))
    return int(m.group(1)), icm
rows = []
def spec(key, extra=None):
    f = work / (key + '.json'); subprocess.run(['node', str(root / 'source/tools/games58.js'), 'spec', key, str(f), '1'] + ([json.dumps(extra)] if extra else []), check=True); return f
CASES = [('final8', 5000, 16), ('final8', 5000, 256), ('final8', 5000, 1024), ('final8w', 5000, 16), ('final8w', 5000, 256), ('bubble4', 5000, 256), ('bubble5-icm', 5000, 256), ('sidepot3-icm', 20000, 256), ('short8-push', 3000, 256)]
for key, updates, mib in CASES:
    sp = spec(key); r = {}
    for name, cli in (('5.7.1', old), ('5.8', new)):
        st = work / ('%s-%s.state' % (key, name)); total, icm = count(cli, [sp, updates, 1, st, mib]); r[name] = {'instructions': total, 'inTournamentEvaluate': icm, 'stateSha256': hashlib.sha256(st.read_bytes()).hexdigest()}
    rows.append({'what': 'training', 'game': key, 'updates': updates, 'tableMemoryMiB': mib, 'icm': key not in ('short8-push',), **r, 'ratio': r['5.8']['instructions'] / r['5.7.1']['instructions'], 'identicalState': r['5.7.1']['stateSha256'] == r['5.8']['stateSha256']})
    print(key, mib, 'MiB ratio %.4f' % rows[-1]['ratio'], 'identical', rows[-1]['identicalState'], 'ICM share %.3f -> %.3f' % (r['5.7.1']['inTournamentEvaluate'] / r['5.7.1']['instructions'], r['5.8']['inTournamentEvaluate'] / r['5.8']['instructions']), flush=True)
out.write_text(json.dumps({'tool': 'valgrind callgrind (instruction counts)', 'rows': rows}, indent=1))
