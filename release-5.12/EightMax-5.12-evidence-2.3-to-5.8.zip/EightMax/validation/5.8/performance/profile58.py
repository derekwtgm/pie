#!/usr/bin/env python3
"""EightMax 5.8: where the instructions of one training go, by number of players (valgrind callgrind and cachegrind).
Usage: profile58.py <release root> <mwcli> <out.json>
Instruction and cache-miss counts are deterministic (simulated first-level and last-level caches of valgrind's model
of this machine); they do not depend on what else the machine is doing. They say where the work is, not how many
seconds it takes on a particular processor. Games: a three-, four-, five- and six-player postflop reference game,
the six-player and three-player shipped fixtures, and the eight-handed ICM final table."""
import sys, json, subprocess, pathlib, tempfile, re
root = pathlib.Path(sys.argv[1]).resolve(); cli = str(pathlib.Path(sys.argv[2]).resolve()); out = pathlib.Path(sys.argv[3]); work = pathlib.Path(tempfile.mkdtemp())
def fixture(name):
    f = work / (name + '.json'); f.write_text(json.dumps(json.loads((root / 'studies' / (name + '.emfix.json')).read_text(encoding='utf-8-sig'))['variants'][0]['nativeSpec'])); return f
def game(key):
    f = work / (key + '.json'); subprocess.run(['node', str(root / 'source/tools/games58.js'), 'spec', key, str(f), '1'], check=True, capture_output=True); return f
CASES = [('mid3-turn', game, 20000), ('turn4', game, 20000), ('flop5', game, 20000), ('flop6w', game, 20000), ('flop3-kings', fixture, 20000), ('flop6-jack', fixture, 20000), ('final8w', game, 5000)]
rows = []
for name, make, updates in CASES:
    sp = make(name); st = work / (name + '.state'); spec = json.loads(sp.read_text())
    p = subprocess.run(['valgrind', '--tool=callgrind', '--callgrind-out-file=' + str(work / 'cg.out'), cli, str(sp), str(updates), '1', str(st), '1024'], capture_output=True, text=True)
    m = re.search(r'Collected : (\d+)', p.stderr); assert p.returncode == 0 and m, p.stderr[-300:]
    total = int(m.group(1)); info = json.loads(p.stdout); top = []
    for line in subprocess.run(['callgrind_annotate', str(work / 'cg.out')], capture_output=True, text=True).stdout.splitlines():
        mm = re.match(r'\s*([\d,]+)\s+\(\s*([\d.]+)%\)\s+(.*)', line)
        if mm and 'PROGRAM TOTALS' not in line and len(top) < 8:
            fn = re.sub(r'^\S+:', '', mm.group(3)).split(' [')[0]; fn = re.sub(r'\(anonymous namespace\)::', '', fn); top.append({'function': fn[:110], 'share': float(mm.group(2)) / 100})
    c = subprocess.run(['valgrind', '--tool=cachegrind', '--cache-sim=yes', '--cachegrind-out-file=' + str(work / 'cache.out'), cli, str(sp), str(updates), '1', str(work / 'x.state'), '1024'], capture_output=True, text=True).stderr
    g = lambda k: int(re.search(k + r':\s+([\d,]+)', c).group(1).replace(',', ''))
    visits = info.get('visits') or info.get('stateVisits'); deals = info.get('deals') or info.get('trainingDeals') or updates
    rows.append({'game': name, 'players': spec['n'], 'updates': updates, 'deals': deals, 'tableMiB': info.get('tableMiB'), 'rows': info.get('rows'), 'visits': visits, 'instructions': total, 'instructionsPerDeal': total / deals,
                 'instructionsPerVisit': total / visits if visits else None, 'visitsPerDeal': visits / deals if visits else None, 'd1Misses': g('D1  misses'), 'llMisses': g('LL misses'), 'd1MissesPerDeal': g('D1  misses') / deals, 'llMissesPerDeal': g('LL misses') / deals, 'top': top})
    print(name, spec['n'], 'players', '%.0f instructions/deal' % rows[-1]['instructionsPerDeal'], '%.1f D1 misses/deal' % rows[-1]['d1MissesPerDeal'], [(t['function'][:40], t['share']) for t in top[:4]], flush=True)
out.write_text(json.dumps({'tool': 'valgrind callgrind and cachegrind (deterministic counts; default trainer, one thread)', 'build': subprocess.run([cli, '--build-id'], capture_output=True, text=True).stdout.strip(), 'rows': rows}, indent=1))
