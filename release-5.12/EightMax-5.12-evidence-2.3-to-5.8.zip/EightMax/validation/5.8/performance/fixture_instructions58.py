#!/usr/bin/env python3
"""EightMax 5.8: instruction counts and peak memory of training every shipped fixture, 5.7.1 against 5.8.
Usage: fixture_instructions58.py <release root> <5.7.1 mwcli> <5.8 mwcli> <out.json>
The timed benchmark (trainbench56.py) cannot resolve differences of a few percent on a shared machine (its run-to-run
spread is about 10%). Instruction counts (valgrind callgrind) are deterministic and can. Each fixture is trained for
20,000 deals with the default trainer on one thread by both binaries under callgrind; the two states must be identical.
Peak resident memory is taken from a separate uninstrumented run of 300,000 deals per binary (the figure the program
reports for itself, `processPeakRssMiB`, and the table size).
This script never loads a state file itself (hashes are taken by sha256sum): on Linux a child process starts with its
parent's peak resident size as the floor of its own, so a driver that reads a 300 MiB state would make every later
child report at least that. (The first version of this script, and trainbench56.py, did exactly that; their memory
figures were discarded.)"""
import sys, json, subprocess, pathlib, tempfile, hashlib, re
def sha(p): return subprocess.run(['sha256sum', str(p)], capture_output=True, text=True, check=True).stdout.split()[0]
root = pathlib.Path(sys.argv[1]).resolve(); old, new = (str(pathlib.Path(x).resolve()) for x in sys.argv[2:4]); out = pathlib.Path(sys.argv[4]); work = pathlib.Path(tempfile.mkdtemp()); rows = []
for fx in sorted((root / 'studies').glob('*.emfix.json')):
    name = fx.name[:-len('.emfix.json')]; doc = json.loads(fx.read_text(encoding='utf-8-sig')); spec = work / (name + '.json'); spec.write_text(json.dumps(doc['variants'][0]['nativeSpec'])); mem = str(int(doc['study'].get('memoryMiB', 1024))); r = {'fixture': name, 'players': doc['variants'][0]['nativeSpec']['n'], 'instrumentedDeals': 20000, 'memoryDeals': 300000}
    for label, cli in (('5.7.1', old), ('5.8', new)):
        st = work / ('%s-%s.state' % (name, label)); p = subprocess.run(['valgrind', '--tool=callgrind', '--callgrind-out-file=' + str(work / 'cg.out'), cli, str(spec), '20000', '1', str(st), mem], capture_output=True, text=True)
        m = re.search(r'Collected : (\d+)', p.stderr); assert p.returncode == 0 and m, p.stderr[-300:]
        q = subprocess.run([cli, str(spec), '300000', '1', str(work / 'big.state'), mem], capture_output=True, text=True); assert q.returncode == 0, q.stderr[-300:]; info = json.loads(q.stdout)
        r[label] = {'instructions': int(m.group(1)), 'stateSha256': sha(st), 'processPeakRssMiB': info.get('processPeakRssMiB'), 'tableMiB': info.get('tableMiB'), 'bigStateSha256': sha(work / 'big.state')}
    r['instructionRatio'] = r['5.8']['instructions'] / r['5.7.1']['instructions']; r['identicalStates'] = r['5.8']['stateSha256'] == r['5.7.1']['stateSha256'] and r['5.8']['bigStateSha256'] == r['5.7.1']['bigStateSha256']; rows.append(r)
    print(name, 'instruction ratio %.4f' % r['instructionRatio'], 'identical', r['identicalStates'], 'peak MiB', r['5.7.1']['processPeakRssMiB'], r['5.8']['processPeakRssMiB'], flush=True)
import resource
out.write_text(json.dumps({'tool': 'valgrind callgrind (instruction counts); the program\'s own peak resident memory', 'driverPeakRssMiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 'rows': rows}, indent=1))
