#!/bin/bash
# EightMax 5.8: the Windows programs under Wine. Usage: bash validation/5.8/wine58.sh <release root> <wrapper dir> <work dir>
# <wrapper dir> holds mwcli-wine and EightMax-wine: small scripts that start the Windows executable of <release root>
# under Wine with a minimal environment and pass on EightMax's own variables (validation/5.6/wine/wrapper-example.sh).
#  1. mwcli.exe --selftest58 (what "Run 5.8 focused validation.bat" runs first on a Windows PC), --selftest571, --selftest57
#  2. the reference responses of validation/5.8/windows/response: mwcli.exe must reproduce the bits of the Linux build
#  3. the 5.8, 5.7.1, 5.7, 5.6 and 5.5 regression files with the Windows programs in place of the Linux ones. Where a
#     test compares with an archived LINUX binary, that binary runs natively, so those tests compare the Windows
#     build of 5.8 with the Linux build of the earlier release.
# Wine is not Windows: this is evidence about the Windows executables, not about a Windows PC.
set -u
root=$(cd "$1" && pwd); wr=$(cd "$2" && pwd); work=$3; out="$root/validation/5.8/wine"; rm -rf "$work" "$out"; mkdir -p "$work" "$out"; cd "$root"
win() { printf 'Z:%s' "${1//\//\\}"; }
"$wr/mwcli-wine" --build-id > "$out/build-id.txt" 2>&1; cat "$out/build-id.txt"
wine --version > "$out/wine-version.txt" 2>&1
sha256sum mwcli.exe EightMax.exe gpustress.exe > "$out/executables.sha256"
mkdir -p "$work/st58"; "$wr/mwcli-wine" --selftest58 "$(win "$root/studies")" "$(win "$work/st58")" all > "$out/selftest58-wine.stdout" 2> "$out/selftest58-wine.stderr"; echo "selftest58 exit $?" | tee "$out/selftest58-wine.exit"
cp "$work/st58/selftest58.json" "$out/selftest58-wine.json" 2>/dev/null
mkdir -p "$work/st571"; "$wr/mwcli-wine" --selftest571 "$(win "$root/studies")" "$(win "$work/st571")" all > "$out/selftest571-wine.stdout" 2> "$out/selftest571-wine.stderr"; echo "selftest571 exit $?" | tee "$out/selftest571-wine.exit"
cp "$work/st571/selftest571.json" "$out/selftest571-wine.json" 2>/dev/null
mkdir -p "$work/st57"; "$wr/mwcli-wine" --selftest57 "$(win "$root/validation/5.7/fixtures")" "$(win "$work/st57")" > "$out/selftest57-wine.stdout" 2> "$out/selftest57-wine.stderr"; echo "selftest57 exit $?" | tee "$out/selftest57-wine.exit"
cp "$work/st57/selftest57.json" "$out/selftest57-wine.json" 2>/dev/null
# 2. reference responses
python3 - "$root" "$wr/mwcli-wine" "$work" > "$out/reference-responses-wine.json" <<'PY'
import sys, json, subprocess, hashlib, pathlib
root, cli, work = pathlib.Path(sys.argv[1]), sys.argv[2], pathlib.Path(sys.argv[3]); d = root / 'validation/5.8/windows/response'; g = json.loads((d / 'golden58.json').read_text()); rows = []
win = lambda p: 'Z:' + str(p).replace('/', '\\')
for c in g['cases']:
    st = work / (c['name'] + '.state'); t = subprocess.run([cli, win(d / c['spec']), str(c['updates']), '1', win(st), str(c['memoryMiB'])], capture_output=True, text=True)
    sha = hashlib.sha256(st.read_bytes()).hexdigest() if st.exists() else ''; got = []
    for request in (c['request'], c['parallelRequest']):
        r = subprocess.run([cli, '--response', win(d / c['spec']), win(st), win(d / request), str(c['memoryMiB'])], capture_output=True, text=True)
        try: got.append(['%d:%s:%s:%s' % (s['seat'], s['sampled']['gain']['gainBits'], s['exact']['gainBits'], s['exact']['bestResponseGainBits']) for s in json.loads(r.stdout)['seats']])
        except Exception as e: got.append(['error: ' + (r.stderr.strip()[-200:] or str(e))])
    rows.append({'name': c['name'], 'stateIdentical': sha == c['stateSha256'], 'responseBitsIdentical': got[0] == c['seatBits'], 'parallelSeatsIdentical': got[1] == c['seatBits'], 'got': got[0], 'expected': c['seatBits']})
ok = all(r['stateIdentical'] and r['responseBitsIdentical'] and r['parallelSeatsIdentical'] for r in rows)
print(json.dumps({'what': 'mwcli.exe under Wine against the bits recorded by the Linux build', 'recordedBy': g['recordedBy'], 'cases': len(rows), 'allIdentical': ok, 'rows': rows}, indent=1)); sys.exit(0 if ok else 1)
PY
echo "reference responses exit $?" | tee "$out/reference-responses-wine.exit"
: > "$out/tests.exit"
for f in v58 v571 v57 v56 v55; do
  EM_TEST_MWCLI="$wr/mwcli-wine" EM_TEST_HOST="$wr/EightMax-wine" timeout 10800 node --test --test-concurrency=1 --test-reporter=tap "source/tests/$f.test.js" > "$out/$f.test.tap" 2> "$out/$f.test.stderr"; echo "$f exit $?" | tee -a "$out/tests.exit"
  grep -E '^# (tests|pass|fail|skipped)' "$out/$f.test.tap" | tr '\n' ' '; echo
done
