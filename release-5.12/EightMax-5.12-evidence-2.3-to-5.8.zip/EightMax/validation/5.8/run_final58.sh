#!/bin/bash
# The validation chain of the final 5.8 build on Linux. Usage: bash validation/5.8/run_final58.sh <release root> <work dir>
# <release root> holds build/linux/{mwcli,eightmax,gpustress} (source/native/build.sh) next to the release files.
# Logs go to <work dir>; evidence goes to validation/5.8/. Steps run even if an earlier one fails; exit codes are
# recorded in <work dir>/steps.txt. (Sanitizers, Wine, the experiments and the packaging have their own commands:
# sanitize58.sh, wine58.sh, convergence/*.py, performance/*.py, release58.py; see VALIDATION-5.8.md.)
set -u
root=$(cd "$1" && pwd); work=$2; mkdir -p "$work"; cd "$root"; S="$work/steps.txt"; : > "$S"
V=validation/5.8; T=$V/tests; mkdir -p "$T"; rm -f "$T"/full-regression.* "$T"/rerun-alone* "$T"/failed-in-full-run.txt
export EM_TEST_MWCLI="$root/build/linux/mwcli" EM_TEST_HOST="$root/build/linux/eightmax"
echo "build $("$EM_TEST_MWCLI" --build-id) $(date -u +%FT%TZ)" | tee -a "$S"
# 1. the whole regression suite, three test files at a time (as 5.6, 5.7 and 5.7.1 ran it)
ASAN_OPTIONS=detect_leaks=0 NODE_OPTIONS="--require=$root/validation/5.3/sanitizers/no-leaks.cjs" \
  node --test --test-concurrency=3 --test-reporter=tap source/tests/*.test.js > "$T/full-regression.tap" 2> "$T/full-regression.stderr"; echo "regression exit $?" | tee -a "$S"
tail -8 "$T/full-regression.tap" | tr '\n' ' ' | tee -a "$S"; echo | tee -a "$S"
# 2. every test that failed in (1) is run again, alone, on the then idle machine; both outcomes are kept
grep '^not ok' "$T/full-regression.tap" | sed 's/^not ok [0-9]* - //' > "$T/failed-in-full-run.txt"
: > "$T/rerun-alone.txt"
while IFS= read -r name; do
  [ -z "$name" ] && continue
  file=$(grep -l -F -- "$(printf '%s' "$name" | cut -c1-60)" source/tests/*.test.js | head -1)
  if [ -z "$file" ]; then for f in source/tests/*.test.js; do node --test --test-reporter=tap "$f" 2>/dev/null | grep -q -F -- "- $name" && { file=$f; break; }; done; fi
  [ -z "$file" ] && { echo "NOT FOUND: $name" >> "$T/rerun-alone.txt"; continue; }
  out="$T/rerun-alone-$(basename "$file" .test.js).tap"
  node --test --test-reporter=tap "$file" > "$out" 2>&1
  if grep -q -F -- "not ok" "$out" && grep -F -- "- $name" "$out" | grep -q '^not ok'; then echo "FAILED AGAIN ALONE ($(basename "$file")): $name" >> "$T/rerun-alone.txt"; else echo "passed alone ($(basename "$file")): $name" >> "$T/rerun-alone.txt"; fi
done < "$T/failed-in-full-run.txt"
cat "$T/rerun-alone.txt" | tee -a "$S"
# 3. the self-tests of the Linux build, kept as evidence
rm -rf "$V/selftest"; mkdir -p "$V/selftest"
for st in 58:studies 571:studies 57:validation/5.7/fixtures; do
  n=${st%%:*}; dir=${st##*:}; rm -rf "$work/st$n"
  if [ "$n" = 57 ]; then "$EM_TEST_MWCLI" --selftest$n "$root/$dir" "$work/st$n" > "$V/selftest/selftest$n-linux.stdout" 2> "$V/selftest/selftest$n-linux.stderr"
  else "$EM_TEST_MWCLI" --selftest$n "$root/$dir" "$work/st$n" all > "$V/selftest/selftest$n-linux.stdout" 2> "$V/selftest/selftest$n-linux.stderr"; fi
  echo "selftest$n (Linux) exit $?" | tee -a "$S"; cp "$work/st$n/selftest$n.json" "$V/selftest/selftest$n-linux.json" 2>/dev/null
done
# 4. identical training states: the unchanged 5.7.1 binary against this build (thread counts, trainer options, hand groups, table limits)
rm -rf "$work/identity" "$V/identity"; mkdir -p "$V/identity"; cp validation/5.7.1/linux-bin/mwcli "$work/mwcli571"; chmod +x "$work/mwcli571"
python3 source/tools/identity57.py "$work/mwcli571" "$EM_TEST_MWCLI" "$work/identity" > "$V/identity/identity-against-5.7.1.log" 2>&1; echo "identity against 5.7.1 exit $?" | tee -a "$S"
cp "$work/identity"/summary.json "$work/identity"/identity.jsonl "$V/identity/" 2>/dev/null; tail -3 "$V/identity/identity-against-5.7.1.log" | tee -a "$S"
echo "== done $(date -u +%H:%M:%S)" | tee -a "$S"
