#!/bin/bash
# EightMax 5.8: runs the independent Python check of the trained response (source/tools/independent_response58.py) on the
# postflop chip-EV reference games and keeps every report. Usage: run_independent58.sh <release root> <mwcli> <work dir>
# The Python script shares no code with the engine (its own state reader, betting rules, side pots, card evaluator, tree walk).
set -u
root=$(cd "$1" && pwd); cli=$(readlink -f "$2"); work=$3; out="$root/validation/5.8/independent"; mkdir -p "$work"; : > "$out/summary.txt"
for case in "hu-river 20000 1" "hu-river 5000 2" "hu-turn 5000 1" "hu-turn 20000 2" "river3-chip 5000 1" "river3-chip 20000 2" "turn4 5000 1" "mid3-turn 3000 1"; do
  set -- $case; key=$1; updates=$2; seed=$3; d="$work/$key-$updates-$seed"; mkdir -p "$d"
  node "$root/source/tools/games58.js" spec "$key" "$d/spec.json" "$seed" > /dev/null || { echo "$key $updates seed $seed: spec failed" >> "$out/summary.txt"; continue; }
  "$cli" "$d/spec.json" "$updates" 1 "$d/trained.state" 256 > "$d/train.json" 2> "$d/train.err" || { echo "$key $updates seed $seed: training failed" >> "$out/summary.txt"; continue; }
  s=$(date +%s); python3 -I "$root/source/tools/independent_response58.py" "$cli" "$d/spec.json" "$d/trained.state" "$d/ind" 100000 20480 58 > "$out/$key-$updates-seed$seed.json" 2> "$d/ind.err"; rc=$?
  echo "$key updates $updates seed $seed: exit $rc, $(( $(date +%s) - s )) s" >> "$out/summary.txt"
done
echo done >> "$out/summary.txt"
