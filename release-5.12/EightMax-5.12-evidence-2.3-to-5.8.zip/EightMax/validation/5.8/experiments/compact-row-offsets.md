# Experiment (not adopted): compact row offsets in the strategy table

Idea: a strategy lookup reads hash bucket -> row index -> 32-byte row record (for the value offset) -> values.
Keep a 4-byte copy of the offset per row (record packed to 28 bytes so memory per row stays 32) so that lookups of
opponents' strategies never touch the row record.

Result on the development container (4 logical CPUs, one deal per update, one thread, 100,000 deals, states written
by all builds byte-identical):

First measurement, taken WHILE another process was using a core (a pure-Python cross-check): -6.3% (six-player flop),
-9.1% (three-player flop), -0.7% (three-player preflop), +0.6% (ICM). Discarded: the machine was not idle.

Second measurement, idle machine, 14 interleaved runs per build, median (minimum):
  six-player flop (flop6-jack)        5.7.1 2.112 s (1.909)   candidate 2.064 s (1.806)   -2.3%
  three-player flop (flop3-kings)     5.7.1 0.885 s (0.812)   candidate 0.912 s (0.805)   +3.0%
  three-player preflop (btn25-open)   5.7.1 0.858 s (0.731)   candidate 0.891 s (0.752)   +3.8%
  three-player flop, detailed groups  5.7.1 2.268 s (1.925)   candidate 2.258 s (1.886)   -0.5%
Run-to-run spread of one build is about 10% (median against minimum), larger than every difference.

Cache simulation (valgrind cachegrind, 20,000 deals of flop6-jack; deterministic):
  first-level data cache misses   5.7.1 21,803,653   candidate 22,008,851   (not lower)
The row record is read later in the same update anyway (when the increments are merged), or the new array is missed
instead; the number of first-level misses does not fall.

Decision: not adopted (no measurable gain, added complexity in the table layout). The 5.7.1 layout is kept.
What the profile says instead (callgrind, flop6-jack): the instruction profile of a traversal is flat - Walker::learn
35%, strategy lookup 14%, child-state lookup 12%, merge 5%, betting rules 3%, random numbers 3%, hand groups 5%,
deal 3% - and 4.5 first-level cache misses per state visit explain why a visit costs 90 ns on a 16 MiB table and
23 ns on a table that fits the cache. A real gain needs fewer dependent memory reads per lookup (a different table
layout, with a different memory accounting), which would change when a table limit is reached and is therefore a
format-level change for a later version.
