// EightMax 5.6: the Study Accuracy and Recovery panel driven in a real browser (Chromium via Playwright) against
// the desktop host. No command line is used for the study itself: run, stop, the saved-study list, resume after the
// host process was killed, the calibration flags of the result, discard, and the review of a 5.4 result file.
// 5.6 adds: the replication verdict and the statistical warnings of the result as the panel and the headline show them
// (study_ui55.js is kept as the 5.5 tool; this file replaces it for 5.6).
//
//   node tools/study_ui56.js <host executable> <release root (with studies/ and validation/5.4/studies)> <out-dir> [--wine]
//
// Writes study-ui56.json (every check with its values) and screenshots. Exit code 1 if any check failed.
'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), net = require('node:net'), cp = require('node:child_process');
const { chromium } = require('playwright');
const args = process.argv.slice(2), [exeArg, relArg, outArg] = args.filter(a => !a.startsWith('--')), wine = args.includes('--wine');
if (!exeArg || !relArg || !outArg) { console.error('usage: node tools/study_ui56.js <host executable> <release root> <out-dir> [--wine]'); process.exit(2); }
const exe = path.resolve(exeArg), rel = path.resolve(relArg), out = path.resolve(outArg); fs.mkdirSync(out, { recursive: true });
const checks = [], check = (name, ok, detail) => { checks.push({ name, passed: !!ok, ...(detail !== undefined ? { detail } : {}) }); if (!ok) console.error('FAILED: ' + name + (detail !== undefined ? ' ' + JSON.stringify(detail).slice(0, 500) : '')); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const homeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'em55-ui-')), errors = [];
  const start = async () => {
    const port = await new Promise(r => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => r(p)); }); });
    const env = { ...process.env, HOME: wine ? process.env.HOME : homeDir, USERPROFILE: homeDir, EIGHTMAX_GPU: 'off', WINEDEBUG: '-all' };
    const proc = wine ? cp.spawn('wine', [exe, '--no-browser', '--port=' + port], { env, stdio: 'ignore' }) : cp.spawn(exe, ['--no-browser', '--port=' + port], { env, stdio: 'ignore' });
    const url = 'http://127.0.0.1:' + port, api = async (p, body) => (await fetch(url + '/api/' + p, body === undefined ? {} : { method: 'POST', headers: { 'X-EightMax': '1' }, body: JSON.stringify(body) })).json();
    let info = null; for (let i = 0; i < 600 && !info; i++) { try { info = await api('info'); } catch { await sleep(50); } }
    if (!info) { proc.kill('SIGKILL'); throw new Error('the host did not start'); }
    return { proc, url, api, info };
  };
  let host = await start();
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 1500, height: 1300 } });
  const open = async () => { const page = await ctx.newPage(); page.on('pageerror', e => errors.push(String(e))); page.on('dialog', d => d.accept()); await page.goto(host.url + '/#study'); await page.waitForSelector('#sd-recovery'); return page; };
  const report = { tool: 'study_ui56', generated: new Date().toISOString(), host: wine ? 'Windows executable under ' + cp.execSync('wine --version', { encoding: 'utf8' }).trim() : 'Linux build', executable: path.basename(exe), build: host.info.build, version: host.info.version, browser: 'Chromium ' + browser.version(), checks };
  try {
    let page = await open();
    const wantVersion = fs.readFileSync(path.join(rel, 'source/VERSION'), 'utf8').trim();
    check('the host is ' + wantVersion + ' and announces study checkpoints', host.info.version === wantVersion && host.info.studyCheckpoints === 1, { version: host.info.version, studyCheckpoints: host.info.studyCheckpoints });
    check('the Study Accuracy and Recovery panel is shown with an empty saved-study list', (await page.textContent('#sd-recovery h2')) === 'Study accuracy and recovery' && !!(await page.$('#sd-nockpt')));
    // ---- a study long enough to interrupt: six-player flop, one variant, three seeds ----
    const title = JSON.parse(fs.readFileSync(path.join(rel, 'studies', 'flop6-jack.emfix.json'), 'utf8')).title;
    await page.selectOption('#sd-pick', { label: title }); await page.waitForFunction(t => document.querySelector('#sd-title')?.textContent === t, title);
    await page.selectOption('#sd-variant', 'baseline');
    const set = async (id, v) => { await page.fill(id, String(v)); await page.dispatchEvent(id, 'change'); };
    await set('#sd-seeds', 3); await set('#sd-budgets', '15000,60000'); await set('#sd-threads', 3); await set('#sd-samples', 1000); await set('#sd-qualitySamples', 128);
    await page.click('#sd-run'); await page.waitForSelector('#sd-live');
    await page.waitForFunction(() => /commits; last successful/.test(document.querySelector('#sd-live')?.textContent || ''), null, { timeout: 60000 });
    const live = await page.textContent('#sd-live');
    check('while running: measurement and seed counts, stage, checkpoint, memory and processing mode are shown', /Measurements complete\s*\d+ of 6/.test(live) && /Training seeds complete\s*\d+ of 3/.test(live) && /Stage/.test(live) && /Checkpoint\s*\d+ commits/.test(live) && /MiB in use, peak/.test(live) && /Processing/.test(live), live.slice(0, 600));
    check('no completion time is invented: the only percentage is the share of planned measurements', !/remaining|ETA|minutes left/i.test(live) && /this is a count, not a time estimate/.test(live));
    await page.screenshot({ path: path.join(out, 'running.png'), fullPage: true });
    await page.click('#sd-stop'); await page.waitForSelector('#sd-incomplete', { timeout: 120000 });
    const inc = await page.textContent('#sd-incomplete'), accStopped = await page.textContent('#sd-accuracy');
    check('after Stop: the result is marked incomplete and resumable, not successful', /Incomplete study/.test(inc) && /cancelled/.test(inc) && /can be resumed below/.test(inc), inc);
    check('after Stop: evaluation is shown incomplete and no tolerance is met', /incomplete/.test(accStopped) && !/Meets the declared tolerance<\/b>/.test(await page.innerHTML('#sd-result')), accStopped.slice(0, 300));
    await page.waitForSelector('#sd-checkpoints [data-sd-resume]:not([disabled])');
    const row = await page.textContent('#sd-checkpoints tbody tr');
    check('the stopped study is listed as a saved study with Resume enabled', /flop6-jack/.test(row) && /cancelled/.test(row) && /of 6/.test(row), row);
    await page.screenshot({ path: path.join(out, 'stopped.png'), fullPage: true });
    // ---- resume, then kill the host process while the study runs (an unexpected termination) ----
    await page.click('#sd-checkpoints [data-sd-resume]'); await page.waitForSelector('#sd-live'); await sleep(1200);
    host.proc.kill('SIGKILL'); await new Promise(r => host.proc.once('exit', r)); await page.close();
    host = await start(); page = await open();
    await page.waitForSelector('#sd-checkpoints [data-sd-resume]:not([disabled])');
    const afterKill = await page.textContent('#sd-checkpoints tbody tr');
    check('after the host process was killed: the study is still listed and resumable in a new host process', /flop6-jack/.test(afterKill) && !/complete\b/.test(afterKill.replace(/incomplete/g, '')), afterKill);
    await page.click('#sd-checkpoints [data-sd-resume]');
    await page.waitForFunction(() => !document.querySelector('#sd-live') && !!document.querySelector('#sd-accuracy') && !document.querySelector('#sd-incomplete'), null, { timeout: 300000 });
    const acc = await page.textContent('#sd-accuracy'), doc = await host.api('study/result');
    check('resumed to completion: 6 of 6 measurements, resumed flag, no checkpoint warnings', doc.completion.complete === true && doc.completion.pointsCompleted === 6 && doc.run.checkpoint.resumed === true && doc.run.checkpoint.warnings.length === 0, { completion: doc.completion, checkpoint: doc.run.checkpoint });
    const b = doc.variants[0].budgets.at(-1);
    check('the panel shows the stored calibration status and verdict', (await page.textContent('#sd-accuracy [data-k="calibrated"]')).includes(b.confidence.evaluationCalibrated ? 'yes' : 'NO') && (await page.textContent('#sd-accuracy [data-k="supported"]')).includes(doc.variants[0].budgets.find(x => x.budgetDeals === (doc.variants[0].firstBudgetMeetingTolerance ?? doc.variants[0].lastMeasuredBudget)).verdict), acc.slice(0, 400));
    check('the quality metric is labelled restricted (sampled) and the warning list says it is not exploitability', /restricted \(sampled one-decision gain\)/.test(acc) && /not exploitability/.test(await page.textContent('#sd-warnings')));
    // ---- 5.6: what the number of trainings supports, as shown ----
    const rep = b.confidence.replication, supported = await page.textContent('#sd-accuracy [data-k="supported"]'), warnText = await page.textContent('#sd-warnings'), heads = await page.textContent('#sd-headlines');
    check('5.6: the result carries the replication verdict; three trainings declare no best action', !!rep && rep.trainings === 3 && rep.sufficient === false && b.bestAction.declared === false && doc.replicationCalculation === 'study-5.6-replication-v1', rep);
    check('5.6: the panel says "no", names the across-trainings verdict and the trainings needed', /no/.test(supported) && supported.includes('across trainings: ' + rep.verdict) && supported.includes('3 trainings') && supported.includes(rep.minimumTrainingsForStatementAboutTypicalTraining + ' needed'), supported);
    check('5.6: the warning list states the insufficient replication and the failure rate that could hide', /at least \d+ \(all agreeing\) are needed/.test(warnText) && /would probably \(more than 1 chance in 20\) not have appeared/.test(warnText), warnText.slice(0, 600));
    check('5.6: the headline never recommends an action that is not declared', !/Prefer /.test(heads) || doc.variants.some(v => v.budgets.some(x => x.bestAction && x.bestAction.declared)), heads.slice(0, 300));
    const done = await page.textContent('#sd-checkpoints tbody tr');
    check('the finished study is listed complete and can no longer be resumed', /complete/.test(done) && !!(await page.$('#sd-checkpoints [data-sd-resume][disabled]')), done);
    await page.screenshot({ path: path.join(out, 'resumed-complete.png'), fullPage: true });
    // the same study from the command line, uninterrupted, must give the same numbers
    const cli = path.join(path.dirname(exe), wine ? 'mwcli.exe' : 'mwcli'), ref = path.join(out, 'reference.json');
    if (fs.existsSync(cli)) {
      const r = cp.spawnSync(wine ? 'wine' : cli, [...(wine ? [cli] : []), '--study', path.join(rel, 'studies', 'flop6-jack.emfix.json'), ref, 'variants=baseline', 'seeds=3' /* the first three seeds of the fixture, as the page chooses them */, 'budgets=15000,60000', 'threads=3', 'evaluationSamples=1000', 'qualitySamples=128', 'quiet=1', 'checkpoint=off'], { encoding: 'utf8', env: { ...process.env, WINEDEBUG: '-all' } });
      const same = (x, y) => JSON.stringify(x.variants.map(v => v.perSeed.map(s => s.budgets.map(p => [p.ev, p.frequency, p.evStdErr, p.quality, p.qualityStdErr, p.deals, p.rows])))) === JSON.stringify(y.variants.map(v => v.perSeed.map(s => s.budgets.map(p => [p.ev, p.frequency, p.evStdErr, p.quality, p.qualityStdErr, p.deals, p.rows]))));
      const refDoc = r.status === 0 ? JSON.parse(fs.readFileSync(ref, 'utf8')) : null;
      check('the stopped, killed and resumed desktop study has the numbers of an uninterrupted command-line study', !!refDoc && same(doc, refDoc) && JSON.stringify(doc.variants[0].budgets.map(x => [x.verdict, x.gap])) === JSON.stringify(refDoc.variants[0].budgets.map(x => [x.verdict, x.gap])), r.stderr.slice(0, 300));
    }
    await page.click('#sd-checkpoints [data-sd-discard]'); await page.waitForSelector('#sd-nockpt');
    check('Discard removes the saved study', !!(await page.$('#sd-nockpt')));
    // ---- a 5.4 result file: measurements shown, uncalibrated statements withdrawn ----
    await page.setInputFiles('#sd-result-file', path.join(rel, 'validation/5.4/studies/btn25-open.result.json'));
    // 5.8: the panel of the study shown before already has #sd-warnings, so waiting for the element returns before the 5.4 file is
    // rendered (the race that failed this check once under load). Wait for the content that only a pre-5.5 result produces;
    // if it never appears the check below fails on what the page shows.
    await page.waitForFunction(() => /produced before 5\.5|not calibrated/.test((document.querySelector('#sd-warnings') || {}).textContent || ''), null, { timeout: 15000 }).catch(() => {});
    const warn = await page.textContent('#sd-warnings'), accOld = await page.textContent('#sd-accuracy');
    check('a 5.4 result: calibration shown as NO with the reason, no best action supported', /not calibrated/.test(warn) && /NO/.test(accOld) && !/Prefer /.test(await page.textContent('#sd-headlines')), warn.slice(0, 300));
    await page.screenshot({ path: path.join(out, 'legacy-5.4-result.png'), fullPage: true });
    check('no JavaScript error was raised in the page', errors.length === 0, errors.slice(0, 3));
  } catch (e) { check('the browser session completed', false, String(e && e.stack || e).slice(0, 800)); }
  finally { await browser.close(); host.proc.kill('SIGKILL'); fs.rmSync(homeDir, { recursive: true, force: true }); }
  report.passed = checks.every(c => c.passed); report.checksPassed = checks.filter(c => c.passed).length; report.checksTotal = checks.length;
  fs.writeFileSync(path.join(out, 'study-ui56.json'), JSON.stringify(report, null, 1) + '\n'); console.log(report.checksPassed + ' of ' + report.checksTotal + ' checks passed'); process.exit(report.passed ? 0 : 1);
})();
