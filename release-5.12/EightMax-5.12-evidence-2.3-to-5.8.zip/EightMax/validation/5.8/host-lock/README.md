# The recurring load-sensitive checkpoint test failures: cause and repair

Observed: in full regression runs (three test files side by side) one checkpoint test of `v36.test.js` or `v37.test.js`
failed with an unexpected 409 or 503 and passed when run alone: 5.6 ("the host answered 503 to the preceding upload"),
5.7 ("cancel and concurrent uploader ..."), 5.7.1 ("disk forecast with compressed expansion preserves predecessor"),
and the first full run of 5.8 ("insufficient live table RAM leaves the generation available": 409 instead of 503).
Each time a different test, always a checkpoint request sent right after another one had been answered.

Cause (`source/native/server.c`, `handle()`): a request that works on checkpoints takes `checkpoint_body_mu` with
`trylock` and released it at `finish_request`, AFTER `checkpoint_api()` had sent the answer. A client that read the
answer and sent its next checkpoint request before the answering thread reached the unlock was refused: 409 "Another
checkpoint operation is active" (restore commands) or 503 "Another checkpoint write is in progress" (uploads). On an
idle machine the window is a few instructions; when the answering thread loses its time slice it is milliseconds.
The host had finished the operation; only the lock was still held. A real client (the desktop page, which chains
save and restore requests) can meet the same refusal on a busy PC.

Reproduction (`reproduction-host.patch`, applied to the unmodified 5.7.1 source): the answering thread is kept busy for
250 ms between its answer and the unlock. `reproduction-5.7.1-order.tap`: the next request is refused every time
("restore right after the answered write, round 0: Another checkpoint operation is active", 409).

Repair (`repair.patch`): the lock is released before the first byte of the answer is sent (`respond()` and `cp_send()`
call `release_before_response()`; the request thread registers `cp_release` when it takes the lock). Nothing after
the answer touches shared state (the handler had already released the store lock, the engine lock and the solver
claim before answering). A request that ends without an answer still releases the lock at `finish_request`.
`repaired-host.tap`: with the same 250 ms of work after the answer, four write-then-restore rounds are accepted, and a
write and a restore are still refused while another write is really being received (503 and 409, as before).

Test: `source/tests/v58.test.js`, "5.8 desktop host: after an answered checkpoint request the next one is accepted at
once". No timeout was raised and no test was relaxed. `source/tests/load_sensitive.json` is unchanged: its entries
that concern solver jobs (not the checkpoint lock) have a different cause and are not addressed by this repair.
