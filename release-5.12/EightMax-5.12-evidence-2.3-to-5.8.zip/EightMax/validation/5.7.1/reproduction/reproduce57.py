#!/usr/bin/env python3
"""EightMax 5.7.1, phases 2 and 4: the two findings of the physical Windows run of 5.7, reproduced with the UNCHANGED
5.7 Linux binary (validation/5.7/linux-bin/mwcli, build e4668abe7903f8b0), and the engine defect found on the way.

  A  validate_windows57.ps1, "recovery / damaged manifest refused": the script's own edit ('"resumeCount":' ->
     '"resumeCount" :' in every manifest) followed by a resume. The script expected a refusal; Windows reported exit 0.
  B  What the 5.7 engine does with real damage (a value changed, the checksum changed, a state damaged, files
     missing): the behaviour the script should have tested.
  C  validate_windows57.ps1, "memory / a too-small process budget ...": the script's own command (flop3-kings-small,
     processMemoryMiB=24). The script accepted "stopped OR complete".
  D  The same engine given a workload that does exceed a budget (flop3-kings-detailed, 48 MiB): the memory stop works.
  E  The engine defect: manifest.json damaged, the resume recovers from manifest.prev.json and is killed at the moment
     it would replace manifest.json with its first commit (kill_at_rename_shim.c, LD_PRELOAD). 5.7 has by then
     copied the damaged manifest over manifest.prev.json.

usage: python3 validation/5.7.1/reproduction/reproduce57.py <release root> <work dir> [<mwcli to test>]
       (the third argument runs the same steps with another binary, for example build/linux/mwcli of 5.7.1)
"""
import hashlib, json, os, re, shutil, subprocess, sys
root, work = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
exe_src = os.path.abspath(sys.argv[3]) if len(sys.argv) > 3 else os.path.join(root, 'validation', '5.7', 'linux-bin', 'mwcli')
here = os.path.dirname(os.path.abspath(__file__)); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
exe = os.path.join(work, 'mwcli-under-test'); shutil.copyfile(exe_src, exe); os.chmod(exe, 0o755)
shim = os.path.join(work, 'shim.so'); subprocess.run(['gcc', '-shared', '-fPIC', '-O1', '-o', shim, os.path.join(here, 'kill_at_rename_shim.c'), '-ldl'], check=True)
def run(args, env=None):
    e = dict(os.environ); e.update(env or {}); return subprocess.run([exe] + [str(a) for a in args], capture_output=True, text=True, env=e)
def doc(p): return json.load(open(p)) if os.path.exists(p) else None
def points(d): return [(v['name'], s['seed'], p['budgetDeals'], p['status'], p.get('deals'), p.get('ev'), p.get('frequency'), p.get('quality')) for v in d['variants'] for s in v['perSeed'] for p in s['budgets']]
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
build = run(['--build-id']).stdout.strip()
akq = os.path.join(root, 'studies', 'known-akq-river.emfix.json'); opts = ['seeds=2', 'budgets=20000,400000,6000000', 'threads=2', 'quiet=1', 'processingMode=cpu']
ref = os.path.join(work, 'ref.json'); assert run(['--study', akq, ref] + opts + ['checkpoint=off']).returncode == 0; want = points(doc(ref))
src = os.path.join(work, 'ck'); assert run(['--study', akq, os.path.join(work, 'stopped.json')] + opts + ['checkpoint=' + src, 'timeLimitSeconds=0.5', 'checkpointSeconds=0.1']).returncode == 0
stopped = doc(os.path.join(work, 'stopped.json')); assert stopped['completion']['complete'] is False
def case(name, mutate, env=None, keep=False):
    d = os.path.join(work, 'case-' + name)
    if not keep: shutil.rmtree(d, ignore_errors=True); shutil.copytree(src, d)
    if mutate: mutate(d)
    out = os.path.join(work, name + '.json')
    if os.path.exists(out): os.remove(out)
    r = run(['--study', akq, out] + opts + ['checkpoint=' + d, 'resume=1'], env); x = doc(out); c = x['run']['checkpoint'] if x else {}
    return dict(exit=r.returncode, stderr=r.stderr.strip()[:400], resultWritten=x is not None, complete=bool(x and x['completion']['complete']), resumedFrom=c.get('resumedFrom'), resumeNote=c.get('resumeNote'),
                warnings=c.get('warnings'), pointsRestored=c.get('pointsRestored'), equalsUninterrupted=bool(x and points(x) == want))
def edit(names, f):
    def go(d):
        for n in names:
            p = os.path.join(d, n); t = open(p, 'rb').read(); u = f(t); assert u != t, n; open(p, 'wb').write(u)
    return go
both = ('manifest.json', 'manifest.prev.json')
ws = lambda t: t.replace(b'"resumeCount":', b'"resumeCount" :')
value = lambda t: re.sub(rb'"frequency":\[0\.(\d)', lambda m: b'"frequency":[0.' + (b'8' if m.group(1) == b'9' else bytes([m.group(1)[0] + 1])), t, count=1)
checksum = lambda t: re.sub(rb'"bodySha256":"(.)', lambda m: b'"bodySha256":"' + (b'1' if m.group(1) == b'0' else b'0'), t, count=1)
def state(kind):
    def go(d):
        s = [j['state'] for j in json.load(open(os.path.join(d, 'manifest.json')))['body']['jobs'] if j['state']][0]; p = os.path.join(d, s['file']); b = bytearray(open(p, 'rb').read())
        if kind == 'flip': b[len(b) // 2] ^= 0x40; open(p, 'wb').write(bytes(b))
        elif kind == 'truncate': open(p, 'wb').write(bytes(b[:len(b) // 2]))
        else: os.remove(p)
    return go
A = case('white-space', edit(both, ws))
B = {'a recorded value changed in manifest.json': case('value-newest', edit(('manifest.json',), value)), 'a recorded value changed in both manifests': case('value-both', edit(both, value)),
     'the stored checksum changed in manifest.json': case('checksum-newest', edit(('manifest.json',), checksum)), 'the stored checksum changed in both manifests': case('checksum-both', edit(both, checksum)),
     'one byte of an engine state flipped': case('state-flip', state('flip')), 'an engine state truncated': case('state-truncate', state('truncate')), 'an engine state removed': case('state-missing', state('remove')),
     'manifest.json removed': case('manifest-missing', lambda d: os.remove(os.path.join(d, 'manifest.json')))}
# C the 5.7 script's memory command
small = os.path.join(root, 'studies', 'flop3-kings-small.emfix.json'); mo = ['seeds=2', 'budgets=20000,200000', 'threads=2', 'quiet=1', 'processingMode=cpu', 'checkpoint=' + os.path.join(work, 'ck-mem')]
r = run(['--study', small, os.path.join(work, 'mem.json')] + mo + ['processMemoryMiB=24']); m = doc(os.path.join(work, 'mem.json'))
C = dict(command='mwcli --study studies/flop3-kings-small.emfix.json mem.json seeds=2 budgets=20000,200000 threads=2 quiet=1 processingMode=cpu checkpoint=<dir> processMemoryMiB=24', exit=r.returncode, complete=m['completion']['complete'],
         stoppedByProcessMemory=m['run']['stoppedByProcessMemory'], processPeakRssMiB=m['run']['processPeakRssMiB'], processMemoryBudgetMiB=m['run']['processMemoryBudgetMiB'],
         largestTableMiB=max(p['tableMiB'] for s in m['variants'][0]['perSeed'] for p in s['budgets']), acceptedBy57Script='$stopped -or (Study-Complete $d): passed', memoryStopTested=bool(m['run']['stoppedByProcessMemory']))
# D a workload that exceeds its budget
big = os.path.join(root, 'studies', 'flop3-kings-detailed.emfix.json'); bo = ['seeds=2', 'budgets=2000,60000', 'threads=2', 'quiet=1', 'processingMode=cpu', 'evaluationSamples=2000']
assert run(['--study', big, os.path.join(work, 'bigref.json')] + bo + ['checkpoint=off']).returncode == 0; bref = doc(os.path.join(work, 'bigref.json'))
r = run(['--study', big, os.path.join(work, 'big.json')] + bo + ['checkpoint=' + os.path.join(work, 'ck-big'), 'processMemoryMiB=48']); b1 = doc(os.path.join(work, 'big.json'))
r2 = run(['--study', big, os.path.join(work, 'big.json')] + bo + ['checkpoint=' + os.path.join(work, 'ck-big'), 'resume=1']); b2 = doc(os.path.join(work, 'big.json'))
D = dict(tableMiBOfOneSeedAtTheLastBudget=bref['variants'][0]['perSeed'][0]['budgets'][-1]['tableMiB'], stoppedByProcessMemory=b1['run']['stoppedByProcessMemory'], status=b1['completion']['status'], processPeakRssMiB=b1['run']['processPeakRssMiB'],
         pointsCompletedBeforeTheStop=b1['completion']['pointsCompleted'], resumeExit=r2.returncode, resumedComplete=b2['completion']['complete'], resumedEqualsUninterrupted=points(b2) == points(bref))
# E the kill during the first commit after a recovery from the previous manifest
d = os.path.join(work, 'case-kill'); shutil.copytree(src, d); edit(('manifest.json',), value)(d); prev_before = sha(os.path.join(d, 'manifest.prev.json')); cur_damaged = sha(os.path.join(d, 'manifest.json'))
killed = case('kill', None, {'LD_PRELOAD': shim, 'EM_SHIM_CRASH_ON': '/manifest.json'}, keep=True); prev_after = sha(os.path.join(d, 'manifest.prev.json'))
after = case('kill', None, None, keep=True)
E = dict(damage='a recorded value changed in manifest.json; manifest.prev.json intact', killedProcessExit=killed['exit'], previousManifestSha256Before=prev_before, previousManifestSha256AfterTheKill=prev_after,
         previousManifestReplacedByTheDamagedOne=prev_after == cur_damaged, previousManifestKeptIntact=prev_after == prev_before, resumeAfterTheKill=after, checkpointLost=after['exit'] != 0)
out = dict(tool='reproduce57.py', binary=os.path.relpath(exe_src, root) if exe_src.startswith(root) else exe_src, binarySha256=sha(exe_src), build=build,
           sourceCheckpoint=dict(pointsCompleted=stopped['completion']['pointsCompleted'], pointsRequested=stopped['completion']['pointsRequested'], files=sorted(os.listdir(src))),
           A_whiteSpaceEditOfThe57Script=dict(edit='"resumeCount": -> "resumeCount" : in manifest.json and manifest.prev.json', expectedByTheScript='exit not 0 and a message with SHA-256, damaged or no usable manifest', **A),
           B_realDamage=B, C_memoryCommandOfThe57Script=C, D_workloadAboveItsBudget=D, E_killDuringTheFirstCommitAfterARecovery=E)
print(json.dumps(out, indent=1))
