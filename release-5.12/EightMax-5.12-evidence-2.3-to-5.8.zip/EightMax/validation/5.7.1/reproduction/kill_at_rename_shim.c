// Test shim (Linux, LD_PRELOAD): when EM_SHIM_CRASH_ON names a file-name suffix, the process ends with exit code 86
// at the moment it would rename a temporary file onto a destination with that suffix, as a kill or power loss at
// that instant would. EM_SHIM_SKIP=N lets the first N such renames through.
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static int seen = 0;
int rename(const char *from, const char *to) {
  static int (*real)(const char *, const char *) = 0; if (!real) real = dlsym(RTLD_NEXT, "rename");
  const char *suffix = getenv("EM_SHIM_CRASH_ON"), *skip = getenv("EM_SHIM_SKIP");
  if (suffix && *suffix) { size_t a = strlen(to), b = strlen(suffix); if (a >= b && !strcmp(to + a - b, suffix)) { if (seen++ >= (skip ? atoi(skip) : 0)) { unlink(from); _exit(86); } } }
  return real(from, to);
}
