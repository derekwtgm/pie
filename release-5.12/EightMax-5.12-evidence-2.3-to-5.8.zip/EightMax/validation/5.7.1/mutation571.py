#!/usr/bin/env python3
"""EightMax 5.7.1: can mwcli --selftest571 detect a broken engine?

Each mutation below breaks ONE behaviour the self-test is supposed to verify, in a copy of source/native. The
mutated mwcli is built and runs its own --selftest571. A mutation is "detected" when the self-test exits with
status 1 and exactly the checks that depend on the broken behaviour are not passed. The unmodified source is
built the same way as the control (every check must pass).

usage: python3 validation/5.7.1/mutation571.py <release root> <work dir> [out.json]
"""
import json, os, shutil, subprocess, sys, time
root, work = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(root, 'validation', '5.7.1', 'mutation571.json')
native, studies = os.path.join(root, 'source', 'native'), os.path.join(root, 'source', 'studies')
MUTATIONS = [
    dict(id='M0', what='none (control): the unmodified 5.7.1 source', file=None, expect=[]),
    dict(id='M1', what='the 5.7.1 repair removed: the current manifest is copied to manifest.prev.json without being verified (the 5.5 to 5.7 behaviour)',
         file='study_checkpoint55.hpp', old='if (!old.empty() && intactManifestText(old)) {', new='if (!old.empty()) {', expect=['checkpoint E2']),
    dict(id='M2', what='the manifest body is not compared with its SHA-256',
         file='study_checkpoint55.hpp', old='if (sha256Text(jvS(body)) != strOr(at(v, "bodySha256"), "")) {', new='if (false) {',
         expect=['checkpoint B1', 'checkpoint B2', 'checkpoint C1', 'checkpoint C2', 'checkpoint E2', 'controls N3']),
    dict(id='M3', what='an engine state is not compared with its recorded SHA-256 and length (only its presence is checked)',
         file='study_checkpoint55.hpp', old='if (sha.empty() || sha != j.sha || (double)bytes != j.bytes) {', new='if (sha.empty()) {', expect=['checkpoint D1', 'checkpoint D2']),
    dict(id='M4', what='no fall-back: a damaged or missing manifest.json is never replaced by manifest.prev.json',
         file='study_checkpoint55.hpp', old='const int r2 = readManifest(path("manifest.prev.json"), b, true);', new='const int r2 = r == 0 ? 0 : -1; b = "fall-back disabled";',
         expect=['checkpoint B1', 'checkpoint C1', 'checkpoint E1', 'checkpoint E2', 'checkpoint F2', 'controls N3']),
    dict(id='M5', what='the process memory budget is never enforced (every study completes: what the 5.7 script accepted as a pass)',
         file='study52.hpp', old='const double rss = currentRssMiB(); return rss > processMiB; };', new='const double rss = currentRssMiB(); (void)rss; return false; };',
         expect=['memory A', 'memory B', 'memory C', 'memory D2']),
    dict(id='M6', what='a memory stop does not save the engine state it interrupts',
         file='study52.hpp', old='p.stopReason="process memory budget exceeded during training";if (updates > updatesAtSave) saveNow((int)b, p.deals);break;}', new='p.stopReason="process memory budget exceeded during training";break;}',
         expect=['memory A', 'memory B', 'memory C', 'memory D2']),
]
os.makedirs(work, exist_ok=True); rows = []
for m in MUTATIONS:
    d = os.path.join(work, m['id']); shutil.rmtree(d, ignore_errors=True); shutil.copytree(native, os.path.join(d, 'native'))
    if m['file']:
        p = os.path.join(d, 'native', m['file']); text = open(p).read(); assert text.count(m['old']) == 1, (m['id'], text.count(m['old'])); open(p, 'w').write(text.replace(m['old'], m['new']))
    n = os.path.join(d, 'native'); exe = os.path.join(d, 'mwcli'); t = time.time()
    subprocess.run(['gcc', '-O2', '-c', os.path.join(n, 'json.c'), '-o', os.path.join(d, 'json.o')], check=True)
    subprocess.run(['g++', '-std=c++20', '-O2', '-ffp-contract=off', '-I' + n, os.path.join(n, 'mw.cpp'), os.path.join(n, 'mwcli.cpp'), os.path.join(d, 'json.o'), '-lpthread', '-ldl', '-lz', '-o', exe], check=True)
    st = os.path.join(d, 'st'); r = subprocess.run([exe, '--selftest571', studies, st, 'all'], capture_output=True, text=True)
    rep = json.load(open(os.path.join(st, 'selftest571.json')))
    not_passed = [c['section'] + ' ' + c['id'] for c in rep['checks'] if c['status'] != 'passed']
    statuses = {c['section'] + ' ' + c['id']: c['status'] for c in rep['checks'] if c['status'] != 'passed'}
    detected = (r.returncode == 1 and sorted(not_passed) == sorted(m['expect'])) if m['file'] else (r.returncode == 0 and not not_passed)
    rows.append(dict(id=m['id'], mutation=m['what'], file=m['file'], replaced=m.get('old'), by=m.get('new'), selftestExit=r.returncode, passed=rep['passed'], failed=rep['failed'], untested=rep['untested'],
                     checksNotPassed=statuses, expectedNotPassed=m['expect'], asExpected=detected, seconds=round(time.time() - t, 1),
                     details={k: next(c['detail'] for c in rep['checks'] if c['section'] + ' ' + c['id'] == k)[:300] for k in not_passed}))
    print(m['id'], 'exit', r.returncode, 'passed', rep['passed'], 'failed', rep['failed'], 'untested', rep['untested'], '| not passed:', not_passed, '| as expected:', detected, flush=True)
    shutil.rmtree(d, ignore_errors=True)
ok = all(r['asExpected'] for r in rows)
json.dump(dict(tool='mutation571.py', what='mwcli --selftest571 run by engines with one verified behaviour broken', compiler=subprocess.run(['g++', '--version'], capture_output=True, text=True).stdout.split('\n')[0],
               mutations=len(rows) - 1, detectedExactly=sum(r['asExpected'] for r in rows[1:]), controlPassed=rows[0]['asExpected'], allAsExpected=ok, rows=rows), open(out, 'w'), indent=1)
print('all as expected:', ok, '->', out); sys.exit(0 if ok else 1)
