#!/bin/bash
# EightMax 5.7.1 sanitizer runs: the code 5.7.1 touched (the study checkpoint commit, the save fault filter) and the
# new self-test. Usage: bash validation/5.7.1/sanitize571.sh <release root> <work dir>
#  1. AddressSanitizer + UndefinedBehaviorSanitizer + float-cast-overflow build of the host and CLI (the 5.3 builder);
#     then the 5.5 and 5.6 regression files (study checkpoints, recovery, the checkpoint lock), the checkpoint tests of
#     the 5.7.1 file, and mwcli --selftest571 in checkpoint mode. The memory checks are not run with the instrumented
#     program: AddressSanitizer changes the resident set they measure.
#  2. ThreadSanitizer build of the CLI: a checkpointed study with seeds side by side, a cancelled and resumed study,
#     a resume after a recovery from the previous manifest (the repaired commit path, with three seeds committing
#     side by side), and mwcli --selftest571 in checkpoint mode.
#  3. Leak check: the ASan CLI with detect_leaks=1 on a study resumed from the previous manifest.
set -u
root=$(cd "$1" && pwd); work=$2; out="$root/validation/5.7.1/sanitizers"; rm -rf "$work" "$out"; mkdir -p "$work" "$out"
T="$root/source/tests"
bash "$root/validation/5.3/sanitizers/build-final.sh" "$root/source" "$root/build" "$work/asan" > "$out/build-asan-ubsan.log" 2>&1; echo "asan build exit $?" | tee "$out/build-asan-ubsan.exit"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax" EM_TEST_HOST_STDERR="$out/host-stderr.log" \
  node --test --test-concurrency=1 --test-reporter=tap "$T/v55.test.js" "$T/v56.test.js" > "$out/v55-v56-asan-ubsan.tap" 2> "$out/v55-v56-asan-ubsan.stderr"
echo "asan tests (5.5 and 5.6 files) exit $?" | tee "$out/v55-v56-asan-ubsan.exit"; tail -9 "$out/v55-v56-asan-ubsan.tap"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax" \
  node --test --test-concurrency=1 --test-reporter=tap --test-name-pattern='formatting is not corruption|altered data and altered checksums|damaged, truncated and missing|engine repair|EM_TEST_SAVE_FAULT_FILE' "$T/v571.test.js" > "$out/v571-asan-ubsan.tap" 2> "$out/v571-asan-ubsan.stderr"
echo "asan tests (5.7.1 file, the five checkpoint tests) exit $?" | tee "$out/v571-asan-ubsan.exit"; tail -9 "$out/v571-asan-ubsan.tap"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 "$work/asan/mwcli" --selftest571 "$root/studies" "$work/st-asan" checkpoint > "$out/selftest571-asan.stdout" 2> "$out/selftest571-asan.stderr"; echo "asan selftest571 (checkpoint mode) exit $?" | tee "$out/selftest571-asan.exit"
cp "$work/st-asan/selftest571.json" "$out/selftest571-asan.json" 2>/dev/null
grep -c -E 'ERROR: AddressSanitizer|runtime error:' "$out/v55-v56-asan-ubsan.tap" "$out/v55-v56-asan-ubsan.stderr" "$out/v571-asan-ubsan.tap" "$out/v571-asan-ubsan.stderr" "$out/selftest571-asan.stdout" "$out/selftest571-asan.stderr" "$out/selftest571-asan.json" "$out/host-stderr.log" 2>/dev/null | tee "$out/sanitizer-report-counts.txt"
# 2
obj="$work/tsan"; mkdir -p "$obj"; printf '#define EM_VERSION "5.7.1"\n#define EM_BUILD_ID "tsan"\n' > "$obj/build_info.h"
( cd "$root/source/native" && g++ -std=c++20 -O1 -g1 -fsanitize=thread -fno-omit-frame-pointer -march=x86-64 -ffp-contract=off -I. -c mw.cpp -o "$obj/mw.o" && gcc -O1 -fsanitize=thread -c json.c -o "$obj/json.o" &&
  g++ -std=c++20 -O1 -g1 -fsanitize=thread -march=x86-64 -ffp-contract=off -I. -include "$obj/build_info.h" mwcli.cpp "$obj/mw.o" "$obj/json.o" -lpthread -ldl -lz -o "$obj/mwcli" ) > "$out/build-tsan.log" 2>&1; echo "tsan build exit $?" | tee "$out/build-tsan.exit"
F="$root/studies/flop6-jack.emfix.json"; O="variants=baseline seeds=101,102,103 budgets=3000,9000 evaluationSamples=256 qualitySamples=64 threads=3 parallelSeeds=3 quiet=1"; export TSAN_OPTIONS=halt_on_error=0
{ "$obj/mwcli" --study "$F" "$work/t1.json" $O checkpoint="$work/tck1" checkpointSeconds=0.05; echo "study exit $?"
  EM_STUDY_CANCEL_AFTER_MS=1500 "$obj/mwcli" --study "$F" "$work/t2.json" $O checkpoint="$work/tck2" checkpointSeconds=0.05; echo "cancelled study exit $?"
  # the newest manifest is destroyed: the resume recovers from manifest.prev.json and commits with three seeds side by side
  head -c 300 "$work/tck2/manifest.json" > "$work/tck2/manifest.cut" && mv "$work/tck2/manifest.cut" "$work/tck2/manifest.json"
  "$obj/mwcli" --study "$F" "$work/t2.json" $O checkpoint="$work/tck2" resume=1; echo "study resumed from the previous manifest exit $?"
  "$obj/mwcli" --selftest571 "$root/studies" "$work/st-tsan" checkpoint; echo "selftest571 (checkpoint mode) exit $?"; } > "$out/tsan.log" 2>&1
cp "$work/st-tsan/selftest571.json" "$out/selftest571-tsan.json" 2>/dev/null
echo "ThreadSanitizer warnings: $(grep -c 'WARNING: ThreadSanitizer' "$out/tsan.log")" | tee "$out/tsan-summary.txt"; grep -E 'exit [0-9]+' "$out/tsan.log" | tee -a "$out/tsan-summary.txt"
grep -o '"resumedFrom":"[^"]*"' "$work/t2.json" | tee -a "$out/tsan-summary.txt"
python3 "$root/source/tools/study_equivalence55.py" "$work/t1.json" "$work/t2.json" --quiet | tee -a "$out/tsan-summary.txt"
# 3
K="$root/studies/known-akq-river.emfix.json"; KO="seeds=2 budgets=500,3000,400000 threads=2 quiet=1"
ASAN_OPTIONS=detect_leaks=0 "$work/asan/mwcli" --study "$K" "$work/leak.json" $KO checkpoint="$work/lck" checkpointSeconds=0.02 timeLimitSeconds=0.4 > /dev/null 2>&1
head -c 200 "$work/lck/manifest.json" > "$work/lck/manifest.cut" 2>/dev/null && mv "$work/lck/manifest.cut" "$work/lck/manifest.json"
ASAN_OPTIONS=detect_leaks=1 "$work/asan/mwcli" --study "$K" "$work/leak.json" $KO checkpoint="$work/lck" resume=1 > "$out/leak-resumed-study.log" 2>&1; echo "$?" > "$out/leak-resumed-study.exit"
echo "leak check exit: study resumed from the previous manifest $(cat "$out/leak-resumed-study.exit")" | tee "$out/leak-summary.txt"; grep -c 'ERROR: LeakSanitizer' "$out/leak-resumed-study.log" | tee -a "$out/leak-summary.txt"
grep -o '"resumedFrom":"[^"]*"' "$work/leak.json" | tee -a "$out/leak-summary.txt"
{ cat "$out/build-asan-ubsan.exit" "$out/v55-v56-asan-ubsan.exit" "$out/v571-asan-ubsan.exit" "$out/selftest571-asan.exit" "$out/build-tsan.exit"
  for f in v55-v56-asan-ubsan v571-asan-ubsan; do grep -E '^# (tests|pass|fail|skipped)' "$out/$f.tap" | tr '\n' ' '; echo "($f)"; done
  echo "sanitizer reports (ERROR: AddressSanitizer / runtime error) in all outputs: $(awk -F: '{s+=$NF} END{print s+0}' "$out/sanitizer-report-counts.txt")"
  cat "$out/tsan-summary.txt" "$out/leak-summary.txt"; } > "$out/summary.txt"
