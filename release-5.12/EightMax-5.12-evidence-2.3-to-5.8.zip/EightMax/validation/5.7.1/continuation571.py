#!/usr/bin/env python3
"""EightMax 5.7.1: solver states are interchangeable with 5.7.

For each of the 11 golden games (validation/5.7/windows/golden, states written by the 5.5 Linux trainer) and each
frozen-batch fixture of validation/5.7/fixtures (states written by the 5.6 Linux binary):
  1. the unchanged 5.7 binary trains the first half and saves; the 5.7.1 binary continues from that file to the end;
  2. the 5.7.1 binary trains the first half and saves; the unchanged 5.7 binary continues to the end;
  3. the 5.7.1 binary trains the whole run.
Each final state must be byte-identical to the recorded golden state.

usage: python3 validation/5.7.1/continuation571.py <release root> <5.7 mwcli> <5.7.1 mwcli> <work dir> [out.json]
"""
import hashlib, json, os, shutil, subprocess, sys
root, old_src, new_src, work = [os.path.abspath(a) for a in sys.argv[1:5]]
out = sys.argv[5] if len(sys.argv) > 5 else os.path.join(root, 'validation', '5.7.1', 'continuation', 'continuation-against-5.7.json')
shutil.rmtree(work, ignore_errors=True); os.makedirs(work); os.makedirs(os.path.dirname(out), exist_ok=True)
old, new = os.path.join(work, 'mwcli-5.7'), os.path.join(work, 'mwcli-5.7.1')
for s, d in ((old_src, old), (new_src, new)): shutil.copyfile(s, d); os.chmod(d, 0o755)
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
def train(exe, spec, updates, threads, state, mem, start=None, env=None):
    e = dict(os.environ); e.update(env or {})
    r = subprocess.run([exe, spec, str(updates), str(threads), state, str(mem)] + ([start] if start else []), capture_output=True, text=True, env=e)
    return r.returncode
cases = []
g = os.path.join(root, 'validation', '5.7', 'windows', 'golden')
for c in json.load(open(os.path.join(g, 'golden.json')))['cases']: cases.append((c['name'], os.path.join(g, c['spec']), c['updates'], c['threads'], c['memoryMiB'], c['stateSha256'], 'the 5.5 trainer', {}))
f = os.path.join(root, 'validation', '5.7', 'fixtures')
for c in json.load(open(os.path.join(f, 'golden57.json')))['training']: cases.append((c['name'], os.path.join(f, c['spec']), c['updates'], 4, c['memoryMiB'], c['stateSha256'], 'the 5.6 binary', {'EIGHTMAX_THREAD_CHOICE': 'fixed'}))
rows = []
for name, spec, updates, threads, mem, want, origin, env in cases:
    first, rest = updates // 2, updates - updates // 2; p = lambda n: os.path.join(work, name + '.' + n + '.state'); row = dict(game=name, updates=updates, threads=threads, goldenStateOf=origin, goldenSha256=want)
    a = train(old, spec, first, threads, p('a1'), mem, env=env); b = train(new, spec, rest, threads, p('a2'), mem, p('a1'), env)
    row['trainedBy57ContinuedBy571'] = dict(exits=[a, b], sha256=sha(p('a2')) if b == 0 else None)
    a = train(new, spec, first, threads, p('b1'), mem, env=env); b = train(old, spec, rest, threads, p('b2'), mem, p('b1'), env)
    row['trainedBy571ContinuedBy57'] = dict(exits=[a, b], sha256=sha(p('b2')) if b == 0 else None)
    a = train(new, spec, updates, threads, p('c'), mem, env=env); row['trainedBy571'] = dict(exits=[a], sha256=sha(p('c')) if a == 0 else None)
    row['identical'] = all(row[k]['sha256'] == want for k in ('trainedBy57ContinuedBy571', 'trainedBy571ContinuedBy57', 'trainedBy571'))
    rows.append(row); print(name, 'identical' if row['identical'] else 'DIFFERENT', flush=True)
    for n in ('a1', 'a2', 'b1', 'b2', 'c'):
        if os.path.exists(p(n)): os.remove(p(n))
ok = all(r['identical'] for r in rows)
json.dump(dict(tool='continuation571.py', binary57Sha256=sha(old_src), binary571Sha256=sha(new_src), cases=len(rows), identical=sum(r['identical'] for r in rows), allIdentical=ok, rows=rows), open(out, 'w'), indent=1)
print('all identical:', ok, '->', out); sys.exit(0 if ok else 1)
