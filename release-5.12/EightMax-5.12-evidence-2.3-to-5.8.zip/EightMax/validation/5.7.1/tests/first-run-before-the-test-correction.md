# The first full regression run of 5.7.1, before one test was corrected

Recorded from the development session. The TAP file of this run was not kept: the evidence folder was cleared before
the final run, which is the one in `validation/5.7.1/tests/`. The figures and the two failure records below were
copied from the session's output at the time.

Build `b95ea4033defbcf1` (the source of the final build except for one line of `source/tests/v48.test.js`), Linux,
three test files at a time, with another study process running on the machine during part of the run.

```
# tests 606 # pass 603 # fail 2 # cancelled 0 # skipped 1 # duration_ms 1183242.615044
not ok 403 - 4.4 reproduced 4.3 regression: eight-handed range-sampled EV returns a labelled partial estimate within 50 ms of 100, 250, 600 and 1000 ms limits at 1, 2, 4 and 8 threads
    error: 'limit 1000 ms, 4 threads: returned 56.8 ms after the limit'
    location: source/tests/v44.test.js:197
not ok 474 - 4.8 tournament defaults are unchanged: 8 players, 0.5/1 blinds, 0.1 bb antes, 2.3 bb starting pot, UTG..BB
    error: 'version 4.8 or later'
    location: source/tests/v48.test.js:233 (assertion at line 239)
```

Run again alone on the idle machine:

```
passed alone (v44.test.js): 4.4 reproduced 4.3 regression: ...
FAILED AGAIN ALONE (v48.test.js): 4.8 tournament defaults are unchanged: ...
```

## Classification

**Test 403 (4.4): timing under load.** The test allows an evaluation to return up to 50 ms after its time limit; it
returned 56.8 ms after a 1,000 ms limit while three test files and another study shared four processors, and passed
alone. No code on that path was changed in 5.7.1. Not a defect.

**Test 474 (4.8): a defect of the test, exposed by the first three-part version.** Line 239 was

```js
assert.ok(+fs.readFileSync(path.join(__dirname, '..', 'VERSION'), 'utf8').trim() >= 4.8, 'version 4.8 or later');
```

`+"5.7.1"` is `NaN`, and `NaN >= 4.8` is false. The assertions before it, which are the ones about the tournament
defaults, had passed: the eight-player starting pot is 2.3 BB (0.5 + 1 + 8 x 0.1) and UTG acts first. The line now
compares the version part by part (major greater than 4, or major 4 and minor at least 8); for every two-part
version it accepts and rejects exactly what the old line did, except that "4.10" is now later than "4.8". The seat
labels asserted after it (UTG, UTG+1, MP, HJ, CO, BTN, SB, BB) pass.

Nothing else compares the version as a number (searched in `source/tests`, `source/tools`, `source/web` and
`source/native`).
