#!/usr/bin/env python3
"""Collects the evidence under validation/5.7.1 into validation/5.7.1/validation-summary.json (the machine-readable
validation status of the release; release571.py copies it into the identity file). Usage: summarize571.py <release root>
Every figure is read from an evidence file; a missing file gives null, never a default."""
import json, sys, pathlib, re
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.7.1'
def load(p):
    p = V / p; return json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else None
def text(p):
    p = V / p; return p.read_text(errors='replace') if p.exists() else None
def tap_totals(t):
    if t is None: return None
    g = lambda k: (lambda m: int(m.group(1)) if m else None)(re.search(r'^# %s (\d+)' % k, t, re.M))
    return {'tests': g('tests'), 'passed': g('pass'), 'failed': g('fail'), 'skipped': g('skipped'), 'failedTests': re.findall(r'^not ok \d+ - (.*)$', t, re.M), 'skippedTests': [m[0] for m in re.findall(r'^ok \d+ - (.*?) # SKIP(.*)$', t, re.M)]}
def num(p):
    t = text(p); return int(re.search(r'(-?\d+)', t).group(1)) if t and re.search(r'(-?\d+)', t) else None
def selftest(p):
    d = load(p)
    return None if d is None else {'passed': d['passed'], 'failed': d['failed'], 'untested': d.get('untested'), 'build': d['build'], 'platform': d.get('platform'), 'seconds': d['seconds'],
                                   'notPassed': [c.get('section', '') + ' ' + c.get('id', c['name']) for c in d['checks'] if not c['passed']]}
info = json.loads((root / 'BUILD-INFO.json').read_text()) if (root / 'BUILD-INFO.json').exists() else json.loads((root / 'build/build-info.json').read_text())
S = {'release': info['version'], 'build': info['build'], 'patchOf': {'release': '5.7', 'build': 'e4668abe7903f8b0'},
     'classes': {'1': 'implemented and independently tested (an independent implementation, an exact reference, or the unchanged 5.7 binary agrees)', '2': 'implemented and verified by the project\'s own tests on Linux, or by the Windows programs under Wine',
                 '3': 'implemented, awaiting physical hardware validation (never executed on Windows hardware or an NVIDIA GPU)', '4': 'not implemented, unsuccessful, or not executed'}}
S['baseline57'] = load('baseline/baseline-5.7.json')
S['reproductionWithThe57Binary'] = load('reproduction/reproduction-5.7-binary.json')
r571 = load('reproduction/reproduction-5.7.1-binary.json')
S['sameStepsWithThe571Binary'] = None if r571 is None else {'build': r571['build'], 'whiteSpaceAccepted': r571['A_whiteSpaceEditOfThe57Script']['exit'] == 0 and r571['A_whiteSpaceEditOfThe57Script']['equalsUninterrupted'],
    'killDuringTheFirstCommitAfterARecovery': {k: r571['E_killDuringTheFirstCommitAfterARecovery'][k] for k in ('killedProcessExit', 'previousManifestReplacedByTheDamagedOne', 'previousManifestKeptIntact', 'checkpointLost')}}
# regression
t = text('tests/full-regression.tap'); reg = tap_totals(t); rerun = text('tests/rerun-alone.txt')
if reg:
    reg['rerunAlone'] = [l for l in (rerun or '').splitlines() if l.strip()]; reg['failedAgainAlone'] = [l for l in reg['rerunAlone'] if l.startswith('FAILED AGAIN') or l.startswith('NOT FOUND')]
    reg['tests571'] = len(re.findall(r'^(?:ok|not ok) \d+ - 5\.7\.1 ', t, re.M)); reg['tests571Passed'] = len(re.findall(r'^ok \d+ - 5\.7\.1 ', t, re.M))
    reg['effective'] = {'passed': reg['passed'] + len(reg['rerunAlone']) - len(reg['failedAgainAlone']), 'failed': len(reg['failedAgainAlone']), 'skipped': reg['skipped']} if reg['passed'] is not None else None
    reg['regression57'] = {'tests': 592, 'passed': 591, 'failed': 0, 'skipped': 1}
S['regressionLinux'] = reg
S['selftest571Linux'] = selftest('selftest/selftest571-linux.json'); S['selftest57Linux'] = selftest('selftest/selftest57-linux.json')
# sanitizers
ts = text('sanitizers/tsan-summary.txt'); counts = text('sanitizers/sanitizer-report-counts.txt')
S['sanitizers'] = {'asanUbsan55and56': tap_totals(text('sanitizers/v55-v56-asan-ubsan.tap')), 'asanUbsan571CheckpointTests': tap_totals(text('sanitizers/v571-asan-ubsan.tap')), 'asanUbsanSelftest571Checkpoint': selftest('sanitizers/selftest571-asan.json'),
    'asanBuildExit': num('sanitizers/build-asan-ubsan.exit'), 'tsanBuildExit': num('sanitizers/build-tsan.exit'),
    'sanitizerReports': sum(int(l.rsplit(':', 1)[1]) for l in counts.splitlines() if ':' in l and l.rsplit(':', 1)[1].strip().isdigit()) if counts else None,
    'threadSanitizerWarnings': (lambda m: int(m.group(1)) if m else None)(re.search(r'ThreadSanitizer warnings: (\d+)', ts or '')), 'threadSanitizerRuns': re.findall(r'^(.*) exit (\d+)$', ts or '', re.M),
    'threadSanitizerSelftest571Checkpoint': selftest('sanitizers/selftest571-tsan.json'), 'threadSanitizerNotes': [l for l in (ts or '').splitlines() if 'resumedFrom' in l or 'EQUIVALENT' in l or 'DIFFER' in l],
    'leakSummary': (text('sanitizers/leak-summary.txt') or '').strip().splitlines() or None, 'memoryChecksUnderSanitizers': 'not run: AddressSanitizer and ThreadSanitizer change the resident set the memory checks measure'} if (V / 'sanitizers').exists() else None
# identity against the unchanged 5.7 binary
idn = load('identity/summary.json')
if idn and (V / 'identity/identity.jsonl').exists():
    rows = [json.loads(l) for l in (V / 'identity/identity.jsonl').read_text().splitlines() if l.strip()]; arms = [a for r in rows for a in r.get('arms', [])]
    idn.update(applicableCases=sum('arms' in r for r in rows), identicalCases=sum(r['verdict'] == 'identical' for r in rows), trainingsCompared=len(arms), identicalStates=sum(bool(a.get('identical')) for a in arms),
               different=[r.get('case', r.get('name')) for r in rows if r['verdict'] != 'identical'], baseline='validation/5.7/linux-bin/mwcli (the unchanged 5.7 binary)')
S['identityAgainst57'] = idn
c = load('continuation/continuation-against-5.7.json'); S['solverStatesInterchangeableWith57'] = None if c is None else {k: c[k] for k in ('cases', 'identical', 'allIdentical', 'binary57Sha256', 'binary571Sha256')}
m = load('mutation571.json'); S['mutations'] = None if m is None else {'mutations': m['mutations'], 'detectedExactly': m['detectedExactly'], 'controlPassed': m['controlPassed'], 'allAsExpected': m['allAsExpected'],
    'rows': [{'id': r['id'], 'mutation': r['mutation'], 'selftestExit': r['selftestExit'], 'checksNotPassed': r['checksNotPassed'], 'asExpected': r['asExpected']} for r in m['rows']]}
# Wine
w = {f: tap_totals(text('wine/%s.test.tap' % f)) for f in ('v571', 'v57', 'v56', 'v55')}
S['wine'] = {'version': next((l.strip() for l in (text('wine/wine-version.txt') or '').splitlines() if l.startswith('wine-')), None), 'buildId': (text('wine/build-id.txt') or '').strip() or None, 'selftest571': selftest('wine/selftest571-wine.json'), 'selftest57': selftest('wine/selftest57-wine.json'),
             'tests': w, 'rerunAlone': (text('wine/rerun-alone.txt') or '').strip().splitlines() or None, 'controlWithThe57Programs': load('wine/control-v55-desktop.json'), 'note': 'The Windows executables of the final build under Wine in a Linux container. Wine is not Windows: class 2.'} if (V / 'wine').exists() else None
ui = load('ui/study-ui56.json'); S['ui'] = None if ui is None else {'checksPassed': sum(bool(c.get('passed', c.get('ok'))) for c in ui.get('checks', [])), 'checksTotal': len(ui.get('checks', [])), 'browser': ui.get('browser'), 'build': ui.get('build')}
st = load('stability/stability55.json'); S['stability'] = None if st is None else {'passed': st.get('passed'), 'checks': len(st.get('checks', [])), 'checksPassed': sum(bool(c.get('passed', c.get('ok'))) for c in st.get('checks', [])), 'minutes': st.get('minutesRequested'), 'build': st.get('build')}
lint = load('powershell/static-checks.json')
S['windows'] = {'executablesBuilt': 'cross-compiled on Linux with MinGW-w64 GCC 13 (static), the toolchain that reproduces the shipped 5.7 executables byte for byte', 'executedOnWindowsHardware': False, 'validateWindows571ps1Executed': False,
    'powershellAvailableInDevelopment': False, 'githubActionsWorkflowRun': False,
    'whyNot': 'no Windows machine; running a downloaded PowerShell was refused by the development session\'s permission policy; the session had read-only access to the repository, so no workflow could be started',
    'staticChecksOfThePowerShellScript': lint, 'launchers': ['Run 5.7.1 focused validation.bat', 'Run 5.7.1 Windows validation.bat'],
    'physicalRunOf57': 'validation/5.7.1/windows-5.7-physical (81 passed, 1 failed, build e4668abe7903f8b0): evidence about 5.7, not about 5.7.1'}
S['gpu'] = {'executedOnNvidiaHardware': False, 'cudaCodeChangedIn571': False, 'statement': 'No GPU result exists for the 5.7.1 executables. The CUDA paths of 5.7 ran on an RTX 4060 Ti and matched the CPU (validation/5.7.1/windows-5.7-physical/hardware-validation.json); no CUDA source file was changed, but the executables were rebuilt and have not run on a GPU.'}
(V / 'validation-summary.json').write_text(json.dumps(S, indent=1) + '\n')
brief = {k: (v if not isinstance(v, dict) else {a: b for a, b in v.items() if not isinstance(b, (dict, list))}) for k, v in S.items() if k not in ('classes', 'baseline57', 'reproductionWithThe57Binary')}
print(json.dumps(brief, indent=1)[:6000])
