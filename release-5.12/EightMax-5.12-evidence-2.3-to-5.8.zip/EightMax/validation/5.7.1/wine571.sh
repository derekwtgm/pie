#!/bin/bash
# EightMax 5.7.1: the Windows programs under Wine. Usage: bash validation/5.7.1/wine571.sh <release root> <wrapper dir> <work dir>
# <wrapper dir> holds mwcli-wine and EightMax-wine: small scripts that start the Windows executable of <release root>
# under Wine with a minimal environment and pass on EightMax's own variables (validation/5.6/wine/wrapper-example.sh).
#  1. mwcli.exe --selftest571 (what "Run 5.7.1 focused validation.bat" runs first on a Windows PC) and --selftest57
#  2. the 5.7.1, 5.7, 5.6 and 5.5 regression files with the Windows programs in place of the Linux ones. Where a test
#     compares with an archived LINUX binary (5.6 or 5.7), that binary runs natively, so those tests compare the
#     Windows build of 5.7.1 with the Linux build of the earlier release.
# Wine is not Windows: this is evidence about the Windows executables, not about a Windows PC.
set -u
root=$(cd "$1" && pwd); wr=$(cd "$2" && pwd); work=$3; out="$root/validation/5.7.1/wine"; rm -rf "$work" "$out"; mkdir -p "$work" "$out"; cd "$root"
win() { printf 'Z:%s' "${1//\//\\}"; }
"$wr/mwcli-wine" --build-id > "$out/build-id.txt" 2>&1; cat "$out/build-id.txt"
wine --version > "$out/wine-version.txt" 2>&1
mkdir -p "$work/st571"; "$wr/mwcli-wine" --selftest571 "$(win "$root/studies")" "$(win "$work/st571")" all > "$out/selftest571-wine.stdout" 2> "$out/selftest571-wine.stderr"; echo "selftest571 exit $?" | tee "$out/selftest571-wine.exit"
cp "$work/st571/selftest571.json" "$out/selftest571-wine.json" 2>/dev/null
mkdir -p "$work/st57"; "$wr/mwcli-wine" --selftest57 "$(win "$root/validation/5.7/fixtures")" "$(win "$work/st57")" > "$out/selftest57-wine.stdout" 2> "$out/selftest57-wine.stderr"; echo "selftest57 exit $?" | tee "$out/selftest57-wine.exit"
cp "$work/st57/selftest57.json" "$out/selftest57-wine.json" 2>/dev/null
: > "$out/tests.exit"
for f in v571 v57 v56 v55; do
  EM_TEST_MWCLI="$wr/mwcli-wine" EM_TEST_HOST="$wr/EightMax-wine" timeout 7200 node --test --test-concurrency=1 --test-reporter=tap "source/tests/$f.test.js" > "$out/$f.test.tap" 2> "$out/$f.test.stderr"; echo "$f exit $?" | tee -a "$out/tests.exit"
  grep -E '^# (tests|pass|fail|skipped)' "$out/$f.test.tap" | tr '\n' ' '; echo
done
