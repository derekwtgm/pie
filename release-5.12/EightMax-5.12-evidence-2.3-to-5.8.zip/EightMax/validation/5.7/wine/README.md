The Windows executables of the final build under Wine 9.0 (validation/5.7/wine57.sh), Linux container. Wine is not Windows: class 2.
- selftest57-wine.json   mwcli.exe --selftest57: the step "Run 5.7 Windows validation.bat" runs first.
- v57.test.tap           the 5.7 regression file with mwcli.exe and EightMax.exe in place of the Linux programs. Three of its tests compare with the archived 5.6 LINUX binary, which runs natively: they compare the Windows build of 5.7 with the Linux build of 5.6 (frozen-batch states for 1 to 8 threads, sampled and exact evaluations, complete studies).
- v56.test.tap           the 5.6 regression file, the same way.
The whole suite was not run under Wine for 5.7. 5.6 ran it: 514 passed, 68 failed, 1 skipped, every failure also present with the 5.5 Windows programs under the same harness (VALIDATION-5.6.md).
