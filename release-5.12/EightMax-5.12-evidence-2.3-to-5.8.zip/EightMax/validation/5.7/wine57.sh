#!/bin/bash
# EightMax 5.7: the Windows programs under Wine. Usage: bash validation/5.7/wine57.sh <release root> <wrapper dir> <work dir>
# <wrapper dir> holds mwcli-wine and EightMax-wine: small scripts that start the Windows executable under Wine with a
# minimal environment and pass on EightMax's own variables (validation/5.6/wine/wrapper-example.sh).
#  1. mwcli.exe --selftest57 (the step "Run 5.7 Windows validation.bat" runs first on a Windows PC)
#  2. the 5.7 and 5.6 regression files with the Windows programs in place of the Linux ones. Where a test compares
#     with the archived 5.6 LINUX binary, that binary runs natively, so those tests compare the Windows build of 5.7
#     with the Linux build of 5.6.
# The whole suite was not run under Wine for 5.7.
set -u
root=$(cd "$1" && pwd); wr=$(cd "$2" && pwd); work=$3; out="$root/validation/5.7/wine"; rm -rf "$work"; mkdir -p "$work" "$out"; cd "$root"
"$wr/mwcli-wine" --build-id > "$out/build-id.txt" 2>&1; cat "$out/build-id.txt"
mkdir -p "$work/st57"; "$wr/mwcli-wine" --selftest57 "Z:${root//\//\\}\\validation\\5.7\\fixtures" "Z:${work//\//\\}\\st57" > "$out/selftest57-wine.stdout" 2> "$out/selftest57-wine.stderr"; echo "selftest57 exit $?" | tee "$out/selftest57-wine.exit"
cp "$work/st57/selftest57.json" "$out/selftest57-wine.json" 2>/dev/null
for f in v57 v56; do
  EM_TEST_MWCLI="$wr/mwcli-wine" EM_TEST_HOST="$wr/EightMax-wine" timeout 5400 node --test --test-concurrency=1 --test-reporter=tap "source/tests/$f.test.js" > "$out/$f.test.tap" 2> "$out/$f.test.stderr"; echo "$f exit $?" | tee -a "$out/tests.exit"
  grep -E '^# (tests|pass|fail|skipped)' "$out/$f.test.tap" | tr '\n' ' '; echo
done
