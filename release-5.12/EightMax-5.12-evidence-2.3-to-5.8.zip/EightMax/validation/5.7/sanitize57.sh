#!/bin/bash
# EightMax 5.7 sanitizer runs. Usage: bash validation/5.7/sanitize57.sh <release root> <work dir>
#  1. AddressSanitizer + UndefinedBehaviorSanitizer + float-cast-overflow build of the host and CLI (the 5.3 builder),
#     then the 5.3, 5.4, 5.5 and 5.6 regression files against it (leak detection off: see 3), and four tests of the
#     5.7 file: frozen batches on 1 to 8 threads with every trainer option, the training output, the evaluator path
#     tree with a small memory, and mwcli --selftest57 (worker pool, deal queue, golden states, evaluation).
#     The 5.6 run of this step had one failure, a test that allowed 40 resumes of 0.4 s (the instrumented program
#     needed 54); 5.7 bounds that loop by the duration of the test's own uninterrupted run (v56.test.js).
#  2. ThreadSanitizer build of the CLI: the 5.6 scenarios (studies with seeds side by side, cancel and resume, exact
#     studies, frozen-batch training on 4 threads, parallel exact best response) and the 5.7 ones: frozen-batch
#     training with every update forced onto 4 and 8 threads on a game and on fixtures with Compact and Detailed hand
#     groups (parallel preparation, row-partitioned merge), the measured thread choice, a training stopped by a
#     2 MiB table budget, and sampled evaluation on 4 threads (one path tree per worker).
#  3. Leak check: the ASan CLI with detect_leaks=1 on a complete study and on a frozen-batch training.
set -u
root=$(cd "$1" && pwd); work=$2; out="$root/validation/5.7/sanitizers"; rm -rf "$work" "$out"; mkdir -p "$work" "$out"   # a fresh work directory: checkpoints left by an earlier run would be refused
T="$root/source/tests"
bash "$root/validation/5.3/sanitizers/build-final.sh" "$root/source" "$root/build" "$work/asan" > "$out/build-asan-ubsan.log" 2>&1; echo "asan build exit $?" | tee "$out/build-asan-ubsan.exit"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax" EM_TEST_HOST_STDERR="$out/host-stderr.log" \
  node --test --test-concurrency=1 --test-reporter=tap "$T/v53.test.js" "$T/v54.test.js" "$T/v55.test.js" "$T/v56.test.js" > "$out/v53-v56-asan-ubsan.tap" 2> "$out/v53-v56-asan-ubsan.stderr"
echo "asan tests (5.3 to 5.6 files) exit $?" | tee "$out/v53-v56-asan-ubsan.exit"; tail -9 "$out/v53-v56-asan-ubsan.tap"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1 EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax" \
  node --test --test-concurrency=1 --test-reporter=tap --test-name-pattern='5.7 frozen batches: one state|5.7 training output|small evaluator memory|selftest57' "$T/v57.test.js" > "$out/v57-asan-ubsan.tap" 2> "$out/v57-asan-ubsan.stderr"
echo "asan tests (5.7 file, four tests) exit $?" | tee "$out/v57-asan-ubsan.exit"; tail -9 "$out/v57-asan-ubsan.tap"
grep -c -E 'ERROR: AddressSanitizer|runtime error:' "$out/v53-v56-asan-ubsan.tap" "$out/v53-v56-asan-ubsan.stderr" "$out/v57-asan-ubsan.tap" "$out/v57-asan-ubsan.stderr" "$out/host-stderr.log" 2>/dev/null | tee "$out/sanitizer-report-counts.txt"
# 2
obj="$work/tsan"; mkdir -p "$obj"; printf '#define EM_VERSION "5.7"\n#define EM_BUILD_ID "tsan"\n' > "$obj/build_info.h"
( cd "$root/source/native" && g++ -std=c++20 -O1 -g1 -fsanitize=thread -fno-omit-frame-pointer -march=x86-64 -ffp-contract=off -I. -c mw.cpp -o "$obj/mw.o" && gcc -O1 -fsanitize=thread -c json.c -o "$obj/json.o" &&
  g++ -std=c++20 -O1 -g1 -fsanitize=thread -march=x86-64 -ffp-contract=off -I. -include "$obj/build_info.h" mwcli.cpp "$obj/mw.o" "$obj/json.o" -lpthread -ldl -lz -o "$obj/mwcli" ) > "$out/build-tsan.log" 2>&1; echo "tsan build exit $?" | tee "$out/build-tsan.exit"
F="$root/studies/flop6-jack.emfix.json"; O="variants=baseline seeds=101,102,103 budgets=3000,9000 evaluationSamples=256 qualitySamples=64 threads=3 parallelSeeds=3 quiet=1"
G="$root/source/tools/games48.js"; X="$root/validation/5.7/fixtures"; export TSAN_OPTIONS=halt_on_error=0
{ "$obj/mwcli" --study "$F" "$work/t1.json" $O checkpoint="$work/tck1" checkpointSeconds=0.05; echo "study exit $?"
  EM_STUDY_CANCEL_AFTER_MS=1500 "$obj/mwcli" --study "$F" "$work/t2.json" $O checkpoint="$work/tck2" checkpointSeconds=0.05; echo "cancelled study exit $?"
  "$obj/mwcli" --study "$F" "$work/t2.json" $O checkpoint="$work/tck2" resume=1; echo "resumed study exit $?"
  "$obj/mwcli" --study "$root/studies/known-akq-river.emfix.json" "$work/t3.json" seeds=4 budgets=500,3000 threads=4 parallelSeeds=4 quiet=1; echo "exact study exit $?"
  "$obj/mwcli" --study "$root/studies/known-akq-river.emfix.json" "$work/t4.json" seeds=4 budgets=500,3000 threads=4 parallelSeeds=4 quiet=1 opponentEnumeration=river-cross; echo "river-cross study exit $?"
  node "$G" spec turn4 "$work/b.json" 5 '{"batchDeals":16,"actionStreams":"deal","device":"cpu"}' > /dev/null
  "$obj/mwcli" "$work/b.json" 600 4 "$work/b.state" 128 > /dev/null; echo "frozen-batch training (default, 4 threads, measured choice) exit $?"
  EIGHTMAX_THREAD_CHOICE=fixed "$obj/mwcli" "$work/b.json" 600 4 "$work/b4.state" 128 > /dev/null; echo "frozen-batch training (default, every update on 4 threads) exit $?"
  EIGHTMAX_THREAD_CHOICE=fixed "$obj/mwcli" "$work/b.json" 600 8 "$work/b8.state" 128 > /dev/null; echo "frozen-batch training (default, every update on 8 threads) exit $?"
  node "$G" spec turn4 "$work/c.json" 5 '{"batchDeals":16,"actionStreams":"deal","device":"cpu","opponentEnumeration":"river-cross"}' > /dev/null
  EIGHTMAX_THREAD_CHOICE=fixed "$obj/mwcli" "$work/c.json" 600 4 "$work/c.state" 128 > /dev/null; echo "frozen-batch training (river-cross, every update on 4 threads) exit $?"
  node "$G" spec flop6 "$work/e.json" 5 '{"batchDeals":64,"actionStreams":"deal","device":"cpu","weighting":"dcfr"}' > /dev/null
  EIGHTMAX_THREAD_CHOICE=fixed "$obj/mwcli" "$work/e.json" 200 4 "$work/e.state" 128 > /dev/null; echo "frozen-batch training (DCFR, 64 deals, every update on 4 threads) exit $?"
  EIGHTMAX_THREAD_CHOICE=fixed "$obj/mwcli" "$X/flop3-kings-compact-batch64.spec.json" 60 4 "$work/k.state" 1024 > /dev/null; echo "frozen-batch training (Compact hand groups, every update on 4 threads) exit $?"
  EIGHTMAX_THREAD_CHOICE=fixed "$obj/mwcli" "$X/flop3-kings-detailed-batch64.spec.json" 30 4 "$work/kd.state" 1024 > /dev/null; echo "frozen-batch training (Detailed hand groups, every update on 4 threads) exit $?"
  EIGHTMAX_THREAD_CHOICE=fixed "$obj/mwcli" "$X/icm8-bb-call-batch64.spec.json" 120 4 "$work/i.state" 1024 > /dev/null; echo "frozen-batch training (ICM, hand groups, every update on 4 threads) exit $?"
  EIGHTMAX_THREAD_CHOICE=fixed "$obj/mwcli" "$X/flop3-kings-compact-batch64.spec.json" 400 4 "$work/m.state" 2 > /dev/null; echo "frozen-batch training stopped by a 2 MiB table budget (4 threads) exit $?"
  "$obj/mwcli" "$X/btn25-open-small-sampled.spec.json" 20000 1 "$work/s.state" 256 > /dev/null
  printf '{"method":"sampled","samples":2000,"selectionSamples":32,"seed":57,"threads":4,"timeLimitMs":900000}' > "$work/qs.json"
  "$obj/mwcli" --gain "$X/btn25-open-small-sampled.spec.json" "$work/s.state" "$work/qs.json" 256 > /dev/null; echo "sampled response gain (4 threads, one path tree per worker) exit $?"
  node "$G" spec bubble4 "$work/d.json" 5 '{"batchDeals":1,"device":"cpu"}' > /dev/null; "$obj/mwcli" "$work/d.json" 3000 1 "$work/d.state" 128 > /dev/null
  printf '{"method":"exact","device":"cpu","threads":4,"timeLimitMs":900000,"maxVisits":2000000000,"memoryMiB":64}' > "$work/q.json"
  "$obj/mwcli" --gain "$work/d.json" "$work/d.state" "$work/q.json" 128 > /dev/null; echo "parallel exact best response (compact tables, path trees, 4 threads) exit $?"; } > "$out/tsan-parallel.log" 2>&1
echo "ThreadSanitizer warnings: $(grep -c 'WARNING: ThreadSanitizer' "$out/tsan-parallel.log")" | tee "$out/tsan-summary.txt"; grep -E 'exit [0-9]+' "$out/tsan-parallel.log" | tee -a "$out/tsan-summary.txt"
python3 "$root/source/tools/study_equivalence55.py" "$work/t1.json" "$work/t2.json" --quiet | tee -a "$out/tsan-summary.txt"
# the thread-sanitized frozen-batch states are the states of the release build (same arithmetic)
for s in b b4 b8; do sha256sum "$work/$s.state" | cut -c1-64; done | sort -u | wc -l | sed 's/^/distinct states of the turn4 frozen-batch trainings under ThreadSanitizer (1 expected): /' | tee -a "$out/tsan-summary.txt"
"$root/build/linux/mwcli" "$X/flop3-kings-compact-batch64.spec.json" 60 1 "$work/k-release.state" 1024 > /dev/null
[ "$(sha256sum < "$work/k.state")" = "$(sha256sum < "$work/k-release.state")" ] && echo "Compact-group state under ThreadSanitizer (4 threads) equals the release build (1 thread): yes" | tee -a "$out/tsan-summary.txt" || echo "Compact-group state under ThreadSanitizer DIFFERS from the release build" | tee -a "$out/tsan-summary.txt"
# 3
ASAN_OPTIONS=detect_leaks=1 "$work/asan/mwcli" --study "$root/studies/known-akq-river.emfix.json" "$work/leak.json" seeds=2 budgets=500 quiet=1 > "$out/leak-study.log" 2>&1; echo "$?" > "$out/leak-study.exit"
ASAN_OPTIONS=detect_leaks=1 EIGHTMAX_THREAD_CHOICE=fixed "$work/asan/mwcli" "$work/b.json" 300 4 "$work/leak.state" 128 > "$out/leak-frozen-batch.log" 2>&1; echo "$?" > "$out/leak-frozen-batch.exit"
echo "leak check exits: study $(cat "$out/leak-study.exit"), frozen-batch training $(cat "$out/leak-frozen-batch.exit")" | tee "$out/leak-summary.txt"; grep -c 'ERROR: LeakSanitizer' "$out/leak-study.log" "$out/leak-frozen-batch.log" | tee -a "$out/leak-summary.txt"
