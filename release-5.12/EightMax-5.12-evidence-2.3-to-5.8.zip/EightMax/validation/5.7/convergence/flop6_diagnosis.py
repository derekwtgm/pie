#!/usr/bin/env python3
"""EightMax 5.7: why the 5.6 equal-time comparison on flop6 was unresolved. Reads the 5.6 raw records
(validation/5.6/convergence/main/raw-merged.jsonl) and writes flop6-diagnosis.json next to this script.
Usage: flop6_diagnosis.py <release root>"""
import json, statistics, math, sys, pathlib
root = pathlib.Path(sys.argv[1]).resolve(); rows = [json.loads(l) for l in (root / 'validation/5.6/convergence/main/raw-merged.jsonl').read_text().splitlines() if l.strip()]
out = {'source': 'validation/5.6/convergence/main/raw-merged.jsonl', 'records': len(rows), 'games': {}}
def sign_p(lo, hi):
    n = lo + hi; k = min(lo, hi); return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n) if n else 1.0
for game in ['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'flop6', 'final8', 'bubble4']:
    g = [r for r in rows if r['game'] == game]; res = {}
    for kind, budget in [('time', 0.1), ('time', 0.5), ('deals', 4000), ('deals', 20000), ('deals', 100000)]:
        a = {r['seed']: r for r in g if r['kind'] == kind and r['budget'] == budget and r['arm'] == 'default56'}; b = {r['seed']: r for r in g if r['kind'] == kind and r['budget'] == budget and r['arm'] == 'baseline55'}
        seeds = sorted(set(a) & set(b)); da = [a[s]['nashConv'] for s in seeds]; db = [b[s]['nashConv'] for s in seeds]; d = [x - y for x, y in zip(da, db)]
        lower, higher = sum(x < 0 for x in d), sum(x > 0 for x in d); sd = statistics.stdev(d); md = statistics.fmean(d)
        qa = sorted(da); q = lambda v, p: v[int(p * (len(v) - 1))]
        # share of the variance of the paired difference carried by the largest tenth of |differences| (outlier seeds)
        sq = sorted((x - md) ** 2 for x in d); top = sum(sq[-max(1, len(sq) // 10):]) / sum(sq) if sum(sq) else 0
        res['%s:%s' % (kind, budget)] = {'pairs': len(seeds), 'mean56': statistics.fmean(da), 'mean55': statistics.fmean(db), 'ratioOfMeans': statistics.fmean(da) / statistics.fmean(db), 'median56': statistics.median(da), 'median55': statistics.median(db),
            'ratioOfMedians': statistics.median(da) / statistics.median(db) if statistics.median(db) else None, 'sd56': statistics.stdev(da), 'sd55': statistics.stdev(db), 'coefficientOfVariation56': statistics.stdev(da) / statistics.fmean(da), 'sdOfPairedDifference': sd,
            'meanDifference': md, 'standardisedEffect': md / sd if sd else None, 'seedsLower': lower, 'seedsHigher': higher, 'signTestP': sign_p(lower, higher), 'meanDeals56': statistics.fmean(a[s]['deals'] for s in seeds), 'meanDeals55': statistics.fmean(b[s]['deals'] for s in seeds),
            'quantiles56': {p: q(qa, p) for p in (0, 0.1, 0.25, 0.5, 0.75, 0.9, 1)}, 'quantiles55': {p: q(sorted(db), p) for p in (0, 0.1, 0.25, 0.5, 0.75, 0.9, 1)}, 'shareOfDifferenceVarianceInTopTenthOfSeeds': top,
            # pairs for the 5.6 primary test (sign test and t interval, Bonferroni over 14) to resolve the measured effect with 80% power, normal approximation of the t interval
            'pairsForTIntervalAt14Tests': math.ceil(((3.19 + 0.84) * sd / abs(md)) ** 2) if md else None,
            'pairsForSignTestAt14Tests': (lambda p: math.ceil(((3.19 * 0.5 + 0.84 * math.sqrt(p * (1 - p))) / abs(p - 0.5)) ** 2) if p != 0.5 else None)(lower / (lower + higher)) if lower + higher else None}
    out['games'][game] = res
(pathlib.Path(__file__).resolve().parent / 'flop6-diagnosis.json').write_text(json.dumps(out, indent=1))
for game, res in out['games'].items():
    c = res['time:0.5']; print(game, 'ratio %.2f' % c['ratioOfMeans'], 'medians %.2f' % (c['ratioOfMedians'] or 0), 'CV %.2f' % c['coefficientOfVariation56'], 'effect/sd %.2f' % c['standardisedEffect'], 'lower/higher %d/%d' % (c['seedsLower'], c['seedsHigher']), 'sign p %.2g' % c['signTestP'], 'pairs needed t %s sign %s' % (c['pairsForTIntervalAt14Tests'], c['pairsForSignTestAt14Tests']), 'top-tenth variance share %.2f' % c['shareOfDifferenceVarianceInTopTenthOfSeeds'], 'deals %d vs %d' % (c['meanDeals56'], c['meanDeals55']))
f = out['games']['flop6']
for k in ('deals:4000', 'deals:20000', 'deals:100000', 'time:0.1', 'time:0.5'): print('flop6', k, 'mean %.4f median %.4f sd %.4f' % (f[k]['mean56'], f[k]['median56'], f[k]['sd56']), 'q', {p: round(v, 3) for p, v in f[k]['quantiles56'].items()})
