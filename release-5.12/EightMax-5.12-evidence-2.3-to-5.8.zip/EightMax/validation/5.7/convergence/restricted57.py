#!/usr/bin/env python3
"""EightMax 5.7: what the restricted and sampled response measures say on games where the exact answer is known.
Usage: restricted57.py <release root> <5.7 mwcli> <out dir> [--seeds N]

Whole-game NashConv cannot be computed for the realistic fixtures; studies of those report a SAMPLED response measure
(one decision per seat may deviate) and the engine also has a RESTRICTED best response (the seat's decisions on the
study's first street may deviate). Both evaluate a fixed alternative strategy of one seat against the trained
strategy. The gain of ANY alternative strategy of a seat is at most the gain of that seat's best response, so
  restricted gain <= exact best-response gain            (exactly, when both are evaluated exactly)
  E[sampled gain]  <= exact best-response gain            (the sampled gain is an unbiased estimate of the gain of the
                                                           alternative it selected on an independent sample stream)
and the sums over seats are lower bounds of NashConv. This script checks the direction on every game small enough for
an exact all-seat best response and measures how much of the exact gain each measure finds (its tightness), at two
training budgets. The plan (games, seeds, budgets, tolerances) is fixed below and written to plan.json first.
Nothing here says how tight the measures are on the large fixtures; it says what they can and cannot show."""
import sys, json, subprocess, pathlib, statistics, time, platform, os, hashlib, argparse
ap = argparse.ArgumentParser(); ap.add_argument('root'); ap.add_argument('cli'); ap.add_argument('out'); ap.add_argument('--seeds', type=int, default=5)
A = ap.parse_args(); root = pathlib.Path(A.root).resolve(); cli = str(pathlib.Path(A.cli).resolve()); out = pathlib.Path(A.out).resolve(); out.mkdir(parents=True, exist_ok=True)
if (out / 'raw.jsonl').exists(): raise SystemExit('Use a fresh output directory.')
GAMES = ['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'flop6', 'final8', 'bubble4', 'flop5', 'flop6w']
BUDGETS = [5000, 50000]; SEEDS = list(range(4001, 4001 + A.seeds))
Q = {'exact': {'method': 'exact', 'device': 'cpu', 'threads': 1, 'timeLimitMs': 1800000, 'maxVisits': 2000000000, 'memoryMiB': 1024},
     'restricted': {'method': 'restricted', 'selection': 'exact', 'device': 'cpu', 'threads': 1, 'timeLimitMs': 1800000, 'maxVisits': 2000000000, 'memoryMiB': 1024},
     'sampled': {'method': 'sampled', 'samples': 200000, 'selectionSamples': 2000, 'seed': 57, 'threads': 1, 'timeLimitMs': 1800000}}
plan = {'games': GAMES, 'seeds': SEEDS, 'budgetsDeals': BUDGETS, 'queries': Q, 'trainer': 'default (one deal per update, one thread)',
        'directionRule': 'restricted gain <= exact gain + 1e-9 for every seat of every state (a violation is a defect of one of the evaluators); sampled gain - 4 standard errors <= exact gain for every seat (a violation beyond that is counted and reported)',
        'tightness': 'sum over seats of the measure divided by exact NashConv, per state; reported as median and range per game and budget',
        'environment': platform.platform(), 'binarySha256': hashlib.sha256(open(cli, 'rb').read()).hexdigest(), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(out / 'plan.json').write_text(json.dumps(plan, indent=1))
def gain(doc):
    r = []
    for s in doc['seats']:
        g = s.get('gain'); r.append((g.get('mean'), g.get('stdErr') or 0.0) if isinstance(g, dict) else (g, 0.0))
    return r
rows = []
for game in GAMES:
    for seed in SEEDS:
        sp = out / 'spec.json'; st = out / 'state'
        subprocess.run(['node', str(root / 'source/tools/games48.js'), 'spec', game, str(sp), str(seed), json.dumps({'batchDeals': 1, 'device': 'cpu'})], check=True, capture_output=True)
        done = 0
        for budget in BUDGETS:
            subprocess.run([cli, str(sp), str(budget - done), '1', str(st) + '.next', '128'] + ([str(st)] if done else []), check=True, capture_output=True); os.replace(str(st) + '.next', st); done = budget
            row = {'game': game, 'seed': seed, 'deals': budget}
            for name, q in Q.items():
                qf = out / 'q.json'; qf.write_text(json.dumps(q)); t = time.perf_counter(); p = subprocess.run([cli, '--gain', str(sp), str(st), str(qf), '128'], capture_output=True, text=True)
                if p.returncode: row[name] = {'error': p.stderr.strip()[-200:]}; continue
                d = json.loads(p.stdout); g = gain(d); row[name] = {'seatGains': [x[0] for x in g], 'seatStdErr': [x[1] for x in g], 'sum': sum(x[0] for x in g if x[0] is not None), 'seconds': time.perf_counter() - t, 'nashConv': d.get('nashConv'), 'mode': d.get('mode')}
            rows.append(row)
            with (out / 'raw.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
    print(game, 'done', flush=True)
for f in ('spec.json', 'state', 'q.json'): (out / f).unlink(missing_ok=True)
summary = {'plan': 'plan.json', 'states': len(rows), 'games': {}}; violR = violS = seatsR = seatsS = 0
for game in GAMES:
    for budget in BUDGETS:
        cell = [r for r in rows if r['game'] == game and r['deals'] == budget]; tr = []; ts = []; vr = vs = 0; errors = []
        for r in cell:
            e = r['exact']
            if 'error' in e: errors.append('exact: ' + e['error']); continue
            for name, acc in (('restricted', tr), ('sampled', ts)):
                m = r[name]
                if 'error' in m: errors.append(name + ': ' + m['error']); continue
                if e['sum'] > 0: acc.append(m['sum'] / e['sum'])
                for i, (g, se) in enumerate(zip(m['seatGains'], m['seatStdErr'])):
                    if g is None: continue
                    if name == 'restricted': seatsR += 1; bad = g > e['seatGains'][i] + 1e-9; vr += bad; violR += bad
                    else: seatsS += 1; bad = g - 4 * se > e['seatGains'][i] + 1e-9; vs += bad; violS += bad
        def stat(v): return {'states': len(v), 'median': statistics.median(v), 'min': min(v), 'max': max(v)} if v else None
        summary['games'].setdefault(game, {})[str(budget)] = {'states': len(cell), 'meanExactNashConv': statistics.fmean(r['exact']['sum'] for r in cell if 'error' not in r['exact']) if cell else None,
            'restrictedShareOfExact': stat(tr), 'sampledShareOfExact': stat(ts), 'restrictedAboveExact': vr, 'sampledAboveExactBy4StdErr': vs, 'errors': sorted(set(errors))}
summary['direction'] = {'restrictedSeatGainsChecked': seatsR, 'restrictedAboveExact': violR, 'sampledSeatGainsChecked': seatsS, 'sampledAboveExactBy4StdErr': violS}
(out / 'summary.json').write_text(json.dumps(summary, indent=1)); print(json.dumps(summary['direction']))
