Stability runs of tools/stability55.js against the desktop host of the final build (Linux).

stability55.json              --minutes=3: 11 of 11 checks passed. Its long training study (check E) ran 140 s:
                              60 checkpoint commits, 56 engine-state writes, 5.06 million sampled deals.
stability55-six-minutes.json  --minutes=6 (the 5.6 setting): 10 of 11. Check E failed.

Why E failed with six minutes, and why it is not a checkpoint defect of 5.7:
  The tool starts a study with a budget of 20,000,000 deals per seed and expects its time limit to stop it. On this
  machine the first four parts of the run took 38 s (5.6's run on its machine: 250 s), which left 322 s for the
  study instead of 110 s, and a seed reached 10,000,000 updates. The engine has a limit of 10 million updates per
  training; the study then ends with
      error 500: variant baseline seed 201: training failed: Iteration count must fit the 10 million iteration limit
  instead of being stopped by its time limit, so the document the tool reads has the counters of a failed study.
  The same command line, 330 s, through mwcli:
      5.7 binary: exit 1, that message                     (after about 4 minutes)
      5.6 binary (unchanged): exit 1, the same message     (after 4 min 3 s)
  With 60 s both binaries make 30 commits and 26 engine-state writes and are stopped by the time limit.
  So: (1) periodic checkpoints work in 5.7 as in 5.6; (2) a study whose budget exceeds 10,000,000 deals per seed
  (one deal per update) fails when a seed gets there, in 5.6 and in 5.7. That is a defect of both versions: the
  budget should be refused when the study starts. It was found here because training is fast enough to reach the
  limit inside a test; it is listed in FINAL-REPORT-5.7.md section 12 and was NOT repaired in 5.7 (the shipped
  fixtures stop at 4,000,000 deals).
