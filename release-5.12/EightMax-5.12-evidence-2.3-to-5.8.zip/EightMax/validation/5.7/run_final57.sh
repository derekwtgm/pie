#!/bin/bash
# The final validation chain on the final 5.7 build. Usage: bash validation/5.7/run_final57.sh <release root> <work dir>
# Logs go to <work dir>; evidence goes to validation/5.7/. Steps run even if an earlier one fails; exit codes are
# recorded in <work dir>/steps.txt. (The benchmarks, the convergence plans and the Wine checks have their own
# commands: see VALIDATION-5.7.md.)
set -u
root=$(cd "$1" && pwd); work=$2; mkdir -p "$work"; cd "$root"; S="$work/steps.txt"; : > "$S"
step() { name=$1; shift; echo "== $name $(date -u +%H:%M:%S)" | tee -a "$S"; "$@" > "$work/$name.log" 2>&1; echo "$name exit $?" | tee -a "$S"; }
T=validation/5.7/tests; mkdir -p "$T"; rm -f "$T"/full-regression.* "$T"/rerun-alone* "$T"/failed-in-full-run.txt
export EM_TEST_MWCLI="$root/build/linux/mwcli" EM_TEST_HOST="$root/build/linux/eightmax"
# 1. the whole regression suite, three test files at a time (as 5.6 ran it)
ASAN_OPTIONS=detect_leaks=0 NODE_OPTIONS="--require=$root/validation/5.3/sanitizers/no-leaks.cjs" \
  node --test --test-concurrency=3 --test-reporter=tap source/tests/*.test.js > "$T/full-regression.tap" 2> "$T/full-regression.stderr"; echo "regression exit $?" | tee -a "$S"
tail -8 "$T/full-regression.tap" | tr '\n' ' ' | tee -a "$S"; echo | tee -a "$S"
# 2. every test that failed in (1) is run again, alone, on the then idle machine; both outcomes are kept
grep '^not ok' "$T/full-regression.tap" | sed 's/^not ok [0-9]* - //' > "$T/failed-in-full-run.txt"
: > "$T/rerun-alone.txt"
while IFS= read -r name; do
  [ -z "$name" ] && continue
  file=$(grep -l -F -- "$(printf '%s' "$name" | cut -c1-60)" source/tests/*.test.js | head -1)
  if [ -z "$file" ]; then for f in source/tests/*.test.js; do node --test --test-reporter=tap "$f" 2>/dev/null | grep -q -F -- "- $name" && { file=$f; break; }; done; fi
  [ -z "$file" ] && { echo "NOT FOUND: $name" >> "$T/rerun-alone.txt"; continue; }
  out="$T/rerun-alone-$(basename "$file" .test.js).tap"
  node --test --test-reporter=tap "$file" > "$out" 2>&1
  if grep -q -F -- "not ok" "$out" && grep -F -- "- $name" "$out" | grep -q '^not ok'; then echo "FAILED AGAIN ALONE ($(basename "$file")): $name" >> "$T/rerun-alone.txt"; else echo "passed alone ($(basename "$file")): $name" >> "$T/rerun-alone.txt"; fi
done < "$T/failed-in-full-run.txt"
cat "$T/rerun-alone.txt" | tee -a "$S"
# 3. (The retry rule of tools/run_tests.js, which the Windows workflow uses, was exercised on a synthetic test file:
#    validation/5.7/tests/retry-rule-check.txt. The suite itself is run by (1) and (2).)
# 4. sanitizers
step sanitizers bash validation/5.7/sanitize57.sh . "$work/san"
cat validation/5.7/sanitizers/tsan-summary.txt validation/5.7/sanitizers/sanitizer-report-counts.txt validation/5.7/sanitizers/leak-summary.txt 2>/dev/null | tee -a "$S"
# 5. the Study tab driven in a browser, and the stability run against the desktop host
rm -rf validation/5.7/ui; mkdir -p validation/5.7/ui; step ui node source/tools/study_ui56.js build/linux/eightmax . validation/5.7/ui; rm -f validation/5.7/ui/reference.json
rm -rf validation/5.7/stability; step stability node source/tools/stability55.js build/linux/eightmax . validation/5.7/stability --minutes=6
echo "== done $(date -u +%H:%M:%S)" | tee -a "$S"
