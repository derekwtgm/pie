#!/usr/bin/env python3
"""Writes PERFORMANCE-5.7.md from the evidence in validation/5.7/performance. Usage: write_performance.py <release root>"""
import json, sys, pathlib, statistics
root = pathlib.Path(sys.argv[1]).resolve(); P = root / 'validation/5.7/performance'
thr = json.loads((P / 'threads.json').read_text()); tb = json.loads((P / 'trainbench/summary.json').read_text()); ev = json.loads((P / 'evaluation/summary.json').read_text()); st = json.loads((P / 'studies/summary.json').read_text())
info = json.loads((root / 'BUILD-INFO.json').read_text()) if (root / 'BUILD-INFO.json').exists() else json.loads((root / 'build/build-info.json').read_text())
rows = thr['rows']; games = []
for r in rows:
    if r['game'] not in games: games.append(r['game'])
cell = lambda g, arm, t: next(r for r in rows if r['game'] == g and r['arm'] == arm and r['threads'] == t)
m = lambda r: r['dealsPerSecondMedian']
NAMES = {'flop6w': 'six-player flop, weighted ranges (small game)', 'final8w': 'eight-handed ICM final table (small game)', 'turn4': 'four-player turn (small game)', 'flop5': 'five-player flop (small game)',
         'flop6-jack': 'six-player flop fixture', 'flop3-kings': 'three-player flop fixture', 'btn25-open': 'three-player preflop fixture', 'icm8-bb-call': 'eight-handed ICM fixture', 'flop3-kings-detailed': 'three-player flop fixture, Detailed hand groups'}
L = []; w = L.append
w('# Performance — EightMax 5.7 against 5.6'); w('')
w('Build `%s`. Every number on this page was measured with the final Linux build of 5.7 and the unchanged 5.6 Linux binary (sha256 `%s`), rebuilt from the 5.6 source and byte-identical to the one shipped in 5.6.' % (info['build'], thr['old'][:16] + '…'))
w('')
w('**Conditions.** %s, %d logical processors, 16 GB, a shared cloud virtual machine: **not** the target Windows PC (13th-generation Core i7, RTX 4060 Ti). Nothing else ran beside a measurement. Run-to-run variation on this machine is large (the same single-thread training differs by up to 10%% between repetitions), so every comparison alternates the two binaries and reports medians; differences of a few percent are not findings. No number here says how fast the program is on another machine, and no GPU was involved.' % (thr['cpu'], thr['logicalProcessors']))
w(''); w('Raw data: `validation/5.7/performance/` (`threads.json`, `trainbench/`, `evaluation/`, `studies/`; every repetition is kept). Tools: `source/tools/threads57.py`, `trainbench56.py`, `evalbench57.py`, `studybench57.py`.'); w('')
w('## 1. Summary'); w('')
t4 = [m(cell(g, 'new', 4)) / m(cell(g, 'old', 4)) for g in games]; t4f = [m(cell(g, 'new-fixed', 4)) / m(cell(g, 'old', 4)) for g in games]
sc57 = [m(cell(g, 'new-fixed', 4)) / m(cell(g, 'new-fixed', 1)) for g in games]; sc56 = [m(cell(g, 'old', 4)) / m(cell(g, 'old', 1)) for g in games]
one = [f['speedupMedian'] for f in tb['fixtures']]
samp = [c for c in ev['cases'] if c['kind'].startswith('sampled')]; exact = [c for c in ev['cases'] if c['kind'] == 'exact']
studies = [s for s in st['studies'] if not s.get('error')]
w('| What | 5.7 against 5.6 | Results |'); w('|---|---|---|')
w('| Training, one deal per update, one thread (how a study trains a seed) | %.2fx to %.2fx, median %.2fx: **unchanged** (this path was not modified; the spread is machine noise) | state files byte-identical in %d of %d fixtures |' % (min(one), max(one), statistics.median(one), sum(f['stateIdentical'] for f in tb['fixtures']), len(tb['fixtures'])))
w('| Training, frozen batches (64 deals per update), 4 threads offered, measured thread choice | **%.2fx to %.2fx** faster, median %.2fx | state files byte-identical for every thread count |' % (min(t4), max(t4), statistics.median(t4)))
w('| The same with every update forced onto 4 threads | %.2fx to %.2fx, median %.2fx | identical |' % (min(t4f), max(t4f), statistics.median(t4f)))
w('| Gain from 1 to 4 threads within one version | 5.7: %.2fx to %.2fx (median %.2fx); 5.6: %.2fx to %.2fx (median %.2fx) | |' % (min(sc57), max(sc57), statistics.median(sc57), min(sc56), max(sc56), statistics.median(sc56)))
w('| Sampled evaluation (response gains and action EVs), one thread | **%.2fx to %.2fx** faster, median %.2fx (time reduced by %d%% to %d%%) | every reported number identical in %d of %d cases |' % (min(c['speedupMedian'] for c in samp), max(c['speedupMedian'] for c in samp), statistics.median(c['speedupMedian'] for c in samp), round(100 * (1 - 1 / min(c['speedupMedian'] for c in samp))), round(100 * (1 - 1 / max(c['speedupMedian'] for c in samp))), sum(c['identicalResults'] for c in samp), len(samp)))
w('| Exact evaluation (all-seat best response) | %.2fx to %.2fx, median %.2fx | identical in %d of %d cases |' % (min(c['speedupMedian'] for c in exact), max(c['speedupMedian'] for c in exact), statistics.median(c['speedupMedian'] for c in exact), sum(c['identicalResults'] for c in exact), len(exact)))
w('| Complete studies, 4 threads | wall time %.2fx to %.2fx, median %.2fx | every per-seed measurement identical in %d of %d studies |' % (min(s['wallRatio56Over57'] for s in studies), max(s['wallRatio56Over57'] for s in studies), statistics.median(s['wallRatio56Over57'] for s in studies), sum(s['identicalMeasurements'] for s in studies), len(studies)))
w('')
w('## 2. Why several threads did not help in 5.6 (profile)'); w('')
w('5.6 traversed the deals of a frozen batch on several threads and did everything else on the calling thread. Measured on the 5.6 binary (`threads.json`, arm `old`, stage seconds the engine reports):'); w('')
w('| Game | Threads | deal stage s | traverse s | merge s | wall s (median) |'); w('|---|---|---|---|---|---|')
for g in ['turn4', 'flop6-jack', 'btn25-open', 'icm8-bb-call']:
    for t in (1, 2, 4):
        r = cell(g, 'old', t); s = r['seconds']; w('| %s | %d | %.3f | %.3f | %.3f | %.3f |' % (g, t, s['deal'], s['traverse'], s['merge'], r['medianSeconds']))
w('')
w('Four causes were found and measured during development (`validation/5.7/profile/`, and the stage seconds above):'); w('')
w('1. **Waking the helpers.** One batch of 64 deals is 100 to 1,500 microseconds of traversal. 5.6 woke its helper threads through a condition variable for every batch and put them back to sleep; that costs tens of microseconds per thread. With the 5.6 update unchanged and only the pool replaced (arm `new-legacy` in the development runs, `validation/5.7/performance-development/`), 4 threads went from 0.58 s to 0.49 s on the six-player game and from 0.69 s to 0.53 s on the four-player turn game.')
w('2. **Deals moving between processors.** 5.6 handed deals to whichever thread asked next, so a deal\'s buffers were written by a different processor in almost every batch and each cache line had to be fetched from another core. With each thread keeping its own contiguous share of the deals (and taking leftover deals only when it is done), the traversal stage of the six-player game went from 0.62 s to 0.48 s with 2 threads and from 0.37 s to 0.26 s with 4.')
w('3. **Serial preparation.** Sampling the deals, scoring the showdown hands and computing the hand-group keys ran on one thread: 9% to 71% of single-thread time on the fixtures (see the deal column above; the eight-handed ICM fixture spends most of its time there). 5.7 keeps only the deal sampling and the interning of keys that are new to the dictionary in order.')
w('4. **Serial merge, reading other processors\' caches.** The merge was 4% to 18% of single-thread time and grew with the thread count (the increments lie in the other processors\' caches). 5.7 creates new states and rows in order and adds the increments on all threads, partitioned by table row.')
w('')
w('What still does not scale: sampling the deals (one random stream, consumed in order), creating new betting states and table rows (their identifiers are assigned in deal order, which is what makes the saved state independent of the thread count), and reading the table rows that another thread has just updated. On a table that is still growing fast these are a large share (three-player preflop fixture: `resolve` below).'); w('')
w('## 3. Frozen-batch training, 1, 2 and 4 threads'); w('')
w('64 deals per update, per-deal action streams (the mode in which one training uses several threads); %d repetitions per cell, alternating order, **median** sampled deals per second. "5.7 fixed": every update on all threads offered. "5.7": the measured thread choice (the count it settled on is in brackets).' % thr['repetitions']); w('')
w('| Game | Version | 1 thread | 2 threads | 4 threads | 4 threads / 1 thread | 5.7 / 5.6 at 4 threads | Same state |'); w('|---|---|---|---|---|---|---|---|')
for g in games:
    for arm, label in (('old', '5.6'), ('new-fixed', '5.7 fixed'), ('new', '5.7')):
        c = [cell(g, arm, t) for t in (1, 2, 4)]; ch = ' [%s]' % (c[2]['threadChoice'] or {}).get('selected') if arm == 'new' else ''
        w('| %s | %s | %s | %s | %s%s | %.2fx | %s | %s |' % (NAMES.get(g, g) if arm == 'old' else '', label, format(round(m(c[0])), ','), format(round(m(c[1])), ','), format(round(m(c[2])), ','), ch, m(c[2]) / m(c[0]), '' if arm == 'old' else '**%.2fx**' % (m(c[2]) / m(cell(g, 'old', 4))), 'yes' if all(r['identicalStates'] for r in rows if r['game'] == g) else '**NO**'))
w('')
w('At one thread the frozen-batch update of 5.7 is %.2fx to %.2fx the speed of 5.6 (median %.2fx): the stages are separate passes over the deals, which costs a few percent on the smallest games and saves a little where key computation dominates.' % (min(m(cell(g, 'new-fixed', 1)) / m(cell(g, 'old', 1)) for g in games), max(m(cell(g, 'new-fixed', 1)) / m(cell(g, 'old', 1)) for g in games), statistics.median(m(cell(g, 'new-fixed', 1)) / m(cell(g, 'old', 1)) for g in games)))
w('')
w('**Stages of the 5.7 update** (seconds over the whole run, every update on the stated number of threads; `deal`, `fixup` and `resolve` are serial):'); w('')
w('| Game | Threads | deal | prepare | fixup | traverse | resolve | accumulate | apply | deals whose keys were interned in order |'); w('|---|---|---|---|---|---|---|---|---|---|')
for g in games:
    for t in (1, 4):
        b = cell(g, 'new-fixed', t)['batchStages']; w('| %s | %d | %.3f | %.3f | %.3f | %.3f | %.3f | %.3f | %.3f | %s |' % (g, t, b['deal'], b['prepare'], b['fixup'], b['traverse'], b['resolve'], b['accumulate'], b['apply'], format(b['dealsPreparedInOrder'], ',')))
w('')
w('**Thread choice.** With the measured choice, every run above that was offered 4 threads settled on %s. The choice is made from seconds per state visit of whole updates and is re-measured as training goes on; it never changes a result. On a machine where fewer threads are faster it settles on fewer (the in-engine check `mwcli --selftest57` drives it with synthetic costs).' % (', '.join(sorted(set(str((cell(g, 'new', 4)['threadChoice'] or {}).get('selected')) for g in games))) + ' threads'))
w('')
w('**Memory.** Peak resident memory of these runs: ' + '; '.join('%s %.0f MiB (5.6) / %.0f MiB (5.7)' % (g, cell(g, 'old', 4)['peakRssMiB'] or 0, cell(g, 'new-fixed', 4)['peakRssMiB'] or 0) for g in ['flop6-jack', 'btn25-open', 'flop3-kings-detailed']) + '. The new per-thread structures (touched-row lists, hand-group keys of the 64 deals, the deal queue) are a few kilobytes to a few megabytes and are outside the table budget, whose accounting is unchanged.')
w('')
w('## 4. Training, one deal per update, one thread'); w('')
w('`trainbench56.py` with the 5.6 binary as baseline: %d sampled deals, %d repetitions. This is how a study trains each seed; 5.7 did not change this path, and the table is here to show that it did not get slower.' % (tb['plan']['deals'], tb['plan']['repetitions'])); w('')
w('| Fixture | 5.6 deals/s (best) | 5.7 deals/s (best) | Ratio (best) | Ratio (median) | Peak RSS MiB 5.6 / 5.7 | Same state |'); w('|---|---|---|---|---|---|---|')
for f in tb['fixtures']: w('| %s | %s | %s | %.2fx | %.2fx | %.0f / %.0f | %s |' % (f['fixture'], format(round(f['v55']['dealsPerSecondBest']), ','), format(round(f['v56']['dealsPerSecondBest']), ','), f['speedupBest'], f['speedupMedian'], f['v55']['peakRssMiB'], f['v56']['peakRssMiB'], 'yes' if f['stateIdentical'] else '**NO**'))
w(''); w('(The JSON keys `v55`/`v56` in `trainbench/summary.json` are the tool\'s names for "baseline" and "current": here 5.6 and 5.7.)'); w('')
w('## 5. Evaluation'); w('')
w('The same trained state (both binaries write the same one; checked for every case), the same query, one evaluation thread, %d repetitions, alternating. Wall seconds of the whole process, median.' % ev['environment']['repetitions']); w('')
w('| Case | 5.6 s | 5.7 s | Speed-up | Time saved | Results |'); w('|---|---|---|---|---|---|')
for c in ev['cases']: w('| %s | %.2f | %.2f | **%.2fx** | %d%% | %s |' % (c['case'], c['v56']['medianSeconds'], c['v57']['medianSeconds'], c['speedupMedian'], round(100 * (1 - 1 / c['speedupMedian'])), 'identical (%d numbers)' % c['numbersCompared'] if c['identicalResults'] else 'largest relative difference %.2g' % (c['largestRelativeDifference'] or 0)))
w('')
w('**What was found.** A profile of a sampled response gain on the three-player flop fixture (callgrind, `validation/5.7/profile/`): 28% of the instructions rebuilt betting states (`Rules::advance` / `Rules::build`), 23% recomputed pot layouts at terminals (`Rules::pots`), about 10% computed the card code of the board with `std::sort` for every strategy lookup, about 10% was coverage bookkeeping, and 5% copied 440-byte betting states. A betting state depends only on its action path and a pot layout only on its terminal state, yet both were rebuilt on every visit. The trainer had kept such records since 3.8 and 5.6; the evaluators had not.')
w('')
w('**What was changed.** Each evaluator keeps the part of the betting tree it has walked (`PathTree`, `action_ev.hpp`): a node is built once, by the same rules calls, and read afterwards, including the pot layout of terminals. The tree is private to one evaluator thread, bounded by 1/64 of the evaluator memory (256 KiB to 8 MiB), and a node that does not fit is rebuilt as before. The card code uses a three-element sorting network and written-out binomials (compared with the 5.6 function for every flop in every order). Instructions of the profiled case fell from 12.3 to 6.7 billion with the tree alone.')
w('')
w('**What was not changed.** The sampling: the same random streams, the same draws, the same order of every floating-point operation. That is why the results are identical and not merely close, and why no statistical re-validation of the estimators was needed. The gains are largest where the betting tree below the decision is walked in full for every sample (the small games with two bet sizes) and smallest where a sample is dominated by showdown scoring. Coverage bookkeeping and showdown scoring were left alone. Exact evaluation gains little because 5.6 had already removed its dominant costs (showdown tables, passive runouts).')
w('')
w('Sampled estimators against exact values: on the games small enough for an exact best response, the sampled response measure stayed below the exact gain in every case checked and found a share of it that varies widely by game (CONVERGENCE-5.7.md, section 5). A faster evaluator does not make that measure tighter.'); w('')
w('## 6. Complete studies'); w('')
w('The eight studies of the 5.6 report, identical options, %d threads, %d run per binary (alternating order). "Evaluation" is the sum of action-EV and quality seconds over the study\'s points.' % (st['environment']['threadsRequested'], st['environment']['repetitions'])); w('')
w('| Study | Wall s 5.6 | Wall s 5.7 | Ratio | Training s 5.6 / 5.7 | Evaluation s 5.6 / 5.7 | Evaluation ratio | Peak RSS MiB 5.6 / 5.7 | Per-seed measurements |'); w('|---|---|---|---|---|---|---|---|---|')
for s in st['studies']:
    if s.get('error'): w('| %s | failed | | | | | | | |' % s['study']); continue
    a, b = s['v56'], s['v57']; w('| %s | %.2f | %.2f | **%.2fx** | %.1f / %.1f | %.1f / %.1f | %s | %.0f / %.0f | %s |' % (s['study'], a['wallSeconds'], b['wallSeconds'], s['wallRatio56Over57'], a['trainingSeconds'], b['trainingSeconds'], a['evSeconds'] + a['qualitySeconds'], b['evSeconds'] + b['qualitySeconds'], '%.2fx' % s['evaluationRatio56Over57'] if s['evaluationRatio56Over57'] else 'n/a', a['peakRssMiB'] or 0, b['peakRssMiB'] or 0, 'identical (%d points, %d numbers)' % (s['measurementPoints'], s['numbersCompared']) if s['identicalMeasurements'] else 'largest relative difference %.2g' % (s['largestRelativeDifference'] or 0)))
w('')
rp = P / 'studies-small-repeated/summary.json'
if rp.exists():
    r2 = json.loads(rp.read_text()); w('The four studies that take about a second were measured again with %d repetitions per binary, alternating (best of %d): ' % (r2['environment']['repetitions'], r2['environment']['repetitions']) + '; '.join('%s %.2f s / %.2f s (%.2fx)' % (x['study'], x['v56']['wallSeconds'], x['v57']['wallSeconds'], x['wallRatio56Over57']) for x in r2['studies'] if not x.get('error')) + '. A single run of a study this short moves by 10% to 30% on this machine.'); w('')
w('The two large sampled studies that 5.6 could not speed up (three-player flop and eight-handed ICM: 0.98x and 1.00x against 5.5) are the ones that gain here, because their time is sampled evaluation. Checkpoint overhead: these runs used `checkpoint=off`, as the 5.6 measurements did; the checkpoint code is unchanged in 5.7 (recovery tests: VALIDATION-5.7.md).'); w('')
w('## 7. Targets'); w('')
w('| Target | Result |'); w('|---|---|')
w('| Meaningful multithreading improvement on representative larger workloads | Met on this machine: %.2fx to %.2fx over 5.6 at 4 threads on the five study fixtures; 1 to 4 threads now gives %.2fx to %.2fx. Not proportional to the thread count: sections 2 and 3 say what remains serial. Unmeasured on the target CPU. |' % (min(m(cell(g, 'new', 4)) / m(cell(g, 'old', 4)) for g in games[4:]), max(m(cell(g, 'new', 4)) / m(cell(g, 'old', 4)) for g in games[4:]), min(sc57), max(sc57)))
w('| At least 20%% less sampled-evaluation time | Met: %d%% to %d%% less in the %d sampled cases. |' % (round(100 * (1 - 1 / min(c['speedupMedian'] for c in samp))), round(100 * (1 - 1 / max(c['speedupMedian'] for c in samp))), len(samp)))
w('| No unexplained mathematical differences | None found: states byte-identical, evaluations and study measurements identical. |')
w('| No material regression in complete-study performance | Lowest study ratio %.2fx (%s). |' % (min(s['wallRatio56Over57'] for s in studies), min(studies, key=lambda s: s['wallRatio56Over57'])['study']))
w('| Deterministic checkpoint recovery preserved | Yes (VALIDATION-5.7.md). |')
w('')
w('## 8. Regressions and limits'); w('')
low = [c for c in ev['cases'] if c['speedupMedian'] < 0.97] + [f for f in tb['fixtures'] if f['speedupMedian'] < 0.95]
w('- Cells below 1.00x (median; best-of-repetitions ratio in brackets): ' + ('; '.join(('%s %.2fx [%.2fx]' % (c.get('case') or c.get('fixture'), c['speedupMedian'], c['speedupBest'])) for c in low) + '. The single-thread training path and the exact evaluator of these cases execute the same code as 5.6 apart from the path tree; the best-of-three ratios of the same cases scatter on both sides of 1.00, which is this machine\'s noise, not a measured slowdown. Treat any ratio between 0.9x and 1.1x on this page as "no difference shown".' if low else 'none.'))
w('- Frozen-batch training at one thread is up to %d%% slower than 5.6 on the smallest games (section 3). Frozen batches are meant for several threads; a study trains with one deal per update.' % round(100 * (1 - min(m(cell(g, 'new-fixed', 1)) / m(cell(g, 'old', 1)) for g in games))))
w('- Helper threads poll for up to 200 microseconds after their last piece of work before they sleep. On a machine with fewer free processors than threads offered this wastes processor time; the measured thread choice then settles on fewer threads, but the first updates of a call pay for it.')
w('- Two threads gain less than four on some games (the caller and one helper share the serial stages between them); the thread choice measures 4, 2 and 1 and keeps the fastest.')
w('- No measurement with more than 4 threads exists. The target CPU has 8 performance and 8 efficiency cores; nothing was tuned for that layout.')
w('- No GPU measurement of any kind. No CUDA code changed in 5.7.')
(root / 'PERFORMANCE-5.7.md').write_text('\n'.join(L) + '\n'); print('written', len(L), 'lines')
