#!/usr/bin/env python3
"""Writes CONVERGENCE-5.7.md from validation/5.7/convergence (main, flop6, restricted, flop6-diagnosis.json).
Usage: write_convergence.py <release root>"""
import json, sys, pathlib, statistics
root = pathlib.Path(sys.argv[1]).resolve(); C = root / 'validation/5.7/convergence'
load = lambda p: json.loads((C / p).read_text())
main, mplan = load('main/analysis.json'), load('main/plan.json'); f6, fplan = load('flop6/analysis.json'), load('flop6/plan.json'); rs, rplan = load('restricted/summary.json'), load('restricted/plan.json'); dg = load('flop6-diagnosis.json')
info = json.loads((root / 'BUILD-INFO.json').read_text()) if (root / 'BUILD-INFO.json').exists() else json.loads((root / 'build/build-info.json').read_text())
ROLE = {'hu-river': 'heads-up river', 'hu-turn': 'heads-up turn and river', 'river3-chip': 'three-player river, side pots', 'turn4': 'four-player turn and river', 'flop6': 'six-player flop, all-in or fold', 'final8': 'eight-handed ICM final table', 'bubble4': 'four-player ICM bubble', 'flop5': 'five-player flop', 'flop6w': 'six-player flop, weighted ranges, two bet sizes'}
L = []; w = L.append
def fmt(x, d=4): return 'n/a' if x is None else ('%.' + str(d) + 'f') % x
def row(c): return '%s / %s / %s' % (c.get('seedsLower'), c.get('seedsHigher'), c.get('seedsEqual'))
w('# Convergence — EightMax 5.7 against 5.6'); w('')
w('Build `%s`. Raw data, plans and analyses: `validation/5.7/convergence/` (`main/`, `flop6/`, `restricted/`, `pilot/`, `flop6-diagnosis.json`). Runner: `source/tools/research57.py`; every plan was written to `plan.json` before its first measurement, every row of `raw.jsonl` is kept, and nothing was stopped or selected on results.' % info['build']); w('')
w('**What 5.7 changed and what it did not.** The default trainer (one deal per update) is the 5.6 trainer: same estimator, same code path. Frozen-batch training (several deals per update against a frozen strategy, the mode that uses several threads) computes what 5.6 computed and does it faster on several threads. No new estimator was written. So the questions for this release are (a) is anything different at equal sampled deals (it must not be), (b) does the faster parallel mode get closer to equilibrium in the same wall-clock time than 5.6\'s, (c) is it closer than the default trainer, which would be a reason to change the default, and (d) the 5.6 result that was left unresolved on the six-player flop game.'); w('')
w('NashConv below is exact inside each game\'s abstraction (an all-seat best response by the 5.7 evaluator, whose values equal 5.6\'s). With more than two players it is not exploitability, and reaching zero does not make a strategy unbeatable by coalitions.'); w('')
# ---- main plan
P = mplan; big = 'time:%s' % P['trainingSeconds'][-1]; small = 'time:%s' % P['trainingSeconds'][0]; dk = 'deals:%s' % P['deals'][0]
w('## 1. Plan (written before measurement)'); w('')
w('- Games: %s.' % ', '.join('%s (%s)' % (g, ROLE[g]) for g in P['games']))
w('- Paired seeds: %d (%d to %d), not used by any earlier release. A one-seed pilot (seed 901) checked that every arm runs; it is kept in `pilot/` and not analysed.' % (len(P['seeds']), P['seeds'][0], P['seeds'][-1]))
w('- Arms: ' + '; '.join('`%s` (%s binary, %s, %d thread%s offered)' % (a, v['binary'], 'frozen batches of 64 deals with per-deal action streams' if v['trainerOptions'].get('batchDeals', 1) > 1 else 'default trainer', v['threadsOffered'], '' if v['threadsOffered'] == 1 else 's') for a, v in P['arms'].items()) + '.')
w('- Budgets: %s sampled deals; %s seconds of wall-clock training. Table budget %d MiB. Arms of a seed run one after another in rotated order, one process at a time.' % (', '.join(format(d, ',') for d in P['deals']), ' and '.join(str(s) for s in P['trainingSeconds']), P['memoryMiB']))
w('- Evaluation: %s.' % P['evaluation'])
w('- Identity rule: %s' % P['identityRule'])
w('- Primary metric: %s. Family: %s.' % (P['primaryMetric'], P['primaryFamily']))
w('- Tests: %s.' % P['tests'])
w('- Stopping rule: %s.' % P['stoppingRule'])
w('- Promotion rule: %s' % P['promotionRule'])
w('- Limitations stated in the plan: %s' % P['limitations']); w('')
w('Rows produced: %d of %d planned.' % (main['rows'], len(P['games']) * len(P['seeds']) * len(P['arms']) * (len(P['deals']) + len(P['trainingSeconds'])))); w('')
w('## 2. Equal sampled deals: are the updates the same?'); w('')
w('| Game | default57 vs default56: identical checkpoint files | batch57t4 vs batch56t4: identical checkpoint files | NashConv at %s deals: default / frozen batches (mean) |' % format(P['deals'][0], ',')); w('|---|---|---|---|')
allid = True
for g in P['games']:
    c = main['games'][g][dk]; a = c['contrasts']['default57 vs default56']; b = c['contrasts']['batch57t4 vs batch56t4']; allid &= a['identicalCheckpointFiles'] == a['checkpointPairs'] and b['identicalCheckpointFiles'] == b['checkpointPairs']
    w('| %s | %d of %d | %d of %d | %s / %s |' % (g, a['identicalCheckpointFiles'], a['checkpointPairs'], b['identicalCheckpointFiles'], b['checkpointPairs'], fmt(c['arms']['default57']['meanNashConv']), fmt(c['arms']['batch57t4']['meanNashConv'])))
w('')
w(('**Every checkpoint file is identical.** ' if allid else '**NOT every checkpoint file is identical: a defect.** ') + 'At equal sampled deals 5.7 is 5.6, for the default trainer and for frozen batches on four threads. (Frozen batches and the default trainer differ from each other at equal deals by design: 64 deals share one strategy update.)'); w('')
def contrast_table(cells, name, title):
    w('| Game | %s | NashConv candidate / reference (mean) | Ratio of means | Seeds lower / higher / equal | Sign test p (Bonferroni) | t interval of the difference (Bonferroni) | Verdict |' % title); w('|---|---|---|---|---|---|---|---|')
    for g, c, deals in cells:
        k = c['contrasts'][name]; w('| %s | %s | %s / %s | %.2f | %s | %s | %s | **%s** |' % (g, deals, fmt(k['meanCandidate']), fmt(k['meanReference']), k['ratioOfMeans'], row(k), ('%.2g' % k['signTestPBonferroni']) if 'signTestPBonferroni' in k else 'n/a', ('[%s, %s]' % (fmt(k['tIntervalBonferroni'][0]), fmt(k['tIntervalBonferroni'][1]))) if 'tIntervalBonferroni' in k else 'n/a', k['verdict']))
    w('')
def deals_of(c, a, b): return '%s / %s' % (format(round(c['arms'][a]['meanDeals']), ','), format(round(c['arms'][b]['meanDeals']), ','))
w('## 3. Equal wall-clock time'); w('')
w('### 3.1 Q1 — 5.7 frozen batches on four threads against 5.6 frozen batches on four threads (primary, %s s)' % P['trainingSeconds'][-1]); w('')
contrast_table([(g, main['games'][g][big], deals_of(main['games'][g][big], 'batch57t4', 'batch56t4')) for g in P['games']], 'batch57t4 vs batch56t4', 'Sampled deals in %s s, 5.7 / 5.6' % P['trainingSeconds'][-1])
q1 = [main['games'][g][big]['contrasts']['batch57t4 vs batch56t4']['verdict'] for g in P['games']]
w('Verdicts: %s. ' % ', '.join('%s %s' % (g, v) for g, v in zip(P['games'], q1)) + 'At %s s: %s.' % (P['trainingSeconds'][0], ', '.join('%s %s (ratio %.2f)' % (g, main['games'][g][small]['contrasts']['batch57t4 vs batch56t4']['verdict'], main['games'][g][small]['contrasts']['batch57t4 vs batch56t4']['ratioOfMeans']) for g in P['games']))); w('')
split = [g for g in P['games'] if main['games'][g][big]['contrasts']['batch57t4 vs batch56t4']['verdict'] == 'unresolved' and main['games'][g][big]['contrasts']['batch57t4 vs batch56t4'].get('signTestPBonferroni', 1) < 0.05]
if split: w('In %s the sign test alone is significant after the adjustment (%s) and the t interval is not: a few seeds with a large NashConv dominate the variance of the differences. The rule set in advance needs both tests, so these are reported as unresolved, not as improvements.' % (', '.join(split), '; '.join('%s: %d of %d seeds lower' % (g, main['games'][g][big]['contrasts']['batch57t4 vs batch56t4']['seedsLower'], main['games'][g][big]['contrasts']['batch57t4 vs batch56t4']['pairs']) for g in split))); w('')
w('### 3.2 Q2 — 5.7 frozen batches on four threads against the default trainer on one thread (primary, %s s)' % P['trainingSeconds'][-1]); w('')
contrast_table([(g, main['games'][g][big], deals_of(main['games'][g][big], 'batch57t4', 'default57')) for g in P['games']], 'batch57t4 vs default57', 'Sampled deals in %s s, frozen batches / default' % P['trainingSeconds'][-1])
q2 = [main['games'][g][big]['contrasts']['batch57t4 vs default57']['verdict'] for g in P['games']]
w('Verdicts: %s. ' % ', '.join('%s %s' % (g, v) for g, v in zip(P['games'], q2)) + 'At %s s: %s.' % (P['trainingSeconds'][0], ', '.join('%s %s (ratio %.2f)' % (g, main['games'][g][small]['contrasts']['batch57t4 vs default57']['verdict'], main['games'][g][small]['contrasts']['batch57t4 vs default57']['ratioOfMeans']) for g in P['games']))); w('')
w('### 3.3 Descriptive contrasts (%s s; same penalty, not claimed)' % P['trainingSeconds'][-1]); w('')
contrast_table([(g, main['games'][g][big], deals_of(main['games'][g][big], 'default57', 'default56')) for g in P['games']], 'default57 vs default56', 'Sampled deals, 5.7 default / 5.6 default')
w('The default trainer of 5.7 is the default trainer of 5.6; this contrast measures the noise of an equal-time comparison between two programs doing the same work on this machine. Any verdict other than "unresolved" here would be a warning about the method.'); w('')
contrast_table([(g, main['games'][g][big], deals_of(main['games'][g][big], 'batch56t4', 'default56')) for g in P['games']], 'batch56t4 vs default56', 'Sampled deals, 5.6 frozen batches / 5.6 default')
w('### 3.4 Decision'); w('')
better2 = [g for g, v in zip(P['games'], q2) if v == 'better']; worse2 = [g for g, v in zip(P['games'], q2) if v == 'worse']
w('- **Q1.** 5.7\'s parallel training is closer to equilibrium than 5.6\'s after the same %s s in: %s. Not resolved in: %s. Worse in: %s.' % (P['trainingSeconds'][-1], ', '.join(g for g, v in zip(P['games'], q1) if v == 'better') or 'no game', ', '.join(g for g, v in zip(P['games'], q1) if v == 'unresolved') or 'none', ', '.join(g for g, v in zip(P['games'], q1) if v == 'worse') or 'none'))
w('- **Q2 and the promotion rule.** Frozen batches on four threads are better than the default trainer in: %s; worse in: %s; unresolved in: %s. The rule requires "better" in every game: it is **%s**. %s' % (', '.join(better2) or 'no game', ', '.join(worse2) or 'none', ', '.join(g for g, v in zip(P['games'], q2) if v == 'unresolved') or 'none', 'met' if len(better2) == len(P['games']) else 'not met',
  'Frozen-batch training becomes the default.' if len(better2) == len(P['games']) else '**The default trainer is unchanged.** Frozen-batch training stays an option (`batchDeals`, `actionStreams: "deal"`).'))
w('- No new training algorithm was promoted. An unresolved contrast is reported as unresolved and is not a result.'); w('')
# ---- flop6
F = fplan; fb = 'time:%s' % F['trainingSeconds'][-1]; fs = 'time:%s' % F['trainingSeconds'][0]; d6 = dg['games']['flop6']['time:0.5']
w('## 4. The six-player flop game (unresolved in 5.6)'); w('')
w('### 4.1 Why 5.6 did not resolve it'); w('')
w('From the 5.6 raw records (`flop6_diagnosis.py`, `flop6-diagnosis.json`). 5.6 trained %s deals in 0.5 s against %s for 5.5; the mean NashConv ratio was %.2f and %d of 60 seeds were lower, %d higher.' % (format(round(d6['meanDeals56']), ','), format(round(d6['meanDeals55']), ','), d6['ratioOfMeans'], d6['seedsLower'], d6['seedsHigher'])); w('')
w('| Game (5.6 against 5.5, 0.5 s, 60 pairs) | Ratio of means | Mean difference / its standard deviation | Seeds lower / higher | Pairs the 5.6 tests needed for 80% power at the measured effect (t interval / sign test) |'); w('|---|---|---|---|---|')
for g in ['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'flop6', 'final8', 'bubble4']:
    c = dg['games'][g]['time:0.5']; w('| %s | %.2f | %.2f | %d / %d | %s / %s |' % (g, c['ratioOfMeans'], c['standardisedEffect'], c['seedsLower'], c['seedsHigher'], c['pairsForTIntervalAt14Tests'], c['pairsForSignTestAt14Tests']))
w('')
w('- **Variance between seeds, relative to the effect.** On flop6 the mean improvement was %.2f standard deviations of the paired difference; on the other six games it was 0.6 to 1.9. The NashConv of one flop6 training has a coefficient of variation of %.2f at 0.5 s, and %d%% of the variance of the paired differences sits in the six most extreme seeds.' % (abs(d6['standardisedEffect']), d6['coefficientOfVariation56'], round(100 * d6['shareOfDifferenceVarianceInTopTenthOfSeeds'])))
w('- **Statistical power.** With that effect size the 5.6 tests (Bonferroni over 14) needed about %s pairs (t interval) and %s pairs (sign test) for 80%% power; 60 were run. The unadjusted sign test had p = %.3f.' % (d6['pairsForTIntervalAt14Tests'], d6['pairsForSignTestAt14Tests'], d6['signTestP']))
w('- **Training duration.** Both arms follow the same trajectory per seed (the trainer is identical per deal), so the paired difference compares two points of one noisy trajectory, about a factor two apart in deals. Mean NashConv fell by a factor %.1f from 20,000 to 100,000 deals (about deals to the power -0.7), so a factor two in deals is an expected ratio of about 0.6, the same order as the trajectory\'s own fluctuations at that length.' % (dg['games']['flop6']['deals:20000']['mean56'] / dg['games']['flop6']['deals:100000']['mean56']))
w('- **Not the cause:** sampling inefficiency or information-set coverage specific to this game (its tree is small: all-in or fold, two hands a seat; every information set is visited within the first thousands of deals), and not training throughput (5.6 doubled it here as elsewhere).'); w('')
w('### 4.2 New plan and result'); w('')
w('Plan (written first): %d paired seeds (%d to %d), arms %s, %s s of training, family of %d tests, the same two tests. Question: %s' % (len(F['seeds']), F['seeds'][0], F['seeds'][-1], ', '.join('`%s`' % a for a in F['arms']), ' and '.join(str(s) for s in F['trainingSeconds']), len(F['primary']), F['question'])); w('')
for key, label in ((fs, '%s s (the 5.6 budget)' % F['trainingSeconds'][0]), (fb, '%s s' % F['trainingSeconds'][-1])):
    c = f6['games']['flop6'][key]
    w('**%s.** Mean NashConv and sampled deals: ' % label + '; '.join('`%s` %s (%s deals)' % (a, fmt(v['meanNashConv']), format(round(v['meanDeals']), ',')) for a, v in c['arms'].items()) + '.'); w('')
    w('| Contrast | Role | Ratio of means | Seeds lower / higher / equal | Sign test p (Bonferroni) | t interval (Bonferroni) | Pairs for 80% power at this effect | Verdict |'); w('|---|---|---|---|---|---|---|---|')
    for name, k in c['contrasts'].items(): w('| %s | %s | %.2f | %s | %s | %s | %s | **%s** |' % (name, k['role'], k['ratioOfMeans'], row(k), ('%.2g' % k['signTestPBonferroni']) if 'signTestPBonferroni' in k else 'n/a', ('[%s, %s]' % (fmt(k['tIntervalBonferroni'][0]), fmt(k['tIntervalBonferroni'][1]))) if 'tIntervalBonferroni' in k else 'n/a', k.get('seedsFor80PercentPower', 'n/a'), k['verdict']))
    w('')
v56 = f6['games']['flop6'][fs]['contrasts']['default56 vs baseline55']['verdict']; v57 = f6['games']['flop6'][fs]['contrasts']['default57 vs baseline55']['verdict']
w('**Conclusion for flop6.** At 0.5 s the faster default trainer against 5.5 is "%s" (5.6 binary) and "%s" (5.7 binary) with %d pairs. %s' % (v56, v57, len(F['seeds']),
  'The 5.6 statement "unresolved on flop6" is replaced: the faster trainer is closer to equilibrium at equal time on this game too. The cause of the earlier result was statistical power.' if v56 == 'better' else 'The 5.6 statement stands as it was: the measured means favour the faster trainer and the test does not resolve it. It is not reported as an improvement.'))
w('')
# ---- restricted
w('## 5. Measuring quality where exact NashConv is out of reach'); w('')
w('Exact whole-game NashConv exists only for small games. Studies of the realistic fixtures report a **sampled response measure** (for each seat, one decision may deviate; the best action per hand is chosen on one sample stream and its gain measured on another), and the engine also has a **restricted best response** (the seat\'s decisions on the first street may deviate, later streets follow the trained strategy).'); w('')
w('**Direction, and why.** Each measure is the gain of one fixed alternative strategy of one seat against the trained strategies of the others. A best response is the maximum over all alternatives, so for every seat: restricted gain ≤ best-response gain, and the expectation of the sampled gain ≤ best-response gain (the sampled figure is an unbiased estimate of the gain of the alternative it selected, because selection and measurement use independent samples). Summed over seats they are **lower bounds of NashConv**. Neither is an upper bound: a small value does not show that the strategy is close to equilibrium, only that this limited family of deviations found little.'); w('')
w('**Check on %d trained states of %d games where the exact answer is known** (`restricted57.py`; default trainer, %s deals, seeds %d to %d):' % (rs['states'], len(rplan['games']), ' and '.join(format(b, ',') for b in rplan['budgetsDeals']), rplan['seeds'][0], rplan['seeds'][-1])); w('')
d = rs['direction']
w('- restricted gain above the exact gain (tolerance 1e-9): **%d of %d** seat values;' % (d['restrictedAboveExact'], d['restrictedSeatGainsChecked']))
w('- sampled gain above the exact gain by more than four standard errors: **%d of %d** seat values.' % (d['sampledAboveExactBy4StdErr'], d['sampledSeatGainsChecked'])); w('')
w('How much of the exact NashConv each measure finds (sum over seats divided by exact NashConv; median and range over the seeds):'); w('')
w('| Game | Deals | Exact NashConv (mean) | Restricted: median (min to max) | Sampled: median (min to max) |'); w('|---|---|---|---|---|')
for g in rplan['games']:
    for b in rplan['budgetsDeals']:
        c = rs['games'][g][str(b)]; r, s = c['restrictedShareOfExact'], c['sampledShareOfExact']
        w('| %s | %s | %s | %s | %s |' % (ROLE.get(g, g), format(b, ','), fmt(c['meanExactNashConv']), ('%.2f (%.2f to %.2f)' % (r['median'], r['min'], r['max'])) if r else 'not available: ' + '; '.join(c['errors'])[:80], ('%.2f (%.2f to %.2f)' % (s['median'], s['min'], s['max'])) if s else 'not available'))
w('')
sh = [rs['games'][g][str(b)]['sampledShareOfExact']['median'] for g in rplan['games'] for b in rplan['budgetsDeals'] if rs['games'][g][str(b)]['sampledShareOfExact']]
rh = [rs['games'][g][str(b)]['restrictedShareOfExact']['median'] for g in rplan['games'] for b in rplan['budgetsDeals'] if rs['games'][g][str(b)]['restrictedShareOfExact']]
w('**Reading.** The direction held in every case. The tightness did not: the sampled measure found between %.0f%% and %.0f%% of the exact NashConv (median of the per-game medians %.0f%%), the restricted one between %.0f%% and %.0f%%. It depends on the game (in a push/fold game a seat has one decision, so a one-decision deviation is almost a full best response; in a game with several streets it is not) and on the length of training: from %s to %s deals the sampled share rose in %d of %d games and the restricted share ranged from %.0f%% to %.0f%% on the game where it moved most (%s).%s **The share measured on small games cannot be carried over to the realistic fixtures**: there, the measure is a floor under an unknown NashConv.' % (100 * min(sh), 100 * max(sh), 100 * statistics.median(sh), 100 * min(rh), 100 * max(rh), format(rplan['budgetsDeals'][0], ','), format(rplan['budgetsDeals'][-1], ','),
  sum(rs['games'][g][str(rplan['budgetsDeals'][-1])]['sampledShareOfExact']['median'] > rs['games'][g][str(rplan['budgetsDeals'][0])]['sampledShareOfExact']['median'] for g in rplan['games']), len(rplan['games']),
  *(lambda g: (100 * min(rs['games'][g][str(b)]['restrictedShareOfExact']['median'] for b in rplan['budgetsDeals']), 100 * max(rs['games'][g][str(b)]['restrictedShareOfExact']['median'] for b in rplan['budgetsDeals']), ROLE.get(g, g)))(max(rplan['games'], key=lambda g: abs(rs['games'][g][str(rplan['budgetsDeals'][-1])]['restrictedShareOfExact']['median'] - rs['games'][g][str(rplan['budgetsDeals'][0])]['restrictedShareOfExact']['median']))),
  ' A negative share is a sampled estimate of a gain near zero.' if min(sh) < 0 else '')); w('')
w('### What would measure the large games'); w('')
w('Not implemented in 5.7; listed in the order of what the evidence above suggests is worth doing:'); w('')
w('1. **A deeper restricted response with a validated direction.** The restricted class can be widened street by street (first street, first two streets, …); each wider class is a larger lower bound, and on the small games the sequence can be checked against the exact value. The cost grows with the number of decision nodes of the seat; `maxNodes` already bounds it.')
w('2. **Subgame decomposition.** Exact best responses inside sampled public subtrees (a fixed flop, or a fixed turn) with the trained strategy fixed above them are tractable for the three-player fixtures and give exact numbers for parts of the game; they bound nothing about the whole game unless the parts are weighted by reach and the trunk is included.')
w('3. **Abstraction sensitivity.** Train the same spot with two bet-size sets and two hand groupings and compare the studied decision; a decision that changes with the abstraction is not established, whatever its in-abstraction quality. The study workflow already runs variants side by side; a report of the disagreement is the missing piece.')
w('4. **An upper bound.** None is available cheaply for multiway games. Without one, no percentage of "GTO completeness" can be stated, and none is.')
(root / 'CONVERGENCE-5.7.md').write_text('\n'.join(L) + '\n'); print('written', len(L), 'lines')
