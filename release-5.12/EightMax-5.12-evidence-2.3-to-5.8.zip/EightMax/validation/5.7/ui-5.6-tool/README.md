The first run of the Study-tab check for 5.7 used source/tools/study_ui56.js unchanged: 19 of 20 checks passed. The
one that failed is "the host is 5.6 and announces study checkpoints": the host answered 5.7, which is correct; the
expectation is the tool's. validation/5.7/study_ui57.js is that tool with this one expectation changed to 5.7 (the
tool under source/ is part of the build fingerprint and was left as it is); its run is in validation/5.7/ui:
20 of 20.
