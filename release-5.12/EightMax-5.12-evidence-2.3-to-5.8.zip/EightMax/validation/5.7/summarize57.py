#!/usr/bin/env python3
"""Collects the evidence under validation/5.7 into validation/5.7/validation-summary.json (the machine-readable
validation status of the release; release57.py copies it into the identity file). Usage: summarize57.py <release root>
Every figure is read from an evidence file; a missing file gives null, never a default."""
import json, sys, pathlib, re, statistics, hashlib
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.7'
def load(p):
    p = V / p; return json.loads(p.read_text()) if p.exists() else None
def text(p):
    p = V / p; return p.read_text(errors='replace') if p.exists() else None
def tap_totals(t):
    if t is None: return None
    g = lambda k: (lambda m: int(m.group(1)) if m else None)(re.search(r'^# %s (\d+)' % k, t, re.M))
    return {'tests': g('tests'), 'passed': g('pass'), 'failed': g('fail'), 'skipped': g('skipped'), 'failedTests': re.findall(r'^not ok \d+ - (.*)$', t, re.M), 'skippedTests': [m[0] for m in re.findall(r'^ok \d+ - (.*?) # SKIP(.*)$', t, re.M)]}
info = json.loads((root / 'BUILD-INFO.json').read_text()) if (root / 'BUILD-INFO.json').exists() else json.loads((root / 'build/build-info.json').read_text())
S = {'release': info['version'], 'build': info['build'], 'classes': {'1': 'implemented and independently tested (an independent implementation, an exact reference, or the unchanged 5.6 binary agrees)', '2': 'implemented and verified by the project\'s own tests on Linux, or by the Windows programs under Wine',
     '3': 'implemented, awaiting physical hardware validation (never executed on Windows hardware or an NVIDIA GPU)', '4': 'not implemented, unsuccessful, or not executed'}}
S['baseline56'] = load('baseline/baseline-5.6.json')
# regression
reg = tap_totals(text('tests/full-regression.tap')); rerun = text('tests/rerun-alone.txt')
if reg:
    reg['rerunAlone'] = [l for l in (rerun or '').splitlines() if l.strip()]; reg['failedAgainAlone'] = [l for l in reg['rerunAlone'] if l.startswith('FAILED AGAIN') or l.startswith('NOT FOUND')]
    t = text('tests/full-regression.tap'); reg['tests57'] = len(re.findall(r'^(?:ok|not ok) \d+ - 5\.7 ', t, re.M)); reg['tests57Passed'] = len(re.findall(r'^ok \d+ - 5\.7 ', t, re.M))
    reg['effective'] = {'passed': reg['passed'] + len(reg['rerunAlone']) - len(reg['failedAgainAlone']), 'failed': len(reg['failedAgainAlone']), 'skipped': reg['skipped']} if reg['passed'] is not None else None
S['regressionLinux'] = reg
# sanitizers
def num(p):
    t = text(p); return int(re.search(r'(\d+)', t).group(1)) if t and re.search(r'(\d+)', t) else None
ts = text('sanitizers/tsan-summary.txt'); counts = text('sanitizers/sanitizer-report-counts.txt')
S['sanitizers'] = {'asanUbsan53to56': tap_totals(text('sanitizers/v53-v56-asan-ubsan.tap')), 'asanUbsan57': tap_totals(text('sanitizers/v57-asan-ubsan.tap')), 'asanBuildExit': num('sanitizers/build-asan-ubsan.exit'), 'tsanBuildExit': num('sanitizers/build-tsan.exit'),
    'sanitizerReports': sum(int(l.rsplit(':', 1)[1]) for l in counts.splitlines() if ':' in l and l.rsplit(':', 1)[1].strip().isdigit()) if counts else None,
    'threadSanitizerWarnings': (lambda m: int(m.group(1)) if m else None)(re.search(r'ThreadSanitizer warnings: (\d+)', ts or '')), 'threadSanitizerRuns': re.findall(r'^(.*) exit (\d+)$', ts or '', re.M), 'threadSanitizerNotes': [l for l in (ts or '').splitlines() if 'distinct states' in l or 'equals the release build' in l or 'DIFFERS' in l or 'equivalent' in l.lower()],
    'leakSummary': (text('sanitizers/leak-summary.txt') or '').strip().splitlines() or None} if (V / 'sanitizers').exists() else None
# identity
idn = load('identity/summary.json')
if idn:
    rows = [json.loads(l) for l in (V / 'identity/identity.jsonl').read_text().splitlines() if l.strip()]; arms = [a for r in rows for a in r.get('arms', [])]
    idn.update(applicableCases=sum('arms' in r for r in rows), identicalCases=sum(r['verdict'] == 'identical' for r in rows), trainingsCompared=len(arms), identicalStates=sum(bool(a.get('identical')) for a in arms), twoPartIdentical=sum(r.get('twoPartIdentical') is True for r in rows), twoPartNotComparable=sum(r.get('twoPartIdentical') is None and 'arms' in r for r in rows),
               stoppedByTableBudget=sum(bool(r.get('limitReached')) for r in rows), threadCounts=sorted({a['threads'] for a in arms}), tablePeakDiffers=sum(a.get('tablePeakBytes') is not None and a['tablePeakBytes'] != r.get('oldTablePeakBytes') for r in rows for a in r.get('arms', [])), different=[(r['game'], r['config'], r['verdict'][:160]) for r in rows if r['verdict'].startswith('DIFFERENT')])
S['identityAgainst56'] = idn
# self-test and Wine
for k, p in (('selftest57Linux', 'selftest/selftest57-linux.json'), ('selftest57Wine', 'wine/selftest57-wine.json')):
    d = load(p); S[k] = {'passed': d['passed'], 'failed': d['failed'], 'build': d['build'], 'seconds': d['seconds'], 'failedChecks': [c['name'] for c in d['checks'] if not c['passed']]} if d else None
S['wine'] = {'tests': {f.name[:-4]: tap_totals(f.read_text(errors='replace')) for f in sorted((V / 'wine').glob('*.tap'))}, 'notes': (text('wine/README.md') or '').strip() or None} if (V / 'wine').exists() else None
# ui and stability
ui = load('ui/study-ui56.json'); stb = load('stability/stability55.json')
S['ui'] = {'checksPassed': ui['checksPassed'], 'checksTotal': ui['checksTotal'], 'browser': ui.get('browser'), 'build': ui.get('build')} if ui else None
stb6 = load('stability/stability55-six-minutes.json')
S['stabilitySixMinutes'] = {'passed': stb6['passed'], 'checks': len(stb6['checks']), 'checksPassed': sum(c['passed'] for c in stb6['checks']), 'failed': [c['name'] for c in stb6['checks'] if not c['passed']],
    'explanation': 'the tool\'s long study has a budget of 20,000,000 deals per seed; with 322 s left a seed reached the engine\'s limit of 10 million updates per training and the study ended with an error instead of at its time limit. The unchanged 5.6 binary fails in the same way with the same command (validation/5.7/stability/README.md).'} if stb6 else None
uio = load('ui-5.6-tool/study-ui56.json'); S['uiWithThe56Tool'] = {'checksPassed': uio['checksPassed'], 'checksTotal': uio['checksTotal'], 'failed': [c['name'] for c in uio['checks'] if not c.get('passed')]} if uio else None
S['knownDefectsFound'] = [{'what': 'A study whose budget exceeds 10,000,000 deals per seed (one deal per update) fails with "Iteration count must fit the 10 million iteration limit" when a seed reaches the limit, instead of being refused when it starts.', 'presentIn': ['5.6', '5.7'], 'repaired': False,
    'evidence': 'validation/5.7/stability/README.md', 'workaround': 'keep study budgets at or below 10,000,000 deals per seed (the shipped fixtures stop at 4,000,000); with frozen batches the limit is 10 million updates, that is 640 million deals at 64 deals per update'}]
S['stability'] = {'passed': stb['passed'], 'checks': len(stb['checks']), 'checksPassed': sum(c['passed'] for c in stb['checks']), 'minutes': stb.get('minutesRequested'), 'elapsedSeconds': stb.get('elapsedSeconds'), 'build': stb.get('build'), 'pauseResumeCycles': next((c['detail'].get('cycles') for c in stb['checks'] if isinstance(c.get('detail'), dict) and 'cycles' in c['detail']), None)} if stb else None
# performance
thr = load('performance/threads.json'); tb = load('performance/trainbench/summary.json'); ev = load('performance/evaluation/summary.json'); st = load('performance/studies/summary.json'); st2 = load('performance/studies-small-repeated/summary.json')
perf = {}
if thr:
    rows = thr['rows']; games = sorted({r['game'] for r in rows}); c = lambda g, a, t: next(r for r in rows if r['game'] == g and r['arm'] == a and r['threads'] == t); m = lambda r: r['dealsPerSecondMedian']
    r4 = [m(c(g, 'new', 4)) / m(c(g, 'old', 4)) for g in games]; s57 = [m(c(g, 'new-fixed', 4)) / m(c(g, 'new-fixed', 1)) for g in games]; s56 = [m(c(g, 'old', 4)) / m(c(g, 'old', 1)) for g in games]; r1 = [m(c(g, 'new-fixed', 1)) / m(c(g, 'old', 1)) for g in games]
    perf['frozenBatch'] = {'games': games, 'speedupOver56At4Threads': {'min': min(r4), 'max': max(r4), 'median': statistics.median(r4)}, 'scaling1To4Threads57': {'min': min(s57), 'max': max(s57), 'median': statistics.median(s57)}, 'scaling1To4Threads56': {'min': min(s56), 'max': max(s56), 'median': statistics.median(s56)},
                           'ratioOver56At1Thread': {'min': min(r1), 'max': max(r1), 'median': statistics.median(r1)}, 'identicalStates': all(r['identicalStates'] for r in rows), 'repetitions': thr['repetitions']}
if tb: x = [f['speedupMedian'] for f in tb['fixtures']]; perf['defaultTrainerOneThread'] = {'ratioOver56': {'min': min(x), 'max': max(x), 'median': statistics.median(x)}, 'identicalStates': sum(f['stateIdentical'] for f in tb['fixtures']), 'fixtures': len(tb['fixtures'])}
if ev:
    for k, sel in (('sampledEvaluation', lambda c: c['kind'].startswith('sampled')), ('exactEvaluation', lambda c: c['kind'] == 'exact')):
        x = [c['speedupMedian'] for c in ev['cases'] if sel(c)]; perf[k] = {'speedup': {'min': min(x), 'max': max(x), 'median': statistics.median(x)}, 'timeSavedPercent': {'min': round(100 * (1 - 1 / min(x))), 'max': round(100 * (1 - 1 / max(x)))}, 'cases': len(x), 'identicalResults': sum(c['identicalResults'] for c in ev['cases'] if sel(c))}
if st: ok = [s for s in st['studies'] if not s.get('error')]; x = [s['wallRatio56Over57'] for s in ok]; perf['completeStudies'] = {'wallRatio': {'min': min(x), 'max': max(x), 'median': statistics.median(x)}, 'studies': len(ok), 'identicalMeasurements': sum(s['identicalMeasurements'] for s in ok), 'byStudy': {s['study']: round(s['wallRatio56Over57'], 3) for s in ok}}
if st2: perf['smallStudiesRepeated'] = {s['study']: round(s['wallRatio56Over57'], 3) for s in st2['studies'] if not s.get('error')}
S['performance'] = perf or None
# convergence
main, mplan = load('convergence/main/analysis.json'), load('convergence/main/plan.json'); f6 = load('convergence/flop6/analysis.json'); rs = load('convergence/restricted/summary.json')
conv = {}
if main:
    big = 'time:%s' % mplan['trainingSeconds'][-1]; dk = 'deals:%s' % mplan['deals'][0]; G = mplan['games']
    conv['main'] = {'games': G, 'seeds': len(mplan['seeds']), 'rows': main['rows'], 'equalDeals': {name: {'identicalCheckpointFiles': sum(main['games'][g][dk]['contrasts'][name]['identicalCheckpointFiles'] for g in G), 'pairs': sum(main['games'][g][dk]['contrasts'][name]['checkpointPairs'] for g in G)} for name in ('default57 vs default56', 'batch57t4 vs batch56t4')},
                    'equalTime': {name: {g: {'verdict': main['games'][g][big]['contrasts'][name]['verdict'], 'ratioOfMeans': round(main['games'][g][big]['contrasts'][name]['ratioOfMeans'], 3)} for g in G} for name in ('batch57t4 vs batch56t4', 'batch57t4 vs default57', 'default57 vs default56', 'batch56t4 vs default56')}, 'largestTimeBudgetSeconds': mplan['trainingSeconds'][-1]}
    q2 = [v['verdict'] for v in conv['main']['equalTime']['batch57t4 vs default57'].values()]; conv['main']['promotionRuleMet'] = all(v == 'better' for v in q2); conv['main']['newDefaultTrainer'] = None if not all(v == 'better' for v in q2) else 'frozen batches'
if f6: conv['flop6'] = {k: {name: {'verdict': c['verdict'], 'ratioOfMeans': round(c['ratioOfMeans'], 3), 'seedsLower': c.get('seedsLower'), 'seedsHigher': c.get('seedsHigher'), 'pairs': c['pairs']} for name, c in cell['contrasts'].items()} for k, cell in f6['games']['flop6'].items()}
if rs: conv['restricted'] = {'states': rs['states'], 'direction': rs['direction']}
S['convergence'] = conv or None
S['windows'] = {'executablesBuilt': 'cross-compiled on Linux with MinGW-w64 GCC 13 (static)', 'executedOnWindowsHardware': False, 'validateWindows57ps1Executed': False, 'powershellAvailableInDevelopment': False, 'githubActionsWorkflowRun': False, 'whyNot': 'no Windows machine; the PowerShell download was refused by the session\'s permission policy; the session had read-only access to the repository, so no workflow could be started',
                'staticChecksOfThePowerShellScript': 'balanced quoting and bracketing, every called helper defined, no PowerShell 7-only syntax (a Python scanner, not a parser)'}
S['gpu'] = {'executedOnNvidiaHardware': False, 'cudaCodeChangedIn57': False, 'simulatedDriverTestsInRegressionSuite': True, 'statement': 'No GPU result of any kind exists for 5.7. The CUDA paths ran only against the simulated driver (a test double) inside the Linux regression suite; that is not GPU validation.'}
(V / 'validation-summary.json').write_text(json.dumps(S, indent=1)); print('written; regression', reg and {k: reg[k] for k in ('tests', 'passed', 'failed', 'skipped')})
