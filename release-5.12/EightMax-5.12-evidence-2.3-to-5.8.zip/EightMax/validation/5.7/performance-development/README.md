Thread-scaling measurements taken DURING development of 5.7, with development builds, three repetitions per cell.
They are kept because PERFORMANCE-5.7.md section 2 quotes them for what each step contributed. They are not
measurements of the released build: those are in validation/5.7/performance/.

- threads-step1-pool-and-parallel-stages.json   the new worker pool; arm "new-legacy" is the 5.6 update with only the
  pool replaced; arm "new-fixed" additionally prepares and merges on all threads, with deals still handed to
  whichever thread asks next (slower than "new-legacy": the finding that led to step 2)
- threads-step2-static-deal-shares.json, threads-step2-fixtures.json   each thread keeps its own share of the deals
- threads-step3-keys-prepared-in-parallel.json   hand-group keys computed in the parallel stage, only new keys
  interned in order
Arms: old = the unchanged 5.6 binary. The machine was the same four-processor container; its noise is visible in the
"old" rows, which differ between the files by up to 15%.
