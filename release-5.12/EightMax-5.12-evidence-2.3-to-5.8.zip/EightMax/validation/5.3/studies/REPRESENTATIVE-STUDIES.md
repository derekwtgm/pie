# Representative studies on final 5.3

Executable build `55c4fffde6deb9a1`, Linux x64 on the AMD EPYC 9V74 host described in `../environment.json`. These are CPU runs, not measurements on the target i7/RTX 4060 Ti. Full per-seed ledgers, all budgets, pairwise intervals, quality, sensitivity, and stream seeds are in each `.result.json`; matching `.csv`, plan and CLI summary are beside it. Training/evaluation times below are reported per-seed means at the final requested budget. Total wall time includes every variant and budget; peak RSS is the process high-water mark.

Budgets were deliberately practical: the main reruns use three seeds, 2,000 / 20,000 / 100,000 deals and a 90-second study cap. All original variants remain requested; unstarted variants are retained. Exact companion evaluations can cost more than sampled large-game evaluations. A time-limited baseline may prevent later variants from starting. This is evidence of incomplete work, not evidence about their recommendations.

The known reference is shown twice: a five-seed practical run and the original six-seed fixture. Both are retained. The original six-seed rerun reproduces the 5.2 frequencies and EVs to floating-point roundoff; corrected reporting still classifies its final result as a near tie and meets tolerance at 4,000,000 deals. Its five-seed subset has wider intervals and does not meet tolerance. These are separately declared study families, not one sequential statistical stopping experiment.

The intentionally undertrained case uses 100 / 200 / 400 deals. Its unresolved result is retained. No experimental trainer was promoted; `warm-4-256` remains opt-in.

## btn25-open-small

Total elapsed 2.688 s; peak RSS 21.8 MiB. Build `55c4fffde6deb9a1`. Time limit reached: False.

### baseline

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 0.184039 s; EV evaluation 0.0233563 s; quality evaluation 0.0123387 s; process peak RSS 21.7539 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 96.2163% | -0.1 | [-0.1, -0.1] | 0 |
| Raise to 2.2 | 3.7837% | -0.250117 | [-2.58856, 2.08833] | 0.0230335 |

Leading EV gap (Fold minus Raise to 2.2): 0.150117 BB, simultaneous mean interval [-2.18833, 2.48856], evaluation SE 0.0230335.
Quality mean -0.140775; simultaneous interval [-2.81532, 2.53377].

### wider-range

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 0.190375 s; EV evaluation 0.0194711 s; quality evaluation 0.0104779 s; process peak RSS 21.7539 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 92.5344% | -0.1 | [-0.1, -0.1] | 0 |
| Raise to 2.2 | 7.4656% | -0.354504 | [-6.73365, 6.02464] | 0.0340993 |

Leading EV gap (Fold minus Raise to 2.2): 0.254504 BB, simultaneous mean interval [-6.12464, 6.63365], evaluation SE 0.0340993.
Quality mean -0.113337; simultaneous interval [-3.46246, 3.23579].

### added-size

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 0.195293 s; EV evaluation 0.0241621 s; quality evaluation 0.0122602 s; process peak RSS 21.7539 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 96.9771% | -0.1 | [-0.1, -0.1] | 0 |
| Raise to 2.2 | 2.9968% | -0.472735 | [-5.84443, 4.89896] | 0.0425203 |
| All-in 24.9 | 0.0261% | -1.09073 | [-3.72085, 1.53939] | 0.0630796 |

Leading EV gap (Fold minus Raise to 2.2): 0.372735 BB, simultaneous mean interval [-4.99896, 5.74443], evaluation SE 0.0425203.
Quality mean -0.179355; simultaneous interval [-4.6642, 4.30549].

## btn25-open

Total elapsed 90.012 s; peak RSS 210.6 MiB. Build `55c4fffde6deb9a1`. Time limit reached: True.

### baseline

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 2 / 3 | 3 | incomplete | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 1.30362 s; EV evaluation 1.13922 s; quality evaluation 25.552 s; process peak RSS 210.609 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 77.9028% | -0.1 | [-0.1, -0.1] | 0 |
| Raise to 2.2 | 22.0972% | -0.610679 | [-4.4335, 3.21214] | 0.0467997 |

Leading EV gap (Fold minus Raise to 2.2): 0.510679 BB, simultaneous mean interval [-3.31214, 4.3335], evaluation SE 0.0467997.
Quality mean 0.0957265; simultaneous interval [-242.979, 243.17].

### wider-range

no budget was measured.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 0 / 3 | 0 | noData | False |
| 20000 | 0 / 3 | 0 | noData | False |
| 100000 | 0 / 3 | 0 | noData | False |

No action evaluation at the final requested budget. Earlier measurements, if any, remain in JSON/CSV.

### added-size

no budget was measured.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 0 / 3 | 0 | noData | False |
| 20000 | 0 / 3 | 0 | noData | False |
| 100000 | 0 / 3 | 0 | noData | False |

No action evaluation at the final requested budget. Earlier measurements, if any, remain in JSON/CSV.

## flop3-kings-small-undertrained

Total elapsed 2.474 s; peak RSS 9.6 MiB. Build `55c4fffde6deb9a1`. Time limit reached: False.

### baseline

tolerance not reached; last measured budget 400 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 100 | 3 / 3 | 3 | unresolved | False |
| 200 | 3 / 3 | 3 | unresolved | False |
| 400 | 3 / 3 | 3 | unresolved | False |

Final budget 400; utility chip in BB. Action evaluation exact; quality exact. Training mean 0.00131677 s; EV evaluation 0.0223007 s; quality evaluation 0.249835 s; process peak RSS 9.625 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 32.0874% | 4.91087 | [-2.21634, 12.0381] | 0 |
| Bet to 2.442 | 28.1395% | 7.05934 | [-6.33132, 20.45] | 0 |
| Bet to 5.55 | 39.7731% | 7.00303 | [-6.6209, 20.627] | 0 |

Leading EV gap (Bet to 2.442 minus Bet to 5.55): 0.0563087 BB, simultaneous mean interval [-13.6901, 13.8027], evaluation SE 0.
Quality mean 1.31997; simultaneous interval [-1.50688, 4.14681].

## flop3-kings-small

Total elapsed 12.320 s; peak RSS 21.8 MiB. Build `55c4fffde6deb9a1`. Time limit reached: False.

### baseline

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation exact; quality exact. Training mean 0.249582 s; EV evaluation 0.0241305 s; quality evaluation 0.271644 s; process peak RSS 21.7539 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 0.1722% | 4.67623 | [-1.72793, 11.0804] | 0 |
| Bet to 2.442 | 26.4250% | 6.05523 | [-8.42314, 20.5336] | 0 |
| Bet to 5.55 | 73.4028% | 5.65111 | [0.933942, 10.3683] | 0 |

Leading EV gap (Bet to 2.442 minus Bet to 5.55): 0.404124 BB, simultaneous mean interval [-18.5513, 19.3596], evaluation SE 0.
Quality mean 0.0583774; simultaneous interval [-0.82617, 0.942924].

### wider-range

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation exact; quality exact. Training mean 0.242856 s; EV evaluation 0.0308623 s; quality evaluation 0.330984 s; process peak RSS 21.7539 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 0.0042% | 5.51487 | [2.47414, 8.55559] | 0 |
| Bet to 2.442 | 26.4726% | 6.95954 | [-2.23095, 16.15] | 0 |
| Bet to 5.55 | 73.5232% | 7.23294 | [-5.88891, 20.3548] | 0 |

Leading EV gap (Bet to 5.55 minus Bet to 2.442): 0.273406 BB, simultaneous mean interval [-4.24042, 4.78723], evaluation SE 0.
Quality mean 0.0529024; simultaneous interval [-0.166524, 0.272328].

### added-size

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation exact; quality exact. Training mean 0.270155 s; EV evaluation 0.0319623 s; quality evaluation 0.392647 s; process peak RSS 21.7539 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 1.7402% | 5.00372 | [2.07021, 7.93722] | 0 |
| Bet to 2.442 | 24.0733% | 6.7289 | [0.0322839, 13.4255] | 0 |
| Bet to 5.55 | 27.1314% | 6.97558 | [-2.63505, 16.5862] | 0 |
| Bet to 9.25 | 47.0551% | 7.74515 | [-5.09459, 20.5849] | 0 |

Leading EV gap (Bet to 9.25 minus Bet to 5.55): 0.769562 BB, simultaneous mean interval [-19.2527, 20.7919], evaluation SE 0.
Quality mean 0.126782; simultaneous interval [-0.696784, 0.950348].

## flop3-kings

Total elapsed 64.616 s; peak RSS 62.5 MiB. Build `55c4fffde6deb9a1`. Time limit reached: False.

### baseline

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 1.15043 s; EV evaluation 0.328747 s; quality evaluation 4.81738 s; process peak RSS 56.1719 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 31.8862% | 6.89039 | [-4.08607, 17.8669] | 0.0739051 |
| Bet to 2.442 | 48.9730% | 7.20229 | [-3.51997, 17.9245] | 0.0820707 |
| Bet to 5.55 | 19.1408% | 6.90147 | [-9.08227, 22.8852] | 0.0806792 |

Leading EV gap (Bet to 2.442 minus Bet to 5.55): 0.300818 BB, simultaneous mean interval [-7.02994, 7.63158], evaluation SE 0.0306212.
Quality mean 0.0519253; simultaneous interval [-3.78201, 3.88586].

### wider-range

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 1.14769 s; EV evaluation 0.338812 s; quality evaluation 4.57598 s; process peak RSS 62.4922 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 34.3660% | 7.00372 | [-1.48194, 15.4894] | 0.0754839 |
| Bet to 2.442 | 45.3822% | 7.29272 | [-1.06715, 15.6526] | 0.0817624 |
| Bet to 5.55 | 20.2517% | 7.13978 | [1.84115, 12.4384] | 0.0815527 |

Leading EV gap (Bet to 2.442 minus Bet to 5.55): 0.152933 BB, simultaneous mean interval [-6.88635, 7.19221], evaluation SE 0.0334595.
Quality mean 0.0356864; simultaneous interval [-4.08687, 4.15824].

### added-size

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 1.27178 s; EV evaluation 0.371911 s; quality evaluation 5.58115 s; process peak RSS 62.4922 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 37.9098% | 6.77989 | [1.56683, 11.9929] | 0.0751387 |
| Bet to 2.442 | 40.8665% | 7.12446 | [-3.01537, 17.2643] | 0.0840623 |
| Bet to 5.55 | 20.1567% | 6.8401 | [2.4673, 11.2129] | 0.0815036 |
| Bet to 9.25 | 1.0670% | 6.24995 | [-7.00213, 19.502] | 0.083319 |

Leading EV gap (Bet to 2.442 minus Bet to 5.55): 0.284357 BB, simultaneous mean interval [-10.2136, 10.7823], evaluation SE 0.0309152.
Quality mean 0.0275958; simultaneous interval [-4.54617, 4.60136].

## flop6-jack-small

Total elapsed 90.001 s; peak RSS 21.8 MiB. Build `55c4fffde6deb9a1`. Time limit reached: True.

### baseline

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 1 / 3 | 2 | incomplete | False |
| 20000 | 1 / 3 | 1 | singleSeed | False |
| 100000 | 1 / 3 | 1 | singleSeed | False |

Final budget 100000; utility chip in BB. Action evaluation exact; quality exact. Training mean 0.809374 s; EV evaluation 5.93232 s; quality evaluation 20.0892 s; process peak RSS 21.7539 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 0.7281% | 5.3838 | unavailable | 0 |
| Bet to 4.224 | 21.8419% | 5.97353 | unavailable | 0 |
| Bet to 8.448 | 77.4300% | 5.93878 | unavailable | 0 |

Leading EV gap (Bet to 4.224 minus Bet to 8.448): 0.0347509 BB, simultaneous mean interval unavailable, evaluation SE 0.
Quality mean 0.336196; simultaneous interval unavailable.

### wider-range

no budget was measured.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 0 / 3 | 0 | noData | False |
| 20000 | 0 / 3 | 0 | noData | False |
| 100000 | 0 / 3 | 0 | noData | False |

No action evaluation at the final requested budget. Earlier measurements, if any, remain in JSON/CSV.

### added-size

no budget was measured.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 0 / 3 | 0 | noData | False |
| 20000 | 0 / 3 | 0 | noData | False |
| 100000 | 0 / 3 | 0 | noData | False |

No action evaluation at the final requested budget. Earlier measurements, if any, remain in JSON/CSV.

## flop6-jack

Total elapsed 30.691 s; peak RSS 50.4 MiB. Build `55c4fffde6deb9a1`. Time limit reached: False.

### baseline

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 2.80243 s; EV evaluation 0.0369876 s; quality evaluation 0.269352 s; process peak RSS 49.7734 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 36.5127% | 10.424 | [-7.3823, 28.2302] | 0.134639 |
| Bet to 4.224 | 34.3325% | 10.2841 | [2.93217, 17.6361] | 0.127519 |
| Bet to 8.448 | 29.1547% | 10.5101 | [-7.42578, 28.4459] | 0.130785 |

Leading EV gap (Bet to 8.448 minus Check): 0.086091 BB, simultaneous mean interval [-6.83086, 7.00304], evaluation SE 0.128923.
Quality mean -0.433838; simultaneous interval [-20.7467, 19.879].

### wider-range

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 2.65762 s; EV evaluation 0.0342004 s; quality evaluation 0.321782 s; process peak RSS 49.7734 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 34.6336% | 12.1274 | [4.7427, 19.5121] | 0.137641 |
| Bet to 4.224 | 39.5206% | 11.6871 | [3.4593, 19.9149] | 0.124513 |
| Bet to 8.448 | 25.8457% | 12.0052 | [-5.61469, 29.625] | 0.127623 |

Leading EV gap (Check minus Bet to 8.448): 0.122227 BB, simultaneous mean interval [-11.3873, 11.6318], evaluation SE 0.128525.
Quality mean -0.477667; simultaneous interval [-20.0384, 19.0831].

### added-size

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 3.36568 s; EV evaluation 0.0421703 s; quality evaluation 0.31504 s; process peak RSS 50.4336 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Check | 39.5857% | 11.0688 | [-9.53392, 31.6715] | 0.140501 |
| Bet to 4.224 | 25.1914% | 10.8938 | [-4.82134, 26.609] | 0.125128 |
| Bet to 8.448 | 22.0493% | 10.9773 | [-4.09426, 26.0489] | 0.126493 |
| Bet to 12.8 | 13.1736% | 10.721 | [-3.8703, 25.3124] | 0.128266 |

Leading EV gap (Check minus Bet to 8.448): 0.0915063 BB, simultaneous mean interval [-9.14428, 9.32729], evaluation SE 0.131552.
Quality mean -0.606114; simultaneous interval [-24.2298, 23.0175].

## icm8-bb-call-small

Total elapsed 90.009 s; peak RSS 820.0 MiB. Build `55c4fffde6deb9a1`. Time limit reached: True.

### baseline

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 2 / 3 | 3 | incomplete | False |

Final budget 100000; utility icm in percent of the prize pool. Action evaluation exact; quality exact. Training mean 0.16757 s; EV evaluation 1.0319 s; quality evaluation 7.62387 s; process peak RSS 820.039 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 99.9993% | 11.5543 | [11.5543, 11.5543] | 0 |
| Call 17.9 | 0.0007% | 10.7972 | [9.65854, 11.9359] | 0 |

Leading EV gap (Fold minus Call 17.9): 0.757092 percent of the prize pool, simultaneous mean interval [-0.381572, 1.89576], evaluation SE 0.
Quality mean 0.00894703; simultaneous interval [-9.81536, 9.83325].

### wider-range

no budget was measured.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 0 / 3 | 0 | noData | False |
| 20000 | 0 / 3 | 0 | noData | False |
| 100000 | 0 / 3 | 0 | noData | False |

No action evaluation at the final requested budget. Earlier measurements, if any, remain in JSON/CSV.

### added-size

no budget was measured.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 0 / 3 | 0 | noData | False |
| 20000 | 0 / 3 | 0 | noData | False |
| 100000 | 0 / 3 | 0 | noData | False |

No action evaluation at the final requested budget. Earlier measurements, if any, remain in JSON/CSV.

### chip-ev

no budget was measured.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 0 / 3 | 0 | noData | False |
| 20000 | 0 / 3 | 0 | noData | False |
| 100000 | 0 / 3 | 0 | noData | False |

No action evaluation at the final requested budget. Earlier measurements, if any, remain in JSON/CSV.

## icm8-bb-call

Total elapsed 28.875 s; peak RSS 49.1 MiB. Build `55c4fffde6deb9a1`. Time limit reached: False.

### baseline

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility icm in percent of the prize pool. Action evaluation sampled; quality sampled. Training mean 0.487177 s; EV evaluation 0.00528862 s; quality evaluation 0.198201 s; process peak RSS 22.043 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 33.6537% | 11.5543 | [11.5543, 11.5543] | 0 |
| Call 17.9 | 66.3463% | 11.5408 | [10.0694, 13.0122] | 0.0341315 |

Leading EV gap (Fold minus Call 17.9): 0.013474 percent of the prize pool, simultaneous mean interval [-1.45794, 1.48489], evaluation SE 0.0341315.
Quality mean 0.0468456; simultaneous interval [-0.855254, 0.948945].

### wider-range

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility icm in percent of the prize pool. Action evaluation sampled; quality sampled. Training mean 0.441721 s; EV evaluation 0.00472238 s; quality evaluation 0.195988 s; process peak RSS 23.6211 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 75.8267% | 11.5543 | [11.5543, 11.5543] | 0 |
| Call 17.9 | 24.1733% | 11.6067 | [10.139, 13.0743] | 0.034044 |

Leading EV gap (Call 17.9 minus Fold): 0.0523565 percent of the prize pool, simultaneous mean interval [-1.41529, 1.52], evaluation SE 0.034044.
Quality mean 0.0450765; simultaneous interval [-0.852853, 0.943006].

### added-size

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | unresolved | False |
| 100000 | 3 / 3 | 3 | unresolved | False |

Final budget 100000; utility icm in percent of the prize pool. Action evaluation sampled; quality sampled. Training mean 0.577811 s; EV evaluation 0.00515173 s; quality evaluation 1.96253 s; process peak RSS 49.1445 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 50.1938% | 11.5543 | [11.5543, 11.5543] | 0 |
| Call 17.9 | 49.8062% | 11.6014 | [10.128, 13.0748] | 0.0341768 |

Leading EV gap (Call 17.9 minus Fold): 0.0471004 percent of the prize pool, simultaneous mean interval [-1.42627, 1.52047], evaluation SE 0.0341768.
Quality mean 0.0393988; simultaneous interval [-0.662508, 0.741305].

### chip-ev

tolerance not reached; last measured budget 100000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 2000 | 3 / 3 | 3 | unresolved | False |
| 20000 | 3 / 3 | 3 | ranked | False |
| 100000 | 3 / 3 | 3 | smallEdge | False |

Final budget 100000; utility chip in BB. Action evaluation sampled; quality sampled. Training mean 0.438211 s; EV evaluation 0.00471861 s; quality evaluation 0.181979 s; process peak RSS 49.1445 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 1.6675% | -1.1 | [-1.1, -1.1] | 2.20253e-10 |
| Call 17.9 | 98.3325% | 3.38135 | [-1.06241, 7.82511] | 0.103079 |

Leading EV gap (Call 17.9 minus Fold): 4.48135 BB, simultaneous mean interval [0.0375878, 8.92511], evaluation SE 0.103079.
Quality mean -0.0439243; simultaneous interval [-4.36265, 4.2748].

## known-akq-river-original-six-seeds

Total elapsed 18.702 s; peak RSS 3.9 MiB. Build `55c4fffde6deb9a1`. Time limit reached: False.

### baseline

tolerance first met at 4000000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 1000 | 6 / 6 | 6 | unresolved | False |
| 10000 | 6 / 6 | 6 | unresolved | False |
| 100000 | 6 / 6 | 6 | unresolved | False |
| 1000000 | 6 / 6 | 6 | nearTie | False |
| 4000000 | 6 / 6 | 6 | nearTie | True |

Final budget 4000000; utility chip in BB. Action evaluation exact; quality exact. Training mean 3.1135 s; EV evaluation 0.000401206 s; quality evaluation 0.000121359 s; process peak RSS 3.85547 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 50.0230% | 0 | [0, 0] | 0 |
| Call 10 | 49.9770% | -0.00205413 | [-0.0398911, 0.0357828] | 0 |

Leading EV gap (Fold minus Call 10): 0.00205413 BB, simultaneous mean interval [-0.0357828, 0.0398911], evaluation SE 0.
Quality mean 0.00917553; simultaneous interval [-0.000758767, 0.0191098].

## known-akq-river

Total elapsed 15.617 s; peak RSS 9.4 MiB. Build `55c4fffde6deb9a1`. Time limit reached: False.

### baseline

tolerance not reached; last measured budget 4000000 sampled deals.

| Budget | Completed / requested | Evaluated | Verdict | Tolerance met |
|---:|---:|---:|---|---|
| 1000 | 5 / 5 | 5 | unresolved | False |
| 10000 | 5 / 5 | 5 | unresolved | False |
| 100000 | 5 / 5 | 5 | unresolved | False |
| 1000000 | 5 / 5 | 5 | nearTie | False |
| 4000000 | 5 / 5 | 5 | unresolved | False |

Final budget 4000000; utility chip in BB. Action evaluation exact; quality exact. Training mean 3.12019 s; EV evaluation 0.000404572 s; quality evaluation 0.000118254 s; process peak RSS 9.375 MiB.

| Action | Frequency | EV | Simultaneous 95% mean interval | Evaluation SE of mean |
|---|---:|---:|---|---:|
| Fold | 50.0172% | 0 | [0, 0] | 0 |
| Call 10 | 49.9828% | -0.00350247 | [-0.0580852, 0.0510802] | 0 |

Leading EV gap (Fold minus Call 10): 0.00350247 BB, simultaneous mean interval [-0.0510802, 0.0580852], evaluation SE 0.
Quality mean 0.0100372; simultaneous interval [-0.00278554, 0.0228599].

## How to compare with 5.2

See `STUDY-COMPARISON.md` for each final classification and `../legacy/legacy-comparisons.json` for every historical budget. There are 85 historical variant/budget rows; 53 classifications change after reporting-only review. Twelve old ranked rows lose confidence because their sampled evaluation streams were shared; two exact-evaluation ranked rows become unresolved after the multiple-comparison adjustment. No frequencies, EV measurements, settings or timings change in that review. Original confidence is preserved under `legacyConfidence`.

At the last stored budget, the sampled button-open wider-range, final-table ICM added-size, and final-table chip-EV recommendations lose their old ranked status. They require new independent evaluation. The exact final-table small companion remains ranked in its historical review, and the exact known A-K-Q reference remains a near tie. Fresh practical runs have different seed counts/budgets/streams, so their changed numbers cannot be assigned to reporting repair alone. The fresh chip-EV final-table run shows only a small edge; the other completed practical representative variants are unresolved. None of the practical three-seed studies reaches its declared tolerance.

