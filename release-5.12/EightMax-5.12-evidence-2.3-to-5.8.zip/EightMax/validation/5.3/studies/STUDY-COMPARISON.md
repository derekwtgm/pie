# Study comparison, EightMax 5.3

Historical review changes reporting only. Fresh runs use the plans beside their result files; different training/evaluation budgets and derived evaluation seeds prevent attributing their numerical changes solely to reporting.

| Study / variant | Old final verdict | Reviewed old verdict | Fresh final verdict | Complete | Tolerance |
|---|---|---|---|---|---|
| btn25-open-small / baseline | unresolved | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| btn25-open-small / wider-range | unresolved | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| btn25-open-small / added-size | smallEdge | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| btn25-open / baseline | smallEdge | uncertaintyUnavailable | incomplete | 2/3 | not reached |
| btn25-open / wider-range | ranked | uncertaintyUnavailable | noData | 0/3 | not reached |
| btn25-open / added-size | smallEdge | uncertaintyUnavailable | noData | 0/3 | not reached |
| flop3-kings-small-undertrained / baseline | unresolved | unresolved | unresolved | 3/3 | not reached |
| flop3-kings-small / baseline | unresolved | unresolved | unresolved | 3/3 | not reached |
| flop3-kings-small / wider-range | unresolved | unresolved | unresolved | 3/3 | not reached |
| flop3-kings-small / added-size | unresolved | unresolved | unresolved | 3/3 | not reached |
| flop3-kings / baseline | unresolved | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| flop3-kings / wider-range | unresolved | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| flop3-kings / added-size | unresolved | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| flop6-jack-small / baseline | unresolved | unresolved | singleSeed | 1/3 | not reached |
| flop6-jack-small / wider-range | unresolved | unresolved | noData | 0/3 | not reached |
| flop6-jack-small / added-size | unresolved | unresolved | noData | 0/3 | not reached |
| flop6-jack / baseline | smallEdge | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| flop6-jack / wider-range | unresolved | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| flop6-jack / added-size | smallEdge | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| icm8-bb-call-small / baseline | ranked | ranked | incomplete | 2/3 | not reached |
| icm8-bb-call-small / wider-range | ranked | ranked | noData | 0/3 | not reached |
| icm8-bb-call-small / added-size | ranked | ranked | noData | 0/3 | not reached |
| icm8-bb-call-small / chip-ev | ranked | ranked | noData | 0/3 | not reached |
| icm8-bb-call / baseline | smallEdge | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| icm8-bb-call / wider-range | smallEdge | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| icm8-bb-call / added-size | ranked | uncertaintyUnavailable | unresolved | 3/3 | not reached |
| icm8-bb-call / chip-ev | ranked | uncertaintyUnavailable | smallEdge | 3/3 | not reached |
| known-akq-river-original-six-seeds / baseline | nearTie | nearTie | nearTie | 6/6 | 4000000 |
| known-akq-river / baseline | nearTie | nearTie | unresolved | 5/5 | not reached |

Every fresh JSON and CSV contains action frequencies, EVs, all pairwise gaps, uncertainty, evaluator methods, times, peak RSS, and completion counts. No new training option was promoted; warm-4-256 remains opt-in.
