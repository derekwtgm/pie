# Independent statistical validation

Final source/build: `55c4fffde6deb9a1`; calculation `study-5.3-tfloor-bonferroni-v1`.

30,000 independently generated Gaussian random-effects trials: 3,000 per scenario. NumPy PCG64 seed 531711 supplies data; SciPy supplies independent Student-t critical values. The adapter calls the actual shipped native aggregate. Each trial assesses simultaneous coverage of every action pair; the declared family also reserves action EV and quality comparisons. Intervals below are Wilson 95% Monte Carlo uncertainty intervals, in percentage points. No false ranking was observed; zero is not proof that the true rate is zero.

| Scenario | Replications | Population pairwise coverage | Conditional pairwise coverage | False ranking | Ranked |
|---|---:|---|---|---|---|
| independent_null | 5 | 100.000% [99.872, 100.000] | 97.767% [97.174, 98.238] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |
| identical_strategies_independent | 5 | 100.000% [99.872, 100.000] | 97.633% [97.025, 98.119] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |
| shared_identical | 5 | unavailable | 97.767% [97.174, 98.238] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |
| shared_with_training_variation | 5 | unavailable | 98.267% [97.734, 98.676] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |
| correlated_actions_null | 5 | 99.867% [99.658, 99.948] | 97.733% [97.137, 98.208] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |
| negative_correlated_actions | 5 | 100.000% [99.872, 100.000] | 98.000% [97.434, 98.443] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |
| positive_gap | 12 | 99.000% [98.576, 99.299] | 97.700% [97.099, 98.179] | 0.000% [0.000, 0.128] | 100.000% [99.872, 100.000] |
| exact_evaluation | 5 | 97.167% [96.510, 97.703] | 100.000% [99.872, 100.000] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |
| two_replications | 2 | 100.000% [99.872, 100.000] | 97.667% [97.062, 98.149] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |
| one_replication | 1 | unavailable | 98.333% [97.810, 98.733] | 0.000% [0.000, 0.128] | 0.000% [0.000, 0.128] |

All 21 native critical-value comparisons with SciPy passed (df 1 through 100,000, including Bonferroni tail probabilities).

The positive-gap case has one action ahead by 1.0 utility unit, 12 replications, evaluation SD 0.2 and training SD 0.1. It ranked correctly in all 3,000 trials. Null cases include identical strategies, positive and negative action covariance, independent and fully shared evaluations, exact evaluation, and one/two replications. Shared/unknown evaluation covariance and one training replication deliberately produce no population confidence interval; their conditional intervals remain available when supported.

The conservative evaluation floor and small-df multiplicity adjustment can produce very wide intervals, as the near-100% coverage demonstrates. These tests validate the stated Gaussian scenarios; they do not establish distribution-free coverage for skewed or rare-tail poker data. Per-seat quality covariance bounds and sensitivity use the same scalar calculation, but these coverage experiments measure action-pair intervals, not an exploitability guarantee.

Reproduction: compile `source/tests/study53_probe.cpp` with `source/native/json.c` using C++20 and section garbage collection; run `python source/tools/statistical_validation53.py PROBE statistical-validation.json --trials 3000`. NumPy and SciPy are validation dependencies only.
