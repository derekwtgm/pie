#include <cstdio>
#include <cstring>
#include <cstdint>
#include "mw.h"
#include "json.h"
#include "study52.hpp"
int main(){study52::Variant v;v.labels={"A","B"};v.unit="BB";v.seeds.resize(5);for(auto &s:v.seeds){study52::Point p;p.have=true;p.freq={.5,.5};p.ev={.1,0};p.se={.2,0};p.fallback={0,0};p.pairSe={{0,.2},{.2,0}};s.push_back(p);}study52::Tol t;auto a=study52::aggregate(v,0,t);study52::Out o;study52::aggW(o,v,a,1000,t);puts(o.s.c_str());}
