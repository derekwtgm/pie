# Validation evidence for build 55c4fffde6deb9a1

Final distinct regressions: **544 passed, 0 failed, 0 skipped, 0 timed out**, after three targeted reruns. The original full invocation recorded 541 passes and three failures. Two were LeakSanitizer initialization failures under ptrace; their exact tests passed with leak detection disabled. One packaging guard ran before RELEASE-5.3.md existed; it passed after the document was added. No application source or regression test was changed for these reruns. See validation-summary.json and the retained original regression-linux.json/log.

Additional checks: 14 v53 regressions against final ASan/UBSan binaries; five fully instrumented statistics/interruption helper checks; 2,000,000 numeric-safety cases; 30,000 statistical trials; 21 SciPy critical-value checks; 4,302 DOM/event/export assertions. These counts overlap or measure different things and are not summed as regression tests.

- baseline/: untouched 5.2 integrity, source/build IDs and original defect reproductions.
- reproductions/: final synthetic, shared-workflow and timed 100-seed results.
- fixtures/: checkpoints written with rebuilt original 5.2; older supported versions remain in historical validation directories.
- statistics/: independent generator evidence, covariance models, coverage and false-ranking rates with Wilson intervals.
- studies/: eleven fresh runs, full plans/results/CSV/CLI summaries and human comparison reports.
- legacy/: reporting-only recalculations, all 85 row comparisons and preservation verification.
- ui/: DOM harness, legacy/fresh exports and graphical browser limitation log. The initial harness omitted the required app header; the host correctly rejected it. The corrected harness passed. No production change was required.
- sanitizers/: successful supported checks, failed leak-check attempts and rerun adapter. build-final.log is the completed final sanitizer build; build.log is an interrupted earlier attempt. QuickJS uses address checks only; changed native application paths use address/undefined/float-cast-overflow checks. Leak checking remains unverified.
- build-logs/: final Linux/Windows cross-build output, compiler packages, imported DLLs, identity checks and failed Wine initialization.
- linux-bin/: final Linux validation programs, not Windows executables.

Native Windows CI/runtime/UI, graphical Chromium, physical CUDA and the target i7/RTX 4060 Ti remain unverified. Wine failed initialization. GPU fixtures are simulated drivers, not physical GPU evidence. All new timings are from the Linux AMD EPYC host in environment.json. Older validation records retain their original hardware and build identities and are not new release claims.

Build and reproduction commands are in ../../.. / BUILD-5.3.md (the release-root BUILD-5.3.md). The canonical archive identity is generated outside the ZIP because the ZIP cannot contain its own final hash. The packaging tool verifies a clean extraction of that exact ZIP and runs Linux smoke checks when Windows execution is unavailable.
