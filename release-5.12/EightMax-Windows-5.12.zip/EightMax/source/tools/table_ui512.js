// EightMax 5.12: the table-size switch in a browser (Chromium through Playwright).
//   node tools/table_ui512.js <5.12 EightMax-Offline.html> <5.11 EightMax-Offline.html or -> <out.json> [screenshot-dir]
// With 8-max the library views must be the views of 5.11 (compared as HTML when the 5.11 page is given); with
// 6-max every view must follow six seats; the choice must survive a reload; no script error may occur.
'use strict';
const fs = require('node:fs'), path = require('node:path'), { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');
const [page512, page511, outFile, shotDir] = process.argv.slice(2);
if (!page512 || !outFile) { console.error('usage: node table_ui512.js <5.12 page> <5.11 page or -> <out.json> [screenshot-dir]'); process.exit(2); }
const checks = [], errors = [];
const check = (name, ok, detail) => { checks.push({ name, passed: !!ok, ...(detail !== undefined ? { detail } : {}) }); console.log((ok ? 'ok      ' : 'FAILED  ') + name + (ok || detail === undefined ? '' : '  ' + JSON.stringify(detail).slice(0, 300))); };
const POS6 = ['MP', 'HJ', 'CO', 'BTN', 'SB', 'BB'], POS8 = ['UTG', 'UTG+1', 'MP', 'HJ', 'CO', 'BTN', 'SB', 'BB'];
(async () => {
  const browser = await chromium.launch();
  const open = async file => { const ctx = await browser.newContext({ viewport: { width: 900, height: 1100 } }); const p = await ctx.newPage(); p.on('pageerror', e => errors.push(String(e))); p.on('console', m => { if (m.type() === 'error') errors.push(m.text()); }); await p.goto(pathToFileURL(path.resolve(file)).href); await p.waitForSelector('#v-preflop .grid13'); return p; };
  const text = (p, sel) => p.$$eval(sel, els => els.map(e => e.textContent.trim()));
  const shot = async (p, name) => { if (shotDir) { fs.mkdirSync(shotDir, { recursive: true }); await p.screenshot({ path: path.join(shotDir, name + '.png'), fullPage: false }); } };
  // a walk through the library views; returns the HTML of each step
  const walk = async p => {
    const out = {};
    const snap = async k => { out[k] = await p.$eval('#v-preflop', e => e.innerHTML); };
    await snap('pushfold-start');
    for (const hero of [0, 3, 4]) { await p.click(`[data-pf-hero="${hero}"]`); await snap('pushfold-hero' + hero); }
    await p.click('[data-pf-hero="4"]'); await p.click('[data-pf-facing="1"]'); await snap('pushfold-call');
    await p.click('[data-pf-view="ev"]'); await snap('pushfold-ev'); await p.click('[data-pf-view="nash"]'); await snap('pushfold-max'); await p.click('[data-pf-view="freq"]');
    for (let i = 0; i < 5; i++) await p.click('[data-pf-step="1"]'); await snap('pushfold-15bb');
    await p.click('[data-pf-src="deep"]'); await p.waitForSelector('#dp-node');
    for (const S of [15, 20, 25, 30, 40, 50, 60, 80, 100]) { await p.click(`[data-dp-stack="${S}"]`); await snap('deep-' + S); }
    await p.click('[data-dp-first="2"]'); await snap('deep-first2');
    await p.click('[data-pf-src="library"]'); await p.click('[data-pf-hero="0"]');
    for (let i = 0; i < 5; i++) await p.click('[data-pf-step="-1"]');   // back to the depth the walk started from
    return out;
  };
  const p = await open(page512);
  await p.evaluate(() => { localStorage.clear(); }); await p.reload(); await p.waitForSelector('#v-preflop .grid13');
  check('the page starts on 8-max and shows the switch', await p.$eval('#table-label', e => e.textContent) === '8-max' && await p.$eval('[data-table="8"]', e => e.getAttribute('aria-pressed')) === 'true' && await p.$eval('#table-size', e => !e.hidden));
  check('8-max: seats of the push/fold library', JSON.stringify(await text(p, '[data-pf-hero]')) === JSON.stringify(POS8));
  const eight = await walk(p);
  if (page511 && page511 !== '-') {
    const q = await open(page511); await q.evaluate(() => { localStorage.clear(); }); await q.reload(); await q.waitForSelector('#v-preflop .grid13');
    const old = await walk(q), diff = Object.keys(old).filter(k => old[k] !== eight[k]);
    check('8-max: every library view (push/fold, call, EV, max stack, nine deep charts, a first-in seat) is the HTML of the 5.11 page', diff.length === 0 && Object.keys(old).length === Object.keys(eight).length, { views: Object.keys(old).length, different: diff });
    await q.context().close();
  } else check('8-max against the 5.11 page', false, 'the 5.11 page was not given');
  await shot(p, 'table-8max-preflop');
  // ---- 6-max ----
  await p.click('[data-table="6"]');
  check('6-max: the header says 6-max', await p.$eval('#table-label', e => e.textContent) === '6-max' && await p.$eval('[data-table="6"]', e => e.getAttribute('aria-pressed')) === 'true');
  check('6-max: seats of the push/fold library are MP, HJ, CO, BTN, SB, BB', JSON.stringify(await text(p, '[data-pf-hero]')) === JSON.stringify(POS6));
  // the summary of the page against the chart read independently of the application code
  const depth = parseInt(await p.$eval('#v-preflop .stepper .val', e => e.textContent), 10);
  const independent = await p.evaluate(S => { const C = EM.CHARTS6, str = C.data[S], f = []; for (let h = 0; h < 169; h++) f.push(C.alph.indexOf(str[h]) / 63); let w = 0, t = 0; for (let h = 0; h < 169; h++) { const c = EM.CLASS_NCOMBOS[h]; w += c * f[h]; t += c; } return { pct: 100 * w / t, chars: str.length, n: C.n, depth: S }; }, depth);
  const shown = parseFloat((await p.$eval('#v-preflop .summary .big', e => e.textContent)));
  check('6-max: the first-seat jam percentage shown is the one decoded from EM.CHARTS6 directly', independent.n === 6 && independent.chars === 169 * 20 && Math.abs(shown - independent.pct) < 0.06, { shown, independent });
  check('6-max: the chart line names the table', /6-max/.test(await p.$eval('#v-preflop .card', e => e.textContent)));
  const six = await walk(p);
  check('6-max: the same walk renders (all nine deep charts, five first-in seats)', Object.keys(six).length === Object.keys(eight).length && Object.keys(six).every(k => six[k].length > 500 && six[k] !== eight[k]));
  await p.click('[data-pf-src="deep"]'); await p.waitForSelector('#dp-node');
  check('6-max: first-in seats of the 15-100 BB chart', JSON.stringify(await text(p, '[data-dp-first]')) === JSON.stringify(POS6.slice(0, 5)));
  check('6-max: the deep chart label says 6-handed', /6-handed/.test(await p.$eval('#v-preflop', e => e.textContent)));
  await shot(p, 'table-6max-deep');
  // CO opens, BTN folds, SB folds, BB calls -> two players see a flop -> postflop solver takes the ranges
  await p.click('[data-dp-stack="40"]'); await p.click('[data-dp-first="2"]');
  const act = async re => { const labels = await text(p, '[data-dp-act] .t'); const i = labels.findIndex(x => re.test(x)); if (i < 0) throw new Error('no action ' + re + ' among ' + labels.join(' | ')); await p.click(`[data-dp-act="${i}"]`); };
  let flop = false;
  try { await act(/^Raise/); await act(/^Fold/); await act(/^Fold/); await act(/^Call/); flop = await p.$('[data-dp-flop]') !== null; if (flop) await p.click('[data-dp-flop]'); } catch (e) { errors.push(String(e)); }
  check('6-max: CO raises, BTN and SB fold, BB calls reaches "Solve a flop from here" and opens the postflop solver with BB and CO', flop && /BB/.test(await p.$eval('#v-postflop', e => e.textContent)) && /CO/.test(await p.$eval('#v-postflop', e => e.textContent)));
  await p.click('[data-tab="preflop"]'); await p.click('[data-pf-src="custom"]');
  check('6-max: the custom push/fold form starts with six players', await p.$eval('[data-pfc-n="6"]', e => e.getAttribute('aria-pressed')) === 'true' && (await p.$$('[data-pfc-stack]')).length === 6);
  await p.click('[data-pf-src="library"]');
  await p.click('[data-tab="trainer"]'); await p.waitForSelector('#v-trainer .spot');
  let trainerOk = true; const seen = new Set();
  for (let i = 0; i < 60; i++) { const t = await p.$eval('#v-trainer .spot', e => e.textContent); const m = /You are\s+(\S+)/.exec(t); if (!/6-max/.test(t) || !m || !POS6.includes(m[1])) { trainerOk = false; break; } seen.add(m[1]); await p.click('[data-tr-go="0"]'); await p.click('[data-tr-next="1"]'); }
  check('6-max: sixty trainer drills are six-handed spots with six-handed seats', trainerOk && seen.size >= 4, [...seen]);
  await shot(p, 'table-6max-trainer');
  await p.click('[data-tab="icm"]');
  check('6-max: the ICM calculator starts with six stacks and six prizes', (await p.$eval('#ic-st', e => e.value)).split(',').length === 6 && (await p.$eval('#ic-pay', e => e.value)).split(',').length === 6);
  await p.click('[data-tab="river"]'); await p.waitForSelector('#rv-dealt');
  check('6-max: the multiway example deals six players in', await p.$eval('#rv-dealt', e => e.value) === '6');
  await p.click('[data-tab="study"]'); await p.waitForSelector('#sd-pick');
  const groups = await p.$$eval('#sd-pick optgroup', g => g.map(x => ({ label: x.label, n: x.children.length })));
  check('6-max: the Study list shows the six 6-max fixtures first, then the 8-max ones, and opens a six-handed study', groups.length === 2 && groups[0].label === '6-max' && groups[0].n === 6 && groups[1].label === '8-max' && groups[1].n === 10 && /six-handed/i.test(await p.$eval('#sd-title', e => e.textContent)) && /6 players dealt in/.test(await p.$eval('#sd-fixture', e => e.textContent)), groups);
  await shot(p, 'table-6max-study');
  await p.click('[data-tab="postflop"]');
  check('6-max: a fresh page loads the first sample pot with six antes (5.3 BB) and says so', await (async () => { const c = await p.context().newPage(); c.on('pageerror', e => errors.push(String(e))); await c.goto(p.url().replace(/#.*/, '') + '#postflop'); await c.waitForSelector('#po-pot'); const pot = await c.$eval('#po-pot', e => e.value), note = await c.$eval('#v-postflop', e => e.textContent); await c.close(); return pot === '5.3' && /six 0\.1 bb antes/.test(note); })());
  // ---- persistence ----
  await p.click('[data-tab="preflop"]'); await p.reload(); await p.waitForSelector('#v-preflop .grid13');
  check('the choice survives a reload', await p.$eval('#table-label', e => e.textContent) === '6-max' && JSON.stringify(await text(p, '[data-pf-hero]')) === JSON.stringify(POS6));
  await p.click('[data-table="8"]');
  const back = await walk(p), diff = Object.keys(eight).filter(k => eight[k] !== back[k]);
  check('back on 8-max the library views are again the 8-max views', diff.length === 0, diff);
  await p.click('[data-tab="river"]'); await p.waitForSelector('#rv-dealt');
  check('back on 8-max the multiway example deals eight players in', await p.$eval('#rv-dealt', e => e.value) === '8');
  check('no script error and no console error during the whole walk', errors.length === 0, errors.slice(0, 5));
  await browser.close();
  const passed = checks.filter(c => c.passed).length, failed = checks.length - passed;
  fs.writeFileSync(outFile, JSON.stringify({ what: 'EightMax 5.12 table-size switch, Chromium', page: path.basename(page512), comparedWith511: !!(page511 && page511 !== '-'), passed, failed, checks }, null, 1) + '\n');
  console.log(passed + ' passed, ' + failed + ' failed');
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
