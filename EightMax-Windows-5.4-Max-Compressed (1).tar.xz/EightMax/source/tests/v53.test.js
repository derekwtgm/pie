'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const build=require('./native_build'),{withHost,home}=require('./checkpoint_host');
const E=require('../tools/loadlib');for(const l of ['lib_runouts','lib_wide','lib_river','lib_river_ui','lib_study_ui'])require('../web/'+l);
const src=path.resolve(__dirname,'..'),fx=id=>JSON.parse(fs.readFileSync(path.join(src,'studies',id+'.emfix.json'),'utf8'));
const cli=()=>process.env.EM_TEST_MWCLI||build.cli().cli;
const tmp=t=>{let d=fs.mkdtempSync(path.join(os.tmpdir(),'em53-'));t.after(()=>fs.rmSync(d,{recursive:true,force:true}));return d;};
const run=(args)=>cp.spawnSync(cli(),args.map(String),{encoding:'utf8',timeout:600000,maxBuffer:128<<20});
function study(t,f,opts=[]){const d=tmp(t),input=path.join(d,'fixture.json'),out=path.join(d,'result.json');fs.writeFileSync(input,JSON.stringify(f));const r=run(['--study',input,out,'quiet=1',...opts]);assert.equal(r.status,0,r.stderr+r.stdout);return {doc:JSON.parse(fs.readFileSync(out)),text:r.stdout,dir:d,input};}
function probe(t,data){const d=tmp(t),obj=path.join(d,'json.o'),exe=path.join(d,'probe'+(process.platform==='win32'?'.exe':''));
 cp.execFileSync(process.env.EM_TEST_CC||'gcc',['-O2','-c',path.join(src,'native/json.c'),'-o',obj]);
 cp.execFileSync(process.env.EM_TEST_CXX||'g++',['-std=c++20','-O2','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-I'+path.join(src,'native'),path.join(__dirname,'study53_probe.cpp'),obj,'-o',exe]);
 const r=cp.spawnSync(exe,[],{input:data.map(JSON.stringify).join('\n')+'\n',encoding:'utf8'});assert.equal(r.status,0,r.stderr);return r.stdout.trim().split('\n').map(JSON.parse);}
const synthetic=(independent=true,n=5)=>({values:Array.from({length:n},()=>[.1,0]),errors:Array.from({length:n},()=>[.2,0]),pairErrors:Array.from({length:n},()=>[[0,.2],[.2,0]]),samples:1000,independent,family:1});
test('5.3 reproduced zero-width defect: independent evaluation floor and shared covariance bound retain uncertainty',t=>{
 const [a,b,c,d]=probe(t,[synthetic(),synthetic(false),synthetic(true,1),{...synthetic(),errors:Array.from({length:5},()=>[0,0]),pairErrors:Array.from({length:5},()=>[[0,0],[0,0]]),method:'exact'}]);
 assert.ok(a.gap.ci95[0]<0&&a.gap.ci95[1]>.1);assert.equal(a.verdict,'unresolved');assert.ok(Math.abs(a.gap.evaluationStdErrOfMean-.2/Math.sqrt(5))<1e-14);
 assert.equal(b.gap.ci95,null);assert.equal(b.gap.evaluationStdErrOfMean,.2);assert.ok(b.gap.conditionalEvaluationCi95[0]<0);assert.equal(b.verdict,'uncertaintyUnavailable');
 assert.equal(c.gap.ci95,null);assert.equal(c.verdict,'singleSeed');assert.ok(c.gap.conditionalEvaluationCi95[0]<0);
 assert.deepEqual(d.gap.ci95,[.1,.1]);assert.equal(d.verdict,'ranked');
});
test('5.3 accurate small-df Student t criticals and JS migration agree',t=>{const q=[{df:1,alpha:.05},{df:4,alpha:.005},{df:30,alpha:.05}];const r=probe(t,q);assert.ok(Math.abs(r[0].critical-12.706204736)<1e-8);for(let i=0;i<q.length;i++)assert.ok(Math.abs(r[i].critical-E.study.critical(q[i].df,q[i].alpha))<1e-8);});
test('5.3 selection: a narrow selected top-two gap cannot rank over an uncertain third action',t=>{
 const s={values:Array.from({length:5},()=>[1,.5,0]),errors:Array.from({length:5},()=>[0,0,1]),pairErrors:Array.from({length:5},()=>[[0,0,1],[0,0,1],[1,1,0]]),samples:1000,independent:true,family:3};
 const [r]=probe(t,[s]);assert.ok(r.gap.ci95[0]>.05);assert.equal(r.verdict,'unresolved');assert.equal(r.pairwiseGaps.length,3);
});
test('5.3 unavailable paired uncertainty is not silently zero',t=>{const s=synthetic();s.pairErrors=s.pairErrors.map(()=>[[0,null],[null,0]]);const [r]=probe(t,[s]);assert.equal(r.gap.ci95,null);assert.equal(r.gap.evaluationStdErrOfMean,null);assert.equal(r.meetsTolerance,false);});
test('5.3 timed CLI reproduction: all 100 requested seeds are counted and incomplete budgets cannot meet tolerance',t=>{
 const f=fx('known-akq-river');f.study.seeds=Array.from({length:100},(_,i)=>i);f.study.budgetsDeals=[1000,10000];f.study.tolerance={evGap:100,frequency:1,quality:100};
 const {doc,text}=study(t,f,['timeLimitSeconds=0.15']);assert.equal(doc.run.stoppedByTimeLimit,true);
 for(const b of doc.variants[0].budgets){assert.equal(b.requestedSeeds,100);assert.ok(b.completedSeeds<100);assert.equal(b.complete,false);assert.equal(b.meetsTolerance,false);assert.equal(b.toleranceChecks.allSeedsReachedBudget,false);assert.equal(b.seedStatuses.length,100);assert.ok(text.includes('completed '+b.completedSeeds+'/100 seeds'));}
 assert.equal(doc.variants[0].firstBudgetMeetingTolerance,null);assert.equal(doc.variants[0].perSeed.length,100);assert.ok(doc.variants[0].perSeed.every(s=>s.budgets.length===2));
});
test('5.3 quality none cannot meet a required threshold; last-only quality is evaluated at every required budget',t=>{
 const f=fx('known-akq-river');f.study.quality={method:'none'};
 let {doc}=study(t,f,['seeds=2','budgets=100,1000']);for(const b of doc.variants[0].budgets){assert.equal(b.completedSeeds,0);assert.equal(b.toleranceChecks.qualityWithinTolerance,false);assert.equal(b.meetsTolerance,false);}
 f.study.quality={method:'exact',budgets:'last'};({doc}=study(t,f,['seeds=2','budgets=100,1000']));for(const s of doc.variants[0].perSeed)for(const b of s.budgets){assert.equal(b.complete,true);assert.ok(Number.isFinite(b.quality));}
});
test('5.3 failed evaluations retain earlier completed budgets and later missing quality is explicit',t=>{
 const f=fx('known-akq-river');delete f.study.tolerance.quality;f.study.quality={method:'exact',budgets:'last',maxVisits:1};
 const {doc}=study(t,f,['seeds=2','budgets=100,1000']);const v=doc.variants[0];assert.equal(v.budgets[0].completedSeeds,2);assert.equal(v.budgets[1].completedSeeds,0);assert.equal(v.lastCompleteBudget,100);assert.ok(v.perSeed.every(s=>s.budgets[1].status==='evaluationFailed'));assert.equal(v.budgets[1].meetsTolerance,false);
});
test('5.3 sampled streams are reproducible, unique across runs/variants/budgets/purposes and exported',t=>{
 const f=fx('known-akq-river');f.study.ev={method:'sampled',samples:2000,seed:52};f.study.quality={method:'sampled',samples:200,selectionSamples:64,seed:52};f.variants.push({...JSON.parse(JSON.stringify(f.variants[0])),name:'control'});
 const a=study(t,f,['seeds=3','budgets=100,1000','threads=1']).doc,b=study(t,f,['seeds=3','budgets=100,1000','threads=3']).doc;
 const seen=new Set();for(let vi=0;vi<a.variants.length;vi++)for(let si=0;si<3;si++)for(let bi=0;bi<2;bi++){let x=a.variants[vi].perSeed[si].budgets[bi],y=b.variants[vi].perSeed[si].budgets[bi];for(const key of ['ev','evStdErr','pairedDiffStdErr','evaluationSeed','qualitySeed','quality','qualityStdErr'])assert.deepEqual(x[key],y[key],key);for(const key of ['evaluationSeed','qualitySeed']){assert.ok(!seen.has(x[key]));seen.add(x[key]);}}
 assert.match(a.uncertainty.seedDerivation,/mix32/);assert.equal(a.calculationVersion,E.study.CALCULATION);
});
test('5.3 JSON CSV and headline agree on completion and confidence; old results retain measurements and flag sampled confidence',t=>{
 const d=study(t,fx('known-akq-river'),['seeds=3','budgets=100,1000']).doc;
 for(const r of E.study.rows(d)){const b=d.variants[0].budgets.find(b=>b.budgetDeals===r.budgetDeals),a=b.actions.find(a=>a.label===r.action);assert.equal(r.completedSeeds,b.completedSeeds);assert.equal(r.requestedSeeds,b.requestedSeeds);assert.equal(r.evCi95Low,a.ev.ci95[0]);assert.equal(r.calculationVersion,d.calculationVersion);}
 const csv=E.study.toCSV(d);assert.ok(csv.includes('calculationVersion,requestedSeeds,completedSeeds,complete'));assert.match(E.study.headline(d.variants[0]).completion,/3\/3/);
 const old=JSON.parse(fs.readFileSync(path.join(src,'../validation/5.2/studies/btn25-open-small.result.json'))),up=E.study.validateResult(old);
 assert.equal(up.calculationVersion,'study-5.3-legacy-review-v1');assert.match(up.recalculation.note,/fresh independent evaluation/);assert.deepEqual(up.variants[0].perSeed,old.variants[0].perSeed);assert.equal(up.run.elapsedSeconds,old.run.elapsedSeconds);
 for(const v of up.variants)for(const b of v.budgets){assert.equal(b.gap.ci95,null);assert.equal(b.meetsTolerance,false);assert.ok(b.legacyConfidence);}
 assert.equal(E.study.validateResult(up),up,'idempotent reopening');
 const empty=structuredClone(d);for(const b of empty.variants[0].budgets){delete b.actions;b.completedSeeds=0;b.evaluatedSeeds=0;b.complete=false;b.meetsTolerance=false;}assert.ok(E.study.toCSV(empty).includes('known-akq-river,baseline,100,3,0,0,false,false,'));
 const exact=JSON.parse(fs.readFileSync(path.join(src,'../validation/5.2/studies/known-akq-river.result.json'))),re=E.study.validateResult(exact);assert.ok(re.variants[0].budgets.at(-1).gap.ci95);assert.deepEqual(re.variants[0].perSeed,exact.variants[0].perSeed);
});
test('5.3 overlay guard: a 1.5 BB heads-up postflop pot enforces 1 BB opening in JS and native',t=>{
 const g=E.MultiwayGame({board:'Ks8d5h2c2s',common:1.5,stacks:[20,20],ranges:['AhKh','AsKd'],streets:{river:{bets:'33,50,75',raises:'',maxBets:1}},privateMode:'sampled',traversal:'external'}),d=tmp(t),sp=path.join(d,'s.json'),st=path.join(d,'s.state'),q=path.join(d,'q.json');fs.writeFileSync(sp,JSON.stringify(g.nativeSpec()));fs.writeFileSync(q,JSON.stringify({path:[],board:[]}));assert.equal(run([sp,10,1,st,64]).status,0);const r=run(['--node',sp,st,q]);assert.equal(r.status,0,r.stderr);const acts=JSON.parse(r.stdout).actions;assert.ok(acts.filter(a=>a.to>0).every(a=>a.to>=1));assert.ok(acts.some(a=>a.to===1));assert.ok(g.view([]).actions.some(a=>a.label==='Bet 1'));
});
test('5.3 overlay guard: forced-all-in FGS fallback preserves independent ICM payout values',()=>{
 const payouts=[50,30,20],v=[.25,10,10],start=[1,10,10];const fg=E.makeFGS({depth:1,sb:.5,bb:1,anteType:'none',ante:0,payouts});const val=Array.from(fg.value(v,start));assert.equal(fg.solves,0);
 const expected=Array(3).fill(0);function perms(prefix,left,prob){if(!left.length)return;let sum=left.reduce((s,i)=>s+v[i],0);for(const i of left){let p=prob*v[i]/sum;expected[i]+=p*payouts[prefix.length];perms([...prefix,i],left.filter(j=>j!==i),p);}}perms([],[0,1,2],1);for(let i=0;i<3;i++)assert.ok(Math.abs(val[i]-expected[i])<1e-10);assert.ok(Math.abs(val.reduce((a,b)=>a+b)-100)<1e-10);
});
test('5.3 desktop completion matches CLI with failed quality and supports cancellation retaining seed statuses',{timeout:300000},async t=>{
 const f=fx('known-akq-river');f.study.quality={method:'none'};const options={seeds:3,budgets:[100,1000]};
 await withHost(home(t),{},async api=>{assert.equal((await api('study/start',{fixture:f,options})).status,200);let st;for(let i=0;i<3000;i++){st=await(await api('study/status')).json();if(!st.running)break;await new Promise(r=>setTimeout(r,10));}assert.equal(st.error,null);const doc=await(await api('study/result')).json();for(const b of doc.variants[0].budgets){assert.equal(b.requestedSeeds,3);assert.equal(b.completedSeeds,0);assert.equal(b.meetsTolerance,false);}
 const long=fx('flop6-jack');assert.equal((await api('study/start',{fixture:long,options:{seeds:3,budgets:[1000000,2000000]}})).status,200);await api('study/stop',{});for(let i=0;i<3000;i++){st=await(await api('study/status')).json();if(!st.running)break;await new Promise(r=>setTimeout(r,10));}assert.equal(st.running,false);const stopped=await(await api('study/result')).json();assert.equal(stopped.run.stoppedByUser,true);assert.ok(stopped.variants.every(v=>v.budgets.every(b=>!b.meetsTolerance&&b.seedStatuses.length===3)));});
});
test('5.3 5.2 raw and EMZ1 checkpoints continue through adaptive boundaries with exact RNG/regrets/averages/counters',t=>{
 const d=tmp(t),root=path.join(src,'../validation/5.3/fixtures'),manifest=JSON.parse(fs.readFileSync(path.join(root,'v52-checkpoints.json')));for(const row of manifest.cases){const out=path.join(d,row.file+'.state'),r=run([path.join(root,row.spec),row.remaining,3,out,512,path.join(root,row.file)]);assert.equal(r.status,0,r.stderr);assert.equal(crypto.createHash('sha256').update(fs.readFileSync(out)).digest('hex'),row.finalSha256,row.file);}
});
test('5.3 deterministic interruption at seed and evaluation boundaries preserves completed earlier budgets',{timeout:300000},t=>{
 const d=tmp(t),input=path.join(d,'fixture.json'),out=path.join(d,'result.json');const f=fx('known-akq-river');f.study.tolerance={frequency:1,evGap:100,quality:100};fs.writeFileSync(input,JSON.stringify(f));
 let exe=process.env.EM_TEST_BOUNDARY_DRIVER;if(!exe){exe=path.join(d,'boundaries'+(process.platform==='win32'?'.exe':''));const obj=path.join(d,'json.o');cp.execFileSync(process.env.EM_TEST_CC||'gcc',['-O2','-c',path.join(src,'native/json.c'),'-o',obj]);cp.execFileSync(process.env.EM_TEST_CXX||'g++',['-std=c++20','-O2','-ffp-contract=off','-I'+path.join(src,'native'),path.join(src,'native/mw.cpp'),path.join(__dirname,'study53_boundaries.cpp'),obj,'-lpthread',...(process.platform==='win32'?['-static']:['-ldl']),'-o',exe],{timeout:240000,stdio:'pipe'});}
 const options=JSON.stringify({seeds:3,budgets:[100,1000,10000],threads:2});
 const check=(phase,n)=>{const r=cp.spawnSync(exe,[input,out,phase,String(n),options],{encoding:'utf8'});assert.equal(r.status,0,r.stderr);const doc=JSON.parse(fs.readFileSync(out));assert.equal(doc.run.stoppedByUser,true);return doc.variants[0];};
 let v=check('actionEvaluated',1);assert.equal(v.budgets[0].completedSeeds,0);assert.equal(v.perSeed[0].budgets[0].status,'cancelled');assert.ok(v.perSeed[0].budgets[0].ev.length>0);assert.equal(v.perSeed[0].budgets[0].quality,null);
 v=check('evaluated',1);assert.equal(v.budgets[0].completedSeeds,1);assert.equal(v.perSeed[0].budgets[0].complete,true);assert.equal(v.budgets[0].meetsTolerance,false);
 v=check('beforeTraining',9);assert.equal(v.budgets[1].completedSeeds,3);assert.equal(v.budgets[2].completedSeeds,2);assert.equal(v.firstBudgetMeetingTolerance,1000);assert.equal(v.lastCompleteBudget,1000);assert.match(v.toleranceSummary,/final budget incomplete \(2\/3 seeds complete\)/);assert.equal(E.study.headline(v).budget,1000);
});
