// EightMax 5.2: decision studies in the desktop host (routes under /api/study/).
// A study owns its own engines (study52.hpp creates and frees them); it never touches the study that is open
// in the Multiway tab. One study runs at a time, on a background thread.
//   POST /api/study/start   {"fixture": <EightMax study fixture>, "options": {variants?, seeds?, budgets?, threads?, memoryMiB?, timeLimitSeconds?}}
//   GET  /api/study/status  {running, hasResult, error, progress, elapsedSeconds, stopRequested}
//   GET  /api/study/result  the "EightMax study result" document of the last finished study (404 if none)
//   POST /api/study/stop    asks the running study to stop; the measurements completed so far are reported
#ifndef EM_STUDY_JOBS_H
#define EM_STUDY_JOBS_H
static pthread_mutex_t STUDY_MU = PTHREAD_MUTEX_INITIALIZER;
static volatile int STUDY_RUNNING = 0, STUDY_STOP = 0;
static char *STUDY_RESULT = NULL; static size_t STUDY_RESULT_LEN = 0;
static char STUDY_ERR[768], *STUDY_PROGRESS = NULL; static double STUDY_T0 = 0, STUDY_ELAPSED = 0;
typedef struct { char *fixture; size_t flen; char *options; size_t olen; } StudyArgs;
static void study_jv_write(JB *o, const JV *v) {
  if (!v || v->type == J_NULL) { jb_puts(o, "null"); return; }
  if (v->type == J_BOOL) { jb_puts(o, v->num != 0 ? "true" : "false"); return; }
  if (v->type == J_NUM) { jb_printf(o, "%.17g", v->num); return; }
  if (v->type == J_STR) { jb_str(o, v->str); return; }
  jb_putc(o, v->type == J_ARR ? '[' : '{');
  for (int i = 0; i < v->n; i++) { if (i) jb_putc(o, ','); if (v->type == J_OBJ) { jb_str(o, v->keys[i]); jb_putc(o, ':'); } study_jv_write(o, v->items[i]); }
  jb_putc(o, v->type == J_ARR ? ']' : '}');
}
static void study_progress(void *ctx, const char *json) {
  (void)ctx;
  // Publish an entire JSON document atomically. Truncation corrupts /status.
  // On allocation failure retain the previous complete progress snapshot.
  const size_t n = strlen(json); char *next = (char *)malloc(n + 1);
  if (next) memcpy(next, json, n + 1);
  pthread_mutex_lock(&STUDY_MU);
  if (next) { free(STUDY_PROGRESS); STUDY_PROGRESS = next; }
  STUDY_ELAPSED = now_s() - STUDY_T0;
  pthread_mutex_unlock(&STUDY_MU);
}
static void *study_job(void *a) {
  pthread_mutex_lock(&STUDY_MU); pthread_mutex_unlock(&STUDY_MU);   // wait until the starter has published the job
  StudyArgs *A = (StudyArgs *)a; JB out; jb_init(&out); char err[768] = "";
  const int st = mw_study_run(A->fixture, A->flen, A->options, A->olen, &out, err, sizeof err, &STUDY_STOP, study_progress, NULL);
  pthread_mutex_lock(&STUDY_MU);
  if (st == 200 && !out.failed) { free(STUDY_RESULT); STUDY_RESULT = out.s; STUDY_RESULT_LEN = out.n; out.s = NULL; STUDY_ERR[0] = 0; }
  else snprintf(STUDY_ERR, sizeof STUDY_ERR, "%s", err[0] ? err : "The study failed");
  STUDY_ELAPSED = now_s() - STUDY_T0; STUDY_RUNNING = 0;
  pthread_mutex_unlock(&STUDY_MU);
  jb_free(&out); free(A->fixture); free(A->options); free(A);
  return NULL;
}
// Returns 1 when the route was handled.
static int study_api(sock_t s, const char *method, const char *path, const char *body, size_t blen) {
  if (strncmp(path, "/api/study/", 11)) return 0;
  const char *r = path + 11; const int post = !strcmp(method, "POST");
  if (!strcmp(r, "status") && !post) {
    JB b; jb_init(&b); pthread_mutex_lock(&STUDY_MU);
    jb_printf(&b, "{\"running\":%s,\"hasResult\":%s,\"stopRequested\":%s,\"elapsedSeconds\":", STUDY_RUNNING ? "true" : "false", STUDY_RESULT ? "true" : "false", STUDY_STOP ? "true" : "false");
    jb_num(&b, STUDY_RUNNING ? now_s() - STUDY_T0 : STUDY_ELAPSED, 3); jb_puts(&b, ",\"error\":"); if (STUDY_ERR[0]) jb_str(&b, STUDY_ERR); else jb_puts(&b, "null");
    jb_puts(&b, ",\"progress\":"); jb_puts(&b, STUDY_PROGRESS ? STUDY_PROGRESS : "null"); jb_putc(&b, '}');
    pthread_mutex_unlock(&STUDY_MU); respond_json(s, 200, &b); jb_free(&b); return 1;
  }
  if (!strcmp(r, "result") && !post) {
    pthread_mutex_lock(&STUDY_MU);
    if (!STUDY_RESULT) { pthread_mutex_unlock(&STUDY_MU); respond_err(s, 404, "No study result yet"); return 1; }
    JB b; jb_init(&b); jb_putn(&b, STUDY_RESULT, STUDY_RESULT_LEN); pthread_mutex_unlock(&STUDY_MU);
    respond_json(s, 200, &b); jb_free(&b); return 1;
  }
  if (!strcmp(r, "stop") && post) { __atomic_store_n(&STUDY_STOP, 1, __ATOMIC_RELAXED); respond_ok(s); return 1; }
  if (!strcmp(r, "start") && post) {
    char err[512] = ""; JV *v = json_parse(body ? body : "", body ? blen : 0, err, sizeof err);
    if (!v || v->type != J_OBJ) { if (v) json_free(v); respond_err(s, 400, err[0] ? err : "The request must be a JSON object {fixture, options}"); return 1; }
    const JV *fx = jget(v, "fixture"), *op = jget(v, "options");
    if (!fx || fx->type != J_OBJ || (op && op->type != J_OBJ)) { json_free(v); respond_err(s, 400, "fixture must be an object and options, if present, an object"); return 1; }
    JB f, o; jb_init(&f); jb_init(&o); study_jv_write(&f, fx); if (op) study_jv_write(&o, op); else jb_puts(&o, "{}"); json_free(v);
    StudyArgs *A = (StudyArgs *)calloc(1, sizeof *A);
    if (!A || f.failed || o.failed) { free(A); jb_free(&f); jb_free(&o); respond_err(s, 503, "Out of memory"); return 1; }
    A->fixture = f.s; A->flen = f.n; A->options = o.s; A->olen = o.n;
    pthread_mutex_lock(&STUDY_MU);
    if (STUDY_RUNNING) { pthread_mutex_unlock(&STUDY_MU); free(A->fixture); free(A->options); free(A); respond_err(s, 409, "A study is already running; stop it first"); return 1; }
    if (launch_thread(study_job, A, 16 << 20)) { pthread_mutex_unlock(&STUDY_MU); free(A->fixture); free(A->options); free(A); respond_err(s, 503, "Could not start a study thread"); return 1; }
    __atomic_store_n(&STUDY_STOP, 0, __ATOMIC_RELAXED); STUDY_RUNNING = 1; STUDY_ERR[0] = 0; free(STUDY_PROGRESS); STUDY_PROGRESS = NULL; STUDY_T0 = now_s(); STUDY_ELAPSED = 0;
    pthread_mutex_unlock(&STUDY_MU);
    respond_ok(s); return 1;
  }
  respond_err(s, 404, "Not found"); return 1;
}
#endif
