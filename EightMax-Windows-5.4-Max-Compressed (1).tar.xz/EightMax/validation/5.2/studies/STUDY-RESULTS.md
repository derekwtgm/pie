# EightMax 5.2 study results

Generated from 10 result documents (raw per-seed data: the JSON files next to this report). Build 64104bb52e491e49, 54fa50e5f8456c53, be9b003d488c8dff.

How to read it. **Frequency** is the hero hand's average-strategy frequency (mean over independently seeded trainings; "sd" is the spread across those trainings). **EV gap** is EV(higher) − EV(lower) of the two actions with the highest mean EV; its 95% interval is over trained strategies and so contains both the spread between trainings and the evaluation sampling error, which is listed separately. **Quality** is exact (sum of every seat's exact best-response gain inside the fixture's abstraction) or sampled (one-shot deviations, a lower bound that cannot certify an equilibrium). Verdicts: *ranked* (the whole interval lies above the declared EV tolerance), *nearTie* (the whole interval lies inside ± tolerance: a mix is consistent), *smallEdge* (interval above zero but not above the tolerance), *unresolved*.

## One row per decision (baseline variant)

| Study | Hero and decision | Recommended action or mix | EV gap (95% interval over trainings) | Evaluation se / between-training sd | Quality (kind) | Budget used | Training time per seed (idle machine) | Peak RAM | Tolerance |
|---|---|---|---|---|---|---|---|---|---|
| **btn25-open** | BTN Kd8c, first to act | **Small edge for Raise to 2.2**: Raise to 2.2 87%, Fold 13% | Raise to 2.2 − Fold = +0.047 BB [+0.035, +0.060] | 0.004 / 0.003 | −0.0396 (sampled) | 4,000,000 deals | 80.8 s | 817 MiB | **not reached** (last 4,000,000) |
| **btn25-open-small** | BTN Kd8c, first to act | **Unresolved**: Fold 93%, Raise to 2.2 7% | Fold − Raise to 2.2 = +0.045 BB [−0.004, +0.095] | 0.002 / 0.040 | −0.0008 (sampled) | 2,000,000 deals | 4.8 s | 7 MiB | **not reached** (last 2,000,000) |
| **flop3-kings** | BTN KhJs after SB Check, BB Check | **Unresolved**: Bet to 2.442 82%, Check 15%, Bet to 5.55 3% | Bet to 2.442 − Bet to 5.55 = +0.025 BB [−0.036, +0.087] | 0.005 / 0.048 | 0.0540 (sampled) | 4,000,000 deals | 69.0 s | 57 MiB | **not reached** (last 4,000,000) |
| **flop3-kings-small** | BTN KhJs after SB Check, BB Check | **Unresolved**: Bet to 5.55 63%, Bet to 2.442 37% | Bet to 2.442 − Bet to 5.55 = +0.050 BB [−0.170, +0.269] | 0.000 / 0.177 | 0.0198 (exact) | 2,000,000 deals | 6.1 s | 6 MiB | **not reached** (last 2,000,000) |
| **flop3-kings-detailed** | BTN KhJs after SB Check, BB Check | **Unresolved**: Check 49%, Bet to 2.442 40%, Bet to 5.55 10% | Bet to 2.442 − Check = +0.087 BB [−0.163, +0.336] | 0.019 / 0.007 | n/a (none) | 4,000,000 deals | 104.4 s | 1548 MiB | **not reached** (last 4,000,000) |
| **flop6-jack** | UTG+1 AdJs after SB Check, BB Check | **Small edge for Check**: Bet to 8.448 38%, Bet to 4.224 31%, Check 30% | Check − Bet to 8.448 = +0.101 BB [+0.034, +0.169] | 0.008 / 0.051 | −0.0984 (sampled) | 4,000,000 deals | 150.2 s | 87 MiB | **not reached** (last 4,000,000) |
| **flop6-jack-small** | UTG+1 AdJs after SB Check, BB Check | **Unresolved**: Bet to 4.224 51%, Bet to 8.448 49%, Check 1% | Bet to 8.448 − Bet to 4.224 = +0.088 BB [−0.198, +0.374] | 0.000 / 0.230 | 0.1774 (exact) | 2,000,000 deals | 20.6 s | 11 MiB | **not reached** (last 2,000,000) |
| **icm8-bb-call** | BB AdTc after BTN All-in 39.9, SB Fold | **Small edge for Call 17.9**: Call 17.9 71%, Fold 29% | Call 17.9 − Fold = +0.044 percent of the prize pool [+0.033, +0.055] | 0.002 / 0.008 | 0.0016 (sampled) | 8,000,000 deals | 44.7 s | 50 MiB | **not reached** (last 8,000,000) |
| **icm8-bb-call-small** | BB AdTc after BTN All-in 39.9, SB Fold | **Prefer Fold**: Fold 100% | Fold − Call 17.9 = +0.724 percent of the prize pool [+0.724, +0.725] | 0.000 / 0.000 | 0.0000 (exact) | 2,000,000 deals | 4.0 s | 509 MiB | met at 2,000,000 |
| **known-akq-river** | Seat 2 KhKd after Seat 1 All-in 10 | **Mix (EVs within tolerance)**: Fold 50%, Call 10 50% | Fold − Call 10 = +0.002 BB [−0.015, +0.019] | 0.000 / 0.017 | 0.0092 (exact) | 4,000,000 deals | 4.5 s | 6 MiB | met at 4,000,000 |

## What changed when one input changed

| Study | Variant (one change) | Most frequent action: baseline → variant | Seeds where it changed | Largest mean frequency change | EV gap in the variant | Added action | Note |
|---|---|---|---|---|---|---|---|
| btn25-open | **wider-range**: Blind ranges without the bunching weights: every hand of both blinds at weight 1 (weak hands are 11% more frequent than in the baseline). | Raise to 2.2 → Raise to 2.2 | 0 of 5 | 8.9% | Raise to 2.2 − Fold = +0.126 BB [+0.098, +0.153] (ranked) | – |  |
| btn25-open | **added-size**: The button may also open all-in (25 BB) in addition to raising to 2.2 BB. | Raise to 2.2 → Raise to 2.2 | 0 of 5 | 1.3% | Raise to 2.2 − Fold = +0.039 BB [+0.008, +0.071] (smallEdge) | All-in 24.9: 0.1%, EV vs Raise to 2.2 −0.776 BB [−0.823, −0.728] |  |
| btn25-open-small | **wider-range**: The big blind range gains a weaker hand (Jh4h at weight 1). | Fold → Fold | 0 of 5 | 0.6% | Fold − Raise to 2.2 = +0.029 BB [−0.003, +0.062] (unresolved) | – |  |
| btn25-open-small | **added-size**: The button may also open all-in (25 BB). | Fold → Fold | 0 of 5 | 0.6% | Fold − Raise to 2.2 = +0.033 BB [+0.015, +0.051] (smallEdge) | All-in 24.9: 0.0%, EV vs Fold −1.050 BB [−1.054, −1.046] |  |
| flop3-kings | **wider-range**: The big blind calls preflop with a wider range: 15 more offsuit and suited classes (K7o, K6o:0.5, Q8o, J8o, T8o, 97o, 86o:0.5, 76o, Q7s, J7s, T7s, 96s, 85s, 74s:0.5, 53s). | Bet to 2.442 → Bet to 2.442 | 0 of 5 | 3.5% | Bet to 2.442 − Bet to 5.55 = +0.019 BB [−0.046, +0.083] (unresolved) | – |  |
| flop3-kings | **added-size**: A 125% pot overbet is added on the flop (33%, 75% and 125% pot). | Bet to 2.442 → Bet to 2.442 | 0 of 5 | 0.2% | Bet to 2.442 − Bet to 5.55 = +0.053 BB [−0.042, +0.148] (unresolved) | Bet to 9.25: 0.1%, EV vs Bet to 2.442 −0.223 BB [−0.390, −0.056] |  |
| flop3-kings-small | **wider-range**: The big blind range gains two weaker hands (Jh9h and 6h4h at weight 1). | Bet to 5.55 → Bet to 5.55 | 1 of 5 | 10.8% | Bet to 5.55 − Bet to 2.442 = +0.060 BB [−0.006, +0.126] (unresolved) | – | the baseline's EV order of its two leading actions is reversed |
| flop3-kings-small | **added-size**: A 125% pot overbet is added on the flop. | Bet to 5.55 → Bet to 9.25 | 5 of 5 | 30.8% | Bet to 9.25 − Bet to 5.55 = +0.313 BB [−1.336, +1.962] (unresolved) | Bet to 9.25: 52.0%, EV vs Bet to 5.55 +0.313 BB [−1.336, +1.962] (**now most frequent**) | the baseline's EV order of its two leading actions is reversed |
| flop6-jack | **wider-range**: The button (the last caller) holds a wider range: 15 more classes (22, A6s, A2s, K8s, Q8s, J7s, T7s, 96s, 65s, 54s:0.5, KTo, QTo, J9o, T9o:0.5, A9o:0.5). | Bet to 8.448 → Bet to 8.448 | 1 of 5 | 13.9% | Check − Bet to 8.448 = +0.019 BB [−0.157, +0.196] (unresolved) | – |  |
| flop6-jack | **added-size**: A pot-size bet (100% pot) is added on the flop (33%, 66% and 100% pot). | Bet to 8.448 → Bet to 8.448 | 1 of 5 | 6.5% | Check − Bet to 8.448 = +0.117 BB [+0.025, +0.209] (smallEdge) | Bet to 12.8: 2.3%, EV vs Check −0.170 BB [−0.326, −0.014] |  |
| flop6-jack-small | **wider-range**: The button range gains a weaker hand (Tc7c at weight 1). | Bet to 4.224 → Bet to 4.224 | 2 of 5 | 48.2% | Bet to 4.224 − Bet to 8.448 = +0.107 BB [−0.196, +0.411] (unresolved) | – | the baseline's EV order of its two leading actions is reversed |
| flop6-jack-small | **added-size**: A pot-size bet (100% pot) is added on the flop. | Bet to 4.224 → Bet to 4.224 | 2 of 5 | 8.2% | Bet to 8.448 − Bet to 4.224 = +0.177 BB [−0.006, +0.361] (unresolved) | Bet to 12.8: 0.0%, EV vs Bet to 8.448 −0.742 BB [−1.045, −0.438] |  |
| icm8-bb-call | **wider-range**: No bunching weights: every hand of BTN, SB and BB at weight 1 (weak hands 11% more frequent). | Call 17.9 → Call 17.9 | 1 of 5 | 26.4% | Call 17.9 − Fold = +0.065 percent of the prize pool [+0.049, +0.080] (smallEdge) | – |  |
| icm8-bb-call | **added-size**: The button may also raise to 2.2 BB instead of moving all-in (blinds can call or re-raise all-in; one all-in bet on the flop). | Call 17.9 → Call 17.9 | 1 of 5 | 28.6% | Call 17.9 − Fold = +0.166 percent of the prize pool [+0.127, +0.205] (ranked) | – |  |
| icm8-bb-call | **chip-ev**: Same stacks, ranges and actions, but utilities are chips (BB) instead of ICM prize share. | Call 17.9 → Call 17.9 | 1 of 5 | 29.0% | Call 17.9 − Fold = +4.082 BB [+4.008, +4.156] (ranked) | – | different utility (percent of the prize pool vs BB): EVs not compared |
| icm8-bb-call-small | **wider-range**: The button range gains a weaker hand (Jc6c at weight 1). | Fold → Fold | 0 of 5 | 0.0% | Fold − Call 17.9 = +0.635 percent of the prize pool [+0.635, +0.635] (ranked) | – |  |
| icm8-bb-call-small | **added-size**: The button may also raise to 2.2 BB instead of moving all-in (postflop checked down). The quality metric of this variant is sampled: exact best response exceeds the work limit once a 2.2 BB raise can reach the flop. | Fold → Fold | 0 of 5 | 0.0% | Fold − Call 17.9 = +0.719 percent of the prize pool [+0.711, +0.726] (ranked) | – |  |
| icm8-bb-call-small | **chip-ev**: Same spot with chip utilities (BB) instead of ICM prize share. | Fold → Call 17.9 | 5 of 5 | 100.0% | Call 17.9 − Fold = +0.479 BB [+0.479, +0.479] (ranked) | – | different utility (percent of the prize pool vs BB): EVs not compared; the baseline's EV order of its two leading actions is reversed |

## btn25-open — 25 BB button open, folded to the button (eight-handed MTT)

- UTG, UTG+1, MP, HJ and CO fold. Button to act.
- Seeds 5201, 5202, 5203, 5204, 5205; 2 worker thread(s) requested on 4 logical processors; total 4023 s; process peak RAM 829 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.05, frequency sd ≤ 0.05, stable against the previous budget.

### btn25-open / baseline

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Raise to 2.2 freq (sd) | Fold EV | Raise to 2.2 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 93.4% (4.8%) | 6.6% (4.8%) | −0.100 | −0.485 | Fold − Raise to 2.2 = +0.385 | [−0.018, +0.787] | 0.006 | 0.324 | not evaluated | 29.7% | 4.50 | 28.22 | 0.00 | unresolved | no |
| 1,000,000 | 5 | 30.1% (28.6%) | 69.9% (28.6%) | −0.100 | −0.022 | Raise to 2.2 − Fold = +0.078 | [−0.016, +0.172] | 0.004 | 0.075 | not evaluated | 13.9% | 19.57 | 28.53 | 0.00 | unresolved | no |
| 4,000,000 | 5 | 13.1% (14.9%) | 86.9% (14.9%) | −0.100 | −0.053 | Raise to 2.2 − Fold = +0.047 | [+0.035, +0.060] | 0.004 | 0.003 | −0.0396 ± 0.0130 se | 6.6% | 85.20 | 31.66 | 99.70 | smallEdge | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Small edge for Raise to 2.2: Raise to 2.2 87%, Fold 13%. EV gap Raise to 2.2 − Fold = +0.047 BB, 95% [+0.035, +0.060]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

### btn25-open / wider-range — Blind ranges without the bunching weights: every hand of both blinds at weight 1 (weak hands are 11% more frequent than in the baseline).

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Raise to 2.2 freq (sd) | Fold EV | Raise to 2.2 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 50.3% (21.6%) | 49.7% (21.6%) | −0.100 | −0.135 | Fold − Raise to 2.2 = +0.035 | [−0.195, +0.265] | 0.005 | 0.185 | not evaluated | 26.0% | 4.19 | 27.44 | 0.00 | unresolved | no |
| 1,000,000 | 5 | 18.3% (12.4%) | 81.7% (12.4%) | −0.100 | +0.041 | Raise to 2.2 − Fold = +0.141 | [+0.094, +0.187] | 0.004 | 0.036 | not evaluated | 13.5% | 18.51 | 29.95 | 0.00 | ranked | no |
| 4,000,000 | 5 | 4.2% (6.6%) | 95.8% (6.6%) | −0.100 | +0.026 | Raise to 2.2 − Fold = +0.126 | [+0.098, +0.153] | 0.004 | 0.020 | −0.0531 ± 0.0125 se | 6.7% | 84.35 | 32.65 | 95.88 | ranked | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Prefer Raise to 2.2: Raise to 2.2 96%, Fold 4%. EV gap Raise to 2.2 − Fold = +0.126 BB, 95% [+0.098, +0.153]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

### btn25-open / added-size — The button may also open all-in (25 BB) in addition to raising to 2.2 BB.

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Raise to 2.2 freq (sd) | All-in 24.9 freq (sd) | Fold EV | Raise to 2.2 EV | All-in 24.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 68.6% (23.5%) | 27.3% (23.1%) | 4.1% (7.6%) | −0.100 | −0.406 | −0.765 | Fold − Raise to 2.2 = +0.306 | [+0.133, +0.478] | 0.007 | 0.138 | not evaluated | 26.2% | 3.46 | 28.05 | 0.00 | ranked | no |
| 1,000,000 | 5 | 27.2% (14.6%) | 71.0% (17.9%) | 1.9% (4.0%) | −0.100 | −0.050 | −0.787 | Raise to 2.2 − Fold = +0.050 | [−0.023, +0.123] | 0.004 | 0.058 | not evaluated | 12.4% | 16.72 | 29.68 | 0.00 | unresolved | no |
| 4,000,000 | 5 | 14.3% (17.5%) | 85.6% (17.5%) | 0.1% (0.3%) | −0.100 | −0.061 | −0.836 | Raise to 2.2 − Fold = +0.039 | [+0.008, +0.071] | 0.004 | 0.024 | −0.2095 ± 0.0211 se | 6.1% | 77.84 | 31.78 | 93.45 | smallEdge | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Small edge for Raise to 2.2: Raise to 2.2 86%, Fold 14%. EV gap Raise to 2.2 − Fold = +0.039 BB, 95% [+0.008, +0.071]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

## btn25-open-small — 25 BB button open, small companion (short weighted ranges, exact cards, no postflop betting)

- UTG, UTG+1, MP, HJ and CO fold. Button to act.
- Seeds 5201, 5202, 5203, 5204, 5205; 1 worker thread(s) requested on 4 logical processors; total 341 s; process peak RAM 7 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.03, frequency sd ≤ 0.05, stable against the previous budget.

### btn25-open-small / baseline

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Raise to 2.2 freq (sd) | Fold EV | Raise to 2.2 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 81.8% (12.2%) | 18.2% (12.2%) | −0.100 | −0.389 | Fold − Raise to 2.2 = +0.289 | [+0.136, +0.442] | 0.004 | 0.123 | 0.0661 ± 0.0038 se | 0.0% | 0.10 | 3.62 | 0.63 | ranked | no |
| 200,000 | 5 | 96.4% (3.8%) | 3.6% (3.8%) | −0.100 | −0.285 | Fold − Raise to 2.2 = +0.185 | [−0.114, +0.485] | 0.003 | 0.241 | 0.0148 ± 0.0024 se | 0.0% | 0.86 | 3.78 | 0.67 | unresolved | no |
| 2,000,000 | 5 | 92.6% (3.1%) | 7.4% (3.1%) | −0.100 | −0.145 | Fold − Raise to 2.2 = +0.045 | [−0.004, +0.095] | 0.002 | 0.040 | −0.0008 ± 0.0027 se | 0.0% | 8.96 | 3.85 | 0.87 | unresolved | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Unresolved: Fold 93%, Raise to 2.2 7%. EV gap Fold − Raise to 2.2 = +0.045 BB, 95% [−0.004, +0.095]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

### btn25-open-small / wider-range — The big blind range gains a weaker hand (Jh4h at weight 1).

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Raise to 2.2 freq (sd) | Fold EV | Raise to 2.2 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 81.0% (8.8%) | 19.0% (8.8%) | −0.100 | −0.286 | Fold − Raise to 2.2 = +0.186 | [+0.023, +0.348] | 0.005 | 0.130 | 0.0670 ± 0.0068 se | 0.0% | 0.10 | 3.52 | 0.74 | smallEdge | no |
| 200,000 | 5 | 88.9% (6.7%) | 11.1% (6.7%) | −0.100 | −0.181 | Fold − Raise to 2.2 = +0.081 | [+0.021, +0.142] | 0.002 | 0.049 | 0.0081 ± 0.0026 se | 0.0% | 1.00 | 3.59 | 0.77 | smallEdge | no |
| 2,000,000 | 5 | 93.2% (3.1%) | 6.8% (3.1%) | −0.100 | −0.129 | Fold − Raise to 2.2 = +0.029 | [−0.003, +0.062] | 0.002 | 0.026 | −0.0095 ± 0.0034 se | 0.0% | 9.09 | 3.73 | 0.67 | unresolved | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Unresolved: Fold 93%, Raise to 2.2 7%. EV gap Fold − Raise to 2.2 = +0.029 BB, 95% [−0.003, +0.062]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

### btn25-open-small / added-size — The button may also open all-in (25 BB).

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Raise to 2.2 freq (sd) | All-in 24.9 freq (sd) | Fold EV | Raise to 2.2 EV | All-in 24.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 79.1% (14.3%) | 20.4% (13.9%) | 0.4% (0.4%) | −0.100 | −0.415 | −0.885 | Fold − Raise to 2.2 = +0.315 | [+0.120, +0.510] | 0.004 | 0.157 | 0.1118 ± 0.0074 se | 0.0% | 0.09 | 4.06 | 0.72 | ranked | no |
| 200,000 | 5 | 96.5% (4.1%) | 3.4% (4.1%) | 0.0% (0.0%) | −0.100 | −0.377 | −1.148 | Fold − Raise to 2.2 = +0.277 | [−0.104, +0.659] | 0.004 | 0.307 | 0.0068 ± 0.0056 se | 0.0% | 0.91 | 4.24 | 0.82 | unresolved | no |
| 2,000,000 | 5 | 93.2% (5.0%) | 6.8% (5.0%) | 0.0% (0.0%) | −0.100 | −0.133 | −1.150 | Fold − Raise to 2.2 = +0.033 | [+0.015, +0.051] | 0.002 | 0.014 | −0.0241 ± 0.0078 se | 0.0% | 9.04 | 4.07 | 0.76 | smallEdge | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Small edge for Fold: Fold 93%, Raise to 2.2 7%. EV gap Fold − Raise to 2.2 = +0.033 BB, 95% [+0.015, +0.051]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

## flop3-kings — Three-way flop K-8-5 rainbow, button with top pair after two checks

- Preflop: BTN raises to 2.2, SB calls, BB calls (pot 7.4 BB). Flop Ks 8d 5h: SB checks, BB checks. Button to act.
- Seeds 5211, 5212, 5213, 5214, 5215; 1 worker thread(s) requested on 4 logical processors; total 3090 s; process peak RAM 70 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.05, frequency sd ≤ 0.05, stable against the previous budget.

### flop3-kings / baseline

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Check freq (sd) | Bet to 2.442 freq (sd) | Bet to 5.55 freq (sd) | Check EV | Bet to 2.442 EV | Bet to 5.55 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 28.1% (7.3%) | 54.9% (4.6%) | 17.0% (3.2%) | +6.516 | +6.904 | +6.830 | Bet to 2.442 − Bet to 5.55 = +0.073 | [−0.160, +0.307] | 0.005 | 0.188 | not evaluated | 1.9% | 4.15 | 17.66 | 0.00 | unresolved | no |
| 1,000,000 | 5 | 20.1% (0.9%) | 69.5% (2.9%) | 10.5% (2.2%) | +6.050 | +6.279 | +6.332 | Bet to 5.55 − Bet to 2.442 = +0.053 | [−0.058, +0.164] | 0.005 | 0.089 | not evaluated | 0.6% | 17.69 | 17.81 | 0.00 | unresolved | no |
| 4,000,000 | 5 | 15.2% (1.4%) | 82.1% (1.5%) | 2.7% (0.3%) | +5.848 | +6.136 | +6.111 | Bet to 2.442 − Bet to 5.55 = +0.025 | [−0.036, +0.087] | 0.005 | 0.048 | 0.0540 ± 0.0106 se | 0.3% | 72.15 | 18.43 | 67.31 | unresolved | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Unresolved: Bet to 2.442 82%, Check 15%, Bet to 5.55 3%. EV gap Bet to 2.442 − Bet to 5.55 = +0.025 BB, 95% [−0.036, +0.087]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

### flop3-kings / wider-range — The big blind calls preflop with a wider range: 15 more offsuit and suited classes (K7o, K6o:0.5, Q8o, J8o, T8o, 97o, 86o:0.5, 76o, Q7s, J7s, T7s, 96s, 85s, 74s:0.5, 53s).

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Check freq (sd) | Bet to 2.442 freq (sd) | Bet to 5.55 freq (sd) | Check EV | Bet to 2.442 EV | Bet to 5.55 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 25.1% (8.7%) | 56.1% (9.2%) | 18.8% (3.3%) | +6.614 | +6.992 | +6.882 | Bet to 2.442 − Bet to 5.55 = +0.110 | [−0.065, +0.284] | 0.005 | 0.140 | not evaluated | 2.2% | 4.14 | 18.29 | 0.00 | unresolved | no |
| 1,000,000 | 5 | 17.5% (2.2%) | 68.1% (4.0%) | 14.4% (2.4%) | +6.543 | +6.832 | +6.771 | Bet to 2.442 − Bet to 5.55 = +0.060 | [−0.068, +0.189] | 0.005 | 0.103 | not evaluated | 0.7% | 17.84 | 18.85 | 0.00 | unresolved | no |
| 4,000,000 | 5 | 11.7% (1.4%) | 83.2% (2.1%) | 5.1% (1.9%) | +6.328 | +6.604 | +6.585 | Bet to 2.442 − Bet to 5.55 = +0.019 | [−0.046, +0.083] | 0.005 | 0.051 | 0.0303 ± 0.0106 se | 0.2% | 75.70 | 19.14 | 76.21 | unresolved | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Unresolved: Bet to 2.442 83%, Check 12%, Bet to 5.55 5%. EV gap Bet to 2.442 − Bet to 5.55 = +0.019 BB, 95% [−0.046, +0.083]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

### flop3-kings / added-size — A 125% pot overbet is added on the flop (33%, 75% and 125% pot).

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Check freq (sd) | Bet to 2.442 freq (sd) | Bet to 5.55 freq (sd) | Bet to 9.25 freq (sd) | Check EV | Bet to 2.442 EV | Bet to 5.55 EV | Bet to 9.25 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 28.9% (2.6%) | 57.5% (4.9%) | 12.6% (3.2%) | 1.0% (1.2%) | +6.377 | +6.548 | +6.492 | +6.004 | Bet to 2.442 − Bet to 5.55 = +0.057 | [−0.230, +0.344] | 0.004 | 0.231 | not evaluated | 2.1% | 4.64 | 19.89 | 0.00 | unresolved | no |
| 1,000,000 | 5 | 20.0% (3.2%) | 70.3% (3.2%) | 9.3% (2.3%) | 0.4% (0.5%) | +6.082 | +6.340 | +6.272 | +6.021 | Bet to 2.442 − Bet to 5.55 = +0.068 | [−0.040, +0.177] | 0.005 | 0.086 | not evaluated | 0.6% | 19.65 | 20.18 | 0.00 | unresolved | no |
| 4,000,000 | 5 | 15.1% (0.8%) | 81.9% (1.0%) | 2.9% (0.9%) | 0.1% (0.0%) | +5.896 | +6.174 | +6.121 | +5.951 | Bet to 2.442 − Bet to 5.55 = +0.053 | [−0.042, +0.148] | 0.005 | 0.076 | 0.0453 ± 0.0108 se | 0.2% | 79.18 | 20.66 | 76.51 | unresolved | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Unresolved: Bet to 2.442 82%, Check 15%, Bet to 5.55 3%. EV gap Bet to 2.442 − Bet to 5.55 = +0.053 BB, 95% [−0.042, +0.148]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

## flop3-kings-small — Three-way flop K-8-5, small exact companion (five weighted hands per seat, flop betting only)

- as flop3-kings: SB checks, BB checks, button to act on Ks 8d 5h (pot 7.4 BB).
- Seeds 5211, 5212, 5213, 5214, 5215; 1 worker thread(s) requested on 4 logical processors; total 199 s; process peak RAM 6 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.02, frequency sd ≤ 0.05, quality ≤ 0.02, stable against the previous budget.

### flop3-kings-small / baseline

EVs in **BB** (chip). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Check freq (sd) | Bet to 2.442 freq (sd) | Bet to 5.55 freq (sd) | Check EV | Bet to 2.442 EV | Bet to 5.55 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 0.2% (0.1%) | 28.0% (20.0%) | 71.9% (20.0%) | +4.519 | +5.741 | +6.233 | Bet to 5.55 − Bet to 2.442 = +0.492 | [+0.085, +0.899] | 0.000 | 0.328 | 0.1595 | 0.2% | 0.11 | 0.09 | 0.91 | ranked | no |
| 200,000 | 5 | 0.0% (0.1%) | 33.1% (36.0%) | 66.9% (36.0%) | +4.659 | +5.871 | +5.817 | Bet to 2.442 − Bet to 5.55 = +0.053 | [−0.392, +0.499] | 0.000 | 0.359 | 0.0426 | 0.0% | 1.13 | 0.11 | 1.00 | unresolved | no |
| 2,000,000 | 5 | 0.0% (0.1%) | 36.7% (39.4%) | 63.3% (39.5%) | +4.580 | +5.823 | +5.773 | Bet to 2.442 − Bet to 5.55 = +0.050 | [−0.170, +0.269] | 0.000 | 0.177 | 0.0198 | 0.0% | 11.47 | 0.09 | 0.87 | unresolved | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Unresolved: Bet to 5.55 63%, Bet to 2.442 37%. EV gap Bet to 2.442 − Bet to 5.55 = +0.050 BB, 95% [−0.170, +0.269]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

### flop3-kings-small / wider-range — The big blind range gains two weaker hands (Jh9h and 6h4h at weight 1).

EVs in **BB** (chip). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Check freq (sd) | Bet to 2.442 freq (sd) | Bet to 5.55 freq (sd) | Check EV | Bet to 2.442 EV | Bet to 5.55 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 0.1% (0.1%) | 35.7% (23.8%) | 64.1% (23.7%) | +5.134 | +6.279 | +6.167 | Bet to 2.442 − Bet to 5.55 = +0.111 | [−0.024, +0.246] | 0.000 | 0.109 | 0.1551 | 0.0% | 0.10 | 0.13 | 1.01 | unresolved | no |
| 200,000 | 5 | 0.0% (0.0%) | 26.4% (15.7%) | 73.6% (15.7%) | +5.491 | +6.824 | +6.890 | Bet to 5.55 − Bet to 2.442 = +0.066 | [−0.083, +0.215] | 0.000 | 0.120 | 0.0406 | 0.0% | 0.84 | 0.12 | 0.90 | unresolved | no |
| 2,000,000 | 5 | 0.0% (0.0%) | 25.9% (8.1%) | 74.1% (8.1%) | +5.316 | +6.451 | +6.511 | Bet to 5.55 − Bet to 2.442 = +0.060 | [−0.006, +0.126] | 0.000 | 0.053 | 0.0125 | 0.0% | 8.80 | 0.13 | 1.07 | unresolved | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Unresolved: Bet to 5.55 74%, Bet to 2.442 26%. EV gap Bet to 5.55 − Bet to 2.442 = +0.060 BB, 95% [−0.006, +0.126]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

### flop3-kings-small / added-size — A 125% pot overbet is added on the flop.

EVs in **BB** (chip). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Check freq (sd) | Bet to 2.442 freq (sd) | Bet to 5.55 freq (sd) | Bet to 9.25 freq (sd) | Check EV | Bet to 2.442 EV | Bet to 5.55 EV | Bet to 9.25 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 0.3% (0.5%) | 21.6% (25.0%) | 61.5% (46.9%) | 16.6% (21.9%) | +4.926 | +6.269 | +6.394 | +7.086 | Bet to 9.25 − Bet to 5.55 = +0.691 | [−1.238, +2.620] | 0.000 | 1.554 | 0.2672 | 0.6% | 0.09 | 0.10 | 1.01 | unresolved | no |
| 200,000 | 5 | 0.3% (0.6%) | 26.2% (32.7%) | 28.1% (40.6%) | 45.5% (38.3%) | +5.090 | +6.789 | +7.665 | +7.542 | Bet to 5.55 − Bet to 9.25 = +0.123 | [−0.867, +1.113] | 0.000 | 0.797 | 0.0679 | 0.6% | 0.97 | 0.13 | 1.05 | unresolved | no |
| 2,000,000 | 5 | 0.0% (0.0%) | 15.5% (18.4%) | 32.5% (41.5%) | 52.0% (44.3%) | +5.022 | +6.771 | +7.488 | +7.801 | Bet to 9.25 − Bet to 5.55 = +0.313 | [−1.336, +1.962] | 0.000 | 1.328 | 0.0196 | 0.7% | 9.73 | 0.11 | 0.97 | unresolved | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Unresolved: Bet to 9.25 52%, Bet to 5.55 33%, Bet to 2.442 15%. EV gap Bet to 9.25 − Bet to 5.55 = +0.313 BB, 95% [−1.336, +1.962]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

## flop3-kings-detailed — Three-way flop K-8-5, Detailed hand groups (kept as specified first: exceeds the memory budget)

- as flop3-kings: SB checks, BB checks, button to act on Ks 8d 5h (pot 7.4 BB).
- Seeds 5211, 5212; 1 worker thread(s) requested on 4 logical processors; total 371 s; process peak RAM 1548 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.05, frequency sd ≤ 0.05, stable against the previous budget.

### flop3-kings-detailed / baseline

EVs in **BB** (chip). Quality metric: none — not evaluated.

| Budget (deals) | Seeds | Check freq (sd) | Bet to 2.442 freq (sd) | Bet to 5.55 freq (sd) | Check EV | Bet to 2.442 EV | Bet to 5.55 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1,000,000 | 2 | 31.9% (3.2%) | 48.4% (4.6%) | 19.7% (1.4%) | +5.834 | +5.817 | +5.517 | Check − Bet to 2.442 = +0.017 | [−1.275, +1.309] | 0.017 | 0.142 | not evaluated | 83.0% | 40.92 | 7.87 | 0.00 | unresolved | no |
| 4,000,000 (**2 seed(s) stopped at the table budget, at most 3,696,343 deals**) | 2 | 49.4% (6.6%) | 40.2% (6.8%) | 10.4% (0.2%) | +5.975 | +6.061 | +5.740 | Bet to 2.442 − Check = +0.087 | [−0.163, +0.336] | 0.019 | 0.007 | not evaluated | 58.9% | 167.42 | 10.07 | 0.00 | unresolved | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Unresolved: Check 49%, Bet to 2.442 40%, Bet to 5.55 10%. EV gap Bet to 2.442 − Check = +0.087 BB, 95% [−0.163, +0.336]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

## flop6-jack — Six-way flop J-8-4 rainbow, preflop raiser with top pair top kicker after two checks

- Preflop: UTG folds, UTG+1 raises to 2, MP folds, HJ, CO, BTN, SB and BB call (pot 12.8 BB). Flop Jh 8d 4c: SB checks, BB checks. UTG+1 to act with three players behind.
- Seeds 5221, 5222, 5223, 5224, 5225; 1 worker thread(s) requested on 4 logical processors; total 3440 s; process peak RAM 124 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.05, frequency sd ≤ 0.05, stable against the previous budget.

### flop6-jack / baseline

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Check freq (sd) | Bet to 4.224 freq (sd) | Bet to 8.448 freq (sd) | Check EV | Bet to 4.224 EV | Bet to 8.448 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 34.5% (8.8%) | 38.3% (7.3%) | 27.2% (6.8%) | +9.646 | +9.593 | +9.631 | Check − Bet to 8.448 = +0.015 | [−0.114, +0.145] | 0.009 | 0.103 | not evaluated | 6.6% | 11.30 | 7.68 | 0.00 | unresolved | no |
| 1,000,000 | 5 | 30.1% (4.0%) | 32.6% (6.7%) | 37.3% (7.4%) | +8.917 | +8.916 | +9.011 | Bet to 8.448 − Check = +0.094 | [−0.047, +0.235] | 0.008 | 0.112 | not evaluated | 2.1% | 47.56 | 7.56 | 0.00 | unresolved | no |
| 4,000,000 | 5 | 30.4% (3.3%) | 31.4% (4.5%) | 38.2% (2.6%) | +8.458 | +8.230 | +8.356 | Check − Bet to 8.448 = +0.101 | [+0.034, +0.169] | 0.008 | 0.051 | −0.0984 ± 0.0152 se | 0.6% | 191.09 | 7.61 | 7.13 | smallEdge | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Small edge for Check: Bet to 8.448 38%, Bet to 4.224 31%, Check 30%. EV gap Check − Bet to 8.448 = +0.101 BB, 95% [+0.034, +0.169]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

### flop6-jack / wider-range — The button (the last caller) holds a wider range: 15 more classes (22, A6s, A2s, K8s, Q8s, J7s, T7s, 96s, 65s, 54s:0.5, KTo, QTo, J9o, T9o:0.5, A9o:0.5).

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Check freq (sd) | Bet to 4.224 freq (sd) | Bet to 8.448 freq (sd) | Check EV | Bet to 4.224 EV | Bet to 8.448 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 27.8% (6.8%) | 37.6% (6.2%) | 34.7% (4.3%) | +10.433 | +10.463 | +10.333 | Bet to 4.224 − Check = +0.030 | [−0.200, +0.259] | 0.009 | 0.184 | not evaluated | 7.1% | 10.66 | 7.20 | 0.00 | unresolved | no |
| 1,000,000 | 5 | 21.1% (1.7%) | 32.0% (7.0%) | 46.9% (8.6%) | +9.903 | +9.769 | +9.843 | Check − Bet to 8.448 = +0.061 | [−0.023, +0.144] | 0.008 | 0.065 | not evaluated | 2.4% | 43.86 | 7.74 | 0.00 | unresolved | no |
| 4,000,000 | 5 | 21.2% (3.7%) | 26.7% (5.6%) | 52.1% (6.8%) | +9.258 | +9.103 | +9.239 | Check − Bet to 8.448 = +0.019 | [−0.157, +0.196] | 0.008 | 0.141 | −0.0334 ± 0.0151 se | 0.8% | 177.75 | 7.46 | 7.91 | unresolved | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Unresolved: Bet to 8.448 52%, Bet to 4.224 27%, Check 21%. EV gap Check − Bet to 8.448 = +0.019 BB, 95% [−0.157, +0.196]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

### flop6-jack / added-size — A pot-size bet (100% pot) is added on the flop (33%, 66% and 100% pot).

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Check freq (sd) | Bet to 4.224 freq (sd) | Bet to 8.448 freq (sd) | Bet to 12.8 freq (sd) | Check EV | Bet to 4.224 EV | Bet to 8.448 EV | Bet to 12.8 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 250,000 | 5 | 33.9% (1.9%) | 31.2% (5.1%) | 26.7% (4.6%) | 8.2% (4.5%) | +9.757 | +9.591 | +9.514 | +9.256 | Check − Bet to 4.224 = +0.166 | [+0.072, +0.260] | 0.009 | 0.073 | not evaluated | 7.8% | 13.26 | 8.88 | 0.00 | ranked | no |
| 1,000,000 | 5 | 29.9% (2.7%) | 30.3% (4.6%) | 35.4% (7.1%) | 4.5% (2.4%) | +9.111 | +9.026 | +9.089 | +8.919 | Check − Bet to 8.448 = +0.022 | [−0.135, +0.179] | 0.009 | 0.125 | not evaluated | 2.2% | 55.46 | 9.28 | 0.00 | unresolved | no |
| 4,000,000 | 5 | 29.0% (2.6%) | 24.9% (4.0%) | 43.8% (5.5%) | 2.3% (0.7%) | +8.472 | +8.241 | +8.355 | +8.302 | Check − Bet to 8.448 = +0.117 | [+0.025, +0.209] | 0.008 | 0.072 | −0.1220 ± 0.0171 se | 0.6% | 222.97 | 9.24 | 8.53 | smallEdge | no |

**tolerance not reached; last measured budget 4000000 sampled deals.** Small edge for Check: Bet to 8.448 44%, Check 29%, Bet to 4.224 25%, Bet to 12.8 2%. EV gap Check − Bet to 8.448 = +0.117 BB, 95% [+0.025, +0.209]. Declared tolerance NOT reached; last measured budget 4,000,000 deals.

## flop6-jack-small — Six-way flop J-8-4, small exact companion (three weighted hands per seat, flop betting only)

- as flop6-jack: SB checks, BB checks, UTG+1 to act on Jh 8d 4c (pot 12.8 BB).
- Seeds 5221, 5222, 5223, 5224, 5225; 1 worker thread(s) requested on 4 logical processors; total 3754 s; process peak RAM 14 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.02, frequency sd ≤ 0.05, quality ≤ 0.05, stable against the previous budget.

### flop6-jack-small / baseline

EVs in **BB** (chip). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Check freq (sd) | Bet to 4.224 freq (sd) | Bet to 8.448 freq (sd) | Check EV | Bet to 4.224 EV | Bet to 8.448 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 8.3% (4.7%) | 54.9% (17.7%) | 36.8% (18.4%) | +4.539 | +5.326 | +5.202 | Bet to 4.224 − Bet to 8.448 = +0.124 | [−0.188, +0.435] | 0.000 | 0.251 | 0.7018 | 2.4% | 0.19 | 13.47 | 46.65 | unresolved | no |
| 200,000 | 5 | 2.9% (2.8%) | 46.7% (15.9%) | 50.4% (16.0%) | +5.245 | +5.799 | +5.955 | Bet to 8.448 − Bet to 4.224 = +0.156 | [−0.164, +0.477] | 0.000 | 0.258 | 0.2135 | 0.0% | 1.73 | 13.25 | 46.92 | unresolved | no |
| 2,000,000 | 5 | 0.9% (1.6%) | 50.5% (23.2%) | 48.6% (24.3%) | +5.176 | +5.760 | +5.847 | Bet to 8.448 − Bet to 4.224 = +0.088 | [−0.198, +0.374] | 0.000 | 0.230 | 0.1774 | 0.0% | 17.41 | 13.26 | 46.58 | unresolved | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Unresolved: Bet to 4.224 51%, Bet to 8.448 49%, Check 1%. EV gap Bet to 8.448 − Bet to 4.224 = +0.088 BB, 95% [−0.198, +0.374]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

### flop6-jack-small / wider-range — The button range gains a weaker hand (Tc7c at weight 1).

EVs in **BB** (chip). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Check freq (sd) | Bet to 4.224 freq (sd) | Bet to 8.448 freq (sd) | Check EV | Bet to 4.224 EV | Bet to 8.448 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 13.6% (10.0%) | 50.3% (20.8%) | 36.1% (21.6%) | +4.724 | +5.470 | +5.421 | Bet to 4.224 − Bet to 8.448 = +0.048 | [−0.420, +0.517] | 0.000 | 0.378 | 0.7456 | 1.5% | 0.21 | 18.39 | 64.18 | unresolved | no |
| 200,000 | 5 | 1.9% (1.9%) | 75.1% (26.3%) | 23.0% (27.2%) | +4.884 | +5.252 | +5.146 | Bet to 4.224 − Bet to 8.448 = +0.106 | [−0.212, +0.423] | 0.000 | 0.256 | 0.1648 | 0.0% | 2.15 | 17.44 | 56.19 | unresolved | no |
| 2,000,000 | 5 | 0.2% (0.2%) | 98.7% (2.3%) | 1.1% (2.2%) | +4.871 | +5.205 | +5.098 | Bet to 4.224 − Bet to 8.448 = +0.107 | [−0.196, +0.411] | 0.000 | 0.244 | 0.0408 | 0.0% | 17.79 | 16.87 | 64.76 | unresolved | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Unresolved: Bet to 4.224 99%, Bet to 8.448 1%. EV gap Bet to 4.224 − Bet to 8.448 = +0.107 BB, 95% [−0.196, +0.411]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

### flop6-jack-small / added-size — A pot-size bet (100% pot) is added on the flop.

EVs in **BB** (chip). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Check freq (sd) | Bet to 4.224 freq (sd) | Bet to 8.448 freq (sd) | Bet to 12.8 freq (sd) | Check EV | Bet to 4.224 EV | Bet to 8.448 EV | Bet to 12.8 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 21.5% (14.1%) | 55.9% (10.4%) | 19.1% (11.9%) | 3.5% (1.3%) | +4.979 | +5.779 | +5.939 | +4.874 | Bet to 8.448 − Bet to 4.224 = +0.161 | [−0.293, +0.614] | 0.000 | 0.365 | 0.8779 | 2.0% | 0.23 | 21.30 | 72.48 | unresolved | no |
| 200,000 | 5 | 1.8% (1.4%) | 37.9% (24.5%) | 60.0% (24.1%) | 0.4% (0.3%) | +5.082 | +5.905 | +6.167 | +5.029 | Bet to 8.448 − Bet to 4.224 = +0.262 | [−0.462, +0.986] | 0.000 | 0.583 | 0.2712 | 0.1% | 2.14 | 21.19 | 71.63 | unresolved | no |
| 2,000,000 | 5 | 0.1% (0.2%) | 58.7% (24.5%) | 41.2% (24.5%) | 0.0% (0.0%) | +4.508 | +5.784 | +5.962 | +5.220 | Bet to 8.448 − Bet to 4.224 = +0.177 | [−0.006, +0.361] | 0.000 | 0.148 | 0.1101 | 0.0% | 20.05 | 20.08 | 70.90 | unresolved | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Unresolved: Bet to 4.224 59%, Bet to 8.448 41%. EV gap Bet to 8.448 − Bet to 4.224 = +0.177 BB, 95% [−0.006, +0.361]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

## icm8-bb-call — Eight-handed final table: big blind (18 BB) facing a button all-in, ICM with a chip-EV comparison

- UTG, UTG+1, MP, HJ and CO fold. BTN (40 BB) moves all-in, SB (12 BB) folds. Big blind (18 BB) to act: call or fold.
- Seeds 5231, 5232, 5233, 5234, 5235; 1 worker thread(s) requested on 4 logical processors; total 2341 s; process peak RAM 74 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.05, frequency sd ≤ 0.05, stable against the previous budget.

### icm8-bb-call / baseline

EVs in **percent of the prize pool** (icm). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Call 17.9 freq (sd) | Fold EV | Call 17.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 500,000 | 5 | 32.0% (22.3%) | 68.0% (22.3%) | +11.554 | +11.581 | Call 17.9 − Fold = +0.026 | [−0.019, +0.071] | 0.002 | 0.036 | 0.0214 ± 0.0008 se | 0.0% | 3.78 | 1.31 | 5.61 | unresolved | no |
| 2,000,000 | 5 | 32.6% (34.0%) | 67.4% (34.0%) | +11.554 | +11.597 | Call 17.9 − Fold = +0.042 | [−0.001, +0.085] | 0.002 | 0.034 | 0.0087 ± 0.0007 se | 0.0% | 14.88 | 1.20 | 5.48 | unresolved | no |
| 8,000,000 | 5 | 29.0% (27.8%) | 71.0% (27.8%) | +11.554 | +11.598 | Call 17.9 − Fold = +0.044 | [+0.033, +0.055] | 0.002 | 0.008 | 0.0016 ± 0.0007 se | 0.0% | 66.82 | 1.31 | 6.04 | smallEdge | no |

**tolerance not reached; last measured budget 8000000 sampled deals.** Small edge for Call 17.9: Call 17.9 71%, Fold 29%. EV gap Call 17.9 − Fold = +0.044 percent of the prize pool, 95% [+0.033, +0.055]. Declared tolerance NOT reached; last measured budget 8,000,000 deals.

### icm8-bb-call / wider-range — No bunching weights: every hand of BTN, SB and BB at weight 1 (weak hands 11% more frequent).

EVs in **percent of the prize pool** (icm). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Call 17.9 freq (sd) | Fold EV | Call 17.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 500,000 | 5 | 33.1% (22.7%) | 66.9% (22.7%) | +11.554 | +11.591 | Call 17.9 − Fold = +0.037 | [+0.007, +0.068] | 0.002 | 0.024 | 0.0201 ± 0.0008 se | 0.0% | 5.18 | 1.80 | 6.82 | smallEdge | no |
| 2,000,000 | 5 | 26.3% (14.8%) | 73.7% (14.8%) | +11.554 | +11.616 | Call 17.9 − Fold = +0.062 | [+0.025, +0.099] | 0.002 | 0.029 | 0.0076 ± 0.0007 se | 0.0% | 22.94 | 1.82 | 7.35 | smallEdge | no |
| 8,000,000 | 5 | 2.7% (2.5%) | 97.3% (2.5%) | +11.554 | +11.619 | Call 17.9 − Fold = +0.065 | [+0.049, +0.080] | 0.002 | 0.012 | −0.0001 ± 0.0007 se | 0.0% | 100.02 | 1.54 | 6.33 | smallEdge | no |

**tolerance not reached; last measured budget 8000000 sampled deals.** Small edge for Call 17.9: Call 17.9 97%, Fold 3%. EV gap Call 17.9 − Fold = +0.065 percent of the prize pool, 95% [+0.049, +0.080]. Declared tolerance NOT reached; last measured budget 8,000,000 deals.

### icm8-bb-call / added-size — The button may also raise to 2.2 BB instead of moving all-in (blinds can call or re-raise all-in; one all-in bet on the flop).

EVs in **percent of the prize pool** (icm). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Call 17.9 freq (sd) | Fold EV | Call 17.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 500,000 | 5 | 28.4% (28.4%) | 71.6% (28.4%) | +11.554 | +11.764 | Call 17.9 − Fold = +0.210 | [+0.136, +0.284] | 0.002 | 0.059 | 0.0353 ± 0.0008 se | 0.0% | 4.44 | 1.07 | 39.64 | ranked | no |
| 2,000,000 | 5 | 5.9% (4.7%) | 94.1% (4.7%) | +11.554 | +11.744 | Call 17.9 − Fold = +0.190 | [+0.133, +0.247] | 0.002 | 0.046 | 0.0206 ± 0.0008 se | 0.0% | 18.33 | 1.08 | 40.05 | ranked | no |
| 8,000,000 | 5 | 0.4% (0.2%) | 99.6% (0.2%) | +11.554 | +11.720 | Call 17.9 − Fold = +0.166 | [+0.127, +0.205] | 0.002 | 0.031 | 0.0065 ± 0.0008 se | 0.0% | 72.06 | 1.07 | 40.07 | ranked | no |

**tolerance not reached; last measured budget 8000000 sampled deals.** Prefer Call 17.9: Call 17.9 100%. EV gap Call 17.9 − Fold = +0.166 percent of the prize pool, 95% [+0.127, +0.205]. Declared tolerance NOT reached; last measured budget 8,000,000 deals.

### icm8-bb-call / chip-ev — Same stacks, ranges and actions, but utilities are chips (BB) instead of ICM prize share.

EVs in **BB** (chip). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Call 17.9 freq (sd) | Fold EV | Call 17.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 500,000 | 5 | 0.1% (0.2%) | 99.9% (0.2%) | −1.100 | +3.027 | Call 17.9 − Fold = +4.127 | [+4.030, +4.225] | 0.006 | 0.078 | 0.0029 ± 0.0033 se | 0.0% | 2.63 | 0.96 | 4.12 | ranked | no |
| 2,000,000 | 5 | 0.0% (0.0%) | 100.0% (0.0%) | −1.100 | +3.012 | Call 17.9 − Fold = +4.112 | [+4.076, +4.148] | 0.006 | 0.026 | −0.0291 ± 0.0036 se | 0.0% | 10.78 | 0.99 | 4.15 | ranked | yes |
| 8,000,000 | 5 | 0.0% (0.0%) | 100.0% (0.0%) | −1.100 | +2.982 | Call 17.9 − Fold = +4.082 | [+4.008, +4.156] | 0.006 | 0.059 | −0.0373 ± 0.0038 se | 0.0% | 44.13 | 0.97 | 4.10 | ranked | no |

**tolerance first met at 2000000 sampled deals.** Prefer Call 17.9: Call 17.9 100%. EV gap Call 17.9 − Fold = +4.112 BB, 95% [+4.076, +4.148]. Declared tolerance first met at 2,000,000 deals.

## icm8-bb-call-small — Eight-handed final table, small exact companion (four or five weighted hands per seat)

- UTG, UTG+1, MP, HJ and CO fold. BTN (40 BB) moves all-in, SB (12 BB) folds. Big blind (18 BB) to act: call or fold.
- Seeds 5231, 5232, 5233, 5234, 5235; 1 worker thread(s) requested on 4 logical processors; total 1337 s; process peak RAM 510 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.02, frequency sd ≤ 0.05, quality ≤ 0.02, stable against the previous budget.

### icm8-bb-call-small / baseline

EVs in **percent of the prize pool** (icm). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Fold freq (sd) | Call 17.9 freq (sd) | Fold EV | Call 17.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 100.0% (0.0%) | 0.0% (0.0%) | +11.554 | +10.858 | Fold − Call 17.9 = +0.697 | [+0.548, +0.846] | 0.000 | 0.120 | 0.0398 | 0.0% | 0.03 | 1.47 | 14.89 | ranked | no |
| 200,000 | 5 | 100.0% (0.0%) | 0.0% (0.0%) | +11.554 | +10.827 | Fold − Call 17.9 = +0.727 | [+0.714, +0.741] | 0.000 | 0.011 | 0.0034 | 0.0% | 0.38 | 1.62 | 15.13 | ranked | no |
| 2,000,000 | 5 | 100.0% (0.0%) | 0.0% (0.0%) | +11.554 | +10.830 | Fold − Call 17.9 = +0.724 | [+0.724, +0.725] | 0.000 | 0.000 | 0.0000 | 0.0% | 3.93 | 1.76 | 14.66 | ranked | yes |

**tolerance first met at 2000000 sampled deals.** Prefer Fold: Fold 100%. EV gap Fold − Call 17.9 = +0.724 percent of the prize pool, 95% [+0.724, +0.725]. Declared tolerance first met at 2,000,000 deals.

### icm8-bb-call-small / wider-range — The button range gains a weaker hand (Jc6c at weight 1).

EVs in **percent of the prize pool** (icm). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Fold freq (sd) | Call 17.9 freq (sd) | Fold EV | Call 17.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 99.7% (0.7%) | 0.3% (0.7%) | +11.554 | +10.922 | Fold − Call 17.9 = +0.632 | [+0.489, +0.775] | 0.000 | 0.115 | 0.0408 | 0.0% | 0.06 | 3.37 | 28.21 | ranked | no |
| 200,000 | 5 | 100.0% (0.0%) | 0.0% (0.0%) | +11.554 | +10.911 | Fold − Call 17.9 = +0.644 | [+0.629, +0.659] | 0.000 | 0.012 | 0.0040 | 0.0% | 0.59 | 3.27 | 30.98 | ranked | yes |
| 2,000,000 | 5 | 100.0% (0.0%) | 0.0% (0.0%) | +11.554 | +10.920 | Fold − Call 17.9 = +0.635 | [+0.635, +0.635] | 0.000 | 0.000 | 0.0000 | 0.0% | 6.13 | 3.27 | 32.02 | ranked | yes |

**tolerance first met at 200000 sampled deals.** Prefer Fold: Fold 100%. EV gap Fold − Call 17.9 = +0.644 percent of the prize pool, 95% [+0.629, +0.659]. Declared tolerance first met at 200,000 deals.

### icm8-bb-call-small / added-size — The button may also raise to 2.2 BB instead of moving all-in (postflop checked down). The quality metric of this variant is sampled: exact best response exceeds the work limit once a 2.2 BB raise can reach the flop.

EVs in **percent of the prize pool** (icm). Quality metric: sampled — sum of sampled one-shot deviation gains (one decision node per seat, continuation unchanged).

| Budget (deals) | Seeds | Fold freq (sd) | Call 17.9 freq (sd) | Fold EV | Call 17.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 96.7% (5.2%) | 3.3% (5.2%) | +11.554 | +11.153 | Fold − Call 17.9 = +0.402 | [+0.270, +0.534] | 0.000 | 0.106 | 0.0515 ± 0.0008 se | 0.0% | 0.10 | 3.27 | 0.75 | ranked | no |
| 200,000 | 5 | 100.0% (0.0%) | 0.0% (0.0%) | +11.554 | +10.924 | Fold − Call 17.9 = +0.630 | [+0.556, +0.705] | 0.000 | 0.060 | 0.0120 ± 0.0003 se | 0.0% | 0.89 | 3.44 | 0.88 | ranked | no |
| 2,000,000 | 5 | 100.0% (0.0%) | 0.0% (0.0%) | +11.554 | +10.836 | Fold − Call 17.9 = +0.719 | [+0.711, +0.726] | 0.000 | 0.006 | 0.0004 ± 0.0000 se | 0.0% | 8.46 | 3.23 | 0.94 | ranked | no |

**tolerance not reached; last measured budget 2000000 sampled deals.** Prefer Fold: Fold 100%. EV gap Fold − Call 17.9 = +0.719 percent of the prize pool, 95% [+0.711, +0.726]. Declared tolerance NOT reached; last measured budget 2,000,000 deals.

### icm8-bb-call-small / chip-ev — Same spot with chip utilities (BB) instead of ICM prize share.

EVs in **BB** (chip). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Fold freq (sd) | Call 17.9 freq (sd) | Fold EV | Call 17.9 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20,000 | 5 | 1.3% (1.5%) | 98.7% (1.5%) | −1.100 | −0.378 | Call 17.9 − Fold = +0.722 | [+0.600, +0.844] | 0.000 | 0.098 | 0.0837 | 0.0% | 0.06 | 2.95 | 23.97 | ranked | no |
| 200,000 | 5 | 0.0% (0.0%) | 100.0% (0.0%) | −1.100 | −0.618 | Call 17.9 − Fold = +0.482 | [+0.480, +0.483] | 0.000 | 0.001 | 0.0083 | 0.0% | 0.56 | 2.95 | 26.91 | ranked | no |
| 2,000,000 | 5 | 0.0% (0.0%) | 100.0% (0.0%) | −1.100 | −0.621 | Call 17.9 − Fold = +0.479 | [+0.479, +0.479] | 0.000 | 0.000 | 0.0026 | 0.0% | 4.98 | 2.63 | 21.37 | ranked | yes |

**tolerance first met at 2000000 sampled deals.** Prefer Call 17.9: Call 17.9 100%. EV gap Call 17.9 − Fold = +0.479 BB, 95% [+0.479, +0.479]. Declared tolerance first met at 2,000,000 deals.

## known-akq-river — Known small game: A-K-Q river (closed-form mixed equilibrium)

- River 2c 3d 7h 8s 9c, pot 10 BB (9.8 BB plus two 0.1 BB antes). Seat 1 (aces or queens, equally likely) bets 10 BB (pot). Seat 2 (kings) to act: call or fold.
- Seeds 1, 2, 3, 4, 5, 6; 1 worker thread(s) requested on 4 logical processors; total 24 s; process peak RAM 6 MiB.
- Declared tolerance: EV gap interval half-width ≤ 0.05, frequency sd ≤ 0.05, quality ≤ 0.02, stable against the previous budget.

### known-akq-river / baseline

EVs in **BB** (chip). Quality metric: exact — sum of exact unilateral best-response gains of every seat inside this abstraction.

| Budget (deals) | Seeds | Fold freq (sd) | Call 10 freq (sd) | Fold EV | Call 10 EV | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1,000 | 6 | 49.2% (3.2%) | 50.8% (3.2%) | 0.000 | +0.311 | Call 10 − Fold = +0.311 | [−0.345, +0.968] | 0.000 | 0.626 | 0.3940 | 0.0% | 0.00 | 0.00 | 0.00 | unresolved | no |
| 10,000 | 6 | 50.5% (1.3%) | 49.5% (1.3%) | 0.000 | +0.100 | Call 10 − Fold = +0.100 | [−0.096, +0.296] | 0.000 | 0.187 | 0.1090 | 0.0% | 0.01 | 0.00 | 0.00 | unresolved | no |
| 100,000 | 6 | 49.9% (0.4%) | 50.1% (0.4%) | 0.000 | +0.051 | Call 10 − Fold = +0.051 | [+0.008, +0.094] | 0.000 | 0.041 | 0.0324 | 0.0% | 0.21 | 0.00 | 0.00 | smallEdge | no |
| 1,000,000 | 6 | 49.9% (0.1%) | 50.1% (0.1%) | 0.000 | −0.002 | Fold − Call 10 = +0.002 | [−0.008, +0.013] | 0.000 | 0.010 | 0.0079 | 0.0% | 1.11 | 0.00 | 0.00 | nearTie | no |
| 4,000,000 | 6 | 50.0% (0.1%) | 50.0% (0.1%) | 0.000 | −0.002 | Fold − Call 10 = +0.002 | [−0.015, +0.019] | 0.000 | 0.017 | 0.0092 | 0.0% | 4.05 | 0.00 | 0.00 | nearTie | yes |

**tolerance first met at 4000000 sampled deals.** Mix (EVs within tolerance): Fold 50%, Call 10 50%. EV gap Fold − Call 10 = +0.002 BB, 95% [−0.015, +0.019]. Declared tolerance first met at 4,000,000 deals.

## Training time on an idle machine

Cumulative training time of the baseline variant, first seed, on the 5.2 development machine (4 logical CPUs, Intel(R) Xeon(R) Processor @ 2.10GHz) with no other load, 1 worker thread(s) requested. The default trainer commits one deal per update and uses one worker whatever is requested.

| Study | Deals | Training seconds | Worker threads | Peak RSS (MiB) |
|---|---|---|---|---|
| btn25-open-small | 20,000 | 0.05 | 1 | 5 |
| btn25-open-small | 200,000 | 0.50 | 1 | 6 |
| btn25-open-small | 2,000,000 | 4.78 | 1 | 5 |
| btn25-open | 250,000 | 3.82 | 1 | 171 |
| btn25-open | 1,000,000 | 17.81 | 1 | 315 |
| btn25-open | 4,000,000 | 80.80 | 1 | 759 |
| flop3-kings-detailed | 1,000,000 | 34.81 | 1 | 686 |
| flop3-kings-detailed | 4,000,000 | 104.36 | 1 | 1313 |
| flop3-kings-small | 20,000 | 0.06 | 1 | 5 |
| flop3-kings-small | 200,000 | 0.65 | 1 | 6 |
| flop3-kings-small | 2,000,000 | 6.09 | 1 | 6 |
| flop3-kings | 250,000 | 4.24 | 1 | 26 |
| flop3-kings | 1,000,000 | 17.18 | 1 | 25 |
| flop3-kings | 4,000,000 | 68.96 | 1 | 29 |
| flop6-jack-small | 20,000 | 0.20 | 1 | 9 |
| flop6-jack-small | 200,000 | 2.03 | 1 | 7 |
| flop6-jack-small | 2,000,000 | 20.61 | 1 | 7 |
| flop6-jack | 250,000 | 9.72 | 1 | 46 |
| flop6-jack | 1,000,000 | 36.22 | 1 | 51 |
| flop6-jack | 4,000,000 | 150.18 | 1 | 54 |
| icm8-bb-call-small | 20,000 | 0.06 | 1 | 5 |
| icm8-bb-call-small | 200,000 | 0.38 | 1 | 6 |
| icm8-bb-call-small | 2,000,000 | 4.03 | 1 | 5 |
| icm8-bb-call | 500,000 | 2.90 | 1 | 19 |
| icm8-bb-call | 2,000,000 | 12.11 | 1 | 24 |
| icm8-bb-call | 8,000,000 | 44.72 | 1 | 28 |
| known-akq-river | 1,000 | 0.00 | 1 | 5 |
| known-akq-river | 10,000 | 0.01 | 1 | 5 |
| known-akq-river | 100,000 | 0.12 | 1 | 5 |
| known-akq-river | 1,000,000 | 1.10 | 1 | 5 |
| known-akq-river | 4,000,000 | 4.46 | 1 | 5 |

