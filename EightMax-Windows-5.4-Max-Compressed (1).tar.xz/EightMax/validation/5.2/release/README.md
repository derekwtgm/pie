# Release identity (5.2 requirement 5)

## The 5.1 difference: 1,228 manifest entries in the shipped ZIP, 1,237 in the CI summary

What the evidence shows.

- **The shipped 5.1 ZIP** (`EightMax-Windows-5.1.zip`, attached to the 5.2 request) has 1,228 entries in
  `SHA256SUMS.txt`; all 1,228 verify (checked again here, 0 failures) and your `Windows-self-test.json`
  reports `package.sha256Files = 1228`. Its three executables are byte-identical to a rebuild from its own
  source with the documented cross-compiler (MinGW-w64 GCC 13 posix): EightMax.exe `98cf77a7…`, mwcli.exe
  `b3e675bf…`, gpustress.exe `4127046b…` (done first in the 5.2 work; see `../baseline/`).
- **The CI summary** (`validation/5.1/windows-ci/run61-summary.json`: "1237 SHA-256 entries, ZIP CRC passed")
  describes a different archive: the one the workflow's *Assemble the release around the fresh host* step builds
  **on the runner**. The workflow (`.github/workflows/windows.yml` of 5.1, lines 109-160) shows what goes into it:
  1. executables compiled on the runner with the MSYS2 UCRT64 compiler (`build/fresh/*.exe`), not the release
     executables. Same build ID (the ID is a fingerprint of the source), different bytes;
  2. the repository's `source`, `validation` and `.github` folders at the tested commit (7609665);
  3. twelve files generated during the run and written into `validation/`: `fresh-windows.json`,
     `fresh-windows-host.json`, `windows-selftest47.json`, `windows-selftest48.json`, `windows-selftest49.json`,
     `windows-emz-denied-temp.json` (copied by the assemble step), `Windows-release-test.json`,
     `ACCURACY.json`, `ACCURACY.txt`, `regression-tests.json`, `regression-tests.txt` and `signature.txt`
     (written by the verify step). None of the twelve is in the shipped ZIP.
- The root-level files are the same set in both (25 release notes, 11 other documents and batch files, the three
  executables, the offline page, BUILD-INFO.json).

So 1,237 = (repository files at the CI commit) + 12 runner files, and 1,228 = (repository files at the final
commit). That gives 1,225 files at the CI commit and three evidence files added afterwards. The 5.1 notes say
that the commits after 7609665 "add only documentation and evidence", and `run61-summary.json` (which describes
that very run) is necessarily one of the three. **The run artifact itself is not available here** (the 5.1 work
could not reach the artifact host either), so the two other late files cannot be named from evidence; the
arithmetic and the workflow are consistent with this account and nothing contradicts it.

**Conclusion.** The count difference is not corruption: the two numbers describe two different archives of the
same source build ID. The real gap it exposes is that the archive CI verified was *not the file that was
shipped*: its executables came from another compiler and it carried runner-only files. "1,237 entries verified"
therefore said nothing about the download.

## What 5.2 does instead

`source/tools/release52.py` is the only way the 5.2 ZIP is made, and it is also what the Windows workflow now
calls:

1. it writes `SHA256SUMS.txt` and the deterministic ZIP;
2. it computes the SHA-256 of that file;
3. it extracts **that file** into a new empty directory and checks, on the extracted copy only: every manifest
   entry, that no unlisted file exists, executables / interface / source fingerprint, the executable hashes, and
   a smoke test of the executables (build ID of each, a decision study through `mwcli.exe` checked against the
   closed form of the known game, the 4.9 compressed-checkpoint self-test, the desktop host answering
   `/api/info` and serving the Study tab);
4. it writes `EightMax-Windows-5.2.identity.json` next to the ZIP: archive name, size and SHA-256, manifest entry
   count, manifest hash, executable hashes, build ID and the smoke results.

The identity record cannot be inside the archive it describes (it contains the archive's hash), so it is
delivered beside the ZIP as `EightMax-Windows-5.2.identity.json`, and its values are quoted in the delivery
message. Inside the archive, `SHA256SUMS.txt` and `BUILD-INFO.json` carry the manifest and the build ID; the
record ties them to one archive hash.

If CI is run on 5.2, its archive is again built from runner-compiled executables: it is a test of the source on
Windows, and the workflow comment now says so. Only an archive whose SHA-256 equals the one in the delivered
identity record is the shipped file.
