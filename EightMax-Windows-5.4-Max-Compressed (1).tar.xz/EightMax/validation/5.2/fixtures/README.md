Checkpoints written by the EightMax 5.1 release executable (mwcli.exe, build 7d08acc7eb4577ee,
SHA-256 b3e675bf...ab2f72, run under Wine 9.0 on the 5.2 development machine):
  v51-icm-150.state/.emz    icm-final8.spec.json, 150 updates, 4 threads (full traversal, ICM)
  v51-es6w-60.state/.emz    es6w-b64.spec.json, 60 updates (external sampling, batch 64)
  v51-sched-N.state         sched-2-5-16.spec.json (batchSchedule start 2, doubleEvery 5, up to 16) saved after
                            N = 4, 5, 6, 14, 15, 16 committed updates: before, at and after both batch-size changes
  v51-sched-5.emz, -15.emz  EMZ1 of the two states saved exactly at a transition
  v51-uninterrupted.sha256  SHA-256 of the 5.1 uninterrupted states (24 schedule updates, 300 ICM updates,
                            120 external-sampling updates) that a 5.2 continuation must reproduce byte for byte
tests/v52.test.js continues each of them with the 5.2 engine.
