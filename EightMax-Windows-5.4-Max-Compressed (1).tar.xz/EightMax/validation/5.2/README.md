# EightMax 5.2 validation evidence

**Where everything was measured.** One machine: Intel Xeon @ 2.30 GHz, 4 logical CPUs, 15 GiB RAM, Linux (Ubuntu
24.04), no GPU. Toolchain: GCC 13.3, MinGW-w64 GCC 13 posix (release executables), Node 22.23, Python 3.13,
Wine 9.0, Playwright Chromium. "Windows" below means the release `EightMax.exe` / `mwcli.exe` run under Wine on
that machine. **Nothing in 5.2 was run on the target PC, on Windows itself or on a physical NVIDIA GPU.** The
CUDA "test double" is a simulated driver (`source/tests/cuda_driver_fixture.cpp`). No Windows CI run was possible
(no repository access from this environment). The machine was suspended for three hours during the work
(06:31-09:45 UTC on 2026-11-15); interrupted runs were repeated from scratch and completed ones kept, which is
recorded in the logs.

**Builds named in the evidence.** The release is build **0e6886ced89b8f81**. The Linux regression, the browser checks (`ui/`), the idle timing, the release smoke test, the **sanitizer pass, the deadline trials and the promotion sweep** were all run on it. Not repeated on it: `wine/` (self-tests, v52 tests and device modes under Wine) came from the predecessor build 64104bb52e491e49, whose fingerprinted sources equal the release's except `source/tools/study_ui52.js`; the predecessor's deadline results are kept in `deadline/predecessor-64104bb/`. The decision studies and the six-player confirmation were run with earlier 5.2 builds (each result document names its build); training code did not change during 5.2.

| Path | Contents |
|---|---|
| `baseline/` | Done first. `rebuild-5.1-hashes.txt` = `shipped-5.1-hashes.txt`: the 5.1 source rebuilt here gives the shipped 5.1 executables byte for byte (build 7d08acc7eb4577ee). `uploaded-reports-summary.json`: what the uploaded Windows reports say (all for 5.1 on the target PC); `uploaded-inputs.sha256` |
| `six-player/preregistration.json` | Frozen before any confirmation run (commit 2adc613 of the 5.2 work tree): fixtures, arms, worker counts, budgets, seeds 801-812, primary comparisons, minimum meaningful improvement, control margins, handling of incomplete runs, the engine's 10,000,000-update limit |
| `six-player/plan-confirmation.json`, `confirmation.json`, `confirmation.raw.jsonl.gz`, `confirmation.log` | `tools/convergence52.js`: default, parallel64 and warm-4-256 on flop6, flop6w, the realistic flop6-jack and the controls river3-chip and turn4, at exact training wall times. Raw per-seed and per-seat data, deals, committed updates, threads used, training and evaluation seconds, peak RSS, stop reasons |
| `six-player/decision.json` | `tools/decide52.js` applies the frozen rule. Outcome: no preset, default unchanged |
| `six-player/plan-baseline-1s.json`, `baseline-1s.json`, `.log` | The 5.1 one-second confirmation re-timed on this machine (seeds 701-740; NashConv values are deterministic at equal deals and were verified against the 5.1 raw data on 186 re-evaluated checkpoints, 0 mismatches) |
| `studies/*.result.json`, `*.summary.txt` | `mwcli --study` of every fixture: raw per-seed measurements and aggregates. `STUDY-RESULTS.md`: the readable report (`tools/study_report52.js`). `idle-timing.json`: training time and memory of each study re-measured with no other load (`tools/timing52.js`) |
| `ui/linux/`, `ui/wine/`, `ui/wine-first-run-tool-race/` | `tools/study_ui52.js`: the Study tab driven in Chromium against the Linux host and against `EightMax.exe` under Wine: every fixture opened from its file, opened in the Multiway tab and solved (the specification sent to the engine equals the fixture's; the engine reaches the advertised decision), studies run from the page, every displayed number compared with the result document, JSON and CSV exports compared. `study-ui.json` and screenshots. `wine-first-run-tool-race/study-ui.json`: the first Wine run on the predecessor build, 89 of 91: the tool compared the page with the previous study's result because it did not wait for the new one (a defect of the tool on a slow host, fixed in the release build) |
| `deadline/deadline52-release.json.gz`, `.log` | `tools/deadline52.js`, 100 trials idle and 100 with 8 busy processes (2,200 deadline queries each) with the worker-stage and join telemetry and the stall detector |
| `deadline/deadline52-before-fix.json.gz` | The same on the build before the promotion fix (where the long section was found) |
| `deadline/promotion52-final.json`, `.log` | `tools/promotion52.js`: stop latency when the stop falls into a coverage-tier promotion, 5.2 against the 5.1 behaviour, 1 and 2 workers |
| `fixtures/` | Checkpoints written by the 5.1 release `mwcli.exe` (raw, EMZ1, adaptive-schedule states before / at / after batch-size changes) and the 5.1 uninterrupted hashes; used by `tests/v52.test.js` |
| `regression-linux.json`, `.log` | Full Linux regression on the final source |
| `sanitizers/` | `tools/sanitize52.sh` log (includes the 5.1 and 5.0 passes) |
| `wine/` | Windows executables under Wine: self-tests 4.7-4.9, `tests/v52.test.js` against `mwcli.exe`, four processing modes on the device fixture with the test-double DLL |
| `release/README.md` | The 5.1 manifest-count difference explained; how the 5.2 ZIP is tied to the tested artifact |
| `build-linux.log`, `build-windows.log`, `build-windows-check.log` | Final build; Windows built twice, byte-identical |
