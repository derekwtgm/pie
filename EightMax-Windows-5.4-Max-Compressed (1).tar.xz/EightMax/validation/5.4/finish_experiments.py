import pathlib,time,subprocess,json,re,sys
root=pathlib.Path(__file__).resolve().parents[2];v=root/'validation/5.4';start=time.monotonic()
while True:
 p=v/'final-check-stages.json'
 if p.exists():
  checks=json.loads(p.read_text())
  if any(c['exit']!=0 and not c.get('resolvedBy') for c in checks):raise SystemExit('Final validation stage failed; experiments blocked pending repair')
  if checks and checks[-1]['stage']=='controls':break
 if time.monotonic()-start>5400:raise SystemExit('Validation wait exceeded 90 minutes; no benchmarks run')
 time.sleep(5)
stages=[('convergence',['python3',str(root/'source/tools/research54.py'),str(root.parent/'baseline/EightMax/validation/5.3/linux-bin/mwcli'),str(root/'build/linux/mwcli'),str(v/'convergence')]),('performance',['bash',str(v/'performance/run.sh')]),('studies',['python3',str(v/'studies/run.py')])]
results=[]
for name,cmd in stages:
 print('START',name,flush=True);t=time.monotonic()
 with (v/(name+'.log')).open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 results.append({'stage':name,'exit':p.returncode,'seconds':time.monotonic()-t});(v/'experiment-stages.json').write_text(json.dumps(results,indent=2));print('FINISH',results[-1],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
