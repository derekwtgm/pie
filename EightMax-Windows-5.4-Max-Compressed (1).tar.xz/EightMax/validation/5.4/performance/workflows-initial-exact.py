import pathlib,json,subprocess,time,statistics,math,tempfile
from scipy.stats import t
root=pathlib.Path(__file__).resolve().parents[3];out=pathlib.Path(__file__).resolve().parent
arms={'baseline53':root.parent/'baseline/EightMax/validation/5.3/linux-bin/mwcli','new54':root/'build/linux/mwcli'}
report={'scope':'five paired complete study workflows; setup, training, exact/sample evaluation and result writing are included in process wall time; fixed evaluation plans; 95% paired t intervals with Bonferroni correction across four fixtures; host-specific','rounds':5,'games':[]}
with tempfile.TemporaryDirectory() as td:
 d=pathlib.Path(td)
 for name in ['known-akq-river','flop3-kings-small','flop6-jack-small','icm8-bb-call-small']:
  f=json.loads((root/'studies'/f'{name}.emfix.json').read_text());f['study']['ev']['samples']=4000;f['study']['quality']['samples']=1000;sp=d/'fixture.json';sp.write_text(json.dumps(f));rows={k:[] for k in arms};signature=None
  for i in range(5):
   order=list(arms);order=order[i%2:]+order[:i%2]
   for arm in order:
    start=time.perf_counter();p=subprocess.run([str(arms[arm]),'--study',str(sp),str(d/'result.json'),'seeds=3','budgets=1000,10000','variants=baseline','threads=2','memoryMiB=512','timeLimitSeconds=180','quiet=1'],capture_output=True,text=True,timeout=240);sec=time.perf_counter()-start
    if p.returncode:raise RuntimeError(p.stderr)
    x=json.loads((d/'result.json').read_text());sig=[[[b.get(k) for k in ['deals','frequency','ev','evStdErr','pairedDiffStdErr','quality','qualityStdErr','complete','evaluationSeed','qualitySeed']] for s in v['perSeed'] for b in s['budgets']] for v in x['variants']]
    if signature is None:signature=sig
    if signature!=sig:raise AssertionError('measurement mismatch: '+name+' '+arm)
    rows[arm].append({'seconds':sec,'peakRssMiB':x['run']['processPeakRssMiB'],'completed':[b['completedSeeds'] for b in x['variants'][0]['budgets']]})
  lr=[math.log(a['seconds']/b['seconds']) for a,b in zip(rows['new54'],rows['baseline53'])];m=statistics.mean(lr);h=t.ppf(1-.05/(2*4),4)*statistics.stdev(lr)/math.sqrt(5)
  report['games'].append({'fixture':name,'bitIdenticalMeasurements':True,'rows':rows,'geometricTimeRatio':math.exp(m),'simultaneousRatio95':[math.exp(m-h),math.exp(m+h)],'medianSeconds':{k:statistics.median(r['seconds'] for r in v) for k,v in rows.items()}})
  (out/'workflows.json').write_text(json.dumps(report,indent=2));print(name,report['games'][-1]['medianSeconds'],flush=True)
