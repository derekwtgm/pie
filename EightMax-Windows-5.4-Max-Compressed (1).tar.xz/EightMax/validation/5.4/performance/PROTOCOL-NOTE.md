# Runtime feasibility adjustment

The four exact-response workloads at 1/2/4/8 threads completed all five rounds with bit-identical outputs. No pointwise timing interval established a speedup.

The complete-study benchmark finished five pairs for known A-K-Q and the three-player companion with exact evaluation. The all-exact six-player case was interrupted before completing five pairs because each study required lengthy repeated exact traversals; no incomplete timing estimate is used. The resumed six-player and ICM cases use identical fixed sampled evaluators in both binaries (4,000 action, 1,000 restricted-response quality samples). All four completed-study fixtures retain the original four-comparison correction. Their evaluator types are explicit in the final JSON and report. This is a resource-based protocol adjustment, not a claim of a preregistered full benchmark.
