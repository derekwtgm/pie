#!/bin/bash
set -eu
root=$(cd "$(dirname "$0")/../../.." && pwd)
base="$root/../baseline/EightMax/validation/5.3/linux-bin/mwcli"
new="$root/build/linux/mwcli"
mkdir -p "$root/source/build"
gcc -O2 "$root/source/tools/peak_rss.c" -o "$root/source/build/peak_rss"
for threads in 1 2 4 8; do
node "$root/source/tools/brbench48.js" "$root/validation/5.4/performance/exact-t$threads.json" --arm="baseline53:$base" --arm="new54:$new" --arm="cache-disabled:$new:EM_BR_NO_POLICY_CACHE=1" --games=hu-river,hu-turn,river3-chip,flop6 --rounds=5 --updates=20000 --threads="$threads"
done

python3 "$root/validation/5.4/performance/workflows.py"
