import pathlib,subprocess,json,time
root=pathlib.Path(__file__).resolve().parents[3];out=pathlib.Path(__file__).resolve().parent;cli=root/'build/linux/mwcli';runs=[]
for name in ['known-akq-river','btn25-open-small','flop3-kings-small','flop6-jack-small','icm8-bb-call-small','btn25-open','flop3-kings','flop6-jack','icm8-bb-call']:
 args=[str(cli),'--study',str(root/'studies'/f'{name}.emfix.json'),str(out/f'{name}.result.json'),'preset=standard','variants=baseline','seeds=3','budgets=10000,100000','evaluationSamples=4000','qualitySamples=1000','threads=2','memoryMiB=256','timeLimitSeconds=180','processingMode=cpu','quiet=1']
 t=time.perf_counter();p=subprocess.run(args,capture_output=True,text=True,timeout=240);(out/f'{name}.log').write_text(p.stdout+p.stderr);r={'fixture':name,'args':args,'exit':p.returncode,'wallSeconds':time.perf_counter()-t}
 if p.returncode==0:
  d=json.loads((out/f'{name}.result.json').read_text());r['budgets']=[{'deals':b['budgetDeals'],'completed':b['completedSeeds'],'requested':b['requestedSeeds'],'verdict':b['verdict'],'tolerance':b['meetsTolerance']} for b in d['variants'][0]['budgets']]
 runs.append(r);(out/'summary.json').write_text(json.dumps(runs,indent=2));print(name,r,flush=True)
