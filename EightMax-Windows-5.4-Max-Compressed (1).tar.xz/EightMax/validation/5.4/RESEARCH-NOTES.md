# Research decisions

The baseline trainer is external-sampling MCCFR with linear weighting and standard regret matching. Full traversal, grouped-hand paths, CFR+, uniform weighting, DCFR and terminal-baseline experiments already exist. No new default is assumed superior from theory alone.

The fixed 5.4 plan compares the unchanged 5.3 binary against the 5.4 default and opt-in terminal baseline, DCFR, DCFR with gamma=3 averaging, CFR+ and uniform weighting. Every arm uses the same configured single-deal batch, one training/evaluation thread, 128 MiB budget and paired seeds. Exact response evaluation runs separately from training, with no sampled evaluation stream. Budgets and all comparison families are written before measurement. All negative comparisons remain included.

The new policy cache changes evaluation speed, not training or response mathematics. A fixed betting node fixes public board, state and actor, so its policy depends only on the actor's private-hand index. Eight direct-mapped slots reuse that policy; collisions recompute it. Coverage visit counters are preserved. No checkpoint fields are added. EM_BR_NO_POLICY_CACHE=1 restores the old lookup loop for bitwise comparisons.

A shared showdown cache was already present in 5.3. It is preserved and is not claimed as a new feature.

Primary research context:
- Schmid et al. (2019), Variance Reduction in Monte Carlo Counterfactual Regret Minimization: https://www.mlanctot.info/files/papers/aaai19-vrmccfr.pdf
- Brown and Sandholm (2019), Solving Imperfect-Information Games via Discounted Regret Minimization: https://ojs.aaai.org/index.php/AAAI/article/view/4007

These works motivate experiments; they do not establish this implementation's performance or multiplayer convergence.
