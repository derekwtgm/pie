'use strict';
// DOM/event/export validation of the shipped Study panel. This is NOT a real
// browser or Windows UI test. Install jsdom separately; no runtime dependency
// is added to EightMax. Usage: node check-dom.cjs RELEASE_ROOT JSDOM_MODULE
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),cp=require('node:child_process'),net=require('node:net');
const rel=path.resolve(process.argv[2]),{JSDOM}=require(path.resolve(process.argv[3]));
const src=path.join(rel,'source'),out=__dirname,checks=[];
const E=require(path.join(src,'tools/loadlib'));for(const l of ['lib_runouts','lib_wide','lib_river','lib_river_ui','lib_study_ui'])require(path.join(src,'web',l));
const dom=new JSDOM('<!doctype html><div id="study"></div>');global.document=dom.window.document;
const root=document.querySelector('#study'),blobs=new Map(),downloads=[];
URL.createObjectURL=b=>{const u='blob:test-'+blobs.size;blobs.set(u,b);return u;};URL.revokeObjectURL=()=>{};
dom.window.HTMLAnchorElement.prototype.click=function(){downloads.push({name:this.download,blob:blobs.get(this.href)});};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const equal=(label,a,b)=>{assert.deepStrictEqual(a,b,label);checks.push(label);};
const pause=()=>new Promise(r=>setTimeout(r,10));
const fmt=(v,n=3,sign=false)=>typeof v!=='number'||!Number.isFinite(v)?'–':(v<0?'−':sign&&v>0?'+':'')+Math.abs(v).toFixed(n);
const ci=c=>Array.isArray(c)&&c.every(Number.isFinite)?'['+fmt(c[0],3,true)+', '+fmt(c[1],3,true)+']':'not estimable';
const pct=v=>typeof v!=='number'||!Number.isFinite(v)?'–':(100*v).toFixed(1)+'%';
const q=s=>root.querySelector(s),qa=s=>[...root.querySelectorAll(s)];
let panel,host;
async function opened(file){const input=q('#sd-result-file');Object.defineProperty(input,'files',{value:[{name:path.basename(file),text:async()=>fs.readFileSync(file,'utf8')}]});input.dispatchEvent(new dom.window.Event('change',{bubbles:true}));await pause();assert.equal(panel.state.error,'');return panel.state.result;}
function csvRows(text){let rows=[],row=[],field='',quote=false;for(let i=0;i<text.length;i++){let c=text[i];if(c==='"'){if(quote&&text[i+1]==='"'){field+='"';i++;}else quote=!quote;}else if(!quote&&(c===','||c==='\n')){row.push(field);field='';if(c==='\n'){rows.push(row);row=[];}}else field+=c;}return rows;}
async function verify(doc,label){
 for(let vi=0;vi<doc.variants.length;vi++){
  q('[data-sd-open="'+vi+'"]').click();const v=doc.variants[vi];
  equal(label+' '+v.name+' action count',qa('[data-sd-budget]').length,v.budgets.reduce((n,b)=>n+(b.actions?.length||0),0));
  for(const row of qa('[data-sd-budget]')){const b=v.budgets.find(b=>b.budgetDeals===+row.dataset.sdBudget),a=b.actions.find(a=>a.label===row.dataset.sdAction),g=k=>row.querySelector('[data-k="'+k+'"]').textContent;
   for(const [key,value] of Object.entries({frequencyMean:pct(a.frequency.mean),frequencySd:pct(a.frequency.sdAcrossSeeds),evMean:fmt(a.ev.mean,3,true),evSd:fmt(a.ev.sdAcrossSeeds),evEvalSe:fmt(a.evEvaluationStdErrOfMean)}))equal(label+' '+v.name+' '+b.budgetDeals+' '+a.label+' '+key,g(key),value);
  }
  for(const row of qa('[data-sd-gap]')){const b=v.budgets.find(b=>b.budgetDeals===+row.dataset.sdGap),g=k=>row.querySelector('[data-k="'+k+'"]')?.textContent;
   if(b.gap){equal(label+' gap mean',g('gapMean'),fmt(b.gap.mean,3,true));equal(label+' gap interval',g('gapCi'),ci(b.gap.ci95));equal(label+' gap SE',g('gapEvalSe'),fmt(b.gap.evaluationStdErrOfMean));}
   if(b.quality)equal(label+' quality mean',g('qualityMean'),fmt(b.quality.mean,4));
   equal(label+' verdict',g('verdict'),b.verdict);equal(label+' training seconds',g('trainSeconds'),fmt(b.trainingSecondsMean,2));
  }
  const h=E.study.headline(v),r=q('[data-sd-headline="'+v.name+'"]');
  if(h.budget!==null){equal(label+' headline counts',r.querySelector('[data-k="tolerance"]').textContent.includes(h.completion),true);equal(label+' headline tolerance',r.querySelector('[data-k="tolerance"]').textContent.includes('first met at'),v.firstBudgetMeetingTolerance!==null);}
  equal(label+' final status summary',q('#sd-first').textContent.includes(v.toleranceSummary),true);
  q('[data-sd-seeds]').click();equal(label+' seed ledger rows',qa('.sd-seeds tbody tr').length,v.perSeed.reduce((n,s)=>n+s.budgets.length,0));q('[data-sd-seeds]').click();
 }
 q('#sd-json').click();const json=await downloads.at(-1).blob.text();equal(label+' JSON export',JSON.parse(json),doc);
 q('#sd-csv').click();const csv=await downloads.at(-1).blob.text(),rows=csvRows(csv),columns=rows.shift();
 const expected=doc.variants.flatMap(v=>v.budgets.flatMap(b=>(b.actions||[]).map(a=>({v,b,a}))));equal(label+' CSV action row count',rows.findIndex(r=>r.length===1&&r[0]===''),expected.length);
 for(let i=0;i<expected.length;i++){const {v,b,a}=expected[i],r=Object.fromEntries(columns.map((c,j)=>[c,rows[i][j]]));
  for(const [key,value] of Object.entries({variant:v.name,frequencyMean:a.frequency.mean,evMean:a.ev.mean,gapMean:b.gap?.mean,gapCi95Low:b.gap?.ci95?.[0],gapCi95High:b.gap?.ci95?.[1],completedSeeds:b.completedSeeds,requestedSeeds:b.requestedSeeds,complete:b.complete,meetsTolerance:b.meetsTolerance,calculationVersion:doc.calculationVersion}))equal(label+' CSV '+key,r[key],value===undefined||value===null?'':String(value));
 }
 fs.writeFileSync(path.join(out,label+'.export.json'),json);fs.writeFileSync(path.join(out,label+'.export.csv'),csv);
}
(async()=>{try{
 equal('tested Study source is embedded verbatim in final HTML',fs.readFileSync(path.join(rel,'EightMax-Offline.html'),'utf8').includes(fs.readFileSync(path.join(src,'web/lib_study_ui.js'),'utf8').trim()),true);
 const server=net.createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;await new Promise(r=>server.close(r));
 host=cp.spawn(path.join(rel,'build/linux/eightmax'),['--no-browser','--port='+port],{stdio:'ignore'});
 const napi=async(p,b)=>{const r=await fetch('http://127.0.0.1:'+port+p,b===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json','X-EightMax':'1'},body:JSON.stringify(b)});if(!r.ok)throw Error(r.status+' '+await r.text());return r.json();};
 let info;for(let i=0;i<1000;i++){try{info=await napi('/api/info');break;}catch(e){await pause();}}assert(info);equal('host and archive build match',info.build,JSON.parse(fs.readFileSync(path.join(rel,'BUILD-INFO.json'))).build);
 E.STUDY_FIXTURES=[JSON.parse(fs.readFileSync(path.join(rel,'studies/known-akq-river.emfix.json')))];panel=E.studyPanel(root,{NATIVE:true,napi,esc,openInMultiway:()=>true});await pause();
 for(const id of ['btn25-open-small','known-akq-river']){const file=path.join(rel,'validation/5.2/studies',id+'.result.json'),old=JSON.parse(fs.readFileSync(file)),doc=await opened(file);
  equal('legacy '+id+' warning visible',q('#sd-legacy').textContent.includes('fresh independent evaluation'),true);equal('legacy '+id+' all raw measurements retained',doc.variants.map(v=>v.perSeed),old.variants.map(v=>v.perSeed));equal('legacy '+id+' original timing retained',doc.run,old.run);await verify(doc,'legacy-'+id);
  const reopened=await opened(path.join(out,'legacy-'+id+'.export.json'));equal('legacy '+id+' exported result reopens idempotently',reopened,doc);
 }
 const files=fs.readdirSync(path.join(rel,'validation/5.3/studies')).filter(f=>f.endsWith('.result.json'));
 for(const file of files){const doc=await opened(path.join(rel,'validation/5.3/studies',file));await verify(doc,'fresh-'+file.replace('.result.json',''));}
 await verify(await opened(path.join(rel,'validation/5.3/reproductions/timed-final.json')),'partial-timed');
 for(const [id,value] of [['sd-preset','quick'],['sd-mode','cpu'],['sd-timeLimit','10'],['sd-memory','64'],['sd-samples','128'],['sd-qualitySamples','64'],['sd-seeds','3'],['sd-budgets','100,1000']]){q('#'+id).value=value;q('#'+id).dispatchEvent(new dom.window.Event('change',{bubbles:true}));}
 q('#sd-run').click();for(let i=0;i<3000;i++){await pause();if(!panel.state.running&&panel.state.resultSource==='this application')break;}equal('normal panel Run finishes',panel.state.running,false);equal('normal panel Run has no error',panel.state.error,'');equal('preset reaches native host',panel.state.result.run.preset,'quick');equal('processing mode reaches native host',panel.state.result.run.processingModeRequested,'cpu');equal('normal panel Run uses current build',panel.state.result.build,info.build);await verify(panel.state.result,'desktop-run');
 }catch(e){checks.push('FAILED '+e.stack);process.exitCode=1;}finally{if(host)host.kill();dom.window.close();fs.writeFileSync(path.join(out,'dom-report.json'),JSON.stringify({environment:'Linux Node/jsdom 31.0.1; DOM and actual host API, NOT a real browser, NOT Windows',build:JSON.parse(fs.readFileSync(path.join(rel,'BUILD-INFO.json'))).build,checks:checks.length,failed:process.exitCode?1:0,details:checks},null,1)+'\n');console.log(checks.length+' DOM assertions; failures '+(process.exitCode||0));}})();
