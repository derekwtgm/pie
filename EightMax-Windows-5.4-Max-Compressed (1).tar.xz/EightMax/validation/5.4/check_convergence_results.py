import pathlib,json,math,collections
v=pathlib.Path(__file__).resolve().parent;plan=json.loads((v/'convergence/plan.json').read_text());rows=[json.loads(s) for s in (v/'convergence/raw.jsonl').read_text().splitlines()]
want={(g,s,a,k,b) for g in plan['games'] for s in plan['seeds'] for a in plan['arms'] for k,bs in [('deals',plan['deals']),('time',plan['trainingSeconds'])] for b in bs};got=[(r['game'],r['seed'],r['arm'],r['kind'],r['budget']) for r in rows];assert len(got)==len(set(got)) and set(got)<=want
for r in rows:
 assert not r['memoryStopped'],r
 if r['kind']=='deals':assert r['deals']==r['budget'],r
 assert math.isfinite(r['nashConv']) and r['nashConv']>=-1e-10
 assert abs(sum(r['seatGains'])-r['nashConv'])<1e-7
 assert abs(max(r['seatGains'])-r['largestUnilateralGain'])<1e-7
 if r['game']=='hu-river':assert abs(r['exploitability']*2-r['nashConv'])<1e-7
 assert r['peakRssMiB']>0 and r['gpuPeakMiB'] is None
(v/'convergence/result-integrity.json').write_text(json.dumps({'plannedRows':len(want),'uniqueRows':len(got),'missingRows':len(want-set(got)),'allPlannedRowsCompleted':set(got)==want,'allDealBudgetsReached':True,'memoryStopped':0,'finiteNonnegativeNashConv':True,'gainSumAndMaximumAgree':True,'headsUpExploitabilityConvention':'NashConv / 2','physicalGpuMeasured':False},indent=2));print('Verified',len(rows),'observed planned rows and metric conventions; incomplete plan disclosed')
