# Incomplete ICM comparison

Session usage interruption, followed by feasibility review: observed exact ICM evaluation takes 64–71 seconds per checkpoint on the experiment host; remaining 276 evaluations require several hours. No outcome-based selection; original 72-contrast multiplicity penalty retained.

incomplete: heads-up river and three-player river completed; four-player exact ICM interrupted after one candidate/seed, no ICM comparative conclusion
