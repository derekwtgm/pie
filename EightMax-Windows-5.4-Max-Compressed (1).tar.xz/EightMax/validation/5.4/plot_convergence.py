import pathlib,json,collections,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
v=pathlib.Path(__file__).resolve().parent;rows=[json.loads(l) for l in (v/'convergence/raw.jsonl').read_text().splitlines()];games=['hu-river','river3-chip'];arms=['baseline53','default54','terminal-baseline','dcfr','dcfr-average3','cfr-plus','uniform']
fig,axs=plt.subplots(1,2,figsize=(11,4.6),layout='constrained');colors=plt.cm.tab10(np.linspace(0,1,7))
for ax,g in zip(axs,games):
 for i,arm in enumerate(arms):
  series=collections.defaultdict(list)
  for r in rows:
   if r['game']==g and r['arm']==arm and r['kind']=='deals':series[r['budget']].append(r['nashConv'])
  xs=sorted(series);ys=[np.mean(series[x]) for x in xs];ax.plot(xs,ys,marker='o',markersize=3,label=arm,color=colors[i],linestyle='--' if arm=='default54' else '-')
 ax.set_xscale('log');ax.set_yscale('log');ax.set_title(g);ax.set_xlabel('Sampled deals');ax.set_ylabel('Mean exact NashConv');ax.grid(alpha=.18)
fig.suptitle('EightMax 5.4 — completed exact games, 10 training seeds (ICM comparison incomplete)',fontsize=14);axs[-1].legend(fontsize=8,loc='upper right');fig.savefig(v/'convergence/convergence.png',dpi=160)
