"""Generate checkpoints with the unchanged 5.3 binary; resume with 5.4, raw and EMZ1."""
import pathlib,json,subprocess,hashlib
r=pathlib.Path(__file__).resolve().parents[3];out=pathlib.Path(__file__).resolve().parent/'v53-checkpoints';out.mkdir(exist_ok=True)
old=r.parent/'baseline/EightMax/validation/5.3/linux-bin/mwcli';new=r/'build/linux/mwcli';rows=[]
def run(cli,*a):
 p=subprocess.run([str(cli),*map(str,a)],capture_output=True,text=True,timeout=120)
 assert p.returncode==0,p.stderr
 return json.loads(p.stdout)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for i,config in enumerate([{},{'terminalBaseline':True},{'weighting':'dcfr'},{'weighting':'dcfr','dcfrGamma':3},{'regretMatching':'plus'},{'weighting':'uniform'}]):
 d=out/str(i);d.mkdir(exist_ok=True);sp=d/'spec.json'
 subprocess.run(['node',str(r/'source/tools/games48.js'),'spec','river3-chip',str(sp),'5418',json.dumps(config)],check=True,capture_output=True)
 run(old,sp,1000,1,d/'uninterrupted.state',128);run(old,sp,400,1,d/'partial.state',128);run(old,'--compress',d/'partial.state',d/'partial.emz')
 want=sha(d/'uninterrupted.state')
 for fmt in ['state','emz']:
  for threads in [1,4]:
   p=d/f'resumed-{fmt}-{threads}.state';info=run(new,sp,600,threads,p,128,d/f'partial.{fmt}');got=sha(p);assert got==want,(config,fmt,threads)
   rows.append({'config':config,'format':fmt,'resumeThreads':threads,'sha256':got,'passed':True,'trainingDeals':info['trainingDeals']})
(out/'summary.json').write_text(json.dumps({'baselineBuild':subprocess.check_output([old,'--build-id'],text=True).strip(),'currentBuild':subprocess.check_output([new,'--build-id'],text=True).strip(),'checks':rows,'passed':len(rows),'failed':0},indent=2));print(len(rows),'cross-version continuation checks passed')
