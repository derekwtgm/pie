import pathlib,time,re,subprocess,os,json
root=pathlib.Path(__file__).resolve().parents[3];v=root/'validation/5.4';log=v/'tests/full-regression.tap'
while not re.search(r'^# duration_ms ',log.read_text(),re.M):time.sleep(5)
text=log.read_text();failures=re.findall(r'^not ok \d+ - (.*)',text,re.M);results=[]
for name in failures:
 # Timing-specific 4.4 regression needs an idle machine, not concurrent suite processes.
 if name.startswith('4.4 reproduced 4.3 regression:'):
  env={**os.environ,'EM_TEST_MWCLI':str(root/'build/linux/mwcli'),'EM_TEST_HOST':str(root/'build/linux/eightmax'),'ASAN_OPTIONS':'detect_leaks=0','NODE_OPTIONS':'--require='+str(root/'validation/5.3/sanitizers/no-leaks.cjs')}
  with (v/'tests/isolated-v44.tap').open('w') as f:p=subprocess.run(['node','--test','--test-reporter=tap','--test-name-pattern=4.4 reproduced 4.3 regression:',str(root/'source/tests/v44.test.js')],env=env,stdout=f,stderr=subprocess.STDOUT)
  results.append({'name':name,'exit':p.returncode,'reason':'50 ms deadline overshoot assertion failed under three concurrent regression processes; rerun alone without changing code or threshold','log':'tests/isolated-v44.tap'})
 else:results.append({'name':name,'exit':None,'reason':'not automatically rerun; investigate'})
(v/'tests/reruns.json').write_text(json.dumps(results,indent=2));(v/'tests/sanitized-completed.tap').rename(v/'tests/sanitized.tap')
