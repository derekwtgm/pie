import pathlib,subprocess,json,tempfile
r=pathlib.Path(__file__).resolve().parents[3];results=[]
with tempfile.TemporaryDirectory() as td:
 d=pathlib.Path(td)
 for name,trainer in [('dcfr-average3',{'weighting':'dcfr','dcfrGamma':3}),('terminal-baseline',{'terminalBaseline':True}),('cfr-plus',{'regretMatching':'plus'})]:
  f=json.loads((r/'studies/known-akq-river.emfix.json').read_text());f['study']['trainer']=trainer;(d/'f.json').write_text(json.dumps(f))
  p=subprocess.run([str(r/'build/linux/mwcli'),'--study',str(d/'f.json'),str(d/'r.json'),'seeds=2','budgets=100','memoryMiB=32.5','quiet=1'],capture_output=True,text=True);assert p.returncode==0,p.stderr
  doc=json.loads((d/'r.json').read_text());got=doc['variants'][0]['perSeed'][0]['budgets'][0]['trainer'];assert got
  for k,val in trainer.items():
   if k=='dcfrGamma':continue
   assert got[k]==val,(k,got)
  results.append({'trainer':name,'actual':got,'passed':True})
 for mode in ['cpu','auto','hybrid','gpu']:
  p=subprocess.run([str(r/'build/linux/mwcli'),'--study',str(r/'studies/known-akq-river.emfix.json'),str(d/'r.json'),'seeds=2','budgets=100','processingMode='+mode,'quiet=1'],capture_output=True,text=True);assert p.returncode==0,p.stderr
  doc=json.loads((d/'r.json').read_text());b=doc['variants'][0]['perSeed'][0]['budgets'][0];assert b['trainingDeviceRequested']==mode;assert b['complete'];results.append({'mode':mode,'observedTrainingDevice':b['trainingDevicePath'],'passed':True})
pathlib.Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2))
