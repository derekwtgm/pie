import pathlib,json,re,statistics,collections,hashlib
r=pathlib.Path(__file__).resolve().parents[2];v=r/'validation/5.4'
load=lambda p:json.loads((v/p).read_text())
build=json.loads((r/'BUILD-INFO.json').read_text())['build'];env=load('environment.json');conv=load('convergence/summary.json');rows=[json.loads(l) for l in (v/'convergence/raw.jsonl').read_text().splitlines()];coverage=load('statistics/coverage.json');studies=load('studies/summary.json');work=load('performance/workflows.json')
def counts(file):
 s=(v/file).read_text();return {k:int(re.search(r'^# '+k+r' (\d+)',s,re.M)[1]) for k in ['tests','pass','fail','skipped','cancelled']}
full=counts('tests/full-regression.tap');san=counts('tests/sanitized.tap');ref=load('reference/selftest.json');dom=load('ui/dom-report.json')
rr={};
for p in sorted((v/'performance').glob('exact-t*.json')):rr[p.stem]=json.loads(p.read_text())
initial=counts('tests/development-regression.tap')
failures=re.findall(r'^not ok \d+ - (.*)',(v/'tests/development-regression.tap').read_text(),re.M)
reruns=load('tests/reruns.json') if (v/'tests/reruns.json').exists() else []
resolved=[x for x in reruns if x.get('exit')==0]
finalReruns=load('tests/final-reruns.json')
finalFailures=re.findall(r'^not ok \d+ - (.*)',(v/'tests/full-regression.tap').read_text(),re.M)
consolidated={**full,'pass':full['pass']+sum(x['exit']==0 for x in finalReruns),'fail':full['fail']-sum(x['exit']==0 for x in finalReruns)}
verdicts=collections.Counter(c['verdict'] for c in conv['comparisons']);rare=next(s for s in coverage['scenarios'] if s['scenario']=='rare_tail_mixture')['simultaneousConditionalCoverage']
base={(x['game'],x['seed'],x['budget']):x for x in rows if x['kind']=='deals' and x['arm']=='baseline53'}
current=[x for x in rows if x['kind']=='deals' and x['arm']=='default54'];ident=sum(x['checkpointSha256']==base[x['game'],x['seed'],x['budget']]['checkpointSha256'] for x in current)
summary={'build':build,'developmentRegression':initial,'regression':full,'consolidatedDistinctRegression':consolidated,'originalFailures':failures,'finalFailures':finalFailures,'finalReruns':finalReruns,'reruns':reruns,'sanitizers':san,'referenceChecks':{'passed':ref['passed'],'failed':ref['failed']},'domAssertions':dom['checks'],'domFailed':dom['failed'],'statistics':{'trials':coverage['trialsPerScenario']*len(coverage['scenarios']),'quantilesPassed':sum(q['passed'] for q in coverage['quantiles']),'calibrationWithinTestedTolerance':coverage['calibrationWithinTestedTolerance'],'rareTailConditionalCoverage':rare},'convergence':{'rows':len(rows),'plannedRows':conv['plannedRows'],'comparisons':len(conv['comparisons']),'predeclaredFamilySize':conv['predeclaredFamilySize'],'incompleteComparisons':len(conv['incompleteComparisons']),'verdicts':dict(verdicts),'unchangedDefaultCheckpointPairs':ident,'defaultCheckpointPairs':len(current)},'crossVersion53ContinuationChecks':load('tests/v53-checkpoints/summary.json')['passed'],'nativeWindows':False,'physicalGpu':False,'defaultAlgorithmChanged':False}
(v/'validation-summary.json').write_text(json.dumps(summary,indent=2))
impl='''- Bounded policy reuse in exact best-response traversal; eight local slots per opponent node, with bitwise A/B checks and preserved logical coverage counters.
- `largestUnilateralGain` alongside exact NashConv; two-player chip-EV exploitability remains NashConv / 2.
- Native Quick, Standard, Deep and Research study controls; explicit settings override preset defaults.
- Adjustable evaluation samples, time, memory, threads and processing mode in the desktop and CLI. Quality evaluation now receives the requested cache budget. Evaluation threads are capped to the evaluator's supported 64 independently of training threads.
- Desktop status now publishes whole progress JSON atomically instead of truncating a fixed 512-byte buffer; a long-name/progress cancellation regression guards the repair.
- Periodic training diagnostics: algorithm, deals, observed device, table memory and peak process RAM. JSON adds effective per-variant evaluation settings and training diagnostics; CSV appends preset, mode and confidence fields.
- Reproducible convergence, performance, independent-reference, statistical, compatibility and interruption validation. The 5.3 statistics and calculation identifier are intentionally unchanged.'''
limitations='''Native Windows execution/UI and physical RTX 4060 Ti testing are unavailable. Linux timing is not a prediction for the user's 13th-generation i7. Simulated CUDA checks establish fallback/integration behavior only. Leak checking was disabled; address/undefined-behaviour checks are separate evidence. There is no full-game GTO certificate.

Not implemented: a new learned variance-reduction estimator; adaptive sequential evaluation; selectable confidence levels; automatic study-level checkpoint/resume; new CUDA kernels; a global process-memory limit; a continuous evaluation percentage or reliable ETA. Existing solver checkpoints and partial study results remain supported. See `validation/5.4/NOT-IMPLEMENTED.md`.'''
(r/'RELEASE-5.4.md').write_text(f'''# EightMax Windows 5.4

Build `{build}`. Calculation identifier remains `study-5.3-tfloor-bonferroni-v1`, because its statistical interpretation is preserved.

## Implemented

{impl}

## Evidence and interpretation

The default training algorithm is unchanged. {ident}/{len(current)} equal-deal baseline/current checkpoint pairs are byte-identical. Thus 5.4 does not improve default strategy accuracy at equal sampled deals. Candidate experiments yielded {dict(verdicts)} across {len(conv['comparisons'])} completed contrasts, corrected over the original {conv['predeclaredFamilySize']}-contrast family. Another {len(conv['incompleteComparisons'])} exact ICM contrasts were not completed because of runtime cost. No candidate showed a statistically supported improvement.

The development regression passed 549 of 551 tests. The progress-buffer failure was repaired; a timing failure passed its unchanged isolated rerun. The final-source suite passed 551 of 552 tests, and its sole CPU-load timing failure passed an unchanged isolated rerun, giving 552 distinct passing checks. No tests were skipped. The 22 sanitizer checks, 28 independent reference checks and 4,304 DOM/event/export assertions passed. Raw failures, repairs and reruns remain in validation/5.4.

New statistical stress tests reproduced the rare-tail limitation: conditional simultaneous coverage {rare['rate']:.4%}, Wilson 95% interval [{rare['wilson95'][0]:.4%}, {rare['wilson95'][1]:.4%}]. This is a synthetic known-error stress scenario, not measured coverage on all poker games. The failure is retained and disclosed in the UI.

## Limits

{limitations}

## Use

Extract into a new folder and run `EightMax.exe`. No separate Python or Node runtime is required for the Windows application. Development/research scripts have their own dependencies. Read USER-GUIDE-5.4.md.
''')
lines=['# Convergence — EightMax 5.4','',f'Final build `{build}`. Fixed plan: three small exact games, ten paired training seeds (901–910), seven arms, three deal budgets (4,000 / 20,000 / 100,000) and a separately started 0.1-second training budget. {len(rows)} measured checkpoints. One training thread, one evaluation thread, 128 MiB in each arm. Single-deal batches are held equal.','', 'The baseline arm trains with the unchanged 5.3 Linux binary. All arms are evaluated with the same separate 5.4 exact evaluator, whose results are checked against the old loop and independent references. Exact evaluations need no sampling streams or evaluation confidence intervals. Across-seed intervals concern training variation and remain approximate.','',f'{conv['predeclaredFamilySize']} contrasts were declared before execution; {len(conv['comparisons'])} were completed. The 24 ICM contrasts are not completed; no ICM comparative conclusion is drawn. Observed exact ICM evaluation cost was 64–71 seconds per checkpoint, making the remaining matrix several hours long. The full original multiplicity penalty is retained. See convergence/INTERRUPTION.md. Two-sided paired Student-t intervals use Bonferroni over that entire family. No result-dependent stopping or favorable-seed selection. No default was promoted.','', '| Game | Arm | Comparison | Budget | Baseline NashConv | Candidate NashConv | Difference CI (simultaneous 95%) | Verdict |','|---|---|---|---:|---:|---:|---|---|']
for c in conv['comparisons']:
 lo,hi=c['simultaneousCi95'];lines.append(f"| {c['game']} | {c['arm']} | {c['kind']} | {c['budget']} | {c['baselineMean']:.6g} | {c['candidateMean']:.6g} | [{lo:.6g}, {hi:.6g}] | {c['verdict']} |")
lines+=['','## Cost interpretation','', 'Equal-time runs use the engine cancellation timer, so observed time may slightly overrun the target and includes OS scheduling noise. CPU seconds, setup, training-process wall time, cumulative evaluation time, total measured workflow time and peak RSS are separately retained. CPU/RSS columns measure training and evaluation child processes; Python/Node orchestration CPU and memory are excluded, although setup wall time is included. Research orchestration and additional checkpoint-copy/plotting overhead are excluded from per-row totals; the full stage wall time is recorded separately. Equal CPU time and equal total workflow time are not independently enforced experiment arms. Do not describe them as such. GPU memory is null because no physical GPU was measured.','',f'The default/current states are byte-identical in {ident}/{len(current)} equal-deal pairs. The optimization concerns evaluation work, not a different trained policy. In heads-up chip EV, exploitability is half the displayed NashConv. Multiplayer and ICM NashConv is a sum of unilateral gains, not two-player exploitability.','', 'Raw: `validation/5.4/convergence/plan.json`, `raw.jsonl`, `summary.json`, and per-budget checkpoint files. Reference full-width CFR/CFR+/linear/DCFR results are separate in `validation/5.4/reference/fullwidth.json`; their timings ran alongside validation and are not performance claims.']
(r/'CONVERGENCE-5.4.md').write_text('\n'.join(lines)+'\n')
lines=['# Performance — EightMax 5.4','',f"Measured on {env['cpu']}, Linux, {env['logicalCpus']} visible logical CPUs. These are not i7/RTX 4060 Ti measurements.",'','## Complete response-evaluation requests','','The exact ICM timing matrix was omitted after the convergence feasibility review; the four remaining workloads are reported in full. The same trained checkpoint and request are evaluated by the 5.3 binary, 5.4 binary and 5.4 cache-disabled control. Arm order rotates over five rounds. Includes process startup, checkpoint restore, evaluation and output. All exact gains must remain bit-identical. The listed ratio intervals from the inherited benchmark are pointwise 95%, not corrected across the whole matrix; interpret them as workload-specific measurements.','','| Threads | Game | 5.3 median s | 5.4 median s | Time ratio | Pointwise 95% ratio interval | Peak 5.3/5.4 MiB | Same exact result |','|---:|---|---:|---:|---:|---|---|---|']
for report in rr.values():
 for g in report['games']:
  a,b=g['arms'][:2];ci=b['ratio95'];lines.append(f"| {report['threads']} | {g['key']} | {a['medianSec']:.4f} | {b['medianSec']:.4f} | {b['timeRatioToFirst']:.3f} | [{ci[0]:.3f}, {ci[1]:.3f}] | {a['peakRssMiB']}/{b['peakRssMiB']} | {g['identical']} |")
lines+=['','## Complete study workflows','','Five paired rounds per fixture include setup, training, action evaluation, quality evaluation and saving the result. Known A-K-Q and the three-player companion use exact evaluation. The six-player and ICM companions use identical fixed sampled evaluators in both binaries (4,000 action and 1,000 restricted-response quality samples), after an all-exact attempt was interrupted for runtime feasibility. See performance/PROTOCOL-NOTE.md; this benchmark was adjusted for resource cost and is not claimed to be fully preregistered. Numeric measurements and completion statuses must match. Ratio intervals below are Bonferroni-adjusted over four fixtures.','','| Fixture / evaluation | 5.3 median s | 5.4 median s | Geometric time ratio | Simultaneous 95% interval | Identical measurements |','|---|---:|---:|---:|---|---|']
for g in work['games']:
 ci=g['simultaneousRatio95'];lines.append(f"| {g['fixture']} / {g.get('evaluationMethod','exact')} | {g['medianSeconds']['baseline53']:.4f} | {g['medianSeconds']['new54']:.4f} | {g['geometricTimeRatio']:.3f} | [{ci[0]:.3f}, {ci[1]:.3f}] | {g['bitIdenticalMeasurements']} |")
lines+=['','No universal speedup is asserted. Small heads-up requests can pay cache overhead without reuse, while multiway nodes can reuse many policies. Negative and inconclusive timing results remain included. Training is unchanged in implementation; no training-throughput improvement is established. The sampled ICM complete-study ratio corresponds to 3.1% less elapsed time (family-adjusted 95% interval: about 0.6–5.5% less). This small host-specific result is not attributed specifically to the exact-policy cache, which is not used by that sampled path. Other complete-workflow comparisons are inconclusive. Peak RSS and wall latency are separate quantities. No physical GPU timing or VRAM use was measured. Raw per-round results and reproduction commands are in `validation/5.4/performance/`.']
(r/'PERFORMANCE-5.4.md').write_text('\n'.join(lines)+'\n')
lines=['# Accuracy report — EightMax 5.4','',f'Build `{build}`. This release adds study controls and an evaluated exact-response optimization; it does not claim a new universal GTO accuracy level.','',f'## Independent mathematical checks\n\n{ref["passed"]} independent reference checks passed, {ref["failed"]} failed. These cover known Kuhn values, Leduc, weighted small games, exact responses, counterfactual regrets, strategy averaging, 20,000 side-pot showdowns and 2,000 ICM/bust cases. The full regression also compares native multi-street best responses against separate Python betting, ranking, chance and pot implementations. These independent implementations share no native payoff/evaluation code.','',f'The default/current equal-deal states agree in {ident}/{len(current)} pairs. Exact quality is inside the chosen abstraction. A low sampled one-decision response gain is not full-game exploitability, and cannot certify equilibrium.','', '## Practical studies','', 'These nine fresh runs use three seeds, budgets 10,000 and 100,000 deals, CPU-only mode, two threads, 256 MiB engine budgets, 4,000 action samples, 1,000 quality samples where sampled, and a 180-second cap. They are small, transparent replication studies, not a claim that the longer Deep preset has converged. Changes in budget/settings prevent direct quality comparisons to the old 5.3 representative runs.','', '| Fixture | Budget | Completed/requested | Ranking | Tolerance met |','|---|---:|---|---|---|']
for s in studies:
 for b in s.get('budgets',[]):lines.append(f"| {s['fixture']} | {b['deals']} | {b['completed']}/{b['requested']} | {b['verdict']} | {b['tolerance']} |")
lines+=['','## Statistical checks','',f'{coverage["trialsPerScenario"]} trials in each of {len(coverage["scenarios"])} predeclared synthetic scenarios; {sum(q["passed"] for q in coverage["quantiles"])} independent SciPy quantile checks passed. Per-scenario coverage, false-ranking counts and Wilson intervals are in statistics/coverage.json. Errors use known covariance/standard errors; this is not a validation of all poker-estimated SEs.','',f'Rare-tail conditional coverage was {rare["rate"]:.4%} ({rare["successes"]}/{rare["trials"]}), Wilson 95% [{rare["wilson95"][0]:.4%}, {rare["wilson95"][1]:.4%}]. This failed the nominal 95% calibration target. The full calibration flag is false and the result is retained. The baseline interval formula is preserved, not silently relabeled as distribution-free. No narrower replacement is promoted.','', '## Interpretation','', 'Candidates can win individual small-game comparisons without being robust across games, budgets and timing constraints. CONVERGENCE-5.4.md retains every corrected result. No default change or overall percentage closer-to-GTO claim is justified by this release. Larger linked-street weighted-range tournament equilibrium quality remains an open problem.']
(r/'ACCURACY-REPORT-5.4.md').write_text('\n'.join(lines)+'\n')
(r/'VALIDATION-5.4.md').write_text(f'''# Validation — EightMax 5.4

Build `{build}`. Baseline ZIP CRC and all 1,544 manifest entries passed. Baseline build `55c4fffde6deb9a1` and source/executable identity matched. All historical source, tests, studies and evidence remain available.

## Fresh execution

- Final-source suite: 551/552 passed, with no skipped tests. The loaded deadline test overran by 464.3 ms while other suites were active. Its unchanged isolated rerun, still using nine deliberate load processes, passed with overruns of 9.0–36.5 ms. Thus all 552 distinct checks have passing outcomes; the original timing failure remains recorded.
- Development suite: 549/551 passed. Rich progress JSON exceeded the old 512-byte buffer; whole-document publication repaired the defect and the final host/large-progress tests passed. A separate 51.3 ms overrun against a 50 ms allowance passed unchanged in isolation. These deadlines are cooperative targets, not real-time OS guarantees.
- Raw records: `tests/development-regression.tap`, `tests/full-regression.tap`, `tests/reruns.json`, `tests/final-reruns.json` and their referenced rerun logs under validation/5.4.
- ASan/UBSan/float-cast-overflow focused run: {san['pass']}/{san['tests']} passed, {san['fail']} failed. Third-party QuickJS uses ASan only. Leak detection is disabled and unverified.
- Fresh 5.3-to-5.4 raw/EMZ1 checkpoint continuations: 24 byte-identical checks across six trainer configurations and 1/4 resume threads.
- Independent reference suite: {ref['passed']} passed, {ref['failed']} failed; 36 full-width comparison records also retained.
- Desktop DOM/events/export harness: {dom['checks']} assertions, {dom['failed']} failures; actual Linux host API used. This is not a graphical browser or Windows visual test.
- Statistical simulation: {coverage['trialsPerScenario']*len(coverage['scenarios'])} trials, 21 quantile checks. Rare-tail conditional coverage failed; this diagnostic is not hidden among passing regressions.
- Convergence: {len(rows)} checkpoint evaluations and {len(conv['comparisons'])} corrected paired comparisons.
- Performance: four thread counts (1, 2, 4, 8), four exact workloads, three arms, five rounds; four complete study workflows with five paired rounds. All measurements, failures and controls retained.

The full suite covers legacy raw/EMZ1 checkpoints including 5.1/5.2/5.3 continuation, RNG/regret/average-state preservation, damaged files, transactional memory/cancellation recovery, CPU operation, GPU fallback simulations, chip EV/ICM, weighted ranges, linked streets, individual antes and desktop/CLI paths. New trainer-configuration checkpoint tests compare uninterrupted and resumed files byte for byte. No new checkpoint format was introduced.

## Scope and gaps

{limitations}

The first development workspace was cleared during a usage interruption. Its incomplete logs are not counted. Changes were restored from the conversation and all evidence reported here was rerun in the recovered workspace. Any later isolated reruns are recorded separately; see validation-summary.json and tests/.

## Reproduction

See BUILD-5.4.md. The canonical ZIP's external identity JSON records the final archive hash, extracted checksum verification, source/executable identity and extracted-artifact smoke tests. Historical validation directories describe their historical releases, not this one.
''')
(r/'BUILD-5.4.md').write_text(f'''# Building EightMax 5.4

Final source/build identifier: `{build}`. Statistics identifier: `study-5.3-tfloor-bonferroni-v1` (formula unchanged). Complete source is included. Windows programs are unsigned x64 PE executables with statically linked language runtime/zlib and normal Windows system-DLL dependencies.

Build requirements: Node, Python 3, GCC/G++ supporting C++20, zlib; Linux host also needs OpenSSL development libraries. Windows cross-build uses MinGW-w64 POSIX GCC 14.2.0 and its static zlib. Research scripts require NumPy/SciPy; DOM harness requires jsdom. These are developer requirements, not runtime requirements for the Windows application.

From the release root:

```sh
node source/tools/build.js build
sh source/native/build.sh linux "$PWD/build/native.html" "$PWD/build/linux"
CC=x86_64-w64-mingw32-gcc-posix CXX=x86_64-w64-mingw32-g++-posix sh source/native/build.sh windows "$PWD/build/native.html" "$PWD/build/windows"
```

Windows MSYS2 can use CC=gcc CXX=g++ with the windows target. Compiler flags retain strict arithmetic and no FMA contraction in native multiway code. Do not change source after building without regenerating the interface and binaries; the builder and verifier enforce fingerprint agreement.

Copy build/windows executables, build/EightMax-Offline.html and build/build-info.json (as BUILD-INFO.json) to the release root. Copy Linux programs to validation/5.4/linux-bin for Linux artifact smoke tests.

```sh
EM_TEST_MWCLI="$PWD/build/linux/mwcli" EM_TEST_HOST="$PWD/build/linux/eightmax" ASAN_OPTIONS=detect_leaks=0 NODE_OPTIONS="--require=$PWD/validation/5.3/sanitizers/no-leaks.cjs" node --test --test-concurrency=3 --test-reporter=tap source/tests/*.test.js
bash validation/5.3/sanitizers/build-final.sh source build sanitized
ASAN_OPTIONS=detect_leaks=0 EM_TEST_MWCLI="$PWD/sanitized/mwcli" EM_TEST_HOST="$PWD/sanitized/eightmax" node --test source/tests/v53.test.js source/tests/v54.test.js
node source/tools/verify_build.js .
python3 validation/5.4/release54.py . output
```

The last command generates SHA256SUMS.txt, builds the ZIP, verifies CRC, extracts the exact ZIP to a fresh directory, checks every checksum and all build identities, then runs Linux CLI/checkpoint/desktop API smoke tests. Linux execution does not validate the Windows executables. The external identity JSON holds the ZIP's own SHA-256; it cannot be embedded into that same ZIP.

Convergence reproduction: `python3 source/tools/research54.py /path/to/unchanged-5.3-mwcli build/linux/mwcli fresh-output-directory`. Fixed plan and every raw record are retained. Performance and study runners under validation/5.4 retain exact parameters. Adjust the baseline binary path in those runners to your extracted 5.3 folder. Use the same compiler, resource settings and idle machine for timing comparisons.
''')
# retain historical top-level documentation while making the current release visible
for name,heading in [('ACCURACY-SUMMARY.md','# Version 5.4 measurements'),('ROADMAP.md','# Version 5.4 status'),('CHANGELOG.md','# EightMax 5.4'),('README.txt','EightMax 5.4')]:
 p=r/name;old=p.read_text();prefix=f'{heading}\n\nCurrent release: RELEASE-5.4.md. User instructions: USER-GUIDE-5.4.md. Measured accuracy, convergence, performance and limitations are in the 5.4 reports. Default trainer and checkpoint formats are unchanged.\n\n'
 if not old.startswith(prefix):p.write_text(prefix+old)
print(json.dumps(summary,indent=2))
