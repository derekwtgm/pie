"""Summarize completed predeclared contrasts; retain original multiplicity family."""
import pathlib,json,statistics,math
from scipy import stats
v=pathlib.Path(__file__).resolve().parent;out=v/'convergence';plan=json.loads((out/'plan.json').read_text());rows=[json.loads(l) for l in (out/'raw.jsonl').read_text().splitlines()];family=len(plan['games'])*(len(plan['arms'])-1)*(len(plan['deals'])+len(plan['trainingSeconds']));comp=[];missing=[]
for game in plan['games']:
 for arm in list(plan['arms'])[1:]:
  for kind,budgets in [('deals',plan['deals']),('time',plan['trainingSeconds'])]:
   for budget in budgets:
    B={r['seed']:r for r in rows if (r['game'],r['arm'],r['kind'],r['budget'])==(game,'baseline53',kind,budget)};A={r['seed']:r for r in rows if (r['game'],r['arm'],r['kind'],r['budget'])==(game,arm,kind,budget)}
    if set(B)!=set(plan['seeds']) or set(A)!=set(plan['seeds']):
     missing.append({'game':game,'arm':arm,'kind':kind,'budget':budget,'baselineSeeds':len(B),'candidateSeeds':len(A),'verdict':'not-completed'});continue
    dif=[A[s]['nashConv']-B[s]['nashConv'] for s in plan['seeds']];n=len(dif);mean=statistics.mean(dif);half=float(stats.t.ppf(1-.05/(2*family),n-1))*statistics.stdev(dif)/math.sqrt(n)
    comp.append({'game':game,'arm':arm,'kind':kind,'budget':budget,'n':n,'difference':mean,'simultaneousCi95':[mean-half,mean+half],'baselineMean':statistics.mean(r['nashConv'] for r in B.values()),'candidateMean':statistics.mean(r['nashConv'] for r in A.values()),'familySize':family,'verdict':'better' if mean+half<0 else 'worse' if mean-half>0 else 'unresolved'})
report={'plan':plan,'comparisons':comp,'rows':len(rows),'plannedRows':840,'predeclaredFamilySize':family,'incompleteComparisons':missing,'completion':'incomplete: heads-up river and three-player river completed; four-player exact ICM interrupted after one candidate/seed, no ICM comparative conclusion','reason':'Session usage interruption, followed by feasibility review: observed exact ICM evaluation takes 64–71 seconds per checkpoint on the experiment host; remaining 276 evaluations require several hours. No outcome-based selection; original 72-contrast multiplicity penalty retained.'}
(out/'summary.json').write_text(json.dumps(report,indent=2));(out/'INTERRUPTION.md').write_text('# Incomplete ICM comparison\n\n'+report['reason']+'\n\n'+report['completion']+'\n');print(len(rows),'rows;',len(comp),'completed contrasts;',len(missing),'not completed; correction family',family)
