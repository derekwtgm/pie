# Explicit scope limits

This is an incremental functioning release. It does not complete every proposed research direction.

- No newly derived CFR algorithm, learned baseline state, adaptive opponent exploration, street-dependent regret weighting or new chance-sampling distribution was added. Existing configurable methods are compared, including a new experiment with DCFR average exponent gamma=3. The default trainer remains unchanged.
- No CUDA kernel or hybrid scheduler was changed. Existing CPU, Automatic, Hybrid and GPU-preferred modes remain supported. No physical NVIDIA GPU was available.
- Confidence remains 95%. Selectable confidence, a bootstrap procedure, distribution-free bounds and sequential adaptive sampling were not implemented. The existing conservative calculation is preserved and its synthetic rare-tail limitation is disclosed.
- No automatic study-level checkpoint interval or resumption. Existing solver raw/EMZ1 checkpoints and partial study measurements remain supported; research experiments retain checkpoints at every measured budget.
- Progress adds periodic training diagnostics and observed device, but no continuously measured evaluation percentage, global ETA or recovery after killing an in-flight study process.
- No new work-stealing scheduler, NUMA optimization or external-memory solver. Resource controls retain their table/cache scope rather than a global process cap.
- No certification of full eight-handed no-limit Hold'em equilibrium accuracy. Exact small abstractions do not certify the full game; sampled one-decision gains cannot certify even their own abstraction.
- Native Windows runtime/UI, physical RTX 4060 Ti validation, target-i7 performance and leak checking remain unverified.
