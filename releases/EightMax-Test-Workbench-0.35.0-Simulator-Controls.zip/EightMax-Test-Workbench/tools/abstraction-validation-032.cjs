'use strict';
/* 0.32: independent re-measurement of the mappings enabled at runtime (src/approximate-lookup.js) on NEW random examples
 * (default seed 320, never used in 0.31); every pair records target and source pot and stacks (so SPR differences are visible). Same method as the 0.31 tool, unchanged otherwise.
 * usage: node tools/abstraction-validation-032.cjs [--mappings=chip-scale,pot-bucket-10pct] [--pairs=30] [--seed=320] --out=FILE
 * Original header: 0.31 abstraction compatibility and accuracy report (reports/0.31-abstraction-validation.json).
 * For every candidate mapping in src/strategy-abstraction.js: draw reference target situations (heads-up rivers with the library's
 * river menu), map each to its source situation, solve both exactly enough with the vectorised CFR+ (<= 0.02% of the pot), play
 * the source strategy in the target and measure the EXACT exploitability of that translated strategy (EV loss) and the action
 * differences. Verdict per mapping: accepted only if every pair has a compatible tree and the p95 EV loss is within the limit.
 * Scope: heads-up rivers only (where exact evaluation exists). Nothing here validates abstraction on flops, turns or multiway pots.
 * usage: node tools/abstraction-validation-031.cjs [--pairs=24] [--limit=1.0] [--seed=31] --out=FILE */
const fs = require('node:fs'), os = require('node:os');
const AB = require('../src/strategy-abstraction.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const pairs = +(args.pairs || 24), limitPct = +(args.limit || 1.0); let x = +(args.seed || 320) >>> 0 || 1; const only = String(args.mappings || 'chip-scale,pot-bucket-10pct').split(',');
const rnd = () => { x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; };
const RANGES = ['random', '22+,A2s+,K9s+,Q9s+,J9s+,T9s,98s,ATo+,KJo+', '22-JJ,A2s-AJs,K9s+,Q9s+,J9s+,T8s+,97s+,86s+,75s+,65s,54s,A9o-AJo,KTo+,QTo+,JTo'];
const STREETS = { river: { bets: '50,a', raises: 'a', maxBets: 2 } };
const cardStr = (c) => '23456789TJQKA'[c >> 2] + 'cdhs'[c & 3];
const q = (a, p) => { if (!a.length) return null; const s = a.slice().sort((u, v) => u - v); return +s[Math.min(s.length - 1, Math.ceil(p * s.length) - 1)].toFixed(4); };
function drawTarget() {
  const deck = []; while (deck.length < 5) { const c = Math.floor(rnd() * 52); if (!deck.includes(c)) deck.push(c); }
  const pot = +(3 + rnd() * 17).toFixed(2), s0 = +(4 + rnd() * 36).toFixed(2), s1 = rnd() < 0.5 ? s0 : +(4 + rnd() * 36).toFixed(2), r = RANGES[Math.floor(rnd() * RANGES.length)];
  return { board: deck, pot, stacks: [s0, s1], ranges: [r, rnd() < 0.5 ? r : RANGES[Math.floor(rnd() * RANGES.length)]] };
}
const cfgOf = (t) => ({ board: t.board.map(cardStr).join(''), common: t.pot, stacks: t.stacks, ranges: t.ranges, streets: STREETS, privateSeed: 1 });

(async () => {
  const t0 = Date.now(), doc = { format: 'eightmax-abstraction-validation', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), environment: { cpus: os.cpus().length, node: process.version },
    scope: 'Heads-up river reference games (library river menu: bet 50% pot / all-in, raise all-in, 2 bets), random boards, pots 3-20 bb, stacks 4-40 bb, three range families. EV loss is the exact exploitability (in the target game) of the source strategy played in the target. Abstractions on flops, turns and multiway pots are NOT validated by this report and are therefore not enabled for decisions.',
    errorLimit: { p95EvLossPctPot: limitPct, note: 'Same scale as the "research" quality policy (1% of the pot for heads-up exploitability).' }, mappings: {} };
  doc.seed = +(args.seed || 320); doc.independentOf = 'reports/0.31-abstraction-validation.json (seed 31)';
  for (const [name, m] of Object.entries(AB.MAPPINGS)) {
    if (!only.includes(name)) continue;
    const rows = []; let tries = 0;
    while (rows.length < pairs && tries < pairs * 6) {
      tries++; const t = drawTarget(); let s;
      if (name === 'river-blank-substitution') { const c = AB.blankSubstitute(t.board); if (c === null) continue; s = { ...t, board: t.board.slice(0, 4).concat(c) }; }
      else if (name === 'suit-isomorphism') { const perm = [1, 2, 3, 0]; s = { ...t, board: t.board.map((c) => (c & ~3) | perm[c & 3]) }; }
      else s = m.map(t);
      const same = JSON.stringify(cfgOf(s)) === JSON.stringify(cfgOf(t));
      const cardMap = name === 'suit-isomorphism' ? (c) => (c & ~3) | [1, 2, 3, 0][c & 3] : undefined;
      let r; try { r = AB.validatePair(cfgOf(t), cfgOf(s), { iterations: 800, cardMap }); } catch (e) { r = { compatible: false, reason: 'error: ' + e.message }; }
      rows.push({ target: { board: cfgOf(t).board, pot: t.pot, stacks: t.stacks, ranges: t.ranges.map((x) => (x === 'random' ? 'any-two' : x.length > 30 ? x.slice(0, 27) + '...' : x)) }, source: { board: cfgOf(s).board, pot: s.pot, stacks: s.stacks }, identical: same, ...r });
    }
    const ok = rows.filter((r) => r.compatible), loss = ok.map((r) => r.evLossPctPot), l1 = ok.map((r) => r.actionL1VsTargetSolution), ref = ok.map((r) => r.exploitabilityOfTargetSolutionBB / r.potBB * 100);
    const compatRate = rows.length ? ok.length / rows.length : 0, p95 = q(loss, 0.95);
    const verdict = m.kind === 'exact' ? (p95 !== null && p95 <= 0.05 ? 'accepted (exact mapping; measured loss equals solver precision)' : 'REJECTED: an exact mapping showed loss') : p95 === null ? 'REJECTED: no compatible pairs' : p95 <= limitPct ? (compatRate === 1 ? 'accepted' : 'accepted for compatible trees only (' + (compatRate * 100).toFixed(0) + '% compatible; incompatible states are refused at run time)') : 'REJECTED: p95 EV loss ' + p95 + '% of pot exceeds the ' + limitPct + '% limit';
    doc.mappings[name] = { kind: m.kind, definition: m.definition, preserves: m.preserves, loses: m.loses, pairsTested: rows.length, compatiblePairs: ok.length, compatibilityRate: +compatRate.toFixed(4), pairsWhereMappingChangedNothing: rows.filter((r) => r.identical).length,
      evLossPctPot: { mean: ok.length ? +(loss.reduce((a, b) => a + b, 0) / ok.length).toFixed(4) : null, p50: q(loss, 0.5), p95, max: ok.length ? +Math.max(...loss).toFixed(4) : null },
      actionL1: { mean: ok.length ? +(l1.reduce((a, b) => a + b, 0) / ok.length).toFixed(4) : null, p95: q(l1, 0.95) }, referenceSolverPrecisionPctPot: { max: ok.length ? +Math.max(...ref).toFixed(4) : null },
      incompatibleReasons: rows.filter((r) => !r.compatible).slice(0, 6).map((r) => r.reason), verdict, enabledForDecisionsByDefault: false, pairs: rows };
    process.stderr.write(name + ': ' + ok.length + '/' + rows.length + ' compatible, EV loss p50/p95/max ' + doc.mappings[name].evLossPctPot.p50 + '/' + p95 + '/' + doc.mappings[name].evLossPctPot.max + ' % pot -> ' + verdict + '\n');
    if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1));
  }
  doc.elapsedMs = Date.now() - t0; if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); else console.log(JSON.stringify(doc, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
