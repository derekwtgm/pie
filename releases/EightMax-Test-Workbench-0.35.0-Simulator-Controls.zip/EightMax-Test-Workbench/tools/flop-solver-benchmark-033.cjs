'use strict';
/* 0.33 restricted HEADS-UP FLOP solver benchmark (reports/0.33-flop-solver-benchmark.json).
 * For each configuration (board x range width x bet menu x stack depth): exact full-width CFR+ over flop + every turn + every river card
 * (src/flop-solver.js), stopping at the target (default 0.5 % of the pot) or the time limit. Every reported exploitability comes from the
 * INDEPENDENT evaluator src/fast-multistreet.js (own traversal, showdown and best response); the stored linked record (.emlk) is re-read
 * and re-evaluated (src/strategy-quality.js evaluateLinked) and must give the same number. Also measured:
 *   - checkpoint / resume: N iterations + N more from a checkpoint == 2N uninterrupted (bit-identical tables)
 *   - threads: the same solve on 1 and on T worker threads (wall time; results agree to floating-point summation order)
 *   - a third evaluator: src/independent-eval.js (own rules / pots / evaluator) on a tiny flop game, compared with fast-multistreet
 * usage: node tools/flop-solver-benchmark-033.cjs [--maxMs=240000] [--target=0.5] [--threads=3] [--quick] --out=FILE */
const fs = require('node:fs'), os = require('node:os');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), MS = require('../src/fast-multistreet.js'), FS = require('../src/flop-solver.js'), LK = require('../src/linked-study.js'), Q = require('../src/strategy-quality.js'), IE = require('../src/independent-eval.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const maxMs = +(args.maxMs || 240000), targetPct = +(args.target || 0.5), threads = +(args.threads || Math.min(4, os.cpus().length));
const POT = 6;
const RANGES = { 'narrow (~45 combos)': 'AA,KK,QQ,77,AK,KQs,QJs,JTs,T9s', 'medium (~110 combos)': 'TT+,77,22,AK,AQ,AJs,KQ,KJs,QJs,JTs,T9s,98s,87s', 'wide (~200 combos)': '22+,AJ+,KQ,ATs+,KTs+,QTs+,J9s+,T8s+,97s+,87s,76s' };
const MENUS = { '1 size': (s) => ({ flop: s, turn: s, river: s }) };
const ONE = { bets: '75', raises: 'a', maxBets: 1 }, TWO = { bets: '33,a', raises: 'a', maxBets: 2 };
const BOARDS = ['As7d2h', 'Th9h4c', '8s8d3c'];
const STACKS = { 'SPR 2': [12, 12], 'SPR 4': [24, 24] };
function cases() {
  const out = [];
  for (const b of BOARDS) out.push({ board: b, ranges: 'narrow (~45 combos)', menu: '75% pot, all-in raise, 1 bet/street', streets: MENUS['1 size'](ONE), stacks: 'SPR 2' });
  if (args.quick) return out;
  out.push({ board: 'As7d2h', ranges: 'narrow (~45 combos)', menu: '75% pot, all-in raise, 1 bet/street', streets: MENUS['1 size'](ONE), stacks: 'SPR 4' });
  out.push({ board: 'As7d2h', ranges: 'narrow (~45 combos)', menu: '33% or all-in, all-in raise, 2 bets/street', streets: MENUS['1 size'](TWO), stacks: 'SPR 2' });
  out.push({ board: 'Th9h4c', ranges: 'medium (~110 combos)', menu: '75% pot, all-in raise, 1 bet/street', streets: MENUS['1 size'](ONE), stacks: 'SPR 2' });
  out.push({ board: 'As7d2h', ranges: 'wide (~200 combos)', menu: '75% pot, all-in raise, 1 bet/street', streets: MENUS['1 size'](ONE), stacks: 'SPR 2' });
  return out;
}
const cfgOf = (c) => ({ board: c.board, common: POT, stacks: STACKS[c.stacks], ranges: [RANGES[c.ranges], RANGES[c.ranges]], streets: c.streets, privateSeed: 1 });

(async () => {
  const doc = { format: 'eightmax-flop-solver-benchmark', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), machine: { cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, node: process.version, totalMemBytes: os.totalmem() },
    game: 'heads-up flop subgame, pot ' + POT + ' bb, flop + every turn and river card enumerated, exact private hands, chip EV; both players use the same range',
    solver: 'src/flop-solver.js full-width CFR+ (alternating, RM+, linear averaging)', evaluator: 'src/fast-multistreet.js exact best response (independent code path)', stopRule: 'exploitability <= ' + targetPct + ' % of the pot or ' + maxMs + ' ms', results: [], checks: {} };
  const save = () => { if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); };
  for (const c of cases()) {
    const cfg = cfgOf(c), p = A.prepare(EM, { config: cfg, iterations: 1 }), t0 = Date.now(); let res;
    try { res = await FS.solveParallel(cfg, { iterations: 5000, every: 25, target: targetPct / 100 * POT, deadline: Date.now() + maxMs, maxBytes: 6 * 2 ** 30, threads }); }
    catch (e) { doc.results.push({ ...c, streets: undefined, error: e.message, code: e.code }); save(); continue; }
    const wall = Date.now() - t0, stand = { game: { view: (s) => p.game.view(s), iterations: res.iterations, averageAt: (a, b, cc, d) => res.strategy.averageAt(a, b, cc, d) }, spec: p.spec, options: p.options };
    const te = Date.now(), bytes = LK.exportLinked(stand, { EM }), exportMs = Date.now() - te, rec = LK.open(bytes), tv = Date.now(), ev = Q.evaluateLinked(rec, { potBB: POT }), evMs = Date.now() - tv;
    const row = { board: c.board, ranges: c.ranges, menu: c.menu, stacks: c.stacks, combos: res.core.hands.map((h) => h.length), decisionNodes: res.core.tree.decisions, threads: res.threads, iterations: res.iterations, stopped: res.stopped, wallMs: wall,
      msPerIteration: +(res.solveMs / Math.max(1, res.iterations)).toFixed(1), memoryEstimateMiB: +(res.estimate.bytes / 1048576).toFixed(1), exploitabilityBB: +res.exploitability.toFixed(6), exploitabilityPctPot: +res.exploitabilityPctPot.toFixed(4),
      meetsTarget: res.exploitabilityPctPot <= targetPct, curve: res.curve.map((x) => [x.iterations, +x.pctPot.toFixed(4), x.ms]),
      linkedRecord: { bytes: bytes.length, exportMs, storedRows: rec.meta.counts.storedRows, missingRows: rec.meta.counts.missingRows, impossibleRows: rec.meta.counts.impossibleRows, boards: rec.meta.counts.boards, reEvaluatedExploitabilityBB: ev.exploitabilityBB, reEvaluationMs: evMs, equalToSolverEvaluation: Math.abs(ev.exploitabilityBB - res.exploitability) < 1e-9 } };
    doc.results.push(row); save();
    process.stderr.write(c.board + ' / ' + c.ranges + ' / ' + c.menu + ' / ' + c.stacks + ': ' + row.iterations + ' it, ' + row.exploitabilityPctPot + '% pot, ' + wall + ' ms, linked ' + bytes.length + ' B, missing ' + row.linkedRecord.missingRows + ' (' + row.stopped + ')\n');
  }
  // checkpoint / resume determinism (single thread)
  { const cfg = cfgOf(cases()[0]), p = A.prepare(EM, { config: cfg, iterations: 1 });
    const full = FS.solve(p.game, p.spec, { iterations: 30, evaluate: false }), half = FS.solve(p.game, p.spec, { iterations: 15, evaluate: false }), resumed = FS.solve(p.game, p.spec, { iterations: 30, evaluate: false, resume: half.checkpoint() });
    const a = full.checkpoint().subarray(4, 36), b = resumed.checkpoint().subarray(4, 36);
    doc.checks.checkpointResume = { iterations: '15 + 15 vs 30', identical: Buffer.compare(a, b) === 0, checkpointBytes: half.checkpoint().length }; save(); }
  // thread scaling on the first case (fixed iteration count)
  { const cfg = cfgOf(cases()[0]), runs = [];
    for (const t of [1, threads]) { const t0 = Date.now(), r = await FS.solveParallel(cfg, { iterations: 40, every: 40, threads: t }); runs.push({ threads: t, wallMs: Date.now() - t0, exploitabilityBB: r.exploitability }); }
    doc.checks.threads = { iterations: 40, runs, relativeDifference: Math.abs(runs[0].exploitabilityBB - runs[1].exploitabilityBB) / runs[0].exploitabilityBB, speedup: +(runs[0].wallMs / runs[1].wallMs).toFixed(2), note: 'includes one independent evaluation per run; results differ only by floating-point summation order of the flop regret increments' }; save(); }
  // third evaluator on a tiny flop game: fast-multistreet vs independent-eval on the same solver output
  { const cfg = { board: 'Kd8s3c', common: POT, stacks: [9, 9], ranges: ['AA,KK,88,AK,QJs', 'AA,KK,88,AK,QJs'], streets: { flop: ONE, turn: ONE, river: ONE }, privateSeed: 1 }, p = A.prepare(EM, { config: cfg, iterations: 1 });
    const r = FS.solve(p.game, p.spec, { iterations: 40, every: 40 }), G = IE.holdem({ board: cfg.board, common: POT, stacks: cfg.stacks, hands: p.spec.hands.map((l) => l.map((h) => [h[1], h[2], h[3]])), streets: cfg.streets });
    const geo = IE.compareGeometry(G, (s) => p.game.view(s)), t0 = Date.now(), e = IE.evaluate(G, (seat, node, board, ti, type) => { const h = p.spec.hands[seat][type.src]; return r.strategy.averageAt(node.path, board, seat, { id: h[0], a: h[1], b: h[2], w: h[3] }); });
    doc.checks.thirdEvaluator = { game: 'Kd8s3c, ' + G.types.map((t) => t.length).join(' vs ') + ' combos', geometry: { nodes: geo.checked, mismatches: geo.mismatches.length }, fastMultiStreet: { exploitabilityBB: r.exploitability, values: r.values }, independentEval: { exploitabilityBB: e.exploitability, values: e.values, missingRows: e.missingRows, ms: Date.now() - t0 }, absoluteDifference: Math.abs(e.exploitability - r.exploitability) }; save(); }
  save(); if (!args.out) console.log(JSON.stringify(doc, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
