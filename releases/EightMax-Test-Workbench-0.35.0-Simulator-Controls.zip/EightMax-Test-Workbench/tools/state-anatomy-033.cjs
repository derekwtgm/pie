'use strict';
/* 0.33 native state anatomy: where does the memory of an EightMax external-sampling study (EMMW4 state) go?
 *
 * Streams the state file once (never loads it) and attributes, per street (preflop / flop / turn / river):
 *   - betting states in the tree table and information-set rows (exact counts),
 *   - row bytes on disk (12-byte key + 16 bytes per action: regret and average as f64),
 *   - an estimate of the engine's in-memory cost per row (values + row metadata + row hash, the same model as
 *     es::restoreEstimate in native/source/mw_es.hpp: 16 B/action values, rowMetaBytes per row, 2 x 12 B hash buckets per row),
 *   - "visit mass": the sum of a row's average-strategy accumulator. Rows are created on first visit, so a row exists = visited at
 *     least once; a row whose average mass is tiny compared with the street median was visited rarely or with negligible reach.
 *     Reported as quantiles and as the share of rows below 1 % of the street median (a RELATIVE indicator, not a visit count:
 *     the engine does not store visit counts).
 *   - rows per (state, board) context: postflop rows keyed by exact board + exact hand are mostly singletons.
 * The layout is documented in native/source/MW-PROTOCOL.md and read by src/strategy-store.js; this reader is independent of it.
 * usage: node tools/state-anatomy-033.cjs STATE [--json] [--rowMetaBytes=24] */
const fs = require('node:fs');
const STREET = { 0: 'preflop', 3: 'flop', 4: 'turn', 5: 'river' };

function anatomy(file, o = {}) {
  const fd = fs.openSync(file, 'r'), size = fs.fstatSync(fd).size, rowMetaBytes = o.rowMetaBytes || 24;
  try {
    const rd = (pos, len) => { const b = Buffer.allocUnsafe(len); let got = 0; while (got < len) { const n = fs.readSync(fd, b, got, len - got, pos + got); if (n <= 0) throw new Error('truncated state'); got += n; } return b; };
    const top = rd(0, 12); if (top.toString('latin1', 0, 5) !== 'EMMW4') throw new Error('not an EMMW4 state');
    const hl = top.readUInt32LE(8), head = JSON.parse(rd(12, hl).toString('utf8')), keyed = head.rowKeys === 1;
    if (head.rowSync !== undefined) throw new Error('DCFR row layout (rowSync) is not supported');
    let p = 12 + hl; const sc = rd(p, 4).readUInt32LE(0); p += 4; const tb = rd(p, sc * 9); p += sc * 9;
    const len = new Uint8Array(sc), kind = new Uint8Array(sc);
    const streets = {}; const S = (l) => (streets[STREET[l]] = streets[STREET[l]] || { states: 0, decisionStates: 0, rows: 0, diskBytes: 0, valueBytes: 0, engineBytesEstimate: 0, mass: [], contexts: new Map(), actionsTotal: 0 });
    for (let i = 0; i < sc; i++) { len[i] = tb[i * 9 + 7]; kind[i] = tb[i * 9 + 5]; const s = S(len[i]); s.states++; if (kind[i] === 0) s.decisionStates++; }
    const rowCount = rd(p, 4).readUInt32LE(0); p += 4;
    const CH = 8 << 20, buf = Buffer.allocUnsafe(CH); let carry = Buffer.alloc(0), pos = p, seen = 0;
    const sampleEvery = Math.max(1, Math.floor(rowCount / (o.massSamples || 400000)));   // bounded quantile sample
    while (seen < rowCount) {
      const n = fs.readSync(fd, buf, 0, Math.min(CH, size - pos), pos); if (n <= 0) throw new Error('truncated rows');
      pos += n; const data = carry.length ? Buffer.concat([carry, buf.subarray(0, n)]) : buf.subarray(0, n); let q = 0;
      while (seen < rowCount) {
        let k, L, vo;   // vo: offset of the regrets (averages follow)
        if (keyed) { if (q + 6 > data.length) break; const kl = data.readUInt16LE(q + 4); if (q + 7 + kl > data.length) break; k = data[q + 6 + kl]; L = 7 + kl + 16 * k; vo = q + 7 + kl; }
        else { if (q + 12 > data.length) break; k = data[q + 11]; L = 12 + 16 * k; vo = q + 12; }
        if (q + L > data.length) break;
        const st = data.readUInt32LE(q), s = S(len[st]);
        s.rows++; s.diskBytes += L; s.valueBytes += 16 * k; s.actionsTotal += k; s.engineBytesEstimate += 16 * k + rowMetaBytes + 24;
        if (seen % sampleEvery === 0) { let m = 0; for (let a = 0; a < k; a++) m += data.readDoubleLE(vo + 8 * k + 8 * a); s.mass.push(m); }
        if (len[st] > 0 && !keyed) { const ctx = st * 1e10 + (data[q + 6] * 53 + data[q + 7]) * 2809 + data[q + 8] * 53 + data[q + 9] + data[q + 10] * 1e-3; s.contexts.set(ctx, (s.contexts.get(ctx) || 0) + 1); if (s.contexts.size > 3e6) s.contexts.clear(), s.contextsTruncated = true; }
        q += L; seen++;
      }
      carry = Buffer.from(data.subarray(q));
    }
    const totalRows = Object.values(streets).reduce((a, s) => a + s.rows, 0), totalDisk = Object.values(streets).reduce((a, s) => a + s.diskBytes, 0);
    const out = { layout: keyed ? 'grouped keys (rowKeys=1)' : 'exact rows', file: require('node:path').basename(file), fileBytes: size, iterations: head.iterations, trainingDeals: head.trainingDeals, stateVisits: head.stateVisits, stateTableBytes: sc * 9, states: sc, rows: rowCount,
      engineModel: { perRow: '16 B per action (regret + average f64) + ' + rowMetaBytes + ' B row metadata + 24 B row-hash share (2 x 12 B buckets)', perState: '9 B state table + 24 B state-hash share' }, streets: {} };
    for (const [name, s] of Object.entries(streets)) {
      const m = s.mass.sort((a, b) => a - b), qt = (f) => (m.length ? +m[Math.min(m.length - 1, Math.floor(f * m.length))].toPrecision(4) : null), med = qt(0.5);
      const ctxSizes = [...s.contexts.values()]; const singles = ctxSizes.filter((c) => c === 1).length;
      out.streets[name] = { states: s.states, decisionStates: s.decisionStates, rows: s.rows, rowShare: +(s.rows / Math.max(1, totalRows)).toFixed(4), diskBytes: s.diskBytes, diskShare: +(s.diskBytes / Math.max(1, totalDisk)).toFixed(4),
        meanActions: +(s.actionsTotal / Math.max(1, s.rows)).toFixed(3), engineBytesEstimate: s.engineBytesEstimate + s.states * 33,
        averageMassQuantiles: { p01: qt(0.01), p10: qt(0.1), p50: med, p90: qt(0.9), p99: qt(0.99) }, rowsBelow1PctOfMedianMass: med ? +(m.filter((x) => x < 0.01 * med).length / m.length).toFixed(4) : null,
        ...(name !== 'preflop' ? { contexts: ctxSizes.length, meanRowsPerContext: +(s.rows / Math.max(1, ctxSizes.length)).toFixed(3), singleRowContextShare: +(singles / Math.max(1, ctxSizes.length)).toFixed(4), contextsTruncated: !!s.contextsTruncated } : {}) };
    }
    const post = ['flop', 'turn', 'river'].reduce((a, k) => a + (out.streets[k] ? out.streets[k].rows : 0), 0);
    out.postflopRowShare = +(post / Math.max(1, totalRows)).toFixed(4);
    return out;
  } finally { fs.closeSync(fd); }
}
module.exports = { anatomy };
if (require.main === module) {
  const args = process.argv.slice(2), file = args.find((a) => !a.startsWith('--')); if (!file) { console.error('usage: node tools/state-anatomy-033.cjs STATE'); process.exit(2); }
  console.log(JSON.stringify(anatomy(file), null, 1));
}
