'use strict';
/* Train the eight-seat 25 BB preflop push/fold study and return a prepared study.
 * Uses the native EightMax CLI when given (EIGHTMAX_TEST_CLI on Linux, native\mwcli.exe on Windows), otherwise the
 * JavaScript reference engine (slow: ~4,000 updates/s). The trained state is cached by update count. */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js');

function cliPath() {
  if (process.env.EIGHTMAX_TEST_CLI && fs.existsSync(process.env.EIGHTMAX_TEST_CLI)) return process.env.EIGHTMAX_TEST_CLI;
  const exe = path.join(__dirname, '..', 'native', 'mwcli.exe');
  if (process.platform === 'win32' && fs.existsSync(exe)) return exe;
  return null;
}
function trainStudy(updates, options = {}) {
  const cfg = options.name || options.example || 'preflop8', cacheDir = options.cacheDir || path.join(os.tmpdir(), 'eightmax-study-cache');
  const prepared = A.prepare(EM, { config: options.config || A.EXAMPLES[cfg], iterations: updates, timeMs: 600000, strategyBudgetMiB: options.budgetMiB });
  const cli = options.forceJs ? null : cliPath();
  fs.mkdirSync(cacheDir, { recursive: true });
  const state = path.join(cacheDir, cfg + '-' + updates + (cli ? '-native' : '-js') + '.state');
  let backend;
  if (fs.existsSync(state)) { prepared.game.importNative(fs.readFileSync(state)); backend = cli ? 'native-cli-cpu (cached state)' : 'javascript-reference-cpu (cached state)'; }
  else if (cli) {
    const spec = path.join(cacheDir, cfg + '-' + updates + '.spec.json'), tmp = state + '.tmp' + process.pid;
    fs.writeFileSync(spec, JSON.stringify(A.nativeJob(prepared, 'train').spec));
    const r = cp.spawnSync(cli, [spec, String(updates), String(options.threads || 4), tmp, String(options.budgetMiB ? Math.max(512, options.budgetMiB * 2) : 512)], { encoding: 'utf8', timeout: 600000 });
    if (r.status !== 0) throw new Error('Native training failed: ' + (r.stderr || r.stdout || r.status));
    // 0.26: a run that filled its memory budget exits 0 but is SHORTER than requested; 0.25 used it as if complete. Refuse it (use trainStudyLazy with a larger budget).
    try { const run = require('../src/strategy-budget.js').interpretNativeRun(JSON.parse(r.stdout.trim().split('\n').pop()), updates); if (!run.complete) { fs.rmSync(tmp, { force: true }); const e = new Error('Native study is ' + run.status + ': ' + run.reason + '. Use trainStudyLazy with a larger budget (see docs/STRATEGY-MEMORY.md).'); e.code = run.status; throw e; } } catch (e) { if (e.code === 'memory-limited' || e.code === 'cancelled' || e.code === 'invalid') throw e; }
    fs.renameSync(tmp, state); prepared.game.importNative(fs.readFileSync(state)); backend = 'native-cli-cpu';
  } else { prepared.game.iterate(updates); fs.writeFileSync(state, Buffer.from(prepared.game.exportNative())); backend = 'javascript-reference-cpu'; }
  return { prepared, backend, updates: prepared.game.iterations, statePath: state, EM };
}

/* 0.26: the old synchronous path imported the whole native state into the JavaScript heap and, worse, accepted a run that had stopped at its memory ceiling.
 * trainStudyLazy trains under an explicit, planner-checked budget (resuming at a larger one when permitted), verifies the state, and answers lookups from the
 * state file through a bounded cache - the strategy table is never copied into Node. Preflop information sets only (what PreflopTreeSource reads). */
async function trainStudyLazy(updates, options = {}) {
  const N = require('./native-training.cjs'), { nativeBackedGame } = require('../src/strategy-store.js');
  const cfg = options.name || options.example || 'preflop8', cacheDir = options.cacheDir || path.join(os.tmpdir(), 'eightmax-study-cache'), cli = options.cli || cliPath();
  if (!cli) { const e = new Error('Lazy native studies need the native EightMax engine (EIGHTMAX_TEST_CLI or native/mwcli.exe)'); e.code = 'no-engine'; throw e; }
  const prepared = A.prepare(EM, { config: options.config || A.EXAMPLES[cfg], iterations: updates, timeMs: 600000, strategyBudgetMiB: 32 });
  fs.mkdirSync(cacheDir, { recursive: true });
  // 0.32: options.specPatch adds native-only trainer settings (e.g. opponentExploration, ownHandEnumeration) to the native spec of a
  // RESEARCH variant; the variant must be part of options.name so different variants never share a cached state.
  const spec = A.nativeJob(prepared, 'train').spec; if (options.specPatch) Object.assign(spec, options.specPatch);
  const specFile = path.join(cacheDir, cfg + '.spec.json'); fs.writeFileSync(specFile, JSON.stringify(spec));
  // 0.32: options.continueFromSmaller resumes the largest complete shorter state of the same name (if any)
  let continueFrom = null;
  if (options.continueFromSmaller) { const re = new RegExp('^' + cfg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '-(\\d+)\\.state$'); let best = 0; for (const f of fs.readdirSync(cacheDir)) { const m = re.exec(f); if (!m) continue; const u = +m[1]; const mf = path.join(cacheDir, cfg + '-' + u + '.meta.json'); if (u < updates && u > best && fs.existsSync(mf)) { try { if (JSON.parse(fs.readFileSync(mf, 'utf8')).status === 'complete') { best = u; continueFrom = path.join(cacheDir, f); } } catch (e) { /* ignore unreadable meta */ } } } }
  const r = await N.ensureStudy({ cli, specFile, updates, continueFrom, budgetMiB: options.budgetMiB || 1024, threads: options.threads || 2, dir: cacheDir, name: cfg, autoEscalate: options.autoEscalate !== false, system: options.system, cacheBytes: options.cacheBytes, signal: options.signal });
  const base = prepared.game; prepared.game = nativeBackedGame(base, prepared, r.store);
  return { prepared, backend: 'native-cli-cpu (lazy state file)', updates: r.meta.updatesDone, requestedUpdates: updates, complete: r.meta.status === 'complete', meta: r.meta, store: r.store, statePath: r.store.file, EM };
}
/* 0.32: SHARED preflop strategy. The lazy reader's index covers the whole linked tree (hundreds of MB per reader); decisions read
 * preflop information sets only. preflopSnapshotFor() trains/locates the study once, extracts its preflop strategy into a compact
 * immutable snapshot (src/preflop-snapshot.js, cached as <state>.emps, rebuilt when the state's CRC changes), and returns it in a
 * SharedArrayBuffer that worker threads receive WITHOUT copying. preparedFromSnapshot() is what each worker does with it. */
async function preflopSnapshotFor(updates, options = {}) {
  const PS = require('../src/preflop-snapshot.js');
  // fast path: a complete study whose cached snapshot names the state's row CRC and update count is loaded WITHOUT opening the
  // whole-tree index (the snapshot body hash is verified on load; the state itself was verified when the snapshot was built)
  { const name = options.name || options.example || 'preflop8', cacheDir = options.cacheDir || path.join(os.tmpdir(), 'eightmax-study-cache'), base = path.join(cacheDir, name + '-' + updates), st = base + '.state', mf = base + '.meta.json', file = st + '.emps';
    try { const meta = JSON.parse(fs.readFileSync(mf, 'utf8')); if (meta.status === 'complete' && fs.existsSync(file)) { const h = stateHeader(st), l = PS.load(file, { shared: true }); if (l.snapshot.header.sourceRowCrc32 === h.rowCrc32 && l.snapshot.header.iterations === h.iterations && h.iterations === meta.updatesDone) return { buffer: l.buffer, fingerprint: l.snapshot.fingerprint(), updates: h.iterations, complete: true, requestedUpdates: updates, file, buildMs: 0, stateFile: st, fastPath: true }; } } catch (e) { /* fall through to the full path */ } }
  const s = await trainStudyLazy(updates, options), file = s.statePath + '.emps', crc = s.store.header.rowCrc32;
  let loaded = null;
  if (fs.existsSync(file)) { try { const l = PS.load(file, { shared: true }); if (l.snapshot.header.sourceRowCrc32 === crc && l.snapshot.header.iterations === s.store.header.iterations) loaded = l; } catch (e) { loaded = null; } }
  if (!loaded) { const t0 = Date.now(); const buf = PS.build(s.store, { studyId: 'preflop8-linked-' + s.updates, shared: true }); PS.save(buf, file); loaded = { buffer: buf, snapshot: PS.open(buf, { verify: false }), buildMs: Date.now() - t0 }; }
  s.store.close();   // the whole-tree index is no longer needed in this process
  return { buffer: loaded.buffer, fingerprint: loaded.snapshot.fingerprint(), updates: s.updates, complete: s.complete, requestedUpdates: updates, file, buildMs: loaded.buildMs || 0, stateFile: s.statePath };
}
function stateHeader(f) { const fd = fs.openSync(f, 'r'); try { const top = Buffer.alloc(12); fs.readSync(fd, top, 0, 12, 0); if (top.toString('latin1', 0, 5) !== 'EMMW4') throw new Error('not an EMMW4 state'); const hl = top.readUInt32LE(8), b = Buffer.alloc(hl); fs.readSync(fd, b, 0, hl, 12); return JSON.parse(b.toString('utf8')); } finally { fs.closeSync(fd); } }
/** In a worker (or the main thread): a prepared preflop study answering from a shared snapshot. expect: fingerprint to verify. */
function preparedFromSnapshot(buffer, options = {}) {
  const PS = require('../src/preflop-snapshot.js'), snap = PS.open(buffer, { verify: !!options.verify, expect: options.expect });
  const prepared = A.prepare(EM, { config: options.config || require('./studies.cjs').PREFLOP8_LINKED, iterations: snap.iterations, timeMs: 600000, strategyBudgetMiB: 8 });
  const base = prepared.game; prepared.game = PS.snapshotBackedGame(base, prepared, snap);
  return { prepared, backend: 'native-cli-cpu (shared preflop snapshot)', updates: snap.iterations, complete: true, snapshot: snap, EM };
}
module.exports = { trainStudy, trainStudyLazy, cliPath, preflopSnapshotFor, preparedFromSnapshot };
