'use strict';
/* EightMax Test Workbench 0.26: budgeted, resumable, honest native training.
 *  - the memory budget is a parameter (checked by src/strategy-budget.js), never a constant;
 *  - a run that hits its memory ceiling is reported as 'memory-limited' (0.25 treated it as success);
 *  - a memory-limited study can be CONTINUED from its own state at a larger budget (mwcli resume), never restarted;
 *  - output is written to a temporary file, verified by the lazy reader (CRC, tree table, rows) and renamed atomically,
 *    so an interrupted or failed write leaves the previous state untouched;
 *  - training runs in a child process: it never blocks the dashboard or the solver workers, and can be cancelled. */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
const B = require('../src/strategy-budget.js'), { StrategyStore } = require('../src/strategy-store.js');

function sha256File(f) { const h = crypto.createHash('sha256'), fd = fs.openSync(f, 'r'), b = Buffer.allocUnsafe(1 << 20); try { let n; while ((n = fs.readSync(fd, b, 0, b.length, null)) > 0) h.update(b.subarray(0, n)); } finally { fs.closeSync(fd); } return h.digest('hex'); }
/** Iteration count recorded in a native state header (cheap: reads only the header). */
function headerOf(f) { const fd = fs.openSync(f, 'r'); try { const top = Buffer.alloc(12); if (fs.readSync(fd, top, 0, 12, 0) < 12 || top.toString('latin1', 0, 5) !== 'EMMW4') throw new Error('not an EMMW4 state'); const hl = top.readUInt32LE(8), b = Buffer.alloc(hl); fs.readSync(fd, b, 0, hl, 12); return JSON.parse(b.toString('utf8')); } finally { fs.closeSync(fd); } }
function rm(f) { try { fs.rmSync(f, { force: true }); } catch (e) { /* temp cleanup only */ } }

/** 0.33: CRC-only verification for EMMW4 layouts the lazy reader does not index (rowKeys=1, compact preflop Mode B169). */
function verifyCrcOnly(file) {
  const zlib = require('node:zlib'), fd = fs.openSync(file, 'r');
  try { const size = fs.fstatSync(fd).size, top = Buffer.alloc(12); fs.readSync(fd, top, 0, 12, 0); if (top.toString('latin1', 0, 5) !== 'EMMW4') return false; const hl = top.readUInt32LE(8), hb = Buffer.alloc(hl); fs.readSync(fd, hb, 0, hl, 12); const head = JSON.parse(hb.toString('utf8')); if (!head.rowCrc32) return false;
    let crc = 0, pos = 12 + hl; const buf = Buffer.allocUnsafe(8 << 20); while (pos < size) { const n = fs.readSync(fd, buf, 0, Math.min(buf.length, size - pos), pos); if (n <= 0) return false; crc = zlib.crc32(buf.subarray(0, n), crc); pos += n; }
    return (crc >>> 0).toString(16).padStart(8, '0') === head.rowCrc32; } catch (e) { return false; } finally { fs.closeSync(fd); }
}
/** One native run. opts: cli, specFile, updates, budgetMiB, threads, outFile, resumeFrom, timeoutMs, signal. Resolves with { run, info, outFile, bytes, sha256 } or rejects with an Error that has .code. */
function trainNative(opts) {
  return new Promise((resolve, reject) => {
    const fail = (code, msg) => { const e = new Error(msg); e.code = code; rm(tmp); reject(e); };
    const tmp = opts.outFile + '.tmp' + process.pid + '-' + Math.random().toString(36).slice(2, 7);
    if (!opts.cli || !fs.existsSync(opts.cli)) return fail('no-engine', 'Native EightMax engine not found: ' + opts.cli);
    if (!Number.isInteger(opts.budgetMiB) || opts.budgetMiB < B.NATIVE_MIN_MIB || opts.budgetMiB > B.NATIVE_MAX_MIB) return fail('bad-budget', 'Native memory budget out of range');
    if (opts.resumeFrom && !fs.existsSync(opts.resumeFrom)) return fail('no-resume-state', 'State to resume from does not exist');
    // mwcli's iteration argument is the number of ADDITIONAL updates when a state is resumed (measured in 0.26), so convert the cumulative target
    let toRun = opts.updates, already = 0;
    if (opts.resumeFrom) { try { already = headerOf(opts.resumeFrom).iterations; } catch (e) { return fail('bad-resume-state', 'Cannot read the state to resume: ' + e.message); } toRun = opts.updates - already; if (toRun <= 0) return fail('nothing-to-do', 'State already has ' + already + ' updates (target ' + opts.updates + ')'); }
    const args = [opts.specFile, String(toRun), String(opts.threads || 1), tmp, String(opts.budgetMiB)]; if (opts.resumeFrom) args.push(opts.resumeFrom);
    const t0 = Date.now(), c = cp.spawn(opts.cli, args, { stdio: ['ignore', 'pipe', 'pipe'] }); let out = '', err = '', done = false;
    c.stdout.on('data', (d) => { out += d; if (out.length > 4e6) out = out.slice(-2e6); }); c.stderr.on('data', (d) => { err += d; if (err.length > 1e5) err = err.slice(-5e4); });
    const timer = setTimeout(() => { c.kill('SIGKILL'); fail('timeout', 'Native training exceeded ' + (opts.timeoutMs || 3600000) + ' ms and was stopped'); }, opts.timeoutMs || 3600000);
    const onAbort = () => { c.kill('SIGKILL'); clearTimeout(timer); fail('cancelled', 'Training cancelled'); };
    if (opts.signal) { if (opts.signal.aborted) return onAbort(); opts.signal.addEventListener('abort', onAbort, { once: true }); }
    c.on('error', (e) => { clearTimeout(timer); fail('spawn', 'Could not start the native engine: ' + e.message); });
    // 0.30: 'close' (not 'exit'): 'exit' can fire before the child's stdout has been read completely, which lost the result line
    // under concurrent training (reproduced: 3 of 9 concurrent library jobs failed with empty output and exit code 0).
    c.on('close', (code, sig) => {
      if (done) return; done = true; clearTimeout(timer); if (opts.signal) opts.signal.removeEventListener('abort', onAbort);
      if (sig || code !== 0) return fail('native-failed', 'Native training failed (' + (sig || code) + '): ' + (err || out).slice(-300));
      let info; try { info = JSON.parse(out.trim().split('\n').pop()); } catch (e) { return fail('bad-output', 'Native engine printed no result: ' + JSON.stringify(out.slice(-300)) + ' / ' + JSON.stringify(err.slice(-300))); }
      let store; try { store = StrategyStore.open(tmp, { cacheBytes: 0 }); store.close(); } catch (e) { if (e.code !== 'unsupported-layout' || !verifyCrcOnly(tmp)) return fail('bad-state', 'Written state failed verification: ' + e.message); }   // 0.33: class-keyed (rowKeys) compact preflop states: whole-body CRC verified instead
      try { fs.renameSync(tmp, opts.outFile); } catch (e) { return fail('write-failed', 'Could not replace the state file: ' + e.message); }
      const run = B.interpretNativeRun(info, opts.updates);   // info.iterations is cumulative (it includes the resumed updates)
      resolve({ run, info, outFile: opts.outFile, bytes: fs.statSync(opts.outFile).size, sha256: sha256File(opts.outFile), wallMs: Date.now() - t0 });
    });
  });
}

/**
 * Make sure a trained study exists at the requested length.
 * opts: cli, specFile, updates, budgetMiB, threads, dir, name, autoEscalate (default true), system: {totalRamBytes, freeRamBytes} (default os.*), cacheBytes
 * Returns { store, meta } where meta.status is 'complete' or 'memory-limited' (when no larger budget is permitted). The store is lazily read.
 */
async function ensureStudy(opts) {
  const dir = opts.dir, base = path.join(dir, opts.name + '-' + opts.updates), state = base + '.state', metaFile = base + '.meta.json';
  fs.mkdirSync(dir, { recursive: true });
  const sys = opts.system || { totalRamBytes: os.totalmem(), freeRamBytes: os.freemem() };
  const planned = B.plan({ ...sys, requestedMiB: opts.budgetMiB, hostMiB: opts.hostMiB });
  if (!planned.ok) { const e = new Error(planned.reason); e.code = planned.code; e.plan = planned; throw e; }
  if (fs.existsSync(state) && fs.existsSync(metaFile)) {
    try { const meta = JSON.parse(fs.readFileSync(metaFile, 'utf8')); if (meta.status === 'complete' || (meta.status === 'memory-limited' && !opts.autoEscalate)) { const store = StrategyStore.open(state, { cacheBytes: opts.cacheBytes }); if (meta.sha256 && meta.sha256 !== sha256File(state)) throw new Error('cached state does not match its recorded checksum'); return { store, meta: { ...meta, cached: true } }; } } catch (e) { rm(state); rm(metaFile); }
  }
  // 0.32: continue a SHORTER complete study of the same game instead of starting again (Continue Training / High-Accuracy mode).
  // The checkpoint carries the sampler state, so continuing to N updates follows the same algorithm as one N-update run.
  let continuedFrom = null;
  if (!fs.existsSync(state) && opts.continueFrom && fs.existsSync(opts.continueFrom)) { const h = headerOf(opts.continueFrom); if (h.iterations < opts.updates) { fs.copyFileSync(opts.continueFrom, state + '.cont'); fs.renameSync(state + '.cont', state); continuedFrom = { file: path.basename(opts.continueFrom), iterations: h.iterations }; } }
  let budget = opts.budgetMiB, resume = fs.existsSync(state) ? state : null, last; const history = [];
  for (;;) {
    last = await trainNative({ cli: opts.cli, specFile: opts.specFile, updates: opts.updates, budgetMiB: budget, threads: opts.threads, outFile: state, resumeFrom: resume, timeoutMs: opts.timeoutMs, signal: opts.signal });
    history.push({ budgetMiB: budget, status: last.run.status, updatesDone: last.run.updatesDone, resumed: !!resume, wallMs: last.wallMs, processPeakRssMiB: last.run.processPeakRssMiB, tableMiB: last.run.tableMiB });
    if (last.run.status !== 'memory-limited' || opts.autoEscalate === false) break;
    const bigger = B.nextBudget(budget, B.plan({ ...sys, hostMiB: opts.hostMiB })); if (!bigger) break;
    budget = bigger; resume = state;
  }
  const meta = { format: 'eightmax-workbench-study-meta', version: 1, name: opts.name, continuedFrom, status: last.run.status, updatesRequested: opts.updates, updatesDone: last.run.updatesDone, budgetMiB: budget, bytes: last.bytes, sha256: last.sha256, studyId: last.run.studyId, tableMiB: last.run.tableMiB, processPeakRssMiB: last.run.processPeakRssMiB, history, reason: last.run.reason || null };
  fs.writeFileSync(metaFile + '.tmp', JSON.stringify(meta, null, 1)); fs.renameSync(metaFile + '.tmp', metaFile);
  return { store: StrategyStore.open(state, { cacheBytes: opts.cacheBytes }), meta };
}
module.exports = { verifyCrcOnly, trainNative, ensureStudy, sha256File, headerOf };
