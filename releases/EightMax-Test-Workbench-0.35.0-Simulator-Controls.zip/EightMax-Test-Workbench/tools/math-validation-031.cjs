'use strict';
/* 0.31 independent mathematical validation (reports/0.31-math-validation.json). Extends tools/math-validation-030.cjs (re-run and
 * embedded unchanged) with:
 *   A reference games with different stacks, pots, range widths, bet menus and betting depth (heads-up rivers): independent
 *     full-width CFR+ reference (src/fast-river.js), EightMax native convergence over several seeds (mean, sd, t-based 95% CI),
 *     seed-to-seed strategy stability, training time;
 *   B multiplayer rivers: exact NashConv curves over seeds (NashConv, NOT exploitability);
 *   C quality-targeted training outcomes (what the 0.31 library actually stores) with the policy classification;
 *   D the 0.30 stored-record finding re-measured: fixed 20,000-update any-two-cards river studies vs the 0.31 trainers.
 * Every measurement names the exact game it applies to. Nothing here is a statement about the full eight-handed tournament game.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/math-validation-031.cjs [--seeds=5] [--quick] [--skip030] --out=FILE */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const T95 = { 1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262 };
function stat(a) { const n = a.length, m = a.reduce((x, y) => x + y, 0) / n, sd = n > 1 ? Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / (n - 1)) : 0, h = n > 1 ? (T95[n - 1] || 1.96) * sd / Math.sqrt(n) : null; return { n, mean: +m.toFixed(6), sd: +sd.toFixed(6), variance: +(sd * sd).toFixed(8), ci95: h === null ? null : [+(m - h).toFixed(6), +(m + h).toFixed(6)], min: +Math.min(...a).toFixed(6), max: +Math.max(...a).toFixed(6) }; }
module.exports = { stat };
if (require.main !== module) return;

const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), X = require('../src/exploitability.js'), F = require('../src/fast-river.js'), Q = require('../src/strategy-quality.js'), AT = require('../src/adaptive-training.js'), LS = require('../src/library-source.js'), SID = require('../src/strategy-identity.js'), AB = require('../src/strategy-abstraction.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const cli = process.env.EIGHTMAX_TEST_CLI || null, quick = !!args.quick, seeds = +(args.seeds || (quick ? 2 : 5)), work = fs.mkdtempSync(path.join(os.tmpdir(), 'em-math031-'));
function runNative(cfg, updates, seed) {
  const p = A.prepare(EM, { config: { ...cfg, privateSeed: seed }, iterations: updates, timeMs: 600000 }), tag = updates + '-' + seed + '-' + Math.random().toString(36).slice(2, 7), spec = path.join(work, tag + '.json'), st = path.join(work, tag + '.state');
  fs.writeFileSync(spec, JSON.stringify(A.nativeJob(p, 'v').spec)); const t0 = Date.now(), r = cp.spawnSync(cli, [spec, String(updates), '1', st, '1024'], { encoding: 'utf8', maxBuffer: 1 << 26 });
  if (r.status !== 0) throw new Error('native training failed: ' + r.stderr); p.game.importNative(fs.readFileSync(st)); fs.rmSync(st, { force: true }); fs.rmSync(spec, { force: true }); p.trainMs = Date.now() - t0; return p;
}
const GAMES = {
  'HU narrow, pot 10, stacks 20, 1 size + all-in, 2 bets': { board: 'Kh9s5c3d2h', common: 10, stacks: [20, 20], ranges: Array(2).fill('TT+,AJs+,KTs+,QJs,AQo+,KQo'), streets: { river: { bets: '50,a', raises: 'a', maxBets: 2 } } },
  'HU any-two, pot 6, stacks 24 (library river menu)': { board: 'Kh9s5c3d2h', common: 6, stacks: [24, 24], ranges: ['random', 'random'], streets: { river: { bets: '50,a', raises: 'a', maxBets: 2 } } },
  'HU medium/wide, pot 5.5, stacks 45, 2 sizes, 3 bets (deeper betting history)': { board: 'Qd8c5h4s2c', common: 5.5, stacks: [45, 45], ranges: ['22+,A2s+,K9s+,Q9s+,J9s+,T9s,98s,ATo+,KJo+', '22-JJ,A2s-AJs,K9s+,Q9s+,J9s+,T8s+,97s+,86s+,75s+,65s,54s,A9o-AJo,KTo+,QTo+,JTo'], streets: { river: { bets: '33,75', raises: 'a', maxBets: 3 } } },
  'HU short, pot 8, stacks 6 / 14 (uneven, all-in dominated)': { board: 'Ac7d7h3c2s', common: 8, stacks: [6, 14], ranges: ['random', '22+,A2s+,K2s+,Q8s+,J8s+,T8s+,A2o+,K9o+,QTo+'], streets: { river: { bets: '50,a', raises: 'a', maxBets: 2 } } },
  'HU polar vs condensed, pot 12, stacks 30, 3 sizes, 1 bet': { board: 'JdTd4c3s2h', common: 12, stacks: [30, 30], ranges: ['AA,KK,QQ,JJ,TT,44,33,22,AdKd,AdQd,9d8d,8d7d', 'AJ,KJ,QJ,JTs,J9s,AT,KT,QT,T9s'], streets: { river: { bets: '33,75,150', raises: 'a', maxBets: 1 } } },
};
const MW = {
  '3-way river, pot 9, stacks 20': { board: 'Qd8c5h4s2c', common: 9, stacks: [20, 20, 20], ranges: ['TT+,AQs+', '99+,AJs+,KQs', '88+,ATs+'], streets: { river: { bets: '50', raises: 'a', maxBets: 1 } } },
  '4-way river, pot 12, stacks 15': { board: 'Kc9h6d3s2s', common: 12, stacks: [15, 15, 15, 15], ranges: ['QQ+,AK', 'JJ+,AQs+', 'TT+,AJs+', '99+,KQs'], streets: { river: { bets: '50', raises: 'a', maxBets: 1 } } },
};
/** mean L1 distance between two strategy accessors on the same game */
function l1(fp, S1, S2) { return AB.meanL1(fp, S1, S2); }

(async () => {
  const t0 = Date.now(), doc = { format: 'eightmax-math-validation', version: 2, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), environment: { platform: process.platform, cpu: os.cpus()[0].model, cpus: os.cpus().length, node: process.version, nativeEngine: cli ? 'mwcli built from the bundled EightMax 5.1 source (build ' + A.ENGINE.build + ')' : 'not available' },
    scope: 'EXACT evaluations of small single-street (river) games. Heads-up: exploitability (constant-sum). Three or more players: NashConv (sum of unilateral gains; not an exploitability, not a safety guarantee). These games check the solver, the stored strategies and the evaluation code; they do NOT measure accuracy of the full eight-handed tournament game (preflop to river), which is not computed anywhere.',
    classifications: { exact: 'complete evaluation of the defined game', estimated: 'sampled evaluation with a stated confidence interval', restricted: 'limited response set or abstraction', unverified: 'no evidence' }, sections: {} };
  const save = () => fs.writeFileSync(args.out || 'math-validation-031.json', JSON.stringify(doc, null, 1));
  // 0.30 validation, re-run unchanged
  if (!args.skip030 && cli) { const out = path.join(work, '030.json'), r = cp.spawnSync(process.execPath, [path.join(__dirname, 'math-validation-030.cjs'), '--seeds=' + Math.min(5, seeds), ...(quick ? ['--quick'] : []), '--out=' + out], { encoding: 'utf8', env: process.env, maxBuffer: 1 << 26 }); doc.sections.rerunOf030 = r.status === 0 ? { status: 'pass', note: 'tools/math-validation-030.cjs re-run unchanged with this build', report: JSON.parse(fs.readFileSync(out, 'utf8')).sections } : { status: 'fail', stderr: (r.stderr || '').slice(-2000) }; save(); }
  // A
  const counts = quick ? [5000, 50000] : [5000, 20000, 100000, 400000, 1600000]; doc.sections.headsUpReferenceGames = { classification: 'exact', games: {} };
  for (const [name, cfg] of Object.entries(GAMES)) {
    const base = A.prepare(EM, { config: { ...cfg, privateSeed: 1 }, iterations: 1 }), fp = F.prepare(base.game, base.spec), tr = Date.now(), ref = fp.cfrPlus(quick ? 300 : 2000, { every: quick ? 100 : 250, target: 1e-5 * cfg.common });
    const g = { config: cfg, hands: fp.hands.map((h) => h.length), treeNodes: fp.tree.nodes, reference: { algorithm: ref.method, iterations: ref.iterations, exploitabilityBB: ref.exploitability, exploitabilityPctPot: ref.exploitabilityPctPot, gameValueSeat0BB: ref.values[0], curve: ref.curve, ms: Date.now() - tr }, native: [] };
    if (cli) for (const u of counts) {
      const ps = []; for (let s = 1; s <= seeds; s++) ps.push(runNative(cfg, u, 2000 + s));
      const evs = ps.map((p) => F.prepare(p.game, p.spec).exact(p.game)), Ss = ps.map((p) => fp.strategyOf(p.game)), pairs = []; for (let i = 0; i + 1 < Ss.length; i++) pairs.push(l1(fp, Ss[i], Ss[i + 1]));
      g.native.push({ updates: u, exploitabilityBB: stat(evs.map((e) => e.exploitability)), exploitabilityPctPot: +(stat(evs.map((e) => e.exploitability)).mean / cfg.common * 100).toFixed(4), seat0ValueBB: stat(evs.map((e) => e.values[0])), valueGapToReferenceBB: +(stat(evs.map((e) => e.values[0])).mean - ref.values[0]).toFixed(6), seedToSeedStrategyL1: pairs.length ? stat(pairs) : null, distanceToReferenceL1: stat(Ss.map((S) => l1(fp, S, ref.strategy))), trainMs: stat(ps.map((p) => p.trainMs)) });
    }
    g.monotoneMeanDecrease = g.native.every((r, i) => i === 0 || r.exploitabilityBB.mean <= g.native[i - 1].exploitabilityBB.mean * 1.05);
    doc.sections.headsUpReferenceGames.games[name] = g; process.stderr.write('A ' + name + ': ref ' + ref.exploitability.toExponential(2) + ' bb; native ' + g.native.map((r) => r.updates / 1000 + 'k ' + r.exploitabilityBB.mean.toFixed(4)).join(', ') + '\n'); save();
  }
  // B
  doc.sections.multiplayerNashConv = { classification: 'exact', caveat: 'NashConv is the sum of each player\'s best unilateral gain. With three or more players a NashConv of zero does not imply safety against coalitions; equilibria are neither unique nor interchangeable; heads-up exploitability thresholds are not applied.', games: {} };
  if (cli) for (const [name, cfg] of Object.entries(MW)) {
    const curve = []; for (const u of quick ? [5000, 50000] : [5000, 20000, 100000, 400000]) { const nc = [], gains = []; for (let s = 1; s <= Math.min(3, seeds); s++) { const p = runNative(cfg, u, 3000 + s), e = X.exact(p.game, p.spec); nc.push(e.nashConv); gains.push(e.gains); } curve.push({ updates: u, nashConvBB: stat(nc), nashConvPctPot: +(stat(nc).mean / cfg.common * 100).toFixed(3), perPlayerGainMeanBB: gains[0].map((_, q) => +(gains.reduce((a, g) => a + g[q], 0) / gains.length).toFixed(5)) }); }
    doc.sections.multiplayerNashConv.games[name] = { config: cfg, curve }; process.stderr.write('B ' + name + ': ' + curve.map((c) => c.updates / 1000 + 'k ' + c.nashConvBB.mean.toFixed(4)).join(', ') + '\n'); save();
  }
  // C + D: what the library stores
  const spots = [
    ['HU river any-two (0.30 library default ranges)', { street: 'river', board: ['Kh', '9s', '5c', '3d', '2h'], stacksBehind: [24, 24], pot: 6 }],
    ['HU river medium ranges', { street: 'river', board: ['Qd', '8c', '5h', '4s', '2c'], stacksBehind: [45, 45], pot: 5.5, ranges: GAMES['HU medium/wide, pot 5.5, stacks 45, 2 sizes, 3 bets (deeper betting history)'].ranges }],
    ['3-way river', { street: 'river', board: ['Qd', '8c', '5h', '4s', '2c'], stacksBehind: [20, 20, 20], pot: 9, ranges: MW['3-way river, pot 9, stacks 20'].ranges }],
  ];
  doc.sections.libraryTrainingOutcomes = { classification: 'exact', policy: Q.policySummary(Q.policyOf('research')), rows: [] };
  for (const [name, p] of spots) {
    const b = p.board.map(SID.cardId), hu = p.stacksBehind.length === 2, row = { situation: name };
    if (cli) { const fixed = LS.spotFromParams({ ...p, board: b }, { ranges: p.ranges }); const r = await LS.trainSpot(fixed.spot, { cli }); const g = require('../src/strategy-snapshot.js').decode(r.body), ev = Q.evaluateSnapshot(g, fixed.identity); row.fixed20000_030 = { trainMs: r.training.trainMs, evaluation: ev, status: Q.classify(ev, 'research').status }; }
    for (const trainer of hu ? ['vector-cfr-plus', ...(cli ? ['eightmax-native'] : [])] : cli ? ['eightmax-native'] : []) {
      const sp = LS.spotFromParams({ ...p, board: b }, { ranges: p.ranges, training: AT.trainingPolicy({ trainer }), abstraction: trainer === 'vector-cfr-plus' ? SID.ABSTRACTION_FULL_WIDTH : undefined });
      const r = await AT.trainAdaptive(sp.spot, { cli, trainer, policy: 'research', maxTimeMs: quick ? 20000 : 90000 });
      row[trainer] = { updates: r.training.iterations, trainMs: r.training.trainMs, stoppedBecause: r.training.stoppedBecause, status: r.quality.status, reason: r.quality.reason, curve: r.training.curve };
    }
    doc.sections.libraryTrainingOutcomes.rows.push(row); process.stderr.write('C ' + name + ': ' + JSON.stringify(Object.fromEntries(Object.entries(row).filter(([k]) => k !== 'situation').map(([k, v]) => [k, v.status + (v.evaluation ? ' ' + (v.evaluation.exploitabilityBB || v.evaluation.nashConvBB).toFixed(4) : ' ' + v.updates)]))) + '\n'); save();
  }
  doc.sections.relatedReports = { trainingVariants: 'reports/0.31-training-variants.json', abstraction: 'reports/0.31-abstraction-validation.json', rangeSupport: 'reports/0.31-range-support.json' };
  doc.elapsedMs = Date.now() - t0; save(); fs.rmSync(work, { recursive: true, force: true });
})().catch((e) => { console.error(e); process.exit(1); });
