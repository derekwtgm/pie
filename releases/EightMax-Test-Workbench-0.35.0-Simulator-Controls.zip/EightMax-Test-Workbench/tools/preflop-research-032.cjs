'use strict';
/* 0.32 eight-handed preflop research (reports/0.32-preflop-research.json).
 * For each (updates, seed, variant): train (or continue) the linked preflop study with the native engine, build its shared preflop
 * snapshot, measure information-set coverage (exact counts + sampled reach), range support of the derived flop ranges (the 0.31
 * measurement, same method), optional response gains (mwcli --verify restricted / sampled, with 95% intervals), and seed stability
 * (mwcli --compare). Every figure carries its classification (exact count / sampled estimate / restricted lower bound).
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/preflop-research-032.cjs --updates=500000,2000000 --seeds=8,108 --variants=baseline
 *        [--gains=restricted,sampled] [--gainSamples=2000] [--lineSamples=8000] [--rangeSamples=6000] [--cache=DIR] [--out=FILE]
 *        [--mode=fast|standard|high-accuracy] [--maxMinutes=N] (high-accuracy: continue in doubling blocks within the time budget)
 * Variants: baseline (0.31 trainer), explore20 (opponent exploration 0.2 instead of 0.1: more samples of rare actions),
 *           ownenum (own-hand enumeration: every hand of the updating seat per deal). Native-only research settings. */
const fs = require('node:fs'), path = require('node:path'), os = require('node:os');
const TS = require('./train-study.cjs'), T = require('./studies.cjs'), PR = require('../src/preflop-research.js'), PS = require('../src/preflop-snapshot.js'), RE = require('../src/range-engine.js'), ST = require('../src/solver-tree.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const cli = process.env.EIGHTMAX_TEST_CLI; if (!cli) { console.error('EIGHTMAX_TEST_CLI is required'); process.exit(2); }
const mode = PR.modeOf(args.mode || 'standard');
const counts = String(args.updates || (mode.updates || mode.startUpdates)).split(',').map(Number), seeds = String(args.seeds || mode.seeds.join(',')).split(',').map(Number);
const variants = String(args.variants || 'baseline').split(','), gainMethods = args.gains ? String(args.gains).split(',').filter((x) => x && x !== 'none') : [];
const cache = args.cache || path.join(os.tmpdir(), 'em-preflop-032'), limit = +(args.limit || 0.25);
const VARIANTS = { baseline: null, explore20: { opponentExploration: 0.2 }, ownenum: { ownHandEnumeration: true } };

/** 0.31 range-support measurement (tools/range-support-031.cjs), parameterised by the prepared study. */
function rangeSupport(prepared, studyId, samples) {
  const src = new ST.PreflopTreeSource(require('../tests/load-solver.cjs'), prepared, { studyId }), st = src.study; st.seatOrder = [0, 1, 2, 3, 4, 5, 6, 7];
  const rows = new Map(prepared.spec.hands.map((r, i) => [i, RE.rowMap(r)]));
  let x = 12345; const rnd = () => { x = (Math.imul(x, 1103515245) + 12345) >>> 0; return x / 4294967296; };
  const seen = new Map(); let toFlop = 0; const t0 = Date.now();
  for (let n = 0; n < samples; n++) {
    const deck = Array.from({ length: 52 }, (_, i) => i); for (let i = 51; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    const hole = Array.from({ length: 8 }, (_, s2) => [deck[2 * s2], deck[2 * s2 + 1]]), steps = []; let v = st._view(steps);
    while (v.kind === 'player') {
      const h = hole[v.seat], row = rows.get(v.seat).get(RE.IDX[Math.min(...h) * 52 + Math.max(...h)]);
      let p = row ? prepared.game.averageAt('r' + steps.join(''), prepared.spec.board, v.seat, { id: row[0], a: row[1], b: row[2], w: row[3] }) : null;
      if (!p) { const q = st._pool(v.seat, h, 'r' + steps.join('')); p = q ? q.mix : v.labels.map(() => 1 / v.labels.length); }
      let r = rnd(), a = 0; while (a < p.length - 1 && r >= p[a]) { r -= p[a]; a++; } steps.push(a); v = st._view(steps);
    }
    const live = Array.isArray(v.live) ? v.live.filter(Boolean).length : 0; if (v.kind !== 'chance' || live < 2) continue; toFlop++;
    const key = 'r' + steps.join(','); const e = seen.get(key); if (e) { e.count++; continue; } seen.set(key, { steps: steps.slice(), count: 1, live });
  }
  for (const [, e] of seen) {
    const acts = []; let steps2 = []; for (const a of e.steps) { const v = st._view(steps2), lab = v.parsed[a]; acts.push({ seat: v.seat, type: lab.kind === 'allin' ? 'allin' : lab.kind, amount: lab.to || 0, street: 'preflop' }); steps2 = steps2.concat(a); }
    const bt = [0, 1, 2, 3, 4, 5, 6, 7].find((b) => ST.preflopSeatOrder(b).every((sim, i) => sim === i));
    const r = RE.preflopRanges(src, { button: bt, actions: acts }, { ST });
    const liveSeats = st._view(e.steps).live.map((l, i) => (l ? i : -1)).filter((i) => i >= 0);
    e.status = r.status; e.unsupported = liveSeats.map((s2) => r.ranges.get(s2).unsupported.reduce((acc, u) => acc + u.massShare, 0));
  }
  const flop = [...seen.values()], share = (f) => +(flop.filter(f).reduce((a, l) => a + l.count, 0) / Math.max(1, toFlop)).toFixed(4);
  return { method: 'same as tools/range-support-031.cjs (Monte-Carlo line sampling; each distinct line analysed exactly with RE.preflopRanges)', sampledDeals: samples, dealsReachingFlop: toFlop, distinctFlopLines: flop.length, analysisMs: Date.now() - t0, unsupportedLimit: limit,
    shareOfFlopsAllRangesFullySupported: share((l) => l.status === 'ok' && l.unsupported.every((u) => u === 0)), shareOfFlopsWithinLimit: share((l) => l.status === 'ok' && l.unsupported.every((u) => u <= limit)),
    byPlayers: Object.fromEntries([2, 3, 4, 5].map((n) => { const L2 = flop.filter((l) => l.live === n), m2 = L2.reduce((a, l) => a + l.count, 0); return [n, { shareOfFlops: +(m2 / Math.max(1, toFlop)).toFixed(4), withinLimit: +(L2.filter((l) => l.status === 'ok' && l.unsupported.every((u) => u <= limit)).reduce((a, l) => a + l.count, 0) / Math.max(1, m2)).toFixed(4) }]; })),
    // sampling uncertainty of the within-limit share (binomial over the deals that reach the flop; lines are not independent of deals, so this is approximate)
    withinLimitCi95: (() => { const p = share((l) => l.status === 'ok' && l.unsupported.every((u) => u <= limit)), se = Math.sqrt(Math.max(0, p * (1 - p)) / Math.max(1, toFlop)); return [+(p - 1.96 * se).toFixed(4), +(p + 1.96 * se).toFixed(4)]; })() };
}

(async () => {
  const doc = { format: 'eightmax-preflop-research', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), mode: mode.name, modeLabel: mode.label,
    machine: { cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, totalMemBytes: os.totalmem(), node: process.version, platform: process.platform },
    game: 'eight seats, equal 25 BB stacks, SB 0.5 / BB 1 / ante 0.1 BB per player, chip EV, linked preflop tree (fold / call / open 2.2 / all-in, up to 3 bets) continuing to the river with single-size postflop menus; every seat starts from all 1,326 combinations',
    classifications: { coverage: 'exact count of stored rows (native state)', reach: 'sampled estimate (Monte-Carlo line sampling, fixed seed)', rangeSupport: 'sampled estimate (same method as 0.31)', gains: 'restricted best response = LOWER BOUND, evaluated by sampling (95% interval); sampled = one-decision deviation estimate', fullGameExploitability: 'unavailable (not computed; never reported as zero)' },
    runs: [], comparisons: [] };
  const save = () => { if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); };
  const states = new Map();
  for (const variant of variants) for (const seed of seeds) for (const updates of counts) {
    const name = 'preflop8-linked-' + variant + '-s' + seed, t0 = Date.now();
    const cfg = { ...T.PREFLOP8_LINKED, privateSeed: seed };
    let s; try { s = await TS.preflopSnapshotFor(updates, { config: cfg, name, cacheDir: cache, threads: +(args.threads || 3), budgetMiB: +(args.budgetMiB || 2048), cli, specPatch: VARIANTS[variant] || undefined, continueFromSmaller: args.continue !== '0' }); }
    catch (e) { doc.runs.push({ variant, seed, updates, error: e.message, code: e.code || null }); save(); continue; }
    const trainMs = Date.now() - t0, prep = TS.preparedFromSnapshot(s.buffer, { config: cfg });
    const { StrategyStore } = require('../src/strategy-store.js'), store = StrategyStore.open(s.stateFile, { cacheBytes: 64 << 20, verify: false });
    const cov = PR.coverage(store, prep.prepared, { samples: +(args.lineSamples || mode.lineSamples), seed: 4242 }); store.close();
    const rs = rangeSupport(prep.prepared, name + '-' + updates, +(args.rangeSamples || 6000));
    const run = { variant, variantSettings: VARIANTS[variant] || 'EightMax 5.1 default (0.31)', seed, updates: s.updates, requestedUpdates: updates, complete: s.complete, trainOrLoadMs: trainMs, stateFile: path.basename(s.stateFile), stateBytes: fs.statSync(s.stateFile).size, snapshot: { bytes: s.buffer.byteLength, fingerprint: s.fingerprint }, coverage: cov, rangeSupport: rs, gains: [] };
    for (const m of gainMethods) { const specFile = path.join(cache, name + '.spec.json'); const g = PR.verifyGains(cli, specFile, s.stateFile, { method: m, samples: +(args.gainSamples || mode.gainSamples), seed: 1, threads: +(args.gainThreads || 2), timeMs: +(args.gainMs || 3600000) }); run.gains.push({ method: m, ...g }); save(); }
    // per-position first-in deviation gains (sampled one-decision deviations; feasible budget - see docs/PREFLOP-RESEARCH.md)
    if (args.deviations) { const specFile = path.join(cache, name + '.spec.json'); run.firstInDeviations = PR.firstInPaths(prep.prepared).map((f) => { const g = PR.deviationGain(cli, specFile, s.stateFile, f.seat, f.path, { samples: +(args.deviationSamples || 2000), seed: 7 }); process.stderr.write('  ' + f.position + ' gain ' + (g.gainBB ? g.gainBB.mean.toFixed(5) : g.error || g.reason) + '\n'); save(); return { ...g, menu: f.labels }; }); }
    run.assessment = PR.assess(mode, cov, run.gains);
    doc.runs.push(run); states.set(variant + '|' + seed + '|' + updates, { state: s.stateFile, spec: path.join(cache, name + '.spec.json') }); save();
    process.stderr.write(variant + ' seed ' + seed + ' ' + updates + ': class coverage ' + cov.sampled.reachWeightedClassCoverage + ', range support within limit ' + rs.shareOfFlopsWithinLimit + ' (' + trainMs + ' ms)\n');
  }
  // seed stability: same variant and updates, different seeds - mean total-variation distance of the average strategies at every
  // position's first-in node (from the shared snapshots; mwcli --compare refuses different seeds because the study id includes the seed)
  if (!args.noCompare) for (const variant of variants) for (const updates of counts) { const a = states.get(variant + '|' + seeds[0] + '|' + updates), b = states.get(variant + '|' + seeds[1] + '|' + updates); if (!a || !b) continue;
    const sa = PS.load(a.state + '.emps').snapshot, sb = PS.load(b.state + '.emps').snapshot, prep = TS.preparedFromSnapshot(PS.load(a.state + '.emps').buffer, {});
    doc.comparisons.push({ variant, updates, seeds: [seeds[0], seeds[1]], measure: 'mean total-variation distance (0 = identical, 1 = disjoint) over range rows stored in both, at each position\'s first-in node', note: 'Stability, never accuracy: 8-player equilibria need not be unique.', nodes: PR.stability(sa, sb, PR.firstInPaths(prep.prepared)) }); save(); }
  save(); if (!args.out) console.log(JSON.stringify(doc, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
