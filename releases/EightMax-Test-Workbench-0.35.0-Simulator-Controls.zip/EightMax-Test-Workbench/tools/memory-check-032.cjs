'use strict';
/* 0.32 memory check for this computer: the same short simulated workload (workload B, Decision Mode, empty postflop library) with the
 * 0.31 path (every worker opens its own lazy reader of the native preflop state) and with the 0.32 shared preflop snapshot.
 * Writes a comparison in the format of reports/0.32-memory-comparison.json. Trains the preflop study first if it is missing.
 * usage: node tools/memory-check-032.cjs [--tables=1,5,10] [--hands=6] [--updates=200000] [--work=DIR] --out=FILE */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const tables = args.tables || '1,5,10', hands = args.hands || '6', updates = args.updates || '200000', work = args.work || path.join(os.tmpdir(), 'em-memory-check'), out = args.out || path.join(work, 'memory-comparison.json');
const cli = process.env.EIGHTMAX_TEST_CLI || path.join(__dirname, '..', 'native', process.platform === 'win32' ? 'mwcli.exe' : 'mwcli');
fs.mkdirSync(work, { recursive: true }); const cache = path.join(work, 'preflop-cache');
const run = (tool, extra, file) => { const r = cp.spawnSync(process.execPath, [path.join(__dirname, tool), '--tables=' + tables, '--hands=' + hands, '--workers=4', '--updates=' + updates, '--workloads=B', '--work=' + work, '--out=' + file, ...extra], { stdio: 'inherit', env: { ...process.env, EIGHTMAX_TEST_CLI: cli } }); if (r.status !== 0) throw new Error(tool + ' failed (' + r.status + ')'); return JSON.parse(fs.readFileSync(file, 'utf8')); };
// both tools read the preflop cache at <work>/preflop-cache; the 0.32 run is told the same folder
const a = run('benchmark-031.cjs', [], path.join(work, 'run-031path.json')), b = run('benchmark-032.cjs', ['--sharedPreflop=1', '--preflopCache=' + cache], path.join(work, 'run-032shared.json'));
const rows = Object.keys(a.runs).map((t) => { const x = a.runs[t].B, y = b.runs[t].B; return { tables: +t, workers: x.workers, peakRssMiB: { '0.31': Math.round(x.resources.rssBytesPeak / 1048576), '0.32': Math.round(y.resources.rssBytesPeak / 1048576) }, identicalDecisions: ['handsCompleted', 'decisions', 'solverDecisions', 'scriptedFallbackDecisions'].every((k) => x[k] === y[k]), decisionLatencyMs: { '0.31': x.latencyMs.decision, '0.32': y.latencyMs.decision } }; });
const doc = { format: 'eightmax-memory-comparison-032', version: 1, generatedAt: new Date().toISOString(), machine: b.machine, classification: 'SIMULATED TABLES on this computer, identical workload, run back to back', sharedPreflop: b.sharedPreflop, rows };
fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, JSON.stringify(doc, null, 1));
for (const r of rows) console.log(r.tables + ' tables: peak RSS ' + r.peakRssMiB['0.31'] + ' MiB (0.31 path) -> ' + r.peakRssMiB['0.32'] + ' MiB (shared), identical decisions: ' + r.identicalDecisions);
