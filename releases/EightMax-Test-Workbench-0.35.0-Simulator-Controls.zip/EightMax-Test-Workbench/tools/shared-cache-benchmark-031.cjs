'use strict';
/* 0.31 shared strategy retrieval under multi-table load: 0.30 host (v1, main thread, asynchronous replies) vs 0.31 strategy
 * service (v2, dedicated thread, synchronous replies, shared directory). Same library, same load, same request sequence.
 * Load model: each table is an async loop that does `--work-ms` of synchronous CPU work (the measured p50 of one decision cycle of
 * the complete simulated pipeline is ~30 ms) and then fetches one stored strategy (random record, or a missing fingerprint with
 * probability --miss). Tables are spread over min(4, tables) worker threads exactly like the multi-table benchmark, so several
 * tables share one event loop - the condition that made 0.30's shared fetches slow. Worker-local caches are bypassed: every
 * request is a real shared fetch (the decision path would serve repeats from the worker's own memory cache).
 * usage: node tools/shared-cache-benchmark-031.cjs --lib=DIR [--tables=1,2,5,8,10] [--seconds=20] [--work-ms=30] [--miss=0.2] --out=FILE */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), { Worker, isMainThread, workerData, parentPort } = require('node:worker_threads');
if (!isMainThread) {
  const SC = require('../src/shared-strategy-cache.js'), nowMs = () => Number(process.hrtime.bigint()) / 1e6;
  const c = workerData.kind === 'v2' ? new SC.SharedStrategyClientV2(workerData.libraryPort, workerData.libraryService) : new SC.SharedStrategyClient(workerData.libraryPort);
  let x = workerData.seed >>> 0 || 1; const rnd = () => { x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; };
  const recs = workerData.records, lat = [], missLat = [], end = Date.now() + workerData.seconds * 1000; let bad = 0, hits = 0, misses = 0, cycles = 0;
  const table = async () => { while (Date.now() < end) { const t = nowMs(); while (nowMs() - t < workerData.workMs) { /* table work: capture, recognition, reconstruction */ } cycles++;
    const miss = rnd() < workerData.miss, r = recs[Math.floor(rnd() * recs.length)], fp = miss ? r.fp.replace(/^./, (ch) => (ch === 'f' ? '0' : 'f')) : r.fp;
    const t0 = nowMs(), got = await c.fetch(fp, r.identity), ms = nowMs() - t0; (miss ? missLat : lat).push(ms);
    if (miss) { if (got) bad++; else misses++; } else if (!got || got.header.fingerprint !== r.fp) bad++; else hits++;
    await new Promise((res) => setImmediate(res)); } };
  Promise.all(Array.from({ length: workerData.tables }, table)).then(() => parentPort.postMessage({ lat, missLat, bad, hits, misses, cycles }));
  return;
}
const SC = require('../src/shared-strategy-cache.js'), L = require('../src/strategy-library.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const pct = (a, p) => { if (!a.length) return null; const s = a.slice().sort((u, v) => u - v); return +s[Math.min(s.length - 1, Math.ceil(p / 100 * s.length) - 1)].toFixed(3); };
const dist = (a) => ({ n: a.length, p50: pct(a, 50), p95: pct(a, 95), p99: pct(a, 99), max: a.length ? +Math.max(...a).toFixed(3) : null });
(async () => {
  const lib = L.StrategyLibrary.open(args.lib, { readOnly: true }), records = lib.list().map((e) => ({ fp: e.fingerprint, identity: L.decodeRecord(fs.readFileSync(lib.file(e.fingerprint)), e.fingerprint).header.identity }));
  if (records.length < 2) throw new Error('Library needs at least two records');
  const tables = String(args.tables || '1,2,5,8,10').split(',').map(Number), seconds = +(args.seconds || 20), workMs = +(args['work-ms'] || 30), miss = +(args.miss || 0.2);
  const doc = { format: 'eightmax-shared-cache-benchmark', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), machine: { cpu: os.cpus()[0].model, logicalCpus: os.cpus().length, node: process.version },
    settings: { library: { records: records.length, storageBytes: lib.status().storageBytes, rawBytes: lib.status().rawBytes }, seconds, workMsPerCycle: workMs, missShare: miss, workersPerRun: 'min(4, tables)' },
    targets: { p50Ms: 10, p95Ms: 25, p99Ms: 50 }, runs: {} };
  for (const kind of ['v1', 'v2']) for (const T of tables) {
    const host = kind === 'v1' ? new SC.SharedStrategyHost(L.StrategyLibrary.open(args.lib, { sharedMemory: true, cacheBytes: 1024 * 1048576 })) : new SC.SharedStrategyService(args.lib, { cacheBytes: 1024 * 1048576 });
    if (host.ready) await host.ready(); const warmed = await host.prewarm();
    const groups = Array.from({ length: Math.min(4, T) }, () => 0); for (let i = 0; i < T; i++) groups[i % groups.length]++;
    const mem0 = process.memoryUsage().rss, t0 = Date.now();
    const parts = await Promise.all(groups.map((n, gi) => new Promise((res, rej) => { const port = host.port(); const w = new Worker(__filename, { workerData: { kind, tables: n, seconds, workMs, miss, seed: 17 + gi * 7919 + T, records, libraryPort: port, libraryService: host.descriptor ? host.descriptor() : undefined }, transferList: [port] }); w.on('message', res); w.on('error', rej); })));
    const lat = parts.flatMap((p) => p.lat), ml = parts.flatMap((p) => p.missLat), info = host.infoAsync ? await host.infoAsync() : host.info();
    const run = { kind, tables: T, workers: groups.length, wallMs: Date.now() - t0, prewarmedRecords: warmed, hitFetch: dist(lat), missFetch: dist(ml), allFetches: dist(lat.concat(ml)), wrongAnswers: parts.reduce((a, p) => a + p.bad, 0), hits: parts.reduce((a, p) => a + p.hits, 0), misses: parts.reduce((a, p) => a + p.misses, 0), tableCycles: parts.reduce((a, p) => a + p.cycles, 0), rssBytesAfter: process.memoryUsage().rss, rssGrowthBytes: process.memoryUsage().rss - mem0, host: info };
    run.targetsMet = run.allFetches.p50 <= 10 && run.allFetches.p95 <= 25 && run.allFetches.p99 <= 50;
    (doc.runs[kind] = doc.runs[kind] || {})[T] = run; await host.close();
    process.stderr.write(kind + ' ' + T + ' tables: hit p50/p95/p99 ' + run.hitFetch.p50 + '/' + run.hitFetch.p95 + '/' + run.hitFetch.p99 + ' ms, miss p50/p95 ' + run.missFetch.p50 + '/' + run.missFetch.p95 + ', wrong ' + run.wrongAnswers + ', fetches ' + (lat.length + ml.length) + (run.targetsMet ? ', targets met' : ', targets NOT met') + '\n');
    if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1));
  }
  if (!args.out) console.log(JSON.stringify(doc, null, 1));
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
