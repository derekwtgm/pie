'use strict';
/* 0.33 independent multiway validation (reports/0.33-multiway-validation.json).
 * 1. Analytic reference games evaluated by src/independent-eval.js:
 *    - 2-player Kuhn poker, equilibrium family (alpha = 0, 0.2, 1/3): value of player 1 = -1/18, NashConv = 0 (exact)
 *    - 3-player Kuhn poker, everyone checks and folds to bets: NashConv = 6 (each seat gains 2 by always betting)
 *    - 3-player hold'em river, everyone checks and folds to bets: NashConv = 2 x common pot (each seat's best response wins the pot)
 *    - 3-player Kuhn poker, independent CFR: NashConv after N iterations (convergence evidence, not an analytic value)
 * 2. Engine cross-check on the 0.32 three-player turn game (turn AhKd7c2s, pot 6, stacks 12, ranges AA,KK,77,AK,KQs,T9s, 50 % bet,
 *    one bet per street): train with the native engine for each update count, then NashConv by (a) the engine's own exact best
 *    response (mwcli --gain method=exact - engine-internal) and (b) the independent evaluator (own rules, pots, evaluator, best response,
 *    own reconstruction of the strategy from the state file). Betting geometry of both implementations is compared node by node.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/multiway-validation-033.cjs [--updates=20000,80000,320000,1280000] [--seeds=3] [--quick] --out=FILE */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), IE = require('../src/independent-eval.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const cli = process.env.EIGHTMAX_TEST_CLI;

function kuhn2Profile(al) {
  return (seat, node, board, ti) => { const p = node.path;
    if (seat === 0) { if (p === 'r') return ti === 0 ? [1 - al, al] : ti === 1 ? [1, 0] : [1 - 3 * al, 3 * al]; if (p === 'r01') return ti === 0 ? [1, 0] : ti === 1 ? [2 / 3 - al, al + 1 / 3] : [0, 1]; }
    if (p === 'r0') return ti === 0 ? [2 / 3, 1 / 3] : ti === 1 ? [1, 0] : [0, 1]; if (p === 'r1') return ti === 0 ? [1, 0] : ti === 1 ? [2 / 3, 1 / 3] : [0, 1];
    throw new Error('unexpected node ' + p); };
}
const passive = (seat, node) => node.actions.map((a) => (a.kind === 'check' || a.kind === 'fold' ? 1 : 0));
function references() {
  const out = [];
  for (const al of [0, 0.2, 1 / 3]) { const e = IE.evaluate(IE.kuhn(2), kuhn2Profile(al)); out.push({ game: '2-player Kuhn, equilibrium alpha = ' + al.toFixed(4), expected: { player1Value: -1 / 18, nashConv: 0 }, measured: { player1Value: e.values[0], nashConv: e.nashConv }, pass: Math.abs(e.values[0] + 1 / 18) < 1e-12 && Math.abs(e.nashConv) < 1e-12 }); }
  { const e = IE.evaluate(IE.kuhn(3), passive); out.push({ game: '3-player Kuhn, check / fold to bets', expected: { gains: [2, 2, 2], nashConv: 6 }, measured: { gains: e.gains, nashConv: e.nashConv }, pass: e.gains.every((g) => Math.abs(g - 2) < 1e-12) }); }
  { const rng = (l) => l.map((s) => { const c = IE.cards(s); return [c[0], c[1], 1]; });
    const G = IE.holdem({ board: 'AhKd7c2s9h', common: 6, stacks: [12, 12, 12], hands: [rng(['AsAc', 'KcKh', '7d7h', 'QcJc']), rng(['AdKs', 'Ts9s', '8c8d', 'QhQd']), rng(['KsQs', '6h6d', 'JdTd', 'AcKc'])], streets: { river: { bets: '50', raises: 'a', maxBets: 1 } } });
    const e = IE.evaluate(G, passive); out.push({ game: '3-player hold\'em river (pot 6), check / fold to bets', expected: { nashConv: 12, valueSum: 6 }, measured: { nashConv: e.nashConv, valueSum: e.valueSum, values: e.values }, pass: Math.abs(e.nashConv - 12) < 1e-9 && Math.abs(e.valueSum - 6) < 1e-9 }); }
  for (const it of [100, 1000, 5000]) { const t0 = Date.now(), e = IE.evaluate(IE.kuhn(3), IE.cfr(IE.kuhn(3), it)); out.push({ game: '3-player Kuhn, independent vanilla CFR ' + it + ' iterations', expected: 'NashConv decreasing toward 0 (CFR in 3-player Kuhn is known to approach equilibrium empirically; not guaranteed)', measured: { nashConv: e.nashConv, values: e.values, ms: Date.now() - t0 }, pass: null }); }
  return out;
}
(async () => {
  const doc = { format: 'eightmax-multiway-validation', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), machine: { cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, node: process.version },
    evaluator: 'src/independent-eval.js (independent of the EightMax engine and of the workbench solvers: own betting rules, side pots, 7-card evaluator, state-file reader and best response)',
    meaning: 'NashConv = sum of the unilateral best-response gains. With three players it is NOT an exploitability; 0 = Nash equilibrium (not unique, not coalition-proof). Restricted to the defined betting abstraction.', references: references(), engineCrossCheck: [] };
  const save = () => { if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); }; save();
  if (!cli) { doc.engineCrossCheck = 'unavailable: EIGHTMAX_TEST_CLI not set'; save(); return; }
  const m = { bets: '50', raises: 'a', maxBets: 1 }, dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-mw033-'));
  const counts = String(args.updates || (args.quick ? '20000' : '20000,80000,320000,1280000')).split(',').map(Number), seeds = String(args.seeds || '3').split(',').map(Number);
  for (const seed of seeds) for (const ups of counts) {
    const cfg = { board: 'AhKd7c2s', common: 6, stacks: [12, 12, 12], ranges: Array(3).fill('AA,KK,77,AK,KQs,T9s'), streets: { turn: m, river: m }, privateSeed: seed };
    const p = A.prepare(EM, { config: cfg, iterations: Math.min(ups, 10000000), strategyBudgetMiB: 64 }), spec = A.nativeJob(p, 'mw').spec, sf = path.join(dir, 's.json'), st = path.join(dir, 'o.state'), rq = path.join(dir, 'q.json');
    fs.writeFileSync(sf, JSON.stringify(spec)); let t0 = Date.now(); let r = cp.spawnSync(cli, [sf, String(ups), '1', st, '2048'], { encoding: 'utf8' }); if (r.status) { doc.engineCrossCheck.push({ seed, updates: ups, error: String(r.stderr).slice(-300) }); continue; } const trainMs = Date.now() - t0;
    fs.writeFileSync(rq, JSON.stringify({ method: 'exact', seats: [0, 1, 2], samples: 1000, seed: 1, timeLimitMs: 1800000, threads: 1 }));
    t0 = Date.now(); r = cp.spawnSync(cli, ['--gain', sf, st, rq, '4000'], { encoding: 'utf8', maxBuffer: 1 << 28 }); const natMs = Date.now() - t0; let nat = null; try { nat = JSON.parse(r.stdout.slice(r.stdout.indexOf('{'), r.stdout.lastIndexOf('}') + 1)); } catch (e) { nat = { error: String(r.stderr || r.stdout).slice(-300) }; }
    const G = IE.holdem({ board: 'AhKd7c2s', common: 6, stacks: [12, 12, 12], hands: spec.hands.map((l) => l.map((h) => [h[1], h[2], h[3]])), streets: { turn: m, river: m } });
    const geo = IE.compareGeometry(G, (s) => p.game.view(s)), rd = IE.readNativeRows(fs.readFileSync(st), spec, G.board), ie = IE.evaluate(G, rd.strategy.bind(rd), { commonPot: 6 });
    // reconstruction check: probabilities read independently vs the engine's own reader, on up to 5,000 stored rows
    p.game.importNative(fs.readFileSync(st)); let maxDiff = 0, compared = 0; for (const [k, v] of rd.rows) { if (compared >= 5000) break; const [ph, cs, seat, hi] = k.split('|'), h = spec.hands[+seat][+hi], s = p.game.averageAt(ph, cs.split('.').map(Number), +seat, { id: h[0], a: h[1], b: h[2], w: h[3] }); if (!s) continue; compared++; for (let a = 0; a < v.length; a++) maxDiff = Math.max(maxDiff, Math.abs(v[a] - s[a])); }
    const ng = nat && nat.seats ? nat.seats.map((x) => x.gain) : null, nn = ng ? ng.reduce((a, b) => a + b, 0) : null;
    doc.engineCrossCheck.push({ seed, updates: ups, trainMs, geometry: { nodesCompared: geo.checked, mismatches: geo.mismatches.length }, reconstruction: { rowsCompared: compared, maxProbabilityDifference: maxDiff },
      engineInternal: ng ? { gainsBB: ng, nashConvBB: nn, nashConvPctPot: nn / 6 * 100, ms: natMs, classification: 'exact inside the abstraction, engine-internal (not independent)' } : nat,
      independent: { gainsBB: ie.gains, nashConvBB: ie.nashConv, nashConvPctPot: ie.nashConvPctPot, values: ie.values, valueSum: ie.valueSum, missingRows: ie.missingRows, classification: ie.classification, ms: ie.evalMs },
      agreement: ng ? { maxGainDifferenceBB: Math.max(...ng.map((g, i) => Math.abs(g - ie.gains[i]))), withinTolerance1e9: ng.every((g, i) => Math.abs(g - ie.gains[i]) < 1e-9) } : null,
      meetsResearchLimit2_5Pct: ie.nashConvPctPot <= 2.5 });
    process.stderr.write('seed ' + seed + ' ' + ups + ': independent NashConv ' + ie.nashConvPctPot.toFixed(3) + '% pot, engine ' + (nn !== null ? (nn / 6 * 100).toFixed(3) : 'n/a') + '%, missing rows ' + ie.missingRows + '\n'); save();
  }
  fs.rmSync(dir, { recursive: true, force: true }); save(); if (!args.out) console.log(JSON.stringify(doc, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
