'use strict';
/* 0.31 postflop strategy coverage, measured IN-SAMPLE and OUT-OF-SAMPLE (reports/0.31-coverage.json).
 *   1 record    simulated hands with TRAINING seeds in Decision Mode on an empty library: every postflop street start that occurs is
 *               logged as a miss with its exact identity and frequency (the "situations encountered").
 *   2 build     precompute, within a time budget: (a) the full suit-canonical flop catalogue (1,755 flops) for the most frequent flop
 *               configurations (players, pot, stacks, ranges), and (b) every distinct turn/river situation seen in step 1.
 *   3 measure   replay the TRAINING seeds (in-sample coverage) and play UNSEEN seeds (out-of-sample coverage) in Decision Mode.
 *               Each postflop decision is counted as: exact library match / abstracted match (accepted mappings only; none are
 *               enabled by default) / solved on demand (exact heads-up river CFR+, only in the separate "+on-demand" run) / unavailable.
 * The report also lists the most frequent missing configurations and the measured training cost per study to estimate what more
 * coverage would take. SIMULATED TABLES (equal 25 bb starting stacks every hand); not a real client.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/coverage-031.cjs --train-seeds=11,12,13 --test-seeds=901,902,903 --hands=60 --tables=4
 *        --flop-configs=3 --budget-min=20 --ranges=any-two|derived --preflop-cache=DIR --work=DIR --out=FILE */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), { Worker } = require('node:worker_threads');
const L = require('../src/strategy-library.js'), LS = require('../src/library-source.js'), SID = require('../src/strategy-identity.js'), { PrecomputeQueue } = require('../src/precompute.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const cli = process.env.EIGHTMAX_TEST_CLI; if (!cli) { console.error('EIGHTMAX_TEST_CLI is required'); process.exit(2); }
const trainSeeds = String(args['train-seeds'] || '11,12,13').split(',').map(Number), testSeeds = String(args['test-seeds'] || '901,902,903').split(',').map(Number);
const hands = +(args.hands || 60), tables = +(args.tables || 4), flopConfigs = +(args['flop-configs'] || 3), budgetMs = +(args['budget-min'] || 20) * 60000, ranges = args.ranges || 'any-two';
const work = args.work || fs.mkdtempSync(path.join(os.tmpdir(), 'em-cov031-')), lib = path.join(work, 'library'), pfCache = args['preflop-cache'] || path.join(work, 'preflop-cache'), preUpdates = +(args.updates || 500000);

function inWorker(job) { return new Promise((res, rej) => { const w = new Worker(path.join(__dirname, 'pipeline-worker.cjs'), { workerData: { job } }); let done = false; w.on('message', (m) => { done = true; return m.ok ? res(m.result) : rej(new Error(m.error)); }); w.on('error', rej); w.on('exit', (c) => { if (!done) rej(new Error('worker exit ' + c)); }); }); }
async function play(seed, extra = {}) {
  const groups = Array.from({ length: Math.min(4, tables) }, () => []); for (let i = 1; i <= tables; i++) groups[(i - 1) % groups.length].push(i);
  const library = { dir: lib, mode: 'decision', iterations: 20000, rangeModel: ranges, adaptive: true, quality: { policy: 'research', use: 'simulation-experiment' }, ...extra };
  const parts = await Promise.all(groups.map((g, gi) => inWorker({ tables: g, hands, seed, workerId: gi + 1, collectActions: true, solver: { kind: 'preflop-linked', cli, updates: preUpdates, budgetMiB: 1024, cacheDir: pfCache, library } })));
  return { actions: parts.flatMap((p) => p.actions), libs: parts.map((p) => p.library).filter(Boolean) };
}
const { classify } = require('../src/coverage.js');
const cfgKey = (id) => JSON.stringify([id.players, id.potBB, id.stacksBehindBB, id.ranges, id.rangeModel]);

(async () => {
  const t0 = Date.now(); fs.rmSync(lib, { recursive: true, force: true }); fs.mkdirSync(lib, { recursive: true });
  const doc = { format: 'eightmax-coverage-031', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), classification: 'SIMULATED TABLES (equal 25 bb starting stacks), Decision Mode, native solver; not a real client',
    settings: { trainSeeds, testSeeds, handsPerTablePerSeed: hands, tables, flopConfigs, budgetMinutes: budgetMs / 60000, rangeModel: ranges, preflopUpdates: preUpdates, cpus: os.cpus().length },
    definitions: { exact: 'stored strategy with the identical identity (suit isomorphism only)', abstracted: 'stored strategy of a different situation mapped by an ACCEPTED abstraction (none enabled by default)', solvedOnDemand: 'missing heads-up river solved inside the decision by the exact vectorised CFR+ (separate run, separate column)', unavailable: 'no strategy: the labelled scripted test policy acted' } };
  // 1 record
  for (const s of trainSeeds) await play(s);
  const lb = L.StrategyLibrary.open(lib), misses = lb.missSummary(Infinity), distinct = misses.list || [];
  const flopGroups = new Map(); for (const m of distinct) if (m.identity.street === 'flop') { const k = cfgKey(m.identity); const g = flopGroups.get(k) || { count: 0, distinctBoards: 0, sample: m }; g.count += m.count; g.distinctBoards++; flopGroups.set(k, g); }
  const flopTotal = [...flopGroups.values()].reduce((a, g) => a + g.count, 0), topFlop = [...flopGroups.values()].sort((a, b) => b.count - a.count);
  doc.trainingData = { distinctSituations: distinct.length, occurrences: distinct.reduce((a, m) => a + m.count, 0), byStreet: distinct.reduce((m, x) => { const k = x.identity.street + (x.identity.players === 2 ? ' heads-up' : ' multiway'); m[k] = (m[k] || 0) + x.count; return m; }, {}),
    flopConfigurations: topFlop.length, flopOccurrences: flopTotal, topFlopConfigurations: topFlop.slice(0, 12).map((g) => ({ players: g.sample.identity.players, potBB: g.sample.identity.potBB, stacksBB: g.sample.identity.stacksBehindBB, rangeModel: g.sample.identity.rangeModel, occurrences: g.count, shareOfFlopDecisions: +(g.count / Math.max(1, flopTotal)).toFixed(4), distinctBoardsSeen: g.distinctBoards })) };
  process.stderr.write('recorded ' + distinct.length + ' distinct situations, ' + topFlop.length + ' flop configurations\n');
  // 2 build: flop catalogue for the top configurations, then every distinct turn/river seen (priority = frequency)
  const q = new PrecomputeQueue({ library: lb, cli, concurrency: Math.max(1, os.cpus().length - 1), memoryMiB: 512, reserveMiB: 1024, workerThreads: true, adaptiveMaxTimeMs: 20000, adaptiveMaxUpdates: 1280000, qualityPolicy: 'research' });
  const flops = require('./strategy-library.cjs').canonicalFlops(); let queuedFlops = 0;
  for (const g of topFlop.slice(0, flopConfigs)) { const id = g.sample.identity, sp = g.sample.spot; for (const f of flops) { const b = LS.spotFromParams({ street: 'flop', board: f.match(/../g), stacksBehind: id.stacksBehindBB, pot: id.potBB, ranges: sp.config.ranges, rangeModelName: id.rangeModel }, { ranges: sp.config.ranges, iterations: id.training.iterations || 20000 }); if (q.enqueue(b.spot, { priority: g.count, reason: 'flop catalogue' }).status !== 'already-stored') queuedFlops++; } }
  for (const m of distinct) if (m.identity.street !== 'flop' && m.spot) q.enqueue(m.spot, { priority: 1000 + m.count, reason: 'seen in training data' });
  const tb = Date.now(); let jobs = 0; const perKind = {};
  q.on((ev) => { if (ev.type === 'complete' && ev.job.training) { jobs++; const k = ev.job.street + ' ' + ev.job.players + 'p'; (perKind[k] = perKind[k] || []).push(ev.job.training.trainMs); } if (Date.now() - tb > budgetMs) q.pause(); });
  q.start(); await q.drain(); const qs = q.status(); q.close();
  const med = (a) => { const s = a.slice().sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
  doc.build = { budgetMinutes: budgetMs / 60000, elapsedMs: Date.now() - tb, flopCatalogueConfigurations: Math.min(flopConfigs, topFlop.length), flopStudiesQueued: queuedFlops, jobsCompleted: jobs, queue: qs.stats || qs, libraryRecords: lb.list().length, storageBytes: lb.status().storageBytes, medianTrainMsByKind: Object.fromEntries(Object.entries(perKind).map(([k, a]) => [k, { studies: a.length, medianMs: med(a) }])), byQuality: lb.status().byQuality };
  process.stderr.write('built ' + jobs + ' studies in ' + Math.round((Date.now() - tb) / 1000) + ' s\n');
  // 3 measure: in-sample, out-of-sample, out-of-sample with on-demand heads-up rivers
  const inS = [], outS = [], outD = []; for (const s of trainSeeds) inS.push(...(await play(s)).actions); for (const s of testSeeds) outS.push(...(await play(s)).actions); for (const s of testSeeds) outD.push(...(await play(s, { inlineHeadsUpRiver: true, inlineRiverMaxMs: 3000 })).actions);
  doc.inSample = classify(inS); doc.outOfSample = classify(outS); doc.outOfSampleWithOnDemandRivers = classify(outD);
  // missing configurations on unseen hands and the cost to cover them
  const lb2 = L.StrategyLibrary.open(lib), miss2 = (lb2.missSummary(Infinity).list || []).filter((m) => !distinct.some((d) => d.fingerprint === m.fingerprint));
  const missByKind = miss2.reduce((m, x) => { const k = x.identity.street + ' ' + x.identity.players + 'p'; m[k] = m[k] || { distinct: 0, occurrences: 0 }; m[k].distinct++; m[k].occurrences += x.count; return m; }, {});
  doc.missingOnUnseenHands = { distinctSituations: miss2.length, byKind: missByKind, estimatedTrainingHoursToCoverExactly: +(Object.entries(missByKind).reduce((a, [k, v]) => a + v.distinct * ((perKind[k] && med(perKind[k])) || 2000), 0) / 3.6e6).toFixed(2), note: 'Exact coverage of these specific situations does not carry over to new hands: turn and river boards almost never repeat. The estimate is single-thread time for these situations only.' };
  doc.elapsedMs = Date.now() - t0; fs.writeFileSync(args.out || path.join(work, 'coverage.json'), JSON.stringify(doc, null, 1));
  process.stderr.write('in-sample exact ' + (doc.inSample.exactShare * 100).toFixed(1) + '%, out-of-sample exact ' + (doc.outOfSample.exactShare * 100).toFixed(1) + '%, out-of-sample with on-demand rivers ' + (doc.outOfSampleWithOnDemandRivers.anyStrategyShare * 100).toFixed(1) + '%\n');
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
