'use strict';
/* 0.33 calibration of the CHECK-DOWN continuation used by compact preflop modes B / B169 (reports/0.33-checkdown-calibration.json).
 *
 * Question: how far is the value a compact preflop study assigns to reaching the flop (raw showdown equity x pot: nobody bets after
 * the flop) from the value of the same flop under STRATEGIC postflop play?
 * Method (exact for each defined flop game):
 *   1. ranges: from a trained compact preflop study, the BTN first-in OPEN range (open 2.2 frequency per class) and the BB range that
 *      CALLS that open after the SB folds (call frequency per class). Classes below --minFreq are dropped to keep the flop solve
 *      tractable ("core ranges"; the retained share of each range's mass is reported).
 *   2. game: heads-up flop, pot 5.7 bb (2.2 + 2.2 + SB 0.5 + antes 0.8), 22.7 bb behind each, BB first to act; postflop menu of
 *      Mode A (50 % pot bet, all-in raise, 1 bet per street) on flop, turn and river.
 *   3. strategic value: exact CFR+ equilibrium (src/flop-solver.js) to <= --target % of the pot, values from the independent evaluator
 *      (src/fast-multistreet.js); the remaining exploitability bounds the error of these values.
 *   4. check-down value: the same ranges and flop with no postflop betting (exact runout enumeration).
 *   Reported per flop and player: equilibrium value, check-down value, difference (bb and % of pot), realisation ratio = equilibrium
 *   value / check-down value.
 * The result is CALIBRATION DATA for one line (BTN open vs BB call, 25 bb, chip EV) on the sampled flops - not a general correction.
 * usage: node tools/checkdown-calibration-033.cjs --state=PF033_B169_STATE --spec=SPEC [--assumption [--btnRange=R --bbRange=R]] [--flops=As7d2h,...] [--minFreq=0.5] [--target=0.5] [--maxMs=600000] [--threads=3] --out=FILE */
const fs = require('node:fs'), os = require('node:os');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), MS = require('../src/fast-multistreet.js'), FS = require('../src/flop-solver.js'), PC = require('../src/preflop-compact.js'), PR = require('../src/preflop-research.js'), T = require('./studies.cjs');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const minFreq = +(args.minFreq || 0.5), targetPct = +(args.target || 0.5), maxMs = +(args.maxMs || 600000), threads = +(args.threads || Math.min(3, os.cpus().length));
const flops = String(args.flops || 'As7d2h,Kh9h4c,8s8d3c,Jc6d5s').split(',');
const POT = 5.7, BEHIND = 22.7, MENU = { bets: '50', raises: 'a', maxBets: 1 }, NOBET = PC.NOBET;

/** class -> frequency of the chosen action at a node of the read (null for classes without rows). */
function classFreq(read, pathStr, action) { const out = new Array(169).fill(null); for (let c = 0; c < 169; c++) { const s = read.classStrategy(pathStr, c); if (s) out[c] = s[action]; } return out; }
function rangeText(freq, min) {
  const parts = [], names = EM.CLASS_NAMES; let kept = 0, total = 0;
  for (let c = 0; c < 169; c++) { const f = freq[c]; if (f === null) continue; const w = f * EM.CLASS_NCOMBOS[c]; total += w; if (f < min) continue; kept += w; parts.push(names[c] + ':' + f.toFixed(4)); }
  return { text: parts.join(','), retainedMassShare: total ? +(kept / total).toFixed(4) : 0, classes: parts.length };
}
(async () => {
  const spec = JSON.parse(fs.readFileSync(args.spec, 'utf8')), read = PC.readPreflop(args.state, spec, EM);
  const p0 = A.prepare(EM, { config: T.PREFLOP8_LINKED, iterations: 1 }), fi = PR.firstInPaths(p0), btn = fi.find((f) => f.position === 'BTN');
  const openIdx = btn.labels.findIndex((l) => /2\.2/.test(l)); if (openIdx < 0) throw new Error('No 2.2 open at the BTN first-in node: ' + btn.labels);
  // BB facing the BTN open after the SB folds
  const g = p0.game, btnSteps = btn.path.concat(openIdx), sbView = g.view(btnSteps), sbFold = sbView.actions.findIndex((a) => a.label === 'Fold'), bbSteps = btnSteps.concat(sbFold), bbView = g.view(bbSteps);
  const bbCall = bbView.actions.findIndex((a) => /^Call/.test(a.label));
  const btnFreq = classFreq(read, 'r' + btn.path.join(''), openIdx), bbFreq = classFreq(read, 'r' + bbSteps.join(''), bbCall);
  let rBtn = rangeText(btnFreq, minFreq), rBb = rangeText(bbFreq, minFreq), rangeSource = 'approximate strategy-derived (Mode B169 study, classes with frequency >= ' + minFreq + ')';
  // --assumption: explicitly labelled RESEARCH-ASSUMPTION ranges (not derived from any strategy) for a moderate-size calibration
  if (args.assumption) { rBtn = { text: args.btnRange || 'TT+,AJ+,KQ,ATs+,KTs+,QTs+,JTs,T9s,98s', retainedMassShare: null, classes: null }; rBb = { text: args.bbRange || '99-55,AT-A8,KJ-KT,QJ,QTs,JTs,T9s,98s,87s,76s', retainedMassShare: null, classes: null }; rangeSource = 'research assumption (manually specified, not derived from a strategy)'; }
  const doc = { format: 'eightmax-checkdown-calibration', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), machine: { cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, node: process.version },
    source: { rangeSource, state: require('node:path').basename(args.state), updates: read.header.iterations, line: 'BTN opens 2.2 (' + btn.labels[openIdx] + '), SB folds, BB calls (' + bbView.actions[bbCall].label + ')', btnRange: rBtn, bbRange: rBb, minFreq },
    game: 'heads-up flop, pot ' + POT + ' bb, ' + BEHIND + ' bb behind each, BB (seat 0) first to act, menu 50% pot / all-in raise / 1 bet per street on flop, turn and river; chip EV; exact private hands and runouts',
    method: { strategic: 'src/flop-solver.js CFR+ to <= ' + targetPct + '% of the pot; values from src/fast-multistreet.js (independent)', checkdown: 'same flop and ranges, no postflop betting, exact runouts' }, flops: [] };
  const save = () => { if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); }; save();
  for (const flop of flops) {
    const base = { board: flop, common: POT, stacks: [BEHIND, BEHIND], ranges: [rBb.text, rBtn.text], privateSeed: 1 };
    const cfgEq = { ...base, streets: { flop: MENU, turn: MENU, river: MENU } }, cfgCd = { ...base, streets: { flop: NOBET, turn: NOBET, river: NOBET } };
    const pc = A.prepare(EM, { config: cfgCd, iterations: 1 }), cd = MS.prepare(pc.game, pc.spec).evaluate({ rows: (node, seat, board) => new Array(pc.spec.hands[seat].length).fill(0).map(() => Float64Array.of(1)) });
    const t0 = Date.now(); let eq;
    try { eq = await FS.solveParallel(cfgEq, { iterations: 4000, every: 25, target: targetPct / 100 * POT, deadline: Date.now() + maxMs, threads, maxBytes: 8 * 2 ** 30 }); } catch (e) { doc.flops.push({ flop, error: e.message, code: e.code }); save(); continue; }
    const row = { flop, combos: eq.core.hands.map((h) => h.length), iterations: eq.iterations, stopped: eq.stopped, solveMs: Date.now() - t0, exploitabilityPctPot: +eq.exploitabilityPctPot.toFixed(4),
      players: ['BB (out of position)', 'BTN (in position)'].map((name, i) => ({ player: name, equilibriumValueBB: +eq.values[i].toFixed(5), checkdownValueBB: +cd.values[i].toFixed(5), differenceBB: +(eq.values[i] - cd.values[i]).toFixed(5), differencePctPot: +((eq.values[i] - cd.values[i]) / POT * 100).toFixed(3), realisation: +(eq.values[i] / cd.values[i]).toFixed(4) })),
      valueErrorBound: 'equilibrium values are exact for the average strategy; their distance from the game value is bounded by the exploitability (' + eq.exploitability.toFixed(4) + ' bb)' };
    doc.flops.push(row); save(); process.stderr.write(flop + ': ' + JSON.stringify(row.players.map((x) => [x.player, x.equilibriumValueBB, x.checkdownValueBB, x.realisation])) + ' expl ' + row.exploitabilityPctPot + '%\n');
  }
  const ok2 = doc.flops.filter((f) => f.players); if (ok2.length) doc.summary = { flops: ok2.length, meanAbsDifferencePctPot: [0, 1].map((i) => +(ok2.reduce((a, f) => a + Math.abs(f.players[i].differencePctPot), 0) / ok2.length).toFixed(3)), meanRealisation: [0, 1].map((i) => +(ok2.reduce((a, f) => a + f.players[i].realisation, 0) / ok2.length).toFixed(4)), players: ['BB (out of position)', 'BTN (in position)'] };
  save(); if (!args.out) console.log(JSON.stringify(doc, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
