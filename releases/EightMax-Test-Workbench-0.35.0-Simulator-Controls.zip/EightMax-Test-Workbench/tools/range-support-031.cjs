'use strict';
/* 0.31 range-support analysis (reports/0.31-range-support.json): for the eight-handed linked preflop study, enumerate the preflop
 * lines that reach the flop, weight each by its probability under the stored strategy (computed from the conditioned ranges
 * themselves: P(action) = sum_h w(h) sigma(a|h) / sum_h w(h)), and report how often the derived ranges of the players who see
 * the flop are fully supported (every combo had a stored strategy row at every node of the line) or at least within the
 * model's unsupported-share limit. Compares preflop studies trained for different update counts.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/range-support-031.cjs --updates=500000,2000000 --cache=DIR [--min=0.0005] --out=FILE */
const fs = require('node:fs'), path = require('node:path');
const RE = require('../src/range-engine.js'), ST = require('../src/solver-tree.js'), TS = require('./train-study.cjs'), T = require('./studies.cjs');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const counts = String(args.updates || '500000').split(',').map(Number), limit = +(args.limit || 0.25);

async function analyse(updates) {
  const cacheDir = path.join(args.cache || '.', String(updates)); fs.mkdirSync(cacheDir, { recursive: true });
  const s = await TS.trainStudyLazy(updates, { config: T.PREFLOP8_LINKED, name: 'preflop8-linked', cacheDir, threads: 3, budgetMiB: 1024 });
  const src = new ST.PreflopTreeSource(require('../tests/load-solver.cjs'), s.prepared, { studyId: 'preflop8-' + updates }), st = src.study, prepared = st.prepared;
  st.seatOrder = [0, 1, 2, 3, 4, 5, 6, 7];   // study seats == sim seats for this analysis
  const rows = new Map(prepared.spec.hands.map((r, i) => [i, RE.rowMap(r)])), EM = st.EM;
  // Monte-Carlo sample of preflop lines: deal eight random hands and let every seat act from its stored average strategy (class-
  // pooled; a hand with no stored row at a node acts uniformly at random - only for generating line frequencies). Each distinct line
  // that reaches the flop is then analysed ONCE with exactly the range computation used by the decision path (RE.preflopRanges).
  let x = 12345; const rnd = () => { x = (Math.imul(x, 1103515245) + 12345) >>> 0; return x / 4294967296; };
  const samples = +(args.samples || 3000), seen = new Map(); let toFlop = 0;
  const t0 = Date.now();
  for (let n = 0; n < samples; n++) {
    const deck = Array.from({ length: 52 }, (_, i) => i); for (let i = 51; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    const hole = Array.from({ length: 8 }, (_, s2) => [deck[2 * s2], deck[2 * s2 + 1]]), steps = []; let v = st._view(steps);
    while (v.kind === 'player') {
      const h = hole[v.seat], row = rows.get(v.seat).get(RE.IDX[Math.min(...h) * 52 + Math.max(...h)]);
      let p = row ? prepared.game.averageAt('r' + steps.join(''), prepared.spec.board, v.seat, { id: row[0], a: row[1], b: row[2], w: row[3] }) : null;
      if (!p) { const q = st._pool(v.seat, h, 'r' + steps.join('')); p = q ? q.mix : v.labels.map(() => 1 / v.labels.length); }
      let r = rnd(), a = 0; while (a < p.length - 1 && r >= p[a]) { r -= p[a]; a++; } steps.push(a); v = st._view(steps);
    }
    const live = Array.isArray(v.live) ? v.live.filter(Boolean).length : 0; if (v.kind !== 'chance' || live < 2) continue; toFlop++;
    const key = 'r' + steps.join(','); const e = seen.get(key); if (e) { e.count++; continue; } seen.set(key, { steps: steps.slice(), count: 1, live });
  }
  for (const [, e] of seen) {
    // turn the step path into simulator actions (study seat == sim seat with seatOrder [0..7]; button such that preflopSeatOrder gives 0..7)
    const acts = []; let steps2 = []; for (const a of e.steps) { const v = st._view(steps2), lab = v.parsed[a]; acts.push({ seat: v.seat, type: lab.kind === 'allin' ? 'allin' : lab.kind, amount: lab.to || 0, street: 'preflop' }); steps2 = steps2.concat(a); }
    const bt = [0, 1, 2, 3, 4, 5, 6, 7].find((b) => ST.preflopSeatOrder(b).every((sim, i) => sim === i));
    const r = RE.preflopRanges(src, { button: bt, actions: acts }, { ST });
    const liveSeats = st._view(e.steps).live.map((l, i) => (l ? i : -1)).filter((i) => i >= 0);
    e.status = r.status; e.unsupported = liveSeats.map((s2) => r.ranges.get(s2).unsupported.reduce((acc, u) => acc + u.massShare, 0)); e.path = r.path || ('r' + e.steps.join(''));
  }
  const flop = [...seen.values()], mass = toFlop;
  const share = (f) => +(flop.filter(f).reduce((a, l) => a + l.count, 0) / Math.max(1, mass)).toFixed(4);
  return { updates, analysisMs: Date.now() - t0, sampledDeals: samples, dealsReachingFlop: toFlop, distinctFlopLines: flop.length, method: 'Monte-Carlo line sampling from the stored strategy; each distinct line analysed exactly with RE.preflopRanges',
    shareOfFlopsAllRangesFullySupported: share((l) => l.status === 'ok' && l.unsupported.every((u) => u === 0)), shareOfFlopsWithinLimit: share((l) => l.status === 'ok' && l.unsupported.every((u) => u <= limit)), unsupportedLimit: limit,
    byPlayers: Object.fromEntries([2, 3, 4, 5].map((n) => { const L2 = flop.filter((l) => l.live === n), m2 = L2.reduce((a, l) => a + l.count, 0); return [n, { distinctLines: L2.length, shareOfFlops: +(m2 / Math.max(1, mass)).toFixed(4), withinLimit: +(L2.filter((l) => l.status === 'ok' && l.unsupported.every((u) => u <= limit)).reduce((a, l) => a + l.count, 0) / Math.max(1, m2)).toFixed(4) }]; })),
    unsupportedShareDistribution: (() => { const all = flop.flatMap((l) => l.unsupported.map((u) => [u, l.count])); const b = { '0': 0, '0-5%': 0, '5-25%': 0, '25-50%': 0, '>50%': 0 }; let t = 0; for (const [u, c] of all) { t += c; b[u === 0 ? '0' : u <= 0.05 ? '0-5%' : u <= 0.25 ? '5-25%' : u <= 0.5 ? '25-50%' : '>50%'] += c; } for (const k in b) b[k] = +(b[k] / Math.max(1, t)).toFixed(4); return b; })(),
    topLines: flop.sort((a, b) => b.count - a.count).slice(0, 15).map((l) => ({ path: l.path, shareOfFlops: +(l.count / Math.max(1, mass)).toFixed(4), players: l.live, maxUnsupportedShare: +Math.max(...l.unsupported).toFixed(4) })) };
}
(async () => {
  const doc = { format: 'eightmax-range-support', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), study: 'preflop8-linked (8 seats, 25 bb, ante 0.1, opens 2.2 / all-in, 3 bets), native EightMax 5.1',
    meaning: 'A derived range is fully supported when the stored preflop strategy has a row for every combination at every node of the line. Combos without rows keep their prior weight and are counted as unsupported; the range model falls back to any-two-cards (labelled) above the limit.', runs: [] };
  for (const u of counts) { const r = await analyse(u); doc.runs.push(r); process.stderr.write(u + ' updates: flop (' + r.dealsReachingFlop + ' deals reach the flop, ' + r.distinctFlopLines + ' distinct lines), all ranges fully supported ' + (r.shareOfFlopsAllRangesFullySupported * 100).toFixed(1) + '%, within limit ' + (r.shareOfFlopsWithinLimit * 100).toFixed(1) + '% (' + r.analysisMs + ' ms)\n'); }
  if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); else console.log(JSON.stringify(doc, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
