'use strict';
/* 0.33 reach-weighted preflop coverage that works for BOTH snapshot layouts (exact hands: 0.32 builder; 169 classes: Mode B169).
 * Monte-Carlo line sampling: deal 8 hands, follow the stored average strategy (uniform where the acting hand has no stored row), and
 * count, per position, the decisions where the acting hand HAS its own stored strategy. A class-keyed study answers every combination
 * of a stored class. The share is a sampled estimate with a Wilson 95 % interval; it measures availability, not accuracy.
 * usage: node tools/preflop-reach-coverage-033.cjs --state=FILE --spec=FILE [--deals=20000] [--seed=4242] [--out=FILE] */
const fs = require('node:fs'), path = require('node:path');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), T = require('./studies.cjs'), PS = require('../src/preflop-snapshot.js'), PC = require('../src/preflop-compact.js');
const SHORT = PC.SHORT;
function wilson(k, n) { if (!n) return [null, null]; const z = 1.96, p = k / n, d = 1 + z * z / n, c = (p + z * z / (2 * n)) / d, h = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d; return [+(c - h).toFixed(4), +(c + h).toFixed(4)]; }
/** snapshot for a state file: exact layout -> 0.32 builder over the lazy store; keyed -> class snapshot. Cached next to the state. */
function snapshotFor(state, spec) {
  const head = (() => { const fd = fs.openSync(state, 'r'); try { const t = Buffer.alloc(12); fs.readSync(fd, t, 0, 12, 0); const b = Buffer.alloc(t.readUInt32LE(8)); fs.readSync(fd, b, 0, b.length, 12); return JSON.parse(b.toString('utf8')); } finally { fs.closeSync(fd); } })();
  const file = state + '.emps'; if (fs.existsSync(file)) { const l = PS.load(file, {}); if (l.snapshot.header.sourceRowCrc32 === head.rowCrc32) return l.snapshot; }
  let buf; if (head.rowKeys === 1) buf = PC.buildClassSnapshot(state, spec, EM, { studyId: path.basename(state) });
  else { const { StrategyStore } = require('../src/strategy-store.js'), st = StrategyStore.open(state, { cacheBytes: 64 << 20, verify: false }); buf = PS.build(st, { studyId: path.basename(state) }); st.close(); }
  PS.save(buf, file); return PS.open(buf, {});
}
function reachCoverage(snap, spec, o = {}) {
  const prepared = A.prepare(EM, { config: T.PREFLOP8_LINKED, iterations: 1 }), g = prepared.game, deals = o.deals || 20000;
  const idx = spec.hands.map((rows) => new Map(rows.map((r, i) => [Math.min(r[1], r[2]) * 64 + Math.max(r[1], r[2]), i])));
  const vc = new Map(), V = (steps) => { const k = steps.join(','); let v = vc.get(k); if (!v) { const w = g.view(steps); v = { kind: w.kind, seat: w.seat, k: w.actions ? w.actions.length : 0 }; if (vc.size > 200000) vc.clear(); vc.set(k, v); } return v; };
  let x = (o.seed || 4242) >>> 0; const rnd = () => { x = (Math.imul(x, 1103515245) + 12345) >>> 0; return x / 4294967296; };
  const per = SHORT.map((p) => ({ position: p, decisions: 0, withRow: 0 })); let flop = 0;
  for (let d = 0; d < deals; d++) {
    const deck = Array.from({ length: 52 }, (_, i) => i); for (let i = 51; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    const steps = []; let v = V(steps), path = 'r';
    while (v.kind === 'player') {
      const seat = v.seat, a = deck[2 * seat], b = deck[2 * seat + 1], hi = idx[seat].get(Math.min(a, b) * 64 + Math.max(a, b)), p = hi === undefined ? null : snap.averageAt(path, seat, hi), e = per[seat];
      e.decisions++; if (p) e.withRow++;
      const q = p || new Float64Array(v.k).fill(1 / v.k); let r = rnd(), act = 0; while (act < q.length - 1 && r >= q[act]) { r -= q[act]; act++; }
      steps.push(act); path += String(act); v = V(steps);
    }
    if (v.kind === 'chance') flop++;
  }
  return { method: 'Monte-Carlo line sampling from the stored average strategy (uniform where the acting hand has no row); sampled estimate with Wilson 95% intervals', deals, seed: o.seed || 4242, dealsReachingFlop: flop,
    keyedBy: snap.header.keyedBy || 'hand', iterations: snap.header.iterations, snapshotBytes: snap.bytes,
    overall: (() => { const n = per.reduce((s, e) => s + e.decisions, 0), k = per.reduce((s, e) => s + e.withRow, 0); return { decisions: n, share: +(k / n).toFixed(4), ci95: wilson(k, n) }; })(),
    byPosition: per.map((e) => ({ position: e.position, decisions: e.decisions, shareWithOwnRow: e.decisions ? +(e.withRow / e.decisions).toFixed(4) : null, ci95: wilson(e.withRow, e.decisions) })) };
}
module.exports = { reachCoverage, snapshotFor };
if (require.main === module) {
  const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
  const spec = JSON.parse(fs.readFileSync(args.spec, 'utf8')), snap = snapshotFor(args.state, spec), r = reachCoverage(snap, spec, { deals: +(args.deals || 20000), seed: +(args.seed || 4242) });
  r.state = path.basename(args.state); if (args.out) fs.writeFileSync(args.out, JSON.stringify(r, null, 1)); console.log(JSON.stringify({ state: r.state, overall: r.overall, byPosition: r.byPosition.map((x) => x.position + ' ' + x.shareWithOwnRow) }));
}
