'use strict';
/* 0.32 research summary for the dashboard's Research panel (GET /api/research/summary reads the file written here).
 * Collects, WITHOUT training anything: the latest preflop research (this computer's run if present, else the release report),
 * the strategy library's linked-continuation and quality status by street, coverage (release report or this computer's), the
 * turn-solver check, the memory comparison and the live memory state of this computer. Every block says where it came from
 * ("measured on this computer" vs "release measurement on the build machine").
 * usage: node tools/research-summary-032.cjs [--lib=DIR] [--out=FILE] [--release (build-time summary embedded in START.html: no live
 *        computer data, no library)] */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const root = path.join(__dirname, '..'), appData = process.platform === 'win32' && process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'EightMax-Test-Workbench') : path.join(os.homedir(), '.eightmax-workbench');
const read = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } };
function pick(localName, releaseName) { const l = read(path.join(appData, localName)); if (l) return { source: 'measured on this computer', file: path.join(appData, localName), doc: l }; const r = read(path.join(root, 'reports', releaseName)); return r ? { source: 'release measurement on the build machine (Linux container), not this computer', file: 'reports/' + releaseName, doc: r } : null; }

function preflopBlock() {
  const p = pick('preflop-research-latest.json', '0.32-preflop-research.json'); if (!p) return { available: false, message: 'No preflop research yet. Use Run Preflop Research.' };
  const runs = (p.doc.runs || []).filter((r) => !r.error).map((r) => ({ variant: r.variant, seed: r.seed, updates: r.updates, complete: r.complete,
    reachWeightedClassCoverage: r.coverage.sampled.reachWeightedClassCoverage, reachWeightedComboCoverage: r.coverage.sampled.reachWeightedComboCoverage, statesWithNoRow: r.coverage.exactCounts.statesWithNoRow, decisionStates: r.coverage.exactCounts.preflopDecisionStates,
    perSeat: r.coverage.perSeat.map((s) => ({ position: s.position, classCoverage: s.reachWeightedClassCoverage, missingStates: s.reachedStatesWithMissingClasses })), missingBranches: (r.coverage.missingBranches || []).slice(0, 10),
    rangeSupportWithinLimit: r.rangeSupport && r.rangeSupport.shareOfFlopsWithinLimit, rangeSupportCi95: r.rangeSupport && r.rangeSupport.withinLimitCi95,
    deviations: (r.firstInDeviations || []).map((d) => ({ position: d.position, gainBB: d.gainBB ? d.gainBB.mean : null, ci95: d.gainBB ? d.gainBB.ci95 : null, conditionalGainBB: d.conditionalGainBB ? d.conditionalGainBB.mean : null, reach: d.reachProbability ? d.reachProbability.mean : null, fallbackShare: d.fallbackShare, error: d.error || d.reason || null })),
    assessment: r.assessment }));
  return { available: true, source: p.source, file: p.file, mode: p.doc.modeLabel || p.doc.mode, game: p.doc.game, classifications: p.doc.classifications, runs, validationStatus: 'not validated: no full eight-handed accuracy measure exists; coverage and deviation gains are partial evidence (see classifications)' };
}
function libraryBlock() {
  if (args.release) return { available: false, message: 'Release data: no strategy library is bundled. Open the dashboard through START-DESKTOP.cmd to see your own library.' };
  const dir = args.lib || (process.platform === 'win32' && process.env.LOCALAPPDATA ? path.join(appData, 'StrategyLibrary') : path.join(os.homedir(), '.eightmax-workbench', 'StrategyLibrary'));
  if (!fs.existsSync(path.join(dir, 'index.json'))) return { available: false, message: 'No strategy library yet (' + dir + ').' };
  const L = require('../src/strategy-library.js'), Q = require('../src/strategy-quality.js'), lib = L.StrategyLibrary.open(dir, { readOnly: true }), ledger = new Q.QualityLedger(dir), out = {};
  for (const e of lib.list()) { const k = e.street + (e.players === 2 ? ' heads-up' : ' multiway'), b = out[k] || (out[k] = { records: 0, withLinkedContinuation: 0, linkedComplete: 0, validated: 0, unverified: 0, failed: 0, other: 0 });
    b.records++; if (e.linked) { b.withLinkedContinuation++; if (e.linked.missingRows === 0) b.linkedComplete++; }
    const le = ledger.latest(e.fingerprint, e.rawSha256), st = (le && le.status) || e.quality || 'unverified'; if (st === 'validated') b.validated++; else if (st === 'unverified') b.unverified++; else if (st === 'failed-quality-check') b.failed++; else b.other++; }
  return { available: true, source: 'this computer\'s strategy library', dir, byStreet: out, note: 'A flop or turn record is evaluated exactly only with a linked continuation record (heads-up); without one it stays unverified. Linked records with unvisited continuation rows are never validated.' };
}
function coverageBlock() {
  const p = pick('coverage-latest.json', '0.32-coverage.json'); if (!p) return { available: false, message: 'No coverage measurement.' };
  const d = p.doc, col = (c) => (c ? { decisions: c.postflopDecisions, exact: c.exact, abstracted: c.abstracted, solvedOnDemand: c.solvedOnDemand, unavailable: c.unavailable, exactShare: c.exactShare, exactShareCi95: c.exactShareCi95, anyStrategyShare: c.anyStrategyShare, anyStrategyShareCi95: c.anyStrategyShareCi95, byStreet: c.byStreet } : null);
  return { available: true, source: p.source, file: p.file, outOfSampleExact: col(d.outOfSample), outOfSampleWithApproximations: col(d.outOfSampleWithApproximations), outOfSampleWithOnDemandRivers: col(d.outOfSampleWithOnDemandRivers), outOfSampleWithOnDemandRiversTurnsAndApproximations: col(d.outOfSampleWithOnDemandRiversTurnsAndApproximations), extraUnseenSeeds: d.extraUnseenSeeds ? { seeds: d.extraUnseenSeeds.seeds, exactOnly: col(d.extraUnseenSeeds.exactOnly), withOnDemandAndApproximations: col(d.extraUnseenSeeds.withOnDemandAndApproximations) } : null, build: d.build ? { studies: d.build.jobsCompleted, storageBytes: d.build.storageBytes, elapsedMs: d.build.elapsedMs } : null, missingOnUnseenHands: d.missingOnUnseenHands || null, baseline031: d.baseline031 || null };
}
function memoryBlock() {
  const p = pick('memory-latest.json', '0.32-memory-comparison.json'), total = os.totalmem(), free = os.freemem(), used = total - free;
  if (args.release) return { live: null, comparison: p ? { source: p.source, file: p.file, rows: p.doc.rows, sharedPreflop: p.doc.sharedPreflop } : null, trainingLimits: null };
  return { live: { totalBytes: total, freeBytes: free, usedShare: +(used / total).toFixed(3), pressure: used / total > 0.9 ? 'high' : used / total > 0.75 ? 'elevated' : 'normal', thisProcessRssBytes: process.memoryUsage().rss, measuredAt: new Date().toISOString() },
    comparison: p ? { source: p.source, file: p.file, rows: p.doc.rows, sharedPreflop: p.doc.sharedPreflop } : null,
    trainingLimits: { nativeStudyBudgetMiB: 'per study, planner-checked (src/strategy-budget.js); the 2,000,000-update preflop study needs about 2.8 GB while training', turnSolverMaxBytes: 768 << 20, linkedRecordMaxBytes: 256 << 20 } };
}
function turnBlock() { const p = pick('turn-solver-latest.json', '0.32-turn-solver-benchmark.json'); if (!p) return { available: false }; return { available: true, source: p.source, file: p.file, rows: (p.doc.results || []).map((r) => ({ ranges: r.ranges, menu: r.menu, stacks: r.stacks, iterations: r.iterations, solveMs: r.solveMs, exploitabilityPctPot: r.exploitabilityPctPot, stopped: r.stopped, memoryEstimateMiB: r.memoryEstimateMiB, error: r.error || null })) }; }

const doc = { format: 'eightmax-research-summary', version: 1, appVersion: require('../src/engine.js').VERSION, writtenAt: new Date().toISOString(), preflop: preflopBlock(), library: libraryBlock(), coverage: coverageBlock(), turnSolver: turnBlock(), memory: memoryBlock(),
  disclaimer: 'Research measurements under stated assumptions. Nothing here is a GTO certification; eight-handed equilibrium is not established.' };
const out = args.out || path.join(appData, 'research-summary.json'); fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, JSON.stringify(doc, null, 1));
console.log('Research summary written: ' + out);
