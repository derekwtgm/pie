'use strict';
/* 0.33 research summary (GET /api/research/summary). Runs the 0.32 summary (preflop study, linked records, coverage, memory, turn
 * solver - unchanged keys, so the 0.32 Research panel keeps working) and adds the 0.33 block `v033` for the Solver research panel:
 *   preflopModes  solver modes A/B/B169/C: memory, speed, coverage by position, deviation gains, accuracy class (Mode D comparison)
 *   calibration   check-down continuation vs exact flop equilibria (approximation error of modes B/B169)
 *   flopSolver    restricted heads-up flop CFR+: exploitability, iterations, time, memory, complete linked continuations
 *   multiway      independent multiway evaluator: analytic references and the engine cross-check (NashConv)
 *   coverage      0.33 unseen-hand coverage (exact / approximate / on demand / unavailable, by street and player count)
 *   performance   0.33 ten-table benchmark (throughput, latency, memory, errors)
 * Each block is this computer's latest run when present (…-latest.json in the app-data folder), else the release report, and says which.
 * usage: node tools/research-summary-033.cjs [--lib=DIR] [--out=FILE] [--release] */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const root = path.join(__dirname, '..'), appData = process.platform === 'win32' && process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'EightMax-Test-Workbench') : path.join(os.homedir(), '.eightmax-workbench');
const read = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } };
function pick(localName, releaseName) { if (!args.release) { const l = read(path.join(appData, localName)); if (l) return { source: 'measured on this computer', doc: l }; } const r = read(path.join(root, 'reports', releaseName)); return r ? { source: 'release measurement on the build machine (' + releaseName + ')', doc: r } : null; }

function preflopModes() {
  const p = pick('preflop-modes-latest.json', '0.33-preflop-modes.json'); if (!p) return { available: false, message: 'No preflop mode comparison yet. Use Run Preflop Modes.' };
  const runs = (p.doc.runs || []).filter((r) => !r.error).map((r) => ({ mode: r.mode, seed: r.seed, updates: r.updates, accuracy: (p.doc.modes[r.mode] || {}).accuracyClass, peakRssMiB: r.training.peakRssMiB, stateBytes: r.training.stateBytes, updatesPerSecond: r.training.updatesPerSecond,
    checkpointBytes: r.checkpoint && r.checkpoint.emzBytes, postflopRowShare: r.anatomy && r.anatomy.postflopRowShare, preflopRows: r.coverage.preflopRows,
    positions: r.coverage.byPosition.map((x) => ({ position: x.position, statesWithRows: x.statesWithRows, classCoverage: x.classCoverageMean, firstInClasses: x.firstInClassesStored, firstInMissing: x.firstInMissingClasses })),
    gains: (r.gains || []).map((g) => ({ position: g.position, gainBB: g.gainBB ? g.gainBB.mean : null, ci95: g.gainBB ? g.gainBB.ci95 : null, error: g.error || g.reason || null })) }));
  return { available: true, source: p.source, modes: p.doc.modes, classifications: p.doc.classifications, runs, comparisons: p.doc.comparisons || [], fullGame: 'Eight-handed exploitability / NashConv: unavailable (not computed; never 0).' };
}
function block(local, release, map) { const p = pick(local, release); if (!p) return { available: false, message: 'Not measured yet.' }; return { available: true, source: p.source, ...map(p.doc) }; }

(async () => {
  let base = {};
  const tmp = path.join(os.tmpdir(), 'em-rs032-' + process.pid + '.json');
  const r = cp.spawnSync(process.execPath, [path.join(__dirname, 'research-summary-032.cjs'), '--out=' + tmp, ...(args.release ? ['--release'] : []), ...(args.lib ? ['--lib=' + args.lib] : [])], { encoding: 'utf8', timeout: 300000 });
  if (r.status === 0) { base = read(tmp) || {}; try { fs.rmSync(tmp); } catch (e) { /* temp */ } } else base = { error032: String(r.stderr || r.stdout).slice(-300) };
  const v033 = {
    preflopModes: preflopModes(),
    calibration: block('checkdown-calibration-latest.json', '0.33-checkdown-calibration.json', (d) => ({ line: d.source && d.source.line, game: d.game, flops: (d.flops || []).filter((f) => f.players).map((f) => ({ flop: f.flop, exploitabilityPctPot: f.exploitabilityPctPot, players: f.players })), summary: d.summary || null })),
    flopSolver: block('flop-solver-latest.json', '0.33-flop-solver-benchmark.json', (d) => ({ game: d.game, evaluator: d.evaluator, results: (d.results || []).map((x) => ({ board: x.board, ranges: x.ranges, menu: x.menu, stacks: x.stacks, combos: x.combos, iterations: x.iterations, exploitabilityPctPot: x.exploitabilityPctPot, wallMs: x.wallMs, memoryMiB: x.memoryEstimateMiB, meetsTarget: x.meetsTarget, missingRows: x.linkedRecord ? x.linkedRecord.missingRows : null, error: x.error })), checks: d.checks })),
    multiway: block('multiway-validation-latest.json', '0.33-multiway-validation.json', (d) => ({ evaluator: d.evaluator, meaning: d.meaning, references: (d.references || []).map((x) => ({ game: x.game, pass: x.pass, measured: x.measured })), crossCheck: Array.isArray(d.engineCrossCheck) ? d.engineCrossCheck.map((x) => ({ updates: x.updates, independentPctPot: x.independent && x.independent.nashConvPctPot, enginePctPot: x.engineInternal && x.engineInternal.nashConvPctPot, agree: x.agreement && x.agreement.withinTolerance1e9, missingRows: x.independent && x.independent.missingRows, meetsLimit: x.meetsResearchLimit2_5Pct })) : [] })),
    coverage: block('coverage-latest-033.json', '0.33-coverage.json', (d) => ({ columns: d.columns || null, summary: d.summary || null })),
    performance: block('benchmark-latest-033.json', '0.33-benchmark-ten-table-linux-simulated.json', (d) => ({ summary: d.summary || null })),
    machine: { cpus: os.cpus().length, totalMemBytes: os.totalmem(), freeMemBytes: os.freemem(), platform: process.platform }, generatedAt: new Date().toISOString(), appVersion: require('../src/engine.js').VERSION };
  const doc = { ...base, v033 };
  const out = args.out || path.join(appData, 'research-summary.json'); fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, JSON.stringify(doc, null, 1));
  console.log('Research summary written to ' + out);
})().catch((e) => { console.error(e); process.exit(1); });
