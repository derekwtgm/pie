'use strict';
/* 0.32 on-demand heads-up TURN solver benchmark (reports/0.32-turn-solver-benchmark.json).
 * For each configuration (range width x stack depth x bet menu): exact full-width CFR+ over turn + every river card
 * (src/fast-multistreet.js), stopping at 0.4 % of the pot (80 % of the research 0.5 %... see policy) or the time limit; records the
 * exact exploitability curve, wall time, memory estimate, linked-record size, and the exact re-evaluation of the stored bytes.
 * Optional comparison (--native): EightMax native MCCFR trained for the same wall time, evaluated by the same exact evaluator.
 * usage: node tools/turn-solver-benchmark-032.cjs [--maxMs=60000] [--native] --out=FILE */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), MS = require('../src/fast-multistreet.js'), LK = require('../src/linked-study.js'), Q = require('../src/strategy-quality.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const maxMs = +(args.maxMs || 60000), cli = process.env.EIGHTMAX_TEST_CLI;
const RANGES = { 'narrow (42 combos after the board)': 'AA,KK,77,AK,KQ,QJs,JTs,T9s', 'medium (109 combos after the board)': '22+,AJs+,KQs,QJs,JTs,T9s,98s,AQo+', 'wide (216 combos after the board)': '22+,A2s+,K9s+,Q9s+,J9s+,T8s+,97s+,87s,76s,ATo+,KJo+,QJo', 'any-two (1,128 combos after the board)': 'random' };
const MENUS = { 'restricted (1 size)': { turn: { bets: '75', raises: 'a', maxBets: 1 }, river: { bets: '75', raises: 'a', maxBets: 1 } }, 'library (2 sizes)': { turn: { bets: '50,a', raises: 'a', maxBets: 2 }, river: { bets: '50,a', raises: 'a', maxBets: 2 } } };
const STACKS = { 'SPR 1.5': [6, 6], 'SPR 4': [16, 16], 'SPR 10': [40, 40] };
const POT = 4, target = 0.004 * POT;   // 0.4 % of the pot = 80 % of the 0.5 % "strict" limit; the research policy limit is 1 %
(async () => {
  const doc = { format: 'eightmax-turn-solver-benchmark', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), machine: { cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, node: process.version },
    game: 'heads-up turn subgame (board AsKd7h4c), pot ' + POT + ' bb, turn + every river card enumerated, chip EV, exact private hands', stopRule: 'exploitability <= ' + target + ' bb (0.4% of the pot) or ' + maxMs + ' ms', results: [] };
  for (const [rn, r] of Object.entries(RANGES)) for (const [mn, m] of Object.entries(MENUS)) for (const [sn, st] of Object.entries(STACKS)) {
    if (args.quick && (rn.startsWith('any') || sn === 'SPR 10')) continue;
    const cfg = { board: 'AsKd7h4c', common: POT, stacks: st, ranges: [r, r], streets: m, privateSeed: 1 }, p = A.prepare(EM, { config: cfg, iterations: 1 }), t0 = Date.now();
    const F = MS.prepare(p.game, p.spec), est = F.estimateBytes(); let res;
    try { res = F.cfrPlus(100000, { every: 10, target, deadline: Date.now() + maxMs, maxBytes: 1536 << 20 }); } catch (e) { doc.results.push({ ranges: rn, menu: mn, stacks: sn, error: e.message, code: e.code }); continue; }
    const solveMs = Date.now() - t0, stand = { game: { view: (s) => p.game.view(s), iterations: res.iterations, averageAt: (a, b, c, d) => res.strategy.averageAt(a, b, c, d) }, spec: p.spec, options: p.options };
    const te = Date.now(), bytes = LK.exportLinked(stand, { EM }), exportMs = Date.now() - te, tv = Date.now(), ev = Q.evaluateLinked(LK.open(bytes), { potBB: POT }), evalMs = Date.now() - tv;
    const row = { ranges: rn, menu: mn, stacks: sn, combos: F.hands.map((h) => h.length), decisionNodes: F.tree.decisions, memoryEstimateMiB: +(est.bytes / 1048576).toFixed(1), iterations: res.iterations, stopped: res.stopped, solveMs, msPerIteration: +(solveMs / Math.max(1, res.iterations)).toFixed(1),
      exploitabilityBB: +res.exploitability.toFixed(6), exploitabilityPctPot: +res.exploitabilityPctPot.toFixed(4), meetsResearch1Pct: res.exploitabilityPctPot <= 1, meetsStrict05Pct: res.exploitabilityPctPot <= 0.5,
      storedBytesReevaluated: { exploitabilityBB: +ev.exploitabilityBB.toFixed(6), missingRows: ev.missingRows, equalToSolver: Math.abs(ev.exploitabilityBB - res.exploitability) < 1e-9 }, linkedBytes: bytes.length, exportMs, evalMs, curve: res.curve.map((c) => [c.iterations, +c.exploitability.toFixed(5), c.ms]) };
    if (args.native && cli) {   // EightMax native MCCFR for the same wall time, evaluated exactly
      const NT = require('./native-training.cjs'), dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-tsb-')), pn = A.prepare(EM, { config: cfg, iterations: 1000000, strategyBudgetMiB: 256 }), spec = path.join(dir, 's.json'), out = path.join(dir, 'o.state');
      fs.writeFileSync(spec, JSON.stringify(A.nativeJob(pn, 'tsb').spec)); let u = 20000, last = null, tn = Date.now();
      try { while (Date.now() - tn < solveMs) { const rr = await NT.trainNative({ cli, specFile: spec, updates: u, budgetMiB: 1024, threads: 1, outFile: out, resumeFrom: last ? out : null }); last = rr; u *= 2; } pn.game.importNative(fs.readFileSync(out)); const e2 = MS.prepare(pn.game, pn.spec).exact(pn.game); row.nativeSameTime = { updates: pn.game.iterations, wallMs: Date.now() - tn, exploitabilityBB: +e2.exploitability.toFixed(6), exploitabilityPctPot: +e2.exploitabilityPctPot.toFixed(4), missingRows: e2.missingRows }; }
      catch (e) { row.nativeSameTime = { error: e.message }; } fs.rmSync(dir, { recursive: true, force: true });
    }
    doc.results.push(row); process.stderr.write(rn + ' / ' + mn + ' / ' + sn + ': ' + row.iterations + ' it, ' + row.exploitabilityPctPot + '% pot, ' + solveMs + ' ms (' + row.stopped + ')' + (row.nativeSameTime ? ' | native ' + JSON.stringify(row.nativeSameTime) : '') + '\n');
    if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1));
  }
  if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); else console.log(JSON.stringify(doc, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
