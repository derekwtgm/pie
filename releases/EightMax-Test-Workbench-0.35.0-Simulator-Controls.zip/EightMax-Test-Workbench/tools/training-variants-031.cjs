'use strict';
/* 0.31 training-variant study (reports/0.31-training-variants.json).
 * Question: which of the EightMax 5.1 trainer variants (all external-sampling MCCFR, differing only in regret matching and
 * iteration weighting) gives the lowest EXACT exploitability per update on heads-up river reference games, and how big is
 * the gap to an independent full-width CFR+ reference? Every number is an exact evaluation (src/fast-river.js, cross-checked
 * against src/exploitability.js). Scope: heads-up single-street games only; nothing here measures the full tournament game.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/training-variants-031.cjs [--seeds=3] [--counts=5000,20000,100000] [--jobs=3] [--quick] --out=FILE */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), F = require('../src/fast-river.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const cli = process.env.EIGHTMAX_TEST_CLI; if (!cli) { console.error('EIGHTMAX_TEST_CLI (native mwcli) is required'); process.exit(2); }
const quick = !!args.quick, seeds = +(args.seeds || (quick ? 2 : 3)), counts = String(args.counts || (quick ? '5000,20000' : '5000,20000,100000,400000')).split(',').map(Number), jobs = +(args.jobs || Math.max(1, os.cpus().length - 1));
const variants = String(args.variants || Object.keys(A.TRAINER_VARIANTS).join(',')).split(',');
const work = fs.mkdtempSync(path.join(os.tmpdir(), 'em-variants-'));
const T95 = { 1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262 };
const stat = (a) => { const n = a.length, m = a.reduce((x, y) => x + y, 0) / n, sd = n > 1 ? Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / (n - 1)) : 0, h = n > 1 ? (T95[n - 1] || 1.96) * sd / Math.sqrt(n) : null; return { n, mean: +m.toFixed(6), sd: +sd.toFixed(6), ci95: h === null ? null : [+(m - h).toFixed(6), +(m + h).toFixed(6)], min: +Math.min(...a).toFixed(6), max: +Math.max(...a).toFixed(6) }; };
const RIVER2 = { river: { bets: '50,a', raises: 'a', maxBets: 2 } };
const GAMES = {
  'narrow-0.30-reference': { board: 'Kh9s5c3d2h', common: 10, stacks: [20, 20], ranges: Array(2).fill('TT+,AJs+,KTs+,QJs,AQo+,KQo'), streets: RIVER2 },
  'any-two-library-like': { board: 'Kh9s5c3d2h', common: 6, stacks: [24, 24], ranges: ['random', 'random'], streets: RIVER2 },
  'medium-ranges-deep-two-sizes': { board: 'Qd8c5h4s2c', common: 5.5, stacks: [45, 45], ranges: ['22+,A2s+,K9s+,Q9s+,J9s+,T9s,98s,ATo+,KJo+', '22-JJ,A2s-AJs,K9s+,Q9s+,J9s+,T8s+,97s+,86s+,75s+,65s,54s,A9o-AJo,KTo+,QTo+,JTo'], streets: { river: { bets: '33,75', raises: 'a', maxBets: 3 } } },
  'any-two-short-spr': { board: 'Ac7d7h3c2s', common: 8, stacks: [6, 6], ranges: ['random', 'random'], streets: RIVER2 },
};

function runNative(cfg, variant, updates, seed) {
  const p = A.prepare(EM, { config: { ...cfg, privateSeed: seed }, iterations: updates, timeMs: 600000, trainerVariant: variant });
  const tag = variant + '-' + updates + '-' + seed + '-' + Math.random().toString(36).slice(2, 8), spec = path.join(work, tag + '.json'), st = path.join(work, tag + '.state');
  fs.writeFileSync(spec, JSON.stringify(A.nativeJob(p, 'v').spec));
  return new Promise((res, rej) => {
    const t0 = Date.now(), c = cp.spawn(cli, [spec, String(updates), '1', st, '1024'], { stdio: ['ignore', 'pipe', 'pipe'] }); let err = '';
    c.stderr.on('data', (d) => { err += d; }); c.stdout.resume();
    c.on('close', (code) => { if (code !== 0) return rej(new Error('mwcli exit ' + code + ': ' + err.slice(-400))); try { p.game.importNative(fs.readFileSync(st)); fs.rmSync(st, { force: true }); fs.rmSync(spec, { force: true }); p.trainMs = Date.now() - t0; res(p); } catch (e) { rej(e); } });
  });
}
async function pool(tasks, n) { const out = new Array(tasks.length); let i = 0; await Promise.all(Array.from({ length: n }, async () => { while (i < tasks.length) { const k = i++; out[k] = await tasks[k](); } })); return out; }

(async () => {
  const t0 = Date.now(), doc = { format: 'eightmax-training-variants', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), environment: { platform: process.platform, cpus: os.cpus().length, cpuModel: os.cpus()[0].model, node: process.version, nativeCli: path.basename(cli) },
    engine: A.ENGINE, scope: 'Exact exploitability (bb, and % of the starting pot) of heads-up river reference games. All variants are external-sampling MCCFR in EightMax 5.1 (native mwcli, 1 thread); only regret matching and iteration weighting differ. Not a measurement of full-game accuracy.',
    variants: A.TRAINER_VARIANTS, seeds, counts, games: {} };
  for (const [name, cfg] of Object.entries(GAMES)) {
    const base = A.prepare(EM, { config: { ...cfg, privateSeed: 1 }, iterations: 10 }), fp = F.prepare(base.game, base.spec);
    const tr = Date.now(), ref = fp.cfrPlus(quick ? 300 : 1500, { every: quick ? 100 : 250 });
    const g = { config: cfg, hands: fp.hands.map((h) => h.length), treeNodes: fp.tree.nodes, reference: { algorithm: ref.method, iterations: ref.iterations, exploitabilityBB: ref.exploitability, exploitabilityPctPot: ref.exploitabilityPctPot, gameValueSeat0BB: ref.values[0], curve: ref.curve, ms: Date.now() - tr }, results: {} };
    process.stderr.write(name + ': reference CFR+ ' + ref.iterations + ' it, exploitability ' + ref.exploitability.toExponential(3) + ' bb (' + (Date.now() - tr) + ' ms)\n');
    const tasks = [];
    for (const v of variants) for (const u of counts) for (let s = 1; s <= seeds; s++) tasks.push(async () => { const p = await runNative(cfg, v, u, 1000 + s), e = F.prepare(p.game, p.spec).exact(p.game); return { v, u, s, ex: e.exploitability, val: e.values[0], ms: p.trainMs, missing: e.missingRows }; });
    const rs = await pool(tasks, jobs);
    for (const v of variants) { g.results[v] = counts.map((u) => { const r = rs.filter((x) => x.v === v && x.u === u); return { updates: u, exploitabilityBB: stat(r.map((x) => x.ex)), exploitabilityPctPot: +(stat(r.map((x) => x.ex)).mean / cfg.common * 100).toFixed(3), seat0ValueBB: stat(r.map((x) => x.val)), trainMs: stat(r.map((x) => x.ms)), missingRows: r.map((x) => x.missing) }; }); }
    const last = counts[counts.length - 1], ranking = variants.map((v) => ({ variant: v, meanAtMax: g.results[v].find((x) => x.updates === last).exploitabilityBB.mean, ci: g.results[v].find((x) => x.updates === last).exploitabilityBB.ci95 })).sort((a, b) => a.meanAtMax - b.meanAtMax);
    g.rankingAtMaxUpdates = { updates: last, ranking };
    // a variant is "better than the 0.30 default" at a count only when its 95% CI upper bound is below the default's lower bound
    g.significantlyBetterThanDefault = {}; for (const v of variants) if (v !== 'mccfr-linear') g.significantlyBetterThanDefault[v] = counts.map((u) => { const a = g.results[v].find((x) => x.updates === u).exploitabilityBB, b = g.results['mccfr-linear'] && g.results['mccfr-linear'].find((x) => x.updates === u).exploitabilityBB; return { updates: u, better: !!(a.ci95 && b && b.ci95 && a.ci95[1] < b.ci95[0]), worse: !!(a.ci95 && b && b.ci95 && a.ci95[0] > b.ci95[1]), ratioOfMeans: b ? +(a.mean / b.mean).toFixed(3) : null }; });
    doc.games[name] = g;
    process.stderr.write(name + ': ' + ranking.map((r) => r.variant + ' ' + r.meanAtMax.toFixed(4)).join(' | ') + ' @' + last + '\n');
    fs.writeFileSync(args.out || 'training-variants.json', JSON.stringify(doc, null, 1));
  }
  doc.elapsedMs = Date.now() - t0; fs.writeFileSync(args.out || 'training-variants.json', JSON.stringify(doc, null, 1)); fs.rmSync(work, { recursive: true, force: true });
})().catch((e) => { console.error(e); process.exit(1); });
