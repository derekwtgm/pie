'use strict';
/* 0.33 preflop solver modes A/B/B169/C and Mode D comparison (reports/0.33-preflop-modes.json).
 * For every (mode, seed, updates): train with the native EightMax engine (or continue the largest shorter state of the same mode and
 * seed - bit-identical to an uninterrupted run, tested in 0.32), then record:
 *   resources   wall time, updates/s, engine peak RSS (mwcli processPeakRssMiB), state bytes, EMZ1 checkpoint bytes (optional)
 *   anatomy     rows and bytes per street (tools/state-anatomy-033.cjs)
 *   coverage    per position: preflop decision states with rows, mean class coverage, first-in classes stored (exact counts)
 *   strategy    first-in action frequencies per position
 *   gains       optional sampled one-decision deviation gain at every first-in node (mwcli --gain; LOWER-BOUND ESTIMATE, 95 % CI)
 * Comparisons at equal updates: same mode / different seeds (sampling noise) and same seed / different modes (model difference), as
 * mean total-variation distance per first-in node. A model difference is only meaningful where it exceeds the seed-to-seed distance.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/preflop-modes-033.cjs --modes=A,B,B169,C --seeds=8,108 --updates=2000000[,8000000]
 *        [--cache=DIR] [--budgetMiB=12000] [--gains] [--gainModes=A@8,B169@8] [--gainUpdates=N] [--gainSamples=2000] [--emz] [--stacks=25] [--out=FILE] */
const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), cp = require('node:child_process');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), T = require('./studies.cjs'), PC = require('../src/preflop-compact.js'), PR = require('../src/preflop-research.js'), N = require('./native-training.cjs'), AN = require('./state-anatomy-033.cjs');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const cli = process.env.EIGHTMAX_TEST_CLI; if (!cli) { console.error('EIGHTMAX_TEST_CLI is required'); process.exit(2); }
const modes = String(args.modes || 'A,B169').split(','), seeds = String(args.seeds || '8').split(',').map(Number), counts = String(args.updates || '2000000').split(',').map(Number);
const cache = args.cache || path.join(os.tmpdir(), 'em-preflop-033'), stack = +(args.stacks || 25); fs.mkdirSync(cache, { recursive: true });
const baseOf = (seed) => ({ ...T.PREFLOP8_LINKED, stacks: Array(8).fill(stack), privateSeed: seed });
const firstIn = PR.firstInPaths(A.prepare(EM, { config: baseOf(seeds[0]), iterations: 1 }));

(async () => {
  const doc = { format: 'eightmax-preflop-modes', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(),
    machine: { cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, totalMemBytes: os.totalmem(), node: process.version, platform: process.platform }, engine: 'EightMax 5.1 mwcli (unchanged; single-thread shared action stream)',
    modes: Object.fromEntries(modes.map((m) => [m, PC.gameDefinition(m, baseOf(seeds[0]))])),
    classifications: { resources: 'measured on this machine', coverage: 'exact counts from the state file', distances: 'exact between two stored strategies; NOT accuracy (8-player equilibria need not be unique)', gains: 'sampled estimate of a lower bound (one-decision deviation at the first-in node, later play follows the same study and the same continuation model)', exploitability: 'unavailable for the eight-player game (never reported as 0)' },
    runs: [], comparisons: [] };
  const save = () => { if (args.out) fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); };
  const reads = new Map();
  for (const mode of modes) for (const seed of seeds) {
    const { spec } = PC.specFor(mode, baseOf(seed), EM, A), name = 'pf033-' + mode + '-s' + seed + '-b' + stack, specFile = path.join(cache, name + '.spec.json'); fs.writeFileSync(specFile, JSON.stringify(spec));
    for (const updates of counts) {
      const state = path.join(cache, name + '-' + updates + '.state'), metaFile = state + '.meta.json'; let meta = null;
      if (fs.existsSync(state) && fs.existsSync(metaFile)) meta = JSON.parse(fs.readFileSync(metaFile, 'utf8'));
      else {
        let from = null, best = 0; for (const f of fs.readdirSync(cache)) { const m = new RegExp('^' + name + '-(\\d+)\\.state$').exec(f); if (m && +m[1] < updates && +m[1] > best && fs.existsSync(path.join(cache, f + '.meta.json'))) { best = +m[1]; from = path.join(cache, f); } }
        process.stderr.write(mode + ' seed ' + seed + ': training to ' + updates + (from ? ' (continuing ' + best + ')' : '') + '\n');
        try { const r = await N.trainNative({ cli, specFile, updates, budgetMiB: +(args.budgetMiB || 12000), threads: 1, outFile: state, resumeFrom: from, timeoutMs: +(args.timeoutMs || 6 * 3600000) });
          meta = { updates: r.info.iterations, requested: updates, status: r.run.status, continuedFrom: from ? best : 0, wallMs: r.wallMs, segmentUpdates: updates - best, updatesPerSecond: +((updates - best) / (r.wallMs / 1000)).toFixed(0), peakRssMiB: r.info.processPeakRssMiB, tableMiB: r.info.tableMiB, rows: r.info.rows, states: r.info.states, stateBytes: r.bytes, sha256: r.sha256 };
          fs.writeFileSync(metaFile, JSON.stringify(meta)); } catch (e) { doc.runs.push({ mode, seed, updates, error: e.message, code: e.code }); save(); continue; }
      }
      const run = { mode, seed, updates: meta.updates, stackBB: stack, training: meta, anatomy: null, coverage: null, firstIn: [] };
      try { const a = AN.anatomy(state); run.anatomy = { postflopRowShare: a.postflopRowShare, streets: Object.fromEntries(Object.entries(a.streets).map(([k, v]) => [k, { states: v.states, rows: v.rows, diskBytes: v.diskBytes, singleRowContextShare: v.singleRowContextShare }])) }; } catch (e) { run.anatomy = { error: e.message }; }
      if (args.emz) { const z = state + '.emz', t0 = Date.now(), r = cp.spawnSync(cli, ['--compress', state, z, '6'], { encoding: 'utf8' }); run.checkpoint = r.status === 0 ? { emzBytes: fs.statSync(z).size, ratio: +(fs.statSync(z).size / fs.statSync(state).size).toFixed(3), ms: Date.now() - t0 } : { error: String(r.stderr).slice(-200) }; fs.rmSync(z, { force: true }); }
      const rd = PC.readPreflop(state, spec, EM, { keepPaths: firstIn.map((f) => 'r' + f.path.join('')) });   // class strategies only where they are compared reads.set(mode + '|' + seed + '|' + updates, rd);
      run.coverage = { preflopRows: rd.preflopRows, preflopStatesWithRows: rd.states.size, byPosition: PC.positionCoverage(rd, firstIn, EM) };
      run.firstIn = firstIn.map((f) => ({ position: f.position, path: 'r' + f.path.join(''), ...(PC.nodeFrequencies(rd, 'r' + f.path.join(''), f.labels, EM) || { missing: true }) }));
      if (args.gains && (!args.gainModes || String(args.gainModes).split(',').includes(mode + '@' + seed) || String(args.gainModes).split(',').includes(mode)) && (!args.gainUpdates || +args.gainUpdates === updates)) run.gains = firstIn.map((f) => { const gf = state + '.gain-' + f.position + '-' + (+(args.gainSamples || 2000)) + '.json'; let g = null; try { g = JSON.parse(fs.readFileSync(gf, 'utf8')); } catch (e) { g = null; } if (!g) { g = PR.deviationGain(cli, specFile, state, f.seat, f.path, { samples: +(args.gainSamples || 2000), seed: 7, memoryMiB: +(args.gainMemoryMiB || 8000) }); if (!g.error) fs.writeFileSync(gf, JSON.stringify(g)); } process.stderr.write('  ' + mode + ' ' + f.position + ' gain ' + (g.gainBB ? JSON.stringify(g.gainBB) : g.error || g.reason) + '\n'); return g; });
      doc.runs.push(run); save();
      process.stderr.write(mode + ' seed ' + seed + ' ' + meta.updates + ': ' + meta.stateBytes + ' B state, peak ' + meta.peakRssMiB + ' MiB, ' + meta.updatesPerSecond + ' upd/s\n');
    }
  }
  for (const updates of counts) {
    for (const mode of modes) for (let i = 0; i < seeds.length; i++) for (let j = i + 1; j < seeds.length; j++) { const a = reads.get(mode + '|' + seeds[i] + '|' + updates), b = reads.get(mode + '|' + seeds[j] + '|' + updates); if (a && b) doc.comparisons.push({ kind: 'seed-noise', mode, seeds: [seeds[i], seeds[j]], updates, nodes: PC.compareReads(a, b, firstIn, EM) }); }
    for (const seed of seeds) for (let i = 0; i < modes.length; i++) for (let j = i + 1; j < modes.length; j++) { const a = reads.get(modes[i] + '|' + seed + '|' + updates), b = reads.get(modes[j] + '|' + seed + '|' + updates); if (a && b) doc.comparisons.push({ kind: 'model-difference', modes: [modes[i], modes[j]], seed, updates, nodes: PC.compareReads(a, b, firstIn, EM) }); }
  }
  save(); if (!args.out) console.log(JSON.stringify(doc, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
