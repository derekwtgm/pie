'use strict';
/* Worker thread of src/flop-solver.js solveParallel(): owns the turn cards with index % W === w (and their river subtrees), rebuilds
 * the identical game from the study config, and answers { cmd: 'pass' } with its partial flop-regret increments. Worker 0 also counts
 * flop-street terminals and accumulates the flop average strategy, so each is counted exactly once. */
const { parentPort, workerData } = require('node:worker_threads');
const path = require('node:path');
const A = require('./study-adapter.js'), EM = require(path.join(__dirname, '..', 'tests', 'load-solver.cjs')), FS = require('./flop-solver.js');
const { config, w, W } = workerData, prep = A.prepare(EM, { config, iterations: 1 });
let order = null;
const core = FS.createCore(prep.game, prep.spec, { flopTerminals: w === 0, flopAverage: w === 0, ownTurn: (c) => order.get(c) % W === w });
order = new Map(core.turnCards.map((c, i) => [c, i]));
parentPort.on('message', (m) => {
  try {
    if (m.cmd === 'pass') {
      core.setFlopRegrets(m.flop); core.pass(m.p, m.t);
      const incs = []; for (const d of core.flopNodes) if (d.seat === m.p) incs.push([d.id, core.flopInc.get(d.id)]);
      parentPort.postMessage({ seq: m.seq, incs });
    } else if (m.cmd === 'export') {
      // flop tables: only worker 0's flop AVERAGES are meaningful; flop regrets live in the coordinator
      const parts = core.exportTables().filter(([id]) => w === 0 || core.nodes[id].street !== 3);
      parentPort.postMessage({ seq: m.seq, parts });
    } else if (m.cmd === 'import') {
      const mine = m.parts.filter(([id, c]) => { const d = core.nodes[id]; if (d.street === 3) return w === 0; const t = d.street === 4 ? c : Math.floor(c / 52); return order.get(t) % W === w; });
      core.importTables(mine); parentPort.postMessage({ seq: m.seq });
    }
  } catch (e) { parentPort.postMessage({ seq: m.seq, error: e.message }); }
});
