/* EightMax Test Workbench 0.33 - "Solver research" panel: preflop solver modes, flop solver, multiway validation, check-down calibration,
   coverage and performance. Reads GET /api/research/summary (v033 block) through the desktop host; buttons start the release's own
   launchers (POST /api/desktop/launch). Without the host it shows the release measurements embedded at build time, labelled as such. */
(function(){
'use strict';
const $=id=>document.getElementById(id),V=window.WorkbenchResearch033View;
if(!V||!$('r33-panel'))return;
function token(){const d=window.WorkbenchDesktop&&window.WorkbenchDesktop.fromPage&&window.WorkbenchDesktop.fromPage(window);return d&&d.secret?d.secret:null;}
async function host(method,path,body){const t=token();if(!t){const e=Error('not connected');e.code='no-desktop-host';throw e;}
 const r=await fetch('http://127.0.0.1:48713'+path,{method,headers:{'X-EightMax-Session':t,'X-EightMax-Step':'dashboard-research033',...(body===undefined?{}:{'Content-Type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body),credentials:'omit',cache:'no-store'});
 let j=null;try{j=await r.json();}catch(e){}if(!r.ok){const e=Error((j&&j.error)||('HTTP '+r.status));e.code=j&&j.code;throw e;}return j;}
function el(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function say(text,bad){const s=$('r33-status');if(!s)return;s.textContent=text;s.classList.toggle('bad',!!bad);}
function table(id,cols,rows){const t=$(id);if(!t)return;t.textContent='';const h=el('tr');for(const c of cols)h.appendChild(el('th',c[0]));t.appendChild(h);for(const r of rows){const tr=el('tr');for(const c of cols)tr.appendChild(el('td',String(r[c[1]]===undefined?'—':r[c[1]])));t.appendChild(tr);}}
function text(id,t){const e=$(id);if(e)e.textContent=t||'';}
function render(sum){
 const v=(sum&&sum.v033)||{};
 const p=V.preflopModesView(v.preflopModes);text('r33-pf-head',p.headline);text('r33-pf-explain',(p.explain||[]).join(' ')+' '+(p.fullGame||''));
 table('r33-pf-rows',[['Study','study'],['Accuracy class','accuracy'],['Peak RAM','memory'],['State','state'],['Checkpoint','checkpoint'],['Updates/s','speed'],['Postflop rows','postflop']],p.rows);
 text('r33-pf-pos-head',p.positionsOf?'Positions · '+p.positionsOf:'');table('r33-pf-pos',[['Position','position'],['States with rows','states'],['Class coverage','coverage'],['First-in classes','firstIn'],['Missing','missing']],p.positions);
 table('r33-pf-gains',[['Study','study'],['Position (first in)','position'],['Deviation gain (lower bound)','gain'],['95% interval','ci'],['Verdict','verdict']],p.gains);
 table('r33-pf-cmp',[['Comparison','kind'],['Updates','updates'],['Mean strategy distance by position','mean']],p.comparisons);
 const c=V.calibrationView(v.calibration);text('r33-cal-head',c.headline);table('r33-cal-rows',[['Flop','flop'],['Player','player'],['Equilibrium value','equilibrium'],['Check-down value','checkdown'],['Error','error'],['Realised','realisation']],c.rows);
 const f=V.flopView(v.flopSolver);text('r33-flop-head',f.headline);table('r33-flop-rows',[['Configuration','config'],['Result (independent evaluator)','result'],['Continuation','continuation'],['Status','status']],f.rows);
 const m=V.multiwayView(v.multiway);text('r33-mw-head',m.headline);text('r33-mw-meaning',m.meaning||'');table('r33-mw-refs',[['Reference game','game'],['Result','result']],m.refs);table('r33-mw-cross',[['Updates','updates'],['Independent NashConv','independent'],['Engine NashConv','engine'],['Agreement','agree'],['Status','status']],m.cross);
 const cv=V.coverageView(v.coverage);text('r33-cov-head',cv.headline);table('r33-cov-rows',[['Run','name'],['Decisions','decisions'],['Exact','exact'],['Approximate','approximate'],['On demand','onDemand'],['Unavailable','unavailable'],['Gate refusals','refused']],cv.rows);
 const pf=V.performanceView(v.performance);text('r33-perf-head',pf.headline);table('r33-perf-rows',[['Workload','workload'],['Tables','tables'],['Decisions/s','decisionsPerSecond'],['P95','p95'],['Peak RAM','peak'],['Errors','errors']],pf.rows);
 const mc=v.machine;text('r33-machine',mc?'This computer: '+mc.cpus+' logical CPUs, '+(mc.freeMemBytes/1073741824).toFixed(1)+' of '+(mc.totalMemBytes/1073741824).toFixed(1)+' GiB free.':'');
}
async function refresh(){say('Reading research results…');try{render(await host('GET','/api/research/summary'));say('Results read from this computer. Nothing was trained or changed.');}
 catch(e){const emb=window.EIGHTMAX_RESEARCH_SUMMARY;if(emb){render(emb);say((e.code==='no-desktop-host'?'Not connected to the desktop host: ':'Could not read this computer\'s results ('+e.message+'): ')+'showing the RELEASE measurements from the build machine.',e.code!=='no-desktop-host');}else say('Not connected to the desktop host. Start with START-DESKTOP.cmd.',true);}}
async function launch(tool,label){say('Starting '+label+'…');try{const r=await host('POST','/api/desktop/launch',{tool});say(r.message+' It runs in its own window; press Refresh afterwards.');}catch(e){say(e.code==='no-desktop-host'?'Double-click '+label+' in the release folder (this page is not connected to the desktop host).':'Could not start '+label+': '+e.message,true);}}
const btn=(id,tool,label)=>{const b=$(id);if(b)b.addEventListener('click',()=>launch(tool,label));};
btn('r33-run-modes','preflop-modes','RUN-PREFLOP-MODES.cmd');btn('r33-run-flop','flop-solver-check','RUN-FLOP-SOLVER-CHECK.cmd');btn('r33-run-mw','multiway-validation','RUN-MULTIWAY-VALIDATION.cmd');btn('r33-run-summary','research-summary','REFRESH-RESEARCH-SUMMARY.cmd');
btn('r33-train','library-precompute','PRECOMPUTE-STRATEGIES.cmd');btn('r33-continue','library-continue','CONTINUE-TRAINING.cmd');btn('r33-validate','library-validate','VALIDATE-STRATEGIES.cmd');btn('r33-precompute','library-precompute-common','PRECOMPUTE-COMMON-HANDS.cmd');
btn('r33-ranges','view-ranges','VIEW-OPPONENT-RANGES.cmd');btn('r33-hardware','hardware-check','RUN-HARDWARE-CHECK.cmd');btn('r33-selftest','self-test','RUN-SELF-TEST.cmd');btn('r33-collect','collect-results','COLLECT-TEST-RESULTS.cmd');
const r=$('r33-refresh');if(r)r.addEventListener('click',refresh);
const nav=$('r33-nav');if(nav)nav.addEventListener('click',()=>{$('r33-panel').hidden=false;$('r33-panel').scrollIntoView({block:'start'});refresh();});
const close=$('r33-close');if(close)close.addEventListener('click',()=>{$('r33-panel').hidden=true;});
})();
