'use strict';
/* EightMax Test Workbench 0.31: candidate strategy abstractions (state mappings) and their validation.
 *
 * Exact matching stays the default. A mapping sends a target situation T (the table) to a source situation S = map(T) whose stored
 * strategy is then played in T, action by action along the same tree path. Every mapping below is defined precisely, lists what it
 * preserves and what it loses, and is VALIDATED by exact measurement on heads-up river reference games:
 *   EV loss(T) = exploitability in T of the translated S-strategy  (exact, src/fast-river.js), compared with T's own solution.
 * A mapping is accepted only if the tree shapes match and the p95 EV loss over the reference set is within its limit; accepted
 * mappings may be ENABLED by the user for decisions, and every decision that uses one is labelled approximate. Mappings for which
 * no exact evaluation exists (flop/turn street snapshots, multiway) are never accepted here.
 */
const MAPPINGS = Object.freeze({
  'suit-isomorphism': { kind: 'exact', definition: 'Relabel the four suits by a permutation pi (applied to board and hole cards). All ranges are suit-symmetric.', preserves: 'everything (the games are identical up to relabelling)', loses: 'nothing', map: (t) => ({ ...t }), exact: true },
  'chip-scale': { kind: 'approximate', definition: 'Scale pot and every stack by k = 10 / pot (pot normalised to 10 bb). Bet sizes are pot fractions, so the scaled tree has the same shape and the same SPR.', preserves: 'SPR, pot-relative sizes, board, ranges, tree shape', loses: 'absolute chip amounts (minimum-bet and rounding effects)', map: (t) => { const k = 10 / t.pot; return { ...t, pot: 10, stacks: t.stacks.map((s) => +(s * k).toFixed(2)) }; } },
  'stack-bucket-2.5': { kind: 'approximate', definition: 'Round every stack behind to the nearest multiple of 2.5 bb (pot unchanged).', preserves: 'board, ranges, pot, tree menu', loses: 'up to 1.25 bb of each stack; the SPR changes', map: (t) => ({ ...t, stacks: t.stacks.map((s) => Math.max(2.5, Math.round(s / 2.5) * 2.5)) }) },
  'stack-bucket-5': { kind: 'approximate', definition: 'Round every stack behind to the nearest multiple of 5 bb (pot unchanged).', preserves: 'board, ranges, pot, tree menu', loses: 'up to 2.5 bb of each stack; the SPR changes', map: (t) => ({ ...t, stacks: t.stacks.map((s) => Math.max(5, Math.round(s / 5) * 5)) }) },
  'pot-bucket-10pct': { kind: 'approximate', definition: 'Round the pot to the nearest point of the geometric grid 1.1^k bb (stacks unchanged).', preserves: 'board, ranges, stacks, tree menu', loses: 'up to ~5% of the pot; the SPR changes', map: (t) => ({ ...t, pot: +Math.pow(1.1, Math.round(Math.log(t.pot) / Math.log(1.1))).toFixed(2) }) },
  'spr-bucket': { kind: 'approximate', definition: 'Keep the pot; set every stack so that the SPR equals the nearest of {0.5,1,1.5,2,3,4,6,8,12} (relative stack differences kept).', preserves: 'board, ranges, pot, tree menu, which player is covered', loses: 'exact SPR (up to ~25%)', map: (t) => { const grid = [0.5, 1, 1.5, 2, 3, 4, 6, 8, 12], spr = Math.min(...t.stacks) / t.pot, g = grid.reduce((a, b) => (Math.abs(Math.log(b / spr)) < Math.abs(Math.log(a / spr)) ? b : a)), k = g / spr; return { ...t, stacks: t.stacks.map((s) => +(s * k).toFixed(2)) }; } },
  'river-blank-substitution': { kind: 'approximate', definition: 'Replace the river card by another rank of the same suit that also pairs nothing, completes no new flush or straight possibility, and lies between the same two board ranks.', preserves: 'flop and turn, river suit, board pairing / flush / straight structure', loses: 'exact river rank: kicker and some two-pair / straight-draw outcomes change', map: null },
});

/** Tree compatibility: same node paths, same action kinds at every decision node (sizes may differ). */
function treesCompatible(fa, fb) {
  const q = [[fa.tree.tree, fb.tree.tree]];
  while (q.length) { const [a, b] = q.shift(); if (a.kind !== b.kind || a.path !== b.path) return { ok: false, reason: 'node ' + a.path + ' differs' }; if (a.kind !== 'player') continue; if (a.k !== b.k || a.seat !== b.seat) return { ok: false, reason: 'menu at ' + a.path + ' has ' + a.k + ' vs ' + b.k + ' actions' };
    const kinds = (n) => n.labels.map((l) => l.split(' ')[0]).join('|'); if (kinds(a) !== kinds(b)) return { ok: false, reason: 'action kinds at ' + a.path + ' differ (' + a.labels.join('/') + ' vs ' + b.labels.join('/') + ')' }; for (let i = 0; i < a.k; i++) q.push([a.children[i], b.children[i]]); }
  return { ok: true };
}
/** Translated strategy accessor: the S strategy read for the same hand (same cards) at the same path in T. */
function translate(fT, fS, SS, cardMap) {
  const cm = cardMap || ((c) => c);
  const idx = fS.hands.map((H) => new Map(H.map((h, i) => [Math.min(h.a, h.b) * 64 + Math.max(h.a, h.b), i]))), byPath = new Map(); (function walk(n) { if (n.kind === 'player') { byPath.set(n.path, n); n.children.forEach(walk); } })(fS.tree.tree);
  return { get(node, seat, i) { const h = fT.hands[seat][i], a = cm(h.a), b = cm(h.b), j = idx[seat].get(Math.min(a, b) * 64 + Math.max(a, b)), ns = byPath.get(node.path); if (j === undefined || !ns) return new Float64Array(node.k).fill(1 / node.k); return SS.get(ns, seat, j); } };
}
function meanL1(f, S1, S2) { let s = 0, w = 0; const q = [f.tree.tree]; while (q.length) { const n = q.shift(); if (n.kind !== 'player') continue; for (let i = 0; i < f.hands[n.seat].length; i++) { const a = S1.get(n, n.seat, i), b = S2.get(n, n.seat, i); let d = 0; for (let k = 0; k < n.k; k++) d += Math.abs(a[k] - b[k]); s += f.hands[n.seat][i].w * d; w += f.hands[n.seat][i].w; } n.children.forEach((c) => q.push(c)); } return w ? s / w : 0; }

/**
 * Validate one (target, source) pair on a heads-up river. cfgT/cfgS: study configs. Returns the measurements.
 * o: EM, adapter, iterations (CFR+, default 600), target (stop early when exploitability <= target bb), cardMap (target card -> source card)
 */
function validatePair(cfgT, cfgS, o) {
  const A = o.adapter || require('./study-adapter.js'), EM = o.EM || require('../tests/load-solver.cjs'), F = require('./fast-river.js');
  const pT = A.prepare(EM, { config: cfgT, iterations: 1 }), pS = A.prepare(EM, { config: cfgS, iterations: 1 }), fT = F.prepare(pT.game, pT.spec), fS = F.prepare(pS.game, pS.spec);
  const compat = treesCompatible(fT, fS); if (!compat.ok) return { compatible: false, reason: compat.reason };
  const it = o.iterations || 600, solT = fT.cfrPlus(it, { every: 100, target: (o.target || 0.0002) * cfgT.common }), solS = fS.cfrPlus(it, { every: 100, target: (o.target || 0.0002) * cfgS.common });
  const tr = translate(fT, fS, solS.strategy, o.cardMap), e = fT.evaluate(tr);
  return { compatible: true, potBB: cfgT.common, exploitabilityOfTargetSolutionBB: solT.exploitability, exploitabilityOfTranslatedBB: e.exploitability, evLossPctPot: e.exploitability / cfgT.common * 100, actionL1VsTargetSolution: meanL1(fT, tr, solT.strategy), seat0ValueTarget: solT.values[0], seat0ValueTranslated: e.values[0] };
}

/** River blank substitution: returns a different river card meeting the definition, or null if none exists. */
function blankSubstitute(board) {
  const R = (c) => c >> 2, S = (c) => c & 3, [f1, f2, f3, tc, rv] = board, early = [f1, f2, f3, tc], ranks = early.map(R);
  const isBlank = (c) => { if (ranks.includes(R(c)) || early.includes(c)) return false; if (early.filter((x) => S(x) === S(c)).length >= 2) return false; const rs = new Set(ranks.concat(R(c))); for (let lo = -1; lo <= 8; lo++) { const need = [0, 1, 2, 3, 4].map((d) => (lo + d + 13) % 13); const cnt = need.filter((r) => rs.has(r)).length, cntEarly = need.filter((r) => ranks.includes(r)).length; if (cnt >= 3 && cntEarly < 3 && need.includes(R(c))) return false; } return true; };
  if (!isBlank(rv)) return null;
  const lower = ranks.filter((r) => r < R(rv)), upper = ranks.filter((r) => r > R(rv)), lo = lower.length ? Math.max(...lower) : -1, hi = upper.length ? Math.min(...upper) : 13;
  for (let r = lo + 1; r < hi; r++) { if (r === R(rv)) continue; const c = r * 4 + S(rv); if (isBlank(c)) return c; }
  return null;
}

module.exports = { MAPPINGS, treesCompatible, translate, meanL1, validatePair, blankSubstitute };
