'use strict';
/* EightMax Test Workbench 0.31: the library's opponent-range model (preflop line -> flop -> turn -> river).
 *
 * For each table and hand it keeps one weighted range per seat (src/range-engine.js):
 *   preflop  every seat's range is the preflop study's starting range conditioned on each of that seat's preflop actions
 *            (exact Bayes under "the player follows the stored preflop strategy"; class-pooled because suits are symmetric preflop)
 *   flop     street-start range = the preflop range (board cards are blocked per deal by the engine)
 *   turn     flop range conditioned on that seat's flop actions under the STORED flop study that produced the flop decisions
 *   river    turn range conditioned on the turn actions under the stored turn study
 * When the previous street's study is not available (no decision was made from the library on that street, or it was missing)
 * the range is carried forward UNCONDITIONED and the decision says so ("street-conditioning skipped").
 *
 * The text handed to the study is the weights scaled to a maximum of 1 and rounded to `quantum` (default 0.02); the rounding
 * error and the dropped mass are reported with the decision. A range whose unsupported share (combos for which the stored
 * strategy had no row and which therefore kept their prior weight) exceeds `maxUnsupportedShare` is "insufficiently supported":
 * the model then uses the configured fallback ('any-two', labelled as an assumption) or makes the decision unavailable.
 */
const RE = require('./range-engine.js'), ST = require('./solver-tree.js');

const MODEL_PREFLOP = 'preflop-line-v1', MODEL_STREET = 'street-conditioned-v1';

class LibraryRangeModel {
  /** o: preflopSource (ST.PreflopTreeSource), EM, quantum, maxUnsupportedShare, fallback ('any-two'|'unavailable'), preflopValidated, maxHands */
  constructor(o) {
    if (!o || !o.preflopSource) throw new Error('The derived range model needs the preflop study source');
    this.o = { quantum: 0.02, maxUnsupportedShare: 0.25, fallback: 'any-two', preflopValidated: false, maxHands: 256, conditionPostflop: true, ...o };
    this.EM = o.EM || o.preflopSource.EM; this.trackers = new Map();
    this.stats = { built: 0, preflopDerived: 0, streetConditioned: 0, conditioningSkipped: 0, insufficient: 0, unknown: 0, fallbacks: 0, unavailable: 0 };
  }
  _tracker(req) {
    const k = req.table + '|' + req.hand; let t = this.trackers.get(k);
    if (!t) { t = new RE.RangeTracker(req.table, req.hand); t.studies = {}; this.trackers.set(k, t); if (this.trackers.size > this.o.maxHands) this.trackers.delete(this.trackers.keys().next().value); }
    return t;
  }
  _preflopApplies(req) {
    const src = this.o.preflopSource, b = req.blinds;
    if (b && (b.sb !== 50 || b.bb !== 100 || b.ante !== 10)) return 'The preflop study was trained for SB 0.5 / BB 1 / ante 0.1 BB; this table uses other stakes';
    if (!Array.isArray(req.stacks) || !req.stacks.every((s) => s === src.stack)) return 'Starting stacks differ from the preflop study (' + src.stack / 100 + ' BB each)';
    return null;
  }
  /** Ranges for the live players of this street start. Returns { texts, name, provenance, perSeat, warnings, unavailable?, reason? }. */
  rangesFor(req, ctx) {
    this.stats.built++; const t = this._tracker(req), warnings = [];
    if (!t.ranges) {
      const why = this._preflopApplies(req);
      const r = why ? { ranges: new Map(ctx.live.map((s) => [s, RE.WeightedRange.unknown(why)])), status: 'unknown', reason: why } : RE.preflopRanges(this.o.preflopSource, req, { ST, strategyValidated: this.o.preflopValidated });
      t.startPreflop(r); if (r.status === 'ok') this.stats.preflopDerived++;
    }
    // continuity: condition on every earlier postflop street that has a stored study and has not been applied yet
    const order = ['flop', 'turn', 'river'], upto = order.indexOf(req.street); let conditionedAll = true;
    for (let i = 0; i < upto; i++) {
      const street = order[i]; if (t.conditionedStreets.includes(street)) continue;
      const st = t.studies[street], acts = req.actions.filter((a) => a.street === street);
      if (!this.o.conditionPostflop || !st) { conditionedAll = false; if (!t.notes.includes('skip:' + street)) { t.notes.push('skip:' + street); warnings.push('Ranges were NOT updated for the ' + street + ' betting: no stored ' + street + ' strategy was used for this hand (carried forward unconditioned)'); this.stats.conditioningSkipped++; } continue; }
      const work = new Map(); for (const s of st.seatOrder) work.set(s, t.ranges.get(s) ? t.ranges.get(s).clone() : RE.WeightedRange.unknown('untracked seat'));
      const res = RE.conditionOnStreet(work, st.game, st.spec, st.seatOrder, acts, { street, perm: st.isomorphismApplied ? st.perm : null, provenance: st.validated ? RE.PROVENANCE.VALIDATED : RE.PROVENANCE.APPROXIMATE });
      t.applyStreet(street, res, work); if (res.status === 'ok') this.stats.streetConditioned++; else { conditionedAll = false; warnings.push('Ranges not updated for the ' + street + ': ' + res.reason); }
    }
    const perSeat = [], texts = []; let provenance = RE.PROVENANCE.VALIDATED, bad = null;
    for (const s of ctx.live) {
      const r = t.ranges && t.ranges.get(s); const v = r ? r.validate() : { valid: false, problems: ['No range for seat ' + s] };
      const total = r ? r.total() : 0, unsupported = r ? r.unsupported.reduce((a, u) => a + u.massShare, 0) : 1;
      let support = !r || r.provenance === RE.PROVENANCE.UNKNOWN ? 'unknown' : !v.valid ? 'invalid' : unsupported > this.o.maxUnsupportedShare ? 'insufficient' : unsupported > 0 ? 'partially-supported' : 'supported';
      if (support === 'invalid' || support === 'unknown' || support === 'insufficient') bad = bad || { seat: s, support, reason: (v.problems || []).join('; ') || ('unsupported share ' + (unsupported * 100).toFixed(1) + '% exceeds ' + this.o.maxUnsupportedShare * 100 + '%') };
      const st = r && total > 0 && v.valid ? r.toStudyText(this.EM, { quantum: this.o.quantum }) : null;
      perSeat.push({ seat: s, support, provenance: r ? r.provenance : RE.PROVENANCE.UNKNOWN, combos: r ? r.combos() : 0, unsupportedShare: +unsupported.toFixed(4), roundingDroppedShare: st ? st.droppedMassShare : null, roundingMaxError: st ? st.maxAbsWeightError : null, events: r ? r.events.length : 0 });
      texts.push(st ? st.text : null); if (r) provenance = RE.worse(provenance, r.provenance);
    }
    if (bad) {
      if (bad.support === 'insufficient') this.stats.insufficient++; else this.stats.unknown++;
      if (this.o.fallback === 'unavailable') { this.stats.unavailable++; return { unavailable: true, code: 'range-' + bad.support, reason: 'Opponent range for seat ' + bad.seat + ' is ' + bad.support + ': ' + bad.reason, perSeat }; }
      this.stats.fallbacks++;
      return { texts: ctx.live.map(() => 'random'), name: 'any-two-cards-v1', provenance: RE.PROVENANCE.ANY_TWO, perSeat, fallback: true, warnings: warnings.concat(['FALLBACK: derived range for seat ' + bad.seat + ' is ' + bad.support + ' (' + bad.reason + '); every player is modelled with any two cards (an assumption)']) };
    }
    const name = (t.conditionedStreets.length && conditionedAll && upto > 0 ? MODEL_STREET : MODEL_PREFLOP) + '[q=' + this.o.quantum + ']';
    return { texts, name, provenance, perSeat, warnings };
  }
  /** Remember the study used on this street (needed to condition the next street's ranges). */
  noteStudy(req, info) { const t = this._tracker(req); if (!t.studies[req.street]) t.studies[req.street] = info; }
  /** Range display for a table/hand (viewer = hero: hero's own cards and the board are removed from the opponents' ranges). */
  view(table, hand, knownCards = [], board = []) { const t = this.trackers.get(table + '|' + hand); return t ? t.view(knownCards, board) : null; }
  info() { return { ...this.stats, trackedHands: this.trackers.size, quantum: this.o.quantum, maxUnsupportedShare: this.o.maxUnsupportedShare, fallback: this.o.fallback }; }
}

module.exports = { LibraryRangeModel, MODEL_PREFLOP, MODEL_STREET };
