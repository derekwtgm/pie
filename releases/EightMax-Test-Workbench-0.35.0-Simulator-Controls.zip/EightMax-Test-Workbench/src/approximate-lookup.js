'use strict';
/* EightMax Test Workbench 0.32: runtime use of the two abstraction mappings that passed the 0.31 validation
 * (reports/0.31-abstraction-validation.json; re-measured on independent examples in reports/0.32-abstraction-validation.json):
 *
 *   chip-scale        T and S differ only by a common factor k on the pot and every stack (same board, ranges, players, tree
 *                     menu, range model, training policy). Bet sizes are pot fractions, so the trees have the same shape and SPR; in
 *                     chip EV every utility scales by k, so exploitability in % of the pot is unchanged. Measured EV loss p95 0.026% (0.31)
 *                     and 0.052% (0.32, new examples) of the pot (= reference-solver precision). Refused when a mapped wager would fall below 1 BB in either game
 *                     (minimum-bet rules do not scale) or when the stacks are not proportional to within half a chip.
 *   pot-bucket-10pct  S = T with the pot rounded to the geometric grid 1.1^n (stacks unchanged). Measured EV loss p95 0.46% (0.31)
 *                     and 0.73% (0.32, new examples; max 0.78%) of the pot on heads-up rivers - within the 1% limit, but not negligible. Used only at the first decision of a street or after checks (no wager
 *                     whose size would have to be translated), heads-up rivers only (the only validated scope).
 *
 * Both are OFF by default (policy 'exact'). They are used only when the caller passes an explicit approximation policy, and every
 * decision made through one is labelled: strategySource 'library-approximate', approximation {mapping, factor, sourceFingerprint,
 * validatedErrorP95PctPot}, a warning, and exactState false. Never counted as an exact library hit.
 */
const SID = require('./strategy-identity.js');
const VALIDATED = Object.freeze({
  'chip-scale': Object.freeze({ evLossP95PctPot: 0.0521, scope: 'heads-up rivers: 0.31 (30 pairs, p95 0.026%) and 0.32 independent re-measurement (30 new pairs, p95 0.052%); the larger value is stated', streets: ['river'], note: 'scale-invariant in theory on every street (chip EV, pot-fraction sizes); enabled only on rivers, the scope that was MEASURED; the runtime refuses any case where the trees are not proportional' }),
  'pot-bucket-10pct': Object.freeze({ evLossP95PctPot: 0.729, scope: 'heads-up rivers only: 0.31 (30 pairs, p95 0.46%) and 0.32 independent re-measurement (30 new pairs, p95 0.73%, max 0.78%); the larger value is stated', streets: ['river'], players: 2 }),
});
const POLICIES = Object.freeze({ exact: [], 'chip-scale': ['chip-scale'], 'validated-approximations': ['chip-scale', 'pot-bucket-10pct'] });
const potGrid = (p) => +Math.pow(1.1, Math.round(Math.log(p) / Math.log(1.1))).toFixed(2);

/** Scale-invariant key: identity with the pot normalised to 1 and stacks expressed in pots. */
function scaleKey(id) {
  if (!id || id.kind !== 'postflop-street-start') return null;
  const c = JSON.parse(JSON.stringify(id)), pot = id.potBB; c.potBB = 1; c.stacksBehindBB = id.stacksBehindBB.map((s) => +(s / pot).toFixed(4)); delete c.effectiveStackBB; c.spr = +(id.effectiveStackBB / pot).toFixed(4); delete c.rules.blinds;
  return SID.sha256Hex('scale:' + SID.canonical(c));
}

/** Index of stored records by scale class (built lazily from record headers; refreshed when the library index generation changes). */
class ScaleIndex {
  constructor(lib) { this.lib = lib; this.map = new Map(); this.gen = -1; this.identities = new Map(); }
  _refresh() {
    this.lib._loadIndex(); const g = this.lib.index.generation || 0; if (g === this.gen) return; this.gen = g;
    const L = require('./strategy-library.js'), fs = require('node:fs');
    for (const fp of Object.keys(this.lib.index.records)) { if (this.identities.has(fp)) continue; try { const rec = L.decodeRecord(fs.readFileSync(this.lib.file(fp)), fp); this.identities.set(fp, rec.header.identity); const k = scaleKey(rec.header.identity); if (k) { if (!this.map.has(k)) this.map.set(k, []); this.map.get(k).push(fp); } } catch (e) { /* unreadable records are refused by get() anyway */ } }
  }
  candidates(identity) { this._refresh(); return (this.map.get(scaleKey(identity)) || []).map((fp) => ({ fingerprint: fp, identity: this.identities.get(fp) })); }
}

/** Multiply every chip quantity of a decision request by f (pot, bets, stacks, legal limits, recorded amounts). */
function scaleRequest(req, f) {
  const s = (x) => (Number.isFinite(x) ? x * f : x);
  return { ...req, pot: s(req.pot), currentBet: s(req.currentBet), toCall: s(req.toCall), stacks: req.stacks ? req.stacks.map(s) : req.stacks,
    seatsState: req.seatsState.map((p) => ({ ...p, stack: s(p.stack), bet: s(p.bet), total: s(p.total) })), streetStart: req.streetStart ? { ...req.streetStart, pot: s(req.streetStart.pot), behind: req.streetStart.behind.map(s) } : req.streetStart,
    actions: req.actions.map((a) => ({ ...a, amount: s(a.amount) })), legal: req.legal ? { ...req.legal, toCall: s(req.legal.toCall), callAmount: s(req.legal.callAmount), minRaiseTo: s(req.legal.minRaiseTo), maxRaiseTo: s(req.legal.maxRaiseTo) } : req.legal };
}

/** Map a decision taken in the source game back to the table: wager amounts divided by f and rounded to chips, legality re-checked. */
function mapBack(d, f, req, mapping, extra) {
  const lg = req.legal, out = { ...d, warnings: (d.warnings || []).slice(), assumptions: (d.assumptions || []).slice() };
  out.executable = d.executable.map((e) => (e && e.amount !== undefined ? { ...e, amount: Math.round(e.amount / f) } : e));
  const bad = []; out.executable.forEach((e, i) => { if (!e || !(d.probabilities[i] > 0)) return; if ((e.type === 'bet' || e.type === 'raise') && !(e.amount <= lg.maxRaiseTo && (e.amount >= lg.minRaiseTo || e.amount === lg.maxRaiseTo) && e.amount > req.currentBet && e.amount >= 100)) bad.push(i); });
  if (bad.length) return { ...d, status: 'unavailable', code: 'approximation-illegal', reason: 'Mapped wager(s) ' + bad.map((i) => out.executable[i].amount).join(', ') + ' are not legal at the table; approximation refused' };
  out.labels = d.labels.map((l) => l.replace(/([\d.]+)/, (m) => (+(Number(m) / f).toFixed(2)).toString()));
  out.exactState = false; out.strategySource = 'library-approximate'; out.approximation = { mapping, factor: f, validatedErrorP95PctPot: VALIDATED[mapping].evLossP95PctPot, validationScope: VALIDATED[mapping].scope, ...extra };
  out.warnings.push('APPROXIMATE (' + mapping + '): strategy of a stored situation mapped to this one (factor ' + (+f.toFixed(4)) + '); validated p95 EV error ' + VALIDATED[mapping].evLossP95PctPot + '% of the pot; not an exact solver result for this table');
  out.assumptions.push('Approximation ' + mapping + ' (' + VALIDATED[mapping].scope + ')');
  return out;
}

/** Can the given mapping be applied to this request/identity at all (scope checks)? */
function applicable(mapping, built, req) {
  const v = VALIDATED[mapping]; if (!v) return { ok: false, reason: 'Unknown or unvalidated mapping ' + mapping };
  if (!v.streets.includes(built.identity.street)) return { ok: false, reason: mapping + ' is not validated on the ' + built.identity.street };
  if (v.players && built.identity.players !== v.players) return { ok: false, reason: mapping + ' is validated for ' + v.players + ' players only' };
  if (mapping === 'pot-bucket-10pct' && req.actions.some((a) => a.street === req.street && a.type !== 'check')) return { ok: false, reason: 'pot-bucket mapping is used only before any wager on the street' };
  return { ok: true };
}

module.exports = { VALIDATED, POLICIES, potGrid, scaleKey, ScaleIndex, scaleRequest, mapBack, applicable };
