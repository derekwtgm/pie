/* EightMax Test Workbench 0.31 - "Strategy quality" and "Opponent ranges" panels, and the strategy-research buttons.
   Reads GET /api/library/quality and GET /api/ranges/latest through the desktop host and starts tools with POST /api/desktop/launch.
   The range calculator works in any browser (no host): it parses a range with EightMax's own parser and applies card removal. */
(function(){
'use strict';
const $=id=>document.getElementById(id),V=window.WorkbenchResearchView,RE=window.WorkbenchRangeEngine;
if(!V)return;
function token(){const d=window.WorkbenchDesktop&&window.WorkbenchDesktop.fromPage&&window.WorkbenchDesktop.fromPage(window);return d&&d.secret?d.secret:null;}
async function host(method,path,body){
 const t=token();if(!t){const e=Error('Open the workbench with START-DESKTOP.cmd to use this button.');e.code='no-desktop-host';throw e;}
 const r=await fetch('http://127.0.0.1:48713'+path,{method,headers:{'X-EightMax-Session':t,'X-EightMax-Step':'dashboard-research',...(body===undefined?{}:{'Content-Type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body),credentials:'omit',cache:'no-store'});
 let j=null;try{j=await r.json();}catch(e){}
 if(!r.ok){const e=Error((j&&j.error)||('HTTP '+r.status));e.code=j&&j.code;throw e;}
 return j;
}
function el(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function wire(id,fn){const b=$(id);if(b)b.addEventListener('click',fn);}
function say(id,text,bad){const s=$(id);if(!s)return;s.textContent=text;s.classList.toggle('bad',!!bad);}
async function launch(tool,label,statusId){say(statusId,'Starting '+label+'…');try{const r=await host('POST','/api/desktop/launch',{tool});say(statusId,r.message+' It runs in its own window; press Refresh afterwards.');}catch(e){say(statusId,e.code==='no-desktop-host'?'Double-click '+label+' in the release folder (this page is not connected to the desktop host).':'Could not start '+label+': '+e.message,true);}}
/* ---------- strategy quality ---------- */
function renderQuality(sum){
 const v=V.qualityView(sum);$('sq-headline').textContent=v.headline;$('sq-detail').textContent=v.detail;
 const c=$('sq-counts');c.textContent='';for(const [k,n,help] of v.counts){const d=el('div');d.title=help;d.appendChild(el('small',k));d.appendChild(el('b',String(n)));c.appendChild(d);}
 const tb=$('sq-rows');tb.textContent='';for(const r of v.rows){const tr=el('tr');for(const x of [r.situation,r.status,r.accuracy,r.players,r.rangeModel,r.solver,r.updates,r.checked]){tr.appendChild(el('td',String(x)));}tr.className='sq-'+r.statusKey;tr.title=r.why;tb.appendChild(tr);}
 $('sq-note').textContent=v.note||'';
}
async function refreshQuality(){say('sq-status','Reading the accuracy summary…');try{renderQuality(await host('GET','/api/library/quality'));say('sq-status','Summary read. Nothing was trained or changed.');}catch(e){say('sq-status',e.code==='no-desktop-host'?'Not connected to the desktop host. Start with START-DESKTOP.cmd, or double-click VALIDATE-STRATEGIES.cmd in the release folder.':'Could not read the summary: '+e.message,true);}}
/* ---------- opponent ranges ---------- */
let ranges=null;
function drawGrid(container,summary){
 const g=V.rangeGrid(summary),t=el('table','', 'rg-grid');
 for(let i=0;i<13;i++){const tr=el('tr');for(let j=0;j<13;j++){const td=el('td',g.label(i,j));const w=g.grid[i][j];td.style.background='rgba(46,125,50,'+(0.08+0.85*w).toFixed(3)+')';td.title=g.label(i,j)+': relative weight '+(w*100).toFixed(0)+'%';tr.appendChild(td);}t.appendChild(tr);}
 container.textContent='';container.appendChild(t);
}
function renderHand(i){
 const box=$('rg-seats');box.textContent='';if(!ranges||!ranges.hands||!ranges.hands[i]){box.appendChild(el('p','No hand recorded.','muted'));return;}
 const v=V.rangeHandView(ranges.hands[i]);$('rg-hand-title').textContent=v.title+' · ranges updated on: '+v.conditioned;
 for(const s of v.seats){const card=el('div','', 'rg-seat');card.appendChild(el('h4','Seat '+s.seat+' · '+s.combos+' possible hands'));card.appendChild(el('p',s.source,'muted'));
  if(s.unsupported>0)card.appendChild(el('p','Missing information: '+(s.unsupported*100).toFixed(1)+'% of this range had no stored strategy at some decision ('+s.missing+').','bad'));
  if(s.invalid)card.appendChild(el('p','Range problem: '+s.invalid,'bad'));
  const ul=el('ul');for(const h of s.history)ul.appendChild(el('li',h.street+': '+h.action+(h.probability!==null&&h.probability!==undefined?' (this action had probability '+(h.probability*100).toFixed(1)+'% under the stored strategy)':'')));card.appendChild(ul);
  const g=el('div');drawGrid(g,s.top.map(t=>({cls:t.cls,share:t.share})));card.appendChild(g);box.appendChild(card);}
 const n=$('rg-notes');n.textContent=v.notes.join(' · ');
}
async function refreshRanges(){say('rg-status','Reading the latest opponent ranges…');try{ranges=await host('GET','/api/ranges/latest');const sel=$('rg-hand');sel.textContent='';
  if(ranges.available===false){say('rg-status',ranges.message);return;}
  (ranges.hands||[]).forEach((h,i)=>{const o=el('option','Table '+h.table+', hand '+h.hand);o.value=String(i);sel.appendChild(o);});
  $('rg-disclosure').textContent=ranges.disclosure||'';renderHand(0);say('rg-status',(ranges.hands||[]).length+' hands with ranges ('+ranges.handsPlayed+' simulated hands played).');}
 catch(e){say('rg-status',e.code==='no-desktop-host'?'Not connected to the desktop host. Double-click VIEW-OPPONENT-RANGES.cmd, then open the dashboard with START-DESKTOP.cmd.':'Could not read ranges: '+e.message,true);}}
function calculator(){
 if(!RE||!window.EM||!window.EM.parseRange){say('rg-calc-status','The range calculator needs the EightMax card library on this page.',true);return;}
 try{const r=RE.WeightedRange.fromText(window.EM,$('rg-calc-range').value||'random');const dead=($('rg-calc-dead').value||'').replace(/[\s,]/g,'').match(/../g)||[];if(dead.length)r.removeCards(dead,'board and known cards');
  const any=RE.WeightedRange.anyTwo();if(dead.length)any.removeCards(dead);const cmp=r.total()>0?r.compare(any):null;
  drawGrid($('rg-calc-grid'),r.classSummary());say('rg-calc-status',r.combos()+' possible hands ('+(r.combos()/1326*100).toFixed(1)+'% of all two-card hands)'+(cmp?'; difference from "any two cards": '+(cmp.totalVariation*100).toFixed(1)+'%':'')+(r.invalid?' · '+r.invalid:''),!!r.invalid);}
 catch(e){say('rg-calc-status','Could not read the range: '+e.message,true);}
}
function show(id){const p=$(id);if(p){p.hidden=false;p.scrollIntoView({behavior:'smooth'});}}
wire('sq-nav',()=>{show('sq-panel');refreshQuality();});wire('sq-close',()=>{$('sq-panel').hidden=true;});wire('sq-refresh',refreshQuality);
wire('sq-validate',()=>launch('library-validate','VALIDATE-STRATEGIES.cmd','sq-status'));wire('sq-continue',()=>launch('library-continue','CONTINUE-TRAINING.cmd','sq-status'));
wire('rg-nav',()=>{show('rg-panel');refreshRanges();});wire('rg-close',()=>{$('rg-panel').hidden=true;});wire('rg-refresh',refreshRanges);
wire('rg-play',()=>launch('view-ranges','VIEW-OPPONENT-RANGES.cmd','rg-status'));wire('rg-calc',calculator);
const sel=$('rg-hand');if(sel)sel.addEventListener('change',()=>renderHand(+sel.value));
// strategy-research row in the "Test results & checks" panel
wire('tr-train',()=>launch('library-precompute','PRECOMPUTE-STRATEGIES.cmd','tr-status'));wire('tr-continue',()=>launch('library-continue','CONTINUE-TRAINING.cmd','tr-status'));
wire('tr-validate',()=>launch('library-validate','VALIDATE-STRATEGIES.cmd','tr-status'));wire('tr-common',()=>launch('library-precompute-common','PRECOMPUTE-COMMON-HANDS.cmd','tr-status'));
wire('tr-ranges',()=>{show('rg-panel');launch('view-ranges','VIEW-OPPONENT-RANGES.cmd','rg-status');});wire('tr-self-test',()=>launch('self-test','RUN-SELF-TEST.cmd','tr-status'));
wire('tr-long',()=>launch('long-acceptance','RUN-LONG-ACCEPTANCE.cmd','tr-status'));wire('tr-save-workspace',()=>{const b=$('workspace-nav');if(b)b.click();});
window.WorkbenchResearchUI={refreshQuality,refreshRanges,calculator};
})();
