/* EightMax Test Workbench 0.33: INDEPENDENT exact evaluator for small N-player poker games (2-4 players).
 *
 * Purpose: verify strategies trained by the EightMax engine (or by src/flop-solver.js / src/fast-multistreet.js) with code that shares
 * NOTHING with them except the input data (ranges as card pairs + weights, the stated betting rules, and the strategy probabilities).
 * Everything else is implemented here from the rules: betting-state transitions and legal actions, pot and side-pot accounting,
 * uncalled-bet returns, a 7-card hand evaluator, chance enumeration with exact card removal, strategy reconstruction from the native
 * state file (readNativeRows), utilities, best responses and NashConv.
 *
 * Games ("public tree with private types"): every action is public, each player's private information is its type (hole cards); an
 * information set of player i is (public history, public cards, i's type). Two builders:
 *   holdem(def)  postflop hold'em subgame: board (flop/turn/river), common pot, stacks behind, weighted two-card ranges per seat,
 *                per-street menus {bets, raises, maxBets} with sizes 'N' (N % of the pot), 'a' (all-in), 'Nx' (raise to N x the price)
 *   kuhn(n)      n-player Kuhn poker (deck of n+1 ranks, ante 1, one bet of 1) - analytic reference game
 * Evaluation: exact enumeration of every compatible deal of private types and every public card. For player i and each own type,
 * one recursion over the public tree carries the vector of opponent-type tuples (prior x opponents' reach x chance); at i's own
 * information sets the best response takes the max over actions of the summed (counterfactual) values. Perfect recall holds, so this
 * is the exact best-response value. NashConv = sum over players of (best-response value - value). With 2 players and constant sum,
 * exploitability = NashConv / 2. With 3+ players NashConv is NOT an exploitability: 0 means a Nash equilibrium (not unique, not
 * coalition-proof); this module never labels it otherwise.
 * Classification of every result: 'exact' (complete defined game, double precision), with missing strategy rows COUNTED (they are
 * played uniformly and the result is then marked incomplete - never silently treated as solved).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.WorkbenchIndependentEval = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const ok = (x, m) => { if (!x) throw new Error(m); };
  const EPS = 1e-9;

  // ---------- own 7-card evaluator: category * 15^5 + kickers (higher is better) ----------
  function rank5of7(cards) {
    const cnt = new Array(13).fill(0), suits = [0, 0, 0, 0], suitCards = [[], [], [], []];
    for (const c of cards) { const r = c >> 2, s = c & 3; cnt[r]++; suits[s] |= 1 << r; suitCards[s].push(r); }
    const enc = (cat, ks) => { let v = cat; for (let i = 0; i < 5; i++) v = v * 15 + (ks[i] === undefined ? 0 : ks[i] + 1); return v; };
    const straightTop = (mask) => { for (let top = 12; top >= 4; top--) { let all = true; for (let k = 0; k < 5; k++) if (!((mask >> (top - k)) & 1)) { all = false; break; } if (all) return top; } return ((mask >> 12) & 1) && (mask & 15) === 15 ? 3 : -1; };
    for (let s = 0; s < 4; s++) if (suitCards[s].length >= 5) {
      const sf = straightTop(suits[s]); if (sf >= 0) return enc(8, [sf]);
      const fl = suitCards[s].slice().sort((a, b) => b - a).slice(0, 5); var flush = enc(5, fl);
    }
    const byCount = []; for (let r = 12; r >= 0; r--) if (cnt[r]) byCount.push([cnt[r], r]); byCount.sort((a, b) => b[0] - a[0] || b[1] - a[1]);
    const ranksDesc = (excl) => { const out = []; for (let r = 12; r >= 0; r--) if (cnt[r] && !excl.includes(r)) out.push(r); return out; };
    if (byCount[0][0] === 4) return enc(7, [byCount[0][1], ranksDesc([byCount[0][1]])[0]]);
    if (byCount[0][0] === 3 && byCount.length > 1 && byCount[1][0] >= 2) return enc(6, [byCount[0][1], byCount[1][1]]);
    if (flush !== undefined) return flush;
    let mask = 0; for (let r = 0; r < 13; r++) if (cnt[r]) mask |= 1 << r; const st = straightTop(mask); if (st >= 0) return enc(4, [st]);
    if (byCount[0][0] === 3) return enc(3, [byCount[0][1], ...ranksDesc([byCount[0][1]]).slice(0, 2)]);
    if (byCount[0][0] === 2 && byCount[1] && byCount[1][0] === 2) { const hi = byCount[0][1], lo = byCount[1][1]; return enc(2, [hi, lo, ranksDesc([hi, lo])[0]]); }
    if (byCount[0][0] === 2) return enc(1, [byCount[0][1], ...ranksDesc([byCount[0][1]]).slice(0, 3)]);
    return enc(0, ranksDesc([]).slice(0, 5));
  }
  const RANKS = '23456789TJQKA', SUITS = 'cdhs';
  const card = (s) => { const r = RANKS.indexOf(s[0].toUpperCase()), u = SUITS.indexOf(s[1].toLowerCase()); ok(r >= 0 && u >= 0, 'Bad card ' + s); return r * 4 + u; };
  const cards = (s) => (Array.isArray(s) ? s.slice() : (String(s).match(/../g) || []).map(card));

  // ---------- own side-pot accounting ----------
  /** Net result of each seat at a terminal: contributions contrib[], live[], showdown scores (null = folded), common pot. */
  function settle(contrib, live, scores, common) {
    const n = contrib.length, won = new Array(n).fill(0), liveIdx = []; for (let i = 0; i < n; i++) if (live[i]) liveIdx.push(i);
    const total = contrib.reduce((a, b) => a + b, 0) + common;
    if (liveIdx.length === 1) { won[liveIdx[0]] = total; return won.map((x, i) => x - contrib[i]); }
    // layers: sorted distinct contribution levels of ALL seats (folded chips stay in the layer they were put in)
    const levels = [...new Set(contrib.filter((c) => c > EPS))].sort((a, b) => a - b); let prev = 0, commonLeft = common;
    const award = (amount, elig) => { if (amount <= EPS) return; let best = -Infinity, w = []; for (const i of elig) { if (scores[i] > best) { best = scores[i]; w = [i]; } else if (scores[i] === best) w.push(i); } for (const i of w) won[i] += amount / w.length; };
    for (const L of levels) {
      let amount = 0; for (let i = 0; i < n; i++) amount += Math.max(0, Math.min(contrib[i], L) - prev);
      amount += commonLeft; commonLeft = 0;
      let elig = liveIdx.filter((i) => contrib[i] >= L - EPS);
      if (!elig.length) elig = liveIdx.filter((i) => contrib[i] > prev + EPS);   // excess nobody live matched (all others folded/short): back to its owner(s)
      if (!elig.length) elig = liveIdx; award(amount, elig); prev = L;
    }
    if (commonLeft > 0) award(commonLeft, liveIdx);
    return won.map((x, i) => x - contrib[i]);
  }

  // ---------- hold'em postflop game (own betting rules) ----------
  function parseSizes(text, raising) {
    return String(text || '').trim().split(/[\s,]+/).filter(Boolean).map((w) => {
      if (/^(a|all-in)$/i.test(w)) return { kind: 'jam' };
      const m = /^(\d+(?:\.\d+)?)(%|x)?$/i.exec(w); ok(m, 'Unrecognised size ' + w);
      if (m[2] && m[2].toLowerCase() === 'x') { ok(raising, 'Multiples are raise sizes'); return { kind: 'mult', v: +m[1] }; }
      return { kind: 'pot', v: +m[1] / 100 };
    });
  }
  /** def: { board, common, stacks (behind at the root), hands: [[ [a, b, w], ... ] per seat] or ranges, streets: { flop|turn|river: {bets, raises, maxBets} } } */
  function holdem(def) {
    const board0 = cards(def.board), n = def.stacks.length; ok(n >= 2 && n <= 4, 'The independent evaluator handles 2 to 4 players'); ok(board0.length >= 3 && board0.length <= 5, 'Board must have 3 to 5 cards');
    const types = def.hands.map((list) => list.map((h, src) => ({ cards: [h[0], h[1]], w: h[2], src })).filter((t) => !board0.includes(t.cards[0]) && !board0.includes(t.cards[1]) && t.w > 0));
    const menu = {}; for (const [len, name] of [[3, 'flop'], [4, 'turn'], [5, 'river']]) { const m = (def.streets || {})[name]; if (m) menu[len] = { bets: parseSizes(m.bets, false), raises: parseSizes(m.raises, true), cap: m.maxBets == null ? 2 : m.maxBets }; }
    const stacks = def.stacks.slice(), common = def.common;
    // betting state: street length, contributions this street (put), before this street (prev), live, acted (amount the seat last matched, -1 none), price, full, count, last actor
    function decide(s) {
      const total = s.prev.map((v, i) => v + s.put[i]), behind = stacks.map((v, i) => Math.max(0, v - total[i]));
      const acting = s.live.map((l, i) => l && behind[i] > EPS), liveCount = s.live.filter(Boolean).length, left = acting.filter(Boolean).length;
      const pot = common + total.reduce((a, b) => a + b, 0);
      let actor = -1;
      if (liveCount > 1) for (let k = 1; k <= n; k++) { const p = (s.last + k + n) % n; if (acting[p] && (s.put[p] < s.price - EPS || (left > 1 && s.acted[p] < 0))) { actor = p; break; } }
      if (actor < 0) {
        if (liveCount > 1 && s.len < 5) return { kind: 'chance', total, behind, pot, betting: left >= 2 };
        return { kind: 'terminal', total, behind, pot };
      }
      const p = actor, remaining = stacks[p] - s.prev[p], call = Math.min(s.price, remaining), facing = s.price > s.put[p] + EPS;
      const acts = facing ? [{ kind: 'fold', to: s.put[p] }, { kind: 'call', to: call }] : [{ kind: 'check', to: s.put[p] }];
      const respondent = s.live.some((l, i) => l && i !== p && stacks[i] - s.prev[i] > s.price + EPS), row = menu[s.len];
      const reopened = s.acted[p] < 0 || s.price - s.acted[p] >= s.full - EPS;
      if (row && respondent && s.count < row.cap && reopened) {
        const amounts = [];
        for (const z of (facing ? row.raises : row.bets)) {
          let to = remaining; if (z.kind === 'pot') to = s.price + z.v * (pot + (facing ? s.price - s.put[p] : 0)); if (z.kind === 'mult') to = z.v * s.price;
          to = Math.min(remaining, Math.max(s.price + s.full, to)); if (to > s.price + EPS && !amounts.some((x) => Math.abs(x - to) < EPS)) amounts.push(to);
        }
        amounts.sort((a, b) => a - b); for (const to of amounts) acts.push({ kind: 'aggressive', to });
      }
      return { kind: 'decision', actor: p, actions: acts, total, behind, pot };
    }
    function apply(s, a) {
      const d = decide(s), act = d.actions[a], p = d.actor, put = s.put.slice(), live = s.live.slice(), acted = s.acted.slice();
      if (act.kind === 'fold') live[p] = false; put[p] = act.to; acted[p] = act.to; const inc = act.to > s.price + EPS;
      return { len: s.len, prev: s.prev, put, live, acted, price: inc ? act.to : s.price, full: inc ? Math.max(s.full, act.to - s.price) : s.full, count: s.count + (inc ? 1 : 0), last: p };
    }
    const nextStreet = (s, d) => ({ len: s.len + 1, prev: d.total, put: new Array(n).fill(0), live: s.live, acted: new Array(n).fill(-1), price: 0, full: 1, count: 0, last: -1 });
    const root0 = { len: board0.length, prev: new Array(n).fill(0), put: new Array(n).fill(0), live: new Array(n).fill(true), acted: new Array(n).fill(-1), price: 0, full: 1, count: 0, last: -1 };
    let nodes = 0;
    function build(s, path) {
      const d = decide(s); nodes++;
      if (d.kind === 'decision') return { kind: 'decision', actor: d.actor, path, actions: d.actions, pot: d.pot, behind: d.behind, children: d.actions.map((_, a) => build(apply(s, a), path + a)) };
      if (d.kind === 'chance') return { kind: 'chance', path, street: s.len, pot: d.pot, behind: d.behind, runout: !d.betting, child: build(nextStreet(s, d), path + 'c') };
      const contrib = d.total.slice(); return { kind: 'terminal', path, contrib, live: s.live.slice(), pot: d.pot, behind: d.behind, street: s.len };
    }
    const tree = build(root0, 'r');
    const scoreCache = new Map();
    const scoreOf = (cs2, board) => { let k = cs2[0] * 64 + cs2[1]; for (const c of board) k = k * 53 + c + 1; let v = scoreCache.get(k); if (v === undefined) { v = rank5of7(board.concat(cs2)); if (scoreCache.size > 2e6) scoreCache.clear(); scoreCache.set(k, v); } return v; };
    return { n, types, tree, board: board0, deckSize: 52, nodes, common,
      utility(node, typeIdx, board) { const scores = node.live.map((l, i) => (l && node.live.filter(Boolean).length > 1 ? scoreOf(types[i][typeIdx[i]].cards, board) : null)); return settle(node.contrib, node.live, scores, common); },
      describe: 'hold\'em postflop subgame (independent rules: own legal actions, pots, side pots, evaluator)' };
  }

  // ---------- n-player Kuhn poker (analytic reference) ----------
  /** Deck of n+1 ranks (one card each), ante 1 each, one bet of 1, actions check/bet then fold/call; highest live card wins. */
  function kuhn(n = 3) {
    const deck = n + 1, types = Array.from({ length: n }, () => Array.from({ length: deck }, (_, c) => ({ cards: [c], w: 1 })));
    function build(hist, path) {
      // hist: array of actions so far: 'k' check, 'b' bet, 'c' call, 'f' fold
      const betAt = hist.indexOf('b');
      if (betAt < 0) { if (hist.length === n) return { kind: 'terminal', path, hist: hist.slice() }; const p = hist.length; return { kind: 'decision', actor: p, path, actions: [{ kind: 'check' }, { kind: 'aggressive' }], children: [build(hist.concat('k'), path + 0), build(hist.concat('b'), path + 1)] }; }
      const after = hist.length - betAt - 1; if (after === n - 1) return { kind: 'terminal', path, hist: hist.slice() };
      const p = (betAt + 1 + after) % n; return { kind: 'decision', actor: p, path, actions: [{ kind: 'fold' }, { kind: 'call' }], children: [build(hist.concat('f'), path + 0), build(hist.concat('c'), path + 1)] };
    }
    const tree = build([], 'r');
    return { n, types, tree, board: [], deckSize: deck, nodes: 0, common: 0,
      utility(node, typeIdx) {
        const h = node.hist, betAt = h.indexOf('b'), contrib = new Array(n).fill(1), live = new Array(n).fill(true);
        if (betAt >= 0) { contrib[betAt] = 2; for (let k = 1; k < n; k++) { const p = (betAt + k) % n, a = h[betAt + k]; if (a === 'c') contrib[p] = 2; else live[p] = false; } }
        const scores = typeIdx.map((t, i) => (live[i] ? t : null)); return settle(contrib, live, scores, 0); },
      describe: n + '-player Kuhn poker (deck of ' + deck + ' ranks, ante 1, bet 1)' };
  }

  // ---------- exact evaluation ----------
  /** strategy(seat, node, board, typeIndex) -> array of action probabilities, or null when the strategy has no row (counted, uniform). */
  function evaluate(G, strategy, o = {}) {
    const n = G.n, T = G.types, board0 = G.board, t0 = Date.now(); let missing = 0, lookups = 0; const missingKeys = new Set();
    const disjoint = (a, b) => { for (const x of a) if (b.includes(x)) return false; return true; };
    const sigma = (seat, node, board, ti) => { lookups++; const s = strategy(seat, node, board, ti, T[seat][ti]); if (!s) { const k = node.path + '|' + board.join('.') + '|' + seat + '|' + ti; if (!missingKeys.has(k)) { missingKeys.add(k); missing++; } return new Array(node.actions.length).fill(1 / node.actions.length); } ok(s.length === node.actions.length, 'Strategy width ' + s.length + ' differs from ' + node.actions.length + ' actions at ' + node.path); return s; };
    const perPlayer = [];
    let Z = 0;   // total prior mass of compatible deals
    for (let i = 0; i < n; i++) {
      const opp = []; for (let j = 0; j < n; j++) if (j !== i) opp.push(j);
      let vSum = 0, brSum = 0;
      for (let hi = 0; hi < T[i].length; hi++) {
        const own = T[i][hi]; if (!disjoint(own.cards, board0)) continue;
        // compatible opponent tuples
        const tuples = [], w0 = [];
        const rec = (k, idx, used, w) => { if (k === opp.length) { tuples.push(idx.slice()); w0.push(w); return; } const j = opp[k]; for (let t = 0; t < T[j].length; t++) { const c = T[j][t].cards; if (!disjoint(c, used)) continue; idx.push(t); rec(k + 1, idx, used.concat(c), w * T[j][t].w); idx.pop(); } };
        rec(0, [], board0.concat(own.cards), 1);
        if (!tuples.length) continue;
        const full = tuples.map((tp) => { const a = new Array(n); a[i] = hi; opp.forEach((j, k) => { a[j] = tp[k]; }); return a; });
        const handCards = full.map((a) => a.flatMap((t, j) => T[j][t].cards));
        if (i === 0) for (const w of w0) Z += own.w * w;
        const walk = (node, board, w) => {
          if (node.kind === 'terminal') { let v = 0; for (let t = 0; t < w.length; t++) if (w[t]) v += w[t] * G.utility(node, full[t], board)[i]; return [v, v]; }
          if (node.kind === 'chance') {
            const cardsIn = own.cards.length * n, K = G.deckSize - board.length - cardsIn; let v = 0, b = 0;
            for (let c = 0; c < G.deckSize; c++) {
              if (board.includes(c) || own.cards.includes(c)) continue;
              const w2 = new Float64Array(w.length); let any = false; for (let t = 0; t < w.length; t++) if (w[t] && !handCards[t].includes(c)) { w2[t] = w[t] / K; any = true; }
              if (!any) continue; const r = walk(node.child, board.concat(c), w2); v += r[0]; b += r[1];
            }
            return [v, b];
          }
          if (node.actor === i) {
            const s = sigma(i, node, board, hi); let v = 0, b = -Infinity;
            for (let a = 0; a < node.actions.length; a++) { const r = walk(node.children[a], board, w); v += s[a] * r[0]; if (r[1] > b) b = r[1]; }
            return [v, b];
          }
          const j = node.actor, k = opp.indexOf(j), cache = new Map(); let v = 0, b = 0;
          const rows = (t) => { const ti = tuples[t][k]; let s = cache.get(ti); if (!s) { s = sigma(j, node, board, ti); cache.set(ti, s); } return s; };
          for (let a = 0; a < node.actions.length; a++) {
            const w2 = new Float64Array(w.length); let any = false; for (let t = 0; t < w.length; t++) if (w[t]) { const x = w[t] * rows(t)[a]; if (x) { w2[t] = x; any = true; } }
            if (!any) continue; const r = walk(node.children[a], board, w2); v += r[0]; b += r[1];
          }
          return [v, b];
        };
        const r = walk(G.tree, board0, Float64Array.from(w0));
        vSum += own.w * r[0]; brSum += own.w * r[1];
      }
      perPlayer.push({ v: vSum, br: brSum });
    }
    ok(Z > 0, 'No compatible deals');
    const values = perPlayer.map((x) => x.v / Z), bestResponses = perPlayer.map((x) => x.br / Z), gains = bestResponses.map((b, i) => b - values[i]), nashConv = gains.reduce((a, b) => a + b, 0);
    const out = { players: n, values, bestResponses, gains, nashConv, valueSum: values.reduce((a, b) => a + b, 0), missingRows: missing, lookups, complete: missing === 0, evalMs: Date.now() - t0, game: G.describe,
      classification: missing ? 'exact evaluation of an INCOMPLETE strategy (missing rows played uniformly)' : 'exact', method: 'independent exact enumeration (own rules, pots, evaluator, best response)' };
    if (n === 2) { out.exploitability = nashConv / 2; out.exploitabilityNote = 'two-player game: exploitability = NashConv / 2 (constant sum)'; }
    else out.note = 'NashConv with ' + n + ' players: sum of unilateral best-response gains; 0 = Nash equilibrium (not unique, not coalition-proof). Not an exploitability.';
    if (o.commonPot) out.nashConvPctPot = nashConv / o.commonPot * 100;
    return out;
  }

  /** Independent CFR (vanilla, simultaneous updates, uniform average) for small games, used to produce reference strategies (e.g. Kuhn). */
  function cfr(G, iterations) {
    const n = G.n, reg = new Map(), avg = new Map();
    const keyOf = (node, board, seat, ti) => node.path + '|' + board.join('.') + '|' + seat + '|' + ti;
    const cur = (k, m) => { const r = reg.get(k); const out = new Array(m); let s = 0; if (r) for (let a = 0; a < m; a++) s += Math.max(0, r[a]); for (let a = 0; a < m; a++) out[a] = s > 0 ? Math.max(0, r[a]) / s : 1 / m; return out; };
    // full deal enumeration (small games only)
    const deals = []; const rec = (j, idx, used, w) => { if (j === n) { deals.push({ idx: idx.slice(), w }); return; } for (let t = 0; t < G.types[j].length; t++) { const c = G.types[j][t].cards; if (c.some((x) => used.includes(x))) continue; idx.push(t); rec(j + 1, idx, used.concat(c), w * G.types[j][t].w); idx.pop(); } };
    rec(0, [], G.board.slice(), 1);
    for (let it = 1; it <= iterations; it++) {
      const dR = new Map(), dA = new Map();
      for (const d of deals) {
        const walk = (node, reach) => {
          if (node.kind === 'terminal') return G.utility(node, d.idx, G.board);
          ok(node.kind === 'decision', 'cfr(): chance nodes are not supported (use small games)');
          const p = node.actor, k = keyOf(node, G.board, p, d.idx[p]), m = node.actions.length, s = cur(k, m), u = new Array(m), v = new Array(n).fill(0);
          for (let a = 0; a < m; a++) { const r2 = reach.slice(); r2[p] *= s[a]; u[a] = walk(node.children[a], r2); for (let q = 0; q < n; q++) v[q] += s[a] * u[a][q]; }
          let cf = d.w; for (let q = 0; q < n; q++) if (q !== p) cf *= reach[q];
          let R = dR.get(k); if (!R) { R = new Array(m).fill(0); dR.set(k, R); } for (let a = 0; a < m; a++) R[a] += cf * (u[a][p] - v[p]);
          let A = dA.get(k); if (!A) { A = new Array(m).fill(0); dA.set(k, A); } for (let a = 0; a < m; a++) A[a] += d.w * reach[p] * s[a];
          return v;
        };
        walk(G.tree, new Array(n).fill(1));
      }
      for (const [k, R] of dR) { const r = reg.get(k) || new Array(R.length).fill(0); for (let a = 0; a < R.length; a++) r[a] += R[a]; reg.set(k, r); }
      for (const [k, A] of dA) { const x = avg.get(k) || new Array(A.length).fill(0); for (let a = 0; a < A.length; a++) x[a] += A[a]; avg.set(k, x); }
    }
    return (seat, node, board, ti) => { const A = avg.get(keyOf(node, board, seat, ti)); if (!A) return null; const s = A.reduce((a, b) => a + b, 0); return A.map((x) => (s > 0 ? x / s : 1 / A.length)); };
  }

  /** Cross-check of the betting rules against another implementation's view(steps) (EightMax game.view): same decision points, same
   *  number and kind of actions, same pot and stacks behind at every node, same terminal positions. Returns { checked, mismatches }. */
  function compareGeometry(G, view) {
    const mism = []; let checked = 0, runouts = 0;
    const kindOf = (label) => (/^Fold/.test(label) ? 'fold' : /^Check/.test(label) ? 'check' : /^Call/.test(label) ? 'call' : 'aggressive');
    const rec = (node, steps) => {
      const v = view(steps); checked++;
      const want = node.kind === 'decision' ? 'player' : node.kind;
      if (v.kind !== want) { if (node.kind === 'chance' && node.runout && v.kind === 'terminal') { runouts++; return; } mism.push({ path: node.path, mine: want, theirs: v.kind }); return; }   // all-in before the river: their terminal averages the runout, ours deals it
      if (Math.abs((v.pot || 0) - node.pot) > 1e-6 && v.pot !== undefined && node.pot !== undefined) mism.push({ path: node.path, field: 'pot', mine: node.pot, theirs: v.pot });
      if (v.behind && node.behind && v.behind.some((b, i) => Math.abs(b - node.behind[i]) > 1e-6)) mism.push({ path: node.path, field: 'behind', mine: node.behind, theirs: v.behind });
      if (node.kind === 'decision') {
        if (v.seat !== node.actor) mism.push({ path: node.path, field: 'actor', mine: node.actor, theirs: v.seat });
        const theirs = v.actions.map((a) => kindOf(a.label)), mine = node.actions.map((a) => a.kind);
        if (theirs.join() !== mine.join()) { mism.push({ path: node.path, field: 'actions', mine, theirs }); return; }
        node.children.forEach((c, a) => rec(c, steps.concat(a)));
      } else if (node.kind === 'chance') {
        const free = []; for (let c = 0; c < 52 && free.length < 1; c++) if (!steps.some((s) => s && s.card === c) && !G.board.includes(c)) free.push(c);
        rec(node.child, steps.concat({ card: free[0] }));
      }
    };
    rec(G.tree, []);
    return { checked, mismatches: mism, allInRunoutsEquivalent: runouts };
  }

  /** Independent reader of a native EMMW4 state (plain row layout): reconstructs normalised average strategies keyed by
   *  (action path, public cards after the starting board, seat, range index). Returns strategy(seat, node, board, ti) for evaluate(). */
  function readNativeRows(buffer, spec, startBoard) {
    const b = Buffer.from(buffer.buffer ? buffer.buffer : buffer, buffer.byteOffset || 0, buffer.byteLength); ok(b.toString('latin1', 0, 5) === 'EMMW4', 'Not an EMMW4 state');
    const hl = b.readUInt32LE(8), head = JSON.parse(b.toString('utf8', 12, 12 + hl)); ok(head.rowKeys === undefined && head.rowSync === undefined, 'Only the plain row layout is supported');
    let p = 12 + hl; const sc = b.readUInt32LE(p); p += 4; const parent = new Uint32Array(sc), slot = new Uint8Array(sc), actor = new Uint8Array(sc);
    for (let i = 0; i < sc; i++) { parent[i] = b.readUInt32LE(p); slot[i] = b[p + 4]; actor[i] = b[p + 6]; p += 9; }
    const pathOf = (s) => { let x = ''; while (s !== 0) { x = (slot[s] === 7 ? 'c' : String(slot[s])) + x; s = parent[s]; } return 'r' + x; };
    const paths = new Map(); const rows = new Map(); const rc = b.readUInt32LE(p); p += 4;
    for (let r = 0; r < rc; r++) {
      const st = b.readUInt32LE(p), hand = b.readUInt16LE(p + 4), k = b[p + 11]; const cs = []; for (let c = 0; c < 5; c++) if (b[p + 6 + c]) cs.push(b[p + 6 + c] - 1);
      let path = paths.get(st); if (!path) { path = pathOf(st); paths.set(st, path); }
      const avg = new Array(k); let s = 0; for (let a = 0; a < k; a++) { avg[a] = b.readDoubleLE(p + 12 + 8 * k + 8 * a); s += avg[a]; }
      rows.set(path + '|' + cs.join('.') + '|' + actor[st] + '|' + hand, s > 0 ? avg.map((x) => x / s) : avg.map(() => 1 / k));
      p += 12 + 16 * k;
    }
    return { rows, header: head,
      /** native rows carry the whole public board: the three flop cards in ascending order, then later cards in deal order */
      strategy(seat, node, board, ti, type) { const rangeIndex = type && type.src !== undefined ? type.src : ti; const canon = board.slice(0, 3).sort((x, y) => x - y).concat(board.slice(3)); return rows.get(node.path + '|' + canon.join('.') + '|' + seat + '|' + rangeIndex) || null; } };
  }
  return { rank5of7, settle, holdem, kuhn, evaluate, cfr, compareGeometry, readNativeRows, cards, card };
});
