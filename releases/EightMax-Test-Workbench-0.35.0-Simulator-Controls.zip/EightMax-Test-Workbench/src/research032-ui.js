/* EightMax Test Workbench 0.32 - "Research" panel: preflop analysis, multi-street (linked) studies, coverage, memory, turn solver.
   Reads GET /api/research/summary through the desktop host; buttons start the release's own launchers through POST /api/desktop/launch.
   Without the desktop host the panel shows the release measurements embedded at build time, labelled as such. */
(function(){
'use strict';
const $=id=>document.getElementById(id),V=window.WorkbenchResearch032View;
if(!V||!$('rs-panel'))return;
function token(){const d=window.WorkbenchDesktop&&window.WorkbenchDesktop.fromPage&&window.WorkbenchDesktop.fromPage(window);return d&&d.secret?d.secret:null;}
async function host(method,path,body){const t=token();if(!t){const e=Error('not connected');e.code='no-desktop-host';throw e;}
 const r=await fetch('http://127.0.0.1:48713'+path,{method,headers:{'X-EightMax-Session':t,'X-EightMax-Step':'dashboard-research032',...(body===undefined?{}:{'Content-Type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body),credentials:'omit',cache:'no-store'});
 let j=null;try{j=await r.json();}catch(e){}if(!r.ok){const e=Error((j&&j.error)||('HTTP '+r.status));e.code=j&&j.code;throw e;}return j;}
function el(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function say(id,text,bad){const s=$(id);if(!s)return;s.textContent=text;s.classList.toggle('bad',!!bad);}
function table(id,cols,rows){const t=$(id);if(!t)return;t.textContent='';const h=el('tr');for(const c of cols)h.appendChild(el('th',c[0]));t.appendChild(h);for(const r of rows){const tr=el('tr');for(const c of cols)tr.appendChild(el('td',String(r[c[1]]===undefined?'—':r[c[1]])));t.appendChild(tr);}}
function render(sum){
 const p=V.preflopView(sum.preflop);$('rs-pf-head').textContent=p.headline;$('rs-pf-detail').textContent=p.detail;$('rs-pf-status').textContent=p.status+' '+(p.fullGame||'');
 table('rs-pf-runs',[['Study','study'],['Hand-class coverage','classCoverage'],['Combination coverage','comboCoverage'],['Flop ranges supported','rangeSupport'],['Decision states without any row','noRowStates']],p.rows);
 table('rs-pf-seats',[['Position','position'],['Class coverage','coverage'],['Reached states missing classes','missing']],p.seats);
 table('rs-pf-missing',[['Missing branch','path'],['Position','position'],['Reach','reach'],['Stored','classes']],p.missing);
 table('rs-pf-dev',[['Position (first in)','position'],['Deviation gain per hand (lower-bound estimate)','gain'],['At the node','atNode'],['Continuation','fallback']],p.deviations);
 const l=V.linkedView(sum.library);$('rs-lk-head').textContent=l.headline;$('rs-lk-detail').textContent=l.detail||'';
 table('rs-lk-rows',[['Street','street'],['Stored','records'],['With continuation','linked'],['Continuation complete','complete'],['Missing continuation','missing'],['Validated','validated'],['Unverified','unverified'],['Failed','failed']],l.rows);
 const c=V.coverageView(sum.coverage);$('rs-cv-head').textContent=c.headline;$('rs-cv-detail').textContent=(c.detail||'')+(c.resources?' · '+c.resources:'');
 table('rs-cv-rows',[['Run','name'],['Decisions','decisions'],['Exact','exact'],['Any strategy','any'],['Approximate','abstracted'],['Solved on demand','onDemand'],['Unavailable','unavailable']],c.rows);
 table('rs-cv-streets',[['Street','street'],['Decisions','decisions'],['Exact','exact'],['Approximate','abstracted'],['On demand','onDemand'],['Unavailable','unavailable']],c.streets);
 const m=V.memoryView(sum.memory);$('rs-mem-head').textContent=m.headline;$('rs-mem-detail').textContent=m.detail||'';
 $('rs-mem-live').textContent=m.live?'This computer now: '+m.live.used+' of '+m.live.total+' in use (pressure '+m.live.pressure+'); summary tool used '+m.live.process+'.':'';
 table('rs-mem-rows',[['Tables','tables'],['0.31 (copy per worker)','before'],['0.32 (shared)','after'],['Saved','saved'],['Identical decisions','identical']],m.rows);
 const t=V.turnView(sum.turnSolver);$('rs-ts-head').textContent=t.headline;table('rs-ts-rows',[['Configuration','config'],['Result (exact)','result'],['Memory','memory']],t.rows);
}
async function refresh(){say('rs-status','Reading research results…');try{render(await host('GET','/api/research/summary'));say('rs-status','Results read from this computer. Nothing was trained or changed.');}
 catch(e){const emb=window.EIGHTMAX_RESEARCH_SUMMARY;if(emb){render(emb);say('rs-status',(e.code==='no-desktop-host'?'Not connected to the desktop host: ':'Could not read this computer\'s results ('+e.message+'): ')+'showing the RELEASE measurements from the build machine.',e.code!=='no-desktop-host');}else say('rs-status','Not connected to the desktop host. Start with START-DESKTOP.cmd.',true);}}
async function launch(tool,label){say('rs-status','Starting '+label+'…');try{const r=await host('POST','/api/desktop/launch',{tool});say('rs-status',r.message+' It runs in its own window; press Refresh afterwards.');}catch(e){say('rs-status',e.code==='no-desktop-host'?'Double-click '+label+' in the release folder (this page is not connected to the desktop host).':'Could not start '+label+': '+e.message,true);}}
const btn=(id,tool,label)=>{const b=$(id);if(b)b.addEventListener('click',()=>launch(tool,label));};
btn('rs-run-preflop','preflop-research','RUN-PREFLOP-RESEARCH.cmd');btn('rs-run-turn','turn-solver-check','RUN-TURN-SOLVER-CHECK.cmd');btn('rs-run-memory','memory-check','RUN-MEMORY-CHECK.cmd');btn('rs-run-summary','research-summary','REFRESH-RESEARCH-SUMMARY.cmd');
btn('rs-train','library-precompute','PRECOMPUTE-STRATEGIES.cmd');btn('rs-continue','library-continue','CONTINUE-TRAINING.cmd');btn('rs-validate','library-validate','VALIDATE-STRATEGIES.cmd');
const r=$('rs-refresh');if(r)r.addEventListener('click',refresh);
const nav=$('rs-nav');if(nav)nav.addEventListener('click',()=>{$('rs-panel').hidden=false;$('rs-panel').scrollIntoView({block:'start'});refresh();});
const close=$('rs-close');if(close)close.addEventListener('click',()=>{$('rs-panel').hidden=true;});
})();
