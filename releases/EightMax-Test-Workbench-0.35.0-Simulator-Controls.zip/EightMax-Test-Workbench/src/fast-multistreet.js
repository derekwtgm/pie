/* EightMax Test Workbench 0.32: EXACT vectorised evaluation and CFR+ for heads-up MULTI-STREET games (flop -> turn -> river,
 * turn -> river, or river only).
 *
 * Extends the 0.31 river module (src/fast-river.js) to games with chance nodes. Same independence rules as src/exploitability.js:
 * own seven-card evaluator (exploitability.score7), own payouts from the tree geometry (contributions derived from the stacks
 * behind at each terminal), own best response and own CFR+. From a study it takes only (a) the betting-tree geometry (game.view)
 * and (b) the average strategy for each hand at each information set (averageAt(path, publicCards, seat, hand)).
 *
 * Game evaluated: the heads-up postflop game defined by the study - starting board, the two weighted ranges (joint deal with card
 * removal, weight = product of combo weights), the study's betting menus on every street, every turn and river card dealt
 * uniformly from the cards not held by either player and not on the board (exactly: for any compatible pair of hands the number
 * of possible next cards is the same, 48 - |board|, so each next card has the constant weight 1 / (48 - |board|)).
 * Utility = chips won from the pot minus chips put in from the study root (the starting pot is common money).
 * An all-in before the river is a terminal whose value is averaged exactly over every remaining runout.
 *
 * Card removal at chance nodes: a hand that contains the dealt card is impossible below that card; its reach is zeroed there.
 *
 * Results are EXACT for that defined game (no sampling). Two players only: constant-sum, exploitability = NashConv / 2.
 * Exposed: prepare(game, spec, o) -> { evaluate(S), exact(gameLike), cfrPlus(iterations, o), strategyOf(gameLike), tree, hands, estimateBytes }
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./exploitability.js'));
  else root.WorkbenchFastMultiStreet = factory(root.WorkbenchExploitability);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (X) {
  'use strict';
  const ok = (x, m) => { if (!x) throw new Error(m); };
  class SolveCancelled extends Error { constructor(m) { super(m); this.code = 'cancelled'; } }
  class SolveLimit extends Error { constructor(code, m) { super(m); this.code = code; } }

  /** Betting-tree geometry of a multi-street study. The betting structure below a chance node does not depend on the dealt card
   *  (bet sizes are pot fractions), so each street's subtree is built once with a representative card and REUSED for every card;
   *  `verifyCards` re-checks that claim for the given number of alternative cards per chance node. */
  function buildTree(game, spec, o = {}) {
    const rootView = game.view([]); ok(rootView.kind === 'player', 'Root is not a decision');
    const start = rootView.behind.slice(), common = rootView.pot, n = start.length;
    const board0 = Array.isArray(spec.board) ? spec.board.slice() : (String(spec.board).match(/../g) || []).map(X.parse);
    ok(board0.length >= 3 && board0.length <= 5, 'Multi-street evaluation needs a flop, turn or river board');
    let nodes = 0, decisions = 0;
    const free = (board) => { for (let c = 0; c < 52; c++) if (!board.includes(c)) return c; return -1; };
    const geometry = (v) => JSON.stringify([v.kind, v.seat, v.pot, v.behind, v.live, v.actions ? v.actions.map((a) => a.label) : null]);
    const rec = (steps, path, board) => {
      const v = game.view(steps); nodes++;
      if (v.kind === 'player') {
        decisions++; const ch = [];
        for (let a = 0; a < v.actions.length; a++) ch.push(rec(steps.concat(a), path + a, board));
        return { kind: 'player', seat: v.seat, path, k: v.actions.length, labels: v.actions.map((x) => x.label), children: ch, street: board.length, pot: v.pot, behind: v.behind.slice(), live: v.live.slice() };
      }
      if (v.kind === 'chance') {
        ok(board.length < 5, 'Chance node after the river at ' + path);
        const c0 = free(board), child = rec(steps.concat({ card: c0 }), path + 'c', board.concat(c0));
        if (o.verifyCards) {   // the reused subtree must have the same geometry for other cards
          let checked = 0; for (let c = 51; c >= 0 && checked < o.verifyCards; c--) { if (board.includes(c) || c === c0) continue; const a = game.view(steps.concat({ card: c0 })), b = game.view(steps.concat({ card: c })); ok(geometry(a) === geometry(b), 'Betting geometry below ' + path + ' depends on the dealt card'); checked++; }
        }
        return { kind: 'chance', path, child, street: board.length, pot: v.pot, behind: v.behind.slice(), live: v.live.slice() };
      }
      ok(v.kind === 'terminal', 'Unexpected node kind ' + v.kind + ' at ' + path);
      ok(Array.isArray(v.behind) && Array.isArray(v.live), 'Terminal geometry missing at ' + path);
      const contrib = start.map((s, i) => +(s - v.behind[i]).toFixed(6)), total = +(common + contrib.reduce((a, b) => a + b, 0)).toFixed(6);
      ok(v.pot === undefined || Math.abs(v.pot - total) < 1e-6, 'Terminal pot ' + v.pot + ' differs from common + contributions ' + total + ' at ' + path);
      return { kind: 'terminal', path, contrib, live: v.live.slice(), total, street: board.length, pot: v.pot, behind: v.behind.slice() };
    };
    const tree = rec([], 'r', board0);
    let id = 0; (function number(x) { x.id = id++; if (x.kind === 'player') x.children.forEach(number); else if (x.kind === 'chance') number(x.child); })(tree);
    return { tree, start, common, n, nodes, decisions, board: board0, hands: spec.hands };
  }

  function prepare(game, spec, o = {}) {
    const g = buildTree(game, spec, o); ok(g.n === 2, 'Vectorised multi-street evaluation is heads-up only (' + g.n + ' players)');
    const board0 = g.board;
    const H = [0, 1].map((p) => g.hands[p].filter((r) => !board0.includes(r[1]) && !board0.includes(r[2])).map((r) => ({ row: r, a: r[1], b: r[2], w: r[3] })));
    ok(H[0].length && H[1].length, 'A range is empty after removing the board cards');
    const comboKey = (h) => Math.min(h.a, h.b) * 64 + Math.max(h.a, h.b);
    const same = [0, 1].map((p) => { const m = new Map(H[1 - p].map((h, i) => [comboKey(h), i])); return H[p].map((h) => (m.has(comboKey(h)) ? m.get(comboKey(h)) : -1)); });
    // per-card membership: hands of p that contain card c
    const holding = [0, 1].map((p) => { const L = Array.from({ length: 52 }, () => []); H[p].forEach((h, i) => { L[h.a].push(i); L[h.b].push(i); }); return L; });
    const deadline = o.deadline || null, signal = o.signal || null; let work = 0;
    const tick = () => { if ((++work & 1023) === 0) { if (signal && signal.aborted) throw new SolveCancelled('Solve cancelled'); if (deadline && Date.now() > deadline) throw new SolveLimit('time-limit', 'Time limit reached'); } };
    // ---- river showdown tables, one per complete board (memoised, bounded) ----
    const scoreCache = new Map(), maxBoards = o.maxBoardCache || 4096;
    function boardInfo(board) {
      const key = board.slice().sort((a, b) => a - b).join(','); let b = scoreCache.get(key); if (b) return b;
      const sc = [0, 1].map((p) => Float64Array.from(H[p], (h) => (board.includes(h.a) || board.includes(h.b) ? -1 : X.score7([...board, h.a, h.b]))));
      const order = [0, 1].map((p) => H[p].map((_, i) => i).filter((i) => sc[p][i] >= 0).sort((x, y) => sc[p][x] - sc[p][y]));
      b = { sc, order }; if (scoreCache.size >= maxBoards) scoreCache.delete(scoreCache.keys().next().value); scoreCache.set(key, b); return b;
    }
    // buffer pool for the CFR+ hot path (vectors are returned to the pool once the parent has consumed them)
    const pools = new Map(), take = (n) => { const l = pools.get(n); if (l && l.length) return l.pop().fill(0); return new Float64Array(n); }, give = (a) => { let l = pools.get(a.length); if (!l) { l = []; pools.set(a.length, l); } if (l.length < 8192) l.push(a); };
    // scratch buffers reused by masses() (its result is consumed before the next call; nothing keeps a reference)
    const scratch = [0, 1].map((p) => ({ comp: new Float64Array(H[p].length), win: new Float64Array(H[p].length), lose: new Float64Array(H[p].length), c2: new Float64Array(H[p].length), R: new Float64Array(52), Rb: new Float64Array(52), Ra: new Float64Array(52) }));
    /** For own player p on a complete board, opponent reach r: per own hand {comp, win, lose}; exact card removal. */
    function masses(p, r, board) {
      const O = H[1 - p], M = H[p], n = M.length, sc0 = scratch[p], comp = sc0.comp.fill(0), win = sc0.win.fill(0), lose = sc0.lose.fill(0), B = boardInfo(board);
      let total = 0; const R = sc0.R.fill(0); for (let j = 0; j < O.length; j++) { const x = r[j]; if (!x) continue; total += x; R[O[j].a] += x; R[O[j].b] += x; }
      for (let i = 0; i < n; i++) { if (B.sc[p][i] < 0) continue; const h = M[i], s = same[p][i]; comp[i] = total - R[h.a] - R[h.b] + (s >= 0 ? r[s] : 0); }
      const oo = B.order[1 - p], mo = B.order[p], so = B.sc[1 - p], sm = B.sc[p];
      let k = 0, below = 0; const Rb = sc0.Rb.fill(0);
      for (let t = 0; t < mo.length;) { const s0 = sm[mo[t]]; while (k < oo.length && so[oo[k]] < s0) { const j = oo[k], x = r[j]; if (x) { below += x; Rb[O[j].a] += x; Rb[O[j].b] += x; } k++; } let t2 = t; while (t2 < mo.length && sm[mo[t2]] === s0) { const i = mo[t2], h = M[i]; win[i] = below - Rb[h.a] - Rb[h.b]; t2++; } t = t2; }
      k = oo.length - 1; let above = 0; const Ra = sc0.Ra.fill(0);
      for (let t = mo.length - 1; t >= 0;) { const s0 = sm[mo[t]]; while (k >= 0 && so[oo[k]] > s0) { const j = oo[k], x = r[j]; if (x) { above += x; Ra[O[j].a] += x; Ra[O[j].b] += x; } k--; } let t2 = t; while (t2 >= 0 && sm[mo[t2]] === s0) { const i = mo[t2], h = M[i]; lose[i] = above - Ra[h.a] - Ra[h.b]; t2--; } t = t2; }
      return { comp, win, lose };
    }
    const util = new Map();
    function termUtil(node, p) {
      const key = node.path + '|' + p; let u = util.get(key); if (u) return u;
      if (node.live.filter(Boolean).length < 2) u = { fold: X.payoff(node, [0, 0], g.common)[p] };
      else { const sc = (mine, theirs) => (p === 0 ? [mine, theirs] : [theirs, mine]); u = { win: X.payoff(node, sc(2, 1), g.common)[p], lose: X.payoff(node, sc(1, 2), g.common)[p], tie: X.payoff(node, sc(1, 1), g.common)[p] }; }
      util.set(key, u); return u;
    }
    /** Fold-terminal masses (no showdown): compatible opponent mass given the current board (hands touching the board have r = 0). */
    function compOnly(p, r) {
      const O = H[1 - p], M = H[p], n = M.length, comp = scratch[p].c2.fill(0); let total = 0; const R = scratch[p].R.fill(0);
      for (let j = 0; j < O.length; j++) { const x = r[j]; if (!x) continue; total += x; R[O[j].a] += x; R[O[j].b] += x; }
      for (let i = 0; i < n; i++) { const h = M[i], s = same[p][i]; comp[i] = total - R[h.a] - R[h.b] + (s >= 0 ? r[s] : 0); }
      return comp;
    }
    const nextCards = (board) => { const out = []; for (let c = 0; c < 52; c++) if (!board.includes(c)) out.push(c); return out; };
    /** Terminal value vector for p; an all-in before the river is averaged over every runout (weight 1/(48-|board|) per card). */
    function termValues(node, p, r, board, dead) {
      tick(); const u = termUtil(node, p), n = H[p].length, out = take(n);
      if (u.fold !== undefined) { const comp = compOnly(p, r); for (let i = 0; i < n; i++) out[i] = dead[i] ? 0 : u.fold * comp[i]; return out; }
      if (board.length === 5) { const m = masses(p, r, board); for (let i = 0; i < n; i++) { if (dead[i]) continue; const tie = m.comp[i] - m.win[i] - m.lose[i]; out[i] = u.win * m.win[i] + u.lose * m.lose[i] + u.tie * tie; } return out; }
      const E = equityOf(board);
      if (E) {   // all-in before the river: runout-averaged win/tie matrices (exact; same sums as the enumeration below)
        const comp = compOnly(p, r), n1 = H[1].length, W = E.W, T = E.T, dw = u.win - u.lose, dt = u.tie - u.lose;
        if (p === 0) for (let i = 0; i < n; i++) { if (dead[i]) continue; let sw = 0, st = 0; const base = i * n1; for (let j = 0; j < n1; j++) { const x = r[j]; if (x) { sw += x * W[base + j]; st += x * T[base + j]; } } out[i] = u.lose * comp[i] + dw * sw + dt * st; }
        else { const sw = take(n), st = take(n), n0 = H[0].length; for (let j = 0; j < n0; j++) { const x = r[j]; if (!x) continue; const base = j * n1; for (let i = 0; i < n; i++) { st[i] += x * T[base + i]; sw[i] += x * E.L[base + i]; } } for (let i = 0; i < n; i++) if (!dead[i]) out[i] = u.lose * comp[i] + dw * sw[i] + dt * st[i]; give(sw); give(st); }
        return out;
      }
      const cw = 1 / (48 - board.length);
      for (const c of nextCards(board)) { const [r2, d2] = removeCard(p, r, dead, c); const v = termValues(node, p, r2, board.concat(c), d2); for (let i = 0; i < n; i++) out[i] += cw * v[i]; give(v); give(r2); }
      return out;
    }
    // runout equity matrices for player 0 vs player 1 on an incomplete board: W[i][j] = P(0 wins), T = P(tie), L = P(1 wins... i.e. 0 loses),
    // averaged over every runout of compatible cards (weight 1/(48-|board|) per card per street). Bounded by o.maxEquityBytes.
    const equity = new Map(); let equityBytes = 0; const maxEq = o.maxEquityBytes === undefined ? 256 << 20 : o.maxEquityBytes;
    function equityOf(board) {
      const key = ctxOf(board) + ':' + board.length; if (equity.has(key)) return equity.get(key);
      const n0 = H[0].length, n1 = H[1].length, bytes = n0 * n1 * 24, runs = board.length === 4 ? 44 : 45 * 44;
      if (equityBytes + bytes > maxEq || n0 * n1 * runs > (o.maxEquityWork || 4e8)) { equity.set(key, null); return null; }
      const W = new Float64Array(n0 * n1), T = new Float64Array(n0 * n1), L = new Float64Array(n0 * n1);
      const add = (full, w) => { const B = boardInfo(full), s0 = B.sc[0], s1 = B.sc[1]; for (let i = 0; i < n0; i++) { const a = s0[i]; if (a < 0) continue; const hi = H[0][i], base = i * n1; for (let j = 0; j < n1; j++) { const b = s1[j]; if (b < 0) continue; const hj = H[1][j]; if (hj.a === hi.a || hj.a === hi.b || hj.b === hi.a || hj.b === hi.b) continue; if (a > b) W[base + j] += w; else if (a === b) T[base + j] += w; else L[base + j] += w; } } };
      const w1 = 1 / (48 - board.length);
      for (const c of nextCards(board)) { const b1 = board.concat(c); if (b1.length === 5) add(b1, w1); else { const w2 = w1 / (48 - b1.length); for (const c2 of nextCards(b1)) add(b1.concat(c2), w2); } }
      const E = { W, T, L }; equity.set(key, E); equityBytes += bytes; return E;
    }
    function removeCard(p, r, dead, c) {
      const r2 = take(r.length); r2.set(r); for (const j of holding[1 - p][c]) r2[j] = 0;
      const d2 = Uint8Array.from(dead); for (const i of holding[p][c]) d2[i] = 1; return [r2, d2];
    }
    const boardKey = (board) => board.slice(board0.length).join('.');
    const b0 = board0.length, ctxOf = (board) => { let x = 0; for (let i = b0; i < board.length; i++) x = x * 53 + board[i] + 1; return x; };
    const keyOf = (node, board) => node.id * 4096 + ctxOf(board);   // numeric (node, public-card suffix) key: 53 x 53 < 4096
    /** Strategy matrix of seat at node on board (Array of Float64Array[k] per hand). */
    function rowsAt(S, node, seat, board) { if (S.rows) return S.rows(node, seat, board); const out = new Array(H[seat].length); for (let i = 0; i < out.length; i++) out[i] = S.get(node, seat, i, board); return out; }
    /** Value vector for p (per own hand, opponent-weighted) under S; br: p best-responds at every one of its information sets. */
    function walk(node, p, r, S, br, board, dead) {
      tick();
      if (node.kind === 'terminal') return termValues(node, p, r, board, dead);
      const n = H[p].length;
      if (node.kind === 'chance') {
        const out = new Float64Array(n), cw = 1 / (48 - board.length);
        for (const c of nextCards(board)) { const [r2, d2] = removeCard(p, r, dead, c); const v = walk(node.child, p, r2, S, br, board.concat(c), d2); for (let i = 0; i < n; i++) out[i] += cw * v[i]; }
        return out;
      }
      if (node.seat === p) {
        const rows = br ? null : rowsAt(S, node, p, board), out = new Float64Array(n); if (br) out.fill(-Infinity);
        for (let a = 0; a < node.k; a++) { const v = walk(node.children[a], p, r, S, br, board, dead); for (let i = 0; i < n; i++) { if (br) { if (v[i] > out[i]) out[i] = v[i]; } else out[i] += rows[i][a] * v[i]; } }
        if (br) for (let i = 0; i < n; i++) if (dead[i]) out[i] = 0;
        return out;
      }
      const q = 1 - p, rows = rowsAt(S, node, q, board), out = new Float64Array(n);
      for (let a = 0; a < node.k; a++) { const r2 = new Float64Array(r.length); let any = false; for (let j = 0; j < r.length; j++) { r2[j] = r[j] * rows[j][a]; if (r2[j]) any = true; } if (!any) continue; const v = walk(node.children[a], p, r2, S, br, board, dead); for (let i = 0; i < n; i++) out[i] += v[i]; }
      return out;
    }
    const wsum = (() => { const comp = compOnly(0, Float64Array.from(H[1], (h) => h.w)); let s = 0; for (let i = 0; i < H[0].length; i++) s += H[0][i].w * comp[i]; return s; })();
    ok(wsum > 0, 'No compatible deals: ranges are empty after card removal');
    function evaluate(S) {
      const values = [0, 0], brs = [0, 0];
      for (let p = 0; p < 2; p++) {
        const r = Float64Array.from(H[1 - p], (h) => h.w), d = new Uint8Array(H[p].length);
        const v = walk(g.tree, p, r, S, false, board0, d), b = walk(g.tree, p, r, S, true, board0, d);
        for (let i = 0; i < H[p].length; i++) { values[p] += H[p][i].w * v[i] / wsum; brs[p] += H[p][i].w * b[i] / wsum; }
      }
      const gains = brs.map((b, p) => b - values[p]), nashConv = gains[0] + gains[1];
      return { players: 2, values, bestResponses: brs, gains, nashConv, exploitability: nashConv / 2, exploitabilityPctPot: nashConv / 2 / g.common * 100, commonPot: g.common, constantSum: +(values[0] + values[1]).toFixed(9),
        streets: streetsOf(), method: 'vectorised exact multi-street (every turn/river card enumerated; sorted showdown, inclusion-exclusion card removal)' };
    }
    function streetsOf() { const s = new Set(); const v = (n) => { if (n.kind === 'player') { s.add(n.street); n.children.forEach(v); } else if (n.kind === 'chance') v(n.child); }; v(g.tree); return [...s].sort().map((l) => (l === 3 ? 'flop' : l === 4 ? 'turn' : 'river')); }
    /** Accessor over a trained game or a linked record: missing rows are uniform and COUNTED (never silently treated as solved). */
    function strategyOf(gameLike) {
      const cache = new Map(), missing = new Set(); let lookups = 0;
      const one = (node, seat, i, board) => {
        lookups++; const r = H[seat][i].row; if (board.includes(r[1]) || board.includes(r[2])) return new Float64Array(node.k).fill(1 / node.k);
        const s = gameLike.averageAt(node.path, board, seat, { id: r[0], a: r[1], b: r[2], w: r[3] });
        if (!s) { missing.add(node.path + '|' + boardKey(board) + '|' + seat + '|' + i); return new Float64Array(node.k).fill(1 / node.k); } return Float64Array.from(s);
      };
      const rows = (node, seat, board) => { const key = keyOf(node, board); let a = cache.get(key); if (a) return a; a = new Array(H[seat].length); for (let i = 0; i < a.length; i++) a[i] = one(node, seat, i, board); if (cache.size > (o.strategyCacheEntries || 200000)) cache.clear(); cache.set(key, a); return a; };
      return { missing, get lookups() { return lookups; }, rows, get(node, seat, i, board) { return rows(node, seat, board)[i]; } };
    }
    function exact(gameLike) { const S = strategyOf(gameLike || game), t0 = Date.now(); const r = evaluate(S); return { ...r, treeNodes: g.nodes, hands: [H[0].length, H[1].length], missingRows: S.missing.size, evalMs: Date.now() - t0 }; }

    /** Information-set count and memory needed by full-width CFR+ (regret + average per hand per action per board). */
    function estimateBytes() {
      let cells = 0; const rec = (n, boards) => { if (n.kind === 'player') { cells += boards * H[n.seat].length * n.k; n.children.forEach((c) => rec(c, boards)); } else if (n.kind === 'chance') rec(n.child, boards * (48 - n.street)); };
      rec(g.tree, 1); return { cells, bytes: cells * 16 + cells * 2 };
    }

    /** Full-width two-player CFR+ (alternating, RM+, linear averaging) with chance enumeration. Cancellable (o.signal), bounded by
     *  o.maxBytes (refused up front) and o.deadline (stops between iterations with the best evaluated average so far). */
    function cfrPlus(iterations, so = {}) {
      const est = estimateBytes(); if (so.maxBytes && est.bytes > so.maxBytes) throw new SolveLimit('memory-limit', 'Full-width solve needs about ' + Math.round(est.bytes / 1048576) + ' MiB, above the ' + Math.round(so.maxBytes / 1048576) + ' MiB limit');
      const reg = new Map(), avg = new Map();
      // flat per-(node, public cards) tables: hand i, action a at [i * k + a]
      const slot = (m, node, p, board) => { const key = keyOf(node, board); let a = m.get(key); if (!a) { a = new Float64Array(H[p].length * node.k); m.set(key, a); } return a; };
      const curMemo = new Map(), curOf = (node, seat, board) => {
        const key = keyOf(node, board); let c = curMemo.get(key); if (c) return c;
        const R = slot(reg, node, seat, board), k = node.k, n = H[seat].length; c = new Float64Array(n * k);
        for (let i = 0; i < n; i++) { let t = 0; for (let a = 0; a < k; a++) t += R[i * k + a]; for (let a = 0; a < k; a++) c[i * k + a] = t > 0 ? R[i * k + a] / t : 1 / k; }
        curMemo.set(key, c); return c; };
      const normRow = (A, i, k) => { let s = 0; for (let a = 0; a < k; a++) s += A[i * k + a]; const out = new Float64Array(k); for (let a = 0; a < k; a++) out[a] = s > 0 ? A[i * k + a] / s : 1 / k; return out; };
      const Savg = { get(node, seat, i, board) { const A = avg.get(keyOf(node, board)); if (!A) return new Float64Array(node.k).fill(1 / node.k); return normRow(A, i, node.k); },
        rows(node, seat, board) { const A = avg.get(keyOf(node, board)), n = H[seat].length, out = new Array(n); for (let i = 0; i < n; i++) out[i] = A ? normRow(A, i, node.k) : new Float64Array(node.k).fill(1 / node.k); return out; }, averageAt: null };
      const curve = []; let done = 0, stopped = null, lastEval = null;
      const t0 = Date.now();
      try {
        for (let t = 1; t <= iterations; t++) {
          if (so.signal && so.signal.aborted) throw new SolveCancelled('Solve cancelled');
          if (so.deadline && Date.now() > so.deadline && done > 0) { stopped = 'time-limit'; break; }
          for (let p = 0; p < 2; p++) {
            curMemo.clear();
            const upd = (node, r, board, dead) => {
              tick();
              if (node.kind === 'terminal') return termValues(node, p, r, board, dead);
              const n = H[p].length;
              if (node.kind === 'chance') { const out = take(n), cw = 1 / (48 - board.length); for (const c of nextCards(board)) { const [r2, d2] = removeCard(p, r, dead, c); const v = upd(node.child, r2, board.concat(c), d2); for (let i = 0; i < n; i++) out[i] += cw * v[i]; give(v); give(r2); } return out; }
              if (node.seat === p) {
                const cur = curOf(node, p, board), vals = [], out = take(n);
                const k = node.k; for (let a = 0; a < k; a++) { const v = upd(node.children[a], r, board, dead); vals.push(v); for (let i = 0; i < n; i++) out[i] += cur[i * k + a] * v[i]; }
                const R = slot(reg, node, p, board); for (let i = 0; i < n; i++) { if (dead[i]) continue; for (let a = 0; a < k; a++) { const x = R[i * k + a] + vals[a][i] - out[i]; R[i * k + a] = x > 0 ? x : 0; } }
                for (const v of vals) give(v);
                return out;
              }
              const q = 1 - p, cur = curOf(node, q, board), out = take(n);
              for (let a = 0; a < node.k; a++) { const r2 = take(r.length); let any = false; for (let j = 0; j < r.length; j++) { r2[j] = r[j] * cur[j * node.k + a]; if (r2[j]) any = true; } if (any) { const v = upd(node.children[a], r2, board, dead); for (let i = 0; i < n; i++) out[i] += v[i]; give(v); } give(r2); }
              return out;
            };
            give(upd(g.tree, Float64Array.from(H[1 - p], (h) => h.w), board0, new Uint8Array(H[p].length)));
            curMemo.clear(); const q = 1 - p;
            const acc = (node, reach, board) => {
              if (node.kind === 'terminal') return;
              if (node.kind === 'chance') { for (const c of nextCards(board)) { const r2 = take(reach.length); r2.set(reach); for (const j of holding[q][c]) r2[j] = 0; acc(node.child, r2, board.concat(c)); give(r2); } return; }
              if (node.seat === q) { const cur = curOf(node, q, board), A = slot(avg, node, q, board), k = node.k; for (let j = 0; j < reach.length; j++) if (reach[j]) for (let a = 0; a < k; a++) A[j * k + a] += t * reach[j] * cur[j * k + a]; for (let a = 0; a < k; a++) { const r2 = take(reach.length); for (let j = 0; j < reach.length; j++) r2[j] = reach[j] * cur[j * k + a]; acc(node.children[a], r2, board); give(r2); } }
              else for (let a = 0; a < node.k; a++) acc(node.children[a], reach, board);
            };
            acc(g.tree, new Float64Array(H[q].length).fill(1), board0);
          }
          done = t;
          if (so.every && (t % so.every === 0 || t === iterations)) { lastEval = evaluate(Savg); curve.push({ iterations: t, exploitability: lastEval.exploitability, ms: Date.now() - t0 }); if (so.onCheckpoint) so.onCheckpoint(t, lastEval); if (so.target !== undefined && lastEval.exploitability <= so.target) { stopped = 'target-reached'; break; } }
        }
      } catch (e) { if (e instanceof SolveLimit && e.code === 'time-limit' && done > 0) stopped = 'time-limit'; else throw e; }
      const final = (lastEval && curve.length && curve[curve.length - 1].iterations === done) ? lastEval : evaluate(Savg);
      // An information set the player never reaches with positive probability has no average (zero weight). Its play cannot change any
      // value; full-width CFR+ defines it by the current regret-matched strategy (uniform when regrets are all zero), so the solve is complete.
      const idx = [0, 1].map((p) => new Map(H[p].map((h, i) => [h.row[0], i]))), byPathNode = new Map(); (function walkP(x) { if (x.kind === 'player') { byPathNode.set(x.path, x); x.children.forEach(walkP); } else if (x.kind === 'chance') walkP(x.child); })(g.tree);
      const S = { get: Savg.get, rows: Savg.rows, averageAt(path, board, seat, hand) { const nd = byPathNode.get(path); if (!nd) return null; const key = keyOf(nd, board), i = idx[seat].get(hand.id); if (i === undefined) return null; const A = avg.get(key), R = reg.get(key); if (!A && !R) return null;
        const k = nd.k; let s = 0; if (A) for (let a = 0; a < k; a++) s += A[i * k + a]; if (s > 0) return Float64Array.from({ length: k }, (_, a) => A[i * k + a] / s);
        let t = 0; if (R) for (let a = 0; a < k; a++) t += R[i * k + a]; return Float64Array.from({ length: k }, (_, a) => (t > 0 ? R[i * k + a] / t : 1 / k)); } };
      return { ...final, iterations: done, requestedIterations: iterations, stopped: stopped || 'complete', curve, strategy: S, solveMs: Date.now() - t0, estimate: est, informationSets: avg.size, method: 'vectorised full-width CFR+ with chance enumeration (alternating, RM+, linear averaging)' };
    }
    return { tree: g, hands: H, wsum, evaluate, exact, strategyOf, cfrPlus, estimateBytes, boardKey };
  }
  const exact = (game, spec, o) => prepare(game, spec, o).exact(game);
  return { buildTree, prepare, exact, SolveCancelled, SolveLimit };
});
