'use strict';
/* EightMax Test Workbench 0.31: shared directory of stored strategy fingerprints (lock-free, single writer, many readers).
 * Layout (Int32Array over a SharedArrayBuffer): [0] generation, [1] count, [2] capacity, [3] reserved, then `capacity` slots of
 * two int32 words (hi, lo) = the first 64 bits of the SHA-256 fingerprint; (0,0) marks an empty slot. Linear probing.
 * The writer stores lo then hi with Atomics.store; a reader that sees hi != 0 is guaranteed to see the matching lo (sequentially
 * consistent atomics). Entries are never removed (records are immutable; a replaced record keeps its fingerprint).
 * The directory is only a HINT used to skip round trips for misses: "present" is always followed by the full checked fetch,
 * and "absent" is reported as a library miss (the safe outcome) even if a record was stored a moment ago. */
const HEADER = 4;
function keyOf(fp) { let hi = parseInt(fp.slice(0, 8), 16) | 0, lo = parseInt(fp.slice(8, 16), 16) | 0; if (hi === 0) hi = 1; return [hi, lo]; }
class Directory {
  /** sab: SharedArrayBuffer from Directory.create(capacity) (or an existing one). */
  constructor(sab) { this.a = new Int32Array(sab); this.cap = this.a[2]; this.sab = sab; }
  static create(capacity = 1 << 17) { const cap = 1 << Math.ceil(Math.log2(Math.max(16, capacity))), sab = new SharedArrayBuffer((HEADER + 2 * cap) * 4); const a = new Int32Array(sab); a[2] = cap; return new Directory(sab); }
  _slot(hi, lo) { return (((hi ^ (lo * 0x9e3779b1)) >>> 0) & (this.cap - 1)); }
  /** Writer only. Returns false when the directory is full (then readers fall back to asking the service). */
  add(fp) {
    const [hi, lo] = keyOf(fp); let i = this._slot(hi, lo);
    for (let n = 0; n < this.cap; n++, i = (i + 1) & (this.cap - 1)) {
      const o = HEADER + 2 * i, h = Atomics.load(this.a, o);
      if (h === hi && Atomics.load(this.a, o + 1) === lo) return true;
      if (h === 0) { if (Atomics.load(this.a, 1) >= this.cap * 0.75) { this.full = true; return false; } Atomics.store(this.a, o + 1, lo); Atomics.store(this.a, o, hi); Atomics.add(this.a, 1, 1); return true; }
    }
    return false;
  }
  /** Reader: true = a record with this 64-bit prefix is stored (verify by fetching); false = not stored (as of the last refresh). */
  has(fp) {
    const [hi, lo] = keyOf(fp); let i = this._slot(hi, lo);
    for (let n = 0; n < this.cap; n++, i = (i + 1) & (this.cap - 1)) { const o = HEADER + 2 * i, h = Atomics.load(this.a, o); if (h === 0) return false; if (h === hi && Atomics.load(this.a, o + 1) === lo) return true; }
    return false;
  }
  bump() { Atomics.add(this.a, 0, 1); }
  generation() { return Atomics.load(this.a, 0); }
  count() { return Atomics.load(this.a, 1); }
  nearlyFull() { return Atomics.load(this.a, 1) >= this.cap * 0.75; }
}
module.exports = { Directory, keyOf };
