# Eight-handed preflop research (0.32)

Tools: `src/preflop-research.js`, `src/preflop-snapshot.js`, `tools/preflop-research-032.cjs`, `RUN-PREFLOP-RESEARCH.cmd`, dashboard
panel **Research**. Results: `reports/0.32-preflop-research.json`.

## The study
Eight seats, equal 25 BB stacks, SB 0.5 / BB 1 / ante 0.1 BB per player (classic), chip EV, linked preflop tree (fold / call / open
2.2 / all-in, up to 3 bets) **continuing to the river** with single-size postflop menus (bet 50%, raise all-in, 1 bet per street).
Every seat starts from all 1,326 combinations. Trainer: EightMax 5.1 external-sampling MCCFR (linear weighting, standard regret
matching; opponent sampling q = 0.9 sigma + 0.1/k), exact private-hand keys. ICM: the native engine supports ICM utilities, but no ICM
preflop study was run or verified in 0.32; reports are chip EV.

## What is measured, and what each number means
| Measure | Kind | How |
|---|---|---|
| Stored rows per preflop decision state, states with no row | **exact count** | read from the native state (`StrategyStore`) |
| Node reach, reach-weighted combination / hand-class coverage, per position | **sampled estimate** | Monte-Carlo line sampling from the stored strategy (fixed seed) |
| Missing strategy branches | sampled reach + exact counts | reachable states (reach >= 0.1%) where some hand class has no row |
| Range support of derived flop ranges | **sampled estimate** (+ binomial 95% interval) | identical to the 0.31 measurement (`tools/range-support-031.cjs`) |
| First-in deviation gain per position | **sampled estimate of a lower bound**, 95% interval | `mwcli --gain method=sampled` at each position's first-in node: the best one-shot deviation of every hand there, later play following the study |
| Restricted best response (all preflop decisions of one seat) | lower bound | `mwcli --verify method=restricted` - **not feasible here**: 8 seats did not finish in 15 minutes even at 2,000 samples (the engine reports the time-out; nothing is reported as a value) |
| Seed stability | distance, not accuracy | `mwcli --compare` between seeds (8-player equilibria need not be unique) |
| Full eight-handed exploitability / NashConv | **unavailable** | not computed; never reported as zero |

Two-player formulas are never applied: the deviation gain is a per-seat unilateral gain inside the study's abstraction.

## Training modes
| Mode | Default | Purpose | What the name does NOT mean |
|---|---|---|---|
| Fast Reference Study | 200,000 updates, 1 seed | application testing | accuracy |
| Standard Research Study | 2,000,000 updates, seeds 8 and 108 | the 0.31 default length with full diagnostics | accuracy |
| High-Accuracy Research Study | from 2,000,000, doubling within the memory and time budget, 3 seeds | continue until **measured** targets (reach-weighted class coverage >= 99.5% and restricted-gain upper bound <= 0.05 bb) are met | it is reported as meeting its targets only when the measurements do |

Continuation (`continueFromSmaller`) resumes the largest complete shorter state of the same study; a resumed run is bit-identical to an
uninterrupted run of the same length (`tests/preflop-032`). The planner's memory budget bounds every run; a run that fills it is
reported as *memory-limited* with the updates actually done, never as complete.

## Research variants (native-only trainer settings, used only for research studies)
* `explore20` - opponent exploration 0.2 instead of 0.1 (samples rare actions more often).
* `ownenum` - own-hand enumeration (every hand of the updating seat per deal). Measured: 5,000 updates took 35 s and produced a 1.44 GB
  state (combination coverage 92.7% vs 89.0% for 2M baseline updates) - impractical at the lengths needed, not used further.

## Findings (numbers in reports/0.32-preflop-research.json and docs/0.32-validation-report.md sections C-D)
* The linked study's memory grows with training because postflop rows keep being added: 2M updates = 1.18 GB state / 2.8 GB while
  training; with an 8 GiB budget the run stopped at 3.80M updates (5.0 GB table, 6.5 GB RSS). About 4M updates is the practical limit
  of this study design on a 16 GB machine.
* Share of the deviation evaluation's later lookups that hit never-visited rows (uniform fallback), 2M updates: 20-35% at the UTG-HJ
  first-in nodes, 28-35% at CO/BTN, 97% at the SB and BB first-in nodes (500k: 32-76% and 99%). The postflop part of the linked study is
  sparse, and the late-position preflop strategies are trained against largely untrained continuation play.
* Per-position first-in deviation gains (1,000 evaluation samples): early positions are not resolved at this sample size (95% intervals
  include zero); later positions are. At 2M updates the best deviation at the BTN first-in node gains 1.67 bb each time the node is
  reached (0.053 bb per hand overall, 95% interval 0.027-0.078): the stored strategy is measurably not an equilibrium there.
