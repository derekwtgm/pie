# On-demand heads-up turn solving (0.32)

`src/fast-multistreet.js` `cfrPlus()` solves a heads-up turn study (turn + every river card) by full-width CFR+ (alternating updates,
regret matching+, linear averaging) on per-hand vectors, with exact chance enumeration. It is used by
`adaptive-training.js` (trainer `vector-cfr-plus` on a heads-up turn) and therefore by Study Mode, the precompute queue and the
opt-in on-demand path of the decision engine.

* **Exactness.** The stored strategy is re-evaluated from the linked record bytes that are stored (`Q.evaluateLinked`), so the quality
  status describes exactly what is used. Information sets that a player never reaches get the current regret-matched strategy
  (value-neutral; this makes the solve complete, `missingRows = 0`).
* **Bounds.** Memory is estimated before solving (`estimateBytes()`, regret + average per hand per action per board) and the solve is
  **refused** above `turnMaxBytes` (default 768 MiB) - never approximated. Time is bounded by `maxTimeMs` (decision path:
  `inlineTurnMaxMs`, default 8 s); a time-limited solve stops between iterations and is classified by its measured exploitability
  (validated only if it meets the policy). Cancellation (`AbortSignal`) stops it with code `cancelled`.
* **Modes** (brief section 7): *Interactive research* - Study Mode / RUN-TURN-SOLVER-CHECK.cmd, no action deadline. *Cached decision* -
  a stored validated turn record is read like any library record. *Controlled simulation* - `inlineHeadsUpTurn: true` solves a
  missing heads-up turn inside the decision within `inlineTurnMaxMs`, labelled `solved-on-demand`; **off by default**.
* **Turn identities.** A turn trained by `vector-cfr-plus` has a different identity (training policy) from a 0.31 fixed-count turn record,
  so the two never substitute for each other.

Performance (development container, one core, `reports/0.32-turn-solver-benchmark.json`): see the report for every configuration. In
short, narrow and medium ranges reach the 1% research limit in seconds; any-two-cards ranges with deep stacks need minutes and can
exceed the decision deadline - those stay unavailable in the decision path rather than being approximated.

Implementation notes: integer (node, public-card suffix) keys, flat regret/average tables, a buffer pool for the hot path and
runout-equity matrices for pre-river all-ins made the solver about 4x faster than the first version with identical results.
