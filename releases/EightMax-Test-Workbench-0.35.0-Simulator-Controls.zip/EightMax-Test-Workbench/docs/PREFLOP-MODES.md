# Preflop solver modes A, B, B169, C and the Mode D comparison (0.33)

Code: `src/preflop-compact.js`, `tools/preflop-modes-033.cjs` (training, anatomy, coverage, gains, comparisons),
`tools/state-anatomy-033.cjs`, `tools/preflop-reach-coverage-033.cjs`, `tools/checkdown-calibration-033.cjs`.
Launchers: `RUN-PREFLOP-MODES.cmd`, `RUN-033-ACCEPTANCE.cmd`. Reports: `reports/0.33-preflop-modes.json`,
`reports/0.33-preflop-memory.json`, `reports/0.33-checkdown-calibration.json`.

Common game: eight seats, equal 25 bb stacks (configurable), SB 0.5 / BB 1 / classic ante 0.1 bb per player, **chip EV** (no ICM in
these modes), the 0.32 preflop tree (fold / limp / open 2.2 / all-in, 3x raises, at most 3 bets), every seat starts from all 1,326
combinations. Engine: EightMax 5.1 `mwcli`, **unchanged** (build 7d08acc7eb4577ee): the modes are game definitions, not engine changes.

## 1. Where the memory went (measured, `tools/state-anatomy-033.cjs`)

Mode A at 2,000,000 updates (seed 8): 23.3 million information-set rows, 1,176 MB state, 2,864 MiB peak RSS.

* 51 % of the rows are postflop rows (flop 0.59 M, turn 0.25 M, river 0.18 M at 200,000 updates; the share grows with training).
* **99.98 % of the postflop rows are the only row of their (betting state, exact board) context**: each was created by one sampled
  deal and is essentially never visited again. They do not give the preflop strategy a trained continuation (0.32 measured 20–97 %
  of later lookups hitting never-visited rows); they only cost memory.
* The other half are preflop rows of a very large, sparsely visited betting tree (about 600,000 preflop states with rows; most
  deep states hold a handful of hands).
* Engine profile (mwcli seconds): traversal 87 %, deal sampling 6 %, merging 7 %; hand scoring 0.3–0.4 % (`gpuStageBound`), so a GPU
  could save at most 0.4 % of preflop training time - no GPU work was done for preflop training.

## 2. The modes

| Mode | Game after preflop betting closes | Keys | What it is |
|---|---|---|---|
| A full-linked | flop, turn and river with one 50 %-pot bet each (fold / call), as in 0.32 | exact hands | the 0.32 reference, unchanged (same study id, same cached studies) |
| B checkdown | no postflop betting: the board is dealt and hands go to showdown (side pots by contribution) | exact hands | **approximate** continuation |
| B169 checkdown-class | as B | 169 hand classes | **approximate** continuation; class keys are lossless *for this game* (below) |
| C restricted-flop | Mode A's flop betting round, then check-down turn and river | exact hands | **approximate** continuation |
| D comparison | - | - | identical seeds / updates through the modes; resources, coverage, stability, distances, deviation gains |

Why class keys are lossless in Mode B: with no postflop decisions, a seat's only information is its own two cards and the public
preflop actions; the deck and every rule are symmetric under suit permutations, so two suit-isomorphic hands face isomorphic
situations and have identical action values against any profile that is constant on classes. An equilibrium of the class-keyed game
is therefore an equilibrium of Mode B. Deals, card removal and showdowns still use the physical cards. (With postflop decisions the
engine's grouping would also group postflop hands - lossy - so B169 is only offered with the check-down continuation.)

## 3. Resources (same machine, same seeds, 2,000,000 updates, single-thread training)

| Mode | Peak RSS | State | EMZ checkpoint | Rows | Updates/s |
|---|---|---|---|---|---|
| A | 2,864 MiB | 1,176 MB | 501 MB | 23.3 M | 7,503 |
| B | 1,488 MiB | 605 MB | 301 MB | 11.6 M | 8,752 |
| B169 | 904 MiB | 310 MB | 153 MB | 5.9 M | 6,830 |
| C | 2,654 MiB | 891 MB | 411 MB | 17.5 M | 8,079 |

Mode C saves little: the flop rows alone are as sparse as all postflop rows of Mode A. **B169 continued to 8,000,000 updates in a
1,415 MiB peak (557 MB state)** - four times Mode A's 2M training in half its memory (0.32: Mode A stopped near 3.8 M updates at
6.5 GB on a 16 GB budget), and on to **10,000,000 updates - the EightMax 5.1 per-study limit (a 16M request is refused by the engine) -
in a 1,734 MiB peak (603 MB state)**. Continuing a study is bit-identical to an uninterrupted run (test: 8k + 8k = 16k, class-keyed layout).
The shared preflop snapshot of B169@2M is 151 MB (class-keyed format version 2) against 264 MB for Mode A in 0.32.

## 4. Accuracy evidence (each mode inside ITS OWN game; nothing here is an eight-handed exploitability)

**Reach-weighted availability** of the acting hand's own stored strategy (`tools/preflop-reach-coverage-033.cjs`, 20,000 sampled
deals, Wilson 95 % intervals): A@2M **89.3 %** [89.2, 89.4] (BB 71.9 %) - the 0.32 method gave 89.1 % for the same study -
B169@2M **97.7 %** [97.65, 97.78] (BB 94.8 %), above Mode A at 3.8 M updates (92.5 %); **B169@10M 99.6 %** [99.57, 99.63] (every position
>= 99.15 %) - above the 99.5 % coverage target of 0.32's High-Accuracy mode. Coverage is availability, not accuracy (`reports/0.33-preflop-reach-coverage.json`).

**First-in deviation gains** (`mwcli --gain method=sampled`, 2,000 evaluation samples, bb per hand dealt, 95 % intervals; a sampled
estimate of a LOWER bound; later play follows the same study and the same continuation model):

| Position | A @ 2M | B169 @ 2M | B169 @ 8M | B169 @ 10M |
|---|---|---|---|---|
| UTG | 0.038 [−0.743, 0.819] | −0.234 [−0.817, 0.348] | −0.236 [−0.643, 0.171] | −0.062 [−0.440, 0.315] |
| UTG+1 | −0.345 [−0.792, 0.102] | −0.722 [−1.142, −0.302] | −0.182 [−0.515, 0.152] | 0.101 [−0.216, 0.418] |
| MP | 0.041 [−0.220, 0.301] | −0.184 [−0.458, 0.091] | 0.035 [−0.194, 0.264] | −0.064 [−0.284, 0.156] |
| HJ | 0.055 [−0.062, 0.172] | −0.095 [−0.280, 0.090] | −0.166 [−0.322, −0.010] | 0.050 [−0.116, 0.217] |
| CO | 0.051 [−0.002, 0.104] | −0.100 [−0.212, 0.012] | −0.088 [−0.219, 0.043] | −0.053 [−0.179, 0.074] |
| BTN | **0.039 [0.021, 0.058]** | 0.010 [−0.030, 0.050] | −0.015 [−0.077, 0.047] | 0.011 [−0.051, 0.072] |
| SB | **0.0065 [0.0037, 0.0093]** | −0.021 [−0.043, 0.002] | −0.031 [−0.070, 0.008] | −0.033 [−0.067, 0.002] |
| BB | **0.0026 [0.0017, 0.0034]** | 0.006 [−0.004, 0.017] | 0.006 [−0.019, 0.032] | −0.014 [−0.041, 0.012] |
| later lookups hitting unvisited rows | 20 % (UTG) – 97 % (BB) | 2 – 32 % | 1 – 24 % | — |

Mode A has measurable profitable deviations at BTN, SB and BB (reproduces 0.32). B169 shows none whose interval excludes zero at 2M,
8M or 10M. Negative estimates are possible because the deviation is selected and evaluated on separate samples (the estimator is
biased low); intervals that include zero are **not resolved**, not "zero".

**Strategy distances** at the first-in nodes (mean total variation, combination-weighted): seed-to-seed noise A 0.08–0.18,
B 0.07–0.18, B169 0.10–0.33; A vs B 0.08–0.18 and A vs C 0.08–0.18 (not distinguishable from noise at 2M); **B169 vs every
exact-key mode 0.23–0.50**, although B and B169 are the same game. Interpretation (stated as such): exact-key rows are each sampled
about eight times less often, so their averages stay closer to the uniform starting strategy (Mode A plays 34 % of 72o on the
button at 2M; B169 folds it 100 %). Distances are stability measures, never accuracy (eight-player equilibria need not be unique).

## 5. How wrong is the check-down continuation? (calibration)

`tools/checkdown-calibration-033.cjs`: heads-up flop after BTN opens 2.2 and BB calls (pot 5.7 bb, 22.7 bb behind), research-assumption
ranges (BTN TT+,AJ+,KQ,ATs+,KTs+,QTs+,JTs,T9s,98s; BB 99-55,AT-A8,KJ-KT,QJ,QTs,JTs,T9s,98s,87s,76s - manually specified, not derived
from a strategy). Strategic value = exact CFR+ equilibrium of the flop game with Mode A's menu (exploitability 0.38–0.41 % of the
pot, evaluated independently); check-down value = the same flop and ranges with no betting.

| Flop | BB (out of position): equilibrium / check-down / realised | BTN (in position) |
|---|---|---|
| As7d2h | 1.465 / 2.245 bb / 65 % | 4.235 / 3.455 bb / 123 % |
| Kh9h4c | 1.197 / 2.128 bb / 56 % | 4.503 / 3.572 bb / 126 % |
| 8s8d3c | 1.975 / 2.364 bb / 84 % | 3.725 / 3.336 bb / 112 % |

Mean absolute error **12.3 % of the pot** per player (0.70 bb here); the out-of-position caller realises 68 % of its check-down
value, the in-position opener 120 %. **Consequence:** Modes B/B169 misprice position and initiative by a large, measured amount, which
is why they are labelled approximate. Their strategies differ qualitatively from Mode A (for example B169 limps AA on the button
83 % of the time at 2M - an artifact of a game with no postflop betting). They are useful for measuring and reducing *sampling*
error, coverage and memory at large training lengths; they are not a substitute for strategic postflop play. A corrected terminal
(e.g. position-dependent realisation) would need calibration across many lines and stack depths and was not implemented.
