# Shared preflop strategy memory (0.32)

## Problem (measured)
Every table worker opened the native preflop state with the lazy reader (`src/strategy-store.js`). The reader's index covers the
whole linked tree (preflop through the river): 5.6 million states for the 500,000-update study, about 220 MB of typed arrays, plus a
64 MB row cache - per worker. With four workers and the 2,000,000-update study the process peaked at **4.3-4.5 GB** (identical
workload, `reports/0.32-memory-comparison.json`).

## Design
`src/preflop-snapshot.js` extracts the preflop information sets **once** into one immutable buffer:
state table (parent, slot, actor, k, row/value offsets), child index, sorted range-row keys (u16) and the **normalised** average
strategy of every row as IEEE-754 doubles computed exactly like `StrategyStore.averageAt` - answers are bit-for-bit identical
(`tests/preflop-032`, every stored row of a study compared).

* `tools/train-study.cjs preflopSnapshotFor()` builds or loads it (cached as `<state>.emps`; rebuilt when the state's row CRC or update
  count differs; a fast path loads a valid cached snapshot without opening the whole-tree index) into a **SharedArrayBuffer**.
* The main thread passes it to workers through `workerData` (structured clone shares a SharedArrayBuffer; nothing is copied).
  `preparedFromSnapshot()` builds each worker's lookup game over views of that memory.
* **Immutability / no data races:** the buffer is written once before any worker exists and only read afterwards (all access goes
  through read-only accessors; there are no writers), so no locking is needed.
* **Integrity and identity:** SHA-256 of the body in the header (verified on load; corruption -> `checksum`); workers can require the
  expected fingerprint (`expect: {bodySha256, studyId}` -> `identity-mismatch`).
* **Crash recovery:** a crashed worker is replaced by a new worker that receives the same intact buffer (`tests/preflop-032`).
* **Clean shutdown:** workers drop their views; the buffer is freed with the main thread's last reference.

## Measured result (identical workload: workload B, 10 hands/table, 4 workers, 2M-update study)
| Tables | 0.31 path peak RSS | 0.32 shared | Decisions identical |
|---|---|---|---|
| 1 | 1,274 MB | 474 MB | yes |
| 2 | 2,382 MB | 670 MB | yes |
| 5 | 4,286 MB | 955 MB | yes |
| 8 | 4,468 MB | 937 MB | yes |
| 10 | 4,463 MB | 938 MB | yes |

The shared snapshot of the 2M study is 264 MB (one copy for all workers). The 0.31 report's estimate of ~2.5 GB savings is exceeded:
about 3.5 GB at 10 tables on this machine. Retrieval of postflop library records (the v2 strategy service) is unchanged.
Enable it with `--sharedPreflop=1` in `tools/benchmark-032.cjs` or `preflopSnapshot` in the solver factory options.
