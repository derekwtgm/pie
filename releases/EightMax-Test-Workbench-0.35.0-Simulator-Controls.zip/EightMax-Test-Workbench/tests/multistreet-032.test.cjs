'use strict';
// 0.32: exact heads-up multi-street evaluation (src/fast-multistreet.js) checked against an independent brute-force joint-deal
// enumeration (every pair of hands x every runout, scalar recursion), plus CFR+ convergence, cancellation and resource limits.
const test = require('node:test'), assert = require('node:assert');
const EM = require('./load-solver.cjs'), A = require('../src/study-adapter.js'), X = require('../src/exploitability.js'), MS = require('../src/fast-multistreet.js'), FR = require('../src/fast-river.js');

const TURN = { board: 'AhKd7c2s', common: 6, stacks: [12, 12], ranges: ['AA,KK,77,AK,KQs,T9s', 'AA,KK,77,AK,KQs,T9s,65s'], streets: { turn: { bets: '50,a', raises: 'a', maxBets: 2 }, river: { bets: '75,a', raises: 'a', maxBets: 2 } }, privateSeed: 3 };
function trained(cfg, updates) { const p = A.prepare(EM, { config: cfg, iterations: updates }); p.game.iterate(updates); return p; }

/** Independent scalar evaluator: enumerate joint deals and runouts, follow the betting tree, best response per (hand, public cards). */
function bruteForce(prep, gameLike) {
  const T = MS.buildTree(prep.game, prep.spec), board0 = T.board;
  const rows = T.hands.map((rs) => rs.filter((r) => !board0.includes(r[1]) && !board0.includes(r[2])));
  const get = (node, seat, r, board) => { const s = gameLike.averageAt(node.path, board, seat, { id: r[0], a: r[1], b: r[2], w: r[3] }); return s ? Array.from(s) : new Array(node.k).fill(1 / node.k); };
  // value of the profile for (h0, h1)
  const val = (node, hs, board) => {
    if (node.kind === 'terminal') { if (node.live.filter(Boolean).length < 2 || board.length === 5) { const sc = hs.map((r, p) => (node.live[p] && board.length === 5 ? X.score7([...board, r[1], r[2]]) : null)); return X.payoff(node, sc, T.common); }
      const out = [0, 0], cards = []; for (let c = 0; c < 52; c++) if (!board.includes(c) && !hs.some((r) => r[1] === c || r[2] === c)) cards.push(c); for (const c of cards) { const v = val(node, hs, board.concat(c)); out[0] += v[0] / cards.length; out[1] += v[1] / cards.length; } return out; }
    if (node.kind === 'chance') { const out = [0, 0], cards = []; for (let c = 0; c < 52; c++) if (!board.includes(c) && !hs.some((r) => r[1] === c || r[2] === c)) cards.push(c); for (const c of cards) { const v = val(node.child, hs, board.concat(c)); out[0] += v[0] / cards.length; out[1] += v[1] / cards.length; } return out; }
    const s = get(node, node.seat, hs[node.seat], board), out = [0, 0]; for (let a = 0; a < node.k; a++) if (s[a]) { const v = val(node.children[a], hs, board); out[0] += s[a] * v[0]; out[1] += s[a] * v[1]; } return out;
  };
  let wsum = 0; const values = [0, 0]; const pairs = [];
  for (const r0 of rows[0]) for (const r1 of rows[1]) { if (new Set([r0[1], r0[2], r1[1], r1[2]]).size < 4) continue; const w = r0[3] * r1[3]; wsum += w; pairs.push([r0, r1, w]); }
  for (const [r0, r1, w] of pairs) { const v = val(T.tree, [r0, r1], board0); values[0] += w * v[0]; values[1] += w * v[1]; }
  // best response of p: own information set = (own hand, public cards, path); opponents weighted by reach
  const brs = [0, 0];
  for (let p = 0; p < 2; p++) {
    const br = (node, own, opp, board) => {   // opp: [[row, reach]] ; returns sum over opp of reach * value_p
      if (node.kind === 'terminal') { let s = 0; for (const [o, x] of opp) { if (!x) continue; const hs = p === 0 ? [own, o] : [o, own]; s += x * val(node, hs, board)[p]; } return s; }
      if (node.kind === 'chance') {   // the next card is public: best response may depend on it, so enumerate it outside the opponent sum
        let t = 0; for (let c = 0; c < 52; c++) { if (board.includes(c) || c === own[1] || c === own[2]) continue; const opp2 = opp.filter(([o]) => o[1] !== c && o[2] !== c).map(([o, x]) => [o, x / (48 - board.length)]); if (opp2.length) t += br(node.child, own, opp2, board.concat(c)); }
        return t;
      }
      if (node.seat === p) { let best = -Infinity; for (let a = 0; a < node.k; a++) best = Math.max(best, br(node.children[a], own, opp, board)); return best; }
      let t = 0; for (let a = 0; a < node.k; a++) { const o2 = opp.map(([o, x]) => [o, x * get(node, node.seat, o, board)[a]]).filter(([, x]) => x > 0); if (o2.length) t += br(node.children[a], own, o2, board); } return t;
    };
    for (const own of rows[p]) { const opp = rows[1 - p].filter((o) => new Set([own[1], own[2], o[1], o[2]]).size === 4).map((o) => [o, own[3] * o[3]]); if (opp.length) brs[p] += br(T.tree, own, opp, board0); }
  }
  return { values: values.map((v) => v / wsum), bestResponses: brs.map((v) => v / wsum) };
}

test('multi-street exact evaluation equals an independent brute-force enumeration (turn -> river, all-in runouts included)', () => {
  const cfg = { ...TURN, ranges: ['AA,77,KQs,T9s', 'KK,AK,65s,T9s'] };
  const p = trained(cfg, 3000), F = MS.prepare(p.game, p.spec, { verifyCards: 3 }), fast = F.exact(p.game), slow = bruteForce(p, p.game);
  for (let q = 0; q < 2; q++) { assert.ok(Math.abs(fast.values[q] - slow.values[q]) < 1e-9, 'value ' + q + ' ' + fast.values[q] + ' vs ' + slow.values[q]); assert.ok(Math.abs(fast.bestResponses[q] - slow.bestResponses[q]) < 1e-9, 'BR ' + q + ' ' + fast.bestResponses[q] + ' vs ' + slow.bestResponses[q]); }
  assert.ok(Math.abs(fast.values[0] + fast.values[1] - 6) < 1e-9, 'constant-sum: values add to the common pot');
  assert.deepStrictEqual(fast.streets, ['turn', 'river']);
  assert.ok(fast.exploitability >= 0);
});

test('on a river board the multi-street evaluator equals the 0.31 river evaluator', () => {
  const cfg = { board: 'AhKd7c2s9h', common: 6, stacks: [12, 12], ranges: ['AA,KK,77,AK,KQs,T9s', 'AA,KK,77,AK,KQs,T9s,65s'], streets: { river: { bets: '50,a', raises: 'a', maxBets: 2 } }, privateSeed: 4 };
  const p = trained(cfg, 2000), a = MS.prepare(p.game, p.spec).exact(p.game), b = FR.prepare(p.game, p.spec).exact(p.game);
  for (let q = 0; q < 2; q++) { assert.ok(Math.abs(a.values[q] - b.values[q]) < 1e-9); assert.ok(Math.abs(a.bestResponses[q] - b.bestResponses[q]) < 1e-9); }
});

test('multi-street CFR+ converges: exploitability falls with iterations and reaches a small fraction of the pot', () => {
  const p = trained(TURN, 10), F = MS.prepare(p.game, p.spec), r = F.cfrPlus(60, { every: 20 });
  assert.strictEqual(r.curve.length, 3); assert.ok(r.curve[2].exploitability < r.curve[0].exploitability, JSON.stringify(r.curve));
  assert.ok(r.exploitabilityPctPot < 1.0, 'below 1% of the pot after 60 iterations: ' + r.exploitabilityPctPot);
  // the returned strategy is an independent game-like object: re-evaluating it gives the same number
  const again = F.exact(r.strategy); assert.ok(Math.abs(again.exploitability - r.exploitability) < 1e-9); assert.strictEqual(again.missingRows, 0);
});

test('EightMax-trained turn studies get less exploitable with more updates (exact, whole turn+river game)', () => {
  const e = [2000, 40000].map((u) => { const p = trained(TURN, u); return MS.prepare(p.game, p.spec).exact(p.game); });
  assert.ok(e[1].exploitability < e[0].exploitability, e.map((x) => x.exploitability).join(' -> '));
});

test('turn solver: cancellation, time limit and memory limit are enforced and reported', () => {
  const p = trained(TURN, 10), F = MS.prepare(p.game, p.spec);
  const ac = new AbortController(); ac.abort(); assert.throws(() => F.cfrPlus(10, { signal: ac.signal }), (e) => e.code === 'cancelled');
  assert.throws(() => F.cfrPlus(10, { maxBytes: 1024 }), (e) => e.code === 'memory-limit');
  const r = F.cfrPlus(100000, { deadline: Date.now() + 300 }); assert.strictEqual(r.stopped, 'time-limit'); assert.ok(r.iterations >= 1 && r.iterations < 100000);
  assert.ok(F.estimateBytes().bytes > 0);
});

test('the betting geometry below a chance node is verified to be card-independent', () => {
  const p = trained(TURN, 10); const T = MS.buildTree(p.game, p.spec, { verifyCards: 6 }); assert.ok(T.decisions > 3);
});
