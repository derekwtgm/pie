'use strict';
/* 0.31 strategy abstraction: mapping definitions, exactness of suit isomorphism, measured EV loss of approximate mappings,
 * tree-compatibility refusal, river-blank construction, coverage accounting (exact / abstracted / on-demand / unavailable kept apart). */
const test = require('node:test'), assert = require('node:assert/strict');
const AB = require('../src/strategy-abstraction.js'), COV = require('../src/coverage.js'), SID = require('../src/strategy-identity.js');
const R = { river: { bets: '50,a', raises: 'a', maxBets: 2 } }, NAR = 'TT+,AJs+,KTs+,QJs,AQo+,KQo';
const cfg = (board, pot, stacks) => ({ board, common: pot, stacks, ranges: [NAR, NAR], streets: R, privateSeed: 1 });

test('every mapping is defined with what it preserves and loses; none is enabled for decisions by default', () => {
  for (const [name, m] of Object.entries(AB.MAPPINGS)) { assert.ok(m.definition && m.preserves && m.loses, name); assert.ok(['exact', 'approximate'].includes(m.kind)); }
  assert.equal(AB.MAPPINGS['suit-isomorphism'].kind, 'exact'); const t = { pot: 7, stacks: [13.3, 21] };
  assert.deepEqual(AB.MAPPINGS['stack-bucket-5'].map(t).stacks, [15, 20]); assert.equal(AB.MAPPINGS['chip-scale'].map(t).pot, 10); assert.ok(Math.abs(AB.MAPPINGS['chip-scale'].map(t).stacks[0] / 10 - 13.3 / 7) < 0.002);
});

test('suit isomorphism is exact: the relabelled strategy has the source solution\'s (tiny) exploitability in the target', () => {
  const perm = [1, 2, 3, 0], map = (c) => (c & ~3) | perm[c & 3], b = 'Kh9s5c3d2h'.match(/../g).map(SID.cardId), bs = b.map(map).map(SID.cardStr).join('');
  const r = AB.validatePair(cfg('Kh9s5c3d2h', 10, [20, 20]), cfg(bs, 10, [20, 20]), { iterations: 600, cardMap: map });
  assert.ok(r.compatible); assert.ok(r.evLossPctPot < 0.05, 'loss ' + r.evLossPctPot); assert.ok(r.actionL1VsTargetSolution < 0.05);
});

test('an approximate mapping is measured, not assumed: a 5 bb stack shift shows a positive EV loss', () => {
  const r = AB.validatePair(cfg('Kh9s5c3d2h', 10, [12, 12]), cfg('Kh9s5c3d2h', 10, [15, 15]), { iterations: 600 });
  assert.ok(r.compatible); assert.ok(r.evLossPctPot > r.exploitabilityOfTargetSolutionBB / 10 * 100, 'translated strategy is worse than the target\'s own solution');
});

test('incompatible trees are refused (different menu shape), never silently translated', () => {
  const a = cfg('Kh9s5c3d2h', 10, [20, 20]), b = { ...cfg('Kh9s5c3d2h', 10, [20, 20]), streets: { river: { bets: '50', raises: 'a', maxBets: 1 } } };
  const r = AB.validatePair(a, b, { iterations: 50 }); assert.equal(r.compatible, false); assert.match(r.reason, /menu|differ/);
});

test('river-blank substitution only produces boards with the same structure, or refuses', () => {
  const ids = (s) => s.match(/../g).map(SID.cardId);
  const c = AB.blankSubstitute(ids('Ah8s4c2dJh')); assert.ok(c !== null); assert.equal(c & 3, SID.cardId('Jh') & 3); assert.notEqual(c >> 2, SID.cardId('Jh') >> 2); assert.ok((c >> 2) > (SID.cardId('8s') >> 2) && (c >> 2) < (SID.cardId('Ah') >> 2));
  assert.equal(AB.blankSubstitute(ids('KhTs5c3d8h')), null, 'every other rank between 5 and T would create a new three-to-a-straight');
  assert.equal(AB.blankSubstitute(ids('KhTs5c3d5h')), null, 'a pairing river is not a blank'); assert.equal(AB.blankSubstitute(ids('KhTh5h3d8h')), null, 'a flush-completing river is not a blank');
});

test('coverage accounting keeps exact, abstracted, solved-on-demand and unavailable apart (previously unseen hands)', () => {
  const rows = [['preflop', 8, 2500, 'solver', 'study'], ['flop', 2, 2000, 'solver', 'library-disk', null, 1, 'miss', 'unverified'], ['river', 2, 1500, 'solver', 'solved-on-demand', null, 300, null, 'validated'], ['turn', 3, 1500, 'scripted', 'scripted-fallback', 'library-miss'], ['river', 3, 900, 'solver', 'library-approximate', null, 2, null, 'restricted-evaluation']];
  const c = COV.classify(rows); assert.equal(c.postflopDecisions, 4); assert.equal(c.exact, 1); assert.equal(c.solvedOnDemand, 1); assert.equal(c.unavailable, 1); assert.equal(c.abstracted, 1);
  assert.equal(c.exactShare, 0.25); assert.equal(c.anyStrategyShare, 0.75); assert.equal(c.unavailableCodes['library-miss'], 1); assert.equal(c.byStreet['river heads-up'].solvedOnDemand, 1); assert.equal(c.qualityOfUsed.validated, 1);
});
