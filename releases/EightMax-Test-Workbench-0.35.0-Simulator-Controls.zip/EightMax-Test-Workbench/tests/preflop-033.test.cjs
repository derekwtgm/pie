'use strict';
// 0.33: compact preflop solver modes (src/preflop-compact.js), state anatomy (tools/state-anatomy-033.cjs), class-keyed state reading,
// checkpoint continuation of compact studies, memory-budget enforcement, CRC verification of keyed states.
const test = require('node:test'), assert = require('node:assert'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const EM = require('./load-solver.cjs'), A = require('../src/study-adapter.js'), T = require('../tools/studies.cjs'), PC = require('../src/preflop-compact.js'), PR = require('../src/preflop-research.js'), AN = require('../tools/state-anatomy-033.cjs'), N = require('../tools/native-training.cjs');
const cli = process.env.EIGHTMAX_TEST_CLI && fs.existsSync(process.env.EIGHTMAX_TEST_CLI) ? process.env.EIGHTMAX_TEST_CLI : null;
const BASE = { ...T.PREFLOP8_LINKED };
const train = (spec, updates, dir, name, resume) => { const sf = path.join(dir, name + '.json'), st = path.join(dir, name + '.state'); fs.writeFileSync(sf, JSON.stringify(spec)); const args = [sf, String(updates), '1', st, '1024']; if (resume) args.push(resume); const r = cp.spawnSync(cli, args, { encoding: 'utf8' }); assert.strictEqual(r.status, 0, r.stderr); return { st, info: JSON.parse(r.stdout.trim().split('\n').pop()) }; };

test('compact modes are explicit game definitions: A is the unchanged 0.32 study, B/B169 have no postflop betting, C only a flop round', () => {
  const a = PC.specFor('A', BASE, EM, A).spec, ref = A.nativeJob(A.prepare(EM, { config: T.PREFLOP8_LINKED, iterations: 1000, timeMs: 600000, strategyBudgetMiB: 32 }), 'train').spec;
  assert.strictEqual(a.studyId, ref.studyId, 'Mode A keeps the 0.32 study identity (saved studies stay compatible)');
  const b = PC.specFor('B', BASE, EM, A).spec, b169 = PC.specFor('B169', BASE, EM, A).spec, c = PC.specFor('C', BASE, EM, A).spec;
  for (const s of [b, b169]) for (const len of ['3', '4', '5']) { assert.deepStrictEqual(s.rules.sizes[len].bets, []); assert.deepStrictEqual(s.rules.sizes[len].raises, []); }
  assert.deepStrictEqual(c.rules.sizes['3'], a.rules.sizes['3']); assert.deepStrictEqual(c.rules.sizes['4'].bets, []);
  assert.deepStrictEqual(b.rules.sizes['0'], a.rules.sizes['0'], 'identical preflop tree in every mode'); assert.deepStrictEqual(b169.rules.stacks, a.rules.stacks);
  assert.strictEqual(b169.groupKeys.abstraction, 'compact'); assert.ok(!b.groupKeys, 'Mode B keeps exact hands');
  assert.ok(new Set([a.studyId, b.studyId, b169.studyId, c.studyId]).size === 4, 'different games never share a study id or cache');
  const d = PC.gameDefinition('B169', BASE); assert.match(d.accuracyClass, /approximate/); assert.match(d.postflop, /check-down/); assert.strictEqual(d.objective, 'chip EV');
  for (const m of ['B', 'B169', 'C']) assert.doesNotMatch(JSON.stringify(PC.gameDefinition(m, BASE)), /\bGTO\b|solved/i);
  assert.throws(() => PC.modeOf('Z'), /Unknown preflop solver mode/);
  // configurable stacks: a 40 bb game is a different game
  assert.notStrictEqual(PC.specFor('B169', { ...BASE, stacks: Array(8).fill(40) }, EM, A).spec.studyId, b169.studyId);
});
test('state anatomy and compact reader: Mode A has postflop rows in single-row contexts, Mode B none; class keys read back as 169 classes', { skip: !cli && 'native EightMax CLI not available (set EIGHTMAX_TEST_CLI)' }, () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-pf033t-'));
  try {
    const sa = PC.specFor('A', BASE, EM, A).spec, sb = PC.specFor('B', BASE, EM, A).spec, sk = PC.specFor('B169', BASE, EM, A).spec;
    const a = train(sa, 20000, dir, 'a'), b = train(sb, 20000, dir, 'b'), k = train(sk, 20000, dir, 'k');
    const an = AN.anatomy(a.st), bn = AN.anatomy(b.st), kn = AN.anatomy(k.st);
    assert.ok(an.postflopRowShare > 0.2, 'A has postflop rows: ' + an.postflopRowShare); assert.ok(an.streets.river.singleRowContextShare > 0.9, 'A river rows are singletons in their context');
    assert.strictEqual(bn.postflopRowShare, 0); assert.ok(bn.rows < an.rows); assert.ok(fs.statSync(b.st).size < fs.statSync(a.st).size);
    assert.ok(kn.rows < bn.rows, 'class keys store fewer preflop rows than exact hands');
    const fi = PR.firstInPaths(A.prepare(EM, { config: BASE, iterations: 1 })), keep = fi.map((f) => 'r' + f.path.join(''));
    const ra = PC.readPreflop(a.st, sa, EM, { keepPaths: keep }), rk = PC.readPreflop(k.st, sk, EM, { keepPaths: keep });
    assert.strictEqual(rk.keyed, true); assert.strictEqual(ra.keyed, false); assert.ok(ra.preflopRows > rk.preflopRows);
    const utg = rk.byPath.get('r'); assert.ok(utg && utg.cls.size === 169, 'UTG first-in stores every class');
    for (let c = 0; c < 169; c++) { const s = rk.classStrategy('r', c); assert.ok(Math.abs(s.reduce((x, y) => x + y, 0) - 1) < 1e-9); }
    const cov = PC.positionCoverage(rk, fi, EM); assert.strictEqual(cov.length, 8); assert.strictEqual(cov[0].firstInClassesStored, 169); assert.ok(cov.every((x) => x.classCoverageMean === null || (x.classCoverageMean > 0 && x.classCoverageMean <= 1)));
    const same = PC.compareReads(rk, rk, fi, EM); assert.ok(same.every((x) => x.meanTotalVariation === null || x.meanTotalVariation === 0));
    const diff = PC.compareReads(ra, rk, fi, EM); assert.ok(diff[0].meanTotalVariation > 0 && diff[0].meanTotalVariation <= 1);
    const fr = PC.nodeFrequencies(rk, 'r', fi[0].labels, EM); assert.ok(Math.abs(fr.frequencies.reduce((x, y) => x + y, 0) - 1) < 1e-3); assert.strictEqual(fr.combosWithoutRows, 0);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
test('checkpoint continuation of a compact (class-keyed) study is bit-identical to an uninterrupted run; keyed states pass CRC verification and corruption is detected', { skip: !cli && 'native EightMax CLI not available (set EIGHTMAX_TEST_CLI)' }, () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-pf033c-'));
  try {
    const sk = PC.specFor('B169', BASE, EM, A).spec, full = train(sk, 16000, dir, 'full'), half = train(sk, 8000, dir, 'half'), cont = train(sk, 8000, dir, 'cont', half.st);
    assert.strictEqual(cont.info.iterations, 16000);
    const body = (f) => { const b = fs.readFileSync(f), hl = b.readUInt32LE(8); return require('node:crypto').createHash('sha256').update(b.subarray(12 + hl)).digest('hex'); };
    assert.strictEqual(body(cont.st), body(full.st), 'same strategy tables after 8k + 8k as after 16k');
    assert.strictEqual(N.verifyCrcOnly(full.st), true);
    const bad = path.join(dir, 'bad.state'), b = fs.readFileSync(full.st); b[b.length - 20] ^= 0x40; fs.writeFileSync(bad, b); assert.strictEqual(N.verifyCrcOnly(bad), false);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
test('memory budget enforcement: a compact study is refused or stopped at its native budget, never silently reported complete', { skip: !cli && 'native EightMax CLI not available (set EIGHTMAX_TEST_CLI)' }, async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-pf033m-'));
  try {
    const sf = path.join(dir, 's.json'); fs.writeFileSync(sf, JSON.stringify(PC.specFor('A', BASE, EM, A).spec));
    let outcome; try { const r = await N.trainNative({ cli, specFile: sf, updates: 400000, budgetMiB: 64, threads: 1, outFile: path.join(dir, 'o.state') }); outcome = r.run; } catch (e) { outcome = { status: 'refused', code: e.code }; }
    assert.notStrictEqual(outcome.status, 'complete', 'a 64 MiB budget cannot hold 400,000 linked updates: ' + JSON.stringify(outcome));
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
test('class-keyed shared preflop snapshot (format 2): answers every combination with its class row, verifies its checksum, is labelled approximate in decisions', { skip: !cli && 'native EightMax CLI not available (set EIGHTMAX_TEST_CLI)' }, async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em-pf033s-')), PS = require('../src/preflop-snapshot.js');
  try {
    const sk = PC.specFor('B169', BASE, EM, A).spec, k = train(sk, 20000, dir, 'k');
    const buf = PC.buildClassSnapshot(k.st, sk, EM, { studyId: 'preflop8-compact-B169-20000', shared: true }), snap = PS.open(buf, { verify: true });
    assert.strictEqual(snap.header.keyedBy, 'class'); assert.strictEqual(snap.shared, true); assert.match(snap.header.accuracy, /approximate/);
    const rd = PC.readPreflop(k.st, sk, EM, { keepPaths: ['r', 'r0', 'r00000'] }); let n = 0;
    for (const p of ['r', 'r0', 'r00000']) { const seat = p.length - 1; for (let h = 0; h < 1326; h++) { const a = snap.averageAt(p, seat, h), b = rd.classStrategy(p, EM.CLS[sk.hands[seat][h][0]]); assert.strictEqual(!!a, !!b); if (a) { n++; a.forEach((x, i) => assert.ok(Math.abs(x - b[i]) < 1e-12)); } } }
    assert.ok(n > 1326, 'many combinations answered');
    assert.strictEqual(snap.averageAt('r', 1, 0), null, 'wrong seat at a node is a miss');
    const bad = new Uint8Array(buf.byteLength); bad.set(new Uint8Array(buf)); bad[bad.length - 3] ^= 1; assert.throws(() => PS.open(bad.buffer, { verify: true }), /corrupt/);
    const F = require('../tools/solver-factory.cjs'), src = await F.createSource({ kind: 'preflop-linked', preflopSnapshot: buf });
    const pre = src.sources ? src.sources[0] : src; const study = pre.study || (pre.sources && pre.sources[0].study);
    assert.ok(study, 'preflop source built'); assert.strictEqual(study.convergence.verdict, 'approximate'); assert.match(study.id, /compact-B169/);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
