'use strict';
/* 0.32 runtime approximations: chip-scale and pot-bucket-10pct (validated in 0.31) - off by default, explicitly enabled,
 * labelled, legality re-checked, scope-limited; unvalidated mappings cannot be enabled; exact hits stay exact. */
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const L = require('../src/strategy-library.js'), LS = require('../src/library-source.js'), AT = require('../src/adaptive-training.js'), SID = require('../src/strategy-identity.js'), HS = require('../src/hand-state.js'), AL = require('../src/approximate-lookup.js');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'em032a-')), cards = (s) => s.match(/../g);
const adaptiveOpts = { training: ({ street, players }) => (street === 'river' && players === 2 ? AT.trainingPolicy({ trainer: 'vector-cfr-plus' }) : undefined), abstraction: ({ training }) => (training && training.trainer === 'vector-cfr-plus' ? SID.ABSTRACTION_FULL_WIDTH : undefined), range: 'AA,KK,QQ,JJ,TT,99,AK,AQ,KQ,QJs,JTs,T9s,98s', rangeModelName: 'test-range' };
function riverRequest(pot, stack, over = {}) {
  const board = cards('AsKd7h4c2s').map(HS.cardFromString), sb = Array(8).fill(0); sb[1] = stack; sb[2] = stack; const live = Array(8).fill(false); live[1] = live[2] = true;
  const seatsState = Array.from({ length: 8 }, (_, i) => ({ stack: live[i] ? stack : 2400, bet: 0, total: 0, folded: !live[i] }));
  return { format: 'eightmax-decision-request', version: 1, table: 3, hand: 17, revision: 5, stateKey: 'k', street: 'river', actor: 1, button: 0, holeCards: [HS.cardFromString('Qh'), HS.cardFromString('Jh')], board, actions: [],
    stacks: Array(8).fill(2500), toCall: 0, priority: 1, deadlineMs: 2000, pot, currentBet: 0, blinds: { sb: 50, bb: 100, ante: 10 }, seatsState, streetStart: { pot, behind: sb, live },
    legal: { toCall: 0, callAmount: 0, canCheck: true, canCall: false, canFold: false, canRaise: true, minRaiseTo: 100, maxRaiseTo: stack }, ...over };
}

test('scale key: identities differing only by a common chip factor share a scale class; others do not', () => {
  const mk = (pot, s) => LS.spotFromParams({ street: 'river', board: cards('AsKd7h4c2s').map(HS.cardFromString), stacksBehind: [s, s], pot, ranges: ['random', 'random'] }, {}).identity;
  assert.equal(AL.scaleKey(mk(4, 10)), AL.scaleKey(mk(8, 20))); assert.notEqual(AL.scaleKey(mk(4, 10)), AL.scaleKey(mk(4, 12)));
  assert.equal(AL.potGrid(4), 4.18); assert.equal(AL.potGrid(4.18), 4.18);
});

test('chip-scale is OFF by default; when enabled it answers a scaled situation, labelled approximate, with the source strategy and table-legal sizes', async () => {
  const dir = tmp();
  const src = await new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'study', ...adaptiveOpts }).decide(riverRequest(800, 2000)); assert.equal(src.status, 'ok', src.reason);
  const off = await new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'decision', ...adaptiveOpts }).decide(riverRequest(400, 1000)); assert.equal(off.code, 'library-miss', 'exact matching is the default');
  const on = new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'decision', approximationPolicy: 'chip-scale', ...adaptiveOpts }), d = await on.decide(riverRequest(400, 1000));
  assert.equal(d.status, 'ok', d.reason); assert.equal(d.strategySource, 'library-approximate'); assert.equal(d.approximation.mapping, 'chip-scale'); assert.equal(d.approximation.factor, 2); assert.equal(d.exactState, false);
  assert.ok(d.warnings.some((w) => /APPROXIMATE \(chip-scale\)/.test(w))); assert.deepEqual(d.probabilities, src.probabilities, 'same strategy as the stored source situation');
  for (const [i, e] of d.executable.entries()) if (e && e.amount !== undefined && d.probabilities[i] > 0) { assert.ok(e.amount <= 1000 && e.amount >= 100, 'legal wager at the real table: ' + e.amount); assert.equal(e.amount, Math.round(src.executable[i].amount / 2)); }
  assert.equal(on.stats.approximate_chip_scale === undefined ? on.stats['approximate_chip-scale'] : on.stats.approximate_chip_scale, 1);
});

test('chip-scale refuses non-proportional stacks; quality gate still applies to the source strategy', async () => {
  const dir = tmp(); await new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'study', ...adaptiveOpts }).decide(riverRequest(800, 2000));
  const d = await new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'decision', approximationPolicy: 'chip-scale', ...adaptiveOpts }).decide(riverRequest(400, 1100)); assert.equal(d.code, 'library-miss');
});

test('pot-bucket-10pct: used only before any wager on a heads-up river and labelled; a wager on the street refuses it', async () => {
  const dir = tmp(); await new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'study', ...adaptiveOpts }).decide(riverRequest(418, 1000));
  const src = new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'decision', approximationPolicy: 'validated-approximations', ...adaptiveOpts });
  const d = await src.decide(riverRequest(400, 1000)); assert.equal(d.status, 'ok', d.reason); assert.equal(d.approximation.mapping, 'pot-bucket-10pct'); assert.equal(d.strategySource, 'library-approximate');
  const facing = riverRequest(400, 1000, { actor: 2, actions: [{ seat: 1, type: 'bet', amount: 200, street: 'river' }], currentBet: 200, toCall: 200, pot: 600, legal: { toCall: 200, callAmount: 200, canCheck: false, canCall: true, canFold: true, canRaise: true, minRaiseTo: 400, maxRaiseTo: 1000 } });
  facing.seatsState[1] = { ...facing.seatsState[1], stack: 800, bet: 200, total: 200 };
  const f = await src.decide(facing); assert.notEqual(f.strategySource, 'library-approximate');
});

test('only validated mappings can be enabled; unvalidated ones (e.g. stack buckets, river blank substitution) are refused', () => {
  for (const bad of [['stack-bucket-2.5'], ['spr-bucket'], ['river-blank-substitution'], 'nonsense']) assert.throws(() => new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(tmp()), approximationPolicy: bad }));
  assert.deepEqual(AL.POLICIES.exact, []);
});
