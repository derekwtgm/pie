'use strict';
/* 0.32 eight-handed preflop research and shared preflop memory:
 * information-set coverage (exact counts), continuation / checkpoint determinism, multiple seeds, the shared snapshot (bit-for-bit
 * equal to the lazy reader, shared across worker threads without copying, corruption and identity checks, worker crash recovery),
 * first-in deviation gains (sampled lower-bound estimates with intervals), and the training-mode assessment rules. */
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), { Worker } = require('node:worker_threads');
const TS = require('../tools/train-study.cjs'), T = require('../tools/studies.cjs'), PR = require('../src/preflop-research.js'), PS = require('../src/preflop-snapshot.js'), { StrategyStore } = require('../src/strategy-store.js'), NT = require('../tools/native-training.cjs');
const cli = process.env.EIGHTMAX_TEST_CLI && fs.existsSync(process.env.EIGHTMAX_TEST_CLI) ? process.env.EIGHTMAX_TEST_CLI : null, skip = !cli && 'native engine (EIGHTMAX_TEST_CLI) required';
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em032p-'));
const study = (updates, seed = 8, extra = {}) => TS.preflopSnapshotFor(updates, { config: { ...T.PREFLOP8_LINKED, privateSeed: seed }, name: 'pf-s' + seed, cacheDir: dir, threads: 1, budgetMiB: 1024, cli, ...extra });

test('shared preflop snapshot answers every stored preflop row bit-for-bit like the lazy native reader', { skip }, async () => {
  const s = await study(20000), store = StrategyStore.open(s.stateFile, { cacheBytes: 32 << 20 }), snap = PS.open(s.buffer, { verify: true });
  assert.equal(snap.header.rows, store.preflopRows, 'every preflop row is in the snapshot');
  let n = 0;
  for (let st = 0; st < store.stateCount; st++) { if (store.kind[st] !== 0 || store.length[st] !== 0) continue; const p = PR.pathOf(store, st), seat = store.actor[st];
    for (const key of store.rowsAt(st).keys()) { const h = +key.split('|')[0], a = store.averageAt(p, seat, h), b = snap.averageAt(p, seat, h); assert.deepEqual(Array.from(b), Array.from(a)); n++; }
    assert.equal(snap.averageAt(p, seat, 1325 + 1), null); }
  assert.ok(n > 1000); assert.equal(snap.averageAt('r9', 0, 0), null, 'unknown path');
  store.close();
});

test('native checkpoint determinism: continuing 10k -> 20k equals a straight 20k run (Continue Training resumes, never restarts)', { skip }, async () => {
  const a = await study(10000, 21), b = await study(20000, 21, { continueFromSmaller: true });
  const meta = JSON.parse(fs.readFileSync(path.join(dir, 'pf-s21-20000.meta.json'), 'utf8')); assert.deepEqual(meta.continuedFrom, { file: 'pf-s21-10000.state', iterations: 10000 });
  const straight = await TS.preflopSnapshotFor(20000, { config: { ...T.PREFLOP8_LINKED, privateSeed: 21 }, name: 'pf-straight-s21', cacheDir: dir, threads: 2, budgetMiB: 1024, cli });
  assert.equal(b.fingerprint.bodySha256, straight.fingerprint.bodySha256, 'same strategy bytes (thread count independent too)'); assert.notEqual(a.fingerprint.bodySha256, b.fingerprint.bodySha256);
});

test('multiple seeds give different reproducible studies of the same game; each has its own fingerprint', { skip }, async () => {
  const a = await study(10000, 8), b = await study(10000, 108), a2 = await study(10000, 8);
  assert.notEqual(a.fingerprint.bodySha256, b.fingerprint.bodySha256); assert.equal(a.fingerprint.bodySha256, a2.fingerprint.bodySha256);
});

test('information-set coverage: exact counts agree with the state, per-position figures, missing branches listed by reach, incomplete flagged', { skip }, async () => {
  const s = await study(20000), store = StrategyStore.open(s.stateFile, { cacheBytes: 32 << 20 }), p = TS.preparedFromSnapshot(s.buffer, {});
  const c = PR.coverage(store, p.prepared, { samples: 600, seed: 3 }); store.close();
  assert.equal(c.exactCounts.storedRows, s.buffer && PS.open(s.buffer).header.rows); assert.equal(c.perSeat.length, 8); assert.deepEqual(c.perSeat.map((x) => x.position.split(' ')[0]), PR.SHORT.map((x) => x));
  assert.ok(c.sampled.reachWeightedClassCoverage > 0 && c.sampled.reachWeightedClassCoverage <= 1); assert.equal(c.incomplete, true, 'a 20,000-update study has unvisited classes at reachable nodes');
  for (let i = 1; i < c.missingBranches.length; i++) assert.ok(c.missingBranches[i - 1].reach >= c.missingBranches[i].reach);
  assert.match(c.note, /not evidence of accuracy/);
});

test('shared memory: worker threads read ONE SharedArrayBuffer (no copy) and answer identically; a crashed worker is replaced with the same snapshot', { skip }, async () => {
  const s = await study(20000), snap = PS.open(s.buffer), store = StrategyStore.open(s.stateFile, { cacheBytes: 16 << 20 });
  const probes = []; for (let st = 0; st < store.stateCount && probes.length < 400; st++) if (store.kind[st] === 0 && store.length[st] === 0) for (const key of [...store.rowsAt(st).keys()].slice(0, 2)) probes.push([PR.pathOf(store, st), store.actor[st], +key.split('|')[0]]);
  store.close();
  const code = `const { parentPort, workerData } = require('node:worker_threads'); const PS = require(${JSON.stringify(path.resolve(__dirname, '../src/preflop-snapshot.js'))});
    const snap = PS.open(workerData.buffer, { expect: workerData.fp }); if (workerData.crash) throw new Error('simulated worker crash');
    parentPort.postMessage({ shared: snap.shared, bytes: workerData.buffer.byteLength, answers: workerData.probes.map(([p, seat, h]) => { const a = snap.averageAt(p, seat, h); return a ? Array.from(a) : null; }) });`;
  const run = (crash) => new Promise((res, rej) => { const w = new Worker(code, { eval: true, workerData: { buffer: s.buffer, fp: snap.fingerprint(), probes, crash } }); w.once('message', res); w.once('error', rej); });
  const results = await Promise.all([run(false), run(false), run(false)]);
  for (const r of results) { assert.equal(r.shared, true); assert.equal(r.bytes, s.buffer.byteLength); assert.deepEqual(r.answers, probes.map(([p, seat, h]) => Array.from(snap.averageAt(p, seat, h)))); }
  await assert.rejects(run(true), /simulated worker crash/);
  const again = await run(false); assert.deepEqual(again.answers, results[0].answers, 'replacement worker reads the same intact snapshot');
  assert.equal(PS.open(s.buffer, { verify: true }).header.bodySha256, snap.header.bodySha256, 'shared buffer unchanged after the crash');
});

test('snapshot corruption and identity: a flipped byte is refused on load; a different study is refused by fingerprint', { skip }, async () => {
  const s = await study(20000), b = fs.readFileSync(s.file); b[b.length - 100] ^= 0x55; const bad = s.file + '.bad'; fs.writeFileSync(bad, b);
  assert.throws(() => PS.load(bad, { shared: true }), (e) => e.code === 'checksum');
  const other = await study(10000, 108); assert.throws(() => PS.open(other.buffer, { expect: s.fingerprint }), (e) => e.code === 'identity-mismatch');
  assert.throws(() => PS.open(new ArrayBuffer(64)), (e) => e.code === 'bad-magic');
  // a stale cached snapshot (different source state) is rebuilt, not reused
  fs.writeFileSync(s.file, b); const again = await study(20000); assert.equal(again.fingerprint.bodySha256, s.fingerprint.bodySha256);
});

test('first-in nodes of all eight positions, and a sampled one-decision deviation gain with a 95% interval (lower-bound estimate)', { skip }, async () => {
  const s = await study(10000), p = TS.preparedFromSnapshot(s.buffer, {}), f = PR.firstInPaths(p.prepared);
  assert.equal(f.length, 8); for (let i = 0; i < 7; i++) assert.equal(f[i].actor, i); assert.ok(f[0].labels.includes('Fold')); assert.deepEqual(f[7].path.length, 7);
  const g = PR.deviationGain(cli, path.join(dir, 'pf-s8.spec.json'), s.stateFile, 0, f[0].path, { samples: 128, timeMs: 120000 });
  assert.ok(!g.error, g.error); assert.equal(g.position, 'UTG'); assert.ok(Array.isArray(g.gainBB.ci95)); assert.match(g.classification, /LOWER BOUND/); assert.ok(g.fallbackShare >= 0 && g.fallbackShare <= 1);
});

test('training modes: names never imply accuracy; high-accuracy targets are met only by measurement; full-game exploitability is unavailable, never 0', () => {
  assert.deepEqual(Object.keys(PR.MODES), ['fast', 'standard', 'high-accuracy']); assert.throws(() => PR.modeOf('ultra'));
  const cov = { sampled: { reachWeightedClassCoverage: 0.96 }, exactCounts: { statesWithNoRow: 10 } };
  const a = PR.assess('high-accuracy', cov, [{ method: 'restricted', seats: [{ position: 'BB', gainBB: 0.2, ci95BB: [0.1, 0.3] }] }]); assert.equal(a.targetsMet, false);
  const b = PR.assess('high-accuracy', { ...cov, sampled: { reachWeightedClassCoverage: 0.999 } }, [{ method: 'restricted', seats: [{ position: 'BB', gainBB: 0.01, ci95BB: [0.0, 0.02] }] }]); assert.equal(b.targetsMet, true);
  const c = PR.assess('standard', cov, []); assert.equal(c.targetsMet, null); assert.ok(c.statements.some((x) => /unavailable, not zero/.test(x)));
  assert.match(PR.summarizeGains({ methodUsed: 'restricted', seats: [] }).fullGameExploitability, /^unavailable/);
});
