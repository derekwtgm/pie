'use strict';
/* 0.32 linked flop-to-river storage: export / lazy read / bit-for-bit equivalence, continuity with the street record, corruption
 * and identity checks, quality classification of linked evaluations (complete vs incomplete continuation), the exact heads-up
 * turn solver in the decision path (on-demand, bounded, labelled) and backward compatibility with 0.31 records. */
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const EM = require('./load-solver.cjs'), A = require('../src/study-adapter.js'), LK = require('../src/linked-study.js'), MS = require('../src/fast-multistreet.js');
const L = require('../src/strategy-library.js'), LS = require('../src/library-source.js'), Q = require('../src/strategy-quality.js'), AT = require('../src/adaptive-training.js'), SID = require('../src/strategy-identity.js'), HS = require('../src/hand-state.js');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'em032k-')), cards = (s) => s.match(/../g);
const STREETS = { flop: { bets: '50', raises: 'a', maxBets: 1 }, turn: { bets: '50,a', raises: 'a', maxBets: 2 }, river: { bets: '75,a', raises: 'a', maxBets: 2 } };
const narrow = ['AA,KK,77,AK,KQs,T9s', 'AA,KK,77,AK,KQs,T9s,65s'];
function trained(board, updates, ranges = narrow) { const p = A.prepare(EM, { config: { board, common: 6, stacks: [12, 12], ranges, streets: STREETS, privateSeed: 5 }, iterations: updates }); p.game.iterate(updates); return p; }

test('linked turn record answers every street bit-for-bit like the trained study and gives the identical exact evaluation', () => {
  const p = trained('AhKd7c2s', 8000), bytes = LK.exportLinked(p, { EM, fingerprint: 'f'.repeat(64) }), g = LK.open(bytes);
  assert.equal(g.meta.startStreet, 'turn'); assert.deepEqual(Object.keys(g.meta.streets).sort(), ['4', '5']);
  let compared = 0;
  for (const n of g.meta.nodes.filter((x) => x.kind === 'player')) for (const c of [6, 13, 40]) { const board = n.street === 4 ? p.spec.board : p.spec.board.concat(c); if (board.length === 5 && p.spec.board.includes(c)) continue;
    for (const r of p.spec.hands[n.seat]) { const a = p.game.averageAt(n.p, board, n.seat, { id: r[0], a: r[1], b: r[2], w: r[3] }), b = g.averageAt(n.p, board, n.seat, { id: r[0], a: r[1], b: r[2], w: r[3] }); if (board.includes(r[1]) || board.includes(r[2])) { assert.equal(b, null); continue; } assert.equal(!a, !b); if (a) { assert.deepEqual(Array.from(a), Array.from(b)); compared++; } } }
  assert.ok(compared > 200);
  const e1 = MS.prepare(p.game, p.spec).exact(p.game), e2 = MS.prepare(g, g.prepared().spec).exact(g);
  assert.equal(e1.exploitability, e2.exploitability); assert.equal(e1.missingRows, e2.missingRows);
  const rowsPer = (len) => g.meta.streets[len].reduce((t, pth) => t + g.meta.hands[g.meta.nodes.find((x) => x.p === pth).seat].length, 0);
  assert.equal(g.meta.counts.missingRows + g.meta.counts.storedRows + g.meta.counts.impossibleRows, g.meta.sections.reduce((t, sec) => t + rowsPer(sec.street), 0), 'every row slot is accounted for');
});

test('lazy loading: a decision on one river card inflates only that section; the cache stays within its byte bound', () => {
  const p = trained('AhKd7c2s', 3000), g = LK.open(LK.exportLinked(p, { EM }), { cacheBytes: 20000 });
  const n = g.meta.nodes.find((x) => x.kind === 'player' && x.street === 5), r = p.spec.hands[n.seat].find((h) => ![6, ...p.spec.board].includes(h[1]) && ![6, ...p.spec.board].includes(h[2]));
  g.averageAt(n.p, p.spec.board.concat(6), n.seat, { id: r[0], a: r[1], b: r[2] }); assert.equal(g.stats().sectionLoads, 1);
  for (let c = 0; c < 52; c++) if (!p.spec.board.includes(c)) g.averageAt(n.p, p.spec.board.concat(c), n.seat, { id: r[0], a: r[1], b: r[2] });
  assert.ok(g.stats().cacheUsed <= 20000); assert.ok(g.stats().evictions > 0);
});

test('corruption, truncation and wrong format are refused with codes (never read as a strategy)', () => {
  const bytes = LK.exportLinked(trained('AhKd7c2s', 1000), { EM });
  const flip = Uint8Array.from(bytes); flip[flip.length - 5] ^= 0xff; assert.throws(() => LK.open(flip), (e) => e.code === 'checksum');
  assert.throws(() => LK.open(bytes.subarray(0, bytes.length - 10)), (e) => e.code === 'truncated' || e.code === 'checksum');
  const meta = Uint8Array.from(bytes); meta[20] ^= 0x01; assert.throws(() => LK.open(meta), (e) => ['checksum', 'bad-meta'].includes(e.code));
  assert.throws(() => LK.open(new Uint8Array(40)), (e) => e.code === 'bad-magic');
});

test('library: linked record is stored next to its street record only if it reproduces that record exactly; 0.31 records without one stay unverified', async () => {
  const dir = tmp(), lib = L.StrategyLibrary.open(dir);
  const sp = LS.spotFromParams({ street: 'turn', board: cards('AhKd7c2s').map(HS.cardFromString), stacksBehind: [12, 12], pot: 6, ranges: narrow }, { iterations: 4000, streets: STREETS });
  const r = await LS.trainSpot(sp.spot, { EM, linked: true }); assert.ok(r.linked && r.linked.length > 1000);
  lib.put(sp.identity, r.body, { status: 'complete', training: r.training });
  // 0.31-style: no linked record -> unverified, reason names the missing continuation
  const before = Q.evaluateRecord(lib, sp.fingerprint, { ledger: false }); assert.equal(before.status, 'unverified'); assert.match(before.reason, /later-street strategies are not in the record/);
  // wrong study: a linked record from a different training run (different seed) does not match the street record
  const other = trained('AhKd7c2s', 4000); const bad = LK.exportLinked(other, { EM, fingerprint: sp.fingerprint });
  assert.throws(() => lib.putLinked(sp.fingerprint, bad), (e) => e.code === 'continuity');
  assert.throws(() => lib.putLinked(sp.fingerprint, LK.exportLinked(other, { EM, fingerprint: 'a'.repeat(64) })), (e) => e.code === 'identity-mismatch');
  const ok = lib.putLinked(sp.fingerprint, r.linked); assert.ok(ok.bytes > 0); assert.ok(lib.hasLinked(sp.fingerprint)); assert.ok(lib.list().find((x) => x.fingerprint === sp.fingerprint).linked);
  const after = Q.evaluateRecord(lib, sp.fingerprint, { ledger: false });
  assert.equal(after.evaluation.continuation, 'linked'); assert.equal(after.evaluation.type, 'exact'); assert.deepEqual(after.evaluation.streets, ['turn', 'river']);
  // a 4,000-update sampled study leaves continuation rows unvisited: exact number reported, NOT validated
  if (after.evaluation.missingRows > 0) { assert.equal(after.status, 'unverified'); assert.match(after.reason, /never visited/); }
  // corrupt linked file -> refused by getLinked, evaluation falls back to unverified
  const f = lib.linkedFile(sp.fingerprint), b = fs.readFileSync(f); b[b.length - 3] ^= 0xff; fs.writeFileSync(f, b);
  const g = lib.getLinked(sp.fingerprint); assert.equal(g.ok, false); assert.equal(g.code, 'checksum');
  assert.equal(Q.evaluateRecord(lib, sp.fingerprint, { ledger: false }).status, 'unverified');
});

test('classification: complete linked evaluation can validate or fail; incomplete continuation is never validated', () => {
  const base = { type: 'exact', players: 2, potBB: 6, continuation: 'linked', streets: ['turn', 'river'] };
  assert.equal(Q.classify({ ...base, exploitabilityBB: 0.01, missingRows: 0 }, 'research').status, 'validated');
  assert.equal(Q.classify({ ...base, exploitabilityBB: 0.5, missingRows: 0 }, 'research').status, 'failed-quality-check');
  const inc = Q.classify({ ...base, exploitabilityBB: 0.001, missingRows: 12, missingShare: 0.01 }, 'research'); assert.equal(inc.status, 'unverified'); assert.ok(inc.partialEvaluation);
  assert.equal(Q.classify({ type: 'none', players: 3, potBB: 6, continuation: 'linked' }, 'research').status, 'unverified');
});

test('exact turn solver (adaptive, vector CFR+): stores a VALIDATED turn record with its linked river continuation', async () => {
  const sp = LS.spotFromParams({ street: 'turn', board: cards('AhKd7c2s').map(HS.cardFromString), stacksBehind: [12, 12], pot: 6, ranges: narrow }, { streets: STREETS, training: AT.trainingPolicy({ trainer: 'vector-cfr-plus' }), abstraction: SID.ABSTRACTION_FULL_WIDTH });
  const r = await AT.trainAdaptive(sp.spot, { EM, trainer: 'vector-cfr-plus', maxTimeMs: 60000 });
  assert.equal(r.quality.status, 'validated', r.quality.reason); assert.equal(r.quality.evaluation.continuation, 'linked'); assert.equal(r.quality.evaluation.missingRows, 0);
  assert.ok(r.linked); const g = LK.open(r.linked); assert.equal(g.coverage().complete, true);
  const dir = tmp(), lib = L.StrategyLibrary.open(dir); lib.put(sp.identity, r.body, { status: 'complete', training: r.training, quality: r.quality }); lib.putLinked(sp.fingerprint, r.linked);
  assert.equal(Q.evaluateRecord(lib, sp.fingerprint, { ledger: false }).status, 'validated', 'independent re-evaluation from the stored bytes');
});

test('turn solver resource limits: memory estimate above the limit is refused up front; cancellation stops it', async () => {
  const sp = LS.spotFromParams({ street: 'turn', board: cards('AhKd7c2s').map(HS.cardFromString), stacksBehind: [12, 12], pot: 6, ranges: narrow }, { streets: STREETS, training: AT.trainingPolicy({ trainer: 'vector-cfr-plus' }), abstraction: SID.ABSTRACTION_FULL_WIDTH });
  await assert.rejects(AT.trainAdaptive(sp.spot, { EM, trainer: 'vector-cfr-plus', turnMaxBytes: 1024 }), (e) => e.code === 'memory-limited');
  const ac = new AbortController(); ac.abort(); await assert.rejects(AT.trainAdaptive(sp.spot, { EM, trainer: 'vector-cfr-plus', signal: ac.signal }), (e) => e.code === 'cancelled');
});

function turnRequest(over = {}) {
  const board = cards('AsKd7h4c').map(HS.cardFromString), sb = Array(8).fill(0); sb[1] = 1000; sb[2] = 1000; const live = Array(8).fill(false); live[1] = live[2] = true;
  const seatsState = Array.from({ length: 8 }, (_, i) => ({ stack: live[i] ? 1000 : 2400, bet: 0, total: 0, folded: !live[i] }));
  return { format: 'eightmax-decision-request', version: 1, table: 3, hand: 17, revision: 5, stateKey: 'k', street: 'turn', actor: 1, button: 0, holeCards: [HS.cardFromString('Qh'), HS.cardFromString('Jh')], board, actions: [],
    stacks: Array(8).fill(2500), toCall: 0, priority: 1, deadlineMs: 2000, pot: 400, currentBet: 0, blinds: { sb: 50, bb: 100, ante: 10 }, seatsState, streetStart: { pot: 400, behind: sb, live },
    legal: { toCall: 0, callAmount: 0, canCheck: true, canCall: false, canFold: false, canRaise: true, minRaiseTo: 100, maxRaiseTo: 1000 }, ...over };
}
test('on-demand heads-up TURN in Decision Mode (opt-in): solved exactly, labelled solved-on-demand, linked continuation stored; off by default', async () => {
  const training = ({ street, players }) => ((street === 'river' || street === 'turn') && players === 2 ? AT.trainingPolicy({ trainer: 'vector-cfr-plus' }) : undefined), abstraction = ({ training: t }) => (t && t.trainer === 'vector-cfr-plus' ? SID.ABSTRACTION_FULL_WIDTH : undefined);
  const narrowModel = { name: 'test-narrow', ranges: null };
  const dir = tmp(), mk = (o) => new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'decision', training, abstraction, range: 'AA,KK,77,AK,KQ,QJs,JTs,T9s', rangeModelName: 'test-narrow', qualityUse: 'decision', ...o });
  const off = await mk({}).decide(turnRequest()); assert.equal(off.code, 'library-miss', 'turn solving is opt-in');
  const src = mk({ inlineHeadsUpTurn: true, inlineTurnMaxMs: 60000 }); const d = await src.decide(turnRequest());
  assert.equal(d.status, 'ok', d.reason + ' ' + d.code); assert.equal(d.strategySource, 'solved-on-demand'); assert.equal(d.quality.status, 'validated', d.quality.reason); assert.equal(src.stats.solvedOnDemand_turn, 1); assert.equal(src.stats.linkedStored, 1);
  void narrowModel;
});
