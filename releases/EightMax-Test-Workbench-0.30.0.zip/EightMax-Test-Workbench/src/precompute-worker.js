'use strict';
/* 0.30: one training job in a worker thread, so the JavaScript part of a job (state import, snapshot export) runs in parallel
 * with other jobs instead of on the queue's thread. Messages: in {spot, options} / 'abort'; out {progress} / {ok, body, meta, training} / {error}. */
const { parentPort, workerData } = require('node:worker_threads');
const LS = require('./library-source.js');
const controller = new AbortController();
parentPort.on('message', (m) => { if (m === 'abort') controller.abort(); });
LS.trainSpot(workerData.spot, { ...workerData.options, signal: controller.signal, onProgress: (d, t) => parentPort.postMessage({ type: 'progress', done: d, total: t }) })
  .then((r) => { const body = r.body; parentPort.postMessage({ type: 'done', ok: true, body, meta: { playerNodes: r.meta.playerNodes, rows: r.meta.rows }, training: r.training }, [body.buffer]); },
    (e) => parentPort.postMessage({ type: 'done', ok: false, code: e.code || 'failed', message: e.message }));
