'use strict';
/* EightMax Test Workbench 0.30: one copy of each loaded strategy for all table worker threads.
 *
 * The host (main thread) owns a StrategyLibrary opened with sharedMemory:true, so each verified record body is decoded into a
 * SharedArrayBuffer. A worker that misses in its own small cache asks the host over a MessagePort; the host loads the record
 * once (all integrity and identity checks happen there) and posts the SharedArrayBuffer. Posting a SharedArrayBuffer shares
 * the memory, it does not copy it, so ten tables on four workers read the same bytes. The data is never written after it
 * is loaded (records are immutable), so readers need no locks. Workers still re-check the identity they asked for against
 * the record header before using it.
 */
const { MessageChannel } = require('node:worker_threads');
const SID = require('./strategy-identity.js'), SNAP = require('./strategy-snapshot.js');
const nowMs = () => Number(process.hrtime.bigint()) / 1e6;

class SharedStrategyHost {
  constructor(library) {
    if (!library.o.sharedMemory) throw new Error('Open the host library with sharedMemory:true');
    this.lib = library; this.ports = []; this.stats = { requests: 0, served: 0, misses: 0, refused: 0, sharedBytes: 0, sharedRecords: 0 }; this.shared = new Map();
  }
  /** A port to hand to one worker (put it in workerData and in the Worker transferList). */
  port() {
    const ch = new MessageChannel(); this.ports.push(ch.port1);
    ch.port1.on('message', (m) => {
      if (!m || m.type !== 'fetch') return; this.stats.requests++;
      const r = this.lib.get(m.identity, m.fingerprint);
      if (!r.ok) { if (r.code === 'library-miss') this.stats.misses++; else this.stats.refused++; ch.port1.postMessage({ type: 'fetched', id: m.id, ok: false, code: r.code, reason: r.reason }); return; }
      const body = r.slot && r.slot.body; if (!body || !(body.buffer instanceof SharedArrayBuffer)) { ch.port1.postMessage({ type: 'fetched', id: m.id, ok: false, code: 'not-shared', reason: 'Record not held in shared memory' }); return; }
      if (!this.shared.has(m.fingerprint)) { this.shared.set(m.fingerprint, body.byteLength); this.stats.sharedBytes += body.byteLength; this.stats.sharedRecords++; }
      this.stats.served++; ch.port1.postMessage({ type: 'fetched', id: m.id, ok: true, sab: body.buffer, header: r.header, diskMs: r.timings.diskMs });
    });
    ch.port1.unref && ch.port1.unref();
    return ch.port2;
  }
  info() { return { ...this.stats, cacheBytes: this.lib.cacheUsed, cacheEntries: this.lib.cache.size }; }
  close() { for (const p of this.ports) p.close(); }
}

class SharedStrategyClient {
  constructor(port) { this.port = port; this.next = 0; this.waiting = new Map(); this.stats = { fetches: 0, hits: 0, misses: 0, ms: 0 };
    port.on('message', (m) => { const w = this.waiting.get(m.id); if (w) { this.waiting.delete(m.id); if (!this.waiting.size && port.unref) port.unref(); w(m); } }); port.unref && port.unref(); }
  static fromWorker() { const { workerData } = require('node:worker_threads'); const p = workerData && (workerData.libraryPort || (workerData.job && workerData.job.libraryPort)); return p ? new SharedStrategyClient(p) : null; }
  /** Resolves { game, header, ms } or null on a miss/refusal. */
  fetch(fingerprint, identity) {
    const id = ++this.next, t0 = nowMs(); this.stats.fetches++;
    return new Promise((res) => {
      this.waiting.set(id, (m) => {
        const ms = nowMs() - t0; this.stats.ms += ms;
        if (!m.ok) { this.stats.misses++; return res(null); }
        if (SID.diff(m.header.identity, identity).length) { this.stats.misses++; return res(null); }   // never trust a mismatched answer
        const game = SNAP.decode(new Uint8Array(m.sab)); game.shared = true; game.bytes = 0;            // memory is accounted by the host
        this.stats.hits++; res({ game, header: m.header, ms, diskMs: m.diskMs });
      });
      if (this.port.ref) this.port.ref(); this.port.postMessage({ type: 'fetch', id, fingerprint, identity });
    });
  }
}
module.exports = { SharedStrategyHost, SharedStrategyClient };
