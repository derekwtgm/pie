/* EightMax Test Workbench 0.30: exact strategy identity and deterministic fingerprints.
 *
 * A stored strategy may be used ONLY for the exact game it was trained for. The identity below lists every input that
 * defines that game (engine build, rules, blinds/antes, player count, stacks behind, pot, street, board, ranges, action
 * tree, abstraction and training settings). The fingerprint is SHA-256 over a canonical JSON encoding of the identity.
 * A lookup recomputes the identity from the live table and compares the WHOLE identity with the stored one (not only the
 * hash), so a different stack, board, tree or range is never served.
 *
 * The one transformation applied is SUIT ISOMORPHISM, which is exact (lossless), not an approximation: when every range
 * is written without specific suits, relabelling the four suits maps the game onto an identical game. The board is
 * relabelled to a canonical form and the hero's hole cards are relabelled with the same permutation. Any range that
 * names specific suits disables this (the identity then uses the board as dealt). No bucketing, no board or stack
 * similarity, no size translation is done here.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.WorkbenchStrategyIdentity = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const SCHEMA = 'eightmax-strategy-identity', SCHEMA_VERSION = 1;
  const RANKS = '23456789TJQKA', SUITS = 'cdhs';
  const ok = (x, m) => { if (!x) throw new Error(m); };

  /* ---------- SHA-256 (pure JS so the browser dashboard and Node produce the same fingerprint) ---------- */
  const K = new Uint32Array([0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
  function utf8(s) { if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(s); return Uint8Array.from(Buffer.from(s, 'utf8')); }
  function sha256Hex(input) {
    const msg = typeof input === 'string' ? utf8(input) : input, len = msg.length, total = ((len + 9 + 63) >> 6) << 6, b = new Uint8Array(total);
    b.set(msg); b[len] = 0x80; const bits = len * 8; for (let i = 0; i < 8; i++) b[total - 1 - i] = Math.floor(bits / Math.pow(2, 8 * i)) & 255;
    const H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]), W = new Uint32Array(64);
    const rot = (x, n) => (x >>> n) | (x << (32 - n));
    for (let o = 0; o < total; o += 64) {
      for (let i = 0; i < 16; i++) W[i] = (b[o + 4 * i] << 24) | (b[o + 4 * i + 1] << 16) | (b[o + 4 * i + 2] << 8) | b[o + 4 * i + 3];
      for (let i = 16; i < 64; i++) { const s0 = rot(W[i - 15], 7) ^ rot(W[i - 15], 18) ^ (W[i - 15] >>> 3), s1 = rot(W[i - 2], 17) ^ rot(W[i - 2], 19) ^ (W[i - 2] >>> 10); W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0; }
      let a = H[0], bb = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (let i = 0; i < 64; i++) {
        const t1 = (h + (rot(e, 6) ^ rot(e, 11) ^ rot(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + W[i]) | 0, t2 = ((rot(a, 2) ^ rot(a, 13) ^ rot(a, 22)) + ((a & bb) ^ (a & c) ^ (bb & c))) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
      }
      H[0] += a; H[1] += bb; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
    }
    return Array.from(H, (x) => x.toString(16).padStart(8, '0')).join('');
  }

  /** Canonical JSON: sorted keys, no whitespace; numbers must be finite. Same text for the same value, always. */
  function canonical(x) {
    if (x === null || typeof x !== 'object') { if (typeof x === 'number') ok(Number.isFinite(x), 'Identity numbers must be finite'); ok(x !== undefined, 'Identity values cannot be undefined'); return JSON.stringify(x); }
    if (Array.isArray(x)) return '[' + x.map(canonical).join(',') + ']';
    return '{' + Object.keys(x).filter((k) => x[k] !== undefined).sort().map((k) => JSON.stringify(k) + ':' + canonical(x[k])).join(',') + '}';
  }
  const fingerprint = (identity) => sha256Hex(canonical(identity));

  /* ---------- cards and suit isomorphism ---------- */
  const cardStr = (c) => RANKS[c >> 2] + SUITS[c & 3];
  function cardId(s) { const r = RANKS.indexOf(String(s)[0].toUpperCase()), u = SUITS.indexOf(String(s)[1].toLowerCase()); ok(r >= 0 && u >= 0, 'Bad card ' + s); return r * 4 + u; }
  const PERMS = (function () { const out = []; const rec = (p, rest) => { if (!rest.length) { out.push(p); return; } rest.forEach((x, i) => rec(p.concat(x), rest.filter((_, j) => j !== i))); }; rec([], [0, 1, 2, 3]); return out; })();
  const applyPerm = (c, p) => (c & ~3) | p[c & 3];
  /** Ranges that name specific suits (e.g. "AhKh") break suit symmetry. Class notation (AKs, KTo, 22+, random) does not. */
  function rangesSuitSymmetric(ranges) {
    return ranges.every((r) => String(r).split(',').every((tok) => { const t = tok.trim().split(':')[0].replace(/[+\s]/g, ''); return !t.split('-').some((x) => /^[2-9TJQKA][cdhs][2-9TJQKA][cdhs]$/i.test(x)); }));
  }
  /** Canonical board (cards sorted high-to-low after the lexicographically smallest suit relabelling) and the permutation used. */
  function canonicalBoard(board, allowIsomorphism) {
    const ids = board.map((c) => (typeof c === 'string' ? cardId(c) : c));
    ok(new Set(ids).size === ids.length, 'Duplicate board cards');
    if (!allowIsomorphism) return { board: ids.slice().sort((a, b) => b - a).map(cardStr).join(''), perm: [0, 1, 2, 3], applied: false };
    let best = null, bestPerm = null;
    for (const p of PERMS) { const s = ids.map((c) => applyPerm(c, p)).sort((a, b) => b - a).map(cardStr).join(''); if (best === null || s < best) { best = s; bestPerm = p; } }
    return { board: best, perm: bestPerm, applied: bestPerm.some((v, i) => v !== i) };
  }

  /* ---------- identities ---------- */
  const ABSTRACTION = Object.freeze({ privateMode: 'sampled', cards: 'exact (no card bucketing)', traversal: 'external-sampling MCCFR', weighting: 'linear', regretMatching: 'standard', actionStreams: 'shared', batchDeals: 1 });
  const r2 = (x) => Math.round(x * 100) / 100;

  /**
   * Identity of a postflop study that starts at the beginning of a street.
   * input: { engine:{version,build}, blinds:{sb,bb,ante} (chips), street, board:[ids], stacksBehind:[bb in action order], pot (bb),
   *          ranges:[text per live player in action order], rangeModel (name), streets (bet/raise menus), iterations, threads, trainer }
   */
  function postflopIdentity(input) {
    ok(input && input.engine && /^[0-9a-f]{16}$/.test(input.engine.build), 'Engine build required');
    ok(['flop', 'turn', 'river'].includes(input.street), 'Street must be flop, turn or river');
    const n = input.stacksBehind.length; ok(n >= 2 && n <= 8 && input.ranges.length === n, 'Player count and ranges disagree');
    ok({ flop: 3, turn: 4, river: 5 }[input.street] === input.board.length, 'Board length does not match the street');
    const iso = input.isomorphism !== false && rangesSuitSymmetric(input.ranges), cb = canonicalBoard(input.board, iso);
    const stacks = input.stacksBehind.map(r2), sorted = stacks.slice().sort((a, b) => b - a), eff = sorted[1];
    const id = {
      schema: SCHEMA, schemaVersion: SCHEMA_VERSION, kind: 'postflop-street-start',
      engine: { version: input.engine.version, build: input.engine.build },
      rules: { variant: 'no-limit-holdem', tableSeats: 8, blinds: { sb: input.blinds.sb, bb: input.blinds.bb, ante: input.blinds.ante || 0 }, chipUnit: '100 chips = 1 BB' },
      street: input.street, board: cb.board, boardForm: iso ? 'suit-canonical' : 'as-dealt-sorted',
      players: n, stacksBehindBB: stacks, potBB: r2(input.pot), effectiveStackBB: eff, spr: r2(eff / Math.max(0.01, input.pot)),
      priorHistory: 'summarised by pot, stacks behind, live players and the range model',
      rangeModel: input.rangeModel || 'fixed', ranges: input.ranges.slice(),
      tree: JSON.parse(JSON.stringify(input.streets)), abstraction: ABSTRACTION,
      training: { iterations: input.iterations, threads: input.threads || 1, trainer: input.trainer || 'native-cli-cpu', seedPolicy: 'derived-from-identity' },
    };
    return { identity: id, fingerprint: fingerprint(id), suitPermutation: cb.perm, isomorphismApplied: cb.applied };
  }
  /** Deterministic private seed for a study: derived from the identity WITHOUT the seed, so identical identities train identically. */
  const seedOf = (identity) => parseInt(sha256Hex('seed:' + canonical(identity)).slice(0, 8), 16) % 4294967295;

  /** Identity of a whole preflop study (e.g. the eight-handed linked tree) trained by the native engine. */
  function preflopIdentity(input) {
    const id = { schema: SCHEMA, schemaVersion: SCHEMA_VERSION, kind: 'preflop-tree', engine: { version: input.engine.version, build: input.engine.build },
      rules: { variant: 'no-limit-holdem', tableSeats: 8, blinds: input.blinds, chipUnit: '100 chips = 1 BB' }, players: input.config.stacks.length,
      config: JSON.parse(JSON.stringify(input.config)), abstraction: ABSTRACTION, training: { iterations: input.iterations, trainer: input.trainer || 'native-cli-cpu' } };
    return { identity: id, fingerprint: fingerprint(id) };
  }

  /** Structural comparison of two identities: returns the list of differing top-level paths (empty = identical). */
  function diff(a, b, pfx = '') {
    if (canonical(a) === canonical(b)) return [];
    if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) {
      const keys = new Set([...Object.keys(a), ...Object.keys(b)]); const out = []; for (const k of keys) out.push(...diff(a[k], b[k], pfx + k + '.')); return out;
    }
    return [pfx.replace(/\.$/, '') || '(root)'];
  }
  /** Short human summary for dashboards and miss logs. */
  function describe(id) {
    if (id.kind === 'postflop-street-start') return id.street + ' ' + id.board + ', ' + id.players + ' players, pot ' + id.potBB + ' bb, stacks ' + id.stacksBehindBB.join('/') + ' bb, SPR ' + id.spr + ', ' + id.training.iterations + ' updates';
    if (id.kind === 'preflop-tree') return 'preflop tree, ' + id.players + ' players, ' + id.training.iterations + ' updates';
    return id.kind;
  }
  /** Coverage category helpers (reports keep preflop, flop, turn, river, heads-up/multiway and stack depth apart). */
  function stackCategory(effBB) { return effBB < 10 ? 'short (<10 bb)' : effBB < 20 ? 'medium (10-20 bb)' : effBB < 40 ? 'standard (20-40 bb)' : 'deep (40+ bb)'; }

  return { SCHEMA, SCHEMA_VERSION, ABSTRACTION, sha256Hex, canonical, fingerprint, cardStr, cardId, applyPerm, PERMS, rangesSuitSymmetric, canonicalBoard, postflopIdentity, preflopIdentity, seedOf, diff, describe, stackCategory };
});
