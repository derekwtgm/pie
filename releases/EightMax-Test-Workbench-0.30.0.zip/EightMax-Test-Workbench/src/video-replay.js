'use strict';
/* EightMax Test Workbench 0.26: video-file replay for offline recognition tests.
 *
 * Decoding is done by FFmpeg, driven as a child process (rawvideo RGBA on a pipe). FFmpeg is NOT bundled in this archive (no network access was
 * available to fetch a redistributable build; see docs/VIDEO-REPLAY.md): put ffmpeg.exe (and optionally ffprobe.exe) in tools/ffmpeg/, set
 * EIGHTMAX_FFMPEG, or have it on PATH. Without it every function here fails with code 'no-ffmpeg' and says so - nothing is faked.
 *
 * Frames carry: seq (never reused, also across seeks), tMs (NOMINAL sample time in the video = start + n x interval; the raw pipe carries no
 * container timestamps), width, height, RGBA data. Replay can be paused, resumed, seeked and stopped; a paused replay applies back-pressure to
 * the decoder (it does not buffer the whole video). Memory is bounded: at most one frame is held in the generator plus the pipe's buffer. */
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process');

class ReplayError extends Error { constructor(code, message) { super(message); this.code = code; this.name = 'ReplayError'; } }
const exeName = (n) => (process.platform === 'win32' ? n + '.exe' : n);

function locate(tool, opts = {}) {
  const env = tool === 'ffmpeg' ? process.env.EIGHTMAX_FFMPEG : process.env.EIGHTMAX_FFPROBE, cands = [opts[tool], env, path.join(__dirname, '..', 'tools', 'ffmpeg', exeName(tool))].filter(Boolean);
  for (const c of cands) if (fs.existsSync(c)) return c;
  const dirs = (process.env.PATH || '').split(path.delimiter); for (const d of dirs) { const f = path.join(d, exeName(tool)); if (d && fs.existsSync(f)) return f; }
  return null;
}
function run(bin, args, timeoutMs = 60000) {
  return new Promise((resolve, reject) => {
    const c = cp.spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'] }); let out = '', err = ''; const t = setTimeout(() => { c.kill('SIGKILL'); reject(new ReplayError('timeout', bin + ' timed out')); }, timeoutMs);
    c.stdout.on('data', (d) => { out += d; }); c.stderr.on('data', (d) => { err += d; }); c.on('error', (e) => { clearTimeout(t); reject(new ReplayError('spawn', e.message)); });
    c.on('close', (code) => {   // 0.30: 'close', so stdout/stderr are complete
    clearTimeout(t); resolve({ code, out, err }); });
  });
}

/** Video facts: duration, size, frame rate, codec. Uses ffprobe when present, otherwise parses `ffmpeg -i`. */
async function probe(file, opts = {}) {
  if (!fs.existsSync(file)) throw new ReplayError('no-file', 'Video file not found: ' + file);
  const fp = locate('ffprobe', opts), ff = locate('ffmpeg', opts); if (!fp && !ff) throw new ReplayError('no-ffmpeg', 'FFmpeg was not found. Put ffmpeg.exe in tools\\ffmpeg\\, set EIGHTMAX_FFMPEG, or add it to PATH (docs/VIDEO-REPLAY.md).');
  if (fp) {
    const r = await run(fp, ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height,avg_frame_rate,codec_name,duration,nb_frames:format=duration', '-of', 'json', file]);
    let j; try { j = JSON.parse(r.out); } catch (e) { throw new ReplayError('unreadable', 'ffprobe could not read the file: ' + r.err.slice(0, 200)); }
    const s = (j.streams || [])[0]; if (!s) throw new ReplayError('no-video-stream', 'The file has no video stream');
    const [n, d] = String(s.avg_frame_rate || '0/1').split('/').map(Number), dur = parseFloat(s.duration || (j.format && j.format.duration) || 'NaN');
    return { file, width: s.width, height: s.height, codec: s.codec_name, fps: d ? n / d : null, durationMs: Number.isFinite(dur) ? Math.round(dur * 1000) : null, frames: s.nb_frames ? +s.nb_frames : null };
  }
  const r = await run(ff, ['-hide_banner', '-i', file]), m = r.err.match(/Duration: (\d+):(\d+):(\d+\.\d+)/), v = r.err.match(/Video: (\w+).*?, (\d+)x(\d+)/s), f = r.err.match(/(\d+(?:\.\d+)?) fps/);
  if (!v) throw new ReplayError('unreadable', 'FFmpeg could not find a video stream in the file');
  return { file, width: +v[2], height: +v[3], codec: v[1], fps: f ? +f[1] : null, durationMs: m ? Math.round(((+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3])) * 1000) : null, frames: null };
}

class VideoReplay {
  /** opts: intervalMs (spacing of sampled frames, default 500), startMs, endMs, maxFrames, scaleWidth (decode at this width; default native), ffmpeg (path) */
  static async open(file, opts = {}) { const info = await probe(file, opts); return new VideoReplay(file, info, opts); }
  constructor(file, info, opts) {
    this.file = file; this.info = info; this.ffmpeg = locate('ffmpeg', opts); if (!this.ffmpeg) throw new ReplayError('no-ffmpeg', 'ffmpeg is required to decode frames');
    this.intervalMs = opts.intervalMs === undefined ? 500 : opts.intervalMs; if (!(this.intervalMs >= 10 && this.intervalMs <= 3600000)) throw new ReplayError('bad-interval', 'Frame interval must be 10 ms to 1 hour');
    this.startMs = opts.startMs || 0; this.endMs = opts.endMs === undefined ? info.durationMs : opts.endMs; this.maxFrames = opts.maxFrames || Infinity; this.scaleWidth = opts.scaleWidth || null;
    if (this.startMs < 0 || (info.durationMs !== null && this.startMs > info.durationMs)) throw new ReplayError('bad-range', 'Start is outside the video');
    this.seq = 0; this.paused = false; this._resume = null; this._seekTo = null; this._child = null; this._closed = false; this.stats = { decoded: 0, restarts: 0, decodeMs: 0 };
  }
  get width() { return this.scaleWidth ? this.scaleWidth : this.info.width; } get height() { return this.scaleWidth ? Math.round(this.info.height * this.scaleWidth / this.info.width / 2) * 2 : this.info.height; }
  pause() { this.paused = true; if (this._child) this._child.stdout.pause(); }
  resume() { this.paused = false; if (this._child) this._child.stdout.resume(); if (this._resume) { const r = this._resume; this._resume = null; r(); } }
  /** Jump to a position (ms); takes effect before the next frame is delivered. */
  seek(ms) { if (!(ms >= 0) || (this.info.durationMs !== null && ms > this.info.durationMs)) throw new ReplayError('bad-seek', 'Seek position is outside the video'); this._seekTo = ms; if (this._child) this._child.kill('SIGKILL'); if (this._resume) this.resume(); }
  close() { this._closed = true; if (this._child) this._child.kill('SIGKILL'); if (this._resume) { const r = this._resume; this._resume = null; r(); } }

  _spawn(fromMs) {
    const w = this.width, h = this.height, vf = ['fps=' + (1000 / this.intervalMs)]; if (this.scaleWidth) vf.push('scale=' + w + ':' + h + ':flags=bilinear');
    const args = ['-v', 'error', '-nostdin', '-ss', (fromMs / 1000).toFixed(3), '-i', this.file]; if (this.endMs !== null && this.endMs !== undefined) args.push('-t', Math.max(0.001, (this.endMs - fromMs) / 1000).toFixed(3));
    args.push('-an', '-sn', '-vf', vf.join(','), '-f', 'rawvideo', '-pix_fmt', 'rgba', 'pipe:1');
    const c = cp.spawn(this.ffmpeg, args, { stdio: ['ignore', 'pipe', 'pipe'] }); let err = ''; c.stderr.on('data', (d) => { err += d; if (err.length > 20000) err = err.slice(-10000); }); c.errText = () => err; return c;
  }
  /** Async iterator of frames. Ends at the end of the range, after maxFrames, on close(), or throws ReplayError('decode') if FFmpeg fails. */
  async *frames() {
    let from = this.startMs, delivered = 0; const size = this.width * this.height * 4;
    while (!this._closed && delivered < this.maxFrames) {
      const c = this._child = this._spawn(from); this.stats.restarts++; let buf = Buffer.alloc(0), n = 0, exited = false, code = null;
      const done = new Promise((r) => c.on('exit', (cd) => { exited = true; code = cd; r(); })); c.on('error', () => { exited = true; });
      const chunks = []; let wake = null; c.stdout.on('data', (d) => { chunks.push(d); if (wake) { const w = wake; wake = null; w(); } }); c.stdout.on('end', () => { if (wake) { const w = wake; wake = null; w(); } });
      let ended = false; c.stdout.on('end', () => { ended = true; });
      try {
        for (;;) {
          while (buf.length < size && !ended && !this._seekTo && !this._closed) { if (!chunks.length) await new Promise((r) => { wake = r; if (chunks.length || ended) { wake = null; r(); } }); while (chunks.length) buf = Buffer.concat([buf, chunks.shift()]); }
          if (this._closed || this._seekTo !== null) break;
          if (buf.length < size) break;
          const t0 = Date.now(), data = new Uint8ClampedArray(buf.subarray(0, size)); buf = buf.subarray(size);
          const frame = { seq: this.seq++, tMs: from + n * this.intervalMs, width: this.width, height: this.height, data, source: 'video', file: this.file }; n++; delivered++; this.stats.decoded++; this.stats.decodeMs += Date.now() - t0;
          if (this.paused) { c.stdout.pause(); await new Promise((r) => { this._resume = r; }); if (this._closed) break; }
          yield frame; if (delivered >= this.maxFrames) break;
        }
      } finally { if (!exited) c.kill('SIGKILL'); await done.catch(() => {}); this._child = null; }
      if (this._closed) return;
      if (this._seekTo !== null) { from = this._seekTo; this._seekTo = null; continue; }
      if (code !== 0 && code !== null && !(delivered >= this.maxFrames)) { const t = c.errText(); if (code !== 137 && !/Invalid data|moov atom/.test(t) || /Invalid data|moov atom|No such file/.test(t)) throw new ReplayError('decode', 'FFmpeg failed (' + code + '): ' + t.slice(-300)); }
      return;
    }
  }
}

/**
 * Run recognition over a video and score it against reference truth.
 * opts: replay (VideoReplay), vision (ImageObserver), engine (HandStateEngine factory result or null), truthAt(frame) -> truth (metrics.truthFromTable shape) | null,
 *       metrics (MetricsCollector, domain 'video-replay'), heroSeatAt(frame) -> seat
 * Returns { frames: [{seq,tMs,status,reasons?}], report } - false acceptances are counted separately from correct acceptances and from rejections.
 */
async function recognizeVideo(opts) {
  const rows = []; for await (const f of opts.replay.frames()) {
    const hero = opts.heroSeatAt ? opts.heroSeatAt(f) : 0, truth = opts.truthAt ? opts.truthAt(f) : null;
    const r = opts.vision.observe({ width: f.width, height: f.height, data: f.data }, { heroSeat: hero, capturedAt: f.tMs, seq: f.seq });
    const er = r.ok && opts.engine ? opts.engine.ingest(r.observation) : null;
    if (truth && opts.metrics) opts.metrics.add('video-replay', { ...truth, heroSeat: hero }, r, er);
    rows.push({ seq: f.seq, tMs: f.tMs, status: r.ok ? (er ? (er.accepted ? 'accepted' : 'rejected-by-state') : 'read') : 'unreadable', reasons: r.ok ? (er && !er.accepted ? (er.issues || []).map((i) => i.code) : undefined) : r.reasons });
  }
  return { frames: rows, report: opts.metrics ? opts.metrics.report().domains['video-replay'] : null };
}

module.exports = { ReplayError, locate, probe, VideoReplay, recognizeVideo };
