/* EightMax Test Workbench 0.30: compact, immutable snapshot of one street of a trained study.
 *
 * Why: a full native EightMax state for a postflop study is 5-20 MB and importing it takes 0.3-1.6 s (measured on the
 * development machine, docs/STRATEGY-LIBRARY.md) - longer than training it. A decision at the start-of-street study only
 * ever reads nodes of that street, so the snapshot keeps exactly those: every decision node of the street (seat, pot,
 * stacks behind, live flags, menu labels), the study's range rows, and for each node the engine's average strategy for
 * every stored hand, as IEEE-754 doubles copied from averageAt(). Nothing is recomputed, rounded or smoothed: a snapshot
 * answers averageAt() bit-for-bit like the trained game it was exported from (tests/strategy-library-030 checks this).
 * Nodes behind a chance or terminal node are recorded only by kind; the next street has its own study.
 *
 * Binary body (little-endian):  "EMSS" | u32 version | u32 metaLen | meta JSON | pad to 8 | f64 probs[] | f64 ev[] | u16 keys[]
 * The library wraps the body with its own header, checksum and compression (src/strategy-library.js).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.WorkbenchStrategySnapshot = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = 1, RANKS = '23456789TJQKA', SUITS = 'cdhs';
  const ok = (x, m) => { if (!x) throw new Error(m); };
  const cs = (c) => RANKS[c >> 2] + SUITS[c & 3];
  const pairKey = (a, b) => (a < b ? a * 52 + b : b * 52 + a);

  /** Export the current street of a prepared, trained game. Returns { meta, probs:Float64Array, ev:Float64Array, keys:Uint16Array }. */
  function exportStreet(prepared, options = {}) {
    const g = prepared.game, spec = prepared.spec, nodes = [], probs = [], ev = [], keys = [];
    const maxNodes = options.maxNodes || 20000; let rowTotal = 0;
    const queue = [[]];
    // averageAt() re-evaluates the (board + hand) strength on every call although it does not depend on the node. When the engine
    // library is supplied, its pure evalCards() is memoised for the duration of the export (restored afterwards; results identical).
    const EMlib = options.EM, origEval = EMlib && EMlib.evalCards, memo = new Map();
    if (origEval) EMlib.evalCards = function (cards) { const k = cards.join(','); let v = memo.get(k); if (v === undefined) { v = origEval.apply(this, arguments); memo.set(k, v); } return v; };
    try {
    while (queue.length) {
      const steps = queue.shift(), v = g.view(steps), path = 'r' + steps.join('');
      if (v.kind !== 'player') { nodes.push(v.kind === 'terminal' ? { p: path, kind: v.kind, pot: v.pot, behind: v.behind, live: v.live } : { p: path, kind: v.kind }); continue; }   // 0.30: terminal geometry kept for independent exact evaluation
      ok(nodes.length < maxNodes, 'Street has more than ' + maxNodes + ' nodes; refusing to snapshot');
      const labels = v.actions.map((a) => a.label), k = labels.length, evBy = new Map();
      for (const h of v.hands || []) if (Array.isArray(h.ev) && h.ev.length === k) evBy.set(h.cards, h.ev);
      const rows = [];
      for (const r of spec.hands[v.seat]) {
        const pr = g.averageAt(path, spec.board, v.seat, { id: r[0], a: r[1], b: r[2], w: r[3] });
        if (!pr) continue; ok(pr.length === k, 'Strategy width differs from the menu at ' + path);
        rows.push({ key: pairKey(r[1], r[2]), pr, ev: evBy.get(cs(r[1]) + cs(r[2])) || evBy.get(cs(r[2]) + cs(r[1])) || null });
      }
      rows.sort((x, y) => x.key - y.key);
      const node = { p: path, kind: 'player', seat: v.seat, pot: v.pot, behind: v.behind, live: v.live, labels, k, ro: rowTotal, rc: rows.length, po: probs.length };
      for (const r of rows) { keys.push(r.key); for (let i = 0; i < k; i++) { probs.push(r.pr[i]); ev.push(r.ev ? r.ev[i] : NaN); } }
      rowTotal += rows.length; nodes.push(node);
      for (let i = 0; i < k; i++) queue.push(steps.concat(i));
    }
    } finally { if (origEval) EMlib.evalCards = origEval; }
    const meta = { format: 'eightmax-street-snapshot', version: VERSION, iterations: g.iterations, board: spec.board, hands: spec.hands, nodes, playerNodes: nodes.filter((n) => n.kind === 'player').length, rows: rowTotal };
    return { meta, probs: Float64Array.from(probs), ev: Float64Array.from(ev), keys: Uint16Array.from(keys) };
  }

  function encode(snap) {
    const metaBytes = new TextEncoder().encode(JSON.stringify(snap.meta)), head = 12 + metaBytes.length, pad = (8 - (head % 8)) % 8;
    const total = head + pad + snap.probs.byteLength + snap.ev.byteLength + snap.keys.byteLength, out = new Uint8Array(total), dv = new DataView(out.buffer);
    out.set([0x45, 0x4d, 0x53, 0x53]); dv.setUint32(4, VERSION, true); dv.setUint32(8, metaBytes.length, true); out.set(metaBytes, 12);
    let o = head + pad; const put = (ta) => { out.set(new Uint8Array(ta.buffer, ta.byteOffset, ta.byteLength), o); o += ta.byteLength; };
    put(snap.probs); put(snap.ev); put(snap.keys); return out;
  }

  /** Decode a body. With a SharedArrayBuffer-backed input the numeric arrays are views on that memory (no copy). */
  function decode(bytes) {
    ok(bytes && bytes.length >= 12 && bytes[0] === 0x45 && bytes[1] === 0x4d && bytes[2] === 0x53 && bytes[3] === 0x53, 'Not a street snapshot');
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength); ok(dv.getUint32(4, true) === VERSION, 'Unsupported snapshot version');
    const ml = dv.getUint32(8, true); ok(12 + ml <= bytes.length, 'Snapshot metadata truncated');
    const meta = JSON.parse(new TextDecoder().decode(bytes.subarray(12, 12 + ml)));
    const nProb = meta.nodes.reduce((n, x) => n + (x.kind === 'player' ? x.rc * x.k : 0), 0), nKeys = meta.rows;
    let o = 12 + ml; o += (8 - (o % 8)) % 8; ok(o + nProb * 16 + nKeys * 2 === bytes.length, 'Snapshot size does not match its metadata');
    const base = bytes.byteOffset + o; ok(base % 8 === 0, 'Snapshot buffer misaligned');
    const probs = new Float64Array(bytes.buffer, base, nProb), ev = new Float64Array(bytes.buffer, base + nProb * 8, nProb), keys = new Uint16Array(bytes.buffer, base + nProb * 16, nKeys);
    return new SnapshotGame(meta, probs, ev, keys, bytes.byteLength);
  }

  /** Read-only stand-in for a prepared EightMax game: view() and averageAt() for the snapshotted street. */
  class SnapshotGame {
    constructor(meta, probs, ev, keys, bytes) {
      this.meta = meta; this.probs = probs; this.ev = ev; this.keys = keys; this.bytes = bytes || 0;
      this.byPath = new Map(meta.nodes.map((n) => [n.p, n]));
      for (const n of meta.nodes) if (n.kind === 'player') { ok(n.ro + n.rc <= keys.length && n.po + n.rc * n.k <= probs.length, 'Snapshot node out of range'); }
    }
    get iterations() { return this.meta.iterations; }
    _row(n, key) { let lo = n.ro, hi = n.ro + n.rc - 1; while (lo <= hi) { const m = (lo + hi) >> 1, x = this.keys[m]; if (x === key) return m - n.ro; if (x < key) lo = m + 1; else hi = m - 1; } return -1; }
    view(steps) {
      const n = this.byPath.get('r' + steps.join(''));
      if (!n) return { kind: 'outside-snapshot' };
      if (n.kind !== 'player') return n.kind === 'terminal' && n.behind ? { kind: n.kind, pot: n.pot, behind: n.behind, live: n.live } : { kind: n.kind };
      const hands = [];
      for (let i = 0; i < n.rc; i++) { const off = n.po + i * n.k; if (Number.isNaN(this.ev[off])) continue; const key = this.keys[n.ro + i]; hands.push({ cards: cs(Math.floor(key / 52)) + cs(key % 52), ev: Array.from(this.ev.subarray(off, off + n.k)) }); }
      return { kind: 'player', seat: n.seat, pot: n.pot, behind: n.behind, live: n.live, actions: n.labels.map((label) => ({ label })), hands };
    }
    averageAt(path, board, seat, h) {
      const n = this.byPath.get(path); if (!n || n.kind !== 'player' || n.seat !== seat) return null;
      const i = this._row(n, pairKey(h.a, h.b)); if (i < 0) return null;
      const off = n.po + i * n.k; return Float64Array.from(this.probs.subarray(off, off + n.k));
    }
    /** Shape TreeStudy expects of a prepared study. */
    prepared(config) { return { game: this, spec: { hands: this.meta.hands, board: this.meta.board }, options: { config: config || null } }; }
  }

  return { VERSION, exportStreet, encode, decode, SnapshotGame, pairKey };
});
