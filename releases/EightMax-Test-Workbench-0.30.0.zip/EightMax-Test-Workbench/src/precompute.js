'use strict';
/* EightMax Test Workbench 0.30: background strategy precomputation (Study Mode work, never in a decision's critical path).
 *
 * - Jobs are spots (src/library-source.js spotFor): the exact identity plus the study configuration to train.
 * - The queue is persistent (queue.json in the library, replaced atomically). A job that was running when the process stopped is
 *   'interrupted' on the next open and is re-queued; its checkpoint (work/<fp>/checkpoint.state, written after every chunk)
 *   lets training continue from the last completed chunk instead of starting again.
 * - Priority: higher first, then oldest. Priorities from simulation data are the observed miss counts (planFromMisses).
 * - Resource rules, checked before every job start: at most `concurrency` jobs; free memory must exceed the reserve plus the
 *   job's budget; an optional pressure() hook (e.g. the decision service's backlog) pauses new starts. Running jobs are
 *   never killed by throttling; they are short (seconds) and checkpointed.
 * - A job is marked 'complete' only when the full update count trained, the snapshot exported and decoded, and the record
 *   was committed to the library. memory-limited / cancelled / failed / interrupted jobs are never stored as strategies.
 * - Completion is not convergence: records carry convergence 'unproven' unless a measurement says otherwise.
 */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { writeFileAtomic } = require('./strategy-library.js'), LS = require('./library-source.js');

const STATUSES = ['queued', 'running', 'complete', 'failed', 'memory-limited', 'cancelled', 'interrupted', 'already-stored'];

class PrecomputeQueue {
  /**
   * options: library, cli, EM, adapter, concurrency (default 1), threads (per job, default 1), memoryMiB (per job, default 512),
   *   reserveMiB (free memory kept for everything else, default 2048), freeMem() (default os.freemem), pressure() -> {pause:bool, reason},
   *   chunkUpdates (checkpoint interval, default 50,000 updates), workerThreads (run each job's JavaScript part in its own thread; default false), saveDebounceMs (queue file is rewritten at most once per interval; default 1000), maxQueue (default 100000), persist (default true), pollMs (default 50)
   */
  constructor(o) {
    if (!o || !o.library) throw new Error('A strategy library is required');
    this.o = { concurrency: 1, threads: 1, memoryMiB: 512, reserveMiB: 2048, chunkUpdates: 50000, saveDebounceMs: 1000, maxQueue: 100000, persist: true, pollMs: 50, freeMem: () => os.freemem(), ...o };
    this.lib = o.library; this.file = path.join(this.lib.dir, 'queue.json'); this.jobs = new Map(); this.running = new Map(); this.paused = false; this.closed = false; this.listeners = new Set();
    this.stats = { enqueued: 0, duplicates: 0, alreadyStored: 0, started: 0, completed: 0, failed: 0, memoryLimited: 0, cancelled: 0, resumed: 0, throttled: 0, trainMs: 0, totalJobMs: 0 };
    this._load();
  }
  _load() {
    if (!fs.existsSync(this.file)) return;
    let doc; try { doc = JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch (e) { fs.renameSync(this.file, this.file + '.damaged-' + Date.now()); return; }
    for (const j of doc.jobs || []) { if (j.status === 'running') { j.status = 'interrupted'; j.note = 'Process stopped while training; will resume from its last checkpoint'; } this.jobs.set(j.fingerprint, j); }
    for (const j of this.jobs.values()) if (j.status === 'interrupted') { j.status = 'queued'; j.resume = true; }
  }
  /** Persist the queue, at most once per saveDebounceMs (a large catalogue queue is several MB). Safe: a job that was running or
   *  finished after the last save is simply found 'queued' after a crash, and is then skipped (already stored) or resumed from its checkpoint. */
  _save(force) {
    if (!this.o.persist) return;
    if (!force && this.o.saveDebounceMs > 0) { if (!this._saveTimer) { this._saveTimer = setTimeout(() => { this._saveTimer = null; this._save(true); }, this.o.saveDebounceMs); if (this._saveTimer.unref) this._saveTimer.unref(); } return; }
    if (this._saveTimer) { clearTimeout(this._saveTimer); this._saveTimer = null; }
    this._writeQueue();
  }
  _writeQueue() { const jobs = [...this.jobs.values()].map(({ controller, ...j }) => (['complete', 'already-stored', 'cancelled'].includes(j.status) ? { ...j, spot: { street: j.spot && j.spot.street, players: j.spot && j.spot.players } } : j)); writeFileAtomic(this.file, JSON.stringify({ format: 'eightmax-precompute-queue', version: 1, savedAt: new Date().toISOString(), jobs })); }
  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  _emit(ev) { for (const fn of this.listeners) { try { fn(ev); } catch (e) { /* listener errors never stop training */ } } }

  /** Add a spot. Returns the job (existing one when the fingerprint is already queued). Priority: larger = sooner. */
  enqueue(spot, opts = {}) {
    if (this.closed) throw new Error('Queue closed');
    const fp = spot.fingerprint;
    if (this.lib.has(fp)) { this.stats.alreadyStored++; return { fingerprint: fp, status: 'already-stored' }; }
    const ex = this.jobs.get(fp);
    if (ex && ['queued', 'running'].includes(ex.status)) { this.stats.duplicates++; if ((opts.priority || 0) > ex.priority) { ex.priority = opts.priority; this._save(); } return ex; }
    if ([...this.jobs.values()].filter((j) => j.status === 'queued').length >= this.o.maxQueue) { const e = new Error('Training queue is full'); e.code = 'queue-full'; throw e; }
    const job = { fingerprint: fp, spot, priority: opts.priority || 0, reason: opts.reason || 'manual', status: 'queued', enqueuedAt: Date.now(), attempts: 0, progress: 0, error: null };
    this.jobs.set(fp, job); this.stats.enqueued++; this._save(); this._emit({ type: 'queued', job: this.view(job) }); this._pump(); return job;
  }
  /** Queue the most frequently missed situations (actual simulation frequency data). Returns how many were queued. */
  planFromMisses(limit = 100) {
    const s = this.lib.missSummary(limit); let n = 0;
    for (const m of s.list) if (m.spot) { const r = this.enqueue(m.spot, { priority: m.count, reason: 'observed ' + m.count + ' time(s) in simulation' }); if (r.status === 'queued') n++; }
    return { queued: n, distinctMisses: s.distinct, damagedLines: s.damagedLines };
  }
  cancel(fp) {
    const j = this.jobs.get(fp); if (!j) return false;
    if (j.status === 'queued') { j.status = 'cancelled'; this.stats.cancelled++; this._save(); this._emit({ type: 'cancelled', job: this.view(j) }); return true; }
    if (j.status === 'running' && j.controller) { j.controller.abort(); return true; }
    return false;
  }
  cancelAll() { let n = 0; for (const j of this.jobs.values()) if (this.cancel(j.fingerprint)) n++; return n; }
  pause() { this.paused = true; this._emit({ type: 'paused' }); }
  resume() { this.paused = false; this._emit({ type: 'resumed' }); this._pump(); }
  start() { this.paused = false; this._pump(); return this; }

  _next() { let best = null; for (const j of this.jobs.values()) if (j.status === 'queued' && (!best || j.priority > best.priority || (j.priority === best.priority && j.enqueuedAt < best.enqueuedAt))) best = j; return best; }
  _canStart() {
    if (this.paused || this.closed) return { ok: false, reason: 'paused' };
    if (this.running.size >= this.o.concurrency) return { ok: false, reason: 'concurrency limit' };
    const freeMiB = Math.floor(this.o.freeMem() / 1048576); if (freeMiB < this.o.reserveMiB + this.o.memoryMiB) return { ok: false, reason: 'memory: ' + freeMiB + ' MiB free, ' + (this.o.reserveMiB + this.o.memoryMiB) + ' MiB needed' };
    if (this.o.pressure) { const p = this.o.pressure(); if (p && p.pause) return { ok: false, reason: p.reason || 'decision workload has priority' }; }
    return { ok: true };
  }
  _pump() {
    if (this._pumping) return; this._pumping = true;
    try {
      for (;;) {
        const job = this._next(); if (!job) break;
        const c = this._canStart();
        if (!c.ok) { if (c.reason !== 'concurrency limit' && c.reason !== 'paused') { this.stats.throttled++; this.lastThrottle = c.reason; if (!this._retry) { this._retry = setTimeout(() => { this._retry = null; this._pump(); }, this.o.pollMs); if (!this._idle && this._retry.unref) this._retry.unref(); } } break; }
        this._run(job);
      }
    } finally { this._pumping = false; }
  }
  async _run(job) {
    if (this.lib.has(job.fingerprint)) { job.status = 'already-stored'; this.stats.alreadyStored++; this._save(); return; }
    job.status = 'running'; job.attempts++; job.startedAt = Date.now(); job.controller = new AbortController(); this.running.set(job.fingerprint, job); this.stats.started++; if (job.resume) this.stats.resumed++;
    this._save(); this._emit({ type: 'started', job: this.view(job) });
    const workDir = path.join(this.lib.dir, 'work', job.fingerprint.slice(0, 24));
    try {
      const opts = { cli: this.o.cli, threads: this.o.threads, memoryMiB: this.o.memoryMiB, workDir, chunkUpdates: this.o.chunkUpdates, faultAfterChunk: this.o.faultAfterChunk };
      const onProgress = (d, t) => { job.progress = d / t; this._emit({ type: 'progress', job: this.view(job) }); };
      const r = this.o.workerThreads ? await this._inWorker(job, opts, onProgress)
        : await LS.trainSpot(job.spot, { ...opts, EM: this.o.EM, adapter: this.o.adapter, signal: job.controller.signal, onProgress });
      this.lib.put(job.spot.identity, r.body, { status: 'complete', training: { ...r.training, queuedReason: job.reason } });
      job.status = 'complete'; job.training = r.training; this.stats.completed++; this.stats.trainMs += r.training.trainMs;
    } catch (e) {
      const code = e.code || 'failed';
      if (code === 'cancelled' && this.closing) { job.status = 'interrupted'; job.resume = true; }
      else if (code === 'cancelled') { job.status = 'cancelled'; this.stats.cancelled++; fs.rmSync(workDir, { recursive: true, force: true }); }
      else if (code === 'memory-limited') { job.status = 'memory-limited'; this.stats.memoryLimited++; }
      else if (code === 'simulated-interruption') { job.status = 'interrupted'; job.resume = true; }
      else { job.status = 'failed'; this.stats.failed++; }
      job.error = { code, message: e.message };
    } finally {
      job.finishedAt = Date.now(); this.stats.totalJobMs += job.finishedAt - job.startedAt; delete job.controller; this.running.delete(job.fingerprint);
      this._save(); this._emit({ type: job.status, job: this.view(job) });
      if (this._idle && !this.running.size && !this._next()) { this._save(true); const f = this._idle; this._idle = null; f(); }
      this._pump();
    }
  }
  /** Run trainSpot in a worker thread (workerThreads option): the job's JavaScript work no longer serialises on this thread. */
  _inWorker(job, options, onProgress) {
    const { Worker } = require('node:worker_threads');
    return new Promise((resolve, reject) => {
      const w = new Worker(path.join(__dirname, 'precompute-worker.js'), { workerData: { spot: job.spot, options } }); let settled = false;
      const fail = (code, msg) => { if (settled) return; settled = true; const e = new Error(msg); e.code = code; reject(e); };
      const onAbort = () => w.postMessage('abort'); job.controller.signal.addEventListener('abort', onAbort, { once: true });
      w.on('message', (m) => { if (m.type === 'progress') onProgress(m.done, m.total); else if (m.type === 'done') { settled = true; job.controller.signal.removeEventListener('abort', onAbort); w.terminate(); if (m.ok) resolve({ body: m.body, meta: m.meta, training: m.training }); else { const e = new Error(m.message); e.code = m.code; reject(e); } } });
      w.on('error', (e) => fail('worker-crashed', 'Training worker crashed: ' + e.message));
      w.on('exit', (c) => fail('worker-exited', 'Training worker exited (' + c + ') before finishing'));
    });
  }
  /** Resolves when nothing is queued or running (or the queue is paused with nothing running). */
  drain() { if (!this.running.size && (!this._next() || this.paused)) return Promise.resolve(); if (this._retry && this._retry.ref) this._retry.ref(); return new Promise((r) => { this._idle = r; }); }
  view(j) { return { fingerprint: j.fingerprint, status: j.status, priority: j.priority, reason: j.reason, progress: j.progress, attempts: j.attempts, street: j.spot && j.spot.street, players: j.spot && j.spot.players, error: j.error, training: j.training || null }; }
  status() {
    const counts = Object.fromEntries(STATUSES.map((s) => [s, 0])); for (const j of this.jobs.values()) counts[j.status] = (counts[j.status] || 0) + 1;
    return { format: 'eightmax-precompute-status', version: 1, paused: this.paused, running: [...this.running.values()].map((j) => this.view(j)), counts, stats: { ...this.stats }, lastThrottle: this.lastThrottle || null,
      next: [...this.jobs.values()].filter((j) => j.status === 'queued').sort((a, b) => b.priority - a.priority || a.enqueuedAt - b.enqueuedAt).slice(0, 10).map((j) => this.view(j)) };
  }
  close() { this.closed = true; this.closing = true; if (this._saveTimer) this._save(true); if (this._retry) clearTimeout(this._retry); for (const j of this.running.values()) if (j.controller) j.controller.abort(); }
}

module.exports = { PrecomputeQueue, STATUSES };
