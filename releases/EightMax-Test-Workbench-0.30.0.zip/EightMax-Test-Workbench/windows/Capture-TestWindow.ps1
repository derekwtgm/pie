param([Parameter(Mandatory=$true)][string]$InfoFile,[Parameter(Mandatory=$true)][string]$ControlFile,[int]$MaxSeconds=180)
# 0.29: test window for Test-Desktop.ps1's host-capture checks, in its OWN process with its own message loop.
# Found on a Windows runner: when the test script owned the window, a PrintWindow capture by the host sent WM_PRINT to the
# script's thread while that thread was blocked waiting for the host's HTTP reply - a deadlock (request timed out after 30 s).
# Control: write 'red' to the control file to change the colour, 'close' to close the window. Nothing else is read or captured.
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
if(-not ('EightMax.EmShowChild' -as [type])){Add-Type -Namespace EightMax -Name EmShowChild -MemberDefinition '[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr h, int cmd);'}
$form=New-Object Windows.Forms.Form;$form.Text='EightMax host capture check '+$PID;$form.ClientSize=New-Object Drawing.Size(480,300);$form.StartPosition='Manual';$form.Location=New-Object Drawing.Point(80,80);$form.BackColor=[Drawing.Color]::FromArgb(30,120,200);$form.ShowInTaskbar=$true
$label=New-Object Windows.Forms.Label;$label.Text='EightMax';$label.AutoSize=$true;$label.Font=New-Object Drawing.Font('Arial',28);$label.ForeColor=[Drawing.Color]::White;$label.Location=New-Object Drawing.Point(40,40);$form.Controls.Add($label)
$started=[Diagnostics.Stopwatch]::StartNew();$script:announced=$false
$timer=New-Object Windows.Forms.Timer;$timer.Interval=50
$timer.Add_Tick({
    if(-not $script:announced -and $form.Visible){
        # A hidden STARTUPINFO is applied to a process's first ShowWindow call, so show the window again explicitly.
        $null=[EightMax.EmShowChild]::ShowWindow($form.Handle,5);$form.Activate();$form.Refresh()
        $info=[ordered]@{hwnd='0x'+$form.Handle.ToInt64().ToString('x');pid=$PID;title=$form.Text;visible=$form.Visible}
        [IO.File]::WriteAllText($InfoFile+'.tmp',($info|ConvertTo-Json -Compress));Move-Item -LiteralPath ($InfoFile+'.tmp') -Destination $InfoFile -Force;$script:announced=$true
    }
    $command='';if(Test-Path -LiteralPath $ControlFile){try{$command=([IO.File]::ReadAllText($ControlFile)).Trim()}catch{}}
    if($command -eq 'red' -and $form.BackColor.R -ne 200){$form.BackColor=[Drawing.Color]::FromArgb(200,60,40);$form.Refresh()}
    if($command -eq 'close' -or $started.Elapsed.TotalSeconds -gt $MaxSeconds){$timer.Stop();$form.Close()}
})
$form.Add_Shown({$timer.Start()})
[Windows.Forms.Application]::Run($form)
$timer.Dispose();$form.Dispose()
