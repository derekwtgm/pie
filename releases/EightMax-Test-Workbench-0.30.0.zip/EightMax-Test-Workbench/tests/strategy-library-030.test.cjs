'use strict';
/* 0.30 strategy library: identity, bit-exact snapshots, storage integrity, recovery, cache, concurrency and decision modes. */
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto'), { Worker } = require('node:worker_threads');
const SID = require('../src/strategy-identity.js'), SNAP = require('../src/strategy-snapshot.js'), L = require('../src/strategy-library.js'), LS = require('../src/library-source.js');
const EMlib = require('./load-solver.cjs'), A = require('../src/study-adapter.js'), HS = require('../src/hand-state.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'em-lib-test-'));
const cards = (s) => s.match(/../g);
const RIVER = { street: 'river', board: cards('AsKd7h4c2s'), stacksBehind: [10, 10], pot: 4 };
let trainedCache = new Map();
async function trained(params, iterations = 3000) {
  const k = JSON.stringify([params, iterations]); if (trainedCache.has(k)) return trainedCache.get(k);
  const b = LS.spotFromParams(params, { iterations, trainerName: 'javascript-reference-cpu' }); const r = await LS.trainSpot(b.spot, {});
  const v = { ...b, ...r }; trainedCache.set(k, v); return v;
}

/* ---------- 1. identity and fingerprints ---------- */
test('SHA-256 (pure JS) equals node:crypto and the canonical encoding is key-order independent', () => {
  for (const s of ['', 'abc', 'x'.repeat(1000), 'ünïcødé ♠♥']) assert.equal(SID.sha256Hex(s), crypto.createHash('sha256').update(s, 'utf8').digest('hex'));
  assert.equal(SID.canonical({ b: 1, a: [2, { d: 3, c: 4 }] }), SID.canonical({ a: [2, { c: 4, d: 3 }], b: 1 }));
  assert.throws(() => SID.canonical({ a: NaN }), /finite/);
});
test('every game-defining input changes the fingerprint; nothing hand- or table-specific is part of it', () => {
  const base = LS.spotFromParams(RIVER, {}).fingerprint;
  const variants = [{ ...RIVER, stacksBehind: [10, 10.01] }, { ...RIVER, pot: 4.01 }, { ...RIVER, board: cards('AsKd7h4c3s') }, { ...RIVER, blinds: { sb: 50, bb: 100, ante: 0 } }, { ...RIVER, stacksBehind: [10, 10, 10] }, { ...RIVER, street: 'turn', board: cards('AsKd7h4c') }];
  const fps = variants.map((v) => LS.spotFromParams(v, {}).fingerprint); fps.forEach((f) => assert.notEqual(f, base)); assert.equal(new Set(fps).size, fps.length);
  assert.notEqual(LS.spotFromParams(RIVER, { iterations: 20001 }).fingerprint, base, 'training length');
  assert.notEqual(LS.spotFromParams(RIVER, { engine: { version: '5.3', build: '0123456789abcdef' } }).fingerprint, base, 'engine build');
  assert.notEqual(LS.spotFromParams(RIVER, { streets: LS.COMPACT1 }).fingerprint, base, 'action tree');
  assert.notEqual(LS.spotFromParams({ ...RIVER, ranges: ['random', 'AA,KK'] }, {}).fingerprint, base, 'ranges');
  assert.equal(LS.spotFromParams(RIVER, {}).fingerprint, base, 'deterministic');
  const id = LS.spotFromParams(RIVER, {}).identity; for (const k of ['table', 'hand', 'hero', 'holeCards']) assert.equal(JSON.stringify(id).includes('"' + k + '"'), false, k + ' must not be in the identity');
});
test('suit isomorphism is exact and is disabled by suit-specific ranges', () => {
  const a = LS.spotFromParams({ ...RIVER, board: cards('AsKd7h4c2s') }, {}), b = LS.spotFromParams({ ...RIVER, board: cards('AhKc7d4s2h') }, {});
  assert.equal(a.fingerprint, b.fingerprint, 'suit relabelling of the same board');
  const r = [0, 1, 2, 3].map((s) => SID.applyPerm(SID.cardId('As'), b.suitPermutation)); assert.ok(r.every((x) => x >> 2 === 12));
  // mapping the dealt board with its permutation gives exactly the canonical board
  const mapped = cards('AhKc7d4s2h').map(SID.cardId).map((c) => SID.applyPerm(c, b.suitPermutation)).sort((x, y) => y - x).map(SID.cardStr).join(''); assert.equal(mapped, b.identity.board);
  assert.equal(SID.rangesSuitSymmetric(['22+,A2s+,KTo', 'random']), true); assert.equal(SID.rangesSuitSymmetric(['AhKh,QQ']), false);
  const s1 = LS.spotFromParams({ ...RIVER, ranges: ['AhKh,QQ', 'random'], board: cards('AsKd7h4c2s') }, {}), s2 = LS.spotFromParams({ ...RIVER, ranges: ['AhKh,QQ', 'random'], board: cards('AhKc7d4s2h') }, {});
  assert.notEqual(s1.fingerprint, s2.fingerprint); assert.equal(s1.identity.boardForm, 'as-dealt-sorted');
});
test('1,755 suit-canonical flops', () => { assert.equal(require('../tools/strategy-library.cjs').canonicalFlops().length, 1755); });

/* ---------- 2. snapshots reproduce the study bit for bit ---------- */
test('snapshot answers averageAt() and node geometry exactly like the trained game (every node, every row)', async () => {
  const b = LS.spotFromParams({ street: 'flop', board: cards('Td7c2h'), stacksBehind: [12, 12, 12], pot: 4.5 }, { iterations: 1500 });
  const prepared = A.prepare(EMlib, { config: b.spot.config, iterations: 1500, timeMs: 600000 }); prepared.game.iterate(1500);
  const game = SNAP.decode(SNAP.encode(SNAP.exportStreet(prepared, { EM: EMlib }))); let rows = 0, nodes = 0;
  const q = [[]]; while (q.length) { const s = q.shift(), v = prepared.game.view(s), w = game.view(s); assert.equal(w.kind, v.kind); if (v.kind !== 'player') continue; nodes++;
    assert.deepEqual([w.seat, w.pot, w.behind, w.live, w.actions.map((x) => x.label)], [v.seat, v.pot, v.behind, v.live, v.actions.map((x) => x.label)]);
    for (const r of prepared.spec.hands[v.seat]) { const h = { id: r[0], a: r[1], b: r[2], w: r[3] }, x = prepared.game.averageAt('r' + s.join(''), prepared.spec.board, v.seat, h), y = game.averageAt('r' + s.join(''), prepared.spec.board, v.seat, h); assert.equal(!!x, !!y); if (x) { rows++; assert.deepEqual(Array.from(y), Array.from(x)); } }
    for (let i = 0; i < v.actions.length; i++) q.push(s.concat(i)); }
  assert.ok(nodes > 10 && rows > 1000, nodes + ' nodes, ' + rows + ' rows compared');
  assert.equal(game.averageAt('r', '', 1, { a: 0, b: 1 }), null, 'wrong seat at the root is not answered');
});

/* ---------- 3. storage, integrity, recovery ---------- */
test('exact retrieval after restart; different configuration is a miss; damaged, truncated and foreign records are refused', async () => {
  const dir = tmp(), t = await trained(RIVER); let lib = L.StrategyLibrary.open(dir);
  const w = lib.put(t.identity, t.body, { status: 'complete', training: t.training }); assert.equal(w.duplicate, false);
  assert.equal(lib.put(t.identity, t.body, { status: 'complete' }).duplicate, true, 'idempotent');
  assert.throws(() => lib.put(t.identity, t.body, { status: 'memory-limited' }), /Only completed/);
  assert.throws(() => lib.put({ ...t.identity, engine: { version: '5.3', build: '0123456789abcdef' } }, t.body, { status: 'complete' }), (e) => e.code === 'engine-mismatch');
  lib = L.StrategyLibrary.open(dir);   // restart
  const g = lib.get(t.identity); assert.equal(g.ok, true); assert.equal(g.source, 'disk'); assert.equal(lib.get(t.identity).source, 'memory');
  const other = LS.spotFromParams({ ...RIVER, pot: 4.5 }, { iterations: 3000, trainerName: 'javascript-reference-cpu' }); const m = lib.get(other.identity); assert.equal(m.ok, false); assert.equal(m.code, 'library-miss');
  // a record stored under a fingerprint whose identity differs (e.g. copied by hand) is refused
  fs.mkdirSync(path.dirname(lib.file(other.fingerprint)), { recursive: true }); fs.copyFileSync(lib.file(t.fingerprint), lib.file(other.fingerprint));
  const lib2 = L.StrategyLibrary.open(dir, { create: false, readOnly: true }); assert.equal(lib2.get(other.identity).code, 'fingerprint-mismatch'); fs.rmSync(lib.file(other.fingerprint));
  // identity check is on the whole identity, not just the hash
  const forged = JSON.parse(JSON.stringify(t.identity)); forged.potBB = 99; const lib3 = L.StrategyLibrary.open(dir); assert.equal(lib3.get(forged, t.fingerprint).code, 'identity-mismatch');
  // one flipped byte in the payload
  const f = lib.file(t.fingerprint), orig = fs.readFileSync(f), bad = Buffer.from(orig); bad[bad.length - 20] ^= 0xff; fs.writeFileSync(f, bad);
  assert.equal(L.StrategyLibrary.open(dir, { readOnly: true }).get(t.identity).code, 'checksum');
  fs.writeFileSync(f, orig.subarray(0, orig.length - 100)); assert.equal(L.StrategyLibrary.open(dir, { readOnly: true }).get(t.identity).code, 'truncated');
  fs.writeFileSync(f, orig); assert.equal(L.StrategyLibrary.open(dir, { readOnly: true }).get(t.identity).ok, true);
  const v = L.StrategyLibrary.open(dir).verifyAll(); assert.equal(v.ok, 1); assert.equal(v.damaged.length, 0);
  fs.writeFileSync(f, bad); const v2 = L.StrategyLibrary.open(dir, { readOnly: true }).verifyAll(); assert.equal(v2.damaged.length, 1); assert.equal(v2.damaged[0].code, 'checksum');
});
test('engine version mismatch: a library opened for another engine build refuses stored strategies', async () => {
  const dir = tmp(), t = await trained(RIVER); L.StrategyLibrary.open(dir).put(t.identity, t.body, { status: 'complete' });
  const other = L.StrategyLibrary.open(dir, { engine: { version: '5.3', build: 'aaaaaaaaaaaaaaaa' } }); const r = other.get(t.identity); assert.equal(r.ok, false); assert.equal(r.code, 'engine-mismatch');
  assert.equal(other.verifyAll().engineMismatch.length, 1);
});
test('interrupted writes: a crash before the rename leaves no record (temp file removed on reopen); a crash before the index update is recovered', async () => {
  const dir = tmp(), t = await trained(RIVER);
  const l1 = L.StrategyLibrary.open(dir, { faultBeforeRename: true }); assert.throws(() => l1.put(t.identity, t.body, { status: 'complete' }), /Simulated interruption/);
  assert.equal(fs.existsSync(l1.file(t.fingerprint)), false); const temps = () => fs.readdirSync(path.dirname(l1.file(t.fingerprint))).filter((x) => x.includes('.tmp'));
  assert.equal(temps().length, 1); const l2 = L.StrategyLibrary.open(dir); assert.equal(l2.lastRecovery.tempFilesRemoved, 1); assert.equal(temps().length, 0); assert.equal(l2.get(t.identity).ok, false);
  const l3 = L.StrategyLibrary.open(dir, { faultBeforeIndex: true }); assert.throws(() => l3.put(t.identity, t.body, { status: 'complete' }), /before the index/);
  const l4 = L.StrategyLibrary.open(dir); assert.equal(l4.lastRecovery.recordsAdded, 1); assert.equal(l4.list().length, 1); assert.equal(l4.get(t.identity).ok, true);
  fs.writeFileSync(path.join(dir, 'index.json'), '{damaged'); const l5 = L.StrategyLibrary.open(dir); assert.equal(l5.lastRecovery.indexRebuilt, true); assert.equal(l5.list().length, 1);
  // a record damaged on disk is moved to quarantine during recovery, never indexed
  fs.rmSync(path.join(dir, 'index.json')); const f = l5.file(t.fingerprint), b = fs.readFileSync(f); b[b.length - 5] ^= 1; fs.writeFileSync(f, b);
  const l6 = L.StrategyLibrary.open(dir); assert.equal(l6.lastRecovery.quarantined, 1); assert.equal(l6.list().length, 0); assert.equal(fs.readdirSync(path.join(dir, 'quarantine')).length, 1);
});
test('stale write lock of a dead process is taken over; a live lock times out cleanly', async () => {
  const dir = tmp(), t = await trained(RIVER), lib = L.StrategyLibrary.open(dir);
  fs.writeFileSync(path.join(dir, 'write.lock'), JSON.stringify({ pid: 999999, host: os.hostname(), at: 0 })); assert.equal(lib.put(t.identity, t.body, { status: 'complete' }).duplicate, false);
  fs.writeFileSync(path.join(dir, 'write.lock'), JSON.stringify({ pid: process.pid, host: os.hostname(), at: Date.now() })); assert.throws(() => lib._lock(50), (e) => e.code === 'lock-timeout'); fs.rmSync(path.join(dir, 'write.lock'));
});
test('cache: byte budget, LRU eviction, hit/miss counters, run-time budget change, nothing larger than the budget is cached', async () => {
  const dir = tmp(), lib = L.StrategyLibrary.open(dir), spots = [];
  for (const pot of [4, 5, 6]) { const t = await trained({ ...RIVER, pot }, 800); lib.put(t.identity, t.body, { status: 'complete' }); spots.push(t); }
  const one = spots[0].body.byteLength + 4096, c = L.StrategyLibrary.open(dir, { cacheBytes: one * 2 + 10 });
  for (const s of spots) assert.equal(c.get(s.identity).source, 'disk');
  assert.equal(c.cache.size, 2); assert.equal(c.stats.evictions, 1); assert.equal(c.get(spots[0].identity).source, 'disk', 'evicted LRU entry reloads from disk');
  assert.equal(c.get(spots[0].identity).source, 'memory'); assert.ok(c.cacheUsed <= one * 2 + 10);
  c.setCacheBudget(0); assert.equal(c.cache.size, 0); assert.equal(c.get(spots[1].identity).ok, true); assert.equal(c.cache.size, 0, 'over-budget entries are used but not cached');
  assert.equal(c.stats.memoryHits, 1); assert.ok(c.stats.diskHits >= 4);
});
test('import/export bundle round trip; damaged bundles and foreign-engine records are rejected', async () => {
  const a = L.StrategyLibrary.open(tmp()), t1 = await trained(RIVER), t2 = await trained({ ...RIVER, pot: 6 }, 800); a.put(t1.identity, t1.body, { status: 'complete' }); a.put(t2.identity, t2.body, { status: 'complete' });
  const bf = path.join(tmp(), 'x.emslb'); assert.equal(a.exportBundle(bf).records, 2);
  const b = L.StrategyLibrary.open(tmp()); const r = b.importBundle(bf); assert.equal(r.imported, 2); assert.equal(b.importBundle(bf).alreadyPresent, 2); assert.equal(b.get(t1.identity).ok, true);
  const bad = fs.readFileSync(bf); bad[100] ^= 1; fs.writeFileSync(bf, bad); assert.throws(() => L.StrategyLibrary.open(tmp()).importBundle(bf), /checksum/);
  const c = L.StrategyLibrary.open(tmp(), { engine: { version: '9', build: 'bbbbbbbbbbbbbbbb' } }); bad[100] ^= 1; fs.writeFileSync(bf, bad); const rc = c.importBundle(bf); assert.equal(rc.imported, 0); assert.equal(rc.rejected.length, 2);
});
test('concurrent reads from four threads return identical, verified strategies', async () => {
  const dir = tmp(), t = await trained(RIVER); L.StrategyLibrary.open(dir).put(t.identity, t.body, { status: 'complete' });
  const code = `const { parentPort, workerData } = require('node:worker_threads'); const L = require(${JSON.stringify(path.join(__dirname, '../src/strategy-library.js'))});
    const lib = L.StrategyLibrary.open(workerData.dir, { readOnly: true }); let ok = 0, sum = 0; for (let i = 0; i < 200; i++) { lib.clearCache(); const g = lib.get(workerData.identity); if (g.ok) { ok++; sum += g.game.probs[7]; } } parentPort.postMessage({ ok, sum });`;
  const res = await Promise.all([1, 2, 3, 4].map(() => new Promise((r, j) => { const w = new Worker(code, { eval: true, workerData: { dir, identity: t.identity } }); w.on('message', r); w.on('error', j); })));
  assert.ok(res.every((x) => x.ok === 200)); assert.equal(new Set(res.map((x) => x.sum)).size, 1);
});
test('resource plan reads the machine and never assumes 16 GB is free', () => {
  const p16 = L.planResources({ totalRamBytes: 16 * 2 ** 30, freeRamBytes: 9 * 2 ** 30 }); assert.ok(p16.cacheMiB >= 32 && p16.cacheMiB <= 2048); assert.ok(p16.trainingJobs >= 1);
  const low = L.planResources({ totalRamBytes: 16 * 2 ** 30, freeRamBytes: 1 * 2 ** 30 }); assert.equal(low.trainingJobs, 0); assert.match(low.note, /paused/);
  const custom = L.planResources({ totalRamBytes: 16 * 2 ** 30, freeRamBytes: 12 * 2 ** 30, reservations: { windows: 8000 } }); assert.ok(custom.cacheMiB < p16.cacheMiB);
});

/* ---------- 4. decision modes ---------- */
function riverRequest(over = {}) {
  // heads-up river, button 0: seats 1 (first to act) and 2 live; seat order follows the button.
  const board = cards('AsKd7h4c2s').map(HS.cardFromString), sb = Array(8).fill(0); sb[1] = 1000; sb[2] = 1000;
  const live = Array(8).fill(false); live[1] = live[2] = true;
  const seatsState = Array.from({ length: 8 }, (_, i) => ({ stack: live[i] ? 1000 : 2400, bet: 0, total: 0, folded: !live[i] }));
  return { format: 'eightmax-decision-request', version: 1, table: 3, hand: 17, revision: 5, stateKey: 'k', street: 'river', actor: 1, button: 0, holeCards: [HS.cardFromString('Qh'), HS.cardFromString('Jh')], board, actions: [],
    stacks: Array(8).fill(2500), toCall: 0, priority: 1, deadlineMs: 2000, pot: 400, currentBet: 0, blinds: { sb: 50, bb: 100, ante: 10 }, seatsState, streetStart: { pot: 400, behind: sb, live },
    legal: { toCall: 0, callAmount: 0, canCheck: true, canCall: false, canFold: false, canRaise: true, minRaiseTo: 100, maxRaiseTo: 1000 }, ...over };
}
test('Decision Mode never trains: a miss is "unavailable" with the missing configuration, logged for training, no probabilities invented', async () => {
  const lib = L.StrategyLibrary.open(tmp()); let queued = null;
  const src = new LS.LibraryDecisionSource({ library: lib, mode: 'decision', iterations: 3000, trainerName: 'javascript-reference-cpu', onMiss: (spot) => { queued = spot; } });
  const d = await src.decide(riverRequest()); assert.equal(d.status, 'unavailable'); assert.equal(d.code, 'library-miss'); assert.match(d.reason, /No trained strategy is available for this situation/);
  assert.equal(d.probabilities, undefined); assert.ok(d.missingStrategy.fingerprint && /river/.test(d.missingStrategy.summary)); assert.equal(src.stats.trainedInline, 0); assert.ok(queued && queued.fingerprint === d.missingStrategy.fingerprint);
  const ms = lib.missSummary(); assert.equal(ms.distinct, 1); assert.equal(ms.list[0].spot.fingerprint, d.missingStrategy.fingerprint);
});
test('Study Mode trains, stores and answers; the stored strategy is then served from disk to Decision Mode with the same probabilities', async () => {
  const dir = tmp(), lib = L.StrategyLibrary.open(dir);
  const study = new LS.LibraryDecisionSource({ library: lib, mode: 'study', iterations: 3000, trainerName: 'javascript-reference-cpu' });
  const d1 = await study.decide(riverRequest()); assert.equal(d1.status, 'ok', d1.reason); assert.equal(d1.strategySource, 'trained-now'); assert.equal(study.stats.trainedInline, 1);
  const dec = new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(dir), mode: 'decision', iterations: 3000, trainerName: 'javascript-reference-cpu' });
  const d2 = await dec.decide(riverRequest()); assert.equal(d2.status, 'ok'); assert.equal(d2.strategySource, 'library-disk'); assert.deepEqual(d2.probabilities, d1.probabilities); assert.deepEqual(d2.labels, d1.labels);
  const d3 = await dec.decide(riverRequest({ table: 9, hand: 99 })); assert.equal(d3.strategySource, 'library-memory'); assert.deepEqual(d3.probabilities, d1.probabilities, 'same situation on another table reuses the study');
  assert.equal(d2.certification, 'none'); assert.ok(d2.convergence && d2.convergence.verdict === 'unproven');
  // suit-isomorphic board: same stored study, hole cards relabelled consistently
  const iso = { h: 's', s: 'h', d: 'c', c: 'd' }, relabel = (s) => s[0] + iso[s[1]];
  const d4 = await dec.decide(riverRequest({ board: cards('AsKd7h4c2s').map(relabel).map(HS.cardFromString), holeCards: ['Qh', 'Jh'].map(relabel).map(HS.cardFromString) }));
  assert.equal(d4.status, 'ok'); assert.equal(d4.libraryFingerprint, d2.libraryFingerprint); assert.deepEqual(d4.probabilities, d2.probabilities); assert.ok(d4.isomorphism);
  // a different stack is a different game: not served
  const req = riverRequest(); req.streetStart.behind[2] = 990; req.seatsState[2].stack = 990; const d5 = await dec.decide(req); assert.equal(d5.code, 'library-miss');
});
test('deadline policy: inline training only when the measured estimate fits the remaining deadline', async () => {
  const lib = L.StrategyLibrary.open(tmp()), est = new LS.TrainingEstimator({ 2: 5000 });
  const src = new LS.LibraryDecisionSource({ library: lib, mode: 'deadline', iterations: 3000, trainerName: 'javascript-reference-cpu', estimator: est });
  const d1 = await src.decide(riverRequest({ deadlineMs: 2000 })); assert.equal(d1.code, 'library-miss'); assert.equal(src.stats.inlineRefusedByDeadline, 1); assert.equal(src.stats.trainedInline, 0);
  for (let i = 0; i < 40; i++) est.add(2, 50);
  const d2 = await src.decide(riverRequest({ deadlineMs: 2000 })); assert.equal(d2.status, 'ok'); assert.equal(src.stats.trainedInline, 1);
  const fresh = new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(tmp()), mode: 'deadline', iterations: 3000, trainerName: 'javascript-reference-cpu' });
  assert.equal((await fresh.decide(riverRequest())).code, 'library-miss', 'no estimate yet: no inline training');
});
test('invalid observations and unsupported states are refused before any lookup', async () => {
  const src = new LS.LibraryDecisionSource({ library: L.StrategyLibrary.open(tmp()), mode: 'study', iterations: 3000 });
  assert.equal((await src.decide(riverRequest({ streetStart: null }))).code, 'invalid-observation');
  assert.equal((await src.decide(riverRequest({ legal: null }))).code, 'invalid-observation');
  assert.equal((await src.decide(riverRequest({ street: 'preflop', board: [] }))).code, 'street-not-covered');
  const r = riverRequest(); r.streetStart.behind[2] = 150; assert.equal((await src.decide(r)).code, 'stakes-or-stack-mismatch');
  const m = riverRequest(); for (let s = 1; s <= 7; s++) { m.streetStart.live[s] = true; m.streetStart.behind[s] = 1000; m.seatsState[s].folded = false; } assert.equal((await src.decide(m)).code, 'player-count-unsupported');
  assert.equal(src.stats.trainedInline, 0);
});
test('tree profile: heads-up and three-way keep the 0.29 menus; 4 players one size two bets; 5-6 players one size one bet', () => {
  const ST = require('../src/solver-tree.js'); assert.equal(LS.treeProfile030(2), ST.DEFAULT_STREETS); assert.equal(LS.treeProfile030(3), ST.DEFAULT_STREETS);
  assert.equal(LS.treeProfile030(4).flop.maxBets, 2); assert.equal(LS.treeProfile030(6).flop.maxBets, 1);
});
