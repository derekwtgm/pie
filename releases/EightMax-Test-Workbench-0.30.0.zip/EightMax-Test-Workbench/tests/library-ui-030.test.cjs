'use strict';
/* 0.30 dashboard, desktop-host and launcher wiring for the strategy library. */
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path');
const root = path.join(__dirname, '..'), read = (p) => fs.readFileSync(path.join(root, p), 'utf8'), V = require('../src/strategy-library-view.js');
test('plain-language view of the library status, including the missing-strategy message', () => {
  assert.equal(V.view({ available: false, message: 'x' }).available, false);
  const v = V.view({ records: 3, dir: 'D', storageBytes: 2048, rawBytes: 4096, byStreet: { flop: 2, river: 1 }, byPlayers: { 'heads-up': 3 }, byStackCategory: {}, byConvergence: { unproven: 3 }, pendingMisses: 5, lastVerify: { ok: 2, checked: 3, damaged: [{}] } });
  const rows = Object.fromEntries(v.rows); assert.equal(rows['Available strategies'], '3'); assert.match(rows['Accuracy status'], /not proven 3/); assert.match(rows['Last verification'], /DAMAGED/); assert.ok(v.warning);
  assert.match(V.explain('library-miss'), /No trained strategy is available for this situation\. Add it to the training queue/);
  assert.match(V.decisionProvenance({ strategySource: 'library-disk', cache: 'miss', timings: { totalMs: 3.2 }, convergence: { verdict: 'unproven' } }), /loaded from disk.*cache miss.*3\.2 ms.*not proven/);
});
test('dashboard panel, host route, launch tools and .cmd launchers agree', () => {
  const html = read('START.html'); for (const id of ['sl-panel', 'sl-nav', 'sl-precompute', 'sl-verify', 'sl-import', 'sl-export', 'sl-cancel', 'sl-record']) assert.ok(html.includes('id="' + id + '"'), id);
  assert.ok(html.includes('WorkbenchLibraryView')); assert.ok(!html.includes('<script src="src/'), 'START.html is self-contained');
  const host = read('desktop/DesktopHost.cs'); assert.match(host, /r\.Path=="\/api\/library\/status"/); assert.match(host, /strategyLibrary=true/);
  for (const [tool, cmd] of [['library-precompute', 'PRECOMPUTE-STRATEGIES.cmd'], ['library-verify', 'VERIFY-STRATEGIES.cmd'], ['library-cancel', 'CANCEL-TRAINING.cmd'], ['library-record', 'RECORD-SITUATIONS.cmd'], ['library-export', 'EXPORT-STRATEGIES.cmd'], ['library-import', 'IMPORT-STRATEGIES.cmd']]) {
    assert.ok(host.includes('{"' + tool + '","' + cmd + '"}'), tool); const c = fs.readFileSync(path.join(root, cmd), 'latin1'); assert.ok(c.includes('\r\n') && !/[^\r]\n/.test(c), cmd + ' uses CRLF'); assert.match(c, /tools\\strategy-library\.cjs/);
  }
});
test('component metadata is generated from evidence and never claims Windows execution without a matching hash', () => {
  const comp = JSON.parse(read('desktop/COMPONENT-VERSIONS.json')), ev = JSON.parse(read('evidence/windows-ci-runs.json')), crypto = require('node:crypto');
  assert.match(comp.generatedBy, /make-components\.py/);
  for (const [f, c] of Object.entries(comp.components)) { const h = crypto.createHash('sha256').update(fs.readFileSync(path.join(root, f))).digest('hex'); assert.equal(c.sha256, h, f);
    assert.equal(c.status.validatedInWindowsCI, ev.runs.some((r) => r.executables[f] === h), f); assert.equal(c.status.testedOnTargetHardware, (ev.targetHardware || []).some((r) => r.executables[f] === h), f); }
});
