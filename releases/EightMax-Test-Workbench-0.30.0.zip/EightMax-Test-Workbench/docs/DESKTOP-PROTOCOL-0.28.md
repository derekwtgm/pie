# Desktop host local protocol — 0.28.0 repairs

The desktop host (`desktop/DesktopHost.cs`, `EightMaxWorkbench.exe`) serves a private HTTP/1.1 API on `127.0.0.1:48713`.
Every API route needs the per-launch session token in `X-EightMax-Session`; a foreign `Origin` is refused. These checks are unchanged.

## The 0.26.0 "HTTP 400 — Bad Request" on the target PC
* **Confirmed defect (reproduced):** .NET Framework `HttpWebRequest` — the client behind Windows PowerShell 5.1 `Invoke-WebRequest` —
  adds `Expect: 100-continue` to every POST that has a body. 0.26 refused any request carrying an `Expect` header with HTTP 400
  `Invalid local request framing/host.` So job submission, cancel, resume and cancel-intent could never succeed from PowerShell.
  Reproduced by running the real host code (Mono) against `HttpWebRequest`; fixed: the host answers `100 Continue` and reads the body.
* **Not reproduced:** the 0.26 report shows that the **first** request, `GET /api/desktop/health`, also returned 400 on Windows. A GET
  carries no body and no `Expect` header, and the same GET succeeds against the same code here. The exact cause on that PC is
  therefore **still unknown**; candidates (a local proxy/security product rewriting loopback requests, a Host-header variant, a
  request-target in absolute form, header framing differences) are all now reported precisely, see below. The next Windows run
  will record it in `desktop-requests.log` / `desktop-requests.json` and in the raw protocol probe check.

## Error responses
Every refusal is JSON with: `error` (safe message, kept for older dashboards), `code`, `status`, `method`, `path`, `step`,
`requestId`, `appVersion`. Framing refusals also list the request's header NAMES (never values).

| Status | code | meaning |
|---|---|---|
| 400 | unsupported-request-line, unsupported-request-target, proxy-form-target, malformed-header, duplicate-header, missing-host, invalid-host, invalid-content-length, body-not-allowed, incomplete-request, incomplete-body | framing |
| 400 | invalid-request, capture-request-invalid | body/validation (message says what) |
| 403 | session-required | missing/wrong session token or foreign Origin |
| 404 | unknown-route | |
| 405 / 408 / 411 / 413 / 417 / 431 | method-not-allowed / request-timeout, body-timeout / chunked-not-supported / body-too-large / expectation-failed / headers-too-large | |
| 409 | conflict, host-must-be-closed | state conflict |
| 500 | internal-error | unexpected exception (type + message) |
| 503 | host-busy, host-stopping | more than 8 concurrent requests / shutdown in progress |

Accepted Host values: `127.0.0.1:48713` and `localhost:48713` (both loopback; DNS-rebinding protection is kept).

## Request diagnostics
`%LOCALAPPDATA%\EightMax-Test-Workbench\Logs\desktop-requests.log` (1 MB, rotated once): time, request id, method, path,
client step (`X-EightMax-Step`), status, code, duration and reason. **Never** the token, header values or bodies.
`GET /api/desktop/requests` returns the last 200 lines. `windows\Test-Desktop.ps1` records every request it makes (step, method,
route, status, structured code, message, duration) in `desktop-requests.json`, reads error bodies that PowerShell normally hides,
and runs two raw-socket probes before using `Invoke-WebRequest`.

## Concurrency
0.26 served one connection at a time, so an idle connection (for example a browser pre-connect) stalled every other request,
including shutdown, for the read timeout. 0.28 serves up to 8 connections concurrently. Native-job state is still guarded by one
lock. DPI awareness is applied per capture thread (it is a per-thread Windows setting).

## Graceful shutdown (`POST /api/desktop/shutdown`)
1. refuse new work (`503 host-stopping`); 2. reply `{ok:true, stopping:true, nativeWorkStopped}`; 3. stop native work — job objects
with kill-on-close end every `mwcli.exe` and runner; 4. close the listener and delete the private session file; 5. flush logs;
6. end the UI message loop through an invoker control created before the session file is written (`WM_QUIT` only as a fallback).
A watchdog ends the process only if the loop has not returned 10 s after clean-up, and logs `shutdown-watchdog` when it fires.
`Test-Desktop.ps1` waits 20 s for the host to exit by itself; terminating it is the recorded last resort, never the normal path.

## Dashboard tools
`GET /api/desktop/test-results` (latest reports via `Collect-TestResults.ps1 -SummaryOnly`) and `POST /api/desktop/launch`
`{tool}` with a fixed whitelist: capture-check, wgc-check, hardware-check, windows-checks, collect-results, open-results-folder.
Release/desktop acceptance are refused while the host runs (they start their own private host on the same port).

## 0.29: ROOT CAUSE of the first-request HTTP 400 — found on a real Windows machine
On a GitHub-hosted Windows Server 2025 runner the 0.29 candidate (built exactly like 0.26–0.28) answered its very first health
request with:

    HTTP 400 {"error":"Method not found: 'System.String[] System.String.Split(Char, System.StringSplitOptions)'"}

The host executables were compiled with Mono against **Mono's** class library, where `text.Split(' ')` binds to an overload
`Split(char, StringSplitOptions = None)`. .NET Framework 4.8 has no such method, so request parsing threw `MissingMethodException`,
which the host's catch turned into HTTP 400 for **every** request — the first GET and the shutdown POST alike. The 0.26.0, 0.27.0
and 0.28.0 binaries all contain this call (checked with monodis). This explains both failures recorded on the target PC
(HTTP 400 and forced shutdown). It was invisible on Linux, where Mono's library has the overload.

Fix: every Windows executable is now compiled against the **.NET Framework 4.8 reference assemblies** (`-nostdlib`,
`/usr/lib/mono/4.8-api`), so any API missing on Windows is a compile error. `tests/netfx-029.test.cjs` scans the shipped binaries.
With that build the Windows runner passed health, the Expect 100-continue POSTs, every native-job route and graceful shutdown.

0.29 also accepts the RFC 7230 absolute-form target for its own loopback address (a local proxy forwards requests that way) and
rejects every other authority; `Test-Desktop.ps1` compares raw-socket, system-proxy and no-proxy requests before the health check
and states a diagnosis (`First-request diagnosis`). Corpus replay: `tests/http-029.test.cjs`, `reports/0.29-http-corpus-026-vs-029.json`.
