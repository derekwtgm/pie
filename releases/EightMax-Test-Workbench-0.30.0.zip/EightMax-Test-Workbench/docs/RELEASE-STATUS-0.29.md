# 0.29.0 release status

**Development build. Not 1.0.**

| Acceptance area (brief §15) | Status | Evidence |
|---|---|---|
| A. Version consolidation | Met | docs/CONSOLIDATION-0.29.md, inventory test |
| B. Windows repairs | Met on a Windows Server 2025 runner | docs/WINDOWS-CI.md, ci9 81/81 |
| C. Capture integration | Met; WGC still marked unverified for the target PC | host persistent-session checks, capture-029 |
| D. Solver operation | Met; convergence unproven | coverage reports, native jobs on Windows |
| E. Multi-table functionality | Met for simulated tables; fresh solving at 10 tables is not real-time | benchmarks A–D, stress report |
| F. Windows packaging | Met; FFmpeg not bundled | SHA256SUMS.txt, COMPONENT-VERSIONS.json |

**Not yet validated:** the target PC itself, namely Windows 11 Home, 150 % DPI, the RTX 4060 Ti, its security software and its performance.
