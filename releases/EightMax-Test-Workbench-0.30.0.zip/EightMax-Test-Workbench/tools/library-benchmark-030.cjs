'use strict';
/* 0.30 multi-table benchmark with the persistent strategy library. Every run is a COMPLETE simulation: render -> capture ->
 * recognise -> reconstruct -> decide -> execute -> acknowledge, on simulated tables. Workloads are kept apart:
 *   D  native solver computation : empty library, Study Mode: every new postflop spot is trained in the decision path (0.29 behaviour) and stored
 *   B  persistent loading        : same seeded hands, Decision Mode, fresh process: strategies are read from disk (shared host, cold cache)
 *   A  cached retrieval          : same seeded hands, Decision Mode, every record pre-loaded into the shared memory cache
 *   C  partial coverage          : DIFFERENT seed, Decision Mode, library from D: misses are 'unavailable' and the labelled scripted policy acts
 *   E  deadline policy           : the C hands with the 'deadline' mode: inline training only when the measured estimate fits the deadline
 * B and A replay the D hands exactly (seeded simulator, deterministic training), so they measure retrieval, not coverage luck.
 * SIMULATED TABLES on this machine; not real-client; not Windows target hardware; no GPU.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/library-benchmark-030.cjs --tables=1,2,5,8,10 --hands=8 --workers=4 --seed=4127 --cseed=9001
 *        --updates=500000 --post=20000 --workloads=D,B,A,C,E --work=DIR --out=reports/x.json */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), { Worker } = require('node:worker_threads');
const RM = require('../src/resource-monitor.js'), L = require('../src/strategy-library.js'), { SharedStrategyHost } = require('../src/shared-strategy-cache.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')));
const cli = process.env.EIGHTMAX_TEST_CLI; if (!cli) { console.error('EIGHTMAX_TEST_CLI is required (native engine).'); process.exit(2); }
const tablesList = String(args.tables || '1,2,5,8,10').split(',').map(Number), hands = +(args.hands || 8), workers = +(args.workers || 4), seed = +(args.seed || 4127), cseed = +(args.cseed || 9001);
const updates = +(args.updates || 500000), post = +(args.post || 20000), workloads = String(args.workloads || 'D,B,A,C,E').split(','), work = args.work || fs.mkdtempSync(path.join(os.tmpdir(), 'em-bench030-'));
const pct = (a, p) => { if (!a.length) return null; const s = a.slice().sort((x, y) => x - y); return +s[Math.min(s.length - 1, Math.ceil(p / 100 * s.length) - 1)].toFixed(3); };
const dist = (a) => ({ n: a.length, p50: pct(a, 50), p95: pct(a, 95), p99: pct(a, 99), max: a.length ? +Math.max(...a).toFixed(3) : null, mean: a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(3) : null });

function inWorker(job, port) {
  return new Promise((res, rej) => {
    const w = new Worker(path.join(__dirname, 'pipeline-worker.cjs'), { workerData: { job, libraryPort: port }, transferList: port ? [port] : [] });
    w.on('message', (m) => (m.ok ? res(m.result) : rej(new Error(m.error)))); w.on('error', rej);
  });
}
function copyDir(a, b) { fs.cpSync(a, b, { recursive: true }); }

/** Coverage by street, heads-up vs multiway and effective-stack category. Preflop is never pooled with postflop. */
function coverage(actions) {
  const SID = require('../src/strategy-identity.js'), by = {}, add = (k, solver) => { const c = by[k] || (by[k] = { solver: 0, fallback: 0 }); c[solver ? 'solver' : 'fallback']++; };
  for (const [street, players, eff, source] of actions) {
    const sv = source === 'solver'; add('street:' + street, sv); if (street !== 'preflop') { add('postflop:' + (players === 2 ? 'heads-up' : 'multiway'), sv); if (eff !== null) add('postflop-stack:' + SID.stackCategory(eff / 100), sv); add('postflop:all', sv); }
  }
  for (const v of Object.values(by)) v.solverShare = +(v.solver / Math.max(1, v.solver + v.fallback)).toFixed(4);
  return by;
}

async function runOne(name, tables, o) {
  const groups = Array.from({ length: Math.min(workers, tables) }, () => []); for (let i = 1; i <= tables; i++) groups[(i - 1) % groups.length].push(i);
  let host = null; if (o.shared) host = new SharedStrategyHost(L.StrategyLibrary.open(o.lib, { sharedMemory: true, cacheBytes: 1024 * 1048576 }));
  if (host && o.prewarm) { // load every record into shared memory before the clock starts
    for (const e of host.lib.list()) { const buf = fs.readFileSync(host.lib.file(e.fingerprint)); const rec = L.decodeRecord(buf, e.fingerprint, true); host.lib.get(rec.header.identity, e.fingerprint); }
  }
  const mon = new RM.RunMonitor({ intervalMs: 100 }).start(), t0 = Date.now();
  const solver = { kind: 'preflop-linked', cli, updates, budgetMiB: 1024, cacheDir: path.join(work, 'preflop-cache'), library: { dir: o.lib, mode: o.mode, shared: !!o.shared, iterations: post, estimates: o.estimates, workDir: path.join(work, 'inline-work') } };
  const parts = await Promise.all(groups.map((g, gi) => inWorker({ tables: g, hands, seed: o.seed, workerId: gi + 1, solver, collectActions: true }, host ? host.port() : null)));
  parts.forEach((x) => mon.workerReport(x.self)); const res = mon.report({ workers: groups.length }); mon.stop();
  const reps = parts.flatMap((p) => p.reports), actions = parts.flatMap((p) => p.actions), cycles = parts.flatMap((p) => p.cycles), libs = parts.map((p) => p.library).filter(Boolean);
  const sum = (f) => reps.reduce((n, r) => n + f(r), 0), lsum = (k) => libs.reduce((n, l) => n + (l[k] || 0), 0), lt = (k) => libs.flatMap((l) => l.rawTimings ? l.rawTimings[k] : []);
  const solverActs = actions.filter((a) => a[3] === 'solver'), postActs = actions.filter((a) => a[0] !== 'preflop');
  const out = { workload: name, tables, workers: groups.length, seed: o.seed, mode: o.mode, sharedCache: !!o.shared, prewarmed: !!o.prewarm, wallMs: Date.now() - t0,
    handsRequested: tables * hands, handsCompleted: sum((r) => r.completed), solverDecisions: solverActs.length, scriptedFallbackDecisions: actions.length - solverActs.length,
    postflopDecisions: postActs.length, postflopSolver: postActs.filter((a) => a[3] === 'solver').length,
    library: { memoryHits: lsum('memoryHits'), sharedHits: lsum('sharedHits'), diskHits: lsum('diskHits'), misses: lsum('misses'), refused: lsum('refused'), trainedInline: lsum('trainedInline'), inlineRefusedByDeadline: lsum('inlineRefusedByDeadline'), coalesced: lsum('coalesced') },
    latencyMs: { endToEndCycle: dist(cycles), decision: dist(actions.map((a) => a[6]).filter((x) => x !== null && x !== undefined)), postflopDecision: dist(postActs.map((a) => a[6])), postflopLibraryHitDecision: dist(postActs.filter((a) => /^library-/.test(a[4] || '')).map((a) => a[6])),
      postflopTrainedNowDecision: dist(postActs.filter((a) => a[4] === 'trained-now').map((a) => a[6])), strategyLoadFromDisk: dist(lt('diskMs')), strategyLookupMemory: dist(lt('cacheMs')), solverComputation: dist(lt('trainMs')), fingerprint: dist(lt('fingerprintMs')), treeWalkAndValidation: dist(lt('decideMs')),
      decisionCycleP95WorstTable: Math.max(...reps.map((r) => (r.latencyMs.cycle && r.latencyMs.cycle.p95) || 0)) },
    staleDecisions: sum((r) => r.totals.staleDecisions), ackMismatches: sum((r) => r.totals.ackMismatches), suspendedHands: sum((r) => r.totals.suspended), duplicateActionsBlocked: sum((r) => r.totals.duplicateBlocked),
    decisionTimeouts: sum((r) => (r.solver && r.solver.stats && r.solver.stats.timeout) || 0), queueRejected: sum((r) => (r.solver && r.solver.stats && (r.solver.stats.overflow + r.solver.stats.rejected)) || 0),
    workerCrashes: 0, chipAccountingFailures: reps.reduce((n, r) => n + (r.totals.suspended ? 0 : 0), 0),
    unavailableCodes: reps.reduce((m, r) => { for (const [k, v] of Object.entries(r.unavailableCodes || {})) m[k] = (m[k] || 0) + v; return m; }, {}),
    coverage: coverage(actions), resources: { cpuCoresBusy: res.process && res.process.cpuCoresBusy, cpuUtilizationOfMachine: res.process && res.process.cpuUtilizationOfMachine, rssBytesPeak: res.process && res.process.rssBytesPeak, nativeRssBytesPeak: res.native ? res.native.rssBytesPeak : null, workers: res.workers },
    sharedHost: host ? host.info() : null };
  if (host) host.close();
  process.stderr.write(name + ' ' + tables + 't: hands ' + out.handsCompleted + '/' + out.handsRequested + ', postflop solver ' + out.postflopSolver + '/' + out.postflopDecisions + ', cycle p50/p95/p99 ' + out.latencyMs.endToEndCycle.p50 + '/' + out.latencyMs.endToEndCycle.p95 + '/' + out.latencyMs.endToEndCycle.p99 + ' ms, worst-table p95 ' + out.latencyMs.decisionCycleP95WorstTable.toFixed(1) + ', trained ' + out.library.trainedInline + ', hits m/s/d ' + out.library.memoryHits + '/' + out.library.sharedHits + '/' + out.library.diskHits + ', misses ' + out.library.misses + '\n');
  return out;
}

(async () => {
  const doc = { format: 'eightmax-library-benchmark', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), classification: 'SIMULATED TABLES, complete pipeline, real native solver; this machine only; not real-client; not Windows target hardware; no GPU',
    machine: { platform: process.platform, arch: process.arch, node: process.version, cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, totalMemBytes: os.totalmem() },
    settings: { handsPerTable: hands, workers, seed, partialCoverageSeed: cseed, preflopUpdates: updates, postflopUpdatesPerStudy: post, rangeModel: require('../src/library-source.js').LIBRARY_RANGE_MODEL, convergence: 'unproven' }, runs: {} };
  for (const T of tablesList) {
    const libD = path.join(work, 'lib-D-' + T); fs.rmSync(libD, { recursive: true, force: true }); doc.runs[T] = {};
    if (workloads.includes('D')) doc.runs[T].D = await runOne('D', T, { lib: libD, mode: 'study', seed });
    if (workloads.includes('B')) doc.runs[T].B = await runOne('B', T, { lib: libD, mode: 'decision', seed, shared: true });
    if (workloads.includes('A')) doc.runs[T].A = await runOne('A', T, { lib: libD, mode: 'decision', seed, shared: true, prewarm: true });
    if (workloads.includes('C')) doc.runs[T].C = await runOne('C', T, { lib: libD, mode: 'decision', seed: cseed, shared: true });
    if (workloads.includes('C') && args.catalog) {   // C with a precomputed flop catalogue added (hard links; records are immutable)
      const libC = libD + '-cat'; fs.rmSync(libC, { recursive: true, force: true }); copyDir(libD, libC);
      const src = path.join(args.catalog, 'records'); for (const sub of fs.readdirSync(src)) { fs.mkdirSync(path.join(libC, 'records', sub), { recursive: true }); for (const f of fs.readdirSync(path.join(src, sub))) { const t = path.join(libC, 'records', sub, f); if (!fs.existsSync(t)) fs.linkSync(path.join(src, sub, f), t); } }
      fs.rmSync(path.join(libC, 'index.json'), { force: true }); L.StrategyLibrary.open(libC);   // rebuild the catalogue index
      doc.runs[T].Ccatalog = await runOne('C+catalog', T, { lib: libC, mode: 'decision', seed: cseed, shared: true }); doc.runs[T].Ccatalog.catalogRecords = L.StrategyLibrary.open(args.catalog, { readOnly: true }).list().length;
      fs.rmSync(libC, { recursive: true, force: true });
    }
    if (workloads.includes('E')) { const libE = libD + '-E'; fs.rmSync(libE, { recursive: true, force: true }); copyDir(libD, libE); const est = {}; const d = doc.runs[T].D; if (d && d.latencyMs.solverComputation.p50) for (const n of [2, 3, 4, 5, 6]) est[n] = d.latencyMs.solverComputation.p50 * (n <= 2 ? 1 : n / 2);
      doc.runs[T].E = await runOne('E', T, { lib: libE, mode: 'deadline', seed: cseed, shared: true, estimates: est }); }
    doc.runs[T].libraryAfterD = L.StrategyLibrary.open(libD, { readOnly: true }).status();
    if (args.out) { fs.mkdirSync(path.dirname(args.out), { recursive: true }); fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); }
  }
  if (!args.out) console.log(JSON.stringify(doc, null, 1));
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
