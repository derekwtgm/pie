#!/bin/sh
# 0.30 developer build of the Windows executables on Linux (cross-compilation; NOT Windows execution).
# Writes evidence/build-evidence.json from what actually happened (compiler versions, output hashes). Needs mono (mcs) and the .NET 8 SDK.
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd); cd "$root"
A=/usr/lib/mono/4.8-api
REFS="-nostdlib -r:$A/mscorlib.dll -r:$A/System.dll -r:$A/System.Core.dll -r:$A/System.Web.Extensions.dll -r:$A/System.Windows.Forms.dll -r:$A/System.Drawing.dll"
mcs -langversion:5 -main:EightMax.Workbench.DesktopHost -platform:x64 -target:winexe -optimize+ $REFS -out:desktop/bin/EightMaxWorkbench.exe desktop/DesktopHost.cs desktop/CaptureService.cs
mcs -langversion:5 -platform:x64 -target:exe -optimize+ $REFS -out:desktop/bin/EightMaxCapture.exe desktop/capture/EightMaxCapture.cs desktop/CaptureService.cs
tmp=$(mktemp -d); cp -r desktop/wgc "$tmp/wgc"
DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 dotnet publish "$tmp/wgc/EightMaxWgc.csproj" -c Release -o "$tmp/out" -p:EnableWindowsTargeting=true -p:SelfContained=true -p:EnableCompressionInSingleFile=true >/dev/null
cp "$tmp/out/EightMaxWgc.exe" desktop/bin/EightMaxWgc.exe; rm -rf "$tmp"
python3 - "$(mcs --version | head -1)" "$(dotnet --version)" <<'PY'
import hashlib, json, sys, datetime
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
ev = {'format': 'eightmax-build-evidence', 'version': 1, 'builtAt': datetime.datetime.utcnow().isoformat() + 'Z', 'buildHost': 'Linux (cross-compilation)',
      'outputs': {
        'desktop/bin/EightMaxWorkbench.exe': {'sha256': sha('desktop/bin/EightMaxWorkbench.exe'), 'compiler': sys.argv[1] + ' against .NET Framework 4.8 reference assemblies (/usr/lib/mono/4.8-api, -nostdlib), -langversion:5 -platform:x64 -optimize+', 'sources': ['desktop/DesktopHost.cs', 'desktop/CaptureService.cs'], 'crossCompiled': True},
        'desktop/bin/EightMaxCapture.exe': {'sha256': sha('desktop/bin/EightMaxCapture.exe'), 'compiler': sys.argv[1] + ' against .NET Framework 4.8 reference assemblies', 'sources': ['desktop/capture/EightMaxCapture.cs', 'desktop/CaptureService.cs'], 'crossCompiled': True},
        'desktop/bin/EightMaxWgc.exe': {'sha256': sha('desktop/bin/EightMaxWgc.exe'), 'compiler': '.NET SDK ' + sys.argv[2] + ' on Linux, net8.0-windows10.0.22000.0, win-x64 self-contained single file, EnableWindowsTargeting', 'sources': ['desktop/wgc/Program.cs', 'desktop/wgc/SelfTest.cs', 'desktop/wgc/PngWriter.cs'], 'crossCompiled': True}}}
json.dump(ev, open('evidence/build-evidence.json', 'w'), indent=1); print('build evidence written')
PY
