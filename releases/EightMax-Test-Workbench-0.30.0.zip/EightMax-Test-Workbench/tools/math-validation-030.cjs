'use strict';
/* 0.30 mathematical validation (reports/0.30-math-validation.json). Exact measurements on small games that can be evaluated
 * completely, with independent code (src/exploitability.js: own evaluator, own payouts, own best response, own CFR+).
 * It does NOT establish accuracy for the full-size tournament game; see the 'scope' field of the report.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/math-validation-030.cjs [--seeds=5] [--quick] [--library=DIR] --out=reports/0.30-math-validation.json */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const EMlib = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), X = require('../src/exploitability.js'), SNAP = require('../src/strategy-snapshot.js'), L = require('../src/strategy-library.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
const cli = process.env.EIGHTMAX_TEST_CLI || null, quick = !!args.quick, seeds = +(args.seeds || (quick ? 2 : 5)), work = fs.mkdtempSync(path.join(os.tmpdir(), 'em-math-'));
const T95 = { 1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262 };
const stat = (a) => { const n = a.length, m = a.reduce((x, y) => x + y, 0) / n, sd = n > 1 ? Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / (n - 1)) : 0, h = n > 1 ? (T95[n - 1] || 1.96) * sd / Math.sqrt(n) : null; return { n, mean: +m.toFixed(6), sd: +sd.toFixed(6), ci95: h === null ? null : [+(m - h).toFixed(6), +(m + h).toFixed(6)], min: +Math.min(...a).toFixed(6), max: +Math.max(...a).toFixed(6) }; };

function trainNative(cfg, it) {
  const p = A.prepare(EMlib, { config: cfg, iterations: it, timeMs: 600000 }), spec = path.join(work, 's.json'), st = path.join(work, 's.state');
  fs.writeFileSync(spec, JSON.stringify(A.nativeJob(p, 'm').spec)); const t0 = Date.now(), r = cp.spawnSync(cli, [spec, String(it), '1', st, '512'], { encoding: 'utf8' });
  if (r.status !== 0) throw new Error('native training failed: ' + r.stderr); p.game.importNative(fs.readFileSync(st)); p.trainMs = Date.now() - t0; return p;
}
function trainJs(cfg, it) { const p = A.prepare(EMlib, { config: cfg, iterations: it, timeMs: 600000 }); const t0 = Date.now(); p.game.iterate(it); p.trainMs = Date.now() - t0; return p; }
/** Mean L1 distance between two trained profiles over every (node, hand) both store. */
function strategyDistance(p1, p2) {
  let sum = 0, n = 0; const q = [[]];
  while (q.length) { const s = q.shift(), v = p1.game.view(s); if (v.kind !== 'player') continue; const path = 'r' + s.join('');
    for (const r of p1.spec.hands[v.seat]) { const h = { id: r[0], a: r[1], b: r[2], w: r[3] }, a = p1.game.averageAt(path, p1.spec.board, v.seat, h), b = p2.game.averageAt(path, p2.spec.board, v.seat, h); if (a && b) { let d = 0; for (let i = 0; i < a.length; i++) d += Math.abs(a[i] - b[i]); sum += d; n++; } }
    for (let i = 0; i < v.actions.length; i++) q.push(s.concat(i)); }
  return n ? sum / n : null;
}

(async () => {
  const t0 = Date.now(), doc = { format: 'eightmax-math-validation', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), engine: A.ENGINE, nativeEngine: cli ? 'native CLI (mwcli) built from the bundled 5.1 source' : 'not available',
    scope: 'EXACT evaluations of small single-street (river) games defined by EightMax studies. These are reference games: they check the solver, the stored strategies and the evaluation code. They do NOT measure the accuracy of strategies for the full tournament game (preflop through river, 8 players), whose exploitability is not computed anywhere in this release.',
    classifications: { exact: 'complete evaluation of the defined game (all joint deals, all nodes)', estimated: 'sampled evaluation with a stated confidence interval', restricted: 'evaluation against a limited set of responses or an abstraction', unverified: 'no evidence' }, sections: {} };

  // 1. independent evaluator vs EightMax's evaluator
  let x = 12345; const rnd = () => { x = (Math.imul(x, 1103515245) + 12345) >>> 0; return x / 4294967296; }, hs = [];
  for (let t = 0; t < (quick ? 4000 : 20000); t++) { const s = new Set(); while (s.size < 7) s.add(Math.floor(rnd() * 52)); hs.push([...s]); }
  let agree = 0; for (let t = 0; t + 1 < hs.length; t++) if (Math.sign(X.score7(hs[t]) - X.score7(hs[t + 1])) === Math.sign(EMlib.evalCards(hs[t]) - EMlib.evalCards(hs[t + 1]))) agree++;
  doc.sections.evaluatorCrossCheck = { classification: 'exact', comparisons: hs.length - 1, agreeing: agree, note: 'Ordering of random seven-card hands by the independent evaluator and by the EightMax evaluator.' };

  const HU = { board: 'Kh9s5c3d2h', common: 10, stacks: [20, 20], ranges: Array(2).fill('TT+,AJs+,KTs+,QJs,AQo+,KQo'), streets: { river: { bets: '50,a', raises: 'a', maxBets: 2 } } };
  // 2. independent reference equilibrium (CFR+)
  const refIt = quick ? 200 : 1000, base = trainJs({ ...HU, privateSeed: 1 }, 10), ref = X.cfrPlus(base.game, base.spec, refIt);
  doc.sections.referenceSolver = { classification: 'exact', game: HU, algorithm: 'independent two-player CFR+ (alternating updates, regret matching+, linear averaging), full-width', iterations: refIt, exploitabilityBB: ref.exploitability, exploitabilityPctPot: ref.exploitabilityPctPot, values: ref.values, deals: ref.deals };

  // 3. EightMax convergence curve, repeated seeds, exact exploitability
  const counts = quick ? [1000, 10000, 50000] : [1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000], curve = [];
  if (cli) for (const it of counts) {
    const ex = [], val = [], trainMs = [], missing = [], profiles = [];
    for (let s = 1; s <= seeds; s++) { const p = trainNative({ ...HU, privateSeed: 1000 + s }, it), e = X.exact(p.game, p.spec); ex.push(e.exploitability); val.push(e.values[0]); trainMs.push(p.trainMs); missing.push(e.missingRows); if (profiles.length < 2) profiles.push(p); }
    const row = { updates: it, seeds, exploitabilityBB: stat(ex), exploitabilityPctPot: stat(ex.map((v) => v / HU.common * 100)), valueSeat0: stat(val), valueErrorVsReference: stat(val.map((v) => Math.abs(v - ref.values[0]))), missingRows: stat(missing), trainMs: stat(trainMs), seedToSeedStrategyL1: profiles.length === 2 ? +strategyDistance(profiles[0], profiles[1]).toFixed(5) : null };
    curve.push(row); process.stderr.write('native ' + it + ': exploitability ' + row.exploitabilityBB.mean.toFixed(4) + ' bb (95% CI ' + (row.exploitabilityBB.ci95 || []).map((v) => v.toFixed(4)).join('..') + ')\n');
  }
  doc.sections.convergenceNative = { classification: 'exact', game: HU, method: 'EightMax 5.1 native engine, external-sampling MCCFR (sampled private deals, linear weighting); exploitability computed exactly by the independent best response', curve,
    monotoneMeanDecrease: curve.every((r, i) => i === 0 || r.exploitabilityBB.mean <= curve[i - 1].exploitabilityBB.mean * 1.05) };

  // 4. alternative implementation (JavaScript reference engine, same algorithm)
  const jsCounts = quick ? [2000] : [2000, 10000], js = [];
  for (const it of jsCounts) { const ex = []; for (let s = 1; s <= Math.min(3, seeds); s++) { const p = trainJs({ ...HU, privateSeed: 1000 + s }, it); ex.push(X.exact(p.game, p.spec).exploitability); } js.push({ updates: it, exploitabilityBB: stat(ex) }); }
  doc.sections.convergenceJavaScriptEngine = { classification: 'exact', note: 'Same algorithm, separate implementation (EightMax 5.1 JavaScript reference engine).', curve: js, nativeAtSameCounts: curve.filter((r) => jsCounts.includes(r.updates)).map((r) => ({ updates: r.updates, exploitabilityBB: r.exploitabilityBB })) };

  // 5. stored snapshot reproduces the trained study's evaluation exactly
  { const p = cli ? trainNative({ ...HU, privateSeed: 77 }, 20000) : trainJs({ ...HU, privateSeed: 77 }, 5000), e1 = X.exact(p.game, p.spec), g = SNAP.decode(SNAP.encode(SNAP.exportStreet(p, { EM: EMlib }))), e2 = X.exact(g, g.prepared().spec);
    doc.sections.snapshotReproduction = { classification: 'exact', identicalValues: JSON.stringify(e1.values) === JSON.stringify(e2.values), identicalBestResponses: JSON.stringify(e1.bestResponses) === JSON.stringify(e2.bestResponses), exploitabilityBB: e1.exploitability, tolerance: 0, note: 'Bitwise equality of every evaluated quantity computed from the live trained game and from its stored snapshot.' };
    // 6. sampled evaluation: confidence-interval coverage of the exact value
    const reps = quick ? 10 : 40, n = quick ? 4000 : 10000; let covered = 0; const means = [];
    for (let r = 1; r <= reps; r++) { const s = X.sampled(p.game, p.spec, n, r * 7919)[0]; means.push(s.mean); if (s.ci95[0] <= e1.values[0] && e1.values[0] <= s.ci95[1]) covered++; }
    doc.sections.sampledEvaluation = { classification: 'estimated', exactValueSeat0: e1.values[0], samplesPerEstimate: n, replicates: reps, intervalsCoveringExact: covered, coverageRate: covered / reps, sampleMeans: stat(means), note: 'Monte-Carlo estimates with 95% normal-approximation intervals; about 95% of intervals should contain the exact value.' }; }

  // 7. three-player game: exact NashConv (NOT a two-player exploitability)
  const M3 = A.EXAMPLES.river3, mcurve = [];
  if (cli) for (const it of quick ? [1000, 20000] : [1000, 5000, 20000, 100000]) { const nc = [], g3 = []; for (let s = 1; s <= Math.min(3, seeds); s++) { const p = trainNative({ ...M3, privateSeed: 500 + s }, it), e = X.exact(p.game, p.spec); nc.push(e.nashConv); g3.push(e.gains); } mcurve.push({ updates: it, nashConvBB: stat(nc), perPlayerGainMeanBB: [0, 1, 2].map((q) => +(g3.reduce((a, g) => a + g[q], 0) / g3.length).toFixed(5)) }); }
  doc.sections.multiplayerNashConv = { classification: 'exact', game: { board: M3.board, players: 3, common: M3.common, stacks: M3.stacks, rangesSize: M3.ranges.map((r) => r.split(',').length) }, curve: mcurve,
    caveat: 'NashConv is the sum of each player\'s best unilateral gain. In games with three or more players a NashConv of zero (a Nash equilibrium) does not imply safety against coalitions, equilibria are not unique, and the two-player exploitability formula does not apply.' };

  // 8. actual library records (heads-up river snapshots), if a library is given
  if (args.library && fs.existsSync(args.library)) {
    const lib = L.StrategyLibrary.open(args.library, { readOnly: true }), out = [];
    for (const e of lib.list().filter((r) => r.street === 'river' && r.players === 2).slice(0, quick ? 1 : 4)) {
      const rec = L.decodeRecord(fs.readFileSync(lib.file(e.fingerprint)), e.fingerprint), g = SNAP.decode(rec.body);
      try { const t = Date.now(), r = X.exact(g, g.prepared().spec, { maxDeals: 2e6 }); out.push({ fingerprint: e.fingerprint, situation: e.describe, exploitabilityBB: r.exploitability, exploitabilityPctPot: r.exploitabilityPctPot, values: r.values, deals: r.deals, missingRows: r.missingRows, evalMs: Date.now() - t }); }
      catch (x2) { out.push({ fingerprint: e.fingerprint, situation: e.describe, error: x2.message }); }
    }
    doc.sections.libraryRecords = { classification: 'exact', note: 'Exact exploitability of strategies actually stored in the library (heads-up river records only: earlier streets contain chance nodes and are not evaluated exactly here). Missing rows are played uniformly by the evaluator.', records: out };
  }
  doc.runtimeMs = Date.now() - t0;
  const text = JSON.stringify(doc, null, 1); if (args.out) { fs.mkdirSync(path.dirname(args.out), { recursive: true }); fs.writeFileSync(args.out, text); } else console.log(text);
  fs.rmSync(work, { recursive: true, force: true });
})().catch((e) => { console.error(e); process.exit(1); });
