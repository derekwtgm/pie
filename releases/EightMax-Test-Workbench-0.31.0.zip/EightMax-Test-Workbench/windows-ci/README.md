# Windows CI for 0.31.0 (prepared, not yet run)

These are the 0.30 GitHub Actions files updated for 0.31: `workbench-ci/ci.ps1` (driver) and `.github/workflows/workbench-windows.yml`.
The 0.31 build session could not push to the repository (permission was not granted), so **no Windows CI run exists for 0.31**.

To run it: on a new branch of the repository that holds the 0.30 CI files, add
`releases/EightMax-Test-Workbench-0.31.0.zip` and its `.sha256` (the driver refuses a ZIP whose hash differs), plus these two files
at the same paths, and push. The workflow tests the exact ZIP on a GitHub-hosted Windows runner: release acceptance with install,
the Node suite with the bundled node.exe, the strategy library, quality evaluation, the shared-retrieval benchmark, derived ranges
and the quick long-duration profile. A hosted runner is NOT the target PC (no GPU, virtual display).
