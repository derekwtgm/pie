'use strict';
/* Decision-source factory loaded inside solver worker threads. kinds:
 *   preflop-linked  - trained linked preflop study (cached native state) + on-demand postflop studies
 *   postflop-only   - on-demand postflop studies only
 *   burn            - test source that busy-loops (to prove isolation); never used outside tests/benchmarks */
const path = require('node:path');
exports.createSource = async function createSource(o) {
  const root = path.join(__dirname, '..');
  if (o.kind === 'burn') return { decide: (req) => { const end = Date.now() + (req.burnMs || o.burnMs || 50); let x = 0; while (Date.now() < end) x += Math.sqrt(x + 1); return { status: 'unavailable', reason: 'burn source', format: 'eightmax-decision', version: 1, stateKey: req.stateKey }; } };
  const A = require(path.join(root, 'src/study-adapter.js')), ST = require(path.join(root, 'src/solver-tree.js')), T = require(path.join(root, 'tools/studies.cjs')), EM = require(path.join(root, 'tests/load-solver.cjs'));
  const sources = [];
  if (o.kind === 'preflop-linked') {
    if (o.cli) process.env.EIGHTMAX_TEST_CLI = o.cli;
    const TS = require(path.join(root, 'tools/train-study.cjs'));
    // 0.26: with the native engine the study is trained under an explicit budget (default 1 GiB, planner-checked) and read lazily from its state file.
    const lazy = !!TS.cliPath() && o.lazy !== false;
    const s = lazy ? await TS.trainStudyLazy(o.updates || 100000, { config: T.PREFLOP8_LINKED, name: 'preflop8-linked', cacheDir: o.cacheDir, threads: o.trainThreads || 2, budgetMiB: o.budgetMiB || 1024, cacheBytes: o.cacheBytes })
      : TS.trainStudy(o.updates || 100000, { config: T.PREFLOP8_LINKED, name: 'preflop8-linked', cacheDir: o.cacheDir, threads: 2, budgetMiB: 256 });
    const conv = lazy && !s.complete ? { verdict: 'unproven', detail: 'Memory-limited study: ' + s.updates + ' of ' + s.requestedUpdates + ' updates; training length alone proves nothing.' } : undefined;
    sources.push(new ST.PreflopTreeSource(s.EM, s.prepared, { studyId: 'preflop8-linked-' + s.updates, backend: s.backend, convergence: conv }));
  }
  if (o.library) {
    // 0.30: postflop decisions come from the persistent strategy library. mode 'decision' never trains in the decision path;
    // 'study' trains a missing spot inline and stores it; 'deadline' trains inline only when the measured estimate fits the deadline.
    const L = require(path.join(root, 'src/strategy-library.js')), LS = require(path.join(root, 'src/library-source.js'));
    const lib = L.StrategyLibrary.open(o.library.dir, { cacheBytes: (o.library.cacheMiB || 256) * 1048576, missFlushEvery: 1, diskReads: !o.library.shared });
    let sharedClient; if (o.library.shared) { const { SharedStrategyClient } = require(path.join(root, 'src/shared-strategy-cache.js')); sharedClient = SharedStrategyClient.fromWorker(); }
    // 0.31: rangeModel 'derived' (preflop line -> flop -> turn -> river, src/range-model.js) or 'any-two' (0.30 model);
    // quality { policy, use } for the gate; adaptive: true = quality-targeted studies (src/adaptive-training.js) instead of fixed counts.
    let rangeModelEngine = null;
    if (o.library.rangeModel === 'derived') { const pre = sources.find((x) => x instanceof ST.PreflopTreeSource); if (!pre) throw new Error('Derived ranges need the preflop study (kind preflop-linked)'); const { LibraryRangeModel } = require(path.join(root, 'src/range-model.js')); rangeModelEngine = new LibraryRangeModel({ preflopSource: pre, EM, ...(o.library.rangeOptions || {}) }); }
    let training, abstraction;
    if (o.library.adaptive) { const AT = require(path.join(root, 'src/adaptive-training.js')), SID = require(path.join(root, 'src/strategy-identity.js')), q = (o.library.quality && o.library.quality.policy) || 'research';
      // 0.31 profile: rivers are quality-targeted (exactly measurable); flops and turns keep the 0.30 fixed-count identity unless
      // adaptiveStreets includes them (their quality cannot be measured from a street snapshot, so a target would only be stability).
      const streetsOn = o.library.adaptiveStreets || ['river'];
      training = ({ street, players }) => (streetsOn.includes(street) ? AT.trainingPolicy({ policy: q, trainer: street === 'river' && players === 2 ? 'vector-cfr-plus' : 'eightmax-native' }) : undefined);
      abstraction = ({ training: t }) => (t && t.trainer === 'vector-cfr-plus' ? SID.ABSTRACTION_FULL_WIDTH : undefined); }
    const src = new LS.LibraryDecisionSource({ library: lib, mode: o.library.mode || 'decision', iterations: o.library.iterations || 20000, EM, adapter: A, cli: o.cli, sharedClient, estimator: o.library.estimates ? new LS.TrainingEstimator(o.library.estimates) : undefined, workDir: o.library.workDir,
      rangeModelEngine, training, abstraction, qualityPolicy: o.library.quality && o.library.quality.policy, qualityUse: o.library.quality && o.library.quality.use, adaptiveMaxTimeMs: o.library.adaptiveMaxTimeMs, adaptiveMaxUpdates: o.library.maxUpdates, inlineHeadsUpRiver: !!o.library.inlineHeadsUpRiver, inlineRiverMaxMs: o.library.inlineRiverMaxMs || 3000 });
    sources.push(src);
    const comp = new ST.CompositeDecisionSource(sources); comp.library = lib; comp.librarySource = src; comp.rangeModel = rangeModelEngine; return comp;
  }
  sources.push(new ST.PostflopStudySource({ EM, adapter: A, iterations: o.postIterations || 3000, trainer: o.cli ? T.nativeTrainer(o.cli, { threads: 1 }) : undefined, backend: o.cli ? 'native-cli-cpu' : 'javascript-reference-cpu' }));
  return new ST.CompositeDecisionSource(sources);
};
