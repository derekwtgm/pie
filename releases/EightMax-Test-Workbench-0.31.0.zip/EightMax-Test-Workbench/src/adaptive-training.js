'use strict';
/* EightMax Test Workbench 0.31: quality-aware ("adaptive") training of a street-start study.
 *
 * 0.30 trained every library study for a fixed 20,000 updates. 0.31 measured (reports/0.31-training-variants.json) that this
 * leaves heads-up river studies with any-two-cards ranges about 1.7 bb (29 % of a 6 bb pot) exploitable, while more updates are
 * cheap on the river. The adaptive trainer therefore:
 *   1 trains an initial block,              2 measures what can be measured (exact exploitability / NashConv on the river,
 *   strategy stability between checkpoints elsewhere),  3 decides whether more training is justified,
 *   4 continues in doubling blocks while the target is not met and the resource limits allow it (checkpointed, resumable),
 *   5 stops at the quality target, at the update / time limit, or when improvement stalls,
 *   6 returns the snapshot TOGETHER with its quality document (status from src/strategy-quality.js; never "validated" by default).
 *
 * Trainers:
 *   'vector-cfr-plus'  heads-up river only: the workbench's full-width CFR+ (src/fast-river.js). Exact, no sampling. Chosen for
 *                      heads-up rivers because it reached 0.0005 bb on any-two-cards ranges in seconds where EightMax MCCFR
 *                      needs millions of sampled updates (same report). The stored strategy is re-evaluated after decoding.
 *   'eightmax-native'  EightMax 5.1 mwcli, the 0.30 default variant (external-sampling MCCFR, standard regret matching, linear
 *                      averaging: the best of the four variants measured). Any street, 2-6 players.
 *   'eightmax-js'      EightMax 5.1 JavaScript reference engine (tests and machines without mwcli).
 */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const Q = require('./strategy-quality.js'), SNAP = require('./strategy-snapshot.js');

const DEFAULTS = Object.freeze({ initialUpdates: 20000, maxUpdates: 3200000, maxTimeMs: 120000, stallRatio: 0.92, stallChecks: 2, targetMargin: 0.8, cfrPlusEvery: 25, cfrPlusMaxIterations: 4000 });

/** Identity "training" block for a quality-targeted study (what was asked for, not what it took). */
function trainingPolicy(o = {}) {
  const pol = Q.policySummary(Q.policyOf(o.policy));
  return { mode: 'quality-target-v1', trainer: o.trainer || 'eightmax-native', variant: o.trainer === 'vector-cfr-plus' ? 'full-width-cfr-plus' : (o.variant || 'mccfr-linear'),
    target: { headsUpMaxExploitabilityPctPot: pol.headsUp.maxExploitabilityPctPot, multiwayMaxNashConvPctPot: pol.multiway.maxNashConvPctPot, margin: o.targetMargin || DEFAULTS.targetMargin } };
  // resource limits (updates, time) are NOT part of the identity: they do not change the game, and a study trained further later
  // ("refinement") is the same study, better trained. The updates actually used are in the record header and quality document.
}
/** Which trainer a spot gets by default. */
function defaultTrainer(spot, o = {}) { if (o.trainer) return o.trainer; return spot.street === 'river' && spot.players === 2 ? 'vector-cfr-plus' : o.cli ? 'eightmax-native' : 'eightmax-js'; }

/** Mean L1 change of the stored strategy between two snapshots of the same game (rows present in both), weighted by hand weight. */
function snapshotStability(a, b) {
  if (!a || !b) return null; const ga = SNAP.decode(a), gb = SNAP.decode(b); let sum = 0, w = 0;
  const weightOf = (seat) => { const m = new Map(); for (const r of ga.meta.hands[seat]) m.set(Math.min(r[1], r[2]) * 64 + Math.max(r[1], r[2]), r[3]); return m; };
  const nb = new Map(gb.meta.nodes.filter((n) => n.kind === 'player').map((n) => [n.p, n])), wcache = new Map();
  for (const n of ga.meta.nodes) {
    if (n.kind !== 'player') continue; const m = nb.get(n.p); if (!m || m.k !== n.k) continue;
    if (!wcache.has(n.seat)) wcache.set(n.seat, weightOf(n.seat)); const W = wcache.get(n.seat);
    const kb = new Map(); for (let i = 0; i < m.rc; i++) kb.set(gb.keys[m.ro + i], i);
    for (let i = 0; i < n.rc; i++) { const key = ga.keys[n.ro + i], j = kb.get(key); if (j === undefined) continue; let d = 0; for (let x = 0; x < n.k; x++) d += Math.abs(ga.probs[n.po + i * n.k + x] - gb.probs[m.po + j * m.k + x]); const wt = W.get(key) || 1; sum += wt * d; w += wt; }
  }
  return w ? +(sum / w).toFixed(6) : null;
}

function limitBBFor(spot, policy) {
  const p = Q.policyOf(policy), pot = spot.config.common;
  return spot.players === 2 ? Math.min(p.headsUp.maxExploitabilityPctPot * pot / 100, p.headsUp.maxExploitabilityBB === null ? Infinity : p.headsUp.maxExploitabilityBB) : p.multiway.maxNashConvPctPot * pot / 100;
}
const measureOf = (ev) => (ev && ev.type === 'exact' ? (ev.players === 2 ? ev.exploitabilityBB : ev.nashConvBB) : null);

/**
 * Train a spot to a quality target. spot: { fingerprint, identity, config, street, players } (from library-source spotFromParams).
 * o: policy, trainer, EM, adapter, cli, threads, memoryMiB, workDir (checkpoints; kept on failure for resume), signal, onProgress(info),
 *    initialUpdates, maxUpdates, maxTimeMs, stallRatio, stallChecks, targetMargin, cfrPlusEvery, cfrPlusMaxIterations
 * Returns { body, meta, training, quality } where quality is a full quality document (status from the policy).
 */
async function trainAdaptive(spot, o = {}) {
  o = { ...DEFAULTS, ...o };
  const A = o.adapter || require('./study-adapter.js'), EM = o.EM || require('../tests/load-solver.cjs');
  const trainer = defaultTrainer(spot, o), policy = Q.policyOf(o.policy), limitBB = limitBBFor(spot, policy), aim = limitBB * o.targetMargin;
  const fail = (code, msg) => { const e = new Error(msg); e.code = code; throw e; };
  const t0 = Date.now(), curve = [];
  if (trainer === 'vector-cfr-plus') {
    if (!(spot.street === 'river' && spot.players === 2)) fail('unsupported', 'The vectorised CFR+ trainer solves heads-up river studies only');
    const F = require('./fast-river.js'), prepared = A.prepare(EM, { config: spot.config, iterations: 1, timeMs: 600000 }), fr = F.prepare(prepared.game, prepared.spec);
    let cancelled = false;
    const r = fr.cfrPlus(o.cfrPlusMaxIterations, { every: o.cfrPlusEvery, target: aim, onCheckpoint: (t, e) => { curve.push({ updates: t, exploitabilityBB: +e.exploitability.toFixed(6), ms: Date.now() - t0 }); if (o.onProgress) o.onProgress({ updates: t, measureBB: e.exploitability, limitBB }); if (o.signal && o.signal.aborted) cancelled = true; if (Date.now() - t0 > o.maxTimeMs) cancelled = cancelled || 'time'; } });
    if (o.signal && o.signal.aborted) fail('cancelled', 'Training cancelled');
    // export through the snapshot format: a stand-in game whose averageAt() returns the CFR+ average strategy
    const hk = fr.hands.map((H) => new Map(H.map((h, i) => [Math.min(h.a, h.b) * 64 + Math.max(h.a, h.b), i]))), byPath = new Map(); (function idx(n) { if (n.kind === 'player') { byPath.set(n.path, n); n.children.forEach(idx); } })(fr.tree.tree);
    const stand = { game: { view: (s) => prepared.game.view(s), iterations: r.iterations, averageAt(p, board, seat, h) { const node = byPath.get(p); if (!node) return null; const i = hk[seat].get(Math.min(h.a, h.b) * 64 + Math.max(h.a, h.b)); return i === undefined ? null : r.strategy.get(node, seat, i); } }, spec: prepared.spec };
    const snap = SNAP.exportStreet(stand, { EM }), body = SNAP.encode(snap), game = SNAP.decode(body);
    const evaluation = Q.evaluateSnapshot(game, spot.identity);   // evaluated from the bytes that will be stored
    return finish(spot, o, policy, body, snap.meta, evaluation, { backend: 'workbench-vector-cfr-plus', trainer, iterations: r.iterations, trainMs: Date.now() - t0, stoppedBecause: measureOf(evaluation) <= aim ? 'quality-target-met' : cancelled === 'time' ? 'time-limit' : 'iteration-limit', curve, threads: 1 });
  }
  // EightMax engine (native or JavaScript), doubling blocks with a measurement after each block
  // the JavaScript game only holds the imported native state for export; 256 MiB is the most the 5.1 JS engine accepts
  const prepared = A.prepare(EM, { config: spot.config, iterations: o.maxUpdates, timeMs: 600000, trainerVariant: o.variant, strategyBudgetMiB: o.jsBudgetMiB || 256 });
  let done = 0, lastUpdates = 0, target = o.initialUpdates, prevBody = null, prevMeasure = null, stalls = 0, stopped = null, lastEval = null, lastBody = null, lastMeta = null, peakRss = 0, resumedFrom = 0;
  let dir = null, specFile, ckpt;
  if (trainer === 'eightmax-native') {
    if (!o.cli) fail('no-native-engine', 'Native engine (mwcli) not available');
    dir = o.workDir || fs.mkdtempSync(path.join(os.tmpdir(), 'em-adaptive-')); fs.mkdirSync(dir, { recursive: true });
    specFile = path.join(dir, 'spec.json'); ckpt = path.join(dir, 'checkpoint.state'); fs.writeFileSync(specFile, JSON.stringify(A.nativeJob(prepared, spot.fingerprint.slice(0, 12)).spec));
    const NT = require('../tools/native-training.cjs');
    if (fs.existsSync(ckpt)) { try { done = NT.headerOf(ckpt).iterations; resumedFrom = done; target = Math.max(target, done); } catch (e) { fs.rmSync(ckpt, { force: true }); done = 0; } }
  }
  const NT = trainer === 'eightmax-native' ? require('../tools/native-training.cjs') : null;
  while (true) {
    if (o.signal && o.signal.aborted) fail('cancelled', 'Training cancelled');
    if (done < target) {
      if (NT) {
        let r; try { r = await NT.trainNative({ cli: o.cli, specFile, updates: target, budgetMiB: o.memoryMiB || 512, threads: o.threads || 1, outFile: ckpt, resumeFrom: done > 0 ? ckpt : null, timeoutMs: Math.max(10000, o.maxTimeMs - (Date.now() - t0) + 10000), signal: o.signal }); } catch (e) { fail(e.code || 'native-failed', e.message); }
        if (r.run.status !== 'complete') fail(r.run.status === 'memory-limited' ? 'memory-limited' : r.run.status, r.run.reason || 'Native training incomplete');
        done = r.run.updatesDone; peakRss = Math.max(peakRss, r.run.processPeakRssMiB || 0);
        try { prepared.game.importNative(fs.readFileSync(ckpt)); }
        catch (e) { if (!/memory budget/i.test(e.message)) throw e; if (!lastBody) fail('memory-limited', 'Trained state does not fit the export budget: ' + e.message); stopped = 'memory-limit (state too large to export; previous checkpoint kept)'; done = lastUpdates; break; }
      } else {
        while (prepared.game.iterations < target) { if (o.signal && o.signal.aborted) fail('cancelled', 'Training cancelled'); prepared.game.iterate(Math.min(5000, target - prepared.game.iterations)); if (prepared.game.limitReached) fail('memory-limited', 'JavaScript strategy budget filled after ' + prepared.game.iterations + ' updates'); await new Promise((res) => setImmediate(res)); }
        done = prepared.game.iterations;
      }
    }
    // resumed from a kept checkpoint that already covers this block: load it (the export game starts empty)
    if (NT && prepared.game.iterations !== done && fs.existsSync(ckpt)) { try { prepared.game.importNative(fs.readFileSync(ckpt)); } catch (e) { if (!/memory budget/i.test(e.message)) throw e; fail('memory-limited', 'Checkpoint does not fit the export budget: ' + e.message); } }
    if (prepared.game.iterations !== done) fail('invalid', 'Study has ' + prepared.game.iterations + ' of ' + done + ' updates');
    const snap = SNAP.exportStreet(prepared, { EM }), body = SNAP.encode(snap), game = SNAP.decode(body);
    if (snap.meta.playerNodes < 1) fail('invalid', 'Exported study has no decision node');
    const evaluation = Q.evaluateSnapshot(game, spot.identity), measure = measureOf(evaluation), stab = snapshotStability(prevBody, body);
    curve.push({ updates: done, measureBB: measure === null ? null : +measure.toFixed(6), measureKind: measure === null ? null : spot.players === 2 ? 'exploitability' : 'nashconv', stabilityL1: stab, ms: Date.now() - t0 });
    if (o.onProgress) o.onProgress({ updates: done, measureBB: measure, limitBB, stabilityL1: stab });
    lastEval = evaluation; lastBody = body; lastMeta = snap.meta; lastUpdates = done;
    if (measure !== null && measure <= aim) { stopped = 'quality-target-met'; break; }
    if (measure !== null && prevMeasure !== null) { stalls = measure > prevMeasure * o.stallRatio ? stalls + 1 : 0; if (stalls >= o.stallChecks) { stopped = 'improvement-stalled'; break; } }
    if (measure === null && stab !== null && o.stabilityTarget && stab <= o.stabilityTarget) { stopped = 'stability-target-met (not an accuracy measurement)'; break; }
    const next = done * 2; if (next > o.maxUpdates) { stopped = 'update-limit'; break; }
    const elapsed = Date.now() - t0, perUpdate = elapsed / Math.max(1, done); if (elapsed + perUpdate * (next - done) > o.maxTimeMs) { stopped = 'time-limit'; break; }
    prevBody = body; prevMeasure = measure; target = next;
  }
  if (dir && !o.keepWork) fs.rmSync(dir, { recursive: true, force: true });
  return finish(spot, o, policy, lastBody, lastMeta, lastEval, { backend: trainer === 'eightmax-native' ? 'native-cli-cpu' : 'javascript-reference-cpu', trainer, variant: o.variant || 'mccfr-linear', iterations: done, resumedFrom, trainMs: Date.now() - t0, processPeakRssMiB: peakRss || null, stoppedBecause: stopped, curve, threads: o.threads || 1 });
}

function finish(spot, o, policy, body, meta, evaluation, training) {
  SNAP.decode(body);   // round trip before anything is returned for storage
  const rawSha = require('node:crypto').createHash('sha256').update(body).digest('hex');
  const stability = training.curve.length > 1 ? training.curve[training.curve.length - 1].stabilityL1 : null;
  const quality = Q.qualityDocument({ fingerprint: spot.fingerprint, recordRawSha256: rawSha, identity: spot.identity, evaluation, policy, trainingUpdates: training.iterations, curve: training.curve, stability: stability === null || stability === undefined ? null : { lastBlockL1: stability, note: 'Mean L1 change of the stored strategy over the last doubling block; small change is NOT proof of accuracy.' },
    algorithm: training.trainer === 'vector-cfr-plus' ? 'full-width vectorised CFR+ (alternating, RM+, linear averaging)' : 'external-sampling MCCFR (EightMax 5.1), ' + (training.variant || 'mccfr-linear'), limitations: training.stoppedBecause === 'quality-target-met' ? [] : ['Training stopped because: ' + training.stoppedBecause + '.'] });
  return { body, meta, training, quality };
}

module.exports = { DEFAULTS, trainingPolicy, defaultTrainer, snapshotStability, trainAdaptive, limitBBFor };
