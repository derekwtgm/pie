# Strategy abstraction: compatibility and accuracy report (0.31)

**Exact matching stays the default.** No approximate mapping is enabled for decisions in 0.31. This page reports, for every
candidate mapping, its definition, what it keeps, what it loses, and its **measured** error
(`tools/abstraction-validation-031.cjs` → `reports/0.31-abstraction-validation.json`; mappings in `src/strategy-abstraction.js`).

## Method
For each mapping, 30 reference pairs: a target situation T (heads-up river; random board; pot 3–20 bb; stacks 4–40 bb, equal or
unequal; three range families from any-two-cards to a preflop-like range; the library river menu) and its source S = map(T).
Both are solved by the full-width CFR+ to ≤ 0.02 % of the pot (`src/fast-river.js`). The S strategy is played in T along the
same tree paths and its **exact** exploitability in T is the EV loss. Also reported: action-frequency difference (mean L1)
against T's own solution and tree compatibility (same nodes, same action kinds). A mapping is **accepted** only if every compatible
pair keeps p95 EV loss ≤ 1 % of the pot (the same scale as the `research` quality policy); incompatible pairs are refused at run
time.

## Results (30 pairs each)

| Mapping | Kind | Preserves | Loses | Compatible | EV loss p50 / p95 / max (% pot) | Verdict |
|---|---|---|---|---|---|---|
| suit isomorphism | exact | everything | nothing | 30/30 | 0.018 / 0.040 / 0.051 (= solver precision) | **accepted** (already used since 0.30) |
| chip scale (pot → 10 bb, stacks scaled) | approximate | SPR, pot-relative sizes, board, ranges | absolute amounts | 30/30 | 0.017 / 0.026 / 0.026 | **accepted** |
| pot bucket (geometric 10 % grid) | approximate | board, ranges, stacks, menu | up to ~5 % of the pot | 30/30 | 0.092 / 0.459 / 0.746 | **accepted** |
| stack bucket 2.5 bb | approximate | board, ranges, pot, menu | up to 1.25 bb per stack, SPR | 30/30 | 0.250 / 2.149 / 2.804 | **rejected** |
| stack bucket 5 bb | approximate | as above | up to 2.5 bb per stack | 27/30 | 0.549 / 2.482 / 4.198 | **rejected** |
| SPR bucket {0.5,1,1.5,2,3,4,6,8,12} | approximate | pot, board, ranges, menu | exact SPR (≤ ~25 %) | 28/30 | 0.550 / 4.348 / 5.438 | **rejected** |
| river blank substitution | approximate | flop, turn, river suit, board structure | river rank (kickers, two-pair outcomes) | 30/30 | 9.28 / 23.04 / 30.54 | **rejected** |

## What this means
* Changing **stacks** moves equilibrium play more than changing the pot by a few percent: all stack/SPR bucketings tested exceed
  the 1 % limit at the 95th percentile, although their median loss is small. Bucketing stacks would increase coverage at an
  error the quality policy would reject — so it is not enabled.
* **Chip scale** is effectively exact on these games (bet sizes are pot fractions). It does not raise coverage in the simulator
  (every hand starts with equal 25 bb stacks, so pots and stacks repeat exactly per preflop line already) but it is the natural
  canonical form for variable-stack play.
* **Board abstraction is the coverage bottleneck and it is very lossy**: even the most conservative "blank river" substitution
  loses 23 % of the pot at p95.
* Scope: heads-up rivers only — the one case with exact evaluation. Nothing here validates any mapping for flops, turns or
  multiway pots; no mapping is accepted for them.

## Status in 0.31
0.31 delivers the mapping definitions, the validation harness and this report. **Using an accepted approximate mapping in the
decision path is not implemented** (it needs action histories and legal-action checks to be scaled consistently; listed for 1.0).
The coverage tooling already keeps an "abstracted" column separate from exact matches; in 0.31 it is always 0. When it is added,
such decisions must be labelled approximate, never counted as exact, and their quality can be at best `restricted-evaluation`.
