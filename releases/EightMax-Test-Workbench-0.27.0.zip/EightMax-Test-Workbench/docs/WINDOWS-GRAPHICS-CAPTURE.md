# Windows Graphics Capture (0.27) — COMPILED, NEVER RUN ON WINDOWS

**Status, stated plainly.** The 0.26 source was unbuilt. In 0.27 it was compiled for the first time, with the .NET SDK 8.0.134 on Linux (`EnableWindowsTargeting`, target `net8.0-windows10.0.22000.0`, `win-x64`, self-contained single file, 41.6 MB). The compiler found real errors in the 0.26 source (the `IsBorderRequired` property needs the 10.0.22000 projection; `System.Drawing.Common` is not part of the cross-targeting projection), which were fixed. `desktop/bin/EightMaxWgc.exe` ships. **It has NEVER RUN ON WINDOWS.** A successful compile proves the types and signatures agree with the Windows SDK projection; it does not prove that a frame is captured, that the COM vtable slots are right at run time, or what the latency is. Treat it as unverified until `RUN-WGC-CHECK.cmd` passes on a real machine.

## Design
`EightMaxWgc.exe` is a one-shot helper so that the .NET Framework host (which cannot project WinRT) stays unchanged in kind. Per call: operator-selected window (`--hwnd`, optional `--pid`) or monitor (`--monitor`) → `GraphicsCaptureItem` (via `IGraphicsCaptureItemInterop`) → Direct3D 11 device → `Direct3D11CaptureFramePool.CreateFreeThreaded` → first fresh frame → GPU texture copied to a staging texture and mapped (GPU→CPU) → PNG (own encoder, no System.Drawing) + one JSON line. Refused, never captured: invalid or reused handle (`target-lost`, `target-identity-changed`), minimised window, no frame within the timeout, first frame later than `--max-latency-ms` (`stale-frame`), resolution change during capture, an all-black frame (`blank-frame`). No process-memory access, injection, hooks, input synthesis or hiding. PerMonitorV2 DPI manifest.

## How the host uses it
* `POST /api/capture/open|frame` with `target.method = "windows-graphics-capture"` (dashboard: *Capture method*). The host first runs its normal window identity checks (handle, process id, title, minimised, cloaked), then starts the helper with an 8-second limit and passes the JSON/PNG through, adding the usual frame metadata (`helperLatencyMs` is measured by the helper).
* **No silent fallback.** If the helper is missing the reply is `backend-unavailable`; if it fails, its own code is returned (`blank-frame`, `stale-frame`, …). The operator must choose PrintWindow or screen copy explicitly.
* It is **manual-only**: the capture manager never selects it automatically (`manualOnly` in the catalogue) until it has passed the Windows acceptance check.
* `/api/desktop/health` reports `windowsGraphicsCapture=true` only when the helper file is installed.

## What the 0.27 tests verify (Linux)
Compilation for win-x64; PE headers of the shipped executables; the PNG encoder bit-for-bit (CRC-32 per chunk, every pixel of three images); host routing rules and the no-fallback rule by inspection; the safety bans (no memory access, injection, hooks, input synthesis, hiding, network).

## Not implemented
Continuous streaming with a bounded queue, deduplication and capture recovery inside the helper (each call is one frame; the host-side `CaptureSession` provides the queue, deduplication, staleness and recovery logic, which is tested with simulated windows only); monitor selection in the dashboard; any measurement of latency on real hardware.

## To verify on Windows
1. `RUN-WGC-CHECK.cmd` (captures one ordinary window, checks the PNG, refusal of an invalid window, wrong process id and a closed window; writes `reports\wgc-acceptance-*.json`).
2. In the dashboard choose *Capture method → Windows Graphics Capture*, select a window you own, tick consent, Start. Please send `reports\wgc-acceptance-*.json` or the failure text.
`BUILD-WGC.cmd` rebuilds the helper if you have the .NET 8 SDK (not needed to run the workbench).
