@echo off
rem 0.27: acceptance check of the Windows Graphics Capture helper (desktop\bin\EightMaxWgc.exe ships prebuilt). Never run on Windows by the 0.27.0 build.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\Test-Wgc.ps1" %*
pause
