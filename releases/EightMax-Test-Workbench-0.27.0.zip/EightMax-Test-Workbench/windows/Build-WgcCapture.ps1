<# EightMax Test Workbench 0.27 - build the Windows Graphics Capture helper (desktop\wgc) into desktop\bin\EightMaxWgc.exe.
   Needs the .NET 8 SDK on THIS machine once. The produced exe is self-contained: the machine that RUNS the workbench needs no .NET.
   STATUS: a prebuilt desktop\bin\EightMaxWgc.exe ships (cross-compiled on Linux with the .NET 8 SDK; never run on Windows). Use this script only to REBUILD it. This script itself has not been run. #>
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { Write-Host 'The .NET 8 SDK is required to BUILD the capture helper (https://dotnet.microsoft.com/download/dotnet/8.0). It is not needed to run the workbench.' -ForegroundColor Yellow; exit 2 }
$out = Join-Path $root 'desktop\bin'
& dotnet publish (Join-Path $root 'desktop\wgc\EightMaxWgc.csproj') -c Release -r win-x64 --self-contained true -o $out
if ($LASTEXITCODE -ne 0) { Write-Host 'Build failed. Please send the compiler messages.' -ForegroundColor Red; exit $LASTEXITCODE }
Write-Host "Built $out\EightMaxWgc.exe. Now run windows\Test-Wgc.ps1." -ForegroundColor Green
