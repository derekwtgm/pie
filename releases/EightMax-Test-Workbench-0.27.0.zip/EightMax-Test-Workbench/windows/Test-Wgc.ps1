<# EightMax Test Workbench 0.27 - acceptance check for the Windows Graphics Capture helper. Opens Notepad, captures that one window, checks the PNG.
   Writes reports\wgc-acceptance-<date>.json. Every result is measured on THIS machine; nothing is assumed. NOT RUN on Windows by the 0.27.0 build (the helper was cross-compiled on Linux). On Windows 11 the new Notepad may hand the window to another process: if the capture check fails with a process or handle error, use any other ordinary window and report it. #>
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot; $exe = Join-Path $root 'desktop\bin\EightMaxWgc.exe'; $checks = @()
function Add-Check($name, $ok, $detail) { $script:checks += [pscustomobject]@{ name = $name; passed = [bool]$ok; detail = "$detail" }; $c = if ($ok) { 'Green' } else { 'Red' }; Write-Host (('{0,-45} {1}' -f $name, $(if ($ok) { 'PASS' } else { 'FAIL' })) + "  $detail") -ForegroundColor $c }
if (-not (Test-Path $exe)) { Write-Host 'EightMaxWgc.exe is not built. Run windows\Build-WgcCapture.ps1 first.' -ForegroundColor Yellow; exit 2 }
$probe = & $exe --probe | ConvertFrom-Json; Add-Check 'probe: WGC supported' $probe.supported ($probe.os)
$np = Start-Process notepad -PassThru; Start-Sleep -Seconds 2; $np.Refresh(); $h = '0x{0:X}' -f $np.MainWindowHandle.ToInt64(); $png = Join-Path $env:TEMP 'eightmax-wgc-test.png'
$r = & $exe --hwnd $h --pid $np.Id --out $png | ConvertFrom-Json; Add-Check 'capture Notepad window' $r.ok ($r | ConvertTo-Json -Compress)
if ($r.ok) { Add-Check 'PNG written and non-trivial' ((Test-Path $png) -and (Get-Item $png).Length -gt 2000) ((Get-Item $png).Length); Add-Check 'latency below 250 ms' ($r.latencyMs -le 250) "$($r.latencyMs) ms" }
$bad = & $exe --hwnd '0x1' --out $png | ConvertFrom-Json; Add-Check 'invalid window is refused' (-not $bad.ok) $bad.code
$wrong = & $exe --hwnd $h --pid 1 --out $png | ConvertFrom-Json; Add-Check 'wrong process id is refused' ((-not $wrong.ok) -and $wrong.code -eq 'target-identity-changed') $wrong.code
Stop-Process -Id $np.Id -Force -ErrorAction SilentlyContinue
$gone = & $exe --hwnd $h --out $png | ConvertFrom-Json; Add-Check 'closed window is refused' (-not $gone.ok) $gone.code
New-Item -ItemType Directory -Force (Join-Path $root 'reports') | Out-Null
$rep = Join-Path $root ('reports\wgc-acceptance-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json'); [pscustomobject]@{ format = 'eightmax-wgc-acceptance'; machine = $env:COMPUTERNAME; os = [Environment]::OSVersion.VersionString; checks = $checks } | ConvertTo-Json -Depth 5 | Set-Content $rep -Encoding UTF8
Write-Host "Report: $rep"; if ($checks | Where-Object { -not $_.passed }) { exit 1 } else { exit 0 }
