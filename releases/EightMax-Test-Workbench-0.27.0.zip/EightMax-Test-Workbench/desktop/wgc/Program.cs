// EightMax Test Workbench 0.26 - Windows Graphics Capture helper (one-shot, operator-selected target).
//
// STATUS: COMPILES (0.27: built with the .NET 8 SDK, cross-targeting Windows) but NOT EXECUTED. No Windows
// machine was available, so wrong COM vtable slots or runtime failures remain possible. Treat every line as unverified until
// windows\Test-Wgc.ps1 passes on a real machine.
//
// Documented APIs used:
//   Windows.Graphics.Capture: GraphicsCaptureSession.IsSupported, GraphicsCaptureItem (via IGraphicsCaptureItemInterop.CreateForWindow/CreateForMonitor),
//                             Direct3D11CaptureFramePool.CreateFreeThreaded, GraphicsCaptureSession.StartCapture, Direct3D11CaptureFrame (Surface, SystemRelativeTime, ContentSize)
//   Direct3D 11 / DXGI:       D3D11CreateDevice, CreateDirect3D11DeviceFromDXGIDevice, IDirect3DDxgiInterfaceAccess, ID3D11Device::CreateTexture2D,
//                             ID3D11DeviceContext::CopyResource / Map / Unmap (staging texture: GPU -> CPU transfer)
// Never done: process memory access, injection, hooks, input synthesis, hiding. It captures ONE window or monitor that the operator selected
// and that the host validated (handle + process id + title), writes a PNG and prints one JSON line.
//
// usage: EightMaxWgc.exe --probe
//        EightMaxWgc.exe --hwnd 0x1234 [--pid N] --out frame.png [--timeout-ms 2000] [--max-latency-ms 250]
//        EightMaxWgc.exe --monitor 0x65537 --out frame.png
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Windows.Graphics.Capture;
using Windows.Graphics.DirectX;
using Windows.Graphics.DirectX.Direct3D11;
using WinRT;

namespace EightMax.Workbench.Wgc {
static class Program {
    // ---- interop declarations ----
    [ComImport, Guid("3628E81B-3CAC-4C60-B7F4-23CE0E0C3356"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IGraphicsCaptureItemInterop { IntPtr CreateForWindow([In] IntPtr window, [In] ref Guid iid); IntPtr CreateForMonitor([In] IntPtr monitor, [In] ref Guid iid); }
    [ComImport, Guid("A9B3D012-3DF2-4EE3-B8D1-8695F457D3C1"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IDirect3DDxgiInterfaceAccess { IntPtr GetInterface([In] ref Guid iid); }
    [DllImport("combase.dll")] static extern int RoGetActivationFactory(IntPtr classId, ref Guid iid, out IntPtr factory);
    [DllImport("combase.dll", CharSet = CharSet.Unicode)] static extern int WindowsCreateString(string src, int length, out IntPtr hstring);
    [DllImport("combase.dll")] static extern int WindowsDeleteString(IntPtr hstring);
    [DllImport("d3d11.dll")] static extern int D3D11CreateDevice(IntPtr adapter, int driverType, IntPtr software, uint flags, IntPtr featureLevels, uint nLevels, uint sdkVersion, out IntPtr device, out int level, out IntPtr context);
    [DllImport("d3d11.dll")] static extern int CreateDirect3D11DeviceFromDXGIDevice(IntPtr dxgiDevice, out IntPtr graphicsDevice);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);

    static readonly Guid IID_GraphicsCaptureItem = new Guid("79C3F95B-31F7-4EC2-A464-632EF5D30760");
    static readonly Guid IID_ID3D11Texture2D = new Guid("6F15AAF2-D208-4E89-9AB4-489535D34F9C");
    static readonly Guid IID_IDXGIDevice = new Guid("54EC77FA-1377-44E6-8C32-88FD5F44C84C");

    // ---- raw COM calls through the vtable (slots from d3d11.h: ID3D11Device::CreateTexture2D = 5; ID3D11DeviceContext::Map = 14, Unmap = 15, CopyResource = 47) ----
    delegate int CreateTexture2DFn(IntPtr self, ref TEXTURE2D_DESC desc, IntPtr initial, out IntPtr texture);
    delegate void GetDescFn(IntPtr self, out TEXTURE2D_DESC desc);
    delegate void CopyResourceFn(IntPtr self, IntPtr dst, IntPtr src);
    delegate int MapFn(IntPtr self, IntPtr resource, uint subresource, uint mapType, uint flags, out MAPPED mapped);
    delegate void UnmapFn(IntPtr self, IntPtr resource, uint subresource);
    delegate uint ReleaseFn(IntPtr self);
    [StructLayout(LayoutKind.Sequential)] struct TEXTURE2D_DESC { public uint Width, Height, MipLevels, ArraySize, Format, SampleCount, SampleQuality, Usage, BindFlags, CPUAccessFlags, MiscFlags; }
    [StructLayout(LayoutKind.Sequential)] struct MAPPED { public IntPtr Data; public uint RowPitch, DepthPitch; }
    static T Slot<T>(IntPtr obj, int index) where T : Delegate { IntPtr vtbl = Marshal.ReadIntPtr(obj); return Marshal.GetDelegateForFunctionPointer<T>(Marshal.ReadIntPtr(vtbl, index * IntPtr.Size)); }
    static void Release(IntPtr p) { if (p != IntPtr.Zero) Slot<ReleaseFn>(p, 2)(p); }

    const string ClassName = "Windows.Graphics.Capture.GraphicsCaptureItem";

    static string Q(string s) { var b = new StringBuilder("\""); foreach (char c in s ?? "") { if (c == '"' || c == '\\') b.Append('\\').Append(c); else if (c < 32) b.Append(' '); else b.Append(c); } return b.Append('"').ToString(); }
    static int Fail(string code, string reason) { Console.WriteLine("{\"ok\":false,\"backend\":\"windows-graphics-capture\",\"code\":" + Q(code) + ",\"reason\":" + Q(reason) + "}"); return 1; }
    static IntPtr ParseHandle(string s) { s = s.Trim(); return new IntPtr(s.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? Convert.ToInt64(s.Substring(2), 16) : Convert.ToInt64(s)); }

    static GraphicsCaptureItem CreateItem(IntPtr handle, bool monitor) {
        IntPtr hs; Marshal.ThrowExceptionForHR(WindowsCreateString(ClassName, ClassName.Length, out hs));
        try {
            Guid iid = typeof(IGraphicsCaptureItemInterop).GUID; IntPtr factory; Marshal.ThrowExceptionForHR(RoGetActivationFactory(hs, ref iid, out factory));
            var interop = (IGraphicsCaptureItemInterop)Marshal.GetObjectForIUnknown(factory); Guid item = IID_GraphicsCaptureItem;
            IntPtr p = monitor ? interop.CreateForMonitor(handle, ref item) : interop.CreateForWindow(handle, ref item);
            try { return MarshalInterface<GraphicsCaptureItem>.FromAbi(p); } finally { Marshal.Release(p); Marshal.Release(factory); }
        } finally { WindowsDeleteString(hs); }
    }

    static int Main(string[] args) {
        string hwnd = null, monitor = null, outFile = null; int pid = 0, timeoutMs = 2000, maxLatencyMs = 250;
        for (int i = 0; i < args.Length; i++) {
            switch (args[i]) {
                case "--probe": Console.WriteLine("{\"ok\":true,\"backend\":\"windows-graphics-capture\",\"supported\":" + (GraphicsCaptureSession.IsSupported() ? "true" : "false") + ",\"os\":" + Q(Environment.OSVersion.ToString()) + "}"); return 0;
                case "--hwnd": hwnd = args[++i]; break; case "--monitor": monitor = args[++i]; break; case "--out": outFile = args[++i]; break;
                case "--pid": pid = int.Parse(args[++i]); break; case "--timeout-ms": timeoutMs = int.Parse(args[++i]); break; case "--max-latency-ms": maxLatencyMs = int.Parse(args[++i]); break;
                default: return Fail("bad-arguments", "Unknown argument " + args[i]);
            }
        }
        if ((hwnd == null) == (monitor == null) || outFile == null) return Fail("bad-arguments", "Give exactly one of --hwnd / --monitor, and --out");
        if (!GraphicsCaptureSession.IsSupported()) return Fail("unsupported", "Windows Graphics Capture needs Windows 10 version 1903 or later.");
        IntPtr device = IntPtr.Zero, context = IntPtr.Zero, staging = IntPtr.Zero, graphicsDevice = IntPtr.Zero;
        try {
            IntPtr h = ParseHandle(hwnd ?? monitor);
            if (hwnd != null) {   // identity checks mirror the host's PrintWindow path: a reused handle or a minimised window is refused, never captured
                if (!IsWindow(h)) return Fail("target-lost", "The window no longer exists.");
                uint owner; GetWindowThreadProcessId(h, out owner); if (pid != 0 && owner != (uint)pid) return Fail("target-identity-changed", "The handle now belongs to process " + owner + ", not " + pid + ".");
                if (IsIconic(h)) return Fail("target-minimized", "The window is minimised; no frames are produced for it.");
            }
            var item = CreateItem(h, hwnd == null);
            Marshal.ThrowExceptionForHR(D3D11CreateDevice(IntPtr.Zero, 1 /*HARDWARE*/, IntPtr.Zero, 0x20 /*BGRA_SUPPORT*/, IntPtr.Zero, 0, 7 /*SDK*/, out device, out int level, out context));
            Guid dxgi = IID_IDXGIDevice; Marshal.QueryInterface(device, ref dxgi, out IntPtr dxgiDevice);
            Marshal.ThrowExceptionForHR(CreateDirect3D11DeviceFromDXGIDevice(dxgiDevice, out graphicsDevice)); Marshal.Release(dxgiDevice);
            IDirect3DDevice d3d = MarshalInterface<IDirect3DDevice>.FromAbi(graphicsDevice);
            var size = item.Size; if (size.Width <= 0 || size.Height <= 0) return Fail("empty-target", "The target reports a zero size.");
            using (var pool = Direct3D11CaptureFramePool.CreateFreeThreaded(d3d, DirectXPixelFormat.B8G8R8A8UIntNormalized, 2, size)) {
                var session = pool.CreateCaptureSession(item); session.IsCursorCaptureEnabled = false; try { session.IsBorderRequired = false; } catch { /* property needs a newer Windows build */ }
                var arrived = new ManualResetEventSlim(false); pool.FrameArrived += (s, e) => arrived.Set();
                var clock = Stopwatch.StartNew(); session.StartCapture();
                Direct3D11CaptureFrame frame = null; long deadline = timeoutMs;
                while (clock.ElapsedMilliseconds < deadline) { if (!arrived.Wait((int)Math.Max(1, deadline - clock.ElapsedMilliseconds))) break; arrived.Reset(); frame = pool.TryGetNextFrame(); if (frame != null) break; }
                if (frame == null) return Fail("no-frame", "No frame arrived within " + timeoutMs + " ms (window hidden, static or protected content).");
                long latencyMs = clock.ElapsedMilliseconds; if (latencyMs > maxLatencyMs) return Fail("stale-frame", "First frame took " + latencyMs + " ms (limit " + maxLatencyMs + " ms); refused.");
                var content = frame.ContentSize; if (content.Width != size.Width || content.Height != size.Height) return Fail("resolution-changed", "Target resized from " + size.Width + "x" + size.Height + " to " + content.Width + "x" + content.Height + " during capture.");
                var access = frame.Surface.As<IDirect3DDxgiInterfaceAccess>(); Guid tex = IID_ID3D11Texture2D; IntPtr src = access.GetInterface(ref tex);
                try {
                    Slot<GetDescFn>(src, 10)(src, out TEXTURE2D_DESC d);                      // ID3D11Texture2D::GetDesc (slot 10)
                    d.Usage = 3 /*STAGING*/; d.BindFlags = 0; d.CPUAccessFlags = 0x20000 /*READ*/; d.MiscFlags = 0;
                    Marshal.ThrowExceptionForHR(Slot<CreateTexture2DFn>(device, 5)(device, ref d, IntPtr.Zero, out staging));
                    Slot<CopyResourceFn>(context, 47)(context, staging, src);
                    Marshal.ThrowExceptionForHR(Slot<MapFn>(context, 14)(context, staging, 0, 1 /*READ*/, 0, out MAPPED m));
                    int w = (int)d.Width, hgt = (int)d.Height; var bytes = new byte[w * hgt * 4]; bool any = false;
                    for (int y = 0; y < hgt; y++) { Marshal.Copy(m.Data + (int)(y * m.RowPitch), bytes, y * w * 4, w * 4); }
                    Slot<UnmapFn>(context, 15)(context, staging, 0);
                    for (int i = 0; i < bytes.Length; i += 4) if (bytes[i] != 0 || bytes[i + 1] != 0 || bytes[i + 2] != 0) { any = true; break; }
                    if (!any) return Fail("blank-frame", "The captured frame is completely black; refused.");
                    string tmp = outFile + ".tmp"; File.WriteAllBytes(tmp, PngWriter.Encode(bytes, w, hgt)); File.Move(tmp, outFile, true);
                    Console.WriteLine("{\"ok\":true,\"backend\":\"windows-graphics-capture\",\"width\":" + w + ",\"height\":" + hgt + ",\"latencyMs\":" + latencyMs + ",\"systemRelativeTimeMs\":" + (long)frame.SystemRelativeTime.TotalMilliseconds + ",\"path\":" + Q(outFile) + "}");
                    return 0;
                } finally { Release(src); frame.Dispose(); session.Dispose(); }
            }
        } catch (Exception e) { return Fail("capture-failed", e.GetType().Name + ": " + e.Message); }
        finally { Release(staging); Release(context); Release(device); }
    }
}
}
