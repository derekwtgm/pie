@echo off
rem 0.27: REBUILD the Windows Graphics Capture helper (a prebuilt desktop\bin\EightMaxWgc.exe already ships). Needs the .NET 8 SDK on THIS machine once. Never run on Windows.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\Build-WgcCapture.ps1" %*
pause
