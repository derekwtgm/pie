# Windows CI for 0.32.0 (prepared, not yet run)

These are the 0.31 GitHub Actions files updated for 0.32: `workbench-ci/ci.ps1` (driver) and `.github/workflows/workbench-windows.yml`.
The 0.32 build session could read the user's repository (public clone) but could **not push** to it: the session's GitHub token was
invalid and attaching the repository with push access was refused by the session's permission policy. **No Windows CI run exists
for 0.32** (and none exists for the executables rebuilt in 0.31 either).

To run it: on a new branch of the repository that holds the 0.30/0.31 CI files, add `releases/EightMax-Test-Workbench-0.32.0.zip` and
its `.sha256` (the driver refuses a ZIP whose hash differs), plus these two files at the same paths, and push. The workflow tests
the exact ZIP on a GitHub-hosted Windows runner: release acceptance with install and rollback, the Node suite with the bundled
node.exe, the strategy library, quality evaluation, the shared-retrieval benchmark, derived ranges, the quick long-duration profile
and (0.32) the shared-preflop memory comparison, the turn-solver benchmark and a fast preflop research study.
A hosted runner is NOT the target PC (no GPU, virtual display): run RUN-RELEASE-ACCEPTANCE.cmd and RUN-LONG-ACCEPTANCE.cmd there.
