'use strict';
/* 0.32 multi-table benchmark (extends tools/benchmark-031.cjs; the 0.31 tool is kept unchanged for reproduction).
 * 0.32 additions: --sharedPreflop=1 loads the preflop strategy ONCE into a SharedArrayBuffer (src/preflop-snapshot.js) that every
 * worker reads without copying (0.31: every worker opened its own lazy reader of the whole linked state); --stacks=BB runs fixed
 * deep-stack scenarios; per-street accounting (solver / validated / unverified / unavailable / scripted) for every run;
 * --turnSolver=1 enables the exact heads-up turn solver (on-demand, opt-in) in workload G.
 * Original 0.31 header follows.
 * 0.31 multi-table benchmark. Every run is a COMPLETE simulated pipeline (workload F in the brief): render -> capture ->
 * recognise -> reconstruct -> decide (strategy + quality gate) -> execute -> confirm, on simulated tables with the real native
 * solver. Workloads (kept apart so their numbers are never mixed):
 *   E  active solver computation : empty library, Study Mode, any-two-cards ranges, fixed 20,000 updates (the 0.30 setting):
 *                                  every new postflop spot is trained in the decision path, then stored
 *   A  fully cached              : the E hands again, Decision Mode, every record pre-loaded into shared memory
 *   B  partially cached          : UNSEEN seed against the E library: misses are reported as unavailable (labelled scripted policy acts)
 *   C  range-aware               : derived ranges (preflop line -> flop -> turn -> river) + quality-targeted training, Study Mode
 *                                  (build), then the same hands replayed from the library (C-replay, Decision Mode, pre-loaded)
 *   D  quality-gated             : the C hands, Decision Mode, gate use 'decision' (only VALIDATED strategies may be used);
 *                                  everything else is refused by the gate and counted
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/benchmark-031.cjs --tables=1,2,5,8,10 --hands=8 --workers=4 --seed=4127 --cseed=9001
 *        --updates=500000 --workloads=E,A,B,C,D --cache=v2|v1 --work=DIR --out=FILE
 * SIMULATED TABLES on this machine; not a real client; not the Windows target PC; no GPU. */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), { Worker } = require('node:worker_threads');
const RM = require('../src/resource-monitor.js'), L = require('../src/strategy-library.js'), SC = require('../src/shared-strategy-cache.js');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')));
const cli = process.env.EIGHTMAX_TEST_CLI; if (!cli) { console.error('EIGHTMAX_TEST_CLI is required (native engine).'); process.exit(2); }
const tablesList = String(args.tables || '1,2,5,8,10').split(',').map(Number), hands = +(args.hands || 8), workers = +(args.workers || 4), seed = +(args.seed || 4127), cseed = +(args.cseed || 9001);
const updates = +(args.updates || 500000), workloads = String(args.workloads || 'E,A,B,C,D').split(','), work = args.work || fs.mkdtempSync(path.join(os.tmpdir(), 'em-bench031-')), cacheKind = args.cache || 'v2';
const sharedPreflop = args.sharedPreflop === '1', stacksBB = args.stacks ? +args.stacks : null, turnSolver = args.turnSolver === '1';
let preflopShared = null;   // { buffer, fingerprint, ... } when --sharedPreflop=1
const adaptive = { maxUpdates: +(args.maxUpdates || 320000), adaptiveMaxTimeMs: +(args.adaptiveMs || 8000) };
const pct = (a, p) => { if (!a.length) return null; const s = a.slice().sort((x, y) => x - y); return +s[Math.min(s.length - 1, Math.ceil(p / 100 * s.length) - 1)].toFixed(3); };
const dist = (a) => ({ n: a.length, p50: pct(a, 50), p95: pct(a, 95), p99: pct(a, 99), max: a.length ? +Math.max(...a).toFixed(3) : null, mean: a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(3) : null });

function inWorker(job, port, svc) {
  return new Promise((res, rej) => {
    const w = new Worker(path.join(__dirname, 'pipeline-worker.cjs'), { workerData: { job, libraryPort: port, libraryService: port && svc ? svc : undefined }, transferList: port ? [port] : [] });
    let done = false; w.on('message', (m) => { done = true; return m.ok ? res(m.result) : rej(new Error(m.error)); }); w.on('error', rej); w.on('exit', (c) => { if (!done) rej(new Error('pipeline worker exited with code ' + c)); });
  });
}
function coverage(actions) {
  const SID = require('../src/strategy-identity.js'), by = {}, add = (k, solver) => { const c = by[k] || (by[k] = { solver: 0, fallback: 0 }); c[solver ? 'solver' : 'fallback']++; };
  for (const [street, players, eff, source] of actions) { const sv = source === 'solver'; add('street:' + street, sv); if (street !== 'preflop') { add('postflop:' + (players === 2 ? 'heads-up' : 'multiway'), sv); if (eff !== null) add('postflop-stack:' + SID.stackCategory(eff / 100), sv); add('postflop:all', sv); } }
  for (const v of Object.values(by)) v.solverShare = +(v.solver / Math.max(1, v.solver + v.fallback)).toFixed(4);
  return by;
}
/** 0.32 per-street accounting. a = [street, players, eff, source, strategySource, unavailableCode, decideMs, cache, quality, rangeModel, fp, rangeFallback] */
function byStreet(actions) {
  const out = {};
  for (const a of actions) { const st = a[0], e = out[st] || (out[st] = { decisions: 0, solverAttributed: 0, qualityValidated: 0, unverified: 0, otherQuality: 0, unavailableStrategy: 0, scriptedFallback: 0, solvedOnDemand: 0 });
    e.decisions++; if (a[3] === 'solver') { e.solverAttributed++; if (a[4] === 'solved-on-demand') e.solvedOnDemand++; if (st !== 'preflop') { if (a[8] === 'validated') e.qualityValidated++; else if (a[8] === 'unverified') e.unverified++; else if (a[8]) e.otherQuality++; } } else { e.scriptedFallback++; if (a[5]) e.unavailableStrategy++; } }
  return out;
}
function makeHost(dir) { const lib = L.StrategyLibrary.open(dir, { sharedMemory: true, cacheBytes: 1024 * 1048576 }); return cacheKind === 'v1' ? new SC.SharedStrategyHost(lib) : new SC.SharedStrategyService(dir, { cacheBytes: 1024 * 1048576 }); }

async function runOne(name, tables, o) {
  const groups = Array.from({ length: Math.min(workers, tables) }, () => []); for (let i = 1; i <= tables; i++) groups[(i - 1) % groups.length].push(i);
  let host = null; if (o.shared) { host = makeHost(o.lib); if (host.ready) await host.ready(); if (o.prewarm) await host.prewarm(); }
  const mon = new RM.RunMonitor({ intervalMs: 100 }).start(), t0 = Date.now();
  const library = { dir: o.lib, mode: o.mode, shared: !!o.shared, iterations: 20000, workDir: path.join(work, 'inline-work'), rangeModel: o.ranges || 'any-two', adaptive: !!o.adaptive, maxUpdates: adaptive.maxUpdates, adaptiveMaxTimeMs: adaptive.adaptiveMaxTimeMs, quality: { policy: o.policy || 'research', use: o.use || 'simulation-experiment' } };
  if (o.turnSolver) Object.assign(library, { turnSolver: true, inlineHeadsUpTurn: true, inlineHeadsUpRiver: true, inlineTurnMaxMs: +(args.turnMs || 8000), storeLinked: true });
  const solver = { kind: 'preflop-linked', cli, updates, budgetMiB: +(args.budgetMiB || 1024), cacheDir: args.preflopCache || path.join(work, 'preflop-cache'), library, ...(preflopShared ? { preflopSnapshot: preflopShared.buffer, preflopFingerprint: preflopShared.fingerprint } : {}) };
  const parts = await Promise.all(groups.map((g, gi) => inWorker({ tables: g, hands, seed: o.seed, workerId: gi + 1, solver, collectActions: true, ...(stacksBB ? { stacks: stacksBB } : {}) }, host ? host.port() : null, host && host.descriptor ? host.descriptor() : null)));
  parts.forEach((x) => mon.workerReport(x.self)); const res = mon.report({ workers: groups.length }); mon.stop();
  const reps = parts.flatMap((p) => p.reports), actions = parts.flatMap((p) => p.actions), cycles = parts.flatMap((p) => p.cycles), libs = parts.map((p) => p.library).filter(Boolean);
  const sum = (f) => reps.reduce((n, r) => n + f(r), 0), lsum = (k) => libs.reduce((n, l) => n + (l[k] || 0), 0), lt = (k) => libs.flatMap((l) => (l.rawTimings ? l.rawTimings[k] : []));
  const post = actions.filter((a) => a[0] !== 'preflop'), postSolver = post.filter((a) => a[3] === 'solver');
  const qualityCounts = {}; for (const a of postSolver) { const q = a[8] || 'n/a'; qualityCounts[q] = (qualityCounts[q] || 0) + 1; }
  const rangeCounts = {}; for (const a of postSolver) { const r = (a[9] || 'n/a').replace(/\[.*$/, '') + (a[11] ? ' (fallback)' : ''); rangeCounts[r] = (rangeCounts[r] || 0) + 1; }
  const qByStatus = libs.reduce((m, l) => { for (const [k, v] of Object.entries(l.qualityByStatus || {})) m[k] = (m[k] || 0) + v; return m; }, {});
  const wallMs = Date.now() - t0;
  const out = { workload: name, tables, workers: groups.length, seed: o.seed, mode: o.mode, rangeModel: library.rangeModel, adaptiveTraining: library.adaptive, qualityPolicy: library.quality, sharedCache: o.shared ? cacheKind : null, prewarmed: !!o.prewarm, wallMs,
    handsRequested: tables * hands, handsCompleted: sum((r) => r.completed), decisions: actions.length, decisionsPerSecond: +(actions.length / (wallMs / 1000)).toFixed(3),
    solverDecisions: actions.filter((a) => a[3] === 'solver').length, scriptedFallbackDecisions: actions.filter((a) => a[3] !== 'solver').length,
    postflop: { decisions: post.length, fromLibraryExact: postSolver.filter((a) => /^library-/.test(a[4] || '')).length, trainedNow: postSolver.filter((a) => a[4] === 'trained-now').length, abstractedApproximate: 0, unavailable: post.length - postSolver.length, qualityOfUsedStrategies: qualityCounts, rangeModelOfUsedStrategies: rangeCounts },
    library: { memoryHits: lsum('memoryHits'), sharedHits: lsum('sharedHits'), diskHits: lsum('diskHits'), misses: lsum('misses'), refused: lsum('refused'), qualityRejected: lsum('qualityRejected'), qualityByStatusAtLookup: qByStatus, rangeFallbacks: lsum('rangeFallbacks'), rangeUnavailable: lsum('rangeUnavailable'), trainedInline: lsum('trainedInline'), coalesced: lsum('coalesced'),
      cacheHitRate: null, rangeModel: libs.map((l) => l.rangeModel).filter(Boolean) },
    latencyMs: { endToEndCycle: dist(cycles), decision: dist(actions.map((a) => a[6]).filter((x) => x !== null && x !== undefined)), postflopDecision: dist(post.map((a) => a[6])), postflopLibraryHit: dist(post.filter((a) => /^library-/.test(a[4] || '')).map((a) => a[6])),
      sharedFetch: dist(libs.flatMap((l) => (l.rawTimings && l.rawTimings.sharedMs) || [])), strategyLookupMemory: dist(lt('cacheMs')), strategyLoadDisk: dist(lt('diskMs')), solverComputation: dist(lt('trainMs')), decisionCycleP95WorstTable: Math.max(...reps.map((r) => (r.latencyMs.cycle && r.latencyMs.cycle.p95) || 0)) },
    staleDecisions: sum((r) => r.totals.staleDecisions), ackMismatches: sum((r) => r.totals.ackMismatches), suspendedHands: sum((r) => r.totals.suspended), duplicateActionsBlocked: sum((r) => r.totals.duplicateBlocked),
    decisionTimeouts: sum((r) => (r.solver && r.solver.stats && r.solver.stats.timeout) || 0), workerErrors: 0,
    unavailableCodes: reps.reduce((m, r) => { for (const [k, v] of Object.entries(r.unavailableCodes || {})) m[k] = (m[k] || 0) + v; return m; }, {}),
    byStreet: byStreet(actions), coverage: coverage(actions), resources: { cpuCoresBusy: res.process && res.process.cpuCoresBusy, cpuUtilizationOfMachine: res.process && res.process.cpuUtilizationOfMachine, rssBytesPeak: res.process && res.process.rssBytesPeak, nativeRssBytesPeak: res.native ? res.native.rssBytesPeak : null },
    sharedHost: host ? host.info() : null };
  const hits = out.library.memoryHits + out.library.sharedHits + out.library.diskHits; out.library.cacheHitRate = +(out.library.memoryHits / Math.max(1, hits + out.library.misses)).toFixed(4); out.library.libraryHitRate = +(hits / Math.max(1, hits + out.library.misses)).toFixed(4);
  if (host) await host.close();
  process.stderr.write(name + ' ' + tables + 't: hands ' + out.handsCompleted + '/' + out.handsRequested + ', postflop lib/trained/unavail ' + out.postflop.fromLibraryExact + '/' + out.postflop.trainedNow + '/' + out.postflop.unavailable + ', quality ' + JSON.stringify(qualityCounts) + ', ranges ' + JSON.stringify(rangeCounts) + ', gate-refused ' + out.library.qualityRejected + ', cycle p50/p95/p99 ' + out.latencyMs.endToEndCycle.p50 + '/' + out.latencyMs.endToEndCycle.p95 + '/' + out.latencyMs.endToEndCycle.p99 + ' ms, shared fetch p50/p95/p99 ' + out.latencyMs.sharedFetch.p50 + '/' + out.latencyMs.sharedFetch.p95 + '/' + out.latencyMs.sharedFetch.p99 + ', rss ' + Math.round((out.resources.rssBytesPeak || 0) / 1048576) + ' MiB\n');
  return out;
}

(async () => {
  const doc = { format: 'eightmax-benchmark-032', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), classification: 'SIMULATED TABLES, complete pipeline, real native solver; this machine only; not a real client; not the Windows target PC; no GPU',
    machine: { platform: process.platform, arch: process.arch, node: process.version, cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, totalMemBytes: os.totalmem() },
    settings: { handsPerTable: hands, workers, seed, unseenSeed: cseed, preflopUpdates: updates, sharedCache: cacheKind, adaptive, workloads, sharedPreflop, stacksBB: stacksBB || 25, turnSolver }, runs: {} };
  if (sharedPreflop) { const TS = require('./train-study.cjs'), T2 = require('./studies.cjs'), t0 = Date.now(); process.env.EIGHTMAX_TEST_CLI = cli;
    preflopShared = await TS.preflopSnapshotFor(updates, { config: T2.PREFLOP8_LINKED, name: 'preflop8-linked', cacheDir: args.preflopCache || path.join(work, 'preflop-cache'), threads: 2, budgetMiB: +(args.budgetMiB || 1024), cli });
    doc.sharedPreflop = { bytes: preflopShared.buffer.byteLength, fingerprint: preflopShared.fingerprint, loadMs: Date.now() - t0, buildMs: preflopShared.buildMs, file: preflopShared.file, note: 'one SharedArrayBuffer in the main thread; workers receive it through workerData without copying' }; }
  const save = () => { if (args.out) { fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true }); fs.writeFileSync(args.out, JSON.stringify(doc, null, 1)); } };
  for (const T of tablesList) {
    const libE = path.join(work, 'lib-E-' + T), libC = path.join(work, 'lib-C-' + T); doc.runs[T] = {};
    if (workloads.includes('E')) { fs.rmSync(libE, { recursive: true, force: true }); doc.runs[T].E = await runOne('E', T, { lib: libE, mode: 'study', seed }); save(); }
    if (workloads.includes('A')) { doc.runs[T].A = await runOne('A', T, { lib: libE, mode: 'decision', seed, shared: true, prewarm: true }); save(); }
    if (workloads.includes('B')) { doc.runs[T].B = await runOne('B', T, { lib: libE, mode: 'decision', seed: cseed, shared: true }); save(); }
    if (workloads.includes('C')) { fs.rmSync(libC, { recursive: true, force: true }); doc.runs[T].C = await runOne('C', T, { lib: libC, mode: 'study', seed, ranges: 'derived', adaptive: true }); save();
      doc.runs[T]['C-replay'] = await runOne('C-replay', T, { lib: libC, mode: 'decision', seed, shared: true, prewarm: true, ranges: 'derived', adaptive: true }); save(); }
    // F (0.32): deep-stack scenario - Decision Mode on an EMPTY library, missing heads-up rivers and turns solved on demand (exact,
    // bounded, labelled), any-two-cards ranges; run with --stacks=15|25|40|60|100. Preflop decisions at stacks other than the study's
    // 25 bb are unavailable from the preflop study and use the labelled scripted policy (counted per street).
    if (workloads.includes('F')) { const libF = path.join(work, 'lib-F-' + T + '-' + (stacksBB || 25)); fs.rmSync(libF, { recursive: true, force: true }); doc.runs[T].F = await runOne('F', T, { lib: libF, mode: 'decision', seed, adaptive: true, turnSolver: true }); save(); }
    if (workloads.includes('G')) { const libG = path.join(work, 'lib-G-' + T); fs.rmSync(libG, { recursive: true, force: true }); doc.runs[T].G = await runOne('G', T, { lib: libG, mode: 'decision', seed, ranges: 'derived', adaptive: true, turnSolver: true }); save(); }
    if (workloads.includes('D')) { doc.runs[T].D = await runOne('D', T, { lib: libC, mode: 'decision', seed, shared: true, prewarm: true, ranges: 'derived', adaptive: true, use: 'decision' }); save(); }
    for (const [k, d] of [['libraryE', libE], ['libraryC', libC]]) if (fs.existsSync(d)) doc.runs[T][k] = L.StrategyLibrary.open(d, { readOnly: true }).status();
    save();
  }
  if (!args.out) console.log(JSON.stringify(doc, null, 1));
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
