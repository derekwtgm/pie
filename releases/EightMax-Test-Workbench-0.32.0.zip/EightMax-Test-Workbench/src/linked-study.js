/* EightMax Test Workbench 0.32: LINKED multi-street strategy record (flop -> turn -> river continuation strategies).
 *
 * Why: a 0.31 library record is a street snapshot (src/strategy-snapshot.js). It keeps the first street's average strategy, so a
 * flop or turn record cannot be evaluated: its value depends on the turn and river strategies the trained study also learned but
 * did not export. The trained study DOES hold them (the EightMax engine trains the whole tree from the study's start to the river;
 * the workbench uses exact private-hand keys, so every later-street row is keyed by the actual board). This module exports them.
 *
 * Contents (all lossless; numbers are the IEEE-754 doubles returned by the engine's averageAt, copied, never rounded):
 *   meta JSON : format/version, study identity link (street-record fingerprint), start board, range rows, iterations,
 *               the complete betting geometry of every street (decision nodes: path, seat, pot, stacks behind, live flags,
 *               menu labels; chance nodes; terminal contributions), parent-child links (paths: 'c' = dealt card),
 *               and a section index.
 *   sections  : one per public board (the start board, each turn card, each turn+river pair that is reached). A section holds,
 *               for every decision node of that street, k doubles per range row (NaN in slot 0 = no stored row, i.e. the
 *               information set was never visited - reported, never filled in). Each section is deflated separately so a
 *               decision on one runout inflates only that runout (lazy, on-demand subtree loading; bounded LRU).
 * Integrity: SHA-256 over the meta bytes and over every section's compressed bytes, verified on open (corruption is refused).
 *
 * Binary: "EMLK" | u32 version | u32 metaLen | meta JSON | 32-byte SHA-256 of the meta JSON | section bytes (concatenated, offsets in meta.sections)
 * Exposed: exportLinked(prepared, o) -> Uint8Array; open(bytes, o) -> LinkedGame (view, averageAt, coverage, stats);
 *          tree geometry is reused from src/fast-multistreet.js (buildTree) so evaluation and storage agree by construction.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./fast-multistreet.js'), require('node:zlib'), require('node:crypto'));
  else throw new Error('linked-study.js is a Node module');
})(typeof globalThis !== 'undefined' ? globalThis : this, function (MS, zlib, crypto) {
  'use strict';
  const VERSION = 1, MAGIC = [0x45, 0x4d, 0x4c, 0x4b];
  class LinkedError extends Error { constructor(code, m) { super(m); this.code = code; this.name = 'LinkedError'; } }
  const ok = (x, code, m) => { if (!x) throw new LinkedError(code, m); };
  const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');

  /** Compact geometry (no children arrays) + per-street node lists, from MS.buildTree. */
  function flatten(T) {
    const nodes = [], streets = {};
    const rec = (n) => {
      const e = { p: n.path, kind: n.kind, street: n.street, pot: n.pot, behind: n.behind, live: n.live };
      if (n.kind === 'player') { e.seat = n.seat; e.k = n.k; e.labels = n.labels; (streets[n.street] = streets[n.street] || []).push(n.path); }
      if (n.kind === 'terminal') { e.contrib = n.contrib; e.total = n.total; }
      nodes.push(e);
      if (n.kind === 'player') n.children.forEach(rec); else if (n.kind === 'chance') rec(n.child);
    };
    rec(T.tree); return { nodes, streets };
  }

  /** Export every street of a trained (prepared) study. o.maxBytes bounds the uncompressed strategy size (refused above it).
   *  o.fingerprint links the record to its street record; o.identity is stored verbatim. o.EM memoises evalCards during export. */
  function exportLinked(prepared, o = {}) {
    const g = prepared.game, spec = prepared.spec, T = MS.buildTree(g, spec, { verifyCards: o.verifyCards === undefined ? 2 : o.verifyCards });
    const { nodes, streets } = flatten(T), board0 = T.board, hands = spec.hands;
    const byStreet = (len) => (streets[len] || []).map((p) => nodes.find((x) => x.p === p));
    // which boards exist: every next card not on the board (hands that collide are stored as NaN = "impossible/no row")
    const boards = [[]]; if (board0.length <= 3 && streets[4]) for (let c = 0; c < 52; c++) if (!board0.includes(c)) boards.push([c]);
    if (streets[5] && board0.length <= 4) { const base = boards.slice(); for (const b of base) { if (board0.length + b.length !== 4) continue; for (let c = 0; c < 52; c++) if (!board0.includes(c) && !b.includes(c)) boards.push(b.concat(c)); } }
    const EMlib = o.EM, origEval = EMlib && EMlib.evalCards, memo = new Map();
    if (origEval) EMlib.evalCards = function (cards) { const k = cards.join(','); let v = memo.get(k); if (v === undefined) { v = origEval.apply(this, arguments); memo.set(k, v); } return v; };
    const sections = [], parts = []; let offset = 0, raw = 0, stored = 0, missing = 0, impossible = 0;
    try {
      for (const b of boards) {
        const len = board0.length + b.length, list = byStreet(len); if (!list.length) continue;
        const full = board0.concat(b), width = list.reduce((s, n) => s + n.k * hands[n.seat].length, 0), arr = new Float64Array(width); let w = 0;
        for (const n of list) for (const r of hands[n.seat]) {
          const dead = full.includes(r[1]) || full.includes(r[2]);
          const pr = dead ? null : g.averageAt(n.p, full, n.seat, { id: r[0], a: r[1], b: r[2], w: r[3] });
          if (pr) { ok(pr.length === n.k, 'width', 'Strategy width differs from the menu at ' + n.p); for (let a = 0; a < n.k; a++) arr[w + a] = pr[a]; stored++; }
          else { arr[w] = NaN; for (let a = 1; a < n.k; a++) arr[w + a] = 0; if (dead) impossible++; else missing++; }
          w += n.k;
        }
        raw += arr.byteLength; ok(!o.maxBytes || raw <= o.maxBytes, 'too-large', 'Linked strategy exceeds ' + o.maxBytes + ' bytes uncompressed');
        const z = zlib.deflateRawSync(Buffer.from(arr.buffer), { level: o.level || 6 });
        sections.push({ board: b, street: len, offset, length: z.length, values: width, sha256: sha(z) }); parts.push(z); offset += z.length;
      }
    } finally { if (origEval) EMlib.evalCards = origEval; }
    const meta = { format: 'eightmax-linked-study', version: VERSION, createdBy: 'EightMax Test Workbench 0.32', fingerprint: o.fingerprint || null, identity: o.identity || null,
      iterations: g.iterations, startBoard: board0, startStreet: board0.length === 3 ? 'flop' : board0.length === 4 ? 'turn' : 'river', players: T.n, commonPot: T.common, startStacks: T.start,
      hands, nodes, streets, sections, counts: { decisionNodes: T.decisions, treeNodes: T.nodes, storedRows: stored, missingRows: missing, impossibleRows: impossible, boards: sections.length, rawBytes: raw, compressedBytes: offset },
      storage: 'lossless: IEEE-754 doubles from averageAt, raw-deflate per board section' };
    const mt = Buffer.from(JSON.stringify(meta), 'utf8'), digest = crypto.createHash('sha256').update(mt).digest();
    const head = Buffer.alloc(12); Buffer.from(MAGIC).copy(head, 0); head.writeUInt32LE(VERSION, 4); head.writeUInt32LE(mt.length, 8);
    return new Uint8Array(Buffer.concat([head, mt, digest, ...parts]));
  }

  /** Read-only game over a linked record. averageAt answers bit-for-bit like the trained study; view() gives the geometry
   *  (any legal card at a chance node: the betting geometry is card-independent and was verified at export). */
  class LinkedGame {
    constructor(meta, body, o) {
      this.meta = meta; this.body = body; this.byPath = new Map(meta.nodes.map((n) => [n.p, n])); this.cacheBytes = o.cacheBytes === undefined ? 32 << 20 : o.cacheBytes;
      this.cache = new Map(); this.cacheUsed = 0; this.counters = { sectionLoads: 0, hits: 0, evictions: 0, bytesInflated: 0 };
      this.sectionIndex = new Map(meta.sections.map((s, i) => [s.board.join('.'), i]));
      this.rowIndex = meta.hands.map((rows) => new Map(rows.map((r, i) => [r[0], i])));
      // per street: node path -> offset of its block inside the section
      this.layout = {}; for (const [len, paths] of Object.entries(meta.streets)) { let w = 0; const m = new Map(); for (const p of paths) { const n = this.byPath.get(p); m.set(p, w); w += n.k * meta.hands[n.seat].length; } this.layout[len] = m; }
      this.verified = !!o.verify;
    }
    get iterations() { return this.meta.iterations; }
    _section(suffix) {
      const i = this.sectionIndex.get(suffix); if (i === undefined) return null;
      const hit = this.cache.get(i); if (hit) { this.counters.hits++; this.cache.delete(i); this.cache.set(i, hit); return hit; }
      const s = this.meta.sections[i], z = this.body.subarray(s.offset, s.offset + s.length);
      if (sha(z) !== s.sha256) throw new LinkedError('checksum', 'Linked section ' + (suffix || 'root') + ' is corrupt');
      const buf = zlib.inflateRawSync(z); ok(buf.length === s.values * 8, 'size', 'Linked section has the wrong size');
      const arr = new Float64Array(buf.buffer, buf.byteOffset, s.values); this.counters.sectionLoads++; this.counters.bytesInflated += buf.length;
      while (this.cacheUsed + buf.length > this.cacheBytes && this.cache.size) { const [k0, v0] = this.cache.entries().next().value; this.cache.delete(k0); this.cacheUsed -= v0.byteLength; this.counters.evictions++; }
      if (buf.length <= this.cacheBytes) { this.cache.set(i, arr); this.cacheUsed += buf.length; }
      return arr;
    }
    averageAt(path, board, seat, h) {
      const n = this.byPath.get(path); if (!n || n.kind !== 'player' || n.seat !== seat) return null;
      const b0 = this.meta.startBoard.length; if (!Array.isArray(board) || board.length !== n.street) return null;
      for (let i = 0; i < b0; i++) if (board[i] !== this.meta.startBoard[i]) return null;
      const arr = this._section(board.slice(b0).join('.')); if (!arr) return null;
      const ri = this.rowIndex[seat].get(h.id); if (ri === undefined) return null;
      const off = this.layout[n.street].get(path) + ri * n.k; if (Number.isNaN(arr[off])) return null;
      return Float64Array.from(arr.subarray(off, off + n.k));
    }
    view(steps) {
      let path = 'r'; for (const s of steps) path += typeof s === 'object' ? 'c' : String(s);
      const n = this.byPath.get(path); if (!n) return { kind: 'outside-record' };
      if (n.kind === 'player') return { kind: 'player', seat: n.seat, pot: n.pot, behind: n.behind, live: n.live, actions: n.labels.map((label) => ({ label })) };
      return { kind: n.kind, pot: n.pot, behind: n.behind, live: n.live };
    }
    /** Share of stored rows among possible rows, by street (impossible = hand collides with the board). */
    coverage() { const c = this.meta.counts, possible = c.storedRows + c.missingRows; return { storedRows: c.storedRows, missingRows: c.missingRows, share: possible ? c.storedRows / possible : null, complete: c.missingRows === 0 }; }
    prepared() { return { game: this, spec: { hands: this.meta.hands, board: this.meta.startBoard }, options: { config: null } }; }
    stats() { return { sections: this.meta.sections.length, cacheBytes: this.cacheBytes, cacheUsed: this.cacheUsed, cachedSections: this.cache.size, ...this.counters }; }
  }

  function open(bytes, o = {}) {
    ok(bytes && bytes.length >= 12 && MAGIC.every((m, i) => bytes[i] === m), 'bad-magic', 'Not a linked study record');
    const buf = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength), version = buf.readUInt32LE(4), ml = buf.readUInt32LE(8);
    ok(version === VERSION, 'version', 'Unsupported linked record version ' + version); ok(12 + ml <= buf.length, 'truncated', 'Linked record metadata truncated');
    let meta; try { meta = JSON.parse(buf.subarray(12, 12 + ml).toString('utf8')); } catch (e) { throw new LinkedError('bad-meta', 'Linked record metadata is not JSON'); }
    ok(meta.format === 'eightmax-linked-study', 'bad-meta', 'Wrong record format');
    ok(12 + ml + 32 <= buf.length && crypto.createHash('sha256').update(buf.subarray(12, 12 + ml)).digest().equals(buf.subarray(12 + ml, 12 + ml + 32)), 'checksum', 'Linked record metadata checksum mismatch');
    const body = buf.subarray(12 + ml + 32), last = meta.sections[meta.sections.length - 1];
    ok(!last || last.offset + last.length === body.length, 'truncated', 'Linked record body size does not match its section index');
    if (o.verify !== false) for (const s of meta.sections) ok(sha(body.subarray(s.offset, s.offset + s.length)) === s.sha256, 'checksum', 'Linked section ' + (s.board.join('.') || 'root') + ' is corrupt');
    return new LinkedGame(meta, body, { ...o, verify: o.verify !== false });
  }
  return { VERSION, exportLinked, open, LinkedGame, LinkedError };
});
