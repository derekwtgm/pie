'use strict';
/* EightMax Test Workbench 0.30: strategy library command-line tool (run with RUN-TOOL.cmd on Windows, or STRATEGY-LIBRARY.cmd).
 *
 *   status    [--lib=DIR]                         library contents, storage, cache, pending misses -> status.json
 *   verify    [--lib=DIR]                         full checksum / identity / decode check of every record
 *   recover   [--lib=DIR]                         remove interrupted writes, rebuild the catalogue
 *   misses    [--lib=DIR] [--top=20]              most frequent situations that had no strategy
 *   precompute [--lib=DIR] [--from-misses=200] [--concurrency=N] [--memory=512] [--max-jobs=N] [--minutes=M]
 *                                                 train queued situations (resumes interrupted jobs); Ctrl+C stops safely
 *   catalog   [--lib=DIR] --players=2 --pot=6.3 --stacks=21.85,21.85 [--street=flop] [--limit=N] [--priority=1]
 *                                                 queue every suit-canonical flop (1,755) for one configuration
 *   simulate  [--lib=DIR] [--hands=200] [--seed=N] [--ranges=derived|any-two]  play simulated hands in Decision Mode to record which situations occur
 *   export    [--lib=DIR] --out=FILE [--street=flop]   portable bundle (.emslb)
 *   import    [--lib=DIR] --in=FILE                 verify and add a bundle
 *   cancel    [--lib=DIR] --job=FINGERPRINT|all
 * 0.31:
 *   quality   [--lib=DIR] [--policy=research|strict|exploratory] [--limit=N]
 *                                                 exact evaluation of every river record (exploitability / NashConv), classification,
 *                                                 ledger entries, quality-summary.json for the dashboard ("Validate Strategies")
 *   refine    [--lib=DIR] [--policy=..] [--max-jobs=N] [--minutes=M]
 *                                                 "Continue Training": quality-targeted records that are not validated get more training
 *   common    [--lib=DIR] [--hands=300] [--flop-configs=2] [--minutes=60]
 *                                                 "Precompute Common Hands": record situations, then the flop catalogue of the most frequent
 *                                                 configurations and every turn / river seen, highest frequency first
 *   ranges    [--hands=40] [--seed=N] [--updates=2000000]
 *                                                 "View Opponent Ranges": simulated hands with derived ranges; writes ranges-latest.json
 * The default library is %LOCALAPPDATA%\EightMax-Test-Workbench\StrategyLibrary on Windows (~/.eightmax-workbench/StrategyLibrary elsewhere). */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const root = path.join(__dirname, '..');
const L = require(path.join(root, 'src/strategy-library.js')), LS = require(path.join(root, 'src/library-source.js')), SID = require(path.join(root, 'src/strategy-identity.js'));
const { PrecomputeQueue } = require(path.join(root, 'src/precompute.js'));

function defaultLib() { return process.platform === 'win32' && process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'EightMax-Test-Workbench', 'StrategyLibrary') : path.join(os.homedir(), '.eightmax-workbench', 'StrategyLibrary'); }
function cliPath() { if (process.env.EIGHTMAX_TEST_CLI && fs.existsSync(process.env.EIGHTMAX_TEST_CLI)) return process.env.EIGHTMAX_TEST_CLI; const exe = path.join(root, 'native', 'mwcli.exe'); return process.platform === 'win32' && fs.existsSync(exe) ? exe : null; }
/** All 1,755 suit-canonical flops (each listed once). */
function canonicalFlops() { const set = new Set(); for (let a = 0; a < 52; a++) for (let b = a + 1; b < 52; b++) for (let c = b + 1; c < 52; c++) set.add(SID.canonicalBoard([a, b, c], true).board); return [...set].sort(); }
function writeStatus(lib, extra) { const st = { ...lib.status(), ...extra, writtenAt: new Date().toISOString() }; L.writeFileAtomic(path.join(lib.dir, 'status.json'), JSON.stringify(st, null, 1)); return st; }

async function main(argv) {
  const cmd = argv[0] || 'status', a = Object.fromEntries(argv.slice(1).map((x) => x.replace(/^--/, '').split('=')).map(([k, v]) => [k, v === undefined ? true : v]));
  const dir = a.lib || process.env.EIGHTMAX_STRATEGY_LIBRARY || defaultLib(), out = (x) => { process.stdout.write(JSON.stringify(x, null, 1) + '\n'); return x; };
  const lib = L.StrategyLibrary.open(dir, { cacheBytes: 64 << 20 });
  switch (cmd) {
    case 'status': return out(writeStatus(lib, { recovery: lib.lastRecovery }));
    case 'verify': { const r = lib.verifyAll(); writeStatus(lib, { lastVerify: r }); return out(r); }
    case 'recover': return out(lib.recover());
    case 'misses': { const s = lib.missSummary(+(a.top || 20)); return out({ distinct: s.distinct, damagedLines: s.damagedLines, top: s.list.map((m) => ({ fingerprint: m.fingerprint, count: m.count, situation: SID.describe(m.identity) })) }); }
    case 'list': return out(lib.list().map((e) => ({ fingerprint: e.fingerprint, situation: e.describe, bytes: e.bytes, convergence: e.convergence })));
    case 'cancel': { const q = new PrecomputeQueue({ library: lib }); q.pause(); const n = a.job === 'all' || a.job === true ? q.cancelAll() : +q.cancel(String(a.job)); q.close(); return out({ cancelled: n }); }
    case 'export': { if (!a.out) throw new Error('--out=FILE is required'); return out(lib.exportBundle(String(a.out), (e) => !a.street || e.street === a.street)); }
    case 'import': { if (!a.in) throw new Error('--in=FILE is required'); const r = lib.importBundle(String(a.in)); writeStatus(lib); return out(r); }
    case 'catalog': {
      const stacks = String(a.stacks || '').split(',').filter(Boolean).map(Number), pot = +a.pot; if (!stacks.length || !(pot > 0)) throw new Error('--stacks=a,b,.. and --pot=X (bb) are required');
      if (stacks.length !== +(a.players || stacks.length)) throw new Error('--players does not match --stacks');
      const q = new PrecomputeQueue({ library: lib }); q.pause(); const flops = canonicalFlops().slice(0, a.limit ? +a.limit : undefined); let queued = 0, stored = 0;
      for (const f of flops) { const b = LS.spotFromParams({ street: 'flop', board: f.match(/../g), stacksBehind: stacks, pot, iterations: a.iterations ? +a.iterations : undefined }, a.iterations ? { iterations: +a.iterations } : {}); const r = q.enqueue(b.spot, { priority: +(a.priority || 1), reason: 'flop catalogue ' + stacks.length + ' players pot ' + pot }); if (r.status === 'already-stored') stored++; else queued++; }
      q.close(); return out({ flops: flops.length, queued, alreadyStored: stored });
    }
    case 'simulate': {
      const EM = require(path.join(root, 'src/engine.js')), FH = require(path.join(root, 'src/full-hand.js'));
      // 0.31: derived opponent ranges by default (--ranges=any-two for the 0.30 model); the preflop study they need is trained to 2,000,000
      // updates by default (reports/0.31-range-support.json: 500,000 updates left most derived ranges insufficiently supported).
      const ranges = a.ranges || 'derived', src = await require(path.join(root, 'tools/solver-factory.cjs')).createSource({ kind: 'preflop-linked', cli: cliPath(), updates: +(a.updates || (ranges === 'derived' ? 2000000 : 250000)), budgetMiB: 2048, cacheDir: a.cache || path.join(dir, '..', 'StudyCache'), library: { dir, mode: 'decision', rangeModel: ranges, adaptive: a.adaptive !== 'false' } });
      const seed = +(a.seed || 1), p = new FH.SingleTablePipeline({ tableId: 1, client: new FH.OfflineClient(new EM.Table(1, seed + 139)), vision: FH.makeVision(1), decisionSource: src, allowScripted: true, seed: seed + 1, stopOnSuspend: false });
      const rep = await p.run(+(a.hands || 200)); src.library.flushMisses();
      return out({ handsCompleted: rep.completed, attribution: rep.attribution, library: { ok: src.librarySource.stats.ok, misses: src.librarySource.stats.misses }, pendingMisses: lib.missSummary(0).distinct });
    }
    case 'precompute': {
      const cli = cliPath(), plan = L.planResources({ maxTrainingJobs: a.concurrency ? +a.concurrency : undefined });
      const q = new PrecomputeQueue({ library: lib, cli, concurrency: a.concurrency ? +a.concurrency : Math.max(1, plan.trainingJobs), memoryMiB: +(a.memory || 512), reserveMiB: +(a.reserve || 2048), workerThreads: a['worker-threads'] !== 'false' });
      if (a['from-misses']) out({ planned: q.planFromMisses(+a['from-misses']) });
      let n = 0; const max = a['max-jobs'] ? +a['max-jobs'] : Infinity, deadline = a.minutes ? Date.now() + +a.minutes * 60000 : Infinity;
      const stop = () => { process.stderr.write('Stopping: running jobs are checkpointed and will resume next time.\n'); q.close(); };
      process.on('SIGINT', stop); process.on('SIGTERM', stop);
      q.on((ev) => { if (['complete', 'failed', 'memory-limited', 'cancelled', 'interrupted'].includes(ev.type)) { n++; process.stderr.write('[' + new Date().toISOString().slice(11, 19) + '] ' + ev.type + ' ' + ev.job.fingerprint.slice(0, 12) + ' ' + ev.job.street + ' ' + ev.job.players + 'p' + (ev.job.training ? ' ' + ev.job.training.trainMs + ' ms' : '') + (ev.job.error ? ' ' + ev.job.error.message : '') + '\n'); if (n >= max || Date.now() > deadline) q.pause(); if (n % 5 === 0) writeStatus(lib, { precompute: q.status(), resources: plan }); } });
      if (!cli) process.stderr.write('Native engine not found: training uses the slower JavaScript reference engine.\n');
      writeStatus(lib, { precompute: q.status(), resources: plan }); q.start(); await q.drain(); const st = q.status(); q.close(); writeStatus(lib, { precompute: st, resources: plan }); return out({ resources: plan, precompute: st });
    }
    case 'quality': {
      const Q = require(path.join(root, 'src/strategy-quality.js')), led = new Q.QualityLedger(dir), policy = a.policy || 'research', rows = []; let n = 0;
      for (const e of lib.list()) { if (a.limit && n >= +a.limit) break; n++; let doc; try { doc = e.street === 'river' ? Q.evaluateRecord(lib, e.fingerprint, { policy, ledger: led }) : null; } catch (err) { doc = null; }
        const h = L.decodeRecord(fs.readFileSync(lib.file(e.fingerprint)), e.fingerprint).header, q = Q.qualityOf(h, led, policy);
        rows.push({ fingerprint: e.fingerprint, situation: e.describe, street: e.street, players: e.players, rangeModel: e.rangeModel, solver: h.identity.engine.version + ' ' + h.identity.engine.build, trainer: h.training && (h.training.trainer || h.training.backend), updates: h.training && h.training.iterations, status: q.status, label: Q.LABELS[q.status], measurePctPot: q.measurePctPot, measureKind: q.evaluation ? (q.evaluation.players === 2 ? 'exploitability' : 'NashConv') : null, evaluatedAt: q.evaluatedAt || null, reason: q.reason }); }
      const by = rows.reduce((m, r) => { m[r.status] = (m[r.status] || 0) + 1; return m; }, {});
      const sum = { format: 'eightmax-strategy-quality-summary', version: 1, available: true, writtenAt: new Date().toISOString(), policy: Q.policySummary(Q.policyOf(policy)), records: rows.length, byStatus: by, labels: Q.LABELS, rows: rows.slice(0, 2000),
        note: 'Rivers are evaluated exactly (heads-up exploitability, multiway NashConv). Flop and turn records stay unverified: their later streets are not stored, so they cannot be evaluated from the record.' };
      L.writeFileAtomic(path.join(dir, 'quality-summary.json'), JSON.stringify(sum, null, 1)); writeStatus(lib); return out({ records: rows.length, byStatus: by, policy });
    }
    case 'refine': {
      const Q = require(path.join(root, 'src/strategy-quality.js')), led = new Q.QualityLedger(dir), policy = a.policy || 'research', cli = cliPath();
      const q = new PrecomputeQueue({ library: lib, cli, concurrency: Math.max(1, L.planResources().trainingJobs), workerThreads: true, keepCheckpoints: true, qualityPolicy: policy }); let queued = 0, skipped = 0;
      for (const e of lib.list()) { const h = L.decodeRecord(fs.readFileSync(lib.file(e.fingerprint)), e.fingerprint).header; if (!h.identity.training || h.identity.training.mode !== 'quality-target-v1') { skipped++; continue; } const st = Q.qualityOf(h, led, policy).status; if (st === 'validated') continue; q.enqueueRefinement(e.fingerprint); queued++; }
      const deadline = a.minutes ? Date.now() + +a.minutes * 60000 : Infinity; q.on(() => { if (Date.now() > deadline) q.pause(); }); q.start(); await q.drain(); const st = q.status(); q.close(); writeStatus(lib);
      return out({ queuedForRefinement: queued, fixedCountRecordsSkipped: skipped, note: 'Fixed-count records (0.30 identity) cannot be refined in place; train them as quality-targeted studies instead.', precompute: st.stats || st });
    }
    case 'common': {
      const cp = require('node:child_process'), cli = cliPath(); if (!cli) throw new Error('The native engine (native\\mwcli.exe) is required');
      const r = cp.spawnSync(process.execPath, [path.join(__dirname, 'coverage-031.cjs'), '--train-seeds=' + (a.seeds || '11,12,13'), '--test-seeds=' + (a['test-seeds'] || '901'), '--hands=' + (a.hands || 100), '--tables=' + (a.tables || 4), '--flop-configs=' + (a['flop-configs'] || 2), '--budget-min=' + (a.minutes || 60), '--work=' + path.join(dir, '..', 'Coverage'), '--out=' + path.join(dir, '..', 'Coverage', 'coverage-report.json')], { stdio: 'inherit', env: { ...process.env, EIGHTMAX_TEST_CLI: cli } });
      return out({ exit: r.status, report: path.join(dir, '..', 'Coverage', 'coverage-report.json'), note: 'The catalogue is built in its own library folder (Coverage\\library); import it with IMPORT-STRATEGIES after reviewing the report.' });
    }
    case 'ranges': {
      const EM = require(path.join(root, 'src/engine.js')), FH = require(path.join(root, 'src/full-hand.js')), cli = cliPath();
      const src = await require(path.join(root, 'tools/solver-factory.cjs')).createSource({ kind: 'preflop-linked', cli, updates: +(a.updates || 2000000), budgetMiB: 2048, cacheDir: a.cache || path.join(dir, '..', 'StudyCache'), library: { dir, mode: 'decision', rangeModel: 'derived', adaptive: true, inlineHeadsUpRiver: true } });
      const seed = +(a.seed || 1), p = new FH.SingleTablePipeline({ tableId: 1, client: new FH.OfflineClient(new EM.Table(1, seed + 139)), vision: FH.makeVision(1), decisionSource: src, allowScripted: true, seed: seed + 1, stopOnSuspend: false });
      const rep = await p.run(+(a.hands || 40)); src.library.flushMisses();
      const views = []; for (const k of src.rangeModel.trackers.keys()) { const [t, h] = k.split('|'); const v = src.rangeModel.view(+t, +h); if (v) views.push(v); }
      const doc = { format: 'eightmax-range-views', version: 1, available: true, writtenAt: new Date().toISOString(), handsPlayed: rep.completed, model: src.rangeModel.info(), hands: views.slice(-25),
        disclosure: 'Ranges are derived from the betting assuming every player follows the stored strategies (preflop study: not validated). They are estimates of strategic ranges, NOT knowledge of anybody\'s hidden cards.' };
      const parent = path.dirname(path.resolve(dir)), file = path.join(parent === path.parse(parent).root ? dir : parent, 'ranges-latest.json'); if (!fs.existsSync(path.dirname(file))) fs.mkdirSync(path.dirname(file), { recursive: true });   // 0.33: a library at a drive root (C:\em-lib) made this mkdir('C:\') fail with EPERM on Windows CI L.writeFileAtomic(file, JSON.stringify(doc)); return out({ handsPlayed: rep.completed, handsWithRanges: views.length, file, model: doc.model });
    }
    default: throw new Error('Unknown command ' + cmd);
  }
}
module.exports = { main, canonicalFlops, defaultLib };
if (require.main === module) main(process.argv.slice(2)).then(() => process.exit(0), (e) => { process.stderr.write('ERROR: ' + e.message + '\n'); process.exit(1); });
