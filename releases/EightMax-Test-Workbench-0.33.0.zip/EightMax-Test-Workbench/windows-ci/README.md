# Windows CI for 0.33.0

The 0.33.0 Windows files were **built and tested on a GitHub-hosted Windows x64 runner** (repository `derekwtgm/pie`,
branch `claude/workbench-0.33.0-release`). A hosted runner is Windows Server 2025 with no GPU and a 1024 x 768 virtual display at
100 % scaling: it is **not** the target PC (Windows 11, i7-13700F, RTX 4060 Ti, 3840 x 2160 at 150 %).

Two stages, both publishing their logs and outputs to the branch `claude/workbench-0.33.0-ci-results` (readable without an Actions token):

1. **Build stage** (`.github/workflows/workbench-windows-build.yml`, `workbench-ci/build.ps1`): compiles `EightMaxWorkbench.exe` and
   `EightMaxCapture.exe` with the .NET Framework C# compiler and `EightMaxWgc.exe` with the .NET 8 SDK from the shipped sources
   (`windows/Build-Executables.ps1`), then runs the capture and WGC self-tests. Run 44531610774: build succeeded, capture self-test
   8/8 PASS, WGC self-test 13/13 PASS. The executables in this release are exactly those files (`evidence/build-evidence.json`).
2. **Validation stage** (`.github/workflows/workbench-windows.yml`, `workbench-ci/ci.ps1`): extracts the exact release ZIP, verifies its
   checksum, runs the release acceptance with install/uninstall, the strategy library, the 0.32 and 0.33 research tools and the whole Node
   regression suite with the bundled runtime. Run 44575197928 (candidate ZIP ecfd20e4…): release acceptance 81/81 PASS, Node suite
   848 tests / 822 pass / 0 fail / 26 skipped; `ranges` and the quick long-duration run did not pass in runs 44575197928 and 44581998216 - causes
   traced and fixed, see docs/0.33-validation-report.md section K. See `evidence/windows-ci-runs.json` for the runs and what each one observed.

`desktop/COMPONENT-VERSIONS.json` is generated from that evidence: a status is true only when a record names the exact SHA-256 of the file.
