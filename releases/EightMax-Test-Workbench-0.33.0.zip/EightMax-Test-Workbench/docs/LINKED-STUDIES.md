# Linked flop-to-river studies (0.32)

## Why
A library record (0.30/0.31) is a **street snapshot**: the average strategy of the street the study starts on. The EightMax engine
trains the whole tree from that street to the river (the workbench uses exact private-hand keys, so every turn and river row is keyed by
the real board), but the snapshot discarded those rows. A flop or turn strategy's value depends on how play continues, so 0.31 could
not evaluate flop or turn records and the quality gate refused them as *unverified*.

## What 0.32 stores
`src/linked-study.js` exports a **linked record** (`.emlk`, format `eightmax-linked-study` v1) next to the street record:

* meta: start board and street, range rows, iterations, the complete betting geometry of every street (decision nodes with seat, pot,
  stacks behind, live flags and menu labels; chance nodes; terminal contributions), parent-child links (`'c'` in a path = a dealt
  card), the street-record fingerprint it belongs to, counts (stored / missing / impossible rows) and a section index;
* one **section per public board** (start board, each turn card, each turn+river pair reached), each holding k doubles per range row
  for every decision node of that street, *NaN in slot 0 = the information set was never visited*. Values are the IEEE-754 doubles
  returned by the engine's `averageAt`, copied, never rounded (lossless);
* integrity: SHA-256 of the meta bytes and of every section; corruption is refused (`checksum`, `truncated`, `bad-magic`).

Sections are raw-deflated separately and inflated **on demand** through a byte-bounded LRU cache, so a decision on one runout loads
only that runout; the whole record never has to be in memory.

## Continuity and identity
`StrategyLibrary.putLinked(fp, bytes)` stores a linked record only if (1) the street record exists, (2) the linked record names the
same fingerprint, and (3) **its first street reproduces the street record bit for bit** at every node and hand (a linked record from a
different training run is refused with `continuity`). A refinement that replaces a street record moves the old linked record to
`superseded/` with it.

## Compatibility and migration
0.30/0.31 records are unchanged and keep working. Without a linked record a flop/turn record stays *unverified* (reason names the
missing continuation). There is no way to recover continuation strategies from an old snapshot (they were never stored); the migration
path is **retraining**: identities derive their seed from the identity, and native training is deterministic (checked in
`tests/preflop-032`), so retraining a fixed-count record reproduces its street record exactly and `putLinked`'s continuity check proves
it. New training stores linked records when `storeLinked` (decision path) or `linked: true` (`trainSpot`) is set; quality-targeted
heads-up turn training (`adaptive-training.js`) always exports one.

## Evaluation (src/fast-multistreet.js)
Exact, independent of the engine: own seven-card evaluator, own payouts from the tree geometry, own best response. Heads-up only.
Every turn and river card is enumerated; for any compatible pair of hands the number of next cards is the same (48 − |board|), so each
card has weight 1/(48 − |board|); hands containing a dealt card are removed below it; an all-in before the river is averaged over every
runout (precomputed runout-equity matrices, equal to the enumeration to 1e-15). Checked against an independent scalar brute-force
enumeration in `tests/multistreet-032` (equal to 1e-9) and against the 0.31 river evaluator on river boards.

Quality classification (`src/strategy-quality.js`):

| Linked evaluation | Status |
|---|---|
| exact, every continuation row stored, within the policy limit | validated |
| exact, every continuation row stored, above the limit | failed-quality-check |
| exact, but some continuation information sets never visited (filled with uniform play for the evaluation) | **unverified** (`partialEvaluation`, the number and share of missing rows in the reason) |
| multiway (no independent multi-street evaluator yet) | unverified |

A sampled MCCFR flop study at 20,000 updates leaves most river information sets unvisited (measured: 4% of possible river rows
stored for a narrow-range heads-up flop study), so such flop records are evaluated but stay unverified. The exact turn solver
(`docs/TURN-SOLVER.md`) produces complete continuations by construction.
