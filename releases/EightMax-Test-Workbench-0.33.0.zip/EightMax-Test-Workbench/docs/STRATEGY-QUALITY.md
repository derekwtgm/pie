# Strategy quality (0.31)

A finished training job is **not** a converged strategy. 0.31 makes accuracy an explicit, stored, checkable property of every
strategy and lets the decision engine refuse strategies that do not meet a chosen target.

## Classifications (`src/strategy-quality.js`)

| Status | Meaning | Default use |
|---|---|---|
| `validated` | An **exact** evaluation of the specific stored game meets the policy threshold | decisions and simulation |
| `estimated` | Sampled measurement with a 95 % interval | simulation experiments (research policy) |
| `restricted-evaluation` | Evaluated only against limited responses or inside an abstraction | not used by the research policy |
| `unverified` | Not enough evidence (flop/turn street snapshots; any record never evaluated) | labelled simulation experiments only |
| `failed-quality-check` | An evaluation shows the target is not met | refused |

Nothing is ever promoted automatically: a status comes only from `classify(evaluation, policy)`.

## What can be measured

* **Heads-up rivers** — exact exploitability (constant-sum; `exploitability = NashConv / 2`), with `src/fast-river.js`
  (vectorised: sorted showdowns, inclusion–exclusion card removal). It agrees with the independent per-deal evaluator of 0.30
  (`src/exploitability.js`) to 4·10⁻¹¹ bb on every tested game and is ~100× faster (any-two-cards river: 7.4 s → 71 ms).
* **Rivers with 3–6 players** — exact **NashConv** (sum of unilateral best-response gains). This is a different measure: a low
  NashConv is not safety against coalitions, equilibria are not unique. Multiway records use the multiway threshold, never the
  heads-up one.
* **Flops and turns** — a street snapshot stores only that street; later streets are trained inside the study but not stored, so
  the stored record cannot be evaluated. These stay `unverified`. Strategy *stability* between training blocks is recorded and
  labelled "not an accuracy measurement".

## Policies

| Policy | Heads-up limit (exploitability) | Multiway limit (NashConv) | Decision use accepts | Simulation experiments accept |
|---|---|---|---|---|
| `strict` | 0.5 % of pot | 1.0 % | validated | validated |
| `research` (default) | 1.0 % of pot | 2.5 % | validated | validated, estimated, unverified |
| `exploratory` | 5 % of pot | 10 % | validated, estimated | all but failed |
| `off` | — | — | everything (0.30 behaviour) | everything |

Custom policies: `{ base: 'research', headsUp: { maxExploitabilityPctPot: 0.75, maxExploitabilityBB: 0.05 }, multiway: { maxNashConvPctPot: 2 } }`.
The decision source takes `qualityPolicy` and `qualityUse` (`'decision'` for Authorized QA execution, `'simulation-experiment'`
for the simulator). A refused strategy returns `status: 'unavailable', code: 'quality-gate'` with the reason; no probabilities.
Every accepted decision carries `quality` (status, label, measured % of pot, source, policy) and `strategyConfidence`.

## Stored metadata

Records stay immutable. Quality lives (a) in the record header when it was measured at training time and (b) in the **quality
ledger** `<library>/quality/<fp>.json` for later evaluations. Each ledger entry names the record's raw payload SHA-256; an
entry for other bytes is ignored. The status is **re-classified** under the policy in force, so changing the policy changes the
gate result reproducibly. Stored fields: solver/engine build, trainer and algorithm, updates actually used, game (street,
players, board, pot, stacks, range model, abstraction), evaluation type and method, exploitability or NashConv, values,
confidence interval where sampled, stability, convergence curve, evaluation date, policy, status, reason, limitations.

## Quality-targeted ("adaptive") training (`src/adaptive-training.js`)

1. train an initial block (20,000 updates); 2. export the snapshot and evaluate **the bytes that will be stored**;
3. stop if the measure is below `targetMargin × limit` (default 0.8); 4. otherwise double the updates (checkpointed native
state, resumable); 5. stop at the update / time limit, when improvement stalls (two blocks with < 8 % gain) or when the export
budget is reached; 6. store with the quality document.

Trainers: `vector-cfr-plus` (heads-up rivers; full-width CFR+, no sampling), `eightmax-native` (EightMax 5.1 mwcli, the 0.30
default variant), `eightmax-js`. Measured (reports/0.31-math-validation.json, section C):

| Situation | 0.30 fixed 20,000 updates | 0.31 vector CFR+ | 0.31 EightMax adaptive |
|---|---|---|---|
| HU river, any-two-cards, pot 6 | 1.72 bb (28.7 % pot) **failed** | 0.029 bb (0.48 %) validated, 0.44 s | 0.053 bb (0.88 %) validated, 2.56 M updates, 5.6 s |
| HU river, medium ranges, pot 5.5 | 0.69 bb (12.5 %) **failed** | 0.035 bb (0.64 %) validated, 0.16 s | 0.043 bb (0.79 %) validated, 1.28 M, 2.3 s |
| 3-way river, pot 9 | NashConv 0.86 bb (9.6 %) **failed** | — | NashConv validated, 640 k updates, 31 s |

The identity of a quality-targeted study records the *training policy* (mode, trainer, target), not an update count, so
**Continue Training** (`CONTINUE-TRAINING.cmd`, `PrecomputeQueue.enqueueRefinement`) can continue a stored study from its kept
checkpoint and replace the record only when the new exact measurement is better (the old bytes are kept in `superseded/`).
0.30 records (fixed counts) keep their identity and remain usable; they are refined by training a quality-targeted study.

## Trainer variants (reports/0.31-training-variants.json)

EightMax 5.1 supports four external-sampling MCCFR variants. Exact exploitability at 400,000 updates, three seeds, four games:
the 0.30 default (standard regret matching, linear averaging) is lowest in every game — e.g. any-two-cards river 0.179 bb vs
uniform 0.233, DCFR 0.553, RM+ 0.908. RM+ and DCFR are significantly worse (non-overlapping 95 % intervals) at 100,000 and
400,000 updates in all four games; uniform weighting is significantly worse in three games and statistically indistinguishable
in the narrow-range game. No variant is significantly better than the default at any measured count.
**The default variant is therefore unchanged.** The improvement came from training long enough (and, for heads-up rivers,
from full-width CFR+), not from changing the sampled algorithm.

## 0.32: flop and turn records with linked continuations
`evaluateLinked()` evaluates a flop or turn record over the whole linked game to the river (heads-up; `docs/LINKED-STUDIES.md`).
`evaluateRecord()` uses it automatically when the library holds a linked record for the fingerprint. A linked evaluation with any
unvisited continuation information set is **never validated** (status unverified, `partialEvaluation: true`, missing-row count in the
reason), and multiway linked records stay unverified. Previously unverified 0.31 records are not promoted: they gain a status only
after a linked record that reproduces them exactly has been stored and evaluated.
