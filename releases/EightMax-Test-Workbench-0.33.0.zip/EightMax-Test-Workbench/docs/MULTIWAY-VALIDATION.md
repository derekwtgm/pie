# Independent multiway evaluation (0.33)

`src/independent-eval.js` evaluates small 2–4 player poker games **without using the EightMax engine or the workbench solvers**.
It shares only the input data with them: the board, stacks and pot, the weighted two-card ranges, the stated betting rules and the
strategy probabilities. Everything else is written from the rules in this module:

| Part | Implementation |
|---|---|
| Betting rules | own legal-action generator (check/bet, fold/call/raise, pot-fraction, multiple and all-in sizes, raise caps, minimum raise, re-opening rule, short stacks) |
| Money | own side-pot settlement (layers by contribution, folded chips stay in their layer, uncalled excess returned, common money in the main pot, ties split) |
| Hands | own 7-card evaluator (category + kickers) |
| Chance | every turn/river card enumerated; a card held by any player is removed for that deal (exact card removal); weight 1 / (cards left) |
| Strategy | read from the native state file by its own reader (`readNativeRows`), or from any `strategy(seat, node, board, type)` |
| Best response | per own private type, one recursion over the public tree carrying all opponent-type tuples (prior × opponents' reach × chance); the best response takes the maximum at the player's own information sets (perfect recall: exact) |
| Measures | value of each player, best-response value, gain = BR − value, **NashConv = Σ gains** |

Classification: `exact` (complete game, double precision). Information sets the strategy never stored are played uniformly and
**counted**; such a result is labelled "exact evaluation of an INCOMPLETE strategy" and is never validated.

**What NashConv means here.** With three or more players NashConv is not an exploitability. NashConv = 0 means no player can gain by
changing only its own strategy (a Nash equilibrium, inside the stated betting abstraction). Multiplayer equilibria are not unique, a
Nash equilibrium is not safe against cooperating opponents, and a restricted game says nothing about the full eight-handed game.
The two-player formula exploitability = NashConv / 2 is used **only** for two-player constant-sum games.

## Analytic reference games (`tools/multiway-validation-033.cjs`, `reports/0.33-multiway-validation.json`)

| Game | Expected (derived by hand / literature) | Measured |
|---|---|---|
| 2-player Kuhn, equilibrium family α = 0, 0.2, 1/3 | value of player 1 = −1/18, NashConv = 0 | −0.0555… (error < 1e-15), NashConv 0 (≤ 8e-17) |
| 3-player Kuhn, everyone checks and folds to a bet | each seat gains exactly 2 by always betting: NashConv = 6 | gains [2, 2, 2], NashConv 6 |
| 3-player hold'em river (pot 6), everyone checks and folds to a bet | each seat's best response wins the pot: NashConv = 2 × pot = 12, values sum to the pot | 12, value sum 6 |
| 3-player Kuhn, independent vanilla CFR 100 / 1,000 / 5,000 iterations | NashConv decreasing (convergence evidence, not an analytic value) | 0.0895 → 0.0166 → 0.0049 |

Further checks in `tests/multiway-033.test.cjs`: side-pot settlement against hand-worked cases and against `exploitability.payoff` on
300 random legal terminals (chips conserved), the 7-card evaluator against two other evaluators on 1,500 random deals, the betting
rules against the EightMax tree node by node (3-player turn game; 3-player river with raise multiples and a short stack).

## Engine cross-check: the 0.32 three-player turn game

Game: turn AhKd7c2s, pot 6 bb, 12 bb behind each, all three ranges AA,KK,77,AK,KQs,T9s, turn and river: check or bet 50 % of the
pot, one bet per street, chip EV. Trained by the EightMax 5.1 engine (seed 3), then evaluated twice: by the engine's own exact best
response (`mwcli --gain method=exact`, engine-internal) and by the independent evaluator.

| Updates | Independent NashConv (% of pot) | Engine NashConv (% of pot) | Largest gain difference | Unvisited rows (played uniformly) | Geometry / reconstruction |
|---|---|---|---|---|---|
| 20,000 | 60.750 | 60.750 | 0 | 36,545 | 179 nodes, 0 differences / 5,000 rows, max difference 0 |
| 80,000 | 27.662 | 27.662 | 2.2e-16 bb | 16,080 | same |
| 320,000 | 13.725 | 13.725 | 2.2e-16 bb | 4,085 | same |
| 1,280,000 | 7.519 | 7.519 | 1.7e-16 bb | 770 | same |

The independent evaluation agrees with the engine to rounding at every training length (and reproduces the 0.32 report: 60.75 /
27.66 / 13.73 / 7.5 %). The strategy is still **above the 2.5 % research limit** and still has unvisited information sets, so these
multiway records stay **unverified**; nothing here establishes multiway accuracy beyond this restricted game.

## Multiway linked records

0.33 exports store the study's betting rules with each linked record. `strategy-quality.evaluateLinked` now evaluates 3–4 player
linked records with the independent evaluator (after checking that its own rules reproduce the stored tree exactly; otherwise the
record is refused) and classifies NashConv against the multiway limit. Records exported before 0.33 have no stored rules and remain
"no independent evaluation" — never reported as 0.
