// EightMax 5.17 (Phase 7, exact best response of heads-up postflop studies on the CPU and on a GPU).
//
//   The comparisons of the release (agreement with method exact on every game, bit identity across threads, batches
//   and devices, seconds) are validation/5.17; these tests cover what the release adds to the program:
//     - request method exact-hu (brhu-5.17-v1): agreement with method exact, one result for every thread count,
//       fallbacks, refusals; methods exact, restricted and sampled do not take its fields;
//     - one source for the CPU and the OpenCL path: the embedded kernel text is brhu_kernel.h, and the kernel keeps
//       its arithmetic rules;
//     - the OpenCL path, when the machine has an OpenCL device (EM_BRHU_ALLOW_CPU_DEVICE=1 lets a CPU
//       implementation stand in): the bits of the CPU, batch sizes, an altered result is found, the unprotected
//       kernel is refused if the device fuses;
//     - the games (tools/games517.js);
//     - the unchanged 5.16 program writes the same states and refuses the new method;
//     - mwcli --selftest517; the Windows validation script of 5.17, its launchers and the workflow.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
const build = require('./native_build');
const src = path.resolve(__dirname, '..'), root = path.resolve(src, '..'), studies = path.join(src, 'studies');
const g517 = require('../tools/games517.js');
const cli = () => process.env.EM_TEST_MWCLI || build.cli().cli;
const tmp = t => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em517-')); t.after(() => fs.rmSync(d, { recursive: true, force: true })); return d; };
const CL = { EM_BRHU_ALLOW_CPU_DEVICE: '1' };
const run = (args, env = {}, exe = null) => cp.spawnSync(exe || cli(), args.map(String), { encoding: 'utf8', timeout: 3600000, maxBuffer: 256 << 20, env: { ...process.env, ...env } });
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const fixture = id => JSON.parse(fs.readFileSync(path.join(studies, id + '.emfix.json'), 'utf8').replace(/^\ufeff/, ''));
const write = (dir, name, value) => { const f = path.join(dir, name); fs.writeFileSync(f, typeof value === 'string' ? value : JSON.stringify(value)); return f; };
const old516 = () => process.env.EM_TEST_MWCLI_516 || path.join(root, 'validation/5.16/linux-bin/mwcli');
const cases = path.join(root, 'validation/5.17/windows/brhu');
const CPU = ['cpu S1', 'cpu B1', 'cpu B2', 'cpu B3', 'cpu B4', 'cpu B5', 'cpu B6'], GPU = ['gpu G1', 'gpu G2', 'gpu G3', 'gpu G4', 'gpu G5', 'gpu G6'];
const gain = (dir, spec, state, request, env = {}) => { const r = run(['--gain', spec, state, write(dir, 'rq.json', request), 4096], env); let j = null; try { j = JSON.parse(r.stdout); } catch { /* an error text */ } return { r, j }; };
const HU = extra => ({ method: 'exact-hu', timeLimitMs: 3600000, memoryMiB: 4096, ...extra });
const bitsOf = j => j.seats.map(s => [s.policyValueBits, s.bestResponseValueBits, s.gainBits].join(' ')).join(' | ') + ' | ' + j.nashConvBits;
const near = (a, b) => assert.ok(Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(b)), a + ' against ' + b);
const device = () => { const r = run(['--opencl-info'], CL); try { return JSON.parse(r.stdout); } catch { return { usable: false, why: 'no answer' }; } };
const trained = (dir, key, grouping, deals) => { const spec = write(dir, key + '-' + grouping + '.json', g517.spec(key, grouping, 5171)), state = path.join(dir, key + '-' + grouping + '.state'); const r = run([spec, deals, 1, state, 1024], { EIGHTMAX_THREAD_CHOICE: 'fixed' }); assert.equal(r.status, 0, r.stderr); return { spec, state }; };

test('5.17 exact-hu: the values of method exact on river, turn and flop games, one result for every thread count, what the result names', { timeout: 3600000 }, t => {
  const dir = tmp(t);
  for (const [key, grouping] of [['rg-hu-river', 'exact'], ['ho-hu-river', 'compact'], ['rg-hu-turn', 'detailed'], ['ho-hu-turn', 'ranked'], ['rg-hu-flop', 'compact'], ['mx-turn', 'compact']]) {
    const { spec, state } = trained(dir, key, grouping, 40000);
    const h = gain(dir, spec, state, HU({ threads: 1 })), e = gain(dir, spec, state, { method: 'exact', maxVisits: 2000000000, timeLimitMs: 3600000, memoryMiB: 2048 });
    assert.equal(h.r.status, 0, key + ': ' + h.r.stderr); assert.equal(e.r.status, 0, key + ': ' + e.r.stderr);
    assert.equal(h.j.algorithm, 'brhu-5.17-v1'); assert.equal(h.j.mode, 'exactBestResponseHeadsUpVector'); assert.equal(h.j.brDevice, 'cpu'); assert.equal(e.j.algorithm, undefined);
    for (const p of [0, 1]) for (const k of ['policyValue', 'bestResponseValue', 'gain']) near(h.j.seats[p][k], e.j.seats[p][k]);
    near(h.j.nashConv, e.j.nashConv); near(h.j.exploitability, e.j.exploitability); assert.ok(h.j.nashConv > -1e-9, 'a best response is never worse than the policy');
    for (const s of h.j.seats) { assert.match(s.gainBits, /^[0-9a-f]{16}$/); assert.ok(s.bestResponseValue >= s.policyValue - 1e-12); assert.ok(s.policyLookups > 0); }
    assert.ok(Math.abs(h.j.seats[0].policyValue + h.j.seats[1].policyValue - (e.j.seats[0].policyValue + e.j.seats[1].policyValue)) < 1e-9);
    assert.ok(h.j.exactHu.items >= 1 && h.j.exactHu.completeBoards >= 1 && h.j.exactHu.riverSubtrees >= 1);
    for (const threads of [2, 3, 4]) assert.equal(bitsOf(gain(dir, spec, state, HU({ threads })).j), bitsOf(h.j), key + ' on ' + threads + ' threads');
    assert.equal(bitsOf(gain(dir, spec, state, HU({ threads: 1 })).j), bitsOf(h.j), 'the same process twice');
  }
});

test('5.17 exact-hu: whole ranges (1081 and 1128 hands a seat) against method exact; the flop games method exact refuses', { timeout: 3600000 }, t => {
  const dir = tmp(t);
  { const { spec, state } = trained(dir, 'wr-river', 'compact', 40000); const h = gain(dir, spec, state, HU({ threads: 2 })), e = gain(dir, spec, state, { method: 'exact', maxVisits: 2000000000, timeLimitMs: 3600000, memoryMiB: 2048 });
    assert.equal(JSON.parse(fs.readFileSync(spec, 'utf8')).hands[0].length, 1081); near(h.j.nashConv, e.j.nashConv); for (const p of [0, 1]) near(h.j.seats[p].bestResponseValue, e.j.seats[p].bestResponseValue); }
  { const { spec, state } = trained(dir, 'wr-flop', 'compact', 20000); const h = gain(dir, spec, state, HU({ threads: 4 })), e = gain(dir, spec, state, { method: 'exact', maxVisits: 20000000, timeLimitMs: 600000, memoryMiB: 2048 });
    assert.equal(JSON.parse(fs.readFileSync(spec, 'utf8')).hands[0].length, 1176); assert.equal(h.r.status, 0, h.r.stderr); assert.equal(h.j.exactHu.completeBoards, 49 * 48); assert.ok(h.j.nashConv > 0);
    assert.notEqual(e.r.status, 0); assert.match(e.r.stderr, /exceeds maxVisits/);
    assert.equal(bitsOf(gain(dir, spec, state, HU({ threads: 1 })).j), bitsOf(h.j)); }
});

test('5.17 exact-hu: fallbacks, policy current, and what is refused', { timeout: 3600000 }, t => {
  const dir = tmp(t), { spec, state } = trained(dir, 'rg-hu-turn', 'exact', 1);
  const h = gain(dir, spec, state, HU({})), e = gain(dir, spec, state, { method: 'exact', maxVisits: 2000000000, memoryMiB: 2048 });
  near(h.j.nashConv, e.j.nashConv); assert.ok(h.j.seats[0].fallbackLookups > 0);
  const refuse = gain(dir, spec, state, HU({ missing: 'refuse' })); assert.notEqual(refuse.r.status, 0); assert.match(refuse.r.stderr, /no stored/); assert.equal(refuse.j, null);
  const t2 = trained(dir, 'rg-hu-flop', 'ranked', 30000), cur = gain(dir, t2.spec, t2.state, HU({ policy: 'current' })), ecur = gain(dir, t2.spec, t2.state, { method: 'exact', policy: 'current', maxVisits: 2000000000, memoryMiB: 2048 });
  near(cur.j.nashConv, ecur.j.nashConv); assert.notEqual(cur.j.nashConvBits, gain(dir, t2.spec, t2.state, HU({})).j.nashConvBits);
  for (const fb of ['uniform', 'foldCheck']) { const a = gain(dir, spec, state, HU({ fallback: fb })), b = gain(dir, spec, state, { method: 'exact', fallback: fb, maxVisits: 2000000000, memoryMiB: 2048 }); if (a.r.status === 0 && b.r.status === 0) near(a.j.nashConv, b.j.nashConv); else assert.equal(a.r.status !== 0, b.r.status !== 0, fb); }
  // one seat only: no NashConv
  const one = gain(dir, t2.spec, t2.state, HU({ seats: [1] })); assert.equal(one.j.seats.length, 1); assert.equal(one.j.nashConv, undefined);
  const three = write(dir, 'three.json', fixture('flop3-kings').variants[0].nativeSpec), s3 = path.join(dir, 'three.state'); assert.equal(run([three, 50, 1, s3, 512]).status, 0);
  const pre = write(dir, 'pre.json', fixture('sat3-fold-aces').variants[0].nativeSpec), sp = path.join(dir, 'pre.state'); assert.equal(run([pre, 50, 1, sp, 512]).status, 0);
  for (const [sf, st, rq, want] of [[three, s3, HU({}), /exactly two seats/], [pre, sp, HU({}), /exact-hu/], [spec, state, { method: 'exact', brDevice: 'gpu' }, /apply to method exact-hu/], [spec, state, { method: 'sampled', verifyEvery: 4 }, /apply to method exact-hu/],
    [spec, state, HU({ brDevice: 'fast' }), /brDevice/], [spec, state, HU({ path: [0], seats: [0] }), /study root/], [spec, state, HU({ verifyEvery: -1 }), /verifyEvery/]]) {
    const r = gain(dir, sf, st, rq); assert.notEqual(r.r.status, 0, JSON.stringify(rq)); assert.match(r.r.stderr, want); assert.equal(r.j, null);
  }
  const wide = trained(dir, 'wr-flop', 'compact', 2000), small = gain(dir, wide.spec, wide.state, { method: 'exact-hu', memoryMiB: 16 }); assert.notEqual(small.r.status, 0); assert.match(small.r.stderr, /MiB/);
});

test('5.17 one source for both paths: the embedded kernel text is brhu_kernel.h and keeps its arithmetic rules', () => {
  const k = fs.readFileSync(path.join(src, 'native/brhu_kernel.h'), 'utf8'), e = fs.readFileSync(path.join(src, 'native/brhu_kernel_src.hpp'), 'utf8');
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (py) assert.equal(cp.spawnSync(py, [path.join(src, 'native/gen_brhu.py'), '--check']).status, 0, 'brhu_kernel_src.hpp is not the text of brhu_kernel.h: run native/gen_brhu.py');
  const embedded = [...e.matchAll(/^  "(.*)\\n";?$/gm)].map(m => m[1].replace(/\\"/g, '"').replace(/\\\\/g, '\\')).join('\n') + '\n';
  assert.equal(embedded, k.replace(/\r\n/g, '\n') + '\n');
  assert.ok(k.includes('#pragma OPENCL FP_CONTRACT OFF') && k.includes('as_double(as_ulong((a) * (b)) ^ zero)'));
  for (const banned of ['fma(', 'fmax(', 'fmin(', 'pow(', 'mad(', 'native_', 'half_']) assert.ok(!k.includes(banned), 'the kernel calls ' + banned);
  // outside BR_MUL the kernel multiplies only integers (indices): every product of doubles goes through the macro
  const body = k.slice(k.indexOf('static void brhu_item('), k.indexOf('#ifdef BRHU_OPENCL', k.indexOf('static void brhu_item(')));
  assert.equal((body.match(/BR_MUL\(/g) || []).length, 6);
  for (const line of body.split('\n')) { const code = line.replace(/\/\*.*?\*\//g, '').replace(/BR_MUL\([^()]*\)/g, 'M'); if (/[\w\])]\s\*\s[\w(]/.test(code)) assert.ok(/br_u64|br_i32|nOwn|BR_NI|\* [234]\b/.test(code), 'a product outside BR_MUL that is not index arithmetic: ' + line.trim()); }
  const host = fs.readFileSync(path.join(src, 'native/brhu_ocl.hpp'), 'utf8'); assert.deepEqual([...host.matchAll(/"(-cl-[^"]*)"/g)].map(m => m[1]).sort(), ['-cl-std=CL1.2', '-cl-std=CL1.2 -cl-mad-enable']);   // the second is the unprotected test kernel only
  assert.ok(fs.readFileSync(path.join(src, 'native/build.sh'), 'utf8').includes('-ffp-contract=off'));
});

test('5.17 the OpenCL path: the bits of the CPU, batch sizes, an altered result is found, the unprotected kernel', { timeout: 3600000 }, t => {
  const d = device(); if (!d.usable) { t.skip('no OpenCL device on this machine (' + d.why + '): the device path is not exercised here'); return; }
  assert.equal(d.kernelCompiled, true); assert.equal(d.arithmeticProbe.identicalToCpu, true); assert.ok(d.arithmeticProbe.values >= 20000);
  const dir = tmp(t);
  for (const [key, grouping, deals] of [['rg-hu-river', 'exact', 30000], ['ho-hu-turn', 'detailed', 30000], ['mx-turn', 'ranked', 30000], ['rg-hu-flop', 'compact', 30000], ['wr-flop-allin', 'compact', 20000]]) {
    const { spec, state } = trained(dir, key, grouping, deals), c = gain(dir, spec, state, HU({ threads: 2 })), g = gain(dir, spec, state, HU({ brDevice: 'gpu' }), CL), b = gain(dir, spec, state, HU({ brDevice: 'both' }), CL);
    assert.equal(g.r.status, 0, key + ': ' + g.r.stderr); assert.equal(bitsOf(g.j), bitsOf(c.j), key + ' on the device'); assert.equal(bitsOf(b.j), bitsOf(c.j), key + ' both');
    assert.equal(g.j.gpu.itemsWithOtherBits, 0); assert.ok(g.j.gpu.itemsRepeatedOnCpu >= 1); assert.equal(b.j.gpu.itemsRepeatedOnCpu, b.j.exactHu.items); assert.equal(g.j.gpu.items, g.j.exactHu.items);
    assert.equal(g.j.seats[0].policyLookups, c.j.seats[0].policyLookups); assert.equal(g.j.seats[1].fallbackLookups, c.j.seats[1].fallbackLookups);
    for (const batch of [48, 64, 4096]) assert.equal(bitsOf(gain(dir, spec, state, HU({ brDevice: 'gpu', verifyEvery: 0 }), { ...CL, EM_BRHU_BATCH: batch }).j), bitsOf(c.j), key + ' batch ' + batch);
    if (key === 'ho-hu-turn') {
      const flip = gain(dir, spec, state, HU({ brDevice: 'gpu' }), { ...CL, EM_BRHU_TEST: 'flip' }); assert.notEqual(flip.r.status, 0); assert.match(flip.r.stderr, /other bits on the device than on the CPU/); assert.equal(flip.j, null);
      const none = gain(dir, spec, state, HU({ brDevice: 'gpu' }), { EM_BRHU_ALLOW_CPU_DEVICE: '0' }); if (!d.chosenIsGpu) { assert.notEqual(none.r.status, 0); assert.match(none.r.stderr, /cannot use a GPU here/); }
    }
  }
  const u = JSON.parse(run(['--opencl-info'], { ...CL, EM_BRHU_TEST: 'unprotected' }).stdout);
  if (!u.usable) assert.match(u.why, /differs from the CPU/); else t.diagnostic('this device does not fuse a product with a sum even when allowed');
  const bad = JSON.parse(run(['--opencl-info'], { ...CL, EM_BRHU_DEVICE: '99' }).stdout); assert.equal(bad.usable, false); assert.match(bad.why, /does not name a listed/);
});

test('5.17 the games: twelve heads-up postflop games, whole ranges where they say so, only the grouping differs', () => {
  assert.deepEqual(g517.KEYS, ['rg-hu-river', 'rg-hu-turn', 'rg-hu-flop', 'ho-hu-river', 'ho-hu-turn', 'wr-river', 'wr-turn', 'wr-turn-wide', 'wr-flop', 'wr-flop-allin', 'mx-turn', 'mid-flop']);
  for (const key of g517.KEYS) {
    const a = g517.spec(key, 'compact', 3), b = g517.spec(key, 'detailed', 3), c = g517.spec(key, 'exact', 3); assert.equal(a.n, 2); assert.ok(a.board.length >= 3);
    assert.deepEqual(a.hands, b.hands); assert.deepEqual(a.hands, c.hands); assert.deepEqual(a.rules, b.rules); assert.deepEqual(a.rules, c.rules); assert.ok(g517.title(key).length > 10);
    if (key.startsWith('wr-')) { const want = { 5: 1081, 4: 1128, 3: 1176 }[a.board.length]; assert.equal(a.hands[0].length, want); assert.equal(a.hands[1].length, want); assert.equal(g517.added[key].hands, want); }
  }
  assert.equal(g517.spec('mx-turn', 'exact').hands[0].length, 1128); assert.ok(g517.spec('mx-turn', 'exact').hands[1].length < 60);
  assert.throws(() => g517.spec('nothing', 'exact'), /unknown game/);
});

test('5.17 the 5.16 program: the same states for every grouping, and it does not know the new method', { timeout: 3600000 }, t => {
  if (!fs.existsSync(old516())) { t.skip('validation/5.16/linux-bin/mwcli is not in this tree'); return; }
  const old = path.join(os.tmpdir(), 'em517-mwcli516-' + process.pid); fs.copyFileSync(old516(), old); fs.chmodSync(old, 0o755); t.after(() => fs.rmSync(old, { force: true }));
  const dir = tmp(t);
  for (const [key, grouping] of [['rg-hu-turn', 'compact'], ['ho-hu-turn', 'ranked'], ['mx-turn', 'detailed'], ['rg-hu-flop', 'exact']]) {
    const spec = write(dir, key + '.json', g517.spec(key, grouping, 5171)), a = path.join(dir, 'a.state'), b = path.join(dir, 'b.state');
    assert.equal(run([spec, 20000, 1, a, 1024]).status, 0); assert.equal(run([spec, 20000, 1, b, 1024], {}, old).status, 0); assert.equal(sha(a), sha(b), key + ' ' + grouping);
    const rq = write(dir, 'rq.json', HU({})), r = run(['--gain', spec, a, rq, 1024], {}, old); assert.notEqual(r.status, 0); assert.match(r.stderr, /method/);
    const ex = write(dir, 'ex.json', { method: 'exact', maxVisits: 2000000000, timeLimitMs: 3600000, memoryMiB: 1024, threads: 1 }), n = run(['--gain', spec, a, ex, 1024]), o = run(['--gain', spec, a, ex, 1024], {}, old);
    const strip = s => s.replace(/"elapsedMs":[0-9.]+/g, '').replace(/"timing":\{[^}]*\}/g, ''); assert.equal(n.status, 0); assert.equal(JSON.parse(n.stdout).nashConv, JSON.parse(o.stdout).nashConv); assert.deepEqual(JSON.parse(n.stdout).seats.map(s => s.gainBits), JSON.parse(o.stdout).seats.map(s => s.gainBits)); void strip;
  }
});

test('5.17 mwcli --selftest517: every check passes; the device checks pass or are skipped; sections and usage', { timeout: 7200000 }, t => {
  if (!fs.existsSync(path.join(cases, 'reference.json'))) { t.skip('validation/5.17/windows/brhu is not in this tree'); return; }
  const dir = tmp(t), r = run(['--selftest517', cases, studies, dir, 'all'], CL); assert.equal(r.status, 0, r.stdout + r.stderr);
  const rep = JSON.parse(fs.readFileSync(path.join(dir, 'selftest517.json'), 'utf8')); assert.equal(rep.algorithm, 'brhu-5.17-v1'); assert.equal(rep.failed, 0); assert.equal(rep.untested, 0);
  const ids = rep.checks.map(c => c.section + ' ' + c.id); assert.deepEqual(ids, [...CPU, ...GPU]);
  for (const c of rep.checks) assert.ok(c.status === 'passed' || (c.section === 'gpu' && c.status === 'skipped'), c.id + ': ' + c.status + ' ' + c.detail);
  const skipped = rep.checks.filter(c => c.status === 'skipped').length; assert.ok(skipped === 0 || skipped === GPU.length); assert.equal(rep.skipped, skipped);
  assert.equal(rep.milliseconds.length, JSON.parse(fs.readFileSync(path.join(cases, 'reference.json'), 'utf8')).cases.length);
  assert.equal(run(['--selftest517', cases, studies]).status, 2); assert.equal(run(['--selftest517', cases, studies, dir, 'nothing']).status, 2); assert.equal(run(['--selftest517', dir, studies, dir, 'cpu']).status, 2);
});

test('5.17 Windows validation: the script keeps every section of the 5.16 script, plans and imports every 5.17 check, the launchers run the self-tests first, the reference files are complete', () => {
  const file = path.join(src, 'tools/validate_windows517.ps1'), ps = fs.readFileSync(file, 'utf8'), version = fs.readFileSync(path.join(src, 'VERSION'), 'utf8').trim();
  assert.equal(version, '5.17'); assert.match(ps, /\$Release = '5\.17'/); assert.match(ps, /tool = 'validate_windows517\.ps1'/); assert.ok(!/[^\x00-\x7f]/.test(ps), 'the script is ASCII'); assert.ok(ps.includes('$count -gt 1000'));
  for (const s of ["Run-Section 'self-test 5.17'", "Run-Section 'exact best response 5.17'", "Run-Section 'self-test 5.16'", "Run-Section 'grouping 5.16'", "Run-Section 'GPU'", "'--selftest517', $cases, $studies, $dir, 'cpu'", "'--selftest517', $cases, $studies, $dir, 'gpu'", "'--opencl-info'", '$report.physicalOpenclGpu', '$report.exactHuTiming']) assert.ok(ps.includes(s), s);
  for (const id of [...CPU, 'gpu G0', ...GPU]) assert.ok(ps.includes("'" + id + "'"), 'expected check ' + id);
  const plans = [...ps.matchAll(/^Plan '([^']+)' '([^']+)' '([^']+)'/gm)];
  for (const name of ['mwcli --selftest517 ran and wrote its report', 'every expected 5.17 check is in the report', 'the 5.17 report agrees with the exit status of mwcli', 'OpenCL GPU']) {
    assert.equal(plans.filter(p => p[2] === name).length, 1, 'planned once: ' + name); const sec = plans.find(p => p[2] === name)[1]; assert.ok(ps.includes("Check '" + sec + "' '" + name + "'") || ps.includes("Add-Check '" + sec + "' '" + name + "'"), 'planned but never recorded: ' + name); }
  assert.equal(plans.find(p => p[2] === 'OpenCL GPU')[3], 'hardware');
  const focus = /\$focusSections = @\(([^)]*)\)/.exec(ps)[1]; for (const s of ["'self-test 5.17'", "'exact best response 5.17'", "'self-test 5.16'", "'grouping 5.16'", "'golden states'", "'integrity'"]) assert.ok(focus.includes(s), 'focused: ' + s);
  const sections = text => [...text.matchAll(/^Run-Section '([^']+)'/gm)].map(m => m[1]), before = sections(fs.readFileSync(path.join(src, 'tools/validate_windows516.ps1'), 'utf8')), now = sections(ps);
  assert.deepEqual(now.filter(s => before.includes(s)), before); assert.deepEqual(now.filter(s => !before.includes(s)), ['self-test 5.17', 'exact best response 5.17']);
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (py) { const r = cp.spawnSync(py, [path.join(src, 'tools/ps_lint571.py'), file], { encoding: 'utf8' }); assert.equal(r.status, 0, r.stdout + r.stderr); }
  for (const [name, needs] of [['Run 5.17 Windows validation.bat', ['mwcli.exe --selftest57 ', 'mwcli.exe --selftest516 ', 'mwcli.exe --selftest517 "validation\\5.17\\windows\\brhu" "studies"', 'validate_windows517.ps1" %*', 'Windows-selftest517-5.17.json', 'Windows-validation-5.17.json', 'Step 13 of 13', 'if not "%selftest517_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"']],
    ['Run 5.17 focused validation.bat', ['mwcli.exe --selftest517 "validation\\5.17\\windows\\brhu" "studies"', 'validate_windows517.ps1" -Focused %*', 'Windows-focused-validation-5.17.json', 'Windows-selftest517-5.17.json']]]) {
    const f = path.join(root, name); if (!fs.existsSync(f)) continue;
    const text = fs.readFileSync(f).toString('latin1'); assert.ok(!/[^\x00-\x7f]/.test(text), name + ' is ASCII'); assert.ok(!/[^\r]\n/.test(text), name + ' has CRLF line ends'); for (const n of needs) assert.ok(text.includes(n), name + ': ' + n); assert.match(text, /exit \/b %\w+%\r\n$/);
    assert.ok(!text.includes('-5.16.json') && !text.includes('validate_windows516'), name + ' writes 5.17 reports only');
  }
  if (fs.existsSync(cases)) { const ref = JSON.parse(fs.readFileSync(path.join(cases, 'reference.json'), 'utf8')); assert.equal(ref.cases.length, 12); assert.equal(ref.algorithm, 'brhu-5.17-v1');
    for (const c of ref.cases) { assert.ok(fs.existsSync(path.join(cases, c.spec)), c.spec); assert.match(c.stateSha256, /^[0-9a-f]{64}$/); assert.match(c.nashConvBits, /^[0-9a-f]{16}$/); assert.equal(c.seats.length, 2); for (const s of c.seats) for (const k of ['policyValueBits', 'bestResponseValueBits', 'gainBits']) assert.match(s[k], /^[0-9a-f]{16}$/); assert.equal(JSON.parse(fs.readFileSync(path.join(cases, c.spec), 'utf8')).n, 2); if (c.exactAgrees !== null) assert.equal(c.exactAgrees, true, c.name); }
    for (const name of ['wr-turn-wide-ranked', 'wr-flop-compact', 'wr-flop-allin-ranked']) assert.ok(ref.cases.some(c => c.name === name), 'the timed study ' + name + ' is a case'); assert.ok(ref.cases.filter(c => c.exactFinishes).length >= 5); }
  const wf = path.join(root, '.github/workflows/windows.yml');
  if (fs.existsSync(wf)) { const y = fs.readFileSync(wf, 'utf8'); for (const s of ['--selftest517 validation/5.17/windows/brhu source/studies', 'validate_windows517.ps1 -Root', 'Windows-validation-5.17.json', 'windows-selftest517.json', 'source/tests/v517.test.js']) assert.ok(y.includes(s), s); }
});
