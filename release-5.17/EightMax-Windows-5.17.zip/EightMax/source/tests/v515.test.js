'use strict';
// EightMax 5.15 regression tests (Phase 5: ICM and bounty formats).
//   5.15 adds the tournament payoff model tour-5.15-v1 (native/tour515.hpp, web/lib_tour515.js): knockout and
//   progressive-knockout bounties, and the simulation of future hands as push/fold games. It is off unless a spec
//   asks for it ("icm":{"model":"tour-5.15"}); the trainers are those of 5.14 and write the states of 5.14.
//   Tested here:
//     - the model: the native program against the JavaScript mirror on a set of requests; the independent Python
//       implementation; closed forms; the generated data table of the push/fold game;
//     - the push/fold calculator: the bounty rule (the pool rule; changed from 5.14), future hands beyond two, the limit;
//     - the study form: bounties and future hands reach the native spec; spots that do not use them are unchanged;
//       the JavaScript engine trains with bounties;
//     - the engine: training, the state header, continuation rules, refusals; the unchanged 5.14 program (it refuses
//       the spec and the state; it trains the plain studies to the same bytes as 5.15);
//     - mwcli --selftest515; the Windows validation script of 5.15, its launchers and the workflow.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
const build = require('./native_build');
const src = path.resolve(__dirname, '..'), root = path.resolve(src, '..'), studies = path.join(src, 'studies'), native = path.join(src, 'native');
const EM = require('../tools/loadlib.js'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river', 'lib_river_ui']) require('../web/' + l);
const cli = () => process.env.EM_TEST_MWCLI || build.cli().cli;
const tmp = t => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em515-')); t.after(() => fs.rmSync(d, { recursive: true, force: true })); return d; };
const run = (args, env = {}, exe = null) => cp.spawnSync(exe || cli(), args.map(String), { encoding: 'utf8', timeout: 1800000, maxBuffer: 256 << 20, env: { ...process.env, ...env } });
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const IDS = ['model M1', 'model M2', 'model M3', 'model M4', 'model M5', 'training T1', 'training T2', 'training T3', 'training T4', 'checkpoint C1', 'checkpoint C2', 'checkpoint C3'];
const fixture = id => JSON.parse(fs.readFileSync(path.join(studies, id + '.emfix.json'), 'utf8').replace(/^﻿/, ''));
const specOf = (id, variant = 0, extra = {}) => ({ ...fixture(id).variants[variant].nativeSpec, ...extra });
const write = (dir, name, spec) => { const f = path.join(dir, name); fs.writeFileSync(f, JSON.stringify(spec)); return f; };
const header = f => fs.readFileSync(f).subarray(0, 900).toString('latin1');
const old514 = () => process.env.EM_TEST_MWCLI_514 || path.join(root, 'validation/5.14/linux-bin/mwcli');
const fg = (d, t, at = 'bba', ante = 1) => ({ depth: d, table: t, smallBlind: 0.5, bigBlind: 1, ante, anteType: at });
const REQUESTS = [
  { seats: 4, start: [4, 20, 15, 11], prizes: [50, 30, 20], bounty: { share: 0.5, heads: [10, 10, 25, 5] }, outcomes: [{ final: [4, 20, 15, 11] }, { final: [0, 24, 15, 11], won: [2] }, { final: [0, 22, 17, 11], won: [6] }, { final: [0, 0, 39, 11], won: [4, 4] }] },
  { seats: 3, start: [4, 20, 15, 11, 30], prizes: [50, 30, 20], bounty: { share: 1, heads: [10, 10, 25, 5, 8] }, outcomes: [{ final: [0, 24, 15], won: [2] }, { final: [9, 15, 15] }] },
  { seats: 4, start: [4, 20, 15, 11], prizes: [50, 30, 20], fgs: fg(1, [0, 1, 2, 3]), outcomes: [{ final: [4, 20, 15, 11] }, { final: [0, 24, 15, 11], won: [2] }] },
  { seats: 4, start: [4, 20, 15, 11], prizes: [50, 30, 20], bounty: { share: 0.5, heads: [10, 10, 25, 5] }, fgs: fg(1, [0, 1, 2, 3]), outcomes: [{ final: [8.5, 20, 15, 6.5] }] },
  { seats: 3, start: [6, 12, 9], prizes: [50, 30, 20], bounty: { share: 0.5, heads: [10, 10, 25] }, fgs: fg(2, [0, 1, 2]), outcomes: [{ final: [6, 12, 9] }, { final: [0, 18, 9], won: [2] }] },
  { seats: 2, start: [6, 12, 9, 14, 22], prizes: [50, 30, 20], fgs: fg(2, [3, 0, 2, 1], 'classic', 0.1), outcomes: [{ final: [6, 12] }, { final: [12, 6] }] },
  { seats: 2, start: [12, 8], prizes: [70, 30], fgs: fg(3, [0, 1], 'none', 0), outcomes: [{ final: [12, 8] }] },
  { seats: 3, start: [1.6, 10, 10], prizes: [50, 30, 20], fgs: fg(1, [0, 1, 2]), outcomes: [{ final: [0.25, 10.675, 10.675] }] },
];
const ask = (dir, q) => { const f = path.join(dir, 'q.json'); fs.writeFileSync(f, JSON.stringify(q)); const r = run(['--tour515', f]); assert.equal(r.status, 0, r.stderr); return JSON.parse(r.stdout); };

test('5.15 model: the native program and the JavaScript mirror give the same values (bounties, one to three future hands, both, players elsewhere); values add up; bits are the values', { timeout: 1800000 }, t => {
  const dir = tmp(t); let worst = 0, n = 0;
  for (const q of REQUESTS) {
    const { outcomes, ...model } = q, M = EM.tour515(model), got = ask(dir, q); assert.equal(got.model, 'tour-5.15-v1'); assert.match(got.payoffKey, /^[0-9a-f]{16}$/);
    outcomes.forEach((o, i) => { const js = Array.from(M.evaluate(o.final, o.won)), nat = got.outcomes[i].values; assert.equal(nat.length, q.seats);
      js.forEach((x, k) => { worst = Math.max(worst, Math.abs(x - nat[k])); n++; });
      nat.forEach((x, k) => { const b = Buffer.alloc(8); b.writeDoubleBE(x); assert.equal(b.toString('hex'), got.outcomes[i].bits[k]); });
      if (q.start.length === q.seats) { const total = q.prizes.slice(0, q.seats).reduce((a, b) => a + b, 0) + (q.bounty ? q.bounty.heads.reduce((a, b) => a + b, 0) : 0); assert.ok(Math.abs(nat.reduce((a, b) => a + b, 0) - total) < 1e-9, 'sum ' + nat.reduce((a, b) => a + b, 0) + ' of ' + total); } });
  }
  assert.ok(n >= 40 && worst < 1e-9, n + ' values, largest difference ' + worst);
  // the same parameters give the same key; another head gives another
  const a = ask(dir, REQUESTS[0]), b = ask(dir, { ...REQUESTS[0], bounty: { share: 0.5, heads: [10, 10, 25, 6] } }); assert.equal(a.payoffKey, ask(dir, REQUESTS[0]).payoffKey); assert.notEqual(a.payoffKey, b.payoffKey);
  // closed forms: heads-up the winner of everything gets the first prize and both bounties
  const hu = ask(dir, { seats: 2, start: [12, 8], prizes: [70, 30], bounty: { share: 0.5, heads: [10, 20] }, outcomes: [{ final: [20, 0], won: [0, 1] }, { final: [12, 8] }] });
  assert.deepEqual(hu.outcomes[0].values, [100, 30]); assert.ok(Math.abs(hu.outcomes[1].values[0] - 72) < 1e-12 && Math.abs(hu.outcomes[1].values[1] - 58) < 1e-12);
  // refused requests name the reason
  for (const [q, want] of [[{ seats: 4, start: [4, 20, 15, 11], prizes: [50, 30, 20], fgs: fg(4, [0, 1, 2, 3]), outcomes: [] }, /at most 3 hands at this table size/], [{ seats: 3, start: [6, 12, 9], prizes: [50, 30, 20], outcomes: [] }, /"bounty", "fgs" or both/], [{ seats: 3, start: [6, 12, 9], prizes: [50, 30, 20], bounty: { share: 2, heads: [1, 1, 1] }, outcomes: [] }, /at most 1/]]) {
    const f = path.join(dir, 'bad.json'); fs.writeFileSync(f, JSON.stringify(q)); const r = run(['--tour515', f]); assert.equal(r.status, 1); assert.match(r.stderr, want); assert.equal(r.stdout, ''); }
  assert.throws(() => EM.tour515({ start: [4, 20, 15, 11], seats: 4, prizes: [50, 30, 20], fgs: fg(4, [0, 1, 2, 3]) }), /at most 3 hands at this table size/);
});
test('5.15 model: the data table of the native push/fold game is what the generator writes; the independent implementation agrees (short set)', { timeout: 1800000 }, t => {
  const g = cp.spawnSync(process.execPath, [path.join(src, 'tools/gen_pf515.js'), '--check'], { encoding: 'utf8' }); assert.equal(g.status, 0, g.stdout + g.stderr);
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (!py) { t.diagnostic('no Python 3.8: the independent implementation was not run'); return; }
  const dir = tmp(t), names = ['pko', 'ko-others', 'fgs1', 'pko+fgs1', 'pko+fgs2', 'fgs2-others', 'fgs3-hu', 'cannot-post'], req = path.join(dir, 'requests.json'), out = path.join(dir, 'report.json');
  fs.writeFileSync(req, JSON.stringify({ requests: REQUESTS.map((q, i) => ({ name: names[i], ...q })) }));
  const r = cp.spawnSync(py, [path.join(src, 'tools/independent_tour515.py'), 'check', cli(), req, out], { encoding: 'utf8', timeout: 1800000 }); assert.equal(r.status, 0, r.stdout + r.stderr);
  const rep = JSON.parse(fs.readFileSync(out, 'utf8')); assert.equal(rep.passed, true); assert.deepEqual(rep.failed, []);
  assert.ok(rep.counts.A >= 6 && rep.counts.B1 >= 3 && rep.counts.B2 >= 6 && rep.counts.C >= 4, JSON.stringify(rep.counts));
  assert.ok(rep.largest.A < 1e-9 && rep.largest.B1 < 1e-9 && rep.largest.B2 < 1e-9 && rep.largest.C < 1e-9 && rep.largest.gainOverUnit < 1e-3, JSON.stringify(rep.largest));
});
test('5.15 push/fold calculator: bounties follow the pool rule, future hands go beyond two within the work limit, and the plain calculator is unchanged', { timeout: 1800000 }, () => {
  assert.deepEqual([2, 3, 4, 5, 6, 7, 8].map(EM.pushFoldMaxFutureHands), [4, 3, 2, 2, 1, 1, 1]);
  const solve = cfg => { const g = EM.PushFold(cfg); g.solve({ maxIter: 600, tol: 1e-7 }); return { g, v: Array.from(g.values()), r: g.results() }; };
  // heads-up, two prizes: every outcome's value follows the model; the values add up to prizes plus bounties
  const hu = solve({ n: 2, stacks: [12, 8], anteType: 'none', model: 'icm', payouts: [70, 30], bounty: { kind: 'pko', b: [10, 20] } });
  assert.ok(Math.abs(hu.v[0] + hu.v[1] - 130) < 1e-6, 'sum ' + (hu.v[0] + hu.v[1]));
  const ko = solve({ n: 4, stacks: [4, 20, 15, 11], anteType: 'bba', ante: 1, model: 'icm', payouts: [50, 30, 20], bounty: { kind: 'ko', b: [10, 10, 25, 5] } });
  assert.ok(Math.abs(ko.v.reduce((a, b) => a + b, 0) - 150) < 1e-6);
  const plain = solve({ n: 4, stacks: [4, 20, 15, 11], anteType: 'bba', ante: 1, model: 'icm', payouts: [50, 30, 20] });
  assert.ok(Math.abs(plain.v.reduce((a, b) => a + b, 0) - 100) < 1e-6);
  // a covering big blind calls a short all-in wider when there is a bounty to win
  assert.ok(ko.r.call[0][3].pct > plain.r.call[0][3].pct + 1, ko.r.call[0][3].pct + ' against ' + plain.r.call[0][3].pct);
  // bounties at other tables count in the pool: with them a chip is worth more to everybody
  const withOthers = solve({ n: 3, stacks: [6, 12, 9], anteType: 'bba', ante: 1, model: 'icm', payouts: [50, 30, 20], others: [14, 22], bounty: { kind: 'pko', b: [10, 10, 10], others: [10, 10] } }), without = solve({ n: 3, stacks: [6, 12, 9], anteType: 'bba', ante: 1, model: 'icm', payouts: [50, 30, 20], others: [14, 22], bounty: { kind: 'pko', b: [10, 10, 10] } });
  assert.ok(withOthers.v.every((x, i) => x > without.v[i]));
  // three future hands at a table of three; four are refused with the limit
  const three = solve({ n: 3, stacks: [6, 12, 9], anteType: 'bba', ante: 1, model: 'icm', payouts: [50, 30, 20], fgs: { depth: 3 } });
  assert.equal(three.g.fgsDepth, 3); assert.ok(Math.abs(three.v.reduce((a, b) => a + b, 0) - 100) < 1e-6);
  assert.throws(() => EM.PushFold({ n: 3, stacks: [6, 12, 9], model: 'icm', payouts: [50, 30, 20], fgs: { depth: 4 } }), /at most 3 at this table size/);
  // one future hand: the routine of 5.14 (lib_fgs.js, kept) gives the same value of an outcome. (With two hands lib_fgs.js
  // is no longer the 5.14 calculation: its inner hand is solved by PushFold, which now uses the model.)
  const old = EM.makeFGS({ sb: 0.5, bb: 1, anteType: 'bba', ante: 1, payouts: [50, 30, 20], others: [], depth: 1 }), M = EM.tour515({ start: [6, 12, 9], seats: 3, prizes: [50, 30, 20], fgs: fg(1, [0, 1, 2]) });
  for (const v of [[6, 12, 9], [0, 18, 9], [12, 6, 9]]) { const a = Array.from(old.value(v, [6, 12, 9])), b = Array.from(M.evaluate(v, [2, 0, 0])); a.forEach((x, i) => assert.ok(Math.abs(x - b[i]) < 1e-9, v + ': ' + x + ' against ' + b[i])); }
});
test('5.15 study form: bounties and future hands reach the native spec; a spot that does not use them is unchanged; the JavaScript engine trains with bounties', { timeout: 1800000 }, () => {
  const fx = fixture('pko6-bb-call-small'), spot = fx.variants[0].spot, cfg = EM.multiwaySpotConfig(spot);
  assert.deepEqual(cfg.icm.bounty, { kind: 'pko', heads: [10, 6, 14, 12, 8, 20] }); assert.equal(cfg.icm.fgs, undefined);
  const spec = EM.MultiwayGame({ ...cfg, engine: 'native' }).nativeSpec(); assert.equal(spec.icm.model, 'tour-5.15'); assert.deepEqual(spec.icm.bounty, { share: 0.5, heads: [10, 6, 14, 12, 8, 20] }); assert.deepEqual(spec.icm.prizes, [34, 23, 16, 12, 9, 6]); assert.equal(spec.icm.payouts, undefined);
  assert.deepEqual(spec, fx.variants[0].nativeSpec);
  const fx2 = fixture('fgs4-bubble-bb-call-small'), cfg2 = EM.multiwaySpotConfig(fx2.variants[0].spot), spec2 = EM.MultiwayGame({ ...cfg2, engine: 'native' }).nativeSpec();
  assert.deepEqual(spec2.icm.fgs, { depth: 2, table: [3, 0, 1, 2], smallBlind: 0.5, bigBlind: 1, ante: 0.1, anteType: 'classic' });   // the folded cutoff is first to act in the next hand's order of this hand
  // the plain variants carry no key of the model
  const plain = fx.variants[2]; assert.equal(plain.spot.bounty, undefined); assert.equal(plain.nativeSpec.icm.model, undefined); assert.deepEqual(Object.keys(plain.nativeSpec.icm).sort(), ['others', 'payouts', 'start']);
  for (const id of ['icm8-bb-call-small', 'sat5-bubble-bb-call-small']) { const f = fixture(id); assert.ok(!('bounty' in f.variants[0].spot) && !('fgsHands' in f.variants[0].spot)); assert.deepEqual(EM.MultiwayGame({ ...EM.multiwaySpotConfig(f.variants[0].spot), engine: 'native' }).nativeSpec(), f.variants[0].nativeSpec); }
  // one number for everybody; a wrong count is refused; future hands need a preflop study
  const one = EM.MultiwayGame({ ...EM.multiwaySpotConfig({ ...spot, bounties: '7' }), engine: 'native' }).nativeSpec(); assert.deepEqual(one.icm.bounty.heads, [7, 7, 7, 7, 7, 7]);
  assert.throws(() => EM.MultiwayGame(EM.multiwaySpotConfig({ ...spot, bounties: '7,8' })), /one for every player/);
  assert.throws(() => EM.MultiwayGame(EM.multiwaySpotConfig({ ...spot, fgsHands: '5' })), /at most \d hands? at this table size|at most 2 hands/);
  // the JavaScript engine: a few updates with bounties (who won a pot comes from the pot list), values stay inside prizes plus bounties
  const g = EM.MultiwayGame({ ...cfg, engine: 'javascript' }); g.iterate(40); const m = g.metrics(); assert.ok(m.ev.every(x => Number.isFinite(x) && x >= 0 && x <= 34 + 70), JSON.stringify(Array.from(m.ev)));
});
test('5.15 engine: training under the model, the header, continuation, refusals; the unchanged 5.14 program refuses the spec and the state and trains the plain studies to the same bytes', { timeout: 1800000 }, t => {
  const dir = tmp(t), st = n => path.join(dir, n + '.state');
  const pko = write(dir, 'pko.json', specOf('pko6-bb-call-small', 0)), ko = write(dir, 'ko.json', specOf('pko6-bb-call-small', 1)), plain = write(dir, 'plain.json', specOf('pko6-bb-call-small', 2)), two = write(dir, 'two.json', specOf('fgs4-bubble-bb-call-small', 0));
  const a = run([pko, 3000, 1, st('a')]); assert.equal(a.status, 0, a.stderr); const info = JSON.parse(a.stdout); assert.equal(info.payoffModel, 'tour-5.15-v1'); assert.match(info.payoffKey, /^[0-9a-f]{16}$/); assert.equal(info.tournamentModel.bountyShare, 0.5); assert.equal(info.tournamentModel.futureHands, 0);
  assert.ok(header(st('a')).includes('"payoffModel":"tour-5.15-v1","payoffKey":"' + info.payoffKey + '"'));
  const p1 = run([pko, 1000, 1, st('p1')]), p2 = run([pko, 2000, 1, st('p2'), 512, st('p1')]); assert.equal(p1.status + p2.status, 0, p2.stderr); assert.equal(sha(st('p2')), sha(st('a')));
  const b = run([two, 2000, 1, st('b')]); assert.equal(b.status, 0, b.stderr); const ib = JSON.parse(b.stdout); assert.equal(ib.tournamentModel.futureHands, 2); assert.ok(ib.tournamentModel.futureHandsSolved > 0); assert.equal(ib.tournamentModel.tablePlayers, 4);
  const batch = { batchDeals: 16, actionStreams: 'deal' }, tb = write(dir, 'two-batch.json', specOf('fgs4-bubble-bb-call-small', 0, batch)); const hashes = [1, 2, 4].map(n => { const r = run([tb, 100, n, st('t' + n)], { EIGHTMAX_THREAD_CHOICE: 'fixed' }); assert.equal(r.status, 0, r.stderr); return sha(st('t' + n)); }); assert.equal(new Set(hashes).size, 1);
  const pl = run([plain, 3000, 1, st('plain')]); assert.equal(pl.status, 0); assert.ok(!header(st('plain')).includes('payoffModel'));
  for (const [spec, input, want] of [[plain, 'a', /cannot be continued by a study without it/], [pko, 'plain', /was not trained under the payoff model tour-5\.15-v1/], [ko, 'a', /other bounties or another future-game simulation/]]) {
    const r = run([spec, 5, 1, st('no'), 512, st(input)]); assert.equal(r.status, 1, r.stdout); assert.match(r.stderr, want); assert.ok(!fs.existsSync(st('no'))); }
  // exact evaluation works under the model and its values stay inside prizes plus bounties
  const q = write(dir, 'gain.json', { method: 'exact', policy: 'average', device: 'cpu', threads: 1, timeLimitMs: 600000, maxVisits: 2000000000, memoryMiB: 512 }), gr = run(['--gain', pko, st('a'), q]); assert.equal(gr.status, 0, gr.stderr);
  const seats = JSON.parse(gr.stdout).seats; assert.equal(seats.length, 3); for (const s of seats) assert.ok(s.bestResponseValue >= s.policyValue - 1e-9 && s.policyValue > 0 && s.bestResponseValue < 104);
  // the unchanged 5.14 program
  const old = old514(); if (!fs.existsSync(old)) { t.diagnostic('no 5.14 mwcli at ' + old + ': the comparison with 5.14 was not run'); return; }
  const o1 = run([pko, 5, 1, st('o1')], {}, old); assert.equal(o1.status, 1); assert.match(o1.stderr, /Unknown icm\.model/); assert.ok(!fs.existsSync(st('o1')));
  const o2 = run([plain, 5, 1, st('o2'), 512, st('a')], {}, old); assert.equal(o2.status, 1, o2.stdout); assert.match(o2.stderr, /payoff model|different study/i); assert.ok(!fs.existsSync(st('o2')));
  for (const [id, extra, updates, threads] of [['pko6-bb-call-small', {}, 3000, 1], ['icm8-bb-call-small', {}, 3000, 1], ['flop3-kings-small', batch, 150, 3], ['flop6-jack-small', { estimator: 'rbes', ...batch }, 100, 2], ['sat5-bubble-bb-call-small', { trainingStreams: 'philox64' }, 3000, 1]]) {
    const f = write(dir, 'same.json', specOf(id, id === 'pko6-bb-call-small' ? 2 : 0, extra)), n = run([f, updates, threads, st('new')], { EIGHTMAX_THREAD_CHOICE: 'fixed' }), o = run([f, updates, threads, st('old')], { EIGHTMAX_THREAD_CHOICE: 'fixed' }, old);
    assert.equal(n.status + o.status, 0, n.stderr + o.stderr); assert.equal(sha(st('new')), sha(st('old')), id + ': 5.15 and 5.14 write different states'); }
});
test('5.15 self-test: mwcli --selftest515 passes every check under three sections; a section alone; usage errors; without fixtures the training checks do not pass', { timeout: 1800000 }, t => {
  const dir = tmp(t), r = run(['--selftest515', studies, path.join(dir, 'w'), 'all']); assert.equal(r.status, 0, r.stdout + r.stderr.slice(0, 400));
  const doc = JSON.parse(fs.readFileSync(path.join(dir, 'w/selftest515.json'), 'utf8')); assert.equal(doc.failed, 0); assert.equal(doc.untested, 0); assert.equal(doc.passed, 12);
  assert.deepEqual(doc.checks.map(c => c.section + ' ' + c.id), IDS); assert.equal(doc.payoffModel, 'tour-5.15-v1');
  const m = run(['--selftest515', studies, path.join(dir, 'm'), 'model']); assert.equal(m.status, 0); assert.equal(JSON.parse(m.stdout).passed, 5);
  assert.equal(run(['--selftest515']).status, 2); assert.equal(run(['--selftest515', studies, path.join(dir, 'x'), 'everything']).status, 2);
  const empty = path.join(dir, 'empty'); fs.mkdirSync(empty); const e = run(['--selftest515', empty, path.join(dir, 'e'), 'all']); assert.equal(e.status, 1); const d2 = JSON.parse(fs.readFileSync(path.join(dir, 'e/selftest515.json'), 'utf8')); assert.equal(d2.passed, 5, 'the model checks need no fixture');
  const golden = fs.readFileSync(path.join(native, 'selftest515_golden.hpp'), 'utf8').trim().split('\n'); assert.equal(golden.length, 16); assert.ok(golden.every(l => /"[0-9a-f]{64}"\},$/.test(l)), 'every recorded state is a SHA-256');
  const values = fs.readFileSync(path.join(native, 'selftest515_values.hpp'), 'utf8').trim().split('\n'); assert.equal(values.length, 83); assert.ok(values.every(l => /^"[0-9a-f]{16}",$/.test(l)));
});
test('5.15 Windows validation: the script keeps every section of the 5.14 script, plans and imports every 5.15 check, the launchers run the self-tests first, the reference files are complete', () => {
  const file = path.join(src, 'tools/validate_windows515.ps1'), ps = fs.readFileSync(file, 'utf8'), version = fs.readFileSync(path.join(src, 'VERSION'), 'utf8').trim();
  assert.ok(['5.15', '5.16', '5.17'].includes(version), version); assert.match(ps, /\$Release = '5\.15'/);   // 5.16: the 5.15 script is kept as it ran; validate_windows516.ps1 is the current one assert.match(ps, /tool = 'validate_windows515\.ps1'/); assert.ok(!/[^\x00-\x7f]/.test(ps), 'the script is ASCII'); assert.ok(ps.includes('$count -gt 1000'));
  for (const s of ["Run-Section 'self-test 5.15'", "Run-Section 'tournament 5.15'", "Run-Section 'self-test 5.14'", "Run-Section 'equal time 5.14'", "Run-Section 'GPU'", "'--selftest515', $studies, $dir, 'all'", "'--tour515'", "foreach ($o in @($doc.outcomes))"]) assert.ok(ps.includes(s), s);
  for (const id of IDS) assert.ok(ps.includes("'" + id + "'"), 'expected check ' + id);
  const plans = [...ps.matchAll(/^Plan '([^']+)' '([^']+)' '([^']+)'/gm)];
  for (const name of ['mwcli --selftest515 ran and wrote its report', 'every expected 5.15 check is in the report', 'the 5.15 report agrees with the exit status of mwcli', 'mwcli --tour515 prints the bits of the Linux build', 'the interface file carries the payoff model and the new fixtures', 'identical tournament state for every thread count', 'tournament state equals the Linux build', 'tournament: every processing mode writes the same state', 'tournament processing modes and times on this PC']) {
    assert.equal(plans.filter(p => p[2] === name).length, 1, 'planned once: ' + name); const sec = plans.find(p => p[2] === name)[1]; assert.ok(ps.includes("Check '" + sec + "' '" + name + "'") || ps.includes("Add-Check '" + sec + "' '" + name + "'"), 'planned but never recorded: ' + name); }
  const focus = /\$focusSections = @\(([^)]*)\)/.exec(ps)[1]; for (const s of ["'self-test 5.15'", "'tournament 5.15'", "'self-test 5.14'", "'equal time 5.14'", "'golden states'", "'integrity'"]) assert.ok(focus.includes(s), 'focused: ' + s);
  const sections = text => [...text.matchAll(/^Run-Section '([^']+)'/gm)].map(m => m[1]), before = sections(fs.readFileSync(path.join(src, 'tools/validate_windows514.ps1'), 'utf8')), now = sections(ps);
  assert.deepEqual(now.filter(s => before.includes(s)), before); assert.deepEqual(now.filter(s => !before.includes(s)), ['self-test 5.15', 'tournament 5.15']);
  const py = ['python3', 'python'].find(p => cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']).status === 0);
  if (py) { const r = cp.spawnSync(py, [path.join(src, 'tools/ps_lint571.py'), file], { encoding: 'utf8' }); assert.equal(r.status, 0, r.stdout + r.stderr); }
  // the page the script looks into carries what it looks for
  const page = path.join(root, 'EightMax-Offline.html'); if (fs.existsSync(page)) { const html = fs.readFileSync(page, 'utf8'); for (const s of ['function tour515(', 'tour-5.15-v1', 'id="rv-bounty"', 'id="rv-fgsHands"', 'data-pfc-fgs=', '"id":"pko6-bb-call"', '"id":"pko6-bb-call-small"', '"id":"fgs4-bubble-bb-call"', '"id":"fgs4-bubble-bb-call-small"']) assert.ok(html.includes(s), 'the page lacks ' + s); }
  for (const [name, needs] of [['Run 5.15 Windows validation.bat', ['mwcli.exe --selftest57 ', 'mwcli.exe --selftest514 ', 'mwcli.exe --selftest515 ', 'validate_windows515.ps1" %*', 'Windows-selftest515-5.15.json', 'Windows-validation-5.15.json', 'Step 11 of 11', 'if not "%selftest515_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"']],
    ['Run 5.15 focused validation.bat', ['mwcli.exe --selftest515 ', 'validate_windows515.ps1" -Focused %*', 'Windows-focused-validation-5.15.json', 'Windows-selftest515-5.15.json']]]) {
    const f = path.join(root, name); if (!fs.existsSync(f)) continue;
    const text = fs.readFileSync(f).toString('latin1'); assert.ok(!/[^\x00-\x7f]/.test(text), name + ' is ASCII'); assert.ok(!/[^\r]\n/.test(text), name + ' has CRLF line ends'); for (const n of needs) assert.ok(text.includes(n), name + ': ' + n); assert.match(text, /exit \/b %\w+%\r\n$/);
    assert.ok(!text.includes('-5.14.json') && !text.includes('validate_windows514'), name + ' writes 5.15 reports only');
  }
  const refDir = path.join(root, 'validation/5.15/windows/tournament');
  if (fs.existsSync(refDir)) { const ref = JSON.parse(fs.readFileSync(path.join(refDir, 'reference.json'), 'utf8')); assert.equal(ref.cases.length, 2); assert.equal(ref.values.length, 4);
    for (const c of ref.cases) { assert.ok(fs.existsSync(path.join(refDir, c.spec))); assert.match(c.stateSha256, /^[0-9a-f]{64}$/); assert.equal(c.payoffModel, 'tour-5.15-v1'); }
    for (const v of ref.values) { assert.ok(fs.existsSync(path.join(refDir, v.request))); assert.equal(v.bits.length, v.values.length); } }
  const wf = path.join(root, '.github/workflows/windows.yml');
  if (fs.existsSync(wf)) { const y = fs.readFileSync(wf, 'utf8'); for (const s of ['--selftest515 source/studies', version === '5.15' ? 'validate_windows515.ps1 -Root' : 'validate_windows517.ps1 -Root', version === '5.15' ? 'Windows-validation-5.15.json' : 'Windows-validation-5.17.json', 'windows-selftest515.json', 'source/tests/v515.test.js']) assert.ok(y.includes(s), s); }
});
