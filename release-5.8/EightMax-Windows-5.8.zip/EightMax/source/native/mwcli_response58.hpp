// EightMax 5.8: mwcli --response spec.json state request.json [memoryMiB]
// Trained response of every requested seat against a trained state (see response58.hpp for the mathematics).
// request.json: {"seats":[...], "responseDeals":N, "seed":S, "threads":T, "samples":M, "exact":false, "exactMaxVisits":V,
//                "timeLimitMs":ms, "saveStates":"path prefix"}
//   seats           default: every seat
//   responseDeals   sampled deals of response training per seat (default 200000); one walk per deal, for this seat only
//   samples         evaluation deals per seat (default 200000; rounded up to blocks of 1024), independent of the training
//   futureActions   auto (default) | enumerate | sample: whether the other seats' actions are enumerated or sampled in
//                   the evaluation walk (auto: enumerated when the betting tree has at most 4,096 states)
//   exact           also evaluate the response exactly and compute the exact best response (small games only)
//   saveStates      writes "<prefix><seat>.state": an ordinary state file whose policy "average" is (response, sigma of
//                   the others) and whose policy "current" is sigma. It is NOT a training state.
//   parallelSeats   seats handled side by side (default 1). Each holds its own copy of the state in memory. The result
//                   does not depend on it.
// Each seat is a fresh load of the state file, so the seats are independent of one another.
namespace rsp58 {
static double num(const JV *v, double def = NAN) { return v && v->type == J_NUM ? v->num : def; }
static std::string bitsOf(double v) { uint64_t u; std::memcpy(&u, &v, sizeof u); char b[20]; std::snprintf(b, sizeof b, "%016llx", (unsigned long long)u); return b; }   // IEEE 754 bit pattern (no reader can re-round it)
static int run(int argc, char **argv) {
  if (argc < 5 || argc > 6) { std::fprintf(stderr, "usage: mwcli --response spec.json state request.json [memoryMiB]\n"); return 2; }
  std::vector<unsigned char> spec = slurp(argv[2]), reqBytes = slurp(argv[4]); char err[512] = ""; double mib = 4096;
  if (argc == 6 && !numberArg(argv[5], mib)) { std::fprintf(stderr, "error: bad memoryMiB\n"); return 2; }
  if (spec.empty()) { std::fprintf(stderr, "cannot read %s\n", argv[2]); return 2; }
  size_t skip = reqBytes.size() >= 3 && reqBytes[0] == 0xEF && reqBytes[1] == 0xBB && reqBytes[2] == 0xBF ? 3 : 0;
  JV *req = json_parse((const char *)reqBytes.data() + skip, reqBytes.size() - skip, err, sizeof err);
  if (!req || req->type != J_OBJ) { std::fprintf(stderr, "error: request: %s\n", req ? "must be a JSON object" : err); if (req) json_free(req); return 2; }
  struct FreeReq { JV *v; ~FreeReq() { json_free(v); } } freeReq{req};
  static const char *known[] = {"seats", "responseDeals", "seed", "threads", "samples", "exact", "exactMaxVisits", "timeLimitMs", "saveStates", "futureActions", "parallelSeats"};
  for (int i = 0; i < req->n; i++) { bool ok = false; for (const char *k : known) ok |= !std::strcmp(k, req->keys[i]); if (!ok) { std::fprintf(stderr, "error: unknown request field \"%s\"\n", req->keys[i]); return 2; } }
  auto whole = [&](const char *name, long long lo, long long hi, long long def, long long &out) {
    const JV *v = jget(req, name); if (!v) { out = def; return true; }
    if (v->type != J_NUM || !std::isfinite(v->num) || std::floor(v->num) != v->num || v->num < (double)lo || v->num > (double)hi) { std::fprintf(stderr, "error: %s must be a whole number from %lld to %lld\n", name, lo, hi); return false; }
    out = (long long)v->num; return true;
  };
  long long deals, seed, threads, samples, exactVisits, timeMs, parallelSeats;
  if (!whole("parallelSeats", 1, 8, 1, parallelSeats)) return 2;
  if (!whole("responseDeals", 1, 640000000LL, 200000, deals) || !whole("seed", 0, 4294967295LL, 1, seed) || !whole("threads", 1, 256, 1, threads) ||
      !whole("samples", 1024, 1000000000LL, 200000, samples) || !whole("exactMaxVisits", 1000, 2000000000LL, 2000000000LL, exactVisits) || !whole("timeLimitMs", 100, 86400000, 3600000, timeMs)) return 2;
  const JV *ex = jget(req, "exact"); if (ex && ex->type != J_BOOL) { std::fprintf(stderr, "error: exact must be true or false\n"); return 2; }
  const bool exact = ex && ex->num != 0;
  const JV *sv = jget(req, "saveStates"); if (sv && sv->type != J_STR) { std::fprintf(stderr, "error: saveStates must be a string\n"); return 2; }
  const JV *fa = jget(req, "futureActions"); std::string future = "auto";
  if (fa) { if (fa->type != J_STR || (std::strcmp(fa->str, "auto") && std::strcmp(fa->str, "enumerate") && std::strcmp(fa->str, "sample"))) { std::fprintf(stderr, "error: futureActions must be auto, enumerate or sample\n"); return 2; } future = fa->str; }
  const std::string prefix = sv ? sv->str : ""; const std::string text((const char *)spec.data(), spec.size());
  auto load = [&](MW *&m) {
    uint64_t size = 0; std::string why; FILE *f = openCheckpoint(argv[3], size, why);
    if (!f) { std::fprintf(stderr, "error: cannot read state '%s': %s\n", argv[3], why.c_str()); return false; }
    const int st = mw_load_stream(f, size, text.c_str(), mib, -1, &m, err, sizeof err, nullptr, nullptr); std::fclose(f);
    if (st != 200) { std::fprintf(stderr, "error: state '%s' was refused (status %d): %s\n", argv[3], st, err[0] ? err : "unreadable"); return false; }
    return true;
  };
  MW *probe = nullptr; if (!load(probe)) return 1;
  JB info; jb_init(&info); mw_info(probe, &info); JV *iv = json_parse(info.s, info.n, err, sizeof err); jb_free(&info);
  JV *sj = json_parse(text.c_str(), text.size(), err, sizeof err);   // the state was accepted for this spec, so the spec parses
  const int players = (int)num(sj ? jget(sj, "n") : nullptr, 0), batch = std::max(1, (int)num(sj ? jget(sj, "batchDeals") : nullptr, 1));
  if (sj) json_free(sj);
  const long long sourceUpdates = (long long)num(iv ? jget(iv, "iterations") : nullptr, 0), sourceDeals = (long long)num(iv ? jget(iv, "trainingDeals") : nullptr, 0);
  if (iv) json_free(iv);
  mw_free(probe);
  if (players < 2 || players > 8) { std::fprintf(stderr, "error: the state reports no player count\n"); return 1; }
  std::vector<int> seats;
  if (const JV *s = jget(req, "seats")) {
    if (s->type != J_ARR || s->n < 1 || s->n > 8) { std::fprintf(stderr, "error: seats must be an array of 1 to 8 seat numbers\n"); return 2; }
    for (int i = 0; i < s->n; i++) { const JV *x = s->items[i]; if (x->type != J_NUM || std::floor(x->num) != x->num || x->num < 0 || x->num >= players) { std::fprintf(stderr, "error: seats must hold whole numbers from 0 to %d\n", players - 1); return 2; }
      for (int q : seats) if (q == (int)x->num) { std::fprintf(stderr, "error: seats lists a seat twice\n"); return 2; }
      seats.push_back((int)x->num); }
  } else for (int p = 0; p < players; p++) seats.push_back(p);
  const long long updates = (deals + batch - 1) / batch;
  if (updates > 10000000LL) { std::fprintf(stderr, "error: responseDeals needs %lld updates of %d deals; the engine trains at most 10,000,000 updates per state (nothing was started)\n", updates, batch); return 2; }
  JB o; jb_init(&o);
  jb_printf(&o, "{\"tool\":\"mwcli response 5.8\",\"build\":\"%s\",\"version\":\"%s\",\"players\":%d,\"sourceUpdates\":%lld,\"sourceDeals\":%lld,\"batchDeals\":%d,\"responseDealsPerSeat\":%lld,\"responseUpdatesPerSeat\":%lld,\"evaluationSamplesRequested\":%lld,\"seed\":%lld,\"threads\":%lld,\"parallelSeats\":%lld,\"exactRequested\":%s",
            EM_BUILD_ID, EM_VERSION, players, sourceUpdates, sourceDeals, batch, updates * batch, updates, samples, seed, threads, parallelSeats, exact ? "true" : "false");
  jb_puts(&o, ",\"measure\":\"trained response: per seat, the gain of the average strategy of a response training against the other seats' average strategies\",\"direction\":\"each seat gain is a lower bound of that seat's best-response gain; their sum is a lower bound of NashConv inside the study's betting abstraction. Not an upper bound; not exploitability for more than two seats or an ICM utility.\",\"seats\":[");
  double sum = 0, var = 0, sumFloor = 0, exactSum = 0, exactBr = 0; bool allSampled = true, allExact = exact; const auto t0 = std::chrono::steady_clock::now();
  // One seat = one fresh load of the state, its own response training and its own evaluation streams, so the seats
  // are independent of one another and of the order and number of threads that run them ("parallelSeats").
  struct SeatOut { std::string json, error; int exitCode = 0; double mean = NAN, se = NAN, exactGain = NAN, brGain = NAN; bool sampled = false, exactOk = false; };
  std::vector<SeatOut> outs(seats.size());
  std::mutex loadMu;
  auto runSeat = [&](size_t si) {
    SeatOut &R = outs[si]; const int seat = seats[si]; char err[512] = ""; JB o; jb_init(&o); struct FreeO { JB *b; ~FreeO() { jb_free(b); } } freeO{&o};
    auto fail = [&](int code, const std::string &text) { R.exitCode = code; R.error = text; };
    MW *m = nullptr;
    { std::lock_guard<std::mutex> l(loadMu);   // load() reports through the shared error buffer
      uint64_t size = 0; std::string why; FILE *f = openCheckpoint(argv[3], size, why);
      if (!f) { fail(1, std::string("cannot read state '") + argv[3] + "': " + why); return; }
      const int st = mw_load_stream(f, size, text.c_str(), mib, -1, &m, err, sizeof err, nullptr, nullptr); std::fclose(f);
      if (st != 200) { fail(1, std::string("state '") + argv[3] + "' was refused (status " + std::to_string(st) + "): " + (err[0] ? err : "unreadable")); return; } }
    struct FreeM { MW *m; ~FreeM() { mw_free(m); } } freeM{m};
    char rq[256]; std::snprintf(rq, sizeof rq, "{\"seat\":%d,\"seed\":%lld}", seat, seed);
    JB b; jb_init(&b); int st = mw_response_begin(m, rq, std::strlen(rq), &b, err, sizeof err);
    if (st != 200) { jb_free(&b); fail(1, "seat " + std::to_string(seat) + ": " + err); return; }
    jb_printf(&o, "{\"seat\":%d,\"begin\":%.*s", seat, (int)b.n, b.s); jb_free(&b);
    const auto a0 = std::chrono::steady_clock::now();
    if (!mw_train(m, updates, (int)threads, nullptr, nullptr, nullptr, err, sizeof err)) { fail(1, "seat " + std::to_string(seat) + ": response training failed: " + err); return; }
    const double trainSeconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - a0).count();
    jb_init(&b); st = mw_response_end(m, &b, err, sizeof err);
    if (st != 200) { jb_free(&b); fail(1, "seat " + std::to_string(seat) + ": " + err); return; }
    jb_printf(&o, ",\"trainingSeconds\":%.6f,\"end\":%.*s", trainSeconds, (int)b.n, b.s); jb_free(&b);
    { JB mi; jb_init(&mi); mw_info(m, &mi); JV *v = json_parse(mi.s, mi.n, err, sizeof err); jb_free(&mi);
      if (v) { jb_puts(&o, ",\"tableMiB\":"); jb_printf(&o, "%.6f", num(jget(v, "tableMiB"), 0)); json_free(v); } }
    if (!prefix.empty()) {
      const std::string path = prefix + std::to_string(seat) + ".state"; SaveReport rep;
      saveWithReport(path.c_str(), [&](FILE *f) { return mw_write_stream(m, f, nullptr) > 0; }, rep);
      if (!rep.ok) { fail(4, "cannot write '" + path + "': " + rep.text()); return; }
      jb_puts(&o, ",\"savedState\":"); jb_str(&o, path.c_str());
    }
    char vq[256]; std::snprintf(vq, sizeof vq, "{\"samples\":%lld,\"seed\":%lld,\"threads\":%lld,\"timeLimitMs\":%lld,\"futureActions\":\"%s\"}", samples, seed, std::min<long long>(threads, 64), timeMs, future.c_str());
    jb_init(&b); volatile int cancel = 0; st = mw_response_value(m, vq, std::strlen(vq), &b, err, sizeof err, &cancel);
    if (st != 200) { jb_puts(&o, ",\"sampled\":{\"available\":false,\"reason\":"); jb_str(&o, err); jb_putc(&o, '}'); }
    else {
      jb_printf(&o, ",\"sampled\":%.*s", (int)b.n, b.s);
      JV *v = json_parse(b.s, b.n, err, sizeof err); const JV *g = v ? jget(v, "gain") : nullptr; R.mean = num(g ? jget(g, "mean") : nullptr); R.se = num(g ? jget(g, "stdErr") : nullptr);
      R.sampled = std::isfinite(R.mean) && std::isfinite(R.se);
      if (v) json_free(v);
    }
    jb_free(&b);
    if (exact) {
      double pv[2] = {NAN, NAN}, br[2] = {NAN, NAN}; std::string why; double exactSeconds = 0;
      for (int which = 0; which < 2 && why.empty(); which++) {
        char eq[400]; std::snprintf(eq, sizeof eq, "{\"method\":\"exact\",\"seats\":[%d],\"policy\":\"%s\",\"device\":\"cpu\",\"threads\":1,\"timeLimitMs\":%lld,\"maxVisits\":%lld,\"memoryMiB\":1024}", seat, which ? "current" : "average", timeMs, exactVisits);
        jb_init(&b); const auto e0 = std::chrono::steady_clock::now(); st = mw_response_gain(m, eq, std::strlen(eq), &b, err, sizeof err, &cancel);
        exactSeconds += std::chrono::duration<double>(std::chrono::steady_clock::now() - e0).count();
        if (st != 200) why = err;
        else { JV *v = json_parse(b.s, b.n, err, sizeof err); const JV *ss = v ? jget(v, "seats") : nullptr; const JV *s0 = ss && ss->type == J_ARR && ss->n == 1 ? ss->items[0] : nullptr;
          pv[which] = num(s0 ? jget(s0, "policyValue") : nullptr); br[which] = num(s0 ? jget(s0, "bestResponseValue") : nullptr); if (v) json_free(v);
          if (!std::isfinite(pv[which]) || !std::isfinite(br[which])) why = "the exact evaluator returned no value"; }
        jb_free(&b);
      }
      if (!why.empty()) { jb_puts(&o, ",\"exact\":{\"available\":false,\"reason\":"); jb_str(&o, why.c_str()); jb_putc(&o, '}'); }
      else {
        // average = (response, sigma_-seat); current = sigma. The best response to sigma_-seat is the same in both.
        R.exactGain = pv[0] - pv[1]; R.brGain = br[1] - pv[1]; R.exactOk = true;
        jb_printf(&o, ",\"exact\":{\"available\":true,\"policyValue\":%.17g,\"responseValue\":%.17g,\"gain\":%.17g,\"bestResponseValue\":%.17g,\"bestResponseValueFromResponseProfile\":%.17g,\"bestResponseGain\":%.17g,\"shareOfBestResponseGain\":", pv[1], pv[0], R.exactGain, br[1], br[0], R.brGain);
        if (R.brGain > 0) jb_printf(&o, "%.17g", R.exactGain / R.brGain); else jb_puts(&o, "null");
        jb_printf(&o, ",\"gainBits\":\"%s\",\"bestResponseGainBits\":\"%s\",\"seconds\":%.3f}", bitsOf(R.exactGain).c_str(), bitsOf(R.brGain).c_str(), exactSeconds);
      }
    }
    jb_putc(&o, '}');
    R.json.assign(o.s ? o.s : "", o.n);
  };
  { std::atomic<size_t> next{0}; std::vector<std::thread> pool; const size_t workers = (size_t)std::max<long long>(1, std::min<long long>(parallelSeats, (long long)seats.size()));
    auto body = [&] { for (size_t i; (i = next.fetch_add(1)) < seats.size();) runSeat(i); };
    for (size_t w = 1; w < workers; w++) pool.emplace_back(body);
    body(); for (auto &t : pool) t.join(); }
  for (size_t si = 0; si < seats.size(); si++) {
    const SeatOut &R = outs[si];
    if (R.exitCode) { std::fprintf(stderr, "error: %s\n", R.error.c_str()); jb_free(&o); return R.exitCode; }
    if (si) jb_putc(&o, ','); jb_putn(&o, R.json.data(), R.json.size());
    if (R.sampled) { sum += R.mean; var += R.se * R.se; sumFloor += std::max(0.0, R.mean - 1.6448536269514722 * R.se); } else allSampled = false;
    if (exact) { if (R.exactOk) { exactSum += R.exactGain; exactBr += R.brGain; } else allExact = false; }
  }
  jb_puts(&o, "]");
  const bool every = (int)seats.size() == players;
  jb_printf(&o, ",\"summary\":{\"seatsEvaluated\":%zu,\"allSeats\":%s", seats.size(), every ? "true" : "false");
  if (allSampled) {
    jb_printf(&o, ",\"sumOfSeatGains\":{\"mean\":%.17g,\"stdErr\":%.17g,\"ci95\":[%.17g,%.17g]}", sum, std::sqrt(var), sum - 1.959963984540054 * std::sqrt(var), sum + 1.959963984540054 * std::sqrt(var));
    jb_printf(&o, ",\"sumOfSeatLowerBounds95\":%.17g", sumFloor);
    jb_puts(&o, every ? ",\"reading\":\"sumOfSeatGains estimates a lower bound of NashConv (the seats' evaluation samples are independent, so the standard errors add in quadrature). sumOfSeatLowerBounds95 adds the per-seat one-sided 95% bounds, each floored at 0; it is conservative and is not itself a 95% statement about the sum.\""
                      : ",\"reading\":\"not every seat was evaluated: the sum is a lower bound of the evaluated seats' share of NashConv only\"");
  }
  if (exact && allExact) { jb_printf(&o, ",\"exactSumOfSeatGains\":%.17g,\"exactSumOfBestResponseGains\":%.17g,\"exactShare\":", exactSum, exactBr); if (exactBr > 0) jb_printf(&o, "%.17g", exactSum / exactBr); else jb_puts(&o, "null");
    if (every) jb_puts(&o, ",\"exactNashConv\":"), jb_printf(&o, "%.17g", exactBr); }
  jb_printf(&o, "},\"wallSeconds\":%.3f,\"processPeakRssMiB\":%.1f}", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count(), peakRssMiB());
  std::printf("%.*s\n", (int)o.n, o.s); jb_free(&o);
  return 0;
}
}
