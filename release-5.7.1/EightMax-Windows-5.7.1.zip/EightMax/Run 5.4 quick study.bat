@echo off
cd /d "%~dp0"
mwcli.exe --study studies\known-akq-river.emfix.json EightMax-5.4-quick-study.json preset=quick processingMode=cpu
pause
