# EightMax Windows 5.4

Build `980f82b97a922d4d`. Calculation identifier remains `study-5.3-tfloor-bonferroni-v1`, because its statistical interpretation is preserved.

## Implemented

- Bounded policy reuse in exact best-response traversal; eight local slots per opponent node, with bitwise A/B checks and preserved logical coverage counters.
- `largestUnilateralGain` alongside exact NashConv; two-player chip-EV exploitability remains NashConv / 2.
- Native Quick, Standard, Deep and Research study controls; explicit settings override preset defaults.
- Adjustable evaluation samples, time, memory, threads and processing mode in the desktop and CLI. Quality evaluation now receives the requested cache budget. Evaluation threads are capped to the evaluator's supported 64 independently of training threads.
- Desktop status now publishes whole progress JSON atomically instead of truncating a fixed 512-byte buffer; a long-name/progress cancellation regression guards the repair.
- Periodic training diagnostics: algorithm, deals, observed device, table memory and peak process RAM. JSON adds effective per-variant evaluation settings and training diagnostics; CSV appends preset, mode and confidence fields.
- Reproducible convergence, performance, independent-reference, statistical, compatibility and interruption validation. The 5.3 statistics and calculation identifier are intentionally unchanged.

## Evidence and interpretation

The default training algorithm is unchanged. 60/60 equal-deal baseline/current checkpoint pairs are byte-identical. Thus 5.4 does not improve default strategy accuracy at equal sampled deals. Candidate experiments yielded {'unresolved': 28, 'worse': 20} across 48 completed contrasts, corrected over the original 72-contrast family. Another 24 exact ICM contrasts were not completed because of runtime cost. No candidate showed a statistically supported improvement.

The development regression passed 549 of 551 tests. The progress-buffer failure was repaired; a timing failure passed its unchanged isolated rerun. The final-source suite passed 551 of 552 tests, and its sole CPU-load timing failure passed an unchanged isolated rerun, giving 552 distinct passing checks. No tests were skipped. The 22 sanitizer checks, 28 independent reference checks and 4,304 DOM/event/export assertions passed. Raw failures, repairs and reruns remain in validation/5.4.

New statistical stress tests reproduced the rare-tail limitation: conditional simultaneous coverage 86.5667%, Wilson 95% interval [85.2995%, 87.7403%]. This is a synthetic known-error stress scenario, not measured coverage on all poker games. The failure is retained and disclosed in the UI.

## Limits

Native Windows execution/UI and physical RTX 4060 Ti testing are unavailable. Linux timing is not a prediction for the user's 13th-generation i7. Simulated CUDA checks establish fallback/integration behavior only. Leak checking was disabled; address/undefined-behaviour checks are separate evidence. There is no full-game GTO certificate.

Not implemented: a new learned variance-reduction estimator; adaptive sequential evaluation; selectable confidence levels; automatic study-level checkpoint/resume; new CUDA kernels; a global process-memory limit; a continuous evaluation percentage or reliable ETA. Existing solver checkpoints and partial study results remain supported. See `validation/5.4/NOT-IMPLEMENTED.md`.

## Use

Extract into a new folder and run `EightMax.exe`. No separate Python or Node runtime is required for the Windows application. Development/research scripts have their own dependencies. Read USER-GUIDE-5.4.md.
