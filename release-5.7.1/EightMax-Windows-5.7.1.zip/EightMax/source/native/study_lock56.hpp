// EightMax 5.6: one process at a time per study checkpoint directory.
//
// 5.5 checked that a checkpoint existed, matched the study and was intact, but nothing stopped two processes (a
// second "Resume" from the command line while the desktop host was already continuing the study, or the same batch
// file started twice) from loading the same manifest and then committing over each other: both would pass every
// check, both would write generations of the same job files, and each would delete the generation the other's
// manifest names. 5.6 takes an operating-system lock on `study.lock` in the directory for as long as the study
// runs. The lock belongs to the open file handle, so it disappears with the process however the process ends
// (normal exit, Stop, a kill, a crash): there is no stale-lock state to clean up and no process id to trust.
//   POSIX:   open(study.lock) + flock(LOCK_EX | LOCK_NB); the path is re-checked after locking so a holder that
//            unlinked the file while releasing cannot leave two processes locking different inodes.
//   Windows: CreateFile with no sharing and FILE_FLAG_DELETE_ON_CLOSE.
// A second process is refused with HTTP-style status 409 and changes nothing. Network file systems that do not
// implement these locks are outside what this protects.
#pragma once
#include <string>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
#endif
namespace study56 {
struct DirectoryLock {
  std::string path; bool held = false;
#ifdef _WIN32
  HANDLE h = INVALID_HANDLE_VALUE;
  bool acquire(const std::string &dir, std::string &why) {
    path = dir + "\\study.lock";
    h = CreateFileA(path.c_str(), GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_DELETE_ON_CLOSE, nullptr);
    if (h == INVALID_HANDLE_VALUE) { const DWORD e = GetLastError(); why = e == ERROR_SHARING_VIOLATION || e == ERROR_ACCESS_DENIED ? "another running study holds it" : "the lock file could not be opened (Windows error " + std::to_string((unsigned long)e) + ")"; return false; }
    held = true; return true;
  }
  void release() { if (h != INVALID_HANDLE_VALUE) { CloseHandle(h); h = INVALID_HANDLE_VALUE; } held = false; }
#else
  int fd = -1;
  bool acquire(const std::string &dir, std::string &why) {
    path = dir + "/study.lock";
    for (int attempt = 0; attempt < 8; attempt++) {
      fd = ::open(path.c_str(), O_RDWR | O_CREAT | O_CLOEXEC, 0600);
      if (fd < 0) { why = std::string("the lock file could not be opened (") + std::strerror(errno) + ")"; return false; }
      if (::flock(fd, LOCK_EX | LOCK_NB) != 0) { const int e = errno; ::close(fd); fd = -1; why = e == EWOULDBLOCK ? "another running study holds it" : std::string("the lock could not be taken (") + std::strerror(e) + ")"; return false; }
      struct stat a, b;   // the file we locked must still be the file at the path
      if (::fstat(fd, &a) == 0 && ::stat(path.c_str(), &b) == 0 && a.st_ino == b.st_ino && a.st_dev == b.st_dev) { held = true; return true; }
      ::close(fd); fd = -1;
    }
    why = "the lock file kept changing"; return false;
  }
  void release() { if (fd >= 0) { ::unlink(path.c_str()); ::close(fd); fd = -1; } held = false; }
#endif
  DirectoryLock() = default; DirectoryLock(const DirectoryLock &) = delete; DirectoryLock &operator=(const DirectoryLock &) = delete;
  ~DirectoryLock() { release(); }
};
}
