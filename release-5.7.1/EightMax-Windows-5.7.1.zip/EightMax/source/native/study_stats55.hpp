// EightMax 5.5 study uncertainty: bounded-payoff conditional intervals.
// See STATISTICAL-VALIDATION-5.5.md for estimands, assumptions, proofs used and limits.
//
// WHY. The 5.3/5.4 conditional interval was mean +/- t * SE. A Student-t (or normal) quantile is a
// statement about the SHAPE of the sampling distribution of the evaluation mean. With rare, large
// payoffs (an all-in pot reached once in a few thousand samples) that distribution is far from
// normal at practical sample counts AND the estimated SE is itself too small whenever the rare event
// was not drawn. The 5.4 rare-tail experiment (86.6% observed for a nominal 95%) is that failure.
// No interval that sees only (mean, SE) can be valid for all distributions (Bahadur & Savage 1956).
//
// WHAT. Poker utilities are bounded: a seat cannot lose more than it can put in, nor win more than
// the others can put in (chips), and tournament equity lies between the smallest and largest payout.
// For n i.i.d. samples X_i in an interval of width R with unbiased sample variance V_n, Maurer &
// Pontil (2009, Theorem 4) prove for every delta in (0,1), with probability at least 1 - delta,
//     mean(X) - E[X] <= sqrt(2 V_n ln(2/delta) / n) + 7 R ln(2/delta) / (3 (n - 1)).
// Applied to X and -X (delta/2 each) this gives the two-sided half-width ebHalf() below at level
// delta. It is a finite-sample, distribution-free statement GIVEN: (a) i.i.d. samples, (b) equal
// weights, (c) a true bound R on the range, (d) n fixed in advance (no stopping on the values).
// The action evaluator supplies (a), (b), (d) by construction (action_stats.hpp header) and (c)
// from the betting rules (action_ev.hpp utilityBounds); a sample outside the declared bound
// withdraws the calibration claim instead of being ignored.
//
// Several trained strategies r = 1..m: every seed gets level delta/m; by the union bound all m
// per-seed intervals hold together with probability >= 1 - delta, hence so does the interval for
// the MEAN of their true values, mean(Y_r) +/- sum(h_r)/m. No independence between the seeds'
// evaluation streams is needed, so shared streams are covered as well.
// Multiplicity: delta = alpha / family (Bonferroni), family fixed before measurement.
//
// NOT COVERED (reported as uncalibrated, never silently approximated): evaluations without a
// payoff bound or sample count (older documents), sampled quality (a product of two estimates with
// a data-dependent selection step), and the interval across independent TRAININGS, whose
// distribution over seeds is unknown and for which 2-10 replications support only the model-based
// Student-t interval of study_stats53.hpp.
#pragma once
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
namespace study55 {
constexpr const char *CALCULATION = "study-5.5-bounded-eb-v1";
constexpr const char *METHOD = "empirical Bernstein (Maurer-Pontil 2009, Theorem 4), two-sided, union bound over trained strategies, Bonferroni over the declared family";
// Two-sided half-width at level delta for the mean of n i.i.d. samples with range <= `range`.
// Never larger than the range itself (|mean - E| <= R always holds).
inline double ebHalf(double sampleVariance, double range, double n, double delta) {
  if (!(n >= 2 && range >= 0 && delta > 0 && delta < 1 && sampleVariance >= 0) || !std::isfinite(range) || !std::isfinite(sampleVariance)) return NAN;
  const double L = std::log(4 / delta);
  return std::min(range, std::sqrt(2 * sampleVariance * L / n) + 7 * range * L / (3 * (n - 1)));
}
struct Bounded {
  bool calibrated = false, exact = false; double half = NAN, lo = NAN, hi = NAN, delta = NAN;
  const char *reason = "notEvaluated";   // why no calibrated statement is made (empty when calibrated)
};
// mean: mean of the per-strategy estimates. se[r]: standard error of estimate r (sqrt(V_n/n));
// n[r]: its sample count; range[r]: proven width of the sample range (NAN: unknown);
// within[r]: every observed sample lay inside the declared bound.
inline Bounded conditional(double mean, const std::vector<double> &se, const std::vector<double> &n, const std::vector<double> &range,
                           const std::vector<char> &within, const std::vector<char> &exactEvaluation, int family, double alpha = .05) {
  Bounded b; const size_t m = se.size();
  if (!m || !std::isfinite(mean)) { b.reason = "noData"; return b; }
  if (n.size() != m || range.size() != m || within.size() != m || exactEvaluation.size() != m) { b.reason = "noPayoffBound"; return b; }
  b.delta = alpha / std::max(1, family) / (double)m; double sum = 0; bool allExact = true;
  for (size_t r = 0; r < m; r++) {
    if (!std::isfinite(se[r]) || se[r] < 0) { b.reason = "evaluationErrorUnavailable"; return b; }
    // Exactness is DECLARED by the evaluator, never inferred from a zero standard error: a sampled
    // evaluation whose samples happen to be identical (the rare event was not drawn) has SE 0 too.
    if (exactEvaluation[r]) continue;
    allExact = false;
    if (!std::isfinite(range[r]) || range[r] < 0) { b.reason = "noPayoffBound"; return b; }
    if (!within[r]) { b.reason = "payoffBoundViolated"; return b; }
    if (!(n[r] >= 2)) { b.reason = "tooFewSamples"; return b; }
    const double h = ebHalf(se[r] * se[r] * n[r], range[r], n[r], b.delta);
    if (!std::isfinite(h)) { b.reason = "evaluationErrorUnavailable"; return b; }
    sum += h;
  }
  b.calibrated = true; b.exact = allExact; b.half = sum / (double)m; b.lo = mean - b.half; b.hi = mean + b.half; b.reason = ""; return b;
}
inline const char *reasonText(const char *code) {
  const std::string c = code ? code : "";
  if (c.empty()) return "";
  if (c == "noPayoffBound") return "no proven payoff bound or sample count accompanies these evaluations (for example a document from an earlier version); only a normal-approximation interval exists and it is not calibrated for rare large payoffs";
  if (c == "payoffBoundViolated") return "an evaluated sample lay outside the declared payoff bound; the bounded-payoff interval is withdrawn";
  if (c == "tooFewSamples") return "fewer than two evaluation samples";
  if (c == "sampledQuality") return "sampled quality multiplies a conditional gain by an estimated reach probability after a data-dependent selection; no finite-sample bound is implemented for it";
  if (c == "evaluationErrorUnavailable") return "an evaluation standard error is unavailable";
  return "no calibrated statement is available";
}
}
