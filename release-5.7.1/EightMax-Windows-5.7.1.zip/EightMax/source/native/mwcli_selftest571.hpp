// EightMax 5.7.1: mwcli --selftest571 <studies-dir> <work-dir> [all|checkpoint|memory] [keep]
//
// The two weaknesses the physical Windows run of the 5.7 validation found, tested by the shipped program itself
// (nothing but mwcli is needed; "Run 5.7.1 focused validation.bat" runs it first and validate_windows571.ps1
// imports its report):
//
//   checkpoint   The 5.7 script changed only white space in manifest.json and expected a refusal. The manifest's
//                bodySha256 covers the CANONICAL serialisation of the parsed body (study_checkpoint55.hpp), so white
//                space is not data and the engine was right to resume. These checks damage what the integrity
//                data really covers and require the documented reaction to each kind of damage:
//                  P  an untouched copy resumes (positive control)
//                  A  white space only: accepted, identical result
//                  B  a recorded measurement altered without updating bodySha256: detected (previous manifest
//                     used; refused when both manifests are altered)
//                  C  bodySha256 altered, body untouched: detected (same two outcomes)
//                  D  an engine state with a flipped byte, and a truncated one: discarded by its SHA-256/length,
//                     the seed retrained, the result unchanged
//                  E  two committed generations, the newest damaged: the verified previous one is used; a process
//                     killed during the first commit after such a recovery still leaves a usable checkpoint
//                     (the engine repair of 5.7.1)
//                  F  a missing state file, a missing manifest.json, both manifests missing
//                  S  the source checkpoint the copies were made from is byte-identical at the end
//   memory       The 5.7 script gave a small fixture a 24 MiB process budget it never reached (peak 8.4 MiB) and
//                accepted the normal completion. These checks use a fixture whose tables grow well past the
//                budget and require the stop itself:
//                  E  control: with the automatic budget the study completes and reports no memory stop
//                  A  with a 48 MiB budget the study is stopped by the budget, incomplete and resumable
//                  B  resumed with the automatic budget it completes with the measurements of the control
//                  C  what the result document and the checkpoint say about memory
//                  D  invalid budgets are refused; a budget below what the process needs before any training
//                     stops at once, keeps a valid checkpoint and resumes
//   controls     the verdict functions used above are applied to observations they must reject (a normal
//                completion is not a memory stop, a successful resume is not a refusal, a fall-back is not an
//                untouched resume), so a check cannot pass merely because a process exited with status 0.
//
// Every study is a separate mwcli process, recorded with its command, exit status, standard output and standard
// error. Everything is written inside <work-dir>; corruption is applied to COPIES of one source checkpoint, which is
// verified unchanged at the end. Each check has a status:
//   passed    the intended condition was produced and the engine reacted as documented
//   failed    the engine did not react as documented, or the condition the check is about did not occur
//   untested  a step this check depends on could not be carried out (the reason is given); never counted as passed
// The report is <work-dir>/selftest571.json. Exit status: 0 every check passed, 1 a check failed or is untested,
// 2 usage or unreadable fixtures.
#pragma once
#include <algorithm>
#include <initializer_list>
#include <sstream>
namespace st571 {
namespace fs = std::filesystem;
using Env = std::vector<std::pair<std::string, std::string>>;

inline std::string readFile(const std::string &p) { const auto b = slurp(p.c_str()); return std::string(b.begin(), b.end()); }
inline bool writeFile(const std::string &p, const std::string &s) { FILE *f = std::fopen(p.c_str(), "wb"); if (!f) return false; const bool ok = std::fwrite(s.data(), 1, s.size(), f) == s.size(); return std::fclose(f) == 0 && ok; }
inline std::string shaText(const std::string &s) { emsha::Sha256 h; h.add(s.data(), s.size()); return h.hex(); }
inline std::string shaFile(const std::string &p) { return emsha::fileHex(p.c_str()); }
inline bool has(const std::string &s, const char *what) { return s.find(what) != std::string::npos; }
inline std::string oneLine(std::string s, size_t max = 400) { for (char &c : s) if (c == '\n' || c == '\r' || c == '\t') c = ' '; while (!s.empty() && s.back() == ' ') s.pop_back(); return s.size() > max ? s.substr(0, max) + "..." : s; }

// ---- parsed JSON ----
struct Json {
  JV *v = nullptr;
  Json() = default;
  explicit Json(const std::string &text) { char e[160] = ""; if (!text.empty()) v = json_parse(text.c_str(), text.size(), e, sizeof e); }
  Json(const Json &) = delete; Json &operator=(const Json &) = delete;
  Json(Json &&o) noexcept : v(o.v) { o.v = nullptr; }
  Json &operator=(Json &&o) noexcept { if (this != &o) { if (v) json_free(v); v = o.v; o.v = nullptr; } return *this; }
  ~Json() { if (v) json_free(v); }
  explicit operator bool() const { return v != nullptr; }
};
inline const JV *get(const JV *o, const char *k) { return o && o->type == J_OBJ ? jget(o, k) : nullptr; }
inline const JV *dig(const JV *o, std::initializer_list<const char *> keys) { for (const char *k : keys) o = get(o, k); return o; }
inline std::string str(const JV *v) { return v && v->type == J_STR && v->str ? v->str : ""; }
inline double num(const JV *v, double fallback = NAN) { return v && v->type == J_NUM ? v->num : fallback; }
inline bool truth(const JV *v) { return v && v->type == J_BOOL && v->num != 0; }
inline int count(const JV *v) { return v && v->type == J_ARR ? v->n : 0; }
inline std::string nums(const JV *a) { std::string s; for (int i = 0; i < count(a); i++) s += (i ? "," : "") + mwa::fmt(num(a->items[i])); return s; }

// The measurements of a study result, one line per (variant, seed, budget): status, sampled deals, action EVs,
// action frequencies and the quality value, every number with 17 significant digits. Two studies with the same
// text have the same final mathematical state; timings and memory readings are not part of it.
inline std::string measurements(const JV *doc) {
  std::string s; const JV *vs = get(doc, "variants");
  for (int i = 0; i < count(vs); i++) { const JV *v = vs->items[i], *seeds = get(v, "perSeed");
    for (int j = 0; j < count(seeds); j++) { const JV *budgets = get(seeds->items[j], "budgets");
      for (int k = 0; k < count(budgets); k++) { const JV *p = budgets->items[k];
        s += str(get(v, "name")) + "|" + mwa::fmt(num(get(seeds->items[j], "seed"))) + "|" + mwa::fmt(num(get(p, "budgetDeals"))) + "|" + str(get(p, "status")) + "|" + mwa::fmt(num(get(p, "deals"))) + "|" + nums(get(p, "ev")) + "|" + nums(get(p, "frequency")) + "|" + mwa::fmt(num(get(p, "quality"))) + "\n"; } } }
  return s;
}

// ---- what one `mwcli --study` process did ----
struct Obs {
  std::string label, command, out, stdoutText, stderrText, startError;
  int exitCode = -1; bool started = false, timedOut = false; double ms = 0;
  bool wrote = false;                 // the result file exists and parses
  bool complete = false, resumable = false, resumed = false, stoppedByMemory = false, budgetAutomatic = false, checkpointEnabled = false;
  std::string status, resumedFrom, resumeNote, points, memoryNote; std::vector<std::string> warnings;
  long long pointsCompleted = 0, pointsRequested = 0, pointsRestored = 0; int parallelSeeds = 0, threadsPerSeed = 0;
  double peakRss = NAN, budget = NAN, physical = NAN, tableBudget = NAN, evaluationMemory = NAN, perSeedAllowance = NAN;
  double lastTableMiB = NAN;          // tableMiB of the last budget of the first seed (how large the workload grows)
  std::string stoppedPoint;           // "seed S, budget B: deals D of B" for the point stopped by the memory budget
  long long stoppedDeals = -1, stoppedBudget = -1;
  bool anyWarning(const char *a, const char *b = "") const { for (const auto &w : warnings) if (has(w, a) && has(w, b)) return true; return false; }
};
inline void fill(Obs &o) {
  const std::string text = readFile(o.out); Json doc(text); if (!doc) return;
  const JV *d = doc.v, *run = get(d, "run"), *ck = get(run, "checkpoint"), *cp = get(d, "completion");
  if (!run || !cp) return;
  o.wrote = true; o.complete = truth(get(cp, "complete")); o.status = str(get(cp, "status")); o.resumable = truth(get(cp, "resumable"));
  o.pointsCompleted = (long long)num(get(cp, "pointsCompleted"), 0); o.pointsRequested = (long long)num(get(cp, "pointsRequested"), 0);
  o.checkpointEnabled = truth(get(ck, "enabled")); o.resumed = truth(get(ck, "resumed")); o.resumedFrom = str(get(ck, "resumedFrom")); o.resumeNote = str(get(ck, "resumeNote")); o.pointsRestored = (long long)num(get(ck, "pointsRestored"), 0);
  const JV *w = get(ck, "warnings"); for (int i = 0; i < count(w); i++) o.warnings.push_back(str(w->items[i]));
  o.stoppedByMemory = truth(get(run, "stoppedByProcessMemory")); o.budgetAutomatic = truth(get(run, "processMemoryBudgetAutomatic")); o.peakRss = num(get(run, "processPeakRssMiB")); o.budget = num(get(run, "processMemoryBudgetMiB"));
  o.physical = num(get(run, "physicalMemoryMiB")); o.tableBudget = num(get(run, "tableBudgetMiB")); o.evaluationMemory = num(get(run, "evaluationMemoryMiB")); o.perSeedAllowance = num(get(run, "memoryPerSeedAllowanceMiB"));
  o.parallelSeeds = (int)num(get(run, "parallelSeeds"), 0); o.threadsPerSeed = (int)num(get(run, "threadsPerSeed"), 0); o.memoryNote = str(get(run, "memoryNote"));
  o.points = measurements(d);
  const JV *vs = get(d, "variants");
  for (int i = 0; i < count(vs); i++) { const JV *seeds = get(vs->items[i], "perSeed");
    for (int j = 0; j < count(seeds); j++) { const JV *budgets = get(seeds->items[j], "budgets");
      for (int k = 0; k < count(budgets); k++) { const JV *p = budgets->items[k];
        if (i == 0 && j == 0 && k + 1 == count(budgets)) o.lastTableMiB = num(get(p, "tableMiB"));
        if (str(get(p, "status")) == "processMemoryLimit" && o.stoppedDeals < 0) { o.stoppedDeals = (long long)num(get(p, "deals"), 0); o.stoppedBudget = (long long)num(get(p, "budgetDeals"), 0);
          o.stoppedPoint = "seed " + mwa::fmt(num(get(seeds->items[j], "seed"))) + ": " + std::to_string(o.stoppedDeals) + " of " + std::to_string(o.stoppedBudget) + " deals"; } } } }
}

// ---- a checkpoint directory ----
struct State { std::string file, sha; long long bytes = 0, deals = 0; int generation = 0; bool intact = false; };
struct Manifest {
  bool exists = false, parses = false; std::string fileSha, bodySha, status; long long sequence = -1; int points = 0; bool everyPointComplete = true, everyStateIntact = true; std::vector<State> states;
};
inline Manifest manifestOf(const std::string &dir, const char *name) {
  Manifest m; const std::string p = (fs::path(dir) / name).string(), text = readFile(p); m.exists = !text.empty(); if (!m.exists) return m;
  m.fileSha = shaText(text); Json doc(text); const JV *body = get(doc.v, "body"); if (!body) return m;
  m.parses = true; m.bodySha = str(get(doc.v, "bodySha256")); m.status = str(get(body, "status")); m.sequence = (long long)num(get(body, "sequence"), -1);
  const JV *jobs = get(body, "jobs");
  for (int i = 0; i < count(jobs); i++) { const JV *j = jobs->items[i], *pts = get(j, "points"), *s = get(j, "state");
    for (int b = 0; b < count(pts); b++) { m.points++; if (!truth(get(pts->items[b], "complete"))) m.everyPointComplete = false; }
    if (s && s->type == J_OBJ) { State st; st.file = str(get(s, "file")); st.sha = str(get(s, "sha256")); st.bytes = (long long)num(get(s, "bytes"), 0); st.deals = (long long)num(get(s, "deals"), 0); st.generation = (int)num(get(s, "generation"), 0);
      uint64_t bytes = 0; const std::string got = emsha::fileHex((fs::path(dir) / st.file).string().c_str(), &bytes); st.intact = !got.empty() && got == st.sha && (long long)bytes == st.bytes; if (!st.intact) m.everyStateIntact = false; m.states.push_back(st); } }
  return m;
}
// Every file of a directory with its SHA-256 (study.lock, which exists only while a study runs, is left out).
inline std::string digest(const std::string &dir) {
  std::vector<std::string> rows; std::error_code ec;
  for (const auto &e : fs::directory_iterator(dir, ec)) { const std::string n = e.path().filename().string(); if (n == "study.lock" || !e.is_regular_file(ec)) continue; rows.push_back(n + ":" + shaFile(e.path().string())); }
  std::sort(rows.begin(), rows.end()); std::string s; for (const auto &r : rows) s += r + ";"; return s;
}
inline std::string listing(const std::string &dir) { std::vector<std::string> names; std::error_code ec; for (const auto &e : fs::directory_iterator(dir, ec)) names.push_back(e.path().filename().string()); std::sort(names.begin(), names.end()); std::string s; for (const auto &n : names) s += (s.empty() ? "" : ", ") + n; return s; }

// ---- the kinds of damage ----
// White space added outside strings only: after every ':' and ',' and a line break after every '{' and '['.
inline std::string reformat(const std::string &t) {
  std::string o; bool quoted = false;
  for (size_t i = 0; i < t.size(); i++) { const char c = t[i]; o += c;
    if (quoted) { if (c == '\\' && i + 1 < t.size()) o += t[++i]; else if (c == '"') quoted = false; continue; }
    if (c == '"') quoted = true; else if (c == ':') o += ' '; else if (c == ',') o += "\n  "; else if (c == '{' || c == '[') o += "\n    "; }
  return o;
}
// The text without white space outside strings: equal for two documents that differ in formatting only.
inline std::string squeezed(const std::string &t) {
  std::string o; bool quoted = false;
  for (size_t i = 0; i < t.size(); i++) { const char c = t[i];
    if (quoted) { o += c; if (c == '\\' && i + 1 < t.size()) o += t[++i]; else if (c == '"') quoted = false; continue; }
    if (c == ' ' || c == '\n' || c == '\r' || c == '\t') continue; o += c; if (c == '"') quoted = true; }
  return o;
}
// Changes the first digit of the first number that follows `key` (the number stays a valid JSON number).
inline bool alterNumberAfter(std::string &t, const std::string &key) {
  const size_t at = t.find(key); if (at == std::string::npos) return false;
  for (size_t i = at + key.size(); i < t.size() && i < at + key.size() + 4; i++) if (t[i] >= '0' && t[i] <= '9') { t[i] = t[i] == '9' ? '8' : (char)(t[i] + 1); return true; }
  return false;
}
// Changes the first hexadecimal digit of the bodySha256 value.
inline bool alterChecksum(std::string &t) {
  const std::string key = "\"bodySha256\":\""; const size_t at = t.find(key); if (at == std::string::npos || at + key.size() >= t.size()) return false;
  char &c = t[at + key.size()]; c = c == '0' ? '1' : '0'; return true;
}

// ---- verdicts (pure functions of an observation; the "controls" section applies them to observations they must reject) ----
// An intact checkpoint was resumed as it is: no fall-back, no discarded state, complete, the reference measurements.
inline bool acceptedIntact(const Obs &o, const std::string &reference) { return o.exitCode == 0 && o.wrote && o.complete && o.resumed && o.resumedFrom == "manifest.json" && o.resumeNote.empty() && o.warnings.empty() && !reference.empty() && o.points == reference; }
// Damage to manifest.json was detected (`why` names how) and the verified previous manifest was used.
inline bool recoveredFromPrevious(const Obs &o, const std::string &reference, const char *why) { return o.exitCode == 0 && o.wrote && o.complete && o.resumed && o.resumedFrom == "manifest.prev.json" && has(o.resumeNote, why) && has(o.resumeNote, "previous committed manifest") && !reference.empty() && o.points == reference; }
// No usable checkpoint: an explicit refusal, no result written.
inline bool refused(const Obs &o) { return o.started && !o.timedOut && o.exitCode == 5 && !o.wrote && has(o.stderrText, "no usable manifest"); }
// A damaged or missing engine state was named, discarded and the seed retrained; the manifest itself was used.
inline bool stateDiscarded(const Obs &o, const std::string &reference, const std::string &file, const char *phrase) { return o.exitCode == 0 && o.wrote && o.complete && o.resumed && o.resumedFrom == "manifest.json" && o.anyWarning(file.c_str(), phrase) && !reference.empty() && o.points == reference; }
// The process memory budget really stopped the study: flagged, incomplete, resumable, work left undone, and the
// peak resident set above the budget that was asked for. A study that completed can never satisfy this.
inline bool stoppedByBudget(const Obs &o, double limitMiB) { return o.exitCode == 0 && o.wrote && o.stoppedByMemory && !o.complete && o.status == "processMemoryLimit" && o.resumable && o.pointsCompleted < o.pointsRequested && o.peakRss > limitMiB && o.budget == limitMiB && !o.budgetAutomatic; }
// What the engine reported, in one phrase, from the observation alone.
inline std::string classify(const Obs &o) {
  if (!o.started) return "the process could not be started: " + o.startError;
  if (o.timedOut) return "the process did not finish in time and was stopped";
  if (o.exitCode == 86) return "the process was ended by the injected fault (exit 86), as a kill at that instant would";
  if (o.exitCode == 5 && has(o.stderrText, "no usable manifest")) return "refused (exit 5, error 409): no usable manifest; both manifest generations failed verification";
  if (o.exitCode == 5) return "refused (exit 5): " + oneLine(o.stderrText, 200);
  if (o.exitCode != 0) return "error (exit " + std::to_string(o.exitCode) + "): " + oneLine(o.stderrText, 200);
  if (!o.wrote) return "exit 0 but no readable result file";
  if (o.stoppedByMemory) return "stopped by the process memory budget (status " + o.status + "), checkpoint kept";
  if (o.resumedFrom == "manifest.prev.json") return "integrity failure of manifest.json detected; the verified previous manifest was used";
  if (o.anyWarning("does not match its recorded SHA-256")) return "an engine state failed its SHA-256/length check: discarded, the seed retrained from its start";
  if (o.anyWarning("missing or unreadable")) return "an engine state is missing: the seed retrained from its start";
  if (!o.warnings.empty()) return "resumed with warnings";
  if (o.resumed) return "none: the checkpoint was accepted as intact";
  if (o.checkpointEnabled) return "no checkpoint was found in the directory: the study ran from its start";
  return "none";
}

// ---- report ----
struct Evidence {
  std::string s;
  Evidence &raw(const char *k, const std::string &json) { s += (s.empty() ? "" : ",") + mwa::jsonEsc(k) + ":" + json; return *this; }
  Evidence &text(const char *k, const std::string &v) { return raw(k, mwa::jsonEsc(v)); }
  Evidence &number(const char *k, double v) { return raw(k, mwa::fmt(v)); }
  Evidence &whole(const char *k, long long v) { return raw(k, std::to_string(v)); }
  Evidence &flag(const char *k, bool v) { return raw(k, v ? "true" : "false"); }
  Evidence &list(const char *k, const std::vector<std::string> &v) { std::string a = "["; for (size_t i = 0; i < v.size(); i++) a += (i ? "," : "") + mwa::jsonEsc(v[i]); return raw(k, a + "]"); }
  // the fields every checkpoint check reports about the resume it made
  Evidence &resume(const Obs &o, const std::string &reference) {
    whole("engineExitCode", o.exitCode); text("errorClassification", classify(o)); flag("fallbackGenerationUsed", o.resumedFrom == "manifest.prev.json"); text("manifestUsed", o.resumedFrom);
    flag("resultFileWritten", o.wrote); flag("recoveredStudyCompleted", o.wrote && o.complete); flag("finalStateEqualsReference", o.wrote && !reference.empty() && o.points == reference);
    whole("pointsRestored", o.pointsRestored); text("resumeNote", o.resumeNote); list("warnings", o.warnings); text("stderr", ckpt::clip(o.stderrText, 2000)); return *this;
  }
};
struct Harness {
  std::string self, studies, dir; std::ostringstream steps, checks; int passed = 0, failed = 0, untested = 0; bool firstStep = true, firstCheck = true;
  std::string P(const std::string &name) const { return (fs::path(dir) / name).string(); }
  Obs study(const std::string &label, const std::string &fixture, const std::string &outName, std::vector<std::string> options, const Env &env = {}) {
    Obs o; o.label = label; o.out = P(outName); std::error_code ec; fs::remove(o.out, ec);
    std::vector<std::string> args{self, "--study", (fs::path(studies) / fixture).string(), o.out}; for (auto &x : options) args.push_back(x);
    const ckpt::Run r = ckpt::spawn(args, dir, 1800, env);
    o.command = r.command; o.exitCode = r.exitCode; o.started = r.started; o.timedOut = r.timedOut; o.ms = r.ms; o.stdoutText = r.out; o.stderrText = r.err; o.startError = r.startError;
    fill(o);
    steps << (firstStep ? "" : ",\n") << "{\"label\":" << mwa::jsonEsc(label) << ",\"command\":" << mwa::jsonEsc(r.command);
    if (!env.empty()) { steps << ",\"environment\":{"; for (size_t i = 0; i < env.size(); i++) steps << (i ? "," : "") << mwa::jsonEsc(env[i].first) << ":" << mwa::jsonEsc(env[i].second); steps << "}"; }
    steps << ",\"started\":" << (r.started ? "true" : "false") << ",\"exitCode\":" << r.exitCode << ",\"timedOut\":" << (r.timedOut ? "true" : "false") << ",\"ms\":" << mwa::fmt(r.ms)
          << ",\"resultFile\":" << mwa::jsonEsc(o.out) << ",\"resultFileWritten\":" << (o.wrote ? "true" : "false") << ",\"errorClassification\":" << mwa::jsonEsc(classify(o))
          << ",\"stdout\":" << mwa::jsonEsc(ckpt::clip(r.out, 4000)) << ",\"stderr\":" << mwa::jsonEsc(ckpt::clip(r.err, 4000)) << "}";
    firstStep = false; return o;
  }
  // status: "passed", "failed" or "untested". `exercised` says whether the condition the check is about was produced.
  void record(const char *section, const char *id, const std::string &name, const std::string &status, bool exercised, const std::string &detail, const Evidence &ev = {}, const std::vector<std::string> &stepLabels = {}) {
    (status == "passed" ? passed : status == "untested" ? untested : failed)++;
    checks << (firstCheck ? "" : ",\n") << "{\"section\":" << mwa::jsonEsc(section) << ",\"id\":" << mwa::jsonEsc(id) << ",\"name\":" << mwa::jsonEsc(name) << ",\"status\":" << mwa::jsonEsc(status)
           << ",\"passed\":" << (status == "passed" ? "true" : "false") << ",\"exercised\":" << (exercised ? "true" : "false") << ",\"detail\":" << mwa::jsonEsc(detail) << ",\"evidence\":{" << ev.s << "},\"steps\":[";
    for (size_t i = 0; i < stepLabels.size(); i++) checks << (i ? "," : "") << mwa::jsonEsc(stepLabels[i]);
    checks << "]}"; firstCheck = false;
    std::fprintf(stderr, "%s %s %s: %s: %s\n", status == "passed" ? "PASS" : status == "untested" ? "UNTESTED" : "FAIL", section, id, name.c_str(), detail.c_str());
  }
  void verdict(const char *section, const char *id, const std::string &name, bool exercised, bool ok, const std::string &detail, const Evidence &ev = {}, const std::vector<std::string> &stepLabels = {}) {
    record(section, id, name, exercised && ok ? "passed" : "failed", exercised, exercised ? detail : "the condition this check is about was not produced: " + detail, ev, stepLabels);
  }
};

// ============================================================ checkpoint integrity
inline void checkpointSection(Harness &H, Obs &controlAccepted, Obs &controlFallback) {
  const char *SEC = "checkpoint"; const std::string fixture = "known-akq-river.emfix.json"; std::error_code ec;
  const std::vector<std::string> base{"seeds=2", "budgets=20000,400000,6000000", "threads=2", "quiet=1", "processingMode=cpu"};
  auto with = [&](std::initializer_list<std::string> more) { std::vector<std::string> v = base; for (const auto &x : more) v.push_back(x); return v; };
  const char *ids[] = {"P", "A", "B1", "B2", "C1", "C2", "D1", "D2", "E1", "E2", "F1", "F2", "F3", "S"};
  const char *names[] = {"an untouched copy of the checkpoint resumes (positive control)", "white space changed in both manifests, no value changed: accepted, identical result",
    "a recorded value altered in manifest.json without updating its checksum: detected, the previous manifest used", "the same alteration in both manifests: refused, nothing written or changed",
    "the stored checksum of manifest.json altered, its data untouched: detected, the previous manifest used", "the stored checksum altered in both manifests: refused, nothing written or changed",
    "one byte of an engine state flipped: the state is discarded by its SHA-256 and the result is unchanged", "an engine state truncated to half: the state is discarded by its length and SHA-256 and the result is unchanged",
    "two committed generations, the newest manifest destroyed: the verified previous generation is used", "a process killed during the first commit after such a recovery leaves the previous generation intact and resumable",
    "the engine states named by the manifest removed: not treated as present, the seeds retrained", "manifest.json removed: the previous manifest is used", "both manifests removed, state files left: no checkpoint is assumed and no orphaned state is read",
    "the source checkpoint was not modified by any of these checks"};
  auto allUntested = [&](const std::string &why, int from = 0) { for (int i = from; i < 14; i++) H.record(SEC, ids[i], names[i], "untested", false, why); };

  // the uninterrupted reference
  const Obs ref = H.study("checkpoint: uninterrupted reference", fixture, "ck-reference.json", with({"checkpoint=off"}));
  if (!(ref.exitCode == 0 && ref.wrote && ref.complete && !ref.points.empty())) { allUntested("the uninterrupted reference study did not complete (" + classify(ref) + "), so no result can be compared"); return; }
  const std::string want = ref.points; const double T = ref.ms / 1000.0;

  // the source checkpoint: the same study stopped by a time limit part of the way through, with frequent commits.
  // The limit is a fraction of what the reference needed on this machine, so the stop falls inside the study on a
  // fast and on a slow PC; the fraction is lowered if the study still finished or left nothing to damage.
  const std::string src = H.P("ck-source"); Obs made; Manifest cur, prev; bool usable = false; std::string whyNot; double limitUsed = 0;
  for (const double fraction : {0.35, 0.2, 0.1, 0.05}) {
    fs::remove_all(src, ec); char limit[40]; limitUsed = std::max(0.02, T * fraction); std::snprintf(limit, sizeof limit, "timeLimitSeconds=%.3f", limitUsed);
    made = H.study("checkpoint: source checkpoint (time limit " + std::string(limit + 17) + " s)", fixture, "ck-source.json", with({"checkpoint=" + src, limit, "checkpointSeconds=0.05"}));
    cur = manifestOf(src, "manifest.json"); prev = manifestOf(src, "manifest.prev.json");
    if (made.exitCode != 0 || !made.wrote) whyNot = "the interrupted study failed: " + classify(made);
    else if (made.complete) whyNot = "the study finished inside its time limit";
    else if (!cur.parses || !prev.parses) whyNot = "the interrupted study did not leave two manifests";
    else if (cur.states.empty() || !cur.everyStateIntact) whyNot = "the newest manifest names no intact engine state";
    else if (cur.sequence != prev.sequence + 1 || !prev.everyStateIntact) whyNot = "manifest.json and manifest.prev.json are not two consecutive committed generations with intact states";
    else if (made.pointsCompleted < 1) whyNot = "no measurement had been completed when the study stopped";
    else { usable = true; break; }
  }
  if (!usable) { allUntested("no interrupted checkpoint to work on could be made on this machine: " + whyNot + " (reference study " + mwa::fmt(T) + " s). Nothing was tested."); return; }
  const std::string srcDigest = digest(src), curText = readFile((fs::path(src) / "manifest.json").string()), prevText = readFile((fs::path(src) / "manifest.prev.json").string());
  const std::string sourceNote = "source checkpoint: " + std::to_string(made.pointsCompleted) + " of " + std::to_string(made.pointsRequested) + " measurements, manifest generations " + std::to_string(prev.sequence) + " and " + std::to_string(cur.sequence) + ", " + std::to_string(cur.states.size()) + " engine state(s), stopped after " + mwa::fmt(limitUsed) + " s";

  struct Case { std::string id, dir, before; };
  auto copyOf = [&](const char *id) { Case c; c.id = id; c.dir = H.P(std::string("ck-case-") + id); fs::remove_all(c.dir, ec); fs::copy(src, c.dir, fs::copy_options::recursive, ec); return c; };
  auto file = [&](const Case &c, const std::string &name) { return (fs::path(c.dir) / name).string(); };
  auto resume = [&](Case &c, const Env &env = {}, const std::string &suffix = "") { c.before = digest(c.dir); return H.study("checkpoint " + c.id + ": resume" + suffix, fixture, "ck-case-" + c.id + suffix + ".json", with({"checkpoint=" + c.dir, "resume=1"}), env); };
  auto label = [&](const Case &c, const std::string &suffix = "") { return std::vector<std::string>{"checkpoint " + c.id + ": resume" + suffix}; };
  auto done = [&](const Case &c) { fs::remove_all(c.dir, ec); };

  { // P positive control
    Case c = copyOf("P"); const Obs o = resume(c); controlAccepted = o;
    Evidence e; e.text("corruptionMethod", "none (an exact copy of the source checkpoint)").text("originalSha256", cur.fileSha).text("modifiedSha256", shaFile(file(c, "manifest.json")) == cur.fileSha ? cur.fileSha : "changed by the resume").whole("manifestSequenceUsed", cur.sequence).text("sourceCheckpoint", sourceNote).resume(o, want);
    H.verdict(SEC, "P", names[0], digest(src) == srcDigest, acceptedIntact(o, want) && o.pointsRestored == made.pointsCompleted, classify(o) + "; restored " + std::to_string(o.pointsRestored) + " of " + std::to_string(made.pointsCompleted) + " saved measurements; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e, label(c)); done(c);
  }
  { // A white space only
    Case c = copyOf("A"); const std::string a = reformat(curText), b = reformat(prevText); writeFile(file(c, "manifest.json"), a); writeFile(file(c, "manifest.prev.json"), b);
    const bool exercised = a != curText && b != prevText && squeezed(a) == squeezed(curText) && squeezed(b) == squeezed(prevText);
    const Obs o = resume(c);
    Evidence e; e.text("corruptionMethod", "white space inserted outside strings in manifest.json and manifest.prev.json (after every ':' and ',', line breaks after '{' and '['); no value changed").text("originalSha256", cur.fileSha).text("modifiedSha256", shaText(a))
      .whole("bytesBefore", (long long)curText.size()).whole("bytesAfter", (long long)a.size()).flag("onlyWhiteSpaceDiffers", squeezed(a) == squeezed(curText)).whole("manifestSequenceUsed", cur.sequence)
      .text("expected", "accepted: bodySha256 is the SHA-256 of the canonical serialisation of the parsed body, so formatting is not part of the checkpoint's data").resume(o, want);
    H.verdict(SEC, "A", names[1], exercised, acceptedIntact(o, want) && o.pointsRestored == made.pointsCompleted, classify(o) + "; file SHA-256 changed, values unchanged; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e, label(c)); done(c);
  }
  // B a recorded value, C the stored checksum: newest manifest only (1) and both (2)
  struct Damage { const char *one, *both; int nameOne, nameBoth; bool checksum; };
  for (const Damage &d : {Damage{"B1", "B2", 2, 3, false}, Damage{"C1", "C2", 4, 5, true}}) {
    std::string field = d.checksum ? "bodySha256 (first hexadecimal digit)" : "the first action frequency of the first recorded measurement (body.jobs[0].points[0].frequency[0])";
    auto damage = [&](std::string &t) { if (d.checksum) return alterChecksum(t); if (alterNumberAfter(t, "\"frequency\":[")) return true; field = "body.sequence"; return alterNumberAfter(t, "\"sequence\":"); };
    const std::string method = d.checksum ? "the stored checksum " + field + " changed; the body it covers is untouched" : field + " changed to another value; bodySha256 not updated";
    { Case c = copyOf(d.one); std::string t = curText; const bool changed = damage(t) && t != curText && writeFile(file(c, "manifest.json"), t);
      const Obs o = resume(c); if (!d.checksum) controlFallback = o;
      Evidence e; e.text("corruptionMethod", "manifest.json: " + method + "; manifest.prev.json intact").text("originalSha256", cur.fileSha).text("modifiedSha256", shaText(t)).whole("manifestSequenceDamaged", cur.sequence).whole("manifestSequenceUsed", o.resumedFrom == "manifest.prev.json" ? prev.sequence : cur.sequence).resume(o, want);
      H.verdict(SEC, d.one, names[d.nameOne], changed, recoveredFromPrevious(o, want, "does not match its SHA-256"), classify(o) + "; generation used: " + (o.resumedFrom.empty() ? "none" : o.resumedFrom) + "; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e, label(c)); done(c); }
    { Case c = copyOf(d.both); std::string t = curText, u = prevText; const bool changed = damage(t) && damage(u) && t != curText && u != prevText && writeFile(file(c, "manifest.json"), t) && writeFile(file(c, "manifest.prev.json"), u);
      const Obs o = resume(c); const bool untouched = digest(c.dir) == c.before;
      Evidence e; e.text("corruptionMethod", "manifest.json and manifest.prev.json: " + method).text("originalSha256", cur.fileSha).text("modifiedSha256", shaText(t)).text("originalPreviousSha256", prev.fileSha).text("modifiedPreviousSha256", shaText(u)).flag("checkpointDirectoryUnchangedByTheRefusal", untouched).resume(o, want);
      H.verdict(SEC, d.both, names[d.nameBoth], changed, refused(o) && has(o.stderrText, "SHA-256") && untouched, classify(o) + "; result file written: " + (o.wrote ? "yes" : "no") + "; directory unchanged: " + (untouched ? "yes" : "no"), e, label(c)); done(c); }
  }
  // D damaged engine state
  for (const bool truncate : {false, true}) {
    const char *id = truncate ? "D2" : "D1"; Case c = copyOf(id); const State &st = cur.states[0]; const std::string p = file(c, st.file); std::string bytes = readFile(p); const std::string original = shaText(bytes);
    if (truncate) bytes.resize(bytes.size() / 2); else if (!bytes.empty()) bytes[bytes.size() / 2] = (char)(bytes[bytes.size() / 2] ^ 0x40);
    const bool changed = !bytes.empty() && shaText(bytes) != original && original == st.sha && writeFile(p, bytes);
    const Obs o = resume(c);
    Evidence e; e.text("corruptionMethod", truncate ? st.file + " (generation " + std::to_string(st.generation) + ") truncated to half its length; manifests intact" : st.file + " (generation " + std::to_string(st.generation) + "): one bit of the middle byte flipped; manifests intact")
      .text("originalSha256", original).text("modifiedSha256", shaText(bytes)).whole("originalBytes", st.bytes).whole("modifiedBytes", (long long)bytes.size()).whole("manifestSequenceUsed", cur.sequence).flag("damagedStateUsed", false).resume(o, want);
    H.verdict(SEC, id, names[truncate ? 7 : 6], changed, stateDiscarded(o, want, st.file, "does not match its recorded SHA-256") && o.pointsRestored == made.pointsCompleted, classify(o) + "; saved measurements kept: " + std::to_string(o.pointsRestored) + "; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e, label(c)); done(c);
  }
  { // E1 the newest generation destroyed
    Case c = copyOf("E1"); const std::string t = curText.substr(0, curText.size() / 2); const bool changed = writeFile(file(c, "manifest.json"), t) && prev.parses && prev.everyStateIntact && cur.sequence == prev.sequence + 1;
    const Obs o = resume(c);
    Evidence e; e.text("corruptionMethod", "manifest.json (generation " + std::to_string(cur.sequence) + ") truncated to half its length; manifest.prev.json (generation " + std::to_string(prev.sequence) + ") intact").text("originalSha256", cur.fileSha).text("modifiedSha256", shaText(t))
      .whole("committedGenerationsBefore", 2).whole("manifestSequenceDamaged", cur.sequence).whole("manifestSequenceUsed", o.resumedFrom == "manifest.prev.json" ? prev.sequence : -1).resume(o, want);
    H.verdict(SEC, "E1", names[8], changed, recoveredFromPrevious(o, want, "not valid JSON"), classify(o) + "; generation used: " + (o.resumedFrom == "manifest.prev.json" ? std::to_string(prev.sequence) + " (manifest.prev.json)" : "none") + "; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e, label(c)); done(c);
  }
  { // E2 killed during the first commit after a recovery from the previous generation
    Case c = copyOf("E2"); std::string t = curText; const bool changed = alterNumberAfter(t, "\"sequence\":") && writeFile(file(c, "manifest.json"), t);
    const Obs killed = resume(c, {{"EM_TEST_SAVE_FAULT", "crash"}, {"EM_TEST_SAVE_FAULT_FILE", "manifest.json"}}, " (killed while replacing manifest.json)");
    const std::string prevAfter = shaFile(file(c, "manifest.prev.json")); const bool kept = prevAfter == prev.fileSha;
    const Obs o = resume(c, {}, " (after the kill)");
    Evidence e; e.text("corruptionMethod", "manifest.json: body.sequence changed, bodySha256 not updated; then the resuming process is ended (exit 86) at the moment it would replace manifest.json with its first new commit").text("originalSha256", cur.fileSha).text("modifiedSha256", shaText(t))
      .whole("killedProcessExitCode", killed.exitCode).text("previousManifestSha256Before", prev.fileSha).text("previousManifestSha256AfterTheKill", prevAfter).flag("previousGenerationKeptIntact", kept).text("filesAfterTheKill", listing(c.dir))
      .whole("manifestSequenceUsed", o.resumedFrom == "manifest.prev.json" ? prev.sequence : -1).text("engineRepair", "5.5 to 5.7 copied the damaged manifest.json over manifest.prev.json before writing the new manifest, so this kill left no usable manifest; 5.7.1 keeps the verified previous manifest").resume(o, want);
    H.verdict(SEC, "E2", names[9], changed && killed.exitCode == 86, kept && recoveredFromPrevious(o, want, "does not match its SHA-256"), std::string("previous manifest unchanged by the killed process: ") + (kept ? "yes" : "NO") + "; then: " + classify(o) + "; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e,
      {"checkpoint E2: resume (killed while replacing manifest.json)", "checkpoint E2: resume (after the kill)"}); done(c);
  }
  { // F1 state files removed
    Case c = copyOf("F1"); bool removed = !cur.states.empty(); std::vector<std::string> gone; for (const State &st : cur.states) { removed = fs::remove(file(c, st.file), ec) && removed; gone.push_back(st.file); }
    const Obs o = resume(c); bool named = !gone.empty(); for (const auto &g : gone) named = named && o.anyWarning(g.c_str(), "missing or unreadable");
    Evidence e; e.text("corruptionMethod", "every engine state file named by manifest.json deleted; manifests intact").list("removedFiles", gone).text("originalSha256", cur.fileSha).whole("manifestSequenceUsed", cur.sequence).resume(o, want);
    H.verdict(SEC, "F1", names[10], removed, named && o.exitCode == 0 && o.complete && o.resumedFrom == "manifest.json" && o.points == want && o.pointsRestored == made.pointsCompleted, classify(o) + "; every missing file named in a warning: " + (named ? "yes" : "no") + "; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e, label(c)); done(c);
  }
  { // F2 manifest.json removed
    Case c = copyOf("F2"); const bool removed = fs::remove(file(c, "manifest.json"), ec);
    const Obs o = resume(c);
    Evidence e; e.text("corruptionMethod", "manifest.json deleted; manifest.prev.json and the state files intact").text("originalSha256", cur.fileSha).text("modifiedSha256", "(file absent)").whole("manifestSequenceUsed", o.resumedFrom == "manifest.prev.json" ? prev.sequence : -1).resume(o, want);
    H.verdict(SEC, "F2", names[11], removed, recoveredFromPrevious(o, want, "absent or empty"), classify(o) + "; generation used: " + (o.resumedFrom.empty() ? "none" : o.resumedFrom) + "; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e, label(c)); done(c);
  }
  { // F3 both manifests removed
    Case c = copyOf("F3"); const bool removed = fs::remove(file(c, "manifest.json"), ec) && fs::remove(file(c, "manifest.prev.json"), ec);
    const Obs o = resume(c);
    Evidence e; e.text("corruptionMethod", "manifest.json and manifest.prev.json deleted; the state files left in the directory").text("originalSha256", cur.fileSha).text("modifiedSha256", "(file absent)")
      .text("expected", "a directory without a manifest is not a checkpoint: nothing is restored, no state file is read, the study is computed from its start").flag("checkpointReportedAsResumed", o.resumed).resume(o, want);
    H.verdict(SEC, "F3", names[12], removed, o.exitCode == 0 && o.wrote && o.complete && !o.resumed && o.pointsRestored == 0 && o.resumedFrom.empty() && o.points == want, classify(o) + "; measurements restored: " + std::to_string(o.pointsRestored) + "; equals the uninterrupted study: " + (o.points == want ? "yes" : "no"), e, label(c)); done(c);
  }
  { // S the source was never modified
    const std::string after = digest(src); Evidence e; e.text("sourceCheckpoint", sourceNote).text("digestBefore", shaText(srcDigest)).text("digestAfter", shaText(after)).text("files", listing(src)).text("workDirectory", H.dir);
    H.verdict(SEC, "S", names[13], true, after == srcDigest, after == srcDigest ? "every file of the source checkpoint has the SHA-256 it had before the first copy was made; every damaged file was a copy inside the work directory" : "the source checkpoint changed", e);
  }
  fs::remove_all(src, ec);
}

// ============================================================ process memory budget
inline void memorySection(Harness &H, Obs &controlCompleted) {
  const char *SEC = "memory"; const std::string fixture = "flop3-kings-detailed.emfix.json"; std::error_code ec; const double LIMIT = 48;
  const std::vector<std::string> base{"seeds=2", "budgets=2000,60000", "threads=2", "quiet=1", "processingMode=cpu", "evaluationSamples=2000"};
  auto with = [&](std::initializer_list<std::string> more) { std::vector<std::string> v = base; for (const auto &x : more) v.push_back(x); return v; };
  const char *ids[] = {"E", "A", "B", "C", "D1", "D2"};
  const char *names[] = {"control: with the automatic budget the same study completes and reports no memory stop", "a 48 MiB process budget is reached: the study is stopped by it, incomplete and resumable, with a usable checkpoint",
    "resumed with the automatic budget: saved work is kept, the study finishes with the measurements of the control", "memory accounting in the result document and the checkpoint",
    "process budgets outside the supported range are refused and write nothing", "a budget below what the process needs before any training stops at once, keeps a valid checkpoint and resumes"};
  auto untested = [&](int from, int to, const std::string &why) { for (int i = from; i <= to; i++) H.record(SEC, ids[i], names[i], "untested", false, why); };

  // E control: normal completion (kept apart from A: a completed study can never count as a memory stop)
  const Obs control = H.study("memory E: control with the automatic budget", fixture, "mem-control.json", with({"checkpoint=off"})); controlCompleted = control;
  { Evidence e; e.whole("engineExitCode", control.exitCode).text("errorClassification", classify(control)).flag("resultFileWritten", control.wrote).flag("studyCompleted", control.complete).flag("stoppedByProcessMemory", control.stoppedByMemory).text("completionStatus", control.status)
      .number("processMemoryBudgetMiB", control.budget).flag("processMemoryBudgetAutomatic", control.budgetAutomatic).number("physicalMemoryMiB", control.physical).number("processPeakRssMiB", control.peakRss).number("tableMiBAtTheLastBudget", control.lastTableMiB).whole("parallelSeeds", control.parallelSeeds);
    const bool ok = control.exitCode == 0 && control.wrote && control.complete && control.status == "complete" && !control.stoppedByMemory && control.budgetAutomatic && control.physical > 0 && control.budget <= 0.7 * control.physical + 1;
    H.verdict(SEC, "E", names[0], true, ok, classify(control) + "; complete: " + (control.complete ? "yes" : "no") + "; stopped by the memory budget: " + (control.stoppedByMemory ? "yes" : "no") + "; peak " + mwa::fmt(control.peakRss) + " MiB of an automatic budget of " + mwa::fmt(control.budget) + " MiB", e, {"memory E: control with the automatic budget"});
    if (!ok) { untested(1, 5, "the control study did not complete normally (" + classify(control) + "), so there is no reference and no measured workload"); return; } }
  const std::string want = control.points;
  // The workload must be known to exceed the budget: the tables of ONE seed alone, at the last budget, are a
  // deterministic size (the same on every machine) and must be at least 1.5 times the budget.
  if (!(control.lastTableMiB >= 1.5 * LIMIT)) { untested(1, 5, "the fixture no longer grows past the budget: its tables reach " + mwa::fmt(control.lastTableMiB) + " MiB, less than 1.5 times the " + mwa::fmt(LIMIT) + " MiB budget; the memory stop cannot be produced reliably"); return; }

  // A the limit is reached
  const std::string dir = H.P("mem-checkpoint"); fs::remove_all(dir, ec);
  const Obs stopped = H.study("memory A: process budget 48 MiB", fixture, "mem-stopped.json", with({"checkpoint=" + dir, "processMemoryMiB=48"}));
  const Manifest man = manifestOf(dir, "manifest.json"); long long savedDeals = 0; for (const State &s : man.states) savedDeals = std::max(savedDeals, s.deals);
  // When the stop interrupted a training (stoppedDeals >= 0) the engine state committed with it must hold every deal
  // trained up to the stop: a checkpoint that only has an earlier stage would resume correctly but lose that work.
  const bool progressSaved = stopped.stoppedDeals < 0 || savedDeals == stopped.stoppedDeals;
  const bool reached = stoppedByBudget(stopped, LIMIT), checkpointUsable = man.parses && man.everyStateIntact && man.everyPointComplete && man.status == "processMemoryLimit" && (man.points > 0 || savedDeals > 0) && progressSaved;
  { Evidence e; e.whole("engineExitCode", stopped.exitCode).text("errorClassification", classify(stopped)).flag("resultFileWritten", stopped.wrote).flag("memoryLimitReached", reached).flag("stoppedByProcessMemory", stopped.stoppedByMemory).flag("studyCompleted", stopped.complete)
      .text("completionStatus", stopped.status).flag("resumable", stopped.resumable).whole("pointsCompleted", stopped.pointsCompleted).whole("pointsRequested", stopped.pointsRequested).text("stoppedPoint", stopped.stoppedPoint)
      .number("processMemoryBudgetMiB", stopped.budget).number("processPeakRssMiB", stopped.peakRss).number("overshootMiB", stopped.peakRss - LIMIT).number("workloadTableMiBAtTheLastBudget", control.lastTableMiB)
      .flag("checkpointManifestWritten", man.parses).text("checkpointStatus", man.status).whole("checkpointManifestSequence", man.sequence).whole("checkpointMeasurements", man.points).whole("checkpointEngineStates", (long long)man.states.size())
      .whole("checkpointSavedDeals", savedDeals).whole("dealsTrainedWhenStopped", stopped.stoppedDeals).flag("trainingDoneBeforeTheStopIsSaved", progressSaved).flag("everyCheckpointStateMatchesItsSha256", man.everyStateIntact).text("checkpointFiles", listing(dir));
    std::string detail = reached ? "stopped by the memory budget after " + stopped.stoppedPoint + "; peak " + mwa::fmt(stopped.peakRss) + " MiB against a budget of 48 MiB; " + std::to_string(stopped.pointsCompleted) + " of " + std::to_string(stopped.pointsRequested) + " measurements; checkpoint: " + (checkpointUsable ? "manifest and every state verified, the saved state holds all " + std::to_string(savedDeals) + " deals trained" : progressSaved ? std::string("NOT usable") : "the saved state holds " + std::to_string(savedDeals) + " deals, NOT the " + std::to_string(stopped.stoppedDeals) + " trained before the stop")
                                 : stopped.complete ? "the study completed normally (peak " + mwa::fmt(stopped.peakRss) + " MiB): the memory limit was never reached, which is NOT a pass" : classify(stopped) + "; stoppedByProcessMemory " + (stopped.stoppedByMemory ? "true" : "false") + ", status " + stopped.status + ", peak " + mwa::fmt(stopped.peakRss) + " MiB";
    H.verdict(SEC, "A", names[1], reached, checkpointUsable, detail, e, {"memory A: process budget 48 MiB"}); }
  if (!(reached && checkpointUsable)) { untested(2, 3, "the memory stop of check A did not happen or left no usable checkpoint, so there is nothing to resume or to account for"); }
  else {
    // B resume with the automatic budget
    const Obs resumed = H.study("memory B: resume with the automatic budget", fixture, "mem-stopped.json", with({"checkpoint=" + dir, "resume=1"}));
    { Evidence e; e.resume(resumed, want).flag("stoppedByProcessMemory", resumed.stoppedByMemory).flag("processMemoryBudgetAutomatic", resumed.budgetAutomatic).number("processMemoryBudgetMiB", resumed.budget).number("processPeakRssMiB", resumed.peakRss)
        .whole("measurementsSavedBeforeTheStop", stopped.pointsCompleted).whole("dealsOfTheSavedEngineState", savedDeals).flag("savedEngineStateContinued", resumed.warnings.empty());
      const bool ok = acceptedIntact(resumed, want) && resumed.pointsRestored == stopped.pointsCompleted && !resumed.stoppedByMemory && resumed.budgetAutomatic;
      H.verdict(SEC, "B", names[2], true, ok, classify(resumed) + "; restored " + std::to_string(resumed.pointsRestored) + " of " + std::to_string(stopped.pointsCompleted) + " saved measurements and continued the engine state saved at " + std::to_string(savedDeals) + " deals" + (resumed.warnings.empty() ? "" : " (WARNINGS: the state was not continued)") + "; complete: " + (resumed.complete ? "yes" : "no") + "; equals the control: " + (resumed.points == want ? "yes" : "no"), e, {"memory B: resume with the automatic budget"}); }
    // C accounting
    { std::vector<std::string> missing; auto need = [&](bool ok, const char *what) { if (!ok) missing.push_back(what); };
      need(stopped.peakRss > 0 && control.peakRss > 0, "processPeakRssMiB is reported");
      need(stopped.budget == LIMIT && !stopped.budgetAutomatic, "the requested budget is reflected (processMemoryBudgetMiB 48, not automatic)");
      need(stopped.physical > 0, "physicalMemoryMiB is reported");
      need(stopped.tableBudget > 0, "tableBudgetMiB (one engine's tables) is reported");
      need(stopped.evaluationMemory >= 16, "evaluationMemoryMiB (the evaluator cache) is reported");
      need(stopped.perSeedAllowance >= stopped.tableBudget + 64, "memoryPerSeedAllowanceMiB covers the tables, the evaluator cache and the working allowance of one seed");
      need(stopped.parallelSeeds == 1 && control.parallelSeeds >= 1, "a budget smaller than one seed's allowance admits one seed at a time");
      need(stopped.threadsPerSeed >= 1, "threadsPerSeed is reported");
      need(control.lastTableMiB > 0, "tableMiB of a trained point is reported");
      need(has(stopped.memoryNote, "stop condition, not a hard allocation cap"), "the document says the budget is a stop condition, not an allocation cap");
      need(stopped.peakRss > LIMIT && stopped.peakRss < LIMIT + 0.5 * control.lastTableMiB, "the stop followed the excess closely (a soft stop: bounded overshoot)");
      need(man.everyPointComplete && man.points == (int)stopped.pointsCompleted, "the checkpoint records only completed measurements (the stopped one is not among them)");
      need(man.everyStateIntact, "every engine state named by the checkpoint matches its SHA-256 and length");
      Evidence e; e.number("processMemoryBudgetMiB", stopped.budget).number("processPeakRssMiB", stopped.peakRss).number("overshootMiB", stopped.peakRss - LIMIT).number("physicalMemoryMiB", stopped.physical).number("tableBudgetMiB", stopped.tableBudget)
        .number("evaluationMemoryMiB", stopped.evaluationMemory).number("memoryPerSeedAllowanceMiB", stopped.perSeedAllowance).whole("parallelSeedsUnderTheBudget", stopped.parallelSeeds).whole("parallelSeedsInTheControl", control.parallelSeeds).whole("threadsPerSeed", stopped.threadsPerSeed)
        .number("controlPeakRssMiB", control.peakRss).number("controlTableMiBAtTheLastBudget", control.lastTableMiB).text("memoryNote", stopped.memoryNote)
        .text("softStop", "the budget is compared with the resident set after every training chunk and evaluation; it is a stop condition, not a cap on allocation, so the peak exceeds it by what one chunk adds").list("notSatisfied", missing);
      H.verdict(SEC, "C", names[3], true, missing.empty(), missing.empty() ? "13 of 13 statements hold; overshoot " + mwa::fmt(stopped.peakRss - LIMIT) + " MiB above the 48 MiB budget (a soft stop)" : std::to_string(missing.size()) + " statement(s) not satisfied: " + missing[0], e, {"memory A: process budget 48 MiB", "memory E: control with the automatic budget"}); }
  }
  fs::remove_all(dir, ec);
  // D1 values outside the supported range (zero means automatic; any positive finite number is accepted)
  { std::vector<std::string> rows, labels; bool all = true;
    for (const char *bad : {"-1", "nan", "inf", "abc"}) {
      const std::string d = H.P(std::string("mem-invalid")), lab = std::string("memory D1: processMemoryMiB=") + bad; fs::remove_all(d, ec);
      const Obs o = H.study(lab, fixture, "mem-invalid.json", with({"checkpoint=" + d, std::string("processMemoryMiB=") + bad})); labels.push_back(lab);
      const bool nothing = !fs::exists(o.out, ec) && (!fs::exists(d, ec) || fs::is_empty(d, ec)); const bool ok = o.started && !o.timedOut && (o.exitCode == 1 || o.exitCode == 2) && has(o.stderrText, "processMemoryMiB") && nothing; all = all && ok;
      rows.push_back(std::string(bad) + ": exit " + std::to_string(o.exitCode) + ", " + oneLine(o.stderrText, 120) + ", " + (nothing ? "nothing written" : "SOMETHING WAS WRITTEN")); fs::remove_all(d, ec); }
    Evidence e; e.list("attempts", rows).text("supportedRange", "0 (automatic: 70% of physical memory) or any positive finite number of MiB; there is no positive minimum, a small budget is a stop condition that is met at once (check D2)");
    H.verdict(SEC, "D1", names[4], true, all, all ? "-1, nan, inf and abc: each refused with a message naming the option, exit status 1 or 2, no result file and no checkpoint" : "not every invalid value was refused cleanly", e, labels); }
  // D2 a budget the process exceeds before it has trained anything
  { const std::string d = H.P("mem-tiny"); fs::remove_all(d, ec);
    const Obs tiny = H.study("memory D2: process budget 0.5 MiB", fixture, "mem-tiny.json", with({"checkpoint=" + d, "processMemoryMiB=0.5"}));
    const Manifest m = manifestOf(d, "manifest.json"); const bool stoppedAtOnce = stoppedByBudget(tiny, 0.5) && tiny.pointsCompleted == 0 && tiny.stoppedDeals >= 0 && tiny.stoppedDeals < 2000 && tiny.peakRss < LIMIT;
    long long tinySaved = 0; for (const State &st : m.states) tinySaved = std::max(tinySaved, st.deals);
    const bool valid = m.parses && m.everyStateIntact && m.everyPointComplete && m.status == "processMemoryLimit" && !m.states.empty() && tinySaved == tiny.stoppedDeals;
    Obs again; if (stoppedAtOnce && valid) again = H.study("memory D2: resume with the automatic budget", fixture, "mem-tiny.json", with({"checkpoint=" + d, "resume=1"}));
    Evidence e; e.whole("engineExitCode", tiny.exitCode).text("errorClassification", classify(tiny)).flag("stoppedByProcessMemory", tiny.stoppedByMemory).text("stoppedPoint", tiny.stoppedPoint).number("processPeakRssMiB", tiny.peakRss).flag("checkpointValid", valid).whole("checkpointSavedDeals", tinySaved).text("checkpointFiles", listing(d))
      .whole("resumeExitCode", again.exitCode).flag("recoveredStudyCompleted", again.wrote && again.complete).flag("finalStateEqualsReference", again.wrote && again.points == want).list("resumeWarnings", again.warnings);
    H.verdict(SEC, "D2", names[5], stoppedAtOnce, valid && acceptedIntact(again, want), stoppedAtOnce ? "stopped after " + tiny.stoppedPoint + " with a peak of " + mwa::fmt(tiny.peakRss) + " MiB (no crash, no growth); checkpoint valid: " + (valid ? "yes" : "no") + "; resumed and completed with the control's measurements: " + (acceptedIntact(again, want) ? "yes" : "no") : classify(tiny), e,
      {"memory D2: process budget 0.5 MiB", "memory D2: resume with the automatic budget"}); fs::remove_all(d, ec); }
}

// ============================================================ controls of the verdict functions
inline void controlSection(Harness &H, bool ranCheckpoint, bool ranMemory, const Obs &accepted, const Obs &fallback, const Obs &completed) {
  const char *SEC = "controls";
  auto control = [&](const char *id, const std::string &name, bool available, bool rejected, const std::string &detail) {
    if (!available) { H.record(SEC, id, name, "untested", false, "the observation this control is applied to was not produced (see the check it comes from)"); return; }
    Evidence e; e.flag("verdictFunctionRejectedIt", rejected); H.verdict(SEC, id, name, true, rejected, detail, e);
  };
  if (ranCheckpoint) {
    const bool a = accepted.wrote && accepted.exitCode == 0, f = fallback.wrote && fallback.exitCode == 0 && fallback.resumedFrom == "manifest.prev.json";
    control("N1", "a successful resume (exit 0) is not accepted as a refusal", a, !refused(accepted), "the untouched-copy resume of check P, given to the refusal verdict: " + std::string(refused(accepted) ? "ACCEPTED (wrong)" : "rejected"));
    control("N2", "an untouched resume is not accepted as a detection of damage", a, !recoveredFromPrevious(accepted, accepted.points, "does not match its SHA-256") && !stateDiscarded(accepted, accepted.points, "", "does not match its recorded SHA-256"), "the resume of check P, given to the fall-back and discarded-state verdicts: rejected by both");
    control("N3", "a resume that needed the previous manifest is not accepted as an intact checkpoint", f, !acceptedIntact(fallback, fallback.points), "the fall-back resume of check B1, given to the intact-checkpoint verdict: " + std::string(acceptedIntact(fallback, fallback.points) ? "ACCEPTED (wrong)" : "rejected"));
  }
  if (ranMemory) {
    const bool c = completed.wrote && completed.exitCode == 0 && completed.complete;
    control("N4", "a study that completed normally is not accepted as a memory stop", c, !stoppedByBudget(completed, 48) && !stoppedByBudget(completed, completed.budget), "the completed control of check E, given to the memory-stop verdict (this is the observation the 5.7 script accepted): " + std::string(stoppedByBudget(completed, 48) ? "ACCEPTED (wrong)" : "rejected"));
  }
}

inline int run(int argc, char **argv) {
  const std::string mode = argc >= 5 ? argv[4] : "all"; const bool keep = argc >= 6 && !std::strcmp(argv[5], "keep");
  if (argc < 4 || (mode != "all" && mode != "checkpoint" && mode != "memory")) { std::fprintf(stderr, "usage: mwcli --selftest571 studies-dir work-dir [all|checkpoint|memory] [keep]\n"); return 2; }
  std::error_code ec; Harness H; H.self = ckpt::selfPath(argv[0]); H.studies = fs::absolute(argv[2], ec).string(); H.dir = fs::absolute(argv[3], ec).string();
  fs::create_directories(H.dir, ec);
  for (const char *f : {"known-akq-river.emfix.json", "flop3-kings-detailed.emfix.json"}) if (!fs::exists(fs::path(H.studies) / f, ec)) { std::fprintf(stderr, "error: study fixture %s is not in %s\n", f, H.studies.c_str()); return 2; }
  const auto t0 = std::chrono::steady_clock::now(); Obs accepted, fallback, completed;
  const bool ck = mode != "memory", mem = mode != "checkpoint";
  if (ck) checkpointSection(H, accepted, fallback);
  if (mem) memorySection(H, completed);
  controlSection(H, ck, mem, accepted, fallback, completed);
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::ostringstream o;
  o << "{\"tool\":\"mwcli selftest571\",\"version\":\"" << EM_VERSION << "\",\"build\":\"" << EM_BUILD_ID << "\",\"mode\":" << mwa::jsonEsc(mode)
#ifdef _WIN32
    << ",\"platform\":\"windows\""
#else
    << ",\"platform\":\"linux\""
#endif
    << ",\"passed\":" << H.passed << ",\"failed\":" << H.failed << ",\"untested\":" << H.untested << ",\"seconds\":" << mwa::fmt(secs)
    << ",\"statusMeaning\":{\"passed\":\"the intended condition was produced and the engine reacted as documented\",\"failed\":\"the engine did not react as documented, or the condition the check is about did not occur\",\"untested\":\"a step this check depends on could not be carried out; never counted as passed\"}"
    << ",\"checks\":[" << H.checks.str() << "],\"steps\":[" << H.steps.str() << "]}\n";
  const std::string report = H.P("selftest571.json"); const bool written = writeFile(report, o.str());
  if (!keep) for (const char *f : {"ck-reference.json", "ck-source.json", "mem-control.json", "mem-stopped.json", "mem-invalid.json", "mem-tiny.json"}) fs::remove(H.P(f), ec);
  if (!keep) for (const auto &e : fs::directory_iterator(H.dir, ec)) { const std::string n = e.path().filename().string(); if (n.rfind("ck-case-", 0) == 0) fs::remove_all(e.path(), ec); }
  std::printf("{\"tool\":\"mwcli selftest571\",\"build\":\"%s\",\"mode\":\"%s\",\"passed\":%d,\"failed\":%d,\"untested\":%d,\"reportWritten\":%s,\"report\":%s}\n", EM_BUILD_ID, mode.c_str(), H.passed, H.failed, H.untested, written ? "true" : "false", mwa::jsonEsc(report).c_str());
  return (H.failed || H.untested || !written) ? 1 : 0;
}
}
