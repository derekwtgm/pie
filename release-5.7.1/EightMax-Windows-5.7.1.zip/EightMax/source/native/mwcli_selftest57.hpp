// EightMax 5.7: mwcli --selftest57 <fixtures-dir> <work-dir>
// What changed in 5.7, checked by the shipped program itself (Windows CI and the target PC run it from
// "Run 5.7 Windows validation.bat"; nothing but mwcli is needed):
//   1  in-engine checks (mw_selftest57): the rewritten card code against the 5.6 function, the worker pool, the deal
//      queue and the two measured choices;
//   2  frozen-batch training: the same state file for 1, 2, 4 and 8 threads, with the measured thread choice, with
//      every update forced onto all threads, and with the 5.6 update (EIGHTMAX_LEGACY_BATCH=1); each must equal the
//      state the unchanged 5.6 Linux binary wrote (golden57.json); a training stopped and continued with other
//      thread counts must equal it too;
//   3  evaluation: sampled and exact response gains with the evaluator's path tree and without it
//      (EM_EV_NO_PATHS=1) must give the same seats and summary apart from timings, and agree with the 5.6 values
//      to 1e-12.
// Every step is a separate mwcli process, recorded in <work-dir>/selftest57.json. Exit status 1 if a check failed.
#pragma once
namespace st57 {
inline std::string fileSha(const std::string &p) { auto b = slurp(p.c_str()); if (b.empty()) return ""; emsha::Sha256 h; h.add(b.data(), b.size()); return h.hex(); }
// The results of an evaluation document: its "seats" array and its "summary" object, without the "elapsedMs"
// values. The rest of the document (timings, memory readings and work counters such as tree visits, which depend on
// how the request's threads interleave) differs between two runs of the same program and is not compared.
inline std::string resultsOf(const std::string &doc) {
  auto section = [&](const char *key, char open, char close) {
    const size_t at = doc.find(key); if (at == std::string::npos) return std::string();
    size_t e = at + std::strlen(key); int depth = 1; bool quoted = false;
    while (e < doc.size() && depth) { const char c = doc[e]; if (quoted) { if (c == '\\') e++; else if (c == '"') quoted = false; } else if (c == '"') quoted = true; else if (c == open) depth++; else if (c == close) depth--; e++; }
    return doc.substr(at, e - at);
  };
  std::string s = section("\"seats\":[", '[', ']') + section("\"summary\":{", '{', '}');
  for (size_t at = 0; (at = s.find("\"elapsedMs\":", at)) != std::string::npos;) { size_t e = at + 12; while (e < s.size() && (std::isdigit((unsigned char)s[e]) || s[e] == '.' || s[e] == '-' || s[e] == 'e' || s[e] == 'E' || s[e] == '+')) e++; s.erase(at + 12, e - at - 12); at += 12; }
  return s;
}
// Every number that follows `key` in a JSON text, in order.
inline std::vector<double> numbersAfter(const std::string &s, const std::string &key) {
  std::vector<double> v;
  for (size_t at = 0; (at = s.find(key, at)) != std::string::npos; at += key.size()) { const char *p = s.c_str() + at + key.size(); char *end = nullptr; const double x = std::strtod(p, &end); if (end != p) v.push_back(x); }
  return v;
}
inline int run(int argc, char **argv) {
  if (argc < 4) { std::fprintf(stderr, "usage: mwcli --selftest57 fixtures-dir work-dir\n"); return 2; }
  namespace fs = std::filesystem; std::error_code ec;
  const std::string self = ckpt::selfPath(argv[0]), fx = fs::absolute(argv[2], ec).string(), dir = fs::absolute(argv[3], ec).string();
  fs::create_directories(dir, ec);
  auto F = [&](const std::string &name) { return (fs::path(fx) / name).string(); };
  auto P = [&](const std::string &name) { return (fs::path(dir) / name).string(); };
  std::ostringstream steps, checks; int passed = 0, failed = 0; bool firstStep = true, firstCheck = true;
  const auto t0 = std::chrono::steady_clock::now();
  using Env = std::vector<std::pair<std::string, std::string>>;
  auto step = [&](const std::string &label, std::vector<std::string> args, const Env &env = {}) {
    args.insert(args.begin(), self); ckpt::Run r = ckpt::spawn(args, dir, 1800, env);
    steps << (firstStep ? "" : ",\n") << "{\"label\":" << mwa::jsonEsc(label) << ",\"command\":" << mwa::jsonEsc(r.command) << ",\"exitCode\":" << r.exitCode << ",\"timedOut\":" << (r.timedOut ? "true" : "false") << ",\"ms\":" << mwa::fmt(r.ms) << ",\"stderr\":" << mwa::jsonEsc(r.err.substr(0, 400)) << "}";
    firstStep = false; return r;
  };
  auto check = [&](const std::string &name, bool ok, const std::string &detail) {
    (ok ? passed : failed)++; checks << (firstCheck ? "" : ",\n") << "{\"name\":" << mwa::jsonEsc(name) << ",\"passed\":" << (ok ? "true" : "false") << ",\"detail\":" << mwa::jsonEsc(detail) << "}"; firstCheck = false;
    std::fprintf(stderr, "%s %s %s\n", ok ? "PASS" : "FAIL", name.c_str(), detail.c_str());
  };
  // 1 in-engine checks
  { JB j; jb_init(&j); mw_selftest57(&j); const std::string text(j.s ? j.s : "", j.n); jb_free(&j);
    char perr[160] = ""; JV *v = json_parse(text.c_str(), text.size(), perr, sizeof perr);
    if (!v || v->type != J_ARR || !v->n) check("in-engine checks answered", false, text.substr(0, 200));
    else for (int i = 0; i < v->n; i++) { const JV *e = v->items[i]; const JV *n = jget(e, "name"), *p = jget(e, "passed"), *d = jget(e, "detail"); check(n && n->str ? n->str : "?", p && p->type == J_BOOL && p->num != 0, d && d->str ? d->str : ""); }
    if (v) json_free(v); }
  const std::vector<unsigned char> goldenBytes = slurp(F("golden57.json").c_str());
  char gerr[160] = ""; JV *golden = goldenBytes.empty() ? nullptr : json_parse((const char *)goldenBytes.data(), goldenBytes.size(), gerr, sizeof gerr);
  if (!golden) { std::fprintf(stderr, "error: missing or unreadable fixture %s\n", F("golden57.json").c_str()); return 2; }
  struct FreeJ { JV *v; ~FreeJ() { json_free(v); } } freeGolden{golden};
  auto text = [](const JV *o, const char *k) { const JV *x = jget(o, k); return std::string(x && x->str ? x->str : ""); };
  auto whole = [](const JV *o, const char *k) { const JV *x = jget(o, k); return std::to_string((long long)(x ? x->num : 0)); };
  const Env fixed{{"EIGHTMAX_THREAD_CHOICE", "fixed"}}, legacy{{"EIGHTMAX_LEGACY_BATCH", "1"}};
  // 2 frozen-batch training
  if (const JV *tr = jget(golden, "training")) for (int i = 0; i < tr->n; i++) {
    const JV *c = tr->items[i]; const std::string name = text(c, "name"), spec = F(text(c, "spec")), want = text(c, "stateSha256"), updates = whole(c, "updates"), mem = whole(c, "memoryMiB");
    const long long U = std::atoll(updates.c_str());
    struct Arm { const char *label; const char *threads; const Env *env; };
    const Env none; const Arm arms[] = {{"1 thread", "1", &none}, {"2 threads, every update on both", "2", &fixed}, {"4 threads, every update on all", "4", &fixed}, {"8 threads, every update on all", "8", &fixed},
                                        {"4 threads, measured thread choice", "4", &none}, {"4 threads, the 5.6 update", "4", &legacy}};
    std::string detail; bool all = true;
    for (const Arm &a : arms) {
      const std::string st = P(name + "." + a.threads + ".state");
      const auto r = step(name + ": " + a.label, {spec, updates, a.threads, st, mem}, *a.env);
      const bool ok = r.exitCode == 0 && fileSha(st) == want; all &= ok;
      if (!ok) detail += std::string(a.label) + ": exit " + std::to_string(r.exitCode) + " sha256 " + fileSha(st) + "; ";
      fs::remove(st, ec);
    }
    check(name + ": the state of the 5.6 binary for 1, 2, 4 and 8 threads, the measured choice and the 5.6 update", all, all ? want : detail);
    const std::string part = P(name + ".part.state"), two = P(name + ".two.state");
    step(name + ": first third, 2 threads", {spec, std::to_string(U / 3), "2", part, mem}, fixed);
    const auto r2 = step(name + ": continued, 4 threads", {spec, std::to_string(U - U / 3), "4", two, mem, part}, fixed);
    check(name + ": stopped after a third (2 threads) and continued (4 threads) = uninterrupted", r2.exitCode == 0 && fileSha(two) == want, fileSha(two));
    fs::remove(part, ec); fs::remove(two, ec);
  }
  // 3 evaluation with and without the path tree
  if (const JV *evs = jget(golden, "evaluation")) for (int i = 0; i < evs->n; i++) {
    const JV *c = evs->items[i]; const std::string name = text(c, "name"), spec = F(text(c, "spec")), state = P(name + ".state"), q = F(text(c, "query")), mem = whole(c, "memoryMiB"), key = text(c, "compare");
    const auto tr = step(name + ": training", {spec, whole(c, "updates"), "1", state, mem});
    check(name + ": the trained state is the state of the 5.6 binary", tr.exitCode == 0 && fileSha(state) == text(c, "stateSha256"), fileSha(state));
    const auto a = step(name + ": evaluation", {"--gain", spec, state, q, mem});
    const auto b = step(name + ": evaluation without the path tree", {"--gain", spec, state, q, mem}, {{"EM_EV_NO_PATHS", "1"}});
    const std::string na = resultsOf(a.out), nb = resultsOf(b.out);
    check(name + ": the same seats and summary with and without the path tree (timings excluded)", a.exitCode == 0 && b.exitCode == 0 && !na.empty() && na == nb, a.exitCode || b.exitCode ? a.err + b.err : std::to_string(na.size()) + " characters compared");
    const std::vector<double> got = numbersAfter(a.out, key); std::vector<double> want; if (const JV *w = jget(c, "values56")) for (int j = 0; j < w->n; j++) want.push_back(w->items[j]->num);
    bool close = !want.empty() && got.size() == want.size(), same = close; double worst = 0;
    for (size_t j = 0; close && j < want.size(); j++) { const double d = std::fabs(got[j] - want[j]), rel = d / std::max(1e-300, std::max(std::fabs(got[j]), std::fabs(want[j]))); worst = std::max(worst, d > 0 ? rel : 0.0); if (d > 0) same = false; if (rel > 1e-12 && d > 1e-300) close = false; }
    check(name + ": values agree with the 5.6 binary to 1e-12 (relative)", close, std::to_string(want.size()) + " values, " + (same ? "all equal" : "largest relative difference " + mwa::fmt(worst)));
    fs::remove(state, ec);
  }
  const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::ostringstream o; o << "{\"tool\":\"mwcli selftest57\",\"version\":\"" << EM_VERSION << "\",\"build\":\"" << EM_BUILD_ID << "\",\"passed\":" << passed << ",\"failed\":" << failed << ",\"seconds\":" << mwa::fmt(secs) << ",\"checks\":[" << checks.str() << "],\"steps\":[" << steps.str() << "]}";
  { FILE *f = std::fopen(P("selftest57.json").c_str(), "wb"); if (f) { const std::string s = o.str(); std::fwrite(s.data(), 1, s.size(), f); std::fclose(f); } }
  std::printf("{\"tool\":\"mwcli selftest57\",\"build\":\"%s\",\"passed\":%d,\"failed\":%d,\"report\":%s}\n", EM_BUILD_ID, passed, failed, mwa::jsonEsc(P("selftest57.json")).c_str());
  return failed ? 1 : 0;
}
}
