// EightMax 5.6 study uncertainty: what a handful of independent trainings can and cannot support.
// See STATISTICAL-VALIDATION-5.6.md (and -5.5.md for the bounded-payoff intervals this builds on).
//
// 5.5 made the statement about the MEASURED strategies calibrated (study_stats55.hpp) and labelled the interval
// across trainings model-based. What it could not say is how far a result carries beyond the trainings that were
// run: a "ranked" verdict was true for the measured strategies in every validated scenario, yet in a scenario where
// one training in twenty fails badly it was issued in 79% of studies although the POPULATION MEAN did not rank.
// The mean over trainings has no distribution-free interval at five to ten replications (one rare catastrophic
// training moves it arbitrarily), so 5.6 does not try to bound it. It states three smaller things that hold for
// every distribution of training outcomes:
//
// 1. PER-TRAINING CERTIFICATES. For each trained strategy r and each other action i the bounded-payoff interval of
//    the gap EV(leader) - EV(i) is computed at level delta = 0.2 alpha' / (n (k-1)); all n(k-1) intervals hold
//    together with probability >= 1 - 0.2 alpha' (union bound; exact evaluations need no interval, and the
//    intervals are valid for whichever action turns out to lead because they are simultaneous in the sense that
//    one is computed for every training and every other action). Training r "certifies the
//    leader by the margin" when every lower limit exceeds the margin, "certifies a positive edge" when every lower
//    limit exceeds 0, and "certifies another action" when some upper limit is below 0.
//
// 2. THE TYPICAL TRAINING (sign test). The trainings are independent draws (different seeds) from one distribution
//    of training outcomes. If at most half of all trainings truly favoured the leader by the margin, the number s
//    of n that do would be stochastically below Binomial(n, 1/2). The claim "more than half of all trainings favour
//    the leader by the margin" is made when P(Bin(n,1/2) >= s) <= 0.4 alpha', counting only CERTIFIED trainings.
//    The leader is chosen from the same data, so the test is charged twice: a training can favour at most one
//    action by a positive margin, the events "action j is favoured in at least s trainings" are disjoint for
//    s > n/2, and over all actions j with P(favoured) <= 1/2 their probabilities sum to at most 2 P(Bin(n,1/2) >= s)
//    (attained by two actions favoured half of the time each). Total error: 2 x 0.4 alpha' (sign test with
//    selection) + 0.2 alpha' (certificates) = alpha' = alpha / family.
//    It needs 2^-n <= 0.4 alpha': six trainings for a single statement at alpha = 0.05, seven for a family of two,
//    nine for a family of nine (three variants at three budgets), ten up to a family of twenty. The family is the
//    number of (variant, budget) cells of the study, because each cell can carry one declaration; the comparisons
//    with the other actions inside a cell are already covered by (1) and by the disjointness argument above.
//    Below that NO number of agreeing trainings can support it and the verdict is insufficientReplication.
//    This is a statement about the MEDIAN training, never about the mean over trainings and never a prediction for
//    one further training.
//
// 3. WHAT COULD HIDE. If a fraction f of trainings fails, none of n fails with probability (1-f)^n. A failure mode
//    affecting fewer than 1 - 0.05^(1/n) of trainings is therefore more likely than 1 in 20 to leave no trace
//    (45% at n = 5, 39% at 6, 26% at 10, 14% at 20). The number is reported with every result so that agreement
//    among a few trainings is not read as evidence that failures are rare. A training that is SEEN to certify a
//    different action withdraws the declaration (verdict trainingsDisagree) whatever the others say.
//
// A best action is DECLARED only when the 5.5 verdict for the measured strategies is `ranked` and the sign test of
// (2) also supports the margin. Everything else is reported as measured, with the reason no declaration is made.
#pragma once
#include <cmath>
#include <string>
#include <vector>
#include <algorithm>
namespace study56 {
constexpr const char *CALCULATION = "study-5.6-replication-v1";
// P(Binomial(n, 1/2) >= s)
inline double binomialUpperTail(int n, int s) {
  if (s <= 0) return 1; if (s > n) return 0;
  long double c = 1, sum = 0;   // c = C(n, i)
  for (int i = 0; i <= n; i++) { if (i >= s) sum += c; c = c * (long double)(n - i) / (long double)(i + 1); }
  return (double)(sum * std::pow(0.5L, n));
}
inline int minimumTrainings(double signAlpha) { int n = 1; while (n < 62 && std::pow(0.5, n) > signAlpha) n++; return n; }
inline double undetectableFailureRate(int n, double miss = 0.05) { return n > 0 ? 1 - std::pow(miss, 1.0 / n) : 1.0; }
struct Replication {
  int trainings = 0, minimumTrainings = 0, family = 1, certifyMargin = 0, certifyPositive = 0, certifyAnother = 0, uncertified = 0;
  bool sufficient = false, calibrated = true, allExact = true;
  double alpha = 0.05, signAlpha = NAN, perIntervalDelta = NAN, pMargin = NAN, pPositive = NAN, undetectable = NAN;
  // order-statistic interval for the median of the leading-pair gap across trainings
  bool haveMedian = false; double medianLo = NAN, medianHi = NAN, medianCoverage = NAN; int medianRank = 0;
  std::string verdict = "notEvaluated", text;
};
// Largest j such that [x_(j), x_(n+1-j)] covers the median with probability >= 1 - level (two-sided), 0 if none.
inline int medianRank(int n, double level) { int best = 0; for (int j = 1; 2 * j <= n + 1; j++) if (2 * binomialUpperTail(n, n - j + 1) <= level) best = j; return best; }
inline void decide(Replication &r, bool singleAction, bool complete, double margin) {
  const int n = r.trainings;
  r.pMargin = binomialUpperTail(n, r.certifyMargin); r.pPositive = binomialUpperTail(n, r.certifyPositive);
  if (singleAction) { r.verdict = "singleAction"; r.text = "only one legal action"; }
  else if (!n) { r.verdict = "noData"; r.text = "no evaluated training"; }
  else if (!r.calibrated) { r.verdict = "uncalibrated"; r.text = "no statement across trainings: the evaluation of at least one training has no calibrated interval"; }
  else if (!complete) { r.verdict = "incomplete"; r.text = "partial study: nothing is stated across trainings until every requested seed completes"; }
  else if (r.certifyAnother > 0) { r.verdict = "trainingsDisagree"; r.text = std::to_string(r.certifyAnother) + " of " + std::to_string(n) + " trainings certify that a different action is better than the leader for that training: no best action is declared"; }
  else if (!r.sufficient) { r.verdict = "insufficientReplication"; r.text = std::to_string(n) + " independent trainings cannot support a distribution-free statement about the typical training at this confidence and comparison family (at least " + std::to_string(r.minimumTrainings) + " are needed, all agreeing)"; }
  else if (r.pMargin <= r.signAlpha) { r.verdict = "ranked"; r.text = "more than half of all trainings favour the leader over every other action by the declared margin (exact sign test on " + std::to_string(r.certifyMargin) + " of " + std::to_string(n) + " certified trainings; distribution-free; a statement about the median training, not the mean and not a single further training)"; }
  else if (r.pPositive <= r.signAlpha) { r.verdict = "smallEdge"; r.text = "more than half of all trainings favour the leader over every other action, but not by the declared margin (exact sign test on " + std::to_string(r.certifyPositive) + " of " + std::to_string(n) + " certified trainings)"; }
  else { r.verdict = "unresolved"; r.text = "the trainings do not agree often enough for a statement about the typical training (" + std::to_string(r.certifyMargin) + " of " + std::to_string(n) + " certify the margin, " + std::to_string(r.certifyPositive) + " a positive edge)"; }
}
}
