// 5.3 study uncertainty. See STUDY-STATISTICS-5.3.md for estimands and limits.
// Standalone so an independent Python/SciPy harness can exercise this exact code.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>
namespace study53 {
constexpr const char *CALCULATION = "study-5.3-tfloor-bonferroni-v1";
inline double betaFraction(double a, double b, double x) {
  const double tiny=1e-300; double c=1,d=1-(a+b)*x/(a+1); if(std::fabs(d)<tiny)d=tiny; d=1/d; double h=d;
  for(int m=1;m<=300;m++) { double aa=m*(b-m)*x/((a+2*m-1)*(a+2*m));
    d=1+aa*d;if(std::fabs(d)<tiny)d=tiny;c=1+aa/c;if(std::fabs(c)<tiny)c=tiny;d=1/d;h*=d*c;
    aa=-(a+m)*(a+b+m)*x/((a+2*m)*(a+2*m+1));
    d=1+aa*d;if(std::fabs(d)<tiny)d=tiny;c=1+aa/c;if(std::fabs(c)<tiny)c=tiny;d=1/d;double delta=d*c;h*=delta;if(std::fabs(delta-1)<2e-14)break;
  }return h;
}
inline double beta(double x,double a,double b) {
  if(x<=0)return 0;if(x>=1)return 1;
  double bt=std::exp(std::lgamma(a+b)-std::lgamma(a)-std::lgamma(b)+a*std::log(x)+b*std::log1p(-x));
  return x<(a+1)/(a+b+2)?bt*betaFraction(a,b,x)/a:1-bt*betaFraction(b,a,1-x)/b;
}
// Upper two-sided alpha critical value, accurate also at df=1 and small alpha.
inline double criticalUncached(double df,double alpha=.05) {
  if(!(df>=1 && alpha>0 && alpha<1))return NAN;
  // Avoid loss of precision for very large evaluator sample counts.
  df=std::min(df,100000.0);
  auto tail=[&](double t){return beta(df/(df+t*t),df/2,.5);};
  double lo=0,hi=2;while(tail(hi)>alpha && hi<1e15)hi*=2;
  for(int i=0;i<70;i++){double mid=(lo+hi)/2;if(tail(mid)>alpha)lo=mid;else hi=mid;}return (lo+hi)/2;
}
inline double critical(double df,double alpha=.05) {
  struct Entry{double df,alpha,value;};static thread_local std::vector<Entry> cache;
  for(const auto&e:cache)if(e.df==df&&e.alpha==alpha)return e.value;
  double v=criticalUncached(df,alpha);if(cache.size()>=256)cache.clear();cache.push_back({df,alpha,v});return v;
}
struct Stat {
  int n=0; double mean=NAN,sd=NAN,lo=NAN,hi=NAN,min=NAN,max=NAN;
  double evaluationSe=NAN,totalSe=NAN,conditionalLo=NAN,conditionalHi=NAN,betweenSd=NAN,crit=NAN,df=NAN;
  bool independent=true; int family=1;
};
inline Stat descriptive(const std::vector<double>&v) {
  Stat s;s.n=(int)v.size();if(!s.n)return s;
  long double sum=0;for(double x:v){if(!std::isfinite(x))return s;sum+=x;}s.mean=(double)(sum/s.n);
  s.min=*std::min_element(v.begin(),v.end());s.max=*std::max_element(v.begin(),v.end());
  if(s.n>1){long double q=0;for(double x:v)q+=(long double)(x-s.mean)*(x-s.mean);s.sd=std::sqrt((double)(q/(s.n-1)));}return s;
}
// ci95: mean over independent training replications (random-training estimand).
// max(observed SE, evaluation SE) never subtracts uncertainty from this interval.
// It contains the usual t interval under iid Gaussian replicate estimates; for
// non-Gaussian/heteroscedastic poker runs this is an approximation, not a proof.
// Shared/unknown evaluation streams: conditional ensemble interval uses the
// Cauchy-Schwarz upper bound sum(SE)/n; random-training interval is unavailable.
// evalDf is the minimum number of actual evaluation draws minus one.
inline Stat summarize(const std::vector<double>&v,const std::vector<double>&se,
                      bool independent=true,double evalDf=100000,int family=1) {
  Stat s=descriptive(v);s.independent=independent;s.family=std::max(1,family);
  if(!s.n || se.size()!=v.size() || !std::isfinite(s.mean))return s;
  double q=0,ss=0;for(double e:se){if(!std::isfinite(e)||e<0)return s;q+=e*e;ss+=e;}
  s.evaluationSe=(independent?std::sqrt(q):ss)/s.n;
  const bool exact=ss==0;
  if(!exact && !(evalDf>=1))return s;
  double h=exact?0:critical(evalDf,.05/s.family)*s.evaluationSe;
  s.conditionalLo=s.mean-h;s.conditionalHi=s.mean+h;
  if(s.n<2 || (!independent&&!exact))return s;
  s.df=exact?s.n-1:std::min((double)s.n-1,evalDf);
  s.crit=critical(s.df,.05/s.family);
  s.totalSe=std::max(s.sd/std::sqrt((double)s.n),s.evaluationSe);
  s.betweenSd=std::sqrt(std::max(0.0,s.sd*s.sd-q/s.n));
  h=s.crit*s.totalSe;s.lo=s.mean-h;s.hi=s.mean+h;return s;
}
inline uint32_t mix(uint32_t x) { x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;return x^(x>>16); }
inline uint32_t stream(uint32_t base,uint32_t train,uint32_t budget,const char *variant,uint32_t purpose) {
  uint32_t h=2166136261u;for(const unsigned char *p=(const unsigned char*)variant;*p;p++)h=(h^*p)*16777619u;
  return mix(base^mix(train)^mix(budget)^h^purpose);
}
}
