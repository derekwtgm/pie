#!/bin/sh
# EightMax 5.2 sanitizer pass. Runs the whole 5.1 pass (tools/sanitize51.sh, which includes 5.0), then the 5.2
# additions, which cover the native paths changed in 5.2 (study52.hpp, study_jobs.h, the deadline telemetry in
# ev_control.hpp and mw.cpp, mwcli --study):
#  - tests/v52.test.js against the UBSan+ASan CLI and the UBSan+ASan desktop host (study runner, refusals,
#    host study jobs including stop and concurrent start, 5.1 checkpoints, deadline telemetry);
#  - a ThreadSanitizer build of the complete host and CLI (build.sh with -fsanitize=thread):
#      a decision study with a parallel batched trainer and 4 workers (training, sampled EV, sampled quality),
#      a timed-out exact evaluation with 4 workers (the stop / late-worker / join telemetry is written by
#      several threads) and a cancelled one,
#      the host study job started, polled and stopped over HTTP;
#    results of the ThreadSanitizer study must equal the UBSan+ASan study (timings aside).
# Any sanitizer report fails the pass.  Usage: sh sanitize52.sh <source dir> [work dir]
set -eu
src=$(CDPATH= cd -- "$1" && pwd)
t=${2:-$(mktemp -d)}; mkdir -p "$t"; t=$(CDPATH= cd -- "$t" && pwd)
scan() { if grep -q 'runtime error\|ERROR: AddressSanitizer\|WARNING: ThreadSanitizer\|ERROR: LeakSanitizer' "$@"; then grep -h 'runtime error\|ERROR: AddressSanitizer\|WARNING: ThreadSanitizer\|ERROR: LeakSanitizer' -A14 "$@" | head -80; exit 1; fi; }
fail() { echo "$1"; exit 1; }
sh "$src/tools/sanitize51.sh" "$src" "$t"
echo "== UBSan+ASan CLI and host: tests/v52.test.js"
rm -f "$t/host52-ub.err"
ASAN_OPTIONS=detect_leaks=0 EM_TEST_HOST_STDERR="$t/host52-ub.err" EM_TEST_HOST="$t/ub/eightmax" EM_TEST_MWCLI="$t/ub/mwcli" node --test --test-reporter=tap --test-concurrency=1 "$src/tests/v52.test.js" > "$t/v52.tap" 2>&1 || { grep -E '^not ok|rror' -A10 "$t/v52.tap" | head -60; exit 1; }
grep -E '^# (pass|fail|skipped)' "$t/v52.tap"; scan "$t/v52.tap"; [ ! -f "$t/host52-ub.err" ] || scan "$t/host52-ub.err"
echo "== ThreadSanitizer build of the host and CLI"
[ -x "$t/ts/mwcli" ] || sh "$src/tools/build_sanitized_host.sh" "$src" "$t/ts" thread
TS="setarch -R"; export TSAN_OPTIONS="halt_on_error=1 second_deadlock_stack=1"
node -e 'const fs=require("fs");const f=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));f.study.trainer={name:"parallel batches (sanitizer run)",batchDeals:64,actionStreams:"deal",batchSchedule:{start:4,doubleEvery:8}};f.study.ev={method:"sampled",samples:4000,seed:5};f.study.quality={method:"sampled",samples:2000,selectionSamples:32,seed:5};fs.writeFileSync(process.argv[2],JSON.stringify(f))' "$src/studies/flop6-jack-small.emfix.json" "$t/san-study.json"
for b in ub ts; do
  pre=""; [ $b = ts ] && pre="$TS"
  ASAN_OPTIONS=detect_leaks=1 $pre "$t/$b/mwcli" --study "$t/san-study.json" "$t/study-$b.json" quiet=1 seeds=2 budgets=3000,12000 threads=4 > "$t/study-$b.out" 2> "$t/study-$b.err" || { tail -20 "$t/study-$b.err"; fail "study ($b) failed"; }
  scan "$t/study-$b.err"
done
node -e 'const fs=require("fs");const s=f=>JSON.stringify(JSON.parse(fs.readFileSync(f,"utf8")),(k,v)=>/Seconds|PeakRss|elapsed|logicalProcessors|build|version/i.test(k)?undefined:v);if(s(process.argv[1])!==s(process.argv[2])){console.error("study results differ between the sanitized builds");process.exit(1);}const d=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));console.log("  study: "+d.variants.length+" variants, "+d.run.seeds.length+" seeds, training threads used "+d.variants[0].budgets[1].trainingThreadsUsed+", identical under both sanitizers")' "$t/study-ub.json" "$t/study-ts.json" || fail 'study results differ'
echo "== deadline and cancellation with 4 evaluation workers under ThreadSanitizer and ASan+UBSan"
node -e 'const fs=require("fs");const f=JSON.parse(fs.readFileSync(process.argv[1],"utf8")),v=f.variants[0];fs.writeFileSync(process.argv[2]+"/dl.spec.json",JSON.stringify(v.nativeSpec));fs.writeFileSync(process.argv[2]+"/dl.q.json",JSON.stringify({path:v.decision.path,board:[],hands:[v.decision.handIndex],method:"exact",timeLimitMs:300,threads:4,maxVisits:2000000000}));fs.writeFileSync(process.argv[2]+"/dl.c.json",JSON.stringify({path:v.decision.path,board:[],hands:[v.decision.handIndex],method:"exact",timeLimitMs:60000,threads:4,maxVisits:2000000000}))' "$src/studies/icm8-bb-call.emfix.json" "$t"
"$t/ub/mwcli" "$t/dl.spec.json" 2000 2 "$t/dl.state" 512 > /dev/null 2> "$t/dl-train.err"; scan "$t/dl-train.err"
for b in ub ts; do
  pre=""; [ $b = ts ] && pre="$TS"
  EM_QUERY_TIMING=1 $pre "$t/$b/mwcli" --ev "$t/dl.spec.json" "$t/dl.state" "$t/dl.q.json" > /dev/null 2> "$t/dl-$b.err" && fail "deadline ($b): the exact evaluation should time out"
  scan "$t/dl-$b.err"; grep -q '"status":408' "$t/dl-$b.err" || { cat "$t/dl-$b.err"; fail "deadline ($b): expected status 408"; }
  grep -q '"workersJoinedMs":[0-9]' "$t/dl-$b.err" || fail "deadline ($b): no join telemetry"
  EM_CANCEL_AFTER_MS=200 $pre "$t/$b/mwcli" --ev "$t/dl.spec.json" "$t/dl.state" "$t/dl.c.json" > /dev/null 2> "$t/dc-$b.err" && fail "cancel ($b): the evaluation should be cancelled"
  scan "$t/dc-$b.err"; grep -q '"status":409' "$t/dc-$b.err" || { cat "$t/dc-$b.err"; fail "cancel ($b): expected status 409"; }
  echo "  $b: timeout $(grep -o '"lastWorkerSite":"[a-z]*"' "$t/dl-$b.err") $(grep -o '"workersJoinedMs":[0-9.]*' "$t/dl-$b.err"); cancel $(grep -o '"cancelLatencyMs":[0-9.]*' "$t/dc-$b.err")"
done
echo "== tests/coverage52.cpp (stop inside a tier promotion) under ASan+UBSan"
g++ -std=c++20 -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined,float-cast-overflow -fno-sanitize-recover=all -I"$src/native" "$src/tests/coverage52.cpp" -lpthread -o "$t/coverage52-ub"
ASAN_OPTIONS=detect_leaks=1 "$t/coverage52-ub" > "$t/coverage52-ub.out" 2> "$t/coverage52-ub.err" || { cat "$t/coverage52-ub.out" "$t/coverage52-ub.err" | tail -20; fail 'coverage52 failed under ASan+UBSan'; }
scan "$t/coverage52-ub.err"; echo "  $(tail -1 "$t/coverage52-ub.out")"
echo "== host study job (start, poll, stop, concurrent start) under ThreadSanitizer"
rm -f "$t/host52-ts.err"
EM_TEST_HOST_STDERR="$t/host52-ts.err" EM_TEST_HOST="$t/ts/eightmax" EM_TEST_MWCLI="$t/ts/mwcli" $TS node --test --test-reporter=tap --test-concurrency=1 --test-name-pattern='native host' "$src/tests/v52.test.js" > "$t/v52-ts.tap" 2>&1 || { grep -E '^not ok|rror' -A10 "$t/v52-ts.tap" | head -60; exit 1; }
grep -E '^# (pass|fail|skipped)' "$t/v52-ts.tap"; scan "$t/v52-ts.tap"; [ ! -f "$t/host52-ts.err" ] || scan "$t/host52-ts.err"
echo "sanitize52: all passed"
