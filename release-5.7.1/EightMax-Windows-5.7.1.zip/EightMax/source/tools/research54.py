#!/usr/bin/env python3
"""Fixed-plan convergence comparison. Usage: research54.py OLD_CLI NEW_CLI OUTPUT_DIRECTORY.
Requires Python/SciPy, Node, GCC for the optional Linux peak-RSS wrapper. Research only.
All plan comparisons are retained; no optional stopping or default promotion is performed.
"""
import sys,pathlib,json,subprocess,time,resource,os,hashlib,math,statistics,platform,re,shutil
from scipy import stats
old,new=map(lambda s:str(pathlib.Path(s).resolve()),sys.argv[1:3]);out=pathlib.Path(sys.argv[3]).resolve();out.mkdir(parents=True,exist_ok=True);root=pathlib.Path(__file__).resolve().parent
if (out/'raw.jsonl').exists():raise SystemExit('Use a fresh output directory; old results must not be mixed.')
arms={'baseline53':{},'default54':{},'terminal-baseline':{'terminalBaseline':True},'dcfr':{'weighting':'dcfr'},'dcfr-average3':{'weighting':'dcfr','dcfrGamma':3},'cfr-plus':{'regretMatching':'plus'},'uniform':{'weighting':'uniform'}}
plan={'games':['hu-river','river3-chip','bubble4'],'seeds':list(range(901,911)),'arms':arms,'deals':[4000,20000,100000],'trainingSeconds':[.1],'threads':1,'evaluationThreads':1,'memoryMiB':128,'evaluation':'exact all-seat best response, CPU, separate process from training','comparison':'paired raw NashConv differences; simultaneous Student-t intervals using Bonferroni over the entire predeclared family; approximate across non-Gaussian training outcomes','environment':platform.platform(),'baselineSha256':hashlib.sha256(pathlib.Path(old).read_bytes()).hexdigest(),'currentSha256':hashlib.sha256(pathlib.Path(new).read_bytes()).hexdigest()}
(out/'plan.json').write_text(json.dumps(plan,indent=2));peak=root.parent/'build/peak_rss';peak.parent.mkdir(exist_ok=True);subprocess.run(['gcc','-O2',str(root/'peak_rss.c'),'-o',str(peak)],check=True)
rows=[]
def call(cli,args,env=None):
 t=time.perf_counter();c=resource.getrusage(resource.RUSAGE_CHILDREN);p=subprocess.run([str(peak),cli,*map(str,args)],capture_output=True,text=True,timeout=240,env=env);e=resource.getrusage(resource.RUSAGE_CHILDREN)
 if p.returncode:raise RuntimeError(p.stderr)
 d=json.loads(p.stdout);m=re.search(r'peakRssKiB=(\d+)',p.stderr);return d,time.perf_counter()-t,(e.ru_utime+e.ru_stime)-(c.ru_utime+c.ru_stime),int(m[1])/1024 if m else None
for game in plan['games']:
 for seed in plan['seeds']:
  order=list(arms);order=order[seed%len(order):]+order[:seed%len(order)]
  for arm in order:
   d=out/'checkpoints'/game/str(seed)/arm;d.mkdir(parents=True,exist_ok=True);sp=d/'spec.json';st=d/'state';q=d/'query.json';start=time.perf_counter()
   subprocess.run(['node',str(root/'games48.js'),'spec',game,str(sp),str(seed),json.dumps({**arms[arm],'batchDeals':1,'device':'cpu'})],check=True,capture_output=True)
   q.write_text(json.dumps({'method':'exact','device':'cpu','threads':1,'timeLimitMs':180000,'maxVisits':2000000000,'memoryMiB':128}));setup=time.perf_counter()-start
   cli=old if arm=='baseline53' else new;done=0;train=0;process=0;cpu=0;evsum=0;rss=0
   for kind,budgets in [('deals',plan['deals']),('time',plan['trainingSeconds'])]:
    for budget in budgets:
     if kind=='time':args=[sp,10000000,1,str(st)+'.next',128];env={**os.environ,'EM_TRAIN_CANCEL_AFTER_MS':str(round(budget*1000))};train=process=cpu=evsum=rss=0
     else:args=[sp,budget-done,1,str(st)+'.next',128]+([st] if done else []);env=None
     info,sec,c,mem=call(cli,args,env);os.replace(str(st)+'.next',st);train+=info['wallSeconds'];process+=sec;cpu+=c;rss=max(rss,mem or 0)
     gain,evsec,evcpu,mem=call(new,['--gain',sp,st,q,128]);evsum+=evsec;cpu+=evcpu;rss=max(rss,mem or 0)
     if kind=='deals':done=budget
     shutil.copyfile(st,d/f'{kind}-{budget}.state')
     row={'game':game,'seed':seed,'arm':arm,'kind':kind,'budget':budget,'deals':info['trainingDeals'],'trainingSeconds':train,'trainingProcessSeconds':process,'evaluationSeconds':evsec,'evaluationSecondsCumulative':evsum,'setupSeconds':setup,'totalSeconds':setup+process+evsum,'cpuSeconds':cpu,'peakRssMiB':rss,'gpuPeakMiB':None,'nashConv':gain['nashConv'],'exploitability':gain.get('exploitability'),'largestUnilateralGain':gain['largestUnilateralGain'],'seatGains':[s['gain'] for s in gain['seats']],'policyValues':[s['policyValue'] for s in gain['seats']],'checkpointSha256':hashlib.sha256(st.read_bytes()).hexdigest(),'memoryStopped':info.get('limitReached',False),'cancelled':info.get('cancelled',False),'trainingInfo':info}
     rows.append(row)
     with (out/'raw.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(game,seed,arm,flush=True)
family=len(plan['games'])*(len(arms)-1)*(len(plan['deals'])+len(plan['trainingSeconds']));comp=[]
for game in plan['games']:
 for arm in list(arms)[1:]:
  for kind,budgets in [('deals',plan['deals']),('time',plan['trainingSeconds'])]:
   for budget in budgets:
    B={r['seed']:r for r in rows if (r['game'],r['arm'],r['kind'],r['budget'])==(game,'baseline53',kind,budget)};A={r['seed']:r for r in rows if (r['game'],r['arm'],r['kind'],r['budget'])==(game,arm,kind,budget)}
    dif=[A[s]['nashConv']-B[s]['nashConv'] for s in plan['seeds']];n=len(dif);mean=statistics.mean(dif);half=float(stats.t.ppf(1-.05/(2*family),n-1))*statistics.stdev(dif)/math.sqrt(n)
    comp.append({'game':game,'arm':arm,'kind':kind,'budget':budget,'n':n,'difference':mean,'simultaneousCi95':[mean-half,mean+half],'baselineMean':statistics.mean(r['nashConv'] for r in B.values()),'candidateMean':statistics.mean(r['nashConv'] for r in A.values()),'familySize':family,'verdict':'better' if mean+half<0 else 'worse' if mean-half>0 else 'unresolved'})
(out/'summary.json').write_text(json.dumps({'plan':plan,'comparisons':comp,'rows':len(rows)},indent=2))
