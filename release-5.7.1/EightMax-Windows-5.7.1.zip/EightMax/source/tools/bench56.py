#!/usr/bin/env python3
"""EightMax 5.6 performance comparison against the unchanged 5.5 binary.
Usage: bench56.py MWCLI_5.5 MWCLI_5.6 OUTDIR [sections] [--threads N] [--reps R]
sections: comma list of study,evaluation,memory (default all). Rows are appended to OUTDIR/runs.jsonl as they are
measured; every run is kept, including runs that time out.

  study       complete decision studies with identical options, alternating binaries. Wall time, the sums of
              training / action-EV / quality seconds over the study's points, peak resident memory, and a comparison
              of every per-seed measurement of the two versions (identical for sampled evaluation; exact evaluation
              may differ in the last bits where 5.6 sums a runout through a showdown table: tolerance 1e-9 relative).
  evaluation  exact all-seat best response (mwcli --gain) on states trained once, with a 128 MiB and a 1,024 MiB
              evaluator cache. A 5.5 run that exceeds --eval-timeout seconds is recorded as not finished.
  memory      peak resident memory of training alone at fixed sampled deals (tools/peak_rss.c), both versions.
Training throughput has its own tool (trainbench56.py). Run on an otherwise idle machine; nothing here is a claim
about another machine."""
import sys, json, subprocess, time, pathlib, platform, os, hashlib, resource, argparse, statistics
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('sections', nargs='?', default='study,evaluation,memory')
ap.add_argument('--threads', type=int, default=4); ap.add_argument('--reps', type=int, default=2); ap.add_argument('--eval-timeout', type=int, default=900)
A = ap.parse_args(); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); out = pathlib.Path(A.out).resolve(); out.mkdir(parents=True, exist_ok=True); SECTIONS = A.sections.split(',')
root = pathlib.Path(__file__).resolve().parent.parent; tools = root / 'tools'; fx = lambda n: str(root / 'studies' / (n + '.emfix.json'))
WORK = [   # name, fixture, options (identical for both versions)
 ('akq-river exact, standard preset', 'known-akq-river', ['preset=standard']),
 ('3-player preflop small, sampled, standard preset', 'btn25-open-small', ['preset=standard']),
 ('3-player flop small, exact, standard preset', 'flop3-kings-small', ['preset=standard']),
 ('6-player flop, sampled, standard preset', 'flop6-jack', ['preset=standard']),
 ('3-player flop, sampled, standard preset', 'flop3-kings', ['preset=standard']),
 ('8-handed ICM small, exact, 2 seeds x 2 budgets', 'icm8-bb-call-small', ['seeds=101,102', 'budgets=1000,10000', 'variants=baseline', 'memoryMiB=512', 'timeLimitSeconds=900']),
 ('6-player flop small, exact, 2 seeds x 2 budgets', 'flop6-jack-small', ['seeds=101,102', 'budgets=1000,10000', 'variants=baseline', 'memoryMiB=512', 'timeLimitSeconds=900']),
 ('8-handed ICM, sampled, standard preset', 'icm8-bb-call', ['preset=standard']),
]
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
env = {'platform': platform.platform(), 'logicalProcessors': os.cpu_count(), 'threadsRequested': A.threads, 'repetitions': A.reps, 'old': sha(old), 'new': sha(new), 'memTotalKiB': int(open('/proc/meminfo').readline().split()[1]),
       'cpu': next((l.split(':')[1].strip() for l in open('/proc/cpuinfo') if l.startswith('model name')), '?'), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'note': 'shared cloud container; not the target Windows i7 / RTX 4060 Ti machine'}
if not (out / 'environment.json').exists(): (out / 'environment.json').write_text(json.dumps(env, indent=1))
log = (out / 'runs.jsonl').open('a'); rows = []
def rec(**k): rows.append(k); log.write(json.dumps(k) + '\n'); log.flush(); print(json.dumps({x: (round(y, 3) if isinstance(y, float) else y) for x, y in k.items() if x not in ('result',)})[:320], flush=True)
def study(cli, fixture, opts, tag):
    res = out / 'results' / (tag + '.json'); res.parent.mkdir(exist_ok=True); t = time.perf_counter(); r0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    p = subprocess.run([cli, '--study', fx(fixture), str(res), *opts, 'quiet=1'], capture_output=True, text=True); wall = time.perf_counter() - t; r1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    if p.returncode: return {'error': p.stderr[-400:], 'wallSeconds': wall}
    d = json.load(open(res)); tr = ev = q = 0; pts = done = 0
    for v in d['variants']:
        for s in v['perSeed']:
            last = 0
            for b in s['budgets']:
                if b['status'] == 'unstarted': continue
                pts += 1; done += b['complete']; tr += b['trainingSecondsCumulative'] - last; last = b['trainingSecondsCumulative']; ev += b['evSeconds']; q += b['qualitySeconds']
    run = d['run']
    return {'wallSeconds': wall, 'studySeconds': run['elapsedSeconds'], 'cpuSeconds': (r1.ru_utime + r1.ru_stime) - (r0.ru_utime + r0.ru_stime), 'trainingSecondsSum': tr, 'actionEvSecondsSum': ev, 'qualitySecondsSum': q, 'pointsCompleted': done,
            'pointsRequested': sum(len(s['budgets']) for v in d['variants'] for s in v['perSeed']), 'peakRssMiB': run['processPeakRssMiB'], 'stoppedByTimeLimit': run['stoppedByTimeLimit'], 'parallelSeeds': run.get('parallelSeeds'), 'result': str(res.relative_to(out))}
def close(a, b):
    if isinstance(a, list): return isinstance(b, list) and len(a) == len(b) and all(close(x, y) for x, y in zip(a, b))
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool): return a == b or abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))
    return a == b
def same_numbers(a, b):
    X, Y = json.load(open(out / a)), json.load(open(out / b)); n = exact = within = bad = 0; worst = 0.0
    for va, vb in zip(X['variants'], Y['variants']):
        for sa, sb in zip(va['perSeed'], vb['perSeed']):
            for pa, pb in zip(sa['budgets'], sb['budgets']):
                if not (pa.get('complete') and pb.get('complete')): continue
                n += 1; keys = ('ev', 'frequency', 'evStdErr', 'quality', 'qualityStdErr', 'deals', 'rows', 'evaluationSeed')
                if all(pa.get(k) == pb.get(k) for k in keys): exact += 1
                elif all(close(pa.get(k), pb.get(k)) for k in keys):
                    within += 1
                    for k in ('ev', 'quality'):
                        xs, ys = (pa[k], pb[k]) if isinstance(pa.get(k), list) else ([pa.get(k)], [pb.get(k)])
                        for x, y in zip(xs, ys):
                            if isinstance(x, (int, float)) and isinstance(y, (int, float)): worst = max(worst, abs(x - y) / max(1.0, abs(x)))
                else: bad += 1
    return {'pointsCompared': n, 'pointsBitIdentical': exact, 'pointsWithin1e-9': within, 'pointsDiffering': bad, 'largestRelativeDifference': worst}
if 'study' in SECTIONS:
    for name, fixture, opts in WORK:
        for rep in range(A.reps):
            for ver, cli in ([('5.5', old), ('5.6', new)] if rep % 2 == 0 else [('5.6', new), ('5.5', old)]):
                r = study(cli, fixture, opts + ['threads=%d' % A.threads, 'checkpoint=off'], f'{fixture}-{ver}-r{rep}'); rec(section='study', workload=name, fixture=fixture, version=ver, rep=rep, threads=A.threads, **r)
        a = [r for r in rows if r['section'] == 'study' and r['workload'] == name and r['version'] == '5.5' and 'result' in r]; b = [r for r in rows if r['section'] == 'study' and r['workload'] == name and r['version'] == '5.6' and 'result' in r]
        if a and b: rec(section='agreement', workload=name, **same_numbers(a[0]['result'], b[0]['result']))
peak = out / 'peak_rss'
if 'evaluation' in SECTIONS or 'memory' in SECTIONS: subprocess.run(['gcc', '-O2', str(tools / 'peak_rss.c'), '-o', str(peak)], check=True)
def timed(args, timeout, env=None):
    import re
    t = time.perf_counter()
    try: p = subprocess.run([str(peak), *map(str, args)], capture_output=True, text=True, timeout=timeout, env=env)
    except subprocess.TimeoutExpired: return None, time.perf_counter() - t, None, 'timeout'
    m = re.search(r'peakRssKiB=(\d+)', p.stderr); return (json.loads(p.stdout) if p.returncode == 0 and p.stdout.strip() else None), time.perf_counter() - t, (int(m[1]) / 1024 if m else None), (None if p.returncode == 0 else p.stderr[-200:])
if 'evaluation' in SECTIONS:
    w = out / 'evaluation'; w.mkdir(exist_ok=True)
    for game, deals in [('bubble4', 100000), ('final8', 100000), ('flop5', 100000), ('flop6', 100000), ('flop6w', 100000), ('final8w', 100000), ('turn4', 100000), ('river3-chip', 100000)]:
        sp = w / (game + '.json'); st = w / (game + '.state')
        subprocess.run(['node', str(tools / 'games48.js'), 'spec', game, str(sp), '901', json.dumps({'batchDeals': 1, 'device': 'cpu'})], check=True, capture_output=True)
        subprocess.run([new, str(sp), str(deals), '1', str(st), '128'], check=True, capture_output=True)
        for mem in (128, 1024):
            q = w / ('q%d.json' % mem); q.write_text(json.dumps({'method': 'exact', 'device': 'cpu', 'threads': 1, 'timeLimitMs': A.eval_timeout * 1000, 'maxVisits': 2000000000, 'memoryMiB': mem})); vals = {}
            for ver, cli in (('5.6', new), ('5.5', old)):
                g, sec, rss, err = timed([cli, '--gain', sp, st, q, 128], A.eval_timeout + 30)
                vals[ver] = g['nashConv'] if g else None
                rec(section='evaluation', game=game, cacheMiB=mem, version=ver, seconds=sec, peakRssMiB=rss, nashConv=vals[ver], finished=g is not None, error=None if g else (err or 'time limit'), threads=1)
            if vals['5.5'] is not None and vals['5.6'] is not None: rec(section='evaluationAgreement', game=game, cacheMiB=mem, bitIdentical=vals['5.5'] == vals['5.6'], relativeDifference=abs(vals['5.5'] - vals['5.6']) / max(1e-300, abs(vals['5.5'])))
if 'memory' in SECTIONS:
    w = out / 'memory'; w.mkdir(exist_ok=True)
    for name in ['flop3-kings', 'flop6-jack', 'icm8-bb-call', 'btn25-open', 'flop3-kings-detailed']:
        d = json.load(open(fx(name))); sp = w / (name + '.spec.json'); sp.write_text(json.dumps(d['variants'][0]['nativeSpec'])); mem = int(d['study'].get('memoryMiB', 1024))
        for ver, cli in (('5.5', old), ('5.6', new)):
            info, sec, rss, err = timed([cli, sp, 1000000, 1, w / 'x.state', mem], 3600)
            rec(section='memory', fixture=name, version=ver, deals=info and info['trainingDeals'], seconds=sec, trainingWallSeconds=info and info['wallSeconds'], peakRssMiB=rss, tableMiB=info and info['tableMiB'], stateCacheBytes=info and info['stateCache']['bytes'], linkCacheBytes=info and (info.get('linkCache') or {}).get('bytes'), error=err)
        (w / 'x.state').unlink(missing_ok=True)
(out / 'summary.json').write_text(json.dumps({'environment': env, 'rows': rows}, indent=1))
