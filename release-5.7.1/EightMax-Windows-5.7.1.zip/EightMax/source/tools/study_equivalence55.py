#!/usr/bin/env python3
"""EightMax 5.5: are two study result documents the same study result?
Usage: study_equivalence55.py A.json B.json [--quiet]     exit 0 equal, 1 different, 2 unreadable

Equivalence contract (CHECKPOINT-RECOVERY-5.5.md): every measurement, statistic, verdict, seed and identifier must be
byte-identical after removing SESSION fields, which describe how and when the numbers were produced, not the numbers:
wall-clock timings, memory readings, worker counts, checkpoint/resume bookkeeping and stop flags of a session.
Prints the canonical SHA-256 of each document and the first differing paths.
"""
import json, sys, hashlib
SESSION = {'elapsedSeconds', 'processPeakRssMiB', 'trainingSecondsCumulative', 'evSeconds', 'qualitySeconds', 'trainingSecondsMean', 'evSecondsMean', 'qualitySecondsMean',
           'trainingSecondsAtFirstBudgetMeetingTolerance', 'checkpoint', 'checkpointPolicy', 'parallelSeeds', 'parallelSeedsAutomatic', 'threadsPerSeed', 'threadsRequested', 'logicalProcessors',
           'processMemoryBudgetMiB', 'processMemoryBudgetAutomatic', 'physicalMemoryMiB', 'memoryPerSeedAllowanceMiB', 'evaluationMemoryMiB', 'evaluationMemoryAutomatic', 'trainingThreads', 'trainingThreadsUsed', 'timeLimitSeconds',
           # table memory in use is an allocation reading: vector capacities after a restore differ from those grown in place
           'tableMiB', 'tableMiBMax'}
def strip(x):
    if isinstance(x, dict): return {k: strip(v) for k, v in x.items() if k not in SESSION}
    if isinstance(x, list): return [strip(v) for v in x]
    return x
def canon(path):
    d = strip(json.load(open(path))); return d, hashlib.sha256(json.dumps(d, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
def diff(a, b, path, out):
    if len(out) >= 12: return
    if type(a) != type(b): out.append(path + ': type'); return
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b: out.append(path + '/' + k + ': missing on one side')
            else: diff(a[k], b[k], path + '/' + k, out)
    elif isinstance(a, list):
        if len(a) != len(b): out.append(path + ': length %d vs %d' % (len(a), len(b))); return
        for i, (x, y) in enumerate(zip(a, b)): diff(x, y, path + '/%d' % i, out)
    elif a != b: out.append(path + ': %r vs %r' % (a, b))
if __name__ == '__main__':
    try: (a, ha), (b, hb) = canon(sys.argv[1]), canon(sys.argv[2])
    except Exception as e: print('unreadable:', e); sys.exit(2)
    out = []; diff(a, b, '', out)
    if '--quiet' not in sys.argv:
        print(ha, sys.argv[1]); print(hb, sys.argv[2])
        for o in out: print('  differs', o)
    print('EQUIVALENT' if ha == hb else 'DIFFERENT'); sys.exit(0 if ha == hb else 1)
