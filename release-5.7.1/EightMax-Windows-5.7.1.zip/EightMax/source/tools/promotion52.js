// EightMax 5.2: stop latency when the stop falls into a coverage-tier promotion (the long section found by the 5.2
// deadline telemetry). Eight-player linked ICM study, sampled whole-range evaluation (the workload of tools/deadline52.js
// whose check gaps were 80-145 ms). For 1 and 2 evaluation workers, with the 5.2 check and with EM_EV_PROMOTION_CHECK=0
// (5.1 behaviour), a cancellation is raised at every 3 ms from 60 to 420 ms after the start and, separately, the time
// limit is set to each of those values. Reports n, median, p95, p99 and maximum of the return latency after the stop.
//   node tools/promotion52.js <mwcli> <out.json> [--cpus=2,3]
'use strict';
process.env.EM_EV_DIRECT_PATTERNS = '1';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river']) require('../web/' + l);
const [cliArg, out] = process.argv.slice(2).filter(a => !a.startsWith('--')), cli = path.resolve(cliArg), cpus = (process.argv.find(a => a.startsWith('--cpus=')) || '').slice(7);
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em52-promo-')), spec = path.join(dir, 's.json'), state = path.join(dir, 's.state'), q = path.join(dir, 'q.json');
fs.writeFileSync(spec, JSON.stringify(E.MultiwayGame({ privateMode: 'sampled', abstraction: 'exact', traversal: 'external', evaluationDeals: 128, preflop: { mode: 'linked', opens: '2.2,a', raises: 'a', maxBets: 2 }, board: '', dealt: 8, common: 0, stacks: [30, 22, 15, 40, 9, 18, 25, 12], ranges: Array(8).fill('random'), icm: { payouts: [30, 20, 14, 11, 9, 7, 5, 4] }, streets: { flop: { bets: '50', raises: '', maxBets: 1 }, turn: { bets: 'a', raises: '', maxBets: 1 }, river: { bets: 'a', raises: '', maxBets: 1 } }, batchDeals: 4, actionStreams: 'deal', privateSeed: 4 }).nativeSpec()));
cp.execFileSync(cli, [spec, '20', '2', state, '512']);
const run = (query, env, pin) => { fs.writeFileSync(q, JSON.stringify(query)); const r = cp.spawnSync(pin ? 'taskset' : cli, pin ? ['-c', pin, cli, '--ev', spec, state, q] : ['--ev', spec, state, q], { encoding: 'utf8', maxBuffer: 64 << 20, env: { ...process.env, EM_QUERY_TIMING: '1', ...env } }); try { return JSON.parse(r.stderr.split('\n')[0]); } catch { return null; } };
const qt = (a, p) => { const s = a.slice().sort((x, y) => x - y), i = (s.length - 1) * p, lo = Math.floor(i); return +(s[lo] + (s[Math.ceil(i)] - s[lo]) * (i - lo)).toFixed(2); };
const stat = a => ({ n: a.length, median: qt(a, 0.5), p95: qt(a, 0.95), p99: qt(a, 0.99), max: qt(a, 1) });
const report = { tool: 'promotion52', generated: new Date().toISOString(), build: cp.execFileSync(cli, ['--build-id'], { encoding: 'utf8' }).trim(), cpu: os.cpus()[0].model, logicalCpus: os.cpus().length, pinnedCpus: cpus || null, stopTimesMs: '60 to 420 step 3', conditions: [] };
for (const workers of [1, 2]) for (const mode of ['5.2 (promotion reads the clock)', '5.1 behaviour (EM_EV_PROMOTION_CHECK=0)']) {
  const env = mode.startsWith('5.1') ? { EM_EV_PROMOTION_CHECK: '0' } : {}, pin = cpus ? cpus.split(',').slice(0, workers).join(',') : null, cancel = [], limit = [], gaps = [];
  for (let ms = 60; ms <= 420; ms += 3) {
    const c = run({ path: [], hands: [3], range: true, method: 'sampled', samples: 2000000, timeLimitMs: 600, threads: workers }, { ...env, EM_CANCEL_AFTER_MS: String(ms) }, pin); if (c && c.cancelLatencyMs != null) cancel.push(c.cancelLatencyMs);
    const d = run({ path: [], hands: [3], range: true, method: 'sampled', samples: 2000000, timeLimitMs: ms + 40, threads: workers }, env, pin); if (d) { limit.push(d.queryMs - (ms + 40)); gaps.push(d.evaluator.maxCheckGapMs); }
  }
  const row = { evaluationWorkers: workers, mode, cancelLatencyMs: stat(cancel), deadlineOvershootMs: stat(limit), longestCheckGapMs: stat(gaps) }; report.conditions.push(row);
  console.log(workers + ' worker(s), ' + mode + ': cancel ' + JSON.stringify(row.cancelLatencyMs) + ' deadline overshoot ' + JSON.stringify(row.deadlineOvershootMs));
}
fs.rmSync(dir, { recursive: true, force: true }); fs.writeFileSync(out, JSON.stringify(report, null, 1));
