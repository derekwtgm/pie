// EightMax 5.2: training time and memory of each study on an otherwise idle machine. The decision studies of the 5.2
// release were run on one CPU while other work used the machine, so the times inside their result documents are
// upper bounds. This tool repeats only the TRAINING of the baseline variant (first seed) of each fixture through its
// budgets, with the requested worker threads, and records seconds and peak RSS. Results at equal seeds and deals
// are deterministic, so no evaluation is repeated.
//   node tools/timing52.js <mwcli> <studies dir> <out.json> [--threads=1]
'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const [cli, dir, out] = process.argv.slice(2).filter(a => !a.startsWith('--')), threads = +((process.argv.find(a => a.startsWith('--threads=')) || '--threads=1').slice(10));
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'em52-time-')), studies = {};
for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.emfix.json')).sort()) {
  const fx = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8')), v = fx.variants[0], seed = fx.study.seeds[0], spec = { ...v.nativeSpec, actionSeed: (seed ^ 0x7138ab94) >>> 0, state: { ...v.nativeSpec.state, rng: seed, actionRng: (seed ^ 0x7138ab94) >>> 0 } }; delete spec.studyId;
  const sf = path.join(tmp, 's.json'), st = path.join(tmp, 's.state'); fs.writeFileSync(sf, JSON.stringify(spec)); fs.rmSync(st, { force: true });
  let deals = 0, secs = 0; const rows = [];
  for (const b of fx.study.budgetsDeals) {
    const r = cp.spawnSync(path.resolve(cli), [sf, b - deals, threads, st + '.n', fx.study.memoryMiB, ...(deals ? [st] : [])].map(String), { encoding: 'utf8', maxBuffer: 64 << 20 });
    if (r.status !== 0) { rows.push({ deals: b, error: r.stderr.trim().slice(0, 200) }); break; }
    const info = JSON.parse(r.stdout); fs.renameSync(st + '.n', st); secs += info.wallSeconds; deals = info.trainingDeals;
    rows.push({ deals: b, dealsReached: deals, trainingSeconds: secs, threads: info.threads, rows: info.rows, tableMiB: info.tableMiB, peakRssMiB: info.processPeakRssMiB, limitReached: info.limitReached });
    if (info.limitReached) break;
  }
  studies[fx.id] = rows; console.log(fx.id.padEnd(22), rows.map(r => r.error ? 'error' : Math.round(r.deals / 1000) + 'k: ' + r.trainingSeconds.toFixed(1) + ' s, ' + Math.round(r.peakRssMiB) + ' MiB' + (r.limitReached ? ' (table budget reached at ' + r.dealsReached + ')' : '')).join(' | '));
}
fs.rmSync(tmp, { recursive: true, force: true });
fs.writeFileSync(out, JSON.stringify({ tool: 'timing52', generated: new Date().toISOString(), build: cp.execFileSync(path.resolve(cli), ['--build-id'], { encoding: 'utf8' }).trim(), cpu: os.cpus()[0].model, logicalCpus: os.cpus().length, threadsRequested: threads,
  note: 'Cumulative training time of the baseline variant, first seed, on the 5.2 development machine (' + os.cpus().length + ' logical CPUs, ' + os.cpus()[0].model.trim() + ') with no other load, ' + threads + ' worker thread(s) requested. The default trainer commits one deal per update and uses one worker whatever is requested.', studies }, null, 1));
