# EightMax 5.7.1 validation on a Windows PC. Windows PowerShell 5.1 or PowerShell 7; nothing to install.
# Run from the release folder:  "Run 5.7.1 Windows validation.bat"   (every section, 10 to 40 minutes)
#                          or:  "Run 5.7.1 focused validation.bat"   (-Focused: the two repairs of 5.7.1, a few minutes)
#   (or: powershell -NoProfile -ExecutionPolicy Bypass -File source\tools\validate_windows571.ps1 [-Focused])
#
# WHAT 5.7.1 CHANGED IN THIS SCRIPT. validate_windows57.ps1 ran to its end on a physical Windows 11 PC (81 passed,
# 1 failed). Two of its checks did not test what they said:
#   * "recovery / damaged manifest refused" changed only white space in manifest.json and expected a refusal. The
#     manifest's checksum covers the canonical form of its data, not its formatting, so the engine was right to
#     resume and the check was wrong to fail.
#   * "memory / a too-small process budget stops the study" accepted a study that completed normally: the 24 MiB
#     budget was never reached (peak 8.4 MiB), and the check passed.
# Both are replaced by the checks of "mwcli.exe --selftest571" (section 9 below), which damage what the integrity
# data really covers, produce a real memory stop, and cannot pass because a process merely exited with status 0.
# Sections 1 to 8 and 10 to 13 are the 5.7 script, unchanged except for the release number, the evidence kept
# with a failed check, and the peak-memory reading (no longer reported as 0 for a process too short to be sampled).
#
# STATUS OF THIS SCRIPT: the parts taken over from 5.7 ran on Windows PowerShell 5.1. The parts written for 5.7.1
# (the -Focused switch, section 9, the evidence fields) were written on Linux, where PowerShell could not be run:
# their first run on Windows is also a test of them. The checks of "mwcli.exe --selftest571" themselves need no
# PowerShell and were run on Linux and, as the Windows program, under Wine; the launchers run them first and keep
# their report (Windows-selftest571-5.7.1.json) whatever happens to this script.
#
# Reports (next to the executables, or in -OutDir):
#   full run      Windows-validation-5.7.1.json          Windows-validation-5.7.1.txt
#   -Focused      Windows-focused-validation-5.7.1.json  Windows-focused-validation-5.7.1.txt
# Nothing is installed; nothing is written outside the release folder (the reports) and one temporary folder,
# which is removed at the end. Saved studies are never touched: every corruption check works on copies inside that
# temporary folder. No check cuts the power or kills anything but the processes this script started.
#
#   1  environment      Windows version, CPU, RAM, GPU, virtual-machine and Wine indicators
#   2  integrity        the three programs start and report this build; every file against SHA256SUMS.txt
#   3  self-test 5.7    mwcli --selftest57: worker pool, deal queue, card code, thread choice; frozen-batch states of
#                       the 5.6 binary for 1 to 8 threads; evaluation with and without the path tree
#   4  golden states    11 training runs must reproduce, byte for byte, the states the 5.5 Linux binary wrote
#   5  threads          frozen-batch training with 1, 2, 4, 8 and all logical processors, every update on all of them:
#                       identical state; the times and the measured thread choice are reported
#   6  evaluator        exact best response with a 32 MiB and a 1,024 MiB cache: identical values
#   7  study            a complete study of the known game: version, statistics fields, closed form
#   8  recovery         time-limit interruption and resume, a killed process and resume, a second process refused
#   9  self-test 5.7.1  mwcli --selftest571, recorded under three section names:
#                         checkpoint integrity   white space accepted; altered data, altered checksums, damaged and
#                                                missing files detected; the previous generation used only after it
#                                                verifies; refusal when nothing usable is left; the source untouched
#                         memory budget          a real memory stop, its checkpoint, the resume, the accounting,
#                                                invalid budgets, and a normal completion as a separate control
#                         verdict controls       the verdicts above applied to observations they must reject
#  10  configuration    CPU-only mode, GPU-Preferred falling back to the CPU, invalid specs and options refused
#  11  throughput       sampled deals per second on the study fixtures, one thread and all threads (this PC's numbers)
#  12  desktop host     EightMax.exe starts without a browser, reports version and build, serves the Study tab
#  13  GPU              validate_hardware.ps1 and the processing modes (skipped with the reason when no NVIDIA GPU answers)
# -Focused runs sections 1, 2 and 9 only.
#
# Every check has a status and a class.
#   status  passed | failed | skipped (not run on purpose: an option, or hardware that is not there; the reason is
#           given) | untested (planned, but not reached or not possible: a step it depends on failed, or the
#           condition it needs could not be produced; the reason is given) | info (a measurement)
#   class   gate (deterministic: must pass on every Windows PC) | environment (depends on this PC's configuration) |
#           hardware (needs an NVIDIA GPU) | information
# A failed or untested check carries "evidence": the exit status, standard output and standard error of the
# processes it ran, and for the 5.7.1 checks the corruption method, checksums before and after, the manifest
# generation used, and whether the result file was written.
# Exit status: 0 when no gate check failed and none is untested; 1 otherwise; 2 when the script itself failed.
# -Quick skips 11 and shortens 8; -SkipGpu skips 13; -SkipIntegrity skips the checksum pass over every file.
param([switch]$Quick, [switch]$SkipGpu, [switch]$SkipIntegrity, [switch]$Focused, [string]$Root = '', [string]$OutDir = '')
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1: extended type data on System.Array (added by some modules) makes ConvertTo-Json write
# arrays as objects with "value" and "Count"; removing it restores plain JSON arrays.
Remove-TypeData System.Array -ErrorAction SilentlyContinue
$Release = '5.7.1'
if (-not $Root) { $Root = Join-Path $PSScriptRoot '..\..' }
$Root = (Resolve-Path -LiteralPath $Root).Path
if (-not $OutDir) { $OutDir = $Root }
$mwcli = Join-Path $Root 'mwcli.exe'; $hostExe = Join-Path $Root 'EightMax.exe'; $stress = Join-Path $Root 'gpustress.exe'
$work = Join-Path ([System.IO.Path]::GetTempPath()) ('EightMax-' + $Release + '-validation-' + [guid]::NewGuid().ToString('N'))
$records = New-Object System.Collections.Generic.List[object]
$sections = New-Object System.Collections.Generic.List[object]
$children = New-Object System.Collections.Generic.List[object]
$started = Get-Date
$logical = [Environment]::ProcessorCount
$mode = 'full'; if ($Focused) { $mode = 'focused' }
$report = [ordered]@{ tool = 'validate_windows571.ps1'; release = $Release; mode = $mode; started = $started.ToString('o'); root = $Root; quick = [bool]$Quick; scriptCompleted = $false }
$reportName = 'Windows-validation-'; if ($Focused) { $reportName = 'Windows-focused-validation-' }
$jsonPath = Join-Path $OutDir ($reportName + $Release + '.json'); $txtPath = Join-Path $OutDir ($reportName + $Release + '.txt')
# A report of an earlier run must not be mistaken for this run's: both files are removed before anything is checked.
foreach ($old in @($jsonPath, $txtPath)) { if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Force -ErrorAction SilentlyContinue } }
# -Focused: only these sections are planned and run.
$focusSections = @('environment', 'integrity', 'self-test 5.7.1')

# ---- the plan: every check this script intends to make. A planned check that is never recorded is reported as
# ---- 'untested' at the end, so a section that stops early cannot make the report look complete.
$plan = New-Object System.Collections.Generic.List[object]
# $group is the section of Run-Section a check belongs to when its own section label differs (the 5.7.1 self-test).
function Plan([string]$section, [string]$name, [string]$class, [string]$group = '') {
  if (-not $group) { $group = $section }
  if ($Focused -and ($focusSections -notcontains $group)) { return }
  $plan.Add([pscustomobject]@{ section = $section; name = $name; class = $class })
}
Plan 'environment' 'machine' 'information'
Plan 'environment' '64-bit Windows' 'gate'
Plan 'environment' 'physical hardware' 'information'
Plan 'integrity' 'mwcli.exe present' 'gate'
Plan 'integrity' 'EightMax.exe present' 'gate'
Plan 'integrity' 'gpustress.exe present' 'gate'
Plan 'integrity' 'BUILD-INFO.json version' 'gate'
Plan 'integrity' 'mwcli.exe build id' 'gate'
Plan 'integrity' 'EightMax.exe build id' 'gate'
Plan 'integrity' 'gpustress.exe starts' 'gate'
Plan 'integrity' 'SHA256SUMS.txt' 'gate'
Plan 'self-test 5.7' 'mwcli --selftest57 ran and wrote its report' 'gate'
Plan 'golden states' 'every golden state reproduced' 'gate'
Plan 'threads' 'identical state for every thread count' 'gate'
Plan 'threads' 'state equals the 5.6 binary' 'gate'
Plan 'threads' 'thread scaling on this PC' 'information'
Plan 'evaluator' 'exact NashConv with 32 and 1,024 MiB caches' 'gate'
Plan 'study' 'study of the known game completes' 'gate'
Plan 'study' 'version and build in the result' 'gate'
Plan 'study' 'replication statistics present' 'gate'
Plan 'study' 'closed form of the known game' 'gate'
Plan 'recovery' 'uninterrupted reference' 'gate'
Plan 'recovery' 'time-limit interruption and resume' 'gate'
Plan 'recovery' 'second process refused while the first runs' 'gate'
Plan 'recovery' 'killed process, then resume' 'gate'
Plan 'self-test 5.7.1' 'mwcli --selftest571 ran and wrote its report' 'gate'
Plan 'self-test 5.7.1' 'every expected 5.7.1 check is in the report' 'gate'
Plan 'self-test 5.7.1' 'the report agrees with the exit status of mwcli' 'gate'
Plan 'configuration' 'CPU-only study completes on the CPU' 'gate'
Plan 'configuration' 'GPU-Preferred gives the CPU measurements' 'gate'
Plan 'configuration' 'invalid training spec refused, nothing written' 'gate'
Plan 'configuration' 'unreadable spec refused' 'gate'
Plan 'configuration' 'unknown study option refused' 'gate'
Plan 'configuration' 'invalid study option value refused' 'gate'
Plan 'throughput' 'training throughput' 'information'
Plan 'desktop host' 'starts without a browser and answers /api/info' 'gate'
Plan 'desktop host' '/api/info version and build' 'gate'
Plan 'desktop host' 'interface served with the Study tab and this build' 'gate'
Plan 'desktop host' 'saved-study list answers' 'gate'
Plan 'desktop host' 'host process ends when stopped' 'environment'
Plan 'GPU' 'CUDA validation' 'hardware'

function Text($detail) { if ($null -eq $detail) { return '' } if ($detail -is [string]) { return $detail } try { return ($detail | ConvertTo-Json -Compress -Depth 6) } catch { return [string]$detail } }
# Evidence of one finished process: what a failed check needs to be understood without running it again.
function Clip([string]$t, [int]$max = 4000) { if ($null -eq $t) { return '' }; if ($t.Length -le $max) { return $t }; return ($t.Substring(0, [int]($max / 2)) + "`n...[" + ($t.Length - $max) + " characters omitted]...`n" + $t.Substring($t.Length - [int]($max / 2))) }
function Run-Evidence($r, [string]$what = '') {
  if ($null -eq $r) { return $null }
  return [ordered]@{ process = $what; exitCode = $r.exit; timedOut = [bool]$r.timedOut; seconds = $r.seconds; standardOutput = (Clip ([string]$r.out)); standardError = (Clip ([string]$r.err)) }
}
function Add-Check([string]$section, [string]$name, [string]$status, $detail, [string]$class = '', $evidence = $null) {
  if (-not $class) { $p = $plan | Where-Object { $_.section -eq $section -and $_.name -eq $name } | Select-Object -First 1; if ($p) { $class = $p.class } else { $class = 'gate' } }
  # evidence is kept for every check that carries it; a passed check without evidence has null
  $records.Add([pscustomobject]@{ section = $section; name = $name; status = $status; class = $class; detail = $detail; evidence = $evidence })
  $mark = 'PASS'
  if ($status -eq 'failed') { $mark = 'FAIL' } elseif ($status -eq 'skipped') { $mark = 'SKIP' } elseif ($status -eq 'info') { $mark = 'INFO' } elseif ($status -eq 'untested') { $mark = 'UNTESTED' }
  Write-Host ('  [{0}] {1}: {2}' -f $mark, $name, (Text $detail))
}
function Check([string]$section, [string]$name, [bool]$ok, $detail, [string]$class = '', $evidence = $null) { $s = 'failed'; if ($ok) { $s = 'passed' }; Add-Check $section $name $s $detail $class $evidence }
function Run-Section([string]$name, [scriptblock]$body) {
  if ($Focused -and ($focusSections -notcontains $name)) { return }
  Write-Host ''; Write-Host ('== ' + $name)
  $t = Get-Date; $err = $null
  try { & $body } catch { $err = $_.Exception.Message + ' (line ' + $_.InvocationInfo.ScriptLineNumber + ')'; Write-Host ('  [ERROR] section stopped: ' + $err) }
  $sections.Add([pscustomobject]@{ section = $name; seconds = [math]::Round(((Get-Date) - $t).TotalSeconds, 2); error = $err })
  Save-Report
}
function Sha256([string]$path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
# One argument for a Windows command line (CommandLineToArgvW rules: backslashes are literal unless they precede a quote).
function Quote-Arg([string]$a) {
  if ($a -ne '' -and $a -notmatch '[\s"]') { return $a }
  $backslash = [char]92; $quote = [char]34
  $sb = New-Object System.Text.StringBuilder; [void]$sb.Append($quote); $bs = 0
  foreach ($c in $a.ToCharArray()) {
    if ($c -eq $backslash) { $bs++; continue }
    if ($c -eq $quote) { [void]$sb.Append($backslash, ($bs * 2 + 1)); [void]$sb.Append($quote); $bs = 0; continue }
    if ($bs -gt 0) { [void]$sb.Append($backslash, $bs); $bs = 0 }
    [void]$sb.Append($c)
  }
  if ($bs -gt 0) { [void]$sb.Append($backslash, ($bs * 2)) }
  [void]$sb.Append($quote); return $sb.ToString()
}
function Join-Args([string[]]$arguments) { (@($arguments) | ForEach-Object { Quote-Arg $_ }) -join ' ' }
# Runs a program to completion. Returns exit code, stdout, stderr, seconds, peak working set and whether it timed out.
function Invoke-Exe([string]$exe, [string[]]$arguments, [hashtable]$environment = @{}, [int]$timeoutSeconds = 3600) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $exe; $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true; $psi.WorkingDirectory = $work
  $psi.Arguments = Join-Args $arguments
  foreach ($k in $environment.Keys) { $psi.EnvironmentVariables[$k] = [string]$environment[$k] }
  $p = New-Object System.Diagnostics.Process; $p.StartInfo = $psi
  $t = Get-Date
  try { [void]$p.Start() } catch { return [pscustomobject]@{ exit = -998; out = ''; err = ('could not start: ' + $_.Exception.Message); seconds = 0; timedOut = $false; peakMiB = 0 } }
  $outTask = $p.StandardOutput.ReadToEndAsync(); $errTask = $p.StandardError.ReadToEndAsync()
  # Wait in short steps so that the peak working set can be read while the process is alive (it is not available afterwards).
  $peakBytes = 0; $finished = $false; $deadline = (Get-Date).AddSeconds($timeoutSeconds)
  while (-not $finished) {
    $finished = $p.WaitForExit(100)
    if (-not $finished) { try { $p.Refresh(); if ($p.PeakWorkingSet64 -gt $peakBytes) { $peakBytes = $p.PeakWorkingSet64 } } catch {}; if ((Get-Date) -gt $deadline) { break } }
  }
  if (-not $finished) { try { $p.Kill() } catch {}; [void]$p.WaitForExit(15000) } else { $p.WaitForExit() }
  $o = ''; $e = ''
  try { if ($outTask.Wait(15000)) { $o = $outTask.Result } } catch {}
  try { if ($errTask.Wait(15000)) { $e = $errTask.Result } } catch {}
  $code = -999; if ($finished) { $code = $p.ExitCode }
  # 5.7.1: a process that ended before the first 100 ms reading has no sampled peak; 5.7 reported that as 0 MiB.
  $peak = $null; if ($peakBytes -gt 0) { $peak = [math]::Round($peakBytes / 1MB, 1) }
  [pscustomobject]@{ exit = $code; out = $o; err = $e; seconds = [math]::Round(((Get-Date) - $t).TotalSeconds, 3); timedOut = (-not $finished); peakMiB = $peak }
}
# Starts a program that keeps running; it is stopped by Stop-Child or, at the latest, when the script ends.
function Start-Child([string]$exe, [string[]]$arguments) {
  $p = Start-Process -FilePath $exe -ArgumentList (Join-Args $arguments) -WorkingDirectory $work -PassThru -WindowStyle Hidden
  $children.Add($p); return $p
}
function Stop-Child($p) { if ($p) { try { if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; [void]$p.WaitForExit(15000) } } catch {} } }
function Read-Json([string]$path) { if (-not (Test-Path -LiteralPath $path)) { return $null }; try { return (Get-Content -LiteralPath $path -Raw | ConvertFrom-Json) } catch { return $null } }
function Parse-Json([string]$text) { if (-not $text) { return $null }; try { return ($text | ConvertFrom-Json) } catch { return $null } }
function Write-Text([string]$path, [string]$text) { [System.IO.File]::WriteAllText($path, $text, (New-Object System.Text.UTF8Encoding($false))) }
# A number as text that distinguishes every value (Windows PowerShell prints a double with 15 digits by default).
function Num($x) {
  if ($null -eq $x) { return 'null' }
  if ($x -is [double]) { return $x.ToString('R', [System.Globalization.CultureInfo]::InvariantCulture) }
  if ($x -is [single]) { return ([double]$x).ToString('R', [System.Globalization.CultureInfo]::InvariantCulture) }
  if ($x -is [System.IFormattable]) { return $x.ToString($null, [System.Globalization.CultureInfo]::InvariantCulture) }
  return [string]$x
}
# The measurements of a study, one line per (variant, seed, budget).
function Study-Points($doc) {
  if (-not $doc) { return '' }
  $rows = @()
  foreach ($v in @($doc.variants)) { foreach ($s in @($v.perSeed)) { foreach ($p in @($s.budgets)) {
    $rows += ('' + $v.name + '|' + $s.seed + '|' + $p.budgetDeals + '|' + $p.deals + '|' + ((@($p.ev) | ForEach-Object { Num $_ }) -join ',') + '|' + ((@($p.frequency) | ForEach-Object { Num $_ }) -join ',') + '|' + (Num $p.quality))
  } } }
  return ($rows -join "`n")
}
function Study-Complete($doc) { return [bool]($doc -and $doc.completion -and $doc.completion.complete) }
function Http-Get([string]$url, [int]$timeoutMs = 5000) {
  # A direct request to this PC (no system proxy), usable in Windows PowerShell 5.1 and PowerShell 7.
  $req = [System.Net.HttpWebRequest]::Create($url); $req.Proxy = $null; $req.Timeout = $timeoutMs; $req.ReadWriteTimeout = $timeoutMs; $req.Method = 'GET'
  $resp = $req.GetResponse()
  try { $reader = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8); $body = $reader.ReadToEnd(); $reader.Close(); return [pscustomobject]@{ status = [int]$resp.StatusCode; body = $body } } finally { $resp.Close() }
}
# The evidence of a check as indented text lines (hash tables written by this script, objects read from JSON).
function Evidence-Lines($e) {
  $out = New-Object System.Collections.Generic.List[string]
  if ($null -eq $e) { return $out }
  if ($e -is [System.Collections.IDictionary]) { foreach ($k in @($e.Keys)) { $out.Add('      ' + $k + ': ' + (Text $e[$k])) } }
  elseif ($e -is [string]) { $out.Add('      ' + $e) }
  else { foreach ($p in @($e.PSObject.Properties)) { $out.Add('      ' + $p.Name + ': ' + (Text $p.Value)) } }
  return $out
}
function Save-Report {
  $failed = @($records | Where-Object { $_.status -eq 'failed' }); $skipped = @($records | Where-Object { $_.status -eq 'skipped' }); $untested = @($records | Where-Object { $_.status -eq 'untested' })
  $passed = @($records | Where-Object { $_.status -eq 'passed' })
  $gateFailed = @($failed | Where-Object { $_.class -eq 'gate' }); $gateUntested = @($untested | Where-Object { $_.class -eq 'gate' })
  $report.finished = (Get-Date).ToString('o'); $report.seconds = [math]::Round(((Get-Date) - $started).TotalSeconds, 1)
  $report.summary = [ordered]@{ passed = $passed.Count; failed = $failed.Count; skipped = $skipped.Count; untested = $untested.Count; gateFailed = $gateFailed.Count; gateUntested = $gateUntested.Count
    environmentFailed = @($failed | Where-Object { $_.class -eq 'environment' }).Count; hardwareFailed = @($failed | Where-Object { $_.class -eq 'hardware' }).Count
    allGatesPassed = ($gateFailed.Count -eq 0 -and $gateUntested.Count -eq 0 -and [bool]$report.scriptCompleted) }
  $report.sections = $sections; $report.checks = $records
  try {
    Write-Text $jsonPath ($report | ConvertTo-Json -Depth 12)
    $title = 'EightMax ' + $Release + ' Windows validation'; if ($Focused) { $title = 'EightMax ' + $Release + ' focused Windows validation (checkpoint integrity and the process memory budget only)' }
    $lines = @($title, ('Started ' + $report.started + ', ' + $report.seconds + ' s'), ('Script ran to its end: ' + $report.scriptCompleted),
      ('Physical Windows (no Wine or virtual-machine indicator): ' + $report.physicalWindows),
      ('Passed ' + $passed.Count + ', failed ' + $failed.Count + ' (gate ' + $gateFailed.Count + '), skipped ' + $skipped.Count + ', untested ' + $untested.Count), '')
    foreach ($c in $records) {
      $lines += ('[' + $c.status.ToUpper() + '] (' + $c.class + ') ' + $c.section + ' / ' + $c.name + ': ' + (Text $c.detail))
      if (($c.status -eq 'failed' -or $c.status -eq 'untested') -and $null -ne $c.evidence) { foreach ($l in (Evidence-Lines $c.evidence)) { $lines += $l } }
    }
    Write-Text $txtPath ($lines -join "`r`n")
  } catch { Write-Host ('  could not write the report: ' + $_.Exception.Message) }
}

$exitCode = 2
try {
New-Item -ItemType Directory -Path $work | Out-Null

Run-Section 'environment' {
  $os = $null; $cs = $null; $cpu = $null; $gpus = @()
  try { $os = Get-CimInstance Win32_OperatingSystem; $cs = Get-CimInstance Win32_ComputerSystem; $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1 } catch {}
  # Win32_VideoController.AdapterRAM is a 32-bit field: a card with more than 4 GiB is reported as 4,095 MiB.
  try { $gpus = @(Get-CimInstance Win32_VideoController | ForEach-Object { [pscustomobject]@{ name = $_.Name; driver = $_.DriverVersion; adapterRamMiBAtMost4GiBField = [math]::Round([double]$_.AdapterRAM / 1MB) } }) } catch {}
  $smi = $null
  try { $cmd = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue; if ($cmd) { $r = Invoke-Exe $cmd.Source @('--query-gpu=name,memory.total,driver_version', '--format=csv,noheader') @{} 30; if ($r.exit -eq 0) { $smi = $r.out.Trim() } } } catch {}
  $wine = $false; try { $wine = [bool](Get-ItemProperty -Path 'HKLM:\Software\Wine' -ErrorAction SilentlyContinue) } catch {}
  $vm = $false; if ($cs) { $vm = ($cs.Model -match 'Virtual|VMware|KVM|HVM|VirtualBox') -or ($cs.Manufacturer -match 'QEMU|Xen|innotek|Parallels') }
  $arch = ''; if ($os) { $arch = [string]$os.OSArchitecture }
  $cpuName = ''; $cores = $null; if ($cpu) { $cpuName = ([string]$cpu.Name).Trim(); $cores = $cpu.NumberOfCores }
  $ram = $null; if ($cs) { $ram = [math]::Round([double]$cs.TotalPhysicalMemory / 1GB, 1) }
  $caption = [System.Environment]::OSVersion.VersionString; $osVersion = [System.Environment]::OSVersion.Version.ToString(); $osBuild = ''
  if ($os) { $caption = $os.Caption; $osVersion = $os.Version; $osBuild = $os.BuildNumber }
  $manufacturer = ''; $model = ''; if ($cs) { $manufacturer = $cs.Manufacturer; $model = $cs.Model }
  $envInfo = [ordered]@{ windows = $caption; windowsVersion = $osVersion; build = $osBuild; architecture = $arch; is64BitProcess = [Environment]::Is64BitProcess; is64BitOperatingSystem = [Environment]::Is64BitOperatingSystem
    cpu = $cpuName; physicalCores = $cores; logicalProcessors = $logical; ramGiB = $ram; gpus = $gpus; nvidiaSmi = $smi; manufacturer = $manufacturer; model = $model
    wineDetected = $wine; virtualMachineIndicators = [bool]$vm; hardwareQueriesAnswered = [bool]($os -and $cs -and $cpu); powershell = $PSVersionTable.PSVersion.ToString() }
  $report.environment = $envInfo
  Add-Check 'environment' 'machine' 'info' ('{0}; {1}; {2} logical processors; {3} GiB RAM; GPU: {4}' -f $caption, $cpuName, $logical, $ram, ((@($gpus) | ForEach-Object { $_.name }) -join ', '))
  Check 'environment' '64-bit Windows' ([Environment]::Is64BitOperatingSystem) ('64-bit operating system: ' + [Environment]::Is64BitOperatingSystem + ' ' + $arch)
  $report.physicalWindows = ((-not $wine) -and (-not $vm) -and [bool]($os -and $cs))
  if ($report.physicalWindows) { Add-Check 'environment' 'physical hardware' 'info' 'no Wine or virtual-machine indicator' }
  else { Add-Check 'environment' 'physical hardware' 'info' 'Wine or a virtual machine was detected, or the hardware queries did not answer: this report does NOT count as physical Windows validation' }
}

Run-Section 'integrity' {
  foreach ($f in @($mwcli, $hostExe, $stress)) { Check 'integrity' ((Split-Path $f -Leaf) + ' present') (Test-Path -LiteralPath $f) $f }
  $info = Read-Json (Join-Path $Root 'BUILD-INFO.json')
  if (-not $info) { Add-Check 'integrity' 'BUILD-INFO.json version' 'failed' 'BUILD-INFO.json is missing or unreadable'; return }
  $report.build = $info.build; $report.version = $info.version
  Check 'integrity' 'BUILD-INFO.json version' ($info.version -eq $Release) ([string]$info.version)
  $a = Invoke-Exe $mwcli @('--build-id') @{} 60; $b = Invoke-Exe $hostExe @('--build-id') @{} 60
  Check 'integrity' 'mwcli.exe build id' ($a.exit -eq 0 -and $a.out.Trim() -eq ('EightMaxBuild=' + $info.build)) ('exit ' + $a.exit + ': ' + $a.out.Trim() + $a.err.Trim())
  Check 'integrity' 'EightMax.exe build id' ($b.exit -eq 0 -and $b.out.Trim() -eq ('EightMaxBuild=' + $info.build)) ('exit ' + $b.exit + ': ' + $b.out.Trim() + $b.err.Trim())
  $g = Invoke-Exe $stress @() @{} 60
  Check 'integrity' 'gpustress.exe starts' ((-not $g.timedOut) -and (($g.out + $g.err) -match 'usage: gpustress')) ('exit ' + $g.exit + ' (it prints its usage and exits when given no arguments)')
  $sums = Join-Path $Root 'SHA256SUMS.txt'
  if ($SkipIntegrity) { Add-Check 'integrity' 'SHA256SUMS.txt' 'skipped' '-SkipIntegrity was given' }
  elseif (-not (Test-Path -LiteralPath $sums)) { Add-Check 'integrity' 'SHA256SUMS.txt' 'failed' 'file missing' }
  else {
    $bad = New-Object System.Collections.Generic.List[string]; $count = 0
    foreach ($line in [System.IO.File]::ReadAllLines($sums)) {
      if ($line.Length -lt 67) { continue }
      $hash = $line.Substring(0, 64); $rel = $line.Substring(66); $count++
      # the two reports of this script are written into the release folder after the manifest was made
      $p = Join-Path $Root $rel
      if (-not (Test-Path -LiteralPath $p)) { $bad.Add('missing: ' + $rel) } elseif ((Sha256 $p) -ne $hash) { $bad.Add('changed: ' + $rel) }
    }
    $shown = @($bad | Select-Object -First 10); $detail = 'every file matches (' + $count + ' files)'
    if ($bad.Count) { $detail = ('' + $bad.Count + ' of ' + $count + ' files: ' + ($shown -join '; ')) }
    Check 'integrity' 'SHA256SUMS.txt' ($bad.Count -eq 0 -and $count -gt 3000) $detail
  }
}

Run-Section 'self-test 5.7' {
  $dir = Join-Path $work 'st57'; $fixtures = Join-Path $Root 'validation\5.7\fixtures'
  $r = Invoke-Exe $mwcli @('--selftest57', $fixtures, $dir) @{} 3600
  $doc = Read-Json (Join-Path $dir 'selftest57.json')
  Check 'self-test 5.7' 'mwcli --selftest57 ran and wrote its report' ($null -ne $doc -and -not $r.timedOut) ('exit ' + $r.exit + ', ' + $r.seconds + ' s' + $(if (-not $doc) { '; no report: ' + $r.err.Trim() } else { '; passed ' + $doc.passed + ', failed ' + $doc.failed }))
  if ($doc) {
    foreach ($c in @($doc.checks)) { Check 'self-test 5.7' ('selftest57: ' + $c.name) ([bool]$c.passed) $c.detail 'gate' }
    $report.selftest57 = [ordered]@{ passed = $doc.passed; failed = $doc.failed; seconds = $doc.seconds }
  }
}

Run-Section 'golden states' {
  $dir = Join-Path $Root 'validation\5.7\windows\golden'; $g = Read-Json (Join-Path $dir 'golden.json'); $rows = @(); $bad = 0
  if (-not $g) { Add-Check 'golden states' 'every golden state reproduced' 'failed' ('golden.json is missing or unreadable in ' + $dir); return }
  foreach ($c in @($g.cases)) {
    $state = Join-Path $work ($c.name + '.state')
    $r = Invoke-Exe $mwcli @((Join-Path $dir $c.spec), [string]$c.updates, [string]$c.threads, $state, [string]$c.memoryMiB) @{} 1800
    $hash = ''; if ($r.exit -eq 0 -and (Test-Path -LiteralPath $state)) { $hash = Sha256 $state }
    $same = ($hash -eq $c.stateSha256); if (-not $same) { $bad++ }
    $rows += [pscustomobject]@{ name = $c.name; exit = $r.exit; seconds = $r.seconds; identical = $same; sha256 = $hash; expected = $c.stateSha256; error = $r.err.Trim() }
    Check 'golden states' ('golden state ' + $c.name) $same $(if ($same) { 'identical to the 5.5 trainer (' + $r.seconds + ' s)' } else { 'exit ' + $r.exit + ', sha256 ' + $hash + ', expected ' + $c.stateSha256 + ' ' + $r.err.Trim() }) 'gate'
  }
  $report.goldenStates = $rows
  Check 'golden states' 'every golden state reproduced' ($bad -eq 0 -and $rows.Count -ge 11) ('' + ($rows.Count - $bad) + ' of ' + $rows.Count)
}

Run-Section 'threads' {
  # A frozen-batch study (64 deals per update, per-deal action streams): the only mode in which one training uses
  # several threads. EIGHTMAX_THREAD_CHOICE=fixed puts every update on all the threads of the run, so each thread
  # count is really exercised; the last run uses the measured choice and reports what it chose.
  $fixtures = Join-Path $Root 'validation\5.7\fixtures'; $golden = Read-Json (Join-Path $fixtures 'golden57.json')
  $case = $null; if ($golden) { $case = @($golden.training) | Where-Object { $_.name -eq 'flop3-kings-compact-batch64' } | Select-Object -First 1 }
  if (-not $case) { Add-Check 'threads' 'identical state for every thread count' 'failed' 'golden57.json or its flop3-kings-compact-batch64 entry is missing'; return }
  $spec = Join-Path $fixtures $case.spec
  $counts = @(@(1, 2, 4, 8, $logical) | Where-Object { $_ -le $logical } | Sort-Object -Unique); $hashes = @(); $rows = @()
  foreach ($n in $counts) {
    $state = Join-Path $work ('threads-' + $n + '.state'); $r = Invoke-Exe $mwcli @($spec, [string]$case.updates, [string]$n, $state, [string]$case.memoryMiB) @{ EIGHTMAX_THREAD_CHOICE = 'fixed' } 1800
    $h = ''; if ($r.exit -eq 0 -and (Test-Path -LiteralPath $state)) { $h = Sha256 $state }; $hashes += $h
    $i = Parse-Json $r.out; $wall = $null; $used = $null; if ($i) { $wall = $i.wallSeconds; $used = $i.threads }
    $rows += [pscustomobject]@{ threads = $n; mode = 'every update on all threads'; exit = $r.exit; wallSeconds = $wall; threadsUsed = $used; sha256 = $h }
  }
  $state = Join-Path $work 'threads-auto.state'; $r = Invoke-Exe $mwcli @($spec, [string]$case.updates, [string]$logical, $state, [string]$case.memoryMiB) @{} 1800
  $h = ''; if ($r.exit -eq 0 -and (Test-Path -LiteralPath $state)) { $h = Sha256 $state }; $hashes += $h
  $i = Parse-Json $r.out; $wall = $null; $chosen = $null; if ($i) { $wall = $i.wallSeconds; if ($i.threadChoice) { $chosen = $i.threadChoice.selected } }
  $rows += [pscustomobject]@{ threads = $logical; mode = 'measured thread choice'; exit = $r.exit; wallSeconds = $wall; threadsChosen = $chosen; sha256 = $h }
  $distinct = @($hashes | Sort-Object -Unique)
  Check 'threads' 'identical state for every thread count' ($distinct.Count -eq 1 -and $distinct[0] -ne '') (($counts -join ', ') + ' threads and the measured choice: ' + $distinct.Count + ' distinct state(s)')
  Check 'threads' 'state equals the 5.6 binary' ($distinct.Count -eq 1 -and $distinct[0] -eq $case.stateSha256) ('' + $distinct[0] + ' (expected ' + $case.stateSha256 + ')')
  Add-Check 'threads' 'thread scaling on this PC' 'info' (($rows | ForEach-Object { '' + $_.threads + ' threads (' + $_.mode + '): ' + $_.wallSeconds + ' s' }) -join '; ')
  $report.threadScaling = $rows
}

Run-Section 'evaluator' {
  $dir = Join-Path $Root 'validation\5.7\windows\golden'; $rows = @(); $ok = $true; $done = 0
  foreach ($name in @('g04-bubble4', 'g05-flop6', 'g06-final8')) {
    $spec = Join-Path $dir ($name + '.spec.json'); $state = Join-Path $work ($name + '.state')
    if (-not (Test-Path -LiteralPath $state)) { Add-Check 'evaluator' ($name + ': exact NashConv') 'untested' 'its golden state was not produced' 'gate'; $ok = $false; continue }
    $values = @{}
    foreach ($mem in @(32, 1024)) {
      $q = Join-Path $work ('q' + $mem + '.json'); Write-Text $q ('{"method":"exact","device":"cpu","threads":1,"timeLimitMs":900000,"maxVisits":2000000000,"memoryMiB":' + $mem + '}')
      $r = Invoke-Exe $mwcli @('--gain', $spec, $state, $q, '128') @{} 1800; $d = Parse-Json $r.out; $nc = $null; if ($d) { $nc = $d.nashConv }
      $values[$mem] = Num $nc; $rows += [pscustomobject]@{ game = $name; cacheMiB = $mem; exit = $r.exit; seconds = $r.seconds; peakMiB = $r.peakMiB; nashConv = $nc }
    }
    $same = ($values[32] -ne 'null' -and $values[32] -eq $values[1024]); if (-not $same) { $ok = $false }; $done++
    Check 'evaluator' ($name + ': exact NashConv') $same ('' + $values[32] + ' / ' + $values[1024]) 'gate'
  }
  $report.evaluator = $rows
  Check 'evaluator' 'exact NashConv with 32 and 1,024 MiB caches' ($ok -and $done -eq 3) ('' + $done + ' of 3 games evaluated with both caches')
}

Run-Section 'study' {
  $fixture = Join-Path $Root 'studies\known-akq-river.emfix.json'; $out = Join-Path $work 'known.json'
  $r = Invoke-Exe $mwcli @('--study', $fixture, $out, 'quiet=1', 'seeds=3', 'budgets=1000,100000,1000000', 'processingMode=cpu', 'checkpoint=off') @{} 1800
  $d = Read-Json $out
  Check 'study' 'study of the known game completes' ($r.exit -eq 0 -and (Study-Complete $d)) ('exit ' + $r.exit + ', ' + $r.seconds + ' s ' + $r.err.Trim())
  if (-not $d) { return }
  $v = @($d.variants)[0]; $b = @($v.budgets)[@($v.budgets).Count - 1]
  Check 'study' 'version and build in the result' ($d.version -eq $Release -and $d.build -eq $report.build) ('' + $d.version + ' ' + $d.build)
  Check 'study' 'replication statistics present' ($d.replicationCalculation -eq 'study-5.6-replication-v1' -and $null -ne $b.bestAction -and $null -ne $b.confidence.replication) ([string]$d.replicationCalculation)
  $call = @($b.actions) | Where-Object { $_.label -eq 'Call 10' } | Select-Object -First 1
  $freq = $null; $gap = $null; if ($call) { $freq = [double]$call.frequency.mean }; if ($b.gap) { $gap = [double]$b.gap.mean }
  Check 'study' 'closed form of the known game' (($null -ne $freq) -and ($null -ne $gap) -and ([math]::Abs($freq - 0.5) -lt 0.03) -and ([math]::Abs($gap) -lt 0.05)) ('call frequency ' + (Num $freq) + ' (closed form 1/2), EV gap ' + (Num $gap) + ' BB (closed form 0)')
  $report.knownGameStudy = [ordered]@{ seconds = $r.seconds; peakMiB = $r.peakMiB; callFrequency = $freq; evGapBB = $gap; verdict = $b.verdict }
}

Run-Section 'recovery' {
  $fixture = Join-Path $Root 'studies\known-akq-river.emfix.json'; $budgets = 'budgets=20000,400000,6000000'; if ($Quick) { $budgets = 'budgets=20000,400000,1500000' }
  $opts = @('seeds=2', $budgets, 'threads=2', 'quiet=1', 'processingMode=cpu')
  $ref = Join-Path $work 'ref.json'; $r = Invoke-Exe $mwcli (@('--study', $fixture, $ref) + $opts + @('checkpoint=off')) @{} 3600
  $refDoc = Read-Json $ref
  Check 'recovery' 'uninterrupted reference' ($r.exit -eq 0 -and (Study-Complete $refDoc)) ('exit ' + $r.exit + ', ' + $r.seconds + ' s ' + $r.err.Trim()) '' (Run-Evidence $r 'the uninterrupted study')
  if (-not (Study-Complete $refDoc)) { return }
  $want = Study-Points $refDoc
  # (a) time limit, then resume until complete. Every resume must add to the work that is saved, so the loop is
  # bounded by the reference run's own duration instead of by a fixed number of rounds (a slow or busy PC needs
  # more rounds, not a different result).
  $ck = Join-Path $work 'ck-time'; $out = Join-Path $work 'time.json'; $rounds = 0; $limitSeconds = 0.5
  $maxRounds = [int][math]::Max(60, [math]::Ceiling(8 * $r.seconds / $limitSeconds) + 40)
  $r1 = Invoke-Exe $mwcli (@('--study', $fixture, $out) + $opts + @(('checkpoint=' + $ck), ('timeLimitSeconds=' + $limitSeconds), 'checkpointSeconds=0.1')) @{} 600
  $doc = Read-Json $out; $firstComplete = Study-Complete $doc; $lastExit = $r1.exit; $lastRun = $r1
  while ($doc -and -not (Study-Complete $doc) -and $rounds -lt $maxRounds) {
    $rounds++; $rr = Invoke-Exe $mwcli (@('--study', $fixture, $out) + $opts + @(('checkpoint=' + $ck), 'resume=1', ('timeLimitSeconds=' + $limitSeconds), 'checkpointSeconds=0.1')) @{} 600
    $lastExit = $rr.exit; $lastRun = $rr; $doc = Read-Json $out
  }
  $equal = ((Study-Points $doc) -eq $want)
  # 5.7.1: a study that finished inside its first time limit was never interrupted, so nothing was resumed. 5.7
  # passed that case; it is now reported as untested with the reason (it cannot happen unless the PC is far faster
  # than the one this was written for: the limit is 0.5 s and the reference study took over a second there).
  $timeDetail = ('first run complete: ' + $firstComplete + '; resumes: ' + $rounds + ' of at most ' + $maxRounds + '; complete: ' + (Study-Complete $doc) + '; equals the uninterrupted study: ' + $equal + '; last exit ' + $lastExit)
  if ($firstComplete) { Add-Check 'recovery' 'time-limit interruption and resume' 'untested' ('the study finished inside its ' + $limitSeconds + ' s time limit, so there was no interruption to resume from; ' + $timeDetail) '' (Run-Evidence $r1 'the first, time-limited run') }
  else { Check 'recovery' 'time-limit interruption and resume' ((Study-Complete $doc) -and $equal -and $rounds -ge 1) $timeDetail '' (Run-Evidence $lastRun 'the last resume') }
  # (b) a second process is refused while the first runs; the first is killed; resume completes the study
  $ck2 = Join-Path $work 'ck-kill'; $out2 = Join-Path $work 'kill.json'
  $p = Start-Child $mwcli (@('--study', $fixture, $out2) + $opts + @(('checkpoint=' + $ck2), 'checkpointSeconds=0.1'))
  $waited = 0; while (-not (Test-Path -LiteralPath (Join-Path $ck2 'manifest.json')) -and $waited -lt 400 -and -not $p.HasExited) { Start-Sleep -Milliseconds 50; $waited++ }
  if ($p.HasExited) { Add-Check 'recovery' 'second process refused while the first runs' 'skipped' 'the first study finished before the second could be started (a very fast PC); run without -Quick' }
  else {
    $second = Invoke-Exe $mwcli (@('--study', $fixture, (Join-Path $work 'second.json')) + $opts + @(('checkpoint=' + $ck2), 'resume=1')) @{} 600
    if ($p.HasExited) { Add-Check 'recovery' 'second process refused while the first runs' 'skipped' 'the first study finished during the attempt' }
    else { Check 'recovery' 'second process refused while the first runs' ($second.exit -ne 0 -and (($second.err + $second.out) -match 'in use')) ('exit ' + $second.exit + ': ' + $second.err.Trim()) '' (Run-Evidence $second 'the second process') }
  }
  $killed = (-not $p.HasExited); Stop-Child $p
  $r3 = Invoke-Exe $mwcli (@('--study', $fixture, $out2) + $opts + @(('checkpoint=' + $ck2), 'resume=1')) @{} 3600
  $done2 = Read-Json $out2
  # 5.7.1: the resume must really have followed a kill. If the first process had already finished there was nothing
  # to recover, and the check says so instead of passing.
  $killDetail = ('the first process was killed while running: ' + $killed + '; resume exit ' + $r3.exit + ' ' + $r3.err.Trim())
  if (-not $killed) { Add-Check 'recovery' 'killed process, then resume' 'untested' ('the first study had finished before it could be killed, so no interrupted checkpoint was resumed; ' + $killDetail) '' (Run-Evidence $r3 'the resume') }
  else { Check 'recovery' 'killed process, then resume' ($r3.exit -eq 0 -and (Study-Complete $done2) -and ((Study-Points $done2) -eq $want)) $killDetail '' (Run-Evidence $r3 'the resume after the kill') }
  # (c) 5.7 changed white space in manifest.json here and expected a refusal. That is not damage (the checksum covers
  # the manifest's data, not its formatting) and the check is gone; real damage is tested in section 9.
}

Run-Section 'self-test 5.7.1' {
  # Checkpoint integrity and the process memory budget, tested by mwcli itself: every study is a separate mwcli
  # process, every corruption is made on a copy inside this run's temporary folder, and each check says whether the
  # condition it is about was really produced. This section records what the report says, check by check, and adds
  # nothing of its own to the verdicts.
  $dir = Join-Path $work 'st571'; $studies = Join-Path $Root 'studies'
  $r = Invoke-Exe $mwcli @('--selftest571', $studies, $dir, 'all') @{} 3600
  $reportFile = Join-Path $dir 'selftest571.json'; $written = Test-Path -LiteralPath $reportFile
  $doc = Read-Json $reportFile
  $ran = ($null -ne $doc -and -not $r.timedOut -and $null -ne $doc.checks)
  $ranDetail = 'exit ' + $r.exit + ', ' + $r.seconds + ' s; report file written: ' + $written
  if ($ran) { $ranDetail += '; passed ' + $doc.passed + ', failed ' + $doc.failed + ', untested ' + $doc.untested } else { $ranDetail += '; no readable report: ' + $r.err.Trim() }
  Check 'self-test 5.7.1' 'mwcli --selftest571 ran and wrote its report' $ran $ranDetail '' (Run-Evidence $r 'mwcli --selftest571')
  if (-not $ran) { return }
  $report.selftest571 = $doc
  $labels = @{ checkpoint = 'checkpoint integrity'; memory = 'memory budget'; controls = 'verdict controls' }
  $seen = @{}; $notPassed = 0
  foreach ($c in @($doc.checks)) {
    $label = [string]$c.section; if ($labels.ContainsKey($label)) { $label = $labels[$label] }
    $status = [string]$c.status; if (@('passed', 'failed', 'untested') -notcontains $status) { $status = 'failed' }
    if ($status -ne 'passed') { $notPassed++ }
    $seen[([string]$c.section + ' ' + [string]$c.id)] = $true
    # the evidence of the check itself and, when it did not pass, of every process it ran
    $ev = [ordered]@{ id = [string]$c.id; exercisedTheIntendedCondition = [bool]$c.exercised; evidence = $c.evidence }
    if ($status -ne 'passed') {
      $wanted = @($c.steps); $runs = @()
      foreach ($s in @($doc.steps)) { if ($wanted -contains $s.label) { $runs += [ordered]@{ process = $s.label; command = $s.command; exitCode = $s.exitCode; timedOut = $s.timedOut; resultFileWritten = $s.resultFileWritten; errorClassification = $s.errorClassification; standardOutput = $s.stdout; standardError = $s.stderr } } }
      $ev.processes = $runs
    }
    Add-Check $label ([string]$c.id + ': ' + [string]$c.name) $status ([string]$c.detail) 'gate' $ev
  }
  # every check the 5.7.1 release defines must be there: a report that is shorter than expected is not a pass
  $expected = @('checkpoint P', 'checkpoint A', 'checkpoint B1', 'checkpoint B2', 'checkpoint C1', 'checkpoint C2', 'checkpoint D1', 'checkpoint D2', 'checkpoint E1', 'checkpoint E2', 'checkpoint F1', 'checkpoint F2', 'checkpoint F3', 'checkpoint S',
    'memory E', 'memory A', 'memory B', 'memory C', 'memory D1', 'memory D2', 'controls N1', 'controls N2', 'controls N3', 'controls N4')
  $missing = @($expected | Where-Object { -not $seen.ContainsKey($_) })
  foreach ($m in $missing) { Add-Check 'self-test 5.7.1' ('expected check ' + $m) 'untested' 'this check is not in the report of mwcli --selftest571' 'gate' }
  $missingText = 'none'; if ($missing.Count) { $missingText = ($missing -join ', ') }
  Check 'self-test 5.7.1' 'every expected 5.7.1 check is in the report' ($missing.Count -eq 0) ('' + ($expected.Count - $missing.Count) + ' of ' + $expected.Count + ' expected checks reported; missing: ' + $missingText)
  # mwcli exits with 0 only when every check passed; the report and the exit status must tell the same story
  $agree = (($r.exit -eq 0) -eq ($notPassed -eq 0 -and $missing.Count -eq 0)) -and (([int]$doc.failed + [int]$doc.untested) -eq $notPassed)
  Check 'self-test 5.7.1' 'the report agrees with the exit status of mwcli' $agree ('exit ' + $r.exit + '; checks not passed in the report: ' + $notPassed + ' (failed ' + $doc.failed + ', untested ' + $doc.untested + ')')
}

Run-Section 'configuration' {
  $fixture = Join-Path $Root 'studies\icm8-bb-call-small.emfix.json'; $points = @{}; $paths = @{}
  foreach ($mode in @('cpu', 'gpu')) {
    $o = Join-Path $work ('cfg-' + $mode + '.json'); $r = Invoke-Exe $mwcli @('--study', $fixture, $o, 'seeds=2', 'budgets=2000,8000', 'threads=2', 'quiet=1', 'checkpoint=off', ('processingMode=' + $mode)) @{} 1800
    $d = Read-Json $o
    if ($r.exit -eq 0 -and (Study-Complete $d)) { $points[$mode] = Study-Points $d; $paths[$mode] = [string](@(@(@($d.variants)[0].perSeed)[0].budgets)[0].trainingDevicePath) } else { $points[$mode] = 'failed: exit ' + $r.exit + ' ' + $r.err.Trim(); $paths[$mode] = '' }
  }
  Check 'configuration' 'CPU-only study completes on the CPU' ((-not ($points['cpu'] -like 'failed*')) -and ($paths['cpu'] -like 'CPU*')) ('training device: ' + $paths['cpu'] + ' ' + $(if ($points['cpu'] -like 'failed*') { $points['cpu'] } else { '' }))
  # With an NVIDIA GPU this compares the GPU-Preferred mode with the CPU; without one it checks the fall-back to the CPU.
  Check 'configuration' 'GPU-Preferred gives the CPU measurements' ((-not ($points['gpu'] -like 'failed*')) -and $points['gpu'] -eq $points['cpu']) ('GPU-Preferred training device: ' + $paths['gpu'] + ' ' + $(if ($points['gpu'] -like 'failed*') { $points['gpu'] } else { '' }))
  $bad = Join-Path $work 'bad-spec.json'; Write-Text $bad '{"protocol":4,"n":99}'; $state = Join-Path $work 'bad.state'
  $r = Invoke-Exe $mwcli @($bad, '10', '1', $state, '64') @{} 120
  Check 'configuration' 'invalid training spec refused, nothing written' ($r.exit -eq 1 -and ($r.err -match 'error') -and -not (Test-Path -LiteralPath $state)) ('exit ' + $r.exit + ': ' + $r.err.Trim())
  $r = Invoke-Exe $mwcli @((Join-Path $work 'no such spec.json'), '10', '1', $state, '64') @{} 120
  Check 'configuration' 'unreadable spec refused' ($r.exit -eq 2 -and -not (Test-Path -LiteralPath $state)) ('exit ' + $r.exit + ': ' + $r.err.Trim())
  $known = Join-Path $Root 'studies\known-akq-river.emfix.json'; $o = Join-Path $work 'cfg-option.json'
  $r = Invoke-Exe $mwcli @('--study', $known, $o, 'nonsense=1', 'quiet=1') @{} 120
  Check 'configuration' 'unknown study option refused' ($r.exit -eq 2 -and ($r.err -match 'unknown option') -and -not (Test-Path -LiteralPath $o)) ('exit ' + $r.exit + ': ' + $r.err.Trim())
  $r = Invoke-Exe $mwcli @('--study', $known, $o, 'seeds=0', 'quiet=1') @{} 120
  Check 'configuration' 'invalid study option value refused' ($r.exit -eq 1 -and ($r.err -match 'seeds') -and -not (Test-Path -LiteralPath $o)) ('exit ' + $r.exit + ': ' + $r.err.Trim())
}

Run-Section 'throughput' {
  if ($Quick) { Add-Check 'throughput' 'training throughput' 'skipped' '-Quick was given'; return }
  $rows = @(); $dir = Join-Path $Root 'validation\5.7\windows\specs'; $index = Read-Json (Join-Path $dir 'index.json')
  if (-not $index) { Add-Check 'throughput' 'training throughput' 'failed' ('index.json is missing in ' + $dir) 'information'; return }
  foreach ($s in @($index.specs)) {
    # one deal per update on one thread (how a study trains a seed), and 64 deals per update on all threads
    foreach ($arm in @(@{ file = $s.spec; threads = 1; updates = 300000; label = 'one deal per update, 1 thread' }, @{ file = $s.frozenSpec; threads = $logical; updates = 4688; label = ('64 deals per update, ' + $logical + ' threads offered') })) {
      if (-not $arm.file) { continue }
      $best = $null; $info = $null
      foreach ($rep in 1..3) { $r = Invoke-Exe $mwcli @((Join-Path $dir $arm.file), [string]$arm.updates, [string]$arm.threads, (Join-Path $work 'tp.state'), [string]$s.memoryMiB) @{} 1800; if ($r.exit -ne 0) { break }; $i = Parse-Json $r.out; if ($i -and ($null -eq $best -or $i.wallSeconds -lt $best)) { $best = $i.wallSeconds; $info = $i } }
      if ($null -eq $best) { Add-Check 'throughput' ($s.id + ', ' + $arm.label) 'failed' 'training did not run' 'information'; continue }
      $chosen = $null; if ($info.threadChoice) { $chosen = $info.threadChoice.selected }
      $row = [pscustomobject]@{ fixture = $s.id; mode = $arm.label; deals = $info.trainingDeals; bestSeconds = $best; dealsPerSecond = [math]::Round($info.trainingDeals / $best); stateVisitsPerSecond = [math]::Round($info.stateVisits / $best); threadsChosen = $chosen; tableMiB = $info.tableMiB; processPeakRssMiB = $info.processPeakRssMiB }
      $rows += $row; Add-Check 'throughput' ($s.id + ', ' + $arm.label) 'info' ('' + $row.dealsPerSecond + ' sampled deals per second (' + $best + ' s for ' + $info.trainingDeals + ' deals; threads chosen: ' + $chosen + ')') 'information'
    }
  }
  $report.trainingThroughput = $rows
  Add-Check 'throughput' 'training throughput' 'info' ('' + $rows.Count + ' measurements; see trainingThroughput in the JSON report')
}

Run-Section 'desktop host' {
  # A fixed local port is asked for, so nothing has to be read from the host's console output.
  $proc = $null; $port = Get-Random -Minimum 20000 -Maximum 45000; $base = 'http://127.0.0.1:' + $port
  try {
    $proc = Start-Child $hostExe @('--no-browser', ('--port=' + $port))
    $info = $null; $tries = 0
    while (-not $info -and $tries -lt 150 -and -not $proc.HasExited) { $tries++; try { $info = Parse-Json (Http-Get ($base + '/api/info') 5000).body } catch { Start-Sleep -Milliseconds 100 } }
    if (-not $info) { Add-Check 'desktop host' 'starts without a browser and answers /api/info' 'failed' ('no answer on ' + $base + ' (host exited: ' + $proc.HasExited + ')'); return }
    Check 'desktop host' 'starts without a browser and answers /api/info' $true $base
    Check 'desktop host' '/api/info version and build' ($info.version -eq $Release -and $info.build -eq $report.build) ('' + $info.version + ' ' + $info.build + '; studyApi ' + $info.studyApi + '; studyCheckpoints ' + $info.studyCheckpoints)
    $page = Http-Get ($base + '/') 30000
    Check 'desktop host' 'interface served with the Study tab and this build' ($page.status -eq 200 -and $page.body -match 'data-tab="study"' -and $page.body.Contains([string]$report.build)) ('' + $page.body.Length + ' characters')
    $saved = Http-Get ($base + '/api/study/checkpoints') 30000
    Check 'desktop host' 'saved-study list answers' ($saved.status -eq 200 -and $null -ne (Parse-Json $saved.body)) ('status ' + $saved.status)
  } finally {
    Stop-Child $proc
    if ($proc) { $ended = $false; try { $ended = $proc.HasExited } catch {}; Check 'desktop host' 'host process ends when stopped' $ended ('process ' + $proc.Id + ' exited: ' + $ended) }
  }
}

Run-Section 'GPU' {
  if ($SkipGpu) { Add-Check 'GPU' 'CUDA validation' 'skipped' '-SkipGpu was given'; $report.physicalNvidiaExecution = $false; return }
  $r = Invoke-Exe $mwcli @('--cuda-info') @{} 120; $cuda = Parse-Json $r.out
  $report.cudaInfo = $cuda
  $available = [bool]($cuda -and $cuda.available)
  if (-not $available) {
    $reason = $r.out.Trim(); if ($cuda -and $cuda.reason) { $reason = [string]$cuda.reason }
    Add-Check 'GPU' 'CUDA validation' 'skipped' ('no usable NVIDIA CUDA device answered on this PC (' + $reason + '): nothing about the GPU was tested')
    $report.physicalNvidiaExecution = $false; return
  }
  Add-Check 'GPU' 'CUDA device' 'info' $r.out.Trim() 'information'
  $script = Join-Path $Root 'source\tools\validate_hardware.ps1'; $hw = Join-Path $Root 'hardware-validation.json'
  $t = Get-Date; $code = -1
  try { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $script | Out-Host; $code = $LASTEXITCODE } catch { $code = -1 }
  $doc = Read-Json $hw
  Check 'GPU' 'validate_hardware.ps1 (CPU against CUDA, bit for bit; budgets; cold and warm device; cancellation)' ($code -eq 0) ('exit ' + $code + ' after ' + [math]::Round(((Get-Date) - $t).TotalSeconds) + ' s; see hardware-validation.json') 'hardware'
  $ran = [bool]($doc -and $doc.physicalNvidiaExecution); $report.physicalNvidiaExecution = $ran
  Check 'GPU' 'CUDA scored boards on this PC and matched the CPU' $ran ('physicalNvidiaExecution: ' + $ran) 'hardware'
  # the four processing modes must give the same study measurements
  $fixture = Join-Path $Root 'studies\icm8-bb-call-small.emfix.json'; $points = @{}
  foreach ($mode in @('cpu', 'auto', 'hybrid', 'gpu')) { $o = Join-Path $work ('mode-' + $mode + '.json'); $rr = Invoke-Exe $mwcli @('--study', $fixture, $o, 'seeds=2', 'budgets=2000,8000', 'threads=4', 'quiet=1', 'checkpoint=off', ('processingMode=' + $mode)) @{} 1800; if ($rr.exit -eq 0) { $points[$mode] = Study-Points (Read-Json $o) } else { $points[$mode] = 'failed: ' + $rr.err.Trim() } }
  $same = (@($points.Values | Sort-Object -Unique).Count -eq 1 -and -not ($points['cpu'] -like 'failed*'))
  Check 'GPU' 'CPU, Automatic, Hybrid and GPU-Preferred give identical study measurements' $same ((@($points.Keys) | Sort-Object) -join ', ') 'hardware'
  $gpuFailed = @($records | Where-Object { $_.section -eq 'GPU' -and $_.status -eq 'failed' }).Count
  Check 'GPU' 'CUDA validation' ($gpuFailed -eq 0) ('' + $gpuFailed + ' GPU check(s) failed')
}

$report.scriptCompleted = $true
} catch {
  $report.scriptError = $_.Exception.Message + ' (line ' + $_.InvocationInfo.ScriptLineNumber + ')'
  Write-Host ('SCRIPT ERROR: ' + $report.scriptError)
} finally {
  foreach ($c in $children) { Stop-Child $c }
  # every planned check that was not reached
  foreach ($p in $plan) { if (-not ($records | Where-Object { $_.section -eq $p.section -and $_.name -eq $p.name })) { Add-Check $p.section $p.name 'untested' 'not reached: an earlier step of this section, or the script, stopped before it' $p.class } }
  Save-Report
  try { if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
}
$failed = @($records | Where-Object { $_.status -eq 'failed' }); $untested = @($records | Where-Object { $_.status -eq 'untested' }); $skipped = @($records | Where-Object { $_.status -eq 'skipped' }); $passed = @($records | Where-Object { $_.status -eq 'passed' })
$gateBad = @($records | Where-Object { $_.class -eq 'gate' -and ($_.status -eq 'failed' -or $_.status -eq 'untested') })
Write-Host ''
Write-Host ('Passed ' + $passed.Count + ', failed ' + $failed.Count + ', skipped ' + $skipped.Count + ', untested ' + $untested.Count + '. Report: ' + $jsonPath)
if ($failed.Count) { Write-Host 'FAILED checks:'; foreach ($c in $failed) { Write-Host ('  (' + $c.class + ') ' + $c.section + ' / ' + $c.name) } }
if ($untested.Count) { Write-Host 'UNTESTED checks:'; foreach ($c in $untested) { Write-Host ('  (' + $c.class + ') ' + $c.section + ' / ' + $c.name) } }
if ($skipped.Count) { Write-Host 'SKIPPED checks:'; foreach ($c in $skipped) { Write-Host ('  ' + $c.section + ' / ' + $c.name + ': ' + (Text $c.detail)) } }
if (-not $report.scriptCompleted) { $exitCode = 2 } elseif ($gateBad.Count) { $exitCode = 1 } else { $exitCode = 0 }
exit $exitCode
