// EightMax 5.2: applies validation/5.2/six-player/preregistration.json to a convergence52 confirmation report.
//   node tools/decide52.js <confirmation.json> <decision.json>
'use strict';
const fs = require('node:fs');
const [inF, outF] = process.argv.slice(2), r = JSON.parse(fs.readFileSync(inF, 'utf8')), G = Object.fromEntries(r.games.map(g => [g.key, g]));
const et = (game, arm, T) => (G[game]?.equalTime[arm] || []).find(c => c.budgetSeconds === T) || null;
const show = c => !c || !(c.n >= 2) ? { n: c ? c.n : 0, usable: false } : c.ratio !== undefined ? { n: c.n, ratio: +c.ratio.toFixed(4), ci95: c.ratioCi95.map(v => +v.toFixed(4)), p: c.p, holmP: c.holmP ?? null, excludedSeeds: c.excludedSeeds.length } : { n: c.n, difference: +c.meanDifference.toFixed(5), ci95: c.differenceCi95.map(v => +v.toFixed(5)), p: c.p, holmP: c.holmP ?? null, excludedSeeds: c.excludedSeeds.length };
const frac = c => c && c.excludedSeeds ? c.excludedSeeds.length / (c.excludedSeeds.length + (c.n || 0)) : 1;
const cand = 'warm-4-256';
const primaries = [['flop6', 10], ['flop6w', 10], ['flop6w', 60], ['flop6-jack', 60]].map(([g, T]) => ({ game: g, budgetSeconds: T, ...show(et(g, cand, T)), counts: frac(et(g, cand, T)) <= 0.25 }));
const better = c => c.usable === false ? null : c.ratio !== undefined ? c.ratio <= 0.80 && c.holmP != null && c.holmP < 0.05 : c.ci95[1] < 0 && c.holmP != null && c.holmP < 0.05;
const worse = c => c.usable === false ? null : c.ratio !== undefined ? c.ratio > 1 : c.difference > 0;
const pA = [primaries.find(p => p.game === 'flop6w' && p.budgetSeconds === 60), primaries.find(p => p.game === 'flop6' && p.budgetSeconds === 10)];
const ruleA = pA.every(p => p.counts && better(p) === true), ruleB = primaries.every(p => worse(p) !== true);
// (c) at 300 s: warm-4-256 worse than default in every seed? (default may be capped: then compared with the default at its cap, stated)
const raw = r.raw, long = {};
for (const g of ['flop6', 'flop6w', 'flop6-jack']) { const rows = []; for (const s of Object.keys(raw[g]?.[cand] || {})) { const w = raw[g][cand][s].find(x => x.atBudget === 300), d = raw[g].default[s] && (raw[g].default[s].find(x => x.atBudget === 300) || raw[g].default[s].find(x => x.capped)); if (w && d && w.metric != null && d.metric != null) rows.push({ seed: +s, warm: w.metric, default: d.metric, defaultSeconds: +d.wallSeconds.toFixed(1), defaultCapped: !!d.capped, warmDeals: w.deals, defaultDeals: d.deals }); } long[g] = { seeds: rows, warmWorseInEverySeed: rows.length > 0 && rows.every(x => x.warm > x.default) }; }
const ruleC = Object.values(long).every(x => !x.warmWorseInEverySeed);
const controls = ['river3-chip', 'turn4'].flatMap(g => [1, 10].map(T => { const c = et(g, cand, T), s = show(c); return { game: g, budgetSeconds: T, ...s, withinMargin: s.usable === false ? null : s.ci95[1] <= 1.15 }; }));
const trend = {};   // does a longer budget help at all? geometric mean (exact) or mean (sampled) of the metric per arm and budget
for (const g of r.games) trend[g.key] = Object.fromEntries(Object.entries(g.arms).map(([a, v]) => [a, v.atBudget.map(b => ({ budgetSeconds: b.budgetSeconds, seeds: b.seedsInRange, metric: b.metric ? +(b.metric.geometricMean ?? b.metric.mean).toPrecision(4) : null, deals: b.dealsAtBudget ? Math.round(b.dealsAtBudget) : null }))]));
const preset = ruleA && ruleB && ruleC;
const out = { tool: 'decide52', generated: new Date().toISOString(), confirmation: { build: r.build, planSha256: r.planSha256, cpu: r.cpu, logicalCpus: r.logicalCpus, pinnedCpus: r.pinnedCpus, trainingThreads: r.trainingThreads }, candidate: cand,
  primaryComparisons: primaries, rules: { a_improvementAtBothGatingPrimaries: ruleA, b_noPrimaryWorseThanDefault: ruleB, c_notWorseInEverySeedAt300s: ruleC },
  longBudget300s: long, controls, controlsAllWithinMargin: controls.every(c => c.withinMargin === true),
  parallel64: Object.fromEntries(['flop6', 'flop6w', 'flop6-jack', 'river3-chip', 'turn4'].map(g => [g, (G[g]?.equalTime.parallel64 || []).map(c => ({ budgetSeconds: c.budgetSeconds, ...show(c) }))])),
  warmVsParallel64: Object.fromEntries(r.games.map(g => [g.key, (g.warmVsParallel64EqualTime || []).map(c => ({ budgetSeconds: c.budgetSeconds, ...show({ ...c, excludedSeeds: [] }) }))])),
  equalDeals: Object.fromEntries(r.games.map(g => [g.key, Object.fromEntries(Object.entries(g.equalDeals).map(([a, cs]) => [a, cs.map(c => ({ defaultBudgetSeconds: c.defaultBudgetSeconds, deals: Math.round(c.deals), ...show({ ...c, excludedSeeds: [] }) }))]))])),
  armAtBudgetVsDefaultAtUpdateCap: Object.fromEntries(r.games.filter(g => g.armAtBudgetVsDefaultAtUpdateCap).map(g => [g.key, Object.fromEntries(Object.entries(g.armAtBudgetVsDefaultAtUpdateCap).map(([a, cs]) => [a, cs.map(c => ({ budgetSeconds: c.budgetSeconds, defaultCapSecondsMean: +c.defaultCapSeconds.mean.toFixed(1), ...show({ ...c, excludedSeeds: [] }) }))]))])),
  metricByBudget: trend, workers: Object.fromEntries(r.games.map(g => [g.key, Object.fromEntries(Object.entries(g.arms).map(([a, v]) => [a, { requested: v.workerThreadsRequested, usedMax: v.workerThreadsUsedMax, dealsPerSecond: Math.round(v.dealsPerSecond.mean), evaluationSecondsPerCall: v.evaluationSecondsPerCall.mean ? +v.evaluationSecondsPerCall.mean.toFixed(2) : null, peakTrainingRssMiB: v.peakTrainingRssMiB }]))])),
  incomplete: Object.fromEntries(r.games.map(g => [g.key, g.incomplete])),
  decision: { validatedSixPlayerPreset: preset, defaultTrainerChanged: false,
    text: preset ? 'warm-4-256 meets the pre-registered rule for a six-player preset.' : 'warm-4-256 does NOT meet the pre-registered rule for a six-player preset (' + [ruleA ? null : 'rule (a): no >= 20% improvement with Holm p < 0.05 at both flop6w @ 60 s and flop6 @ 10 s', ruleB ? null : 'rule (b): a primary estimate is worse than the default', ruleC ? null : 'rule (c): worse than the default in every seed at 300 s on a six-player fixture'].filter(Boolean).join('; ') + '). No preset is exposed in the Windows interface; batchSchedule stays an opt-in native/CLI option and the default trainer is unchanged.' } };
fs.writeFileSync(outF, JSON.stringify(out, null, 1));
console.log(JSON.stringify({ primaries, rules: out.rules, controls, decision: out.decision.text }, null, 1));
