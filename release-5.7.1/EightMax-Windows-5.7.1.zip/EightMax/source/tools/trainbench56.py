#!/usr/bin/env python3
"""EightMax 5.6: training throughput of the default trainer on the study fixtures, against the unchanged 5.5 binary.
Usage: trainbench56.py BASELINE_5.5_CLI CURRENT_CLI OUTPUT_DIRECTORY [--deals N] [--reps R] [--fixtures a,b] [--threads T]

Trains variant 0 of each study fixture (its nativeSpec, as the study workflow does: one deal per update, one training
thread per seed) for the same number of sampled deals with both binaries, alternating the order in each repetition.
Reports wall seconds (minimum and median over repetitions), sampled deals per second, state visits per second, peak
resident memory, and whether the two saved states are byte-identical. Training only: no evaluation is run.
Every repetition is kept in raw.jsonl. Timings are for this machine and say nothing about another."""
import sys, json, subprocess, hashlib, pathlib, argparse, statistics, time, platform, os
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('--deals', type=int, default=300000); ap.add_argument('--reps', type=int, default=5)
ap.add_argument('--fixtures', default=''); ap.add_argument('--threads', type=int, default=1); ap.add_argument('--memoryMiB', type=int, default=0)
A = ap.parse_args(); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); out = pathlib.Path(A.out).resolve(); out.mkdir(parents=True, exist_ok=True)
if (out / 'raw.jsonl').exists(): raise SystemExit('Use a fresh output directory.')
studies = pathlib.Path(__file__).resolve().parent.parent / 'studies'
names = [x for x in A.fixtures.split(',') if x] or sorted(p.name[:-len('.emfix.json')] for p in studies.glob('*.emfix.json'))
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
plan = {'fixtures': names, 'deals': A.deals, 'repetitions': A.reps, 'threads': A.threads, 'environment': platform.platform(), 'logicalProcessors': os.cpu_count(), 'baselineSha256': sha(old), 'currentSha256': sha(new), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(out / 'plan.json').write_text(json.dumps(plan, indent=1)); summary = []
for name in names:
    fx = json.loads((studies / (name + '.emfix.json')).read_text()); spec = out / (name + '.spec.json'); spec.write_text(json.dumps(fx['variants'][0]['nativeSpec']))
    mem = A.memoryMiB or int(fx['study'].get('memoryMiB', 1024)); runs = {'old': [], 'new': []}; hashes = {}
    for rep in range(A.reps):
        for arm in (('old', 'new') if rep % 2 == 0 else ('new', 'old')):
            st = out / (name + '.' + arm + '.state'); cli = old if arm == 'old' else new
            p = subprocess.run([cli, str(spec), str(A.deals), str(A.threads), str(st), str(mem)], capture_output=True, text=True, timeout=7200)
            if p.returncode: raise SystemExit(name + ' ' + arm + ': ' + p.stderr[-400:])
            info = json.loads(p.stdout); hashes[arm] = sha(st)
            row = {'fixture': name, 'arm': arm, 'repetition': rep, 'wallSeconds': info['wallSeconds'], 'trainingDeals': info['trainingDeals'], 'stateVisits': info['stateVisits'], 'rows': info['rows'], 'states': info['states'], 'tableMiB': info['tableMiB'],
                   'processPeakRssMiB': info.get('processPeakRssMiB'), 'limitReached': info['limitReached'], 'stateSha256': hashes[arm], 'stateCache': info.get('stateCache'), 'linkCache': info.get('linkCache'), 'seconds': info.get('seconds')}
            runs[arm].append(row)
            with (out / 'raw.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
            st.unlink()
    def agg(rs): w = [r['wallSeconds'] for r in rs]; return {'minSeconds': min(w), 'medianSeconds': statistics.median(w), 'dealsPerSecondBest': rs[0]['trainingDeals'] / min(w), 'visitsPerSecondBest': rs[0]['stateVisits'] / min(w), 'peakRssMiB': max(r['processPeakRssMiB'] or 0 for r in rs)}
    o, n = agg(runs['old']), agg(runs['new'])
    s = {'fixture': name, 'players': fx['variants'][0]['nativeSpec'].get('n'), 'deals': runs['new'][0]['trainingDeals'], 'stateVisits': runs['new'][0]['stateVisits'], 'rows': runs['new'][0]['rows'], 'tableMiB': runs['new'][0]['tableMiB'], 'v55': o, 'v56': n,
         'speedupBest': o['minSeconds'] / n['minSeconds'], 'speedupMedian': o['medianSeconds'] / n['medianSeconds'], 'stateIdentical': hashes['old'] == hashes['new'], 'limitReached': runs['new'][0]['limitReached']}
    summary.append(s); print(json.dumps(s), flush=True)
(out / 'summary.json').write_text(json.dumps({'plan': plan, 'fixtures': summary}, indent=1))
sys.exit(0 if all(s['stateIdentical'] for s in summary) else 1)
