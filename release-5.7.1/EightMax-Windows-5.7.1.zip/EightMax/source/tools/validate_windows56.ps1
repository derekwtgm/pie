# EightMax 5.6 validation on a physical Windows PC. Windows PowerShell 5.1 or PowerShell 7; nothing to install.
# Run from the release folder:  "Run 5.6 Windows validation.bat"   (or: powershell -ExecutionPolicy Bypass -File source\tools\validate_windows56.ps1)
#
# Everything below was done on Linux and under Wine before release; none of it was done on Windows hardware.
# This script repeats it on your PC and writes Windows-validation-5.6.json (and a .txt summary) next to the
# executables. Nothing is installed, nothing outside the release folder and a temporary folder is written.
#   1  environment      Windows version, CPU, RAM, GPU, virtual-machine and Wine indicators
#   2  integrity        every file against SHA256SUMS.txt; the three executables against BUILD-INFO.json
#   3  golden states    11 training runs must reproduce, byte for byte, the states the 5.5 Linux binary wrote
#   4  threads          one frozen-batch study trained with 1, 2, 4, 8 and all logical processors: identical state
#   5  evaluator        exact best response with a 32 MiB and a 1,024 MiB cache: identical values, time and memory
#   6  study            a complete quick study; statistical fields of 5.6 present; the known game's closed form
#   7  recovery         time-limit interruption and resume, a killed process and resume, a second process refused
#   8  memory           a study given a too-small process memory budget stops safely and resumes
#   9  throughput       sampled deals per second of the default trainer on the study fixtures (this PC's numbers)
#  10  desktop host     EightMax.exe starts without a browser, reports version and build, serves the Study tab
#  11  GPU              validate_hardware.ps1 and gpustress.exe (skipped with the reason when no NVIDIA GPU answers)
# -Quick skips 9 and shortens 7; -SkipGpu skips 11; -SkipIntegrity skips the 3,900-file checksum pass.
param([switch]$Quick, [switch]$SkipGpu, [switch]$SkipIntegrity, [string]$Root = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path)
$ErrorActionPreference = 'Stop'
Remove-TypeData System.Array -ErrorAction SilentlyContinue
$mwcli = Join-Path $Root 'mwcli.exe'; $host56 = Join-Path $Root 'EightMax.exe'; $stress = Join-Path $Root 'gpustress.exe'
$work = Join-Path ([System.IO.Path]::GetTempPath()) ('EightMax-5.6-validation-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$records = New-Object System.Collections.Generic.List[object]
$sections = New-Object System.Collections.Generic.List[object]
$started = Get-Date
function Add-Check([string]$section, [string]$name, [string]$status, $detail) {
  $records.Add([pscustomobject]@{ section = $section; name = $name; status = $status; detail = $detail })
  $mark = 'PASS'; if ($status -eq 'failed') { $mark = 'FAIL' } elseif ($status -eq 'skipped') { $mark = 'SKIP' } elseif ($status -eq 'info') { $mark = 'INFO' }
  Write-Host ('  [{0}] {1}: {2}' -f $mark, $name, $(if ($detail -is [string]) { $detail } else { ($detail | ConvertTo-Json -Compress -Depth 6) }))
}
function Check([string]$section, [string]$name, [bool]$ok, $detail) { Add-Check $section $name $(if ($ok) { 'passed' } else { 'failed' }) $detail }
function Run-Section([string]$name, [scriptblock]$body) {
  Write-Host ''; Write-Host ('== ' + $name)
  $t = Get-Date; $err = $null
  try { & $body } catch { $err = $_.Exception.Message; Add-Check $name 'section completed' 'failed' $err }
  $sections.Add([pscustomobject]@{ section = $name; seconds = [math]::Round(((Get-Date) - $t).TotalSeconds, 2); error = $err })
}
function Sha256([string]$path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
# Runs a program, returns exit code, stdout, stderr and seconds. Arguments are passed as an array.
function Invoke-Exe([string]$exe, [string[]]$arguments, [hashtable]$environment = @{}, [int]$timeoutSeconds = 3600) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $exe; $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true; $psi.WorkingDirectory = $work
  $psi.Arguments = ($arguments | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } }) -join ' '
  foreach ($k in $environment.Keys) { $psi.EnvironmentVariables[$k] = [string]$environment[$k] }
  $p = New-Object System.Diagnostics.Process; $p.StartInfo = $psi
  $t = Get-Date; [void]$p.Start()
  $outTask = $p.StandardOutput.ReadToEndAsync(); $errTask = $p.StandardError.ReadToEndAsync()
  # Wait in short steps so that the peak working set can be read while the process is alive (it is not available afterwards).
  $peakBytes = 0; $finished = $false; $deadline = (Get-Date).AddSeconds($timeoutSeconds)
  while (-not $finished) {
    $finished = $p.WaitForExit(100)
    if (-not $finished) { try { $p.Refresh(); if ($p.PeakWorkingSet64 -gt $peakBytes) { $peakBytes = $p.PeakWorkingSet64 } } catch {}; if ((Get-Date) -gt $deadline) { break } }
  }
  if (-not $finished) { try { $p.Kill() } catch {}; $p.WaitForExit() } else { $p.WaitForExit() }
  $peak = [math]::Round($peakBytes / 1MB, 1)
  [pscustomobject]@{ exit = $(if ($finished) { $p.ExitCode } else { -999 }); out = $outTask.Result; err = $errTask.Result; seconds = [math]::Round(((Get-Date) - $t).TotalSeconds, 3); timedOut = (-not $finished); peakMiB = $peak }
}
function Read-Json([string]$path) { Get-Content -LiteralPath $path -Raw | ConvertFrom-Json }
function Write-Text([string]$path, [string]$text) { [System.IO.File]::WriteAllText($path, $text, (New-Object System.Text.UTF8Encoding($false))) }
$logical = [Environment]::ProcessorCount
$report = [ordered]@{ tool = 'validate_windows56.ps1'; release = '5.6'; started = $started.ToString('o'); root = $Root; quick = [bool]$Quick }

Run-Section 'environment' {
  $os = Get-CimInstance Win32_OperatingSystem; $cs = Get-CimInstance Win32_ComputerSystem; $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
  $gpus = @(Get-CimInstance Win32_VideoController | ForEach-Object { [pscustomobject]@{ name = $_.Name; driver = $_.DriverVersion; adapterRamMiB = [math]::Round($_.AdapterRAM / 1MB) } })
  $wine = [bool](Get-ItemProperty -Path 'HKLM:\Software\Wine' -ErrorAction SilentlyContinue)
  $vm = ($cs.Model -match 'Virtual|VMware|KVM|HVM|VirtualBox') -or ($cs.Manufacturer -match 'QEMU|Xen|innotek|Parallels')
  $env56 = [ordered]@{ windows = $os.Caption; windowsVersion = $os.Version; build = $os.BuildNumber; architecture = $os.OSArchitecture; cpu = $cpu.Name.Trim(); physicalCores = $cpu.NumberOfCores; logicalProcessors = $logical
    ramGiB = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1); gpus = $gpus; manufacturer = $cs.Manufacturer; model = $cs.Model; wineDetected = $wine; virtualMachineIndicators = [bool]$vm; powershell = $PSVersionTable.PSVersion.ToString() }
  $report.environment = $env56
  Add-Check 'environment' 'machine' 'info' ('{0}; {1}; {2} logical processors; {3} GiB RAM; GPU: {4}' -f $env56.windows, $env56.cpu, $logical, $env56.ramGiB, (($gpus | ForEach-Object { $_.name }) -join ', '))
  Check 'environment' '64-bit Windows' ($os.OSArchitecture -match '64') $os.OSArchitecture
  if ($wine -or $vm) { Add-Check 'environment' 'physical hardware' 'info' 'Wine or a virtual machine was detected: this report does NOT count as physical Windows validation' }
  else { Add-Check 'environment' 'physical hardware' 'passed' 'no Wine or virtual-machine indicator' }
  $report.physicalWindows = (-not $wine) -and (-not $vm)
}

Run-Section 'integrity' {
  foreach ($f in @($mwcli, $host56, $stress)) { Check 'integrity' ((Split-Path $f -Leaf) + ' present') (Test-Path -LiteralPath $f) $f }
  $info = Read-Json (Join-Path $Root 'BUILD-INFO.json'); $report.build = $info.build; $report.version = $info.version
  Check 'integrity' 'BUILD-INFO.json version' ($info.version -eq '5.6') $info.version
  $a = Invoke-Exe $mwcli @('--build-id'); $b = Invoke-Exe $host56 @('--build-id')
  Check 'integrity' 'mwcli.exe build id' ($a.out.Trim() -eq ('EightMaxBuild=' + $info.build)) $a.out.Trim()
  Check 'integrity' 'EightMax.exe build id' ($b.out.Trim() -eq ('EightMaxBuild=' + $info.build)) $b.out.Trim()
  $sums = Join-Path $Root 'SHA256SUMS.txt'
  if ($SkipIntegrity) { Add-Check 'integrity' 'SHA256SUMS.txt' 'skipped' '-SkipIntegrity was given' }
  elseif (-not (Test-Path -LiteralPath $sums)) { Add-Check 'integrity' 'SHA256SUMS.txt' 'failed' 'file missing' }
  else {
    $bad = New-Object System.Collections.Generic.List[string]; $count = 0
    foreach ($line in [System.IO.File]::ReadAllLines($sums)) {
      if ($line.Length -lt 67) { continue }
      $hash = $line.Substring(0, 64); $rel = $line.Substring(66); $count++
      $p = Join-Path $Root $rel
      if (-not (Test-Path -LiteralPath $p)) { $bad.Add('missing: ' + $rel) } elseif ((Sha256 $p) -ne $hash) { $bad.Add('changed: ' + $rel) }
    }
    $shown = @($bad | Select-Object -First 10)
    Check 'integrity' ('SHA256SUMS.txt (' + $count + ' files)') ($bad.Count -eq 0 -and $count -gt 3000) $(if ($bad.Count) { $shown -join '; ' } else { 'every file matches' })
  }
}

Run-Section 'golden states' {
  $dir = Join-Path $Root 'validation/5.6/windows/golden'; $g = Read-Json (Join-Path $dir 'golden.json'); $rows = @()
  foreach ($c in $g.cases) {
    $state = Join-Path $work ($c.name + '.state')
    $r = Invoke-Exe $mwcli @((Join-Path $dir $c.spec), [string]$c.updates, [string]$c.threads, $state, [string]$c.memoryMiB)
    $hash = ''; if ($r.exit -eq 0 -and (Test-Path -LiteralPath $state)) { $hash = Sha256 $state }
    $rows += [pscustomobject]@{ name = $c.name; exit = $r.exit; seconds = $r.seconds; identical = ($hash -eq $c.stateSha256) }
    Check 'golden states' $c.name ($hash -eq $c.stateSha256) $(if ($hash -eq $c.stateSha256) { 'identical to 5.5 (' + $r.seconds + ' s)' } else { 'exit ' + $r.exit + ', sha256 ' + $hash + ', expected ' + $c.stateSha256 + ' ' + $r.err.Trim() })
  }
  $report.goldenStates = $rows
}

Run-Section 'threads' {
  $dir = Join-Path $Root 'validation/5.6/windows/golden'; $spec = Join-Path $dir 'g05-flop6.spec.json'
  $counts = @(1, 2, 4, 8, $logical) | Where-Object { $_ -le $logical } | Sort-Object -Unique; $hashes = @{}; $rows = @()
  foreach ($n in $counts) {
    $state = Join-Path $work ('threads-' + $n + '.state'); $r = Invoke-Exe $mwcli @($spec, '20000', [string]$n, $state, '256')
    $h = ''; if ($r.exit -eq 0) { $h = Sha256 $state }; $hashes[$n] = $h
    $info = $null; try { $info = $r.out | ConvertFrom-Json } catch {}
    $rows += [pscustomobject]@{ threads = $n; exit = $r.exit; wallSeconds = $(if ($info) { $info.wallSeconds } else { $null }); threadsUsed = $(if ($info) { $info.threads } else { $null }); sha256 = $h }
  }
  $distinct = @($hashes.Values | Sort-Object -Unique)
  Check 'threads' ('identical state with ' + ($counts -join ', ') + ' threads') ($distinct.Count -eq 1 -and $distinct[0] -ne '') ($rows | ForEach-Object { '' + $_.threads + ' threads: ' + $_.wallSeconds + ' s' }) 
  $report.threadScaling = $rows
}

Run-Section 'evaluator' {
  $dir = Join-Path $Root 'validation/5.6/windows/golden'; $rows = @()
  foreach ($name in @('g04-bubble4', 'g05-flop6', 'g06-final8')) {
    $spec = Join-Path $dir ($name + '.spec.json'); $state = Join-Path $work ($name + '.state')
    if (-not (Test-Path -LiteralPath $state)) { Add-Check 'evaluator' $name 'skipped' 'its golden state was not produced'; continue }
    $values = @{}
    foreach ($mem in @(32, 1024)) {
      $q = Join-Path $work ('q' + $mem + '.json'); Write-Text $q ('{"method":"exact","device":"cpu","threads":1,"timeLimitMs":900000,"maxVisits":2000000000,"memoryMiB":' + $mem + '}')
      $r = Invoke-Exe $mwcli @('--gain', $spec, $state, $q, '128'); $nc = $null; try { $nc = ($r.out | ConvertFrom-Json).nashConv } catch {}
      $values[$mem] = $nc; $rows += [pscustomobject]@{ game = $name; cacheMiB = $mem; exit = $r.exit; seconds = $r.seconds; peakMiB = $r.peakMiB; nashConv = $nc }
    }
    Check 'evaluator' ($name + ': exact NashConv with 32 and 1,024 MiB caches') (($null -ne $values[32]) -and ($values[32] -eq $values[1024])) ('' + $values[32] + ' / ' + $values[1024])
  }
  $report.evaluator = $rows
}

Run-Section 'study' {
  $fixture = Join-Path $Root 'studies/known-akq-river.emfix.json'; $out = Join-Path $work 'quick.json'
  $r = Invoke-Exe $mwcli @('--study', $fixture, $out, 'preset=quick', 'processingMode=cpu', 'checkpoint=off')
  Check 'study' 'quick study completes' ($r.exit -eq 0 -and (Test-Path -LiteralPath $out)) ('exit ' + $r.exit + ', ' + $r.seconds + ' s')
  $d = Read-Json $out; $v = $d.variants[0]; $b = $v.budgets[$v.budgets.Count - 1]
  Check 'study' 'version and build in the result' ($d.version -eq '5.6' -and $d.build -eq $report.build) ($d.version + ' ' + $d.build)
  Check 'study' '5.6 statistics present' ($d.replicationCalculation -eq 'study-5.6-replication-v1' -and $null -ne $b.bestAction -and $null -ne $b.confidence.replication) $d.replicationCalculation
  Check 'study' 'two trainings declare no best action' ($b.bestAction.declared -eq $false -and $b.confidence.replication.verdict -eq 'insufficientReplication') $b.confidence.replication.verdict
  Check 'study' 'warnings state what is not established' (@($d.statisticalWarnings | Where-Object { $_.code -eq 'insufficientReplication' }).Count -ge 1) (@($d.statisticalWarnings | ForEach-Object { $_.code }) -join ', ')
  Check 'study' 'printed summary' ($r.out -match 'What this study does not establish') 'section present'
  $report.quickStudy = [ordered]@{ seconds = $r.seconds; peakMiB = $r.peakMiB; verdict = $b.verdict; acrossTrainings = $b.confidence.replication.verdict }
}

function Study-Points($doc) { $rows = @(); foreach ($v in $doc.variants) { foreach ($s in $v.perSeed) { foreach ($p in $s.budgets) { $rows += ('' + $v.name + '|' + $s.seed + '|' + $p.budgetDeals + '|' + $p.deals + '|' + (($p.ev | ForEach-Object { [string]$_ }) -join ',') + '|' + $p.quality) } } }; $rows -join "`n" }
Run-Section 'recovery' {
  $fixture = Join-Path $Root 'studies/known-akq-river.emfix.json'; $budgets = 'budgets=20000,400000,6000000'; if ($Quick) { $budgets = 'budgets=20000,400000,1500000' }
  $opts = @('seeds=2', $budgets, 'threads=2', 'quiet=1', 'processingMode=cpu')
  $ref = Join-Path $work 'ref.json'; $r = Invoke-Exe $mwcli (@('--study', $fixture, $ref) + $opts + @('checkpoint=off'))
  Check 'recovery' 'uninterrupted reference' ($r.exit -eq 0) ('' + $r.seconds + ' s'); $want = Study-Points (Read-Json $ref)
  # (a) time limit, then resume until complete
  $ck = Join-Path $work 'ck-time'; $out = Join-Path $work 'time.json'; $rounds = 0
  $r = Invoke-Exe $mwcli (@('--study', $fixture, $out) + $opts + @(('checkpoint=' + $ck), 'timeLimitSeconds=0.5', 'checkpointSeconds=0.1'))
  $firstComplete = (Read-Json $out).completion.complete
  while (-not (Read-Json $out).completion.complete -and $rounds -lt 60) { $rounds++; $r = Invoke-Exe $mwcli (@('--study', $fixture, $out) + $opts + @(('checkpoint=' + $ck), 'resume=1', 'timeLimitSeconds=0.5', 'checkpointSeconds=0.1')) }
  $done = Read-Json $out
  Check 'recovery' 'time-limit interruption and resume' ($done.completion.complete -and ((Study-Points $done) -eq $want)) ('first run complete: ' + $firstComplete + '; resumes: ' + $rounds + '; equals the uninterrupted study: ' + ((Study-Points $done) -eq $want))
  # (b) kill the process, a second process is refused while the first runs, then resume
  $ck2 = Join-Path $work 'ck-kill'; $out2 = Join-Path $work 'kill.json'
  $argLine = (@('--study', $fixture, $out2) + $opts + @(('checkpoint=' + $ck2), 'checkpointSeconds=0.1') | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }) -join ' '
  $p = Start-Process -FilePath $mwcli -ArgumentList $argLine -WorkingDirectory $work -PassThru -WindowStyle Hidden
  $waited = 0; while (-not (Test-Path -LiteralPath (Join-Path $ck2 'manifest.json')) -and $waited -lt 200 -and -not $p.HasExited) { Start-Sleep -Milliseconds 50; $waited++ }
  if ($p.HasExited) { Add-Check 'recovery' 'second process refused while the first runs' 'skipped' 'the first study finished before it could be tested (very fast PC); rerun without -Quick' }
  else {
    $second = Invoke-Exe $mwcli (@('--study', $fixture, (Join-Path $work 'second.json')) + $opts + @(('checkpoint=' + $ck2), 'resume=1'))
    if ($p.HasExited) { Add-Check 'recovery' 'second process refused while the first runs' 'skipped' 'the first study finished during the attempt' }
    else { Check 'recovery' 'second process refused while the first runs' ($second.exit -ne 0 -and ($second.err + $second.out) -match 'in use') ('exit ' + $second.exit + ': ' + $second.err.Trim()) }
  }
  if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force; $p.WaitForExit() ; $killed = $true } else { $killed = $false }
  $r = Invoke-Exe $mwcli (@('--study', $fixture, $out2) + $opts + @(('checkpoint=' + $ck2), 'resume=1'))
  $done2 = $null; if (Test-Path -LiteralPath $out2) { $done2 = Read-Json $out2 }
  Check 'recovery' 'killed process, then resume' ($r.exit -eq 0 -and $done2 -and $done2.completion.complete -and ((Study-Points $done2) -eq $want)) ('process was killed: ' + $killed + '; resume exit ' + $r.exit + ' ' + $r.err.Trim())
  # (c) a damaged manifest is not loaded silently
  $ck3 = Join-Path $work 'ck-damage'; $out3 = Join-Path $work 'damage.json'
  $r = Invoke-Exe $mwcli (@('--study', $fixture, $out3) + $opts + @(('checkpoint=' + $ck3), 'timeLimitSeconds=0.5', 'checkpointSeconds=0.1'))
  foreach ($m in @(Get-ChildItem -LiteralPath $ck3 -Filter 'manifest*.json')) { $t = [System.IO.File]::ReadAllText($m.FullName); Write-Text $m.FullName ($t -replace '"resumeCount":', '"resumeCount" :') }
  $r = Invoke-Exe $mwcli (@('--study', $fixture, (Join-Path $work 'damage2.json')) + $opts + @(('checkpoint=' + $ck3), 'resume=1'))
  Check 'recovery' 'damaged manifest refused' ($r.exit -ne 0 -and ($r.err + $r.out) -match 'SHA-256|damaged|no usable manifest') ('exit ' + $r.exit + ': ' + $r.err.Trim())
}

Run-Section 'memory' {
  $fixture = Join-Path $Root 'studies/flop3-kings-small.emfix.json'; $out = Join-Path $work 'mem.json'; $ck = Join-Path $work 'ck-mem'
  $opts = @('seeds=2', 'budgets=20000,200000', 'threads=2', 'quiet=1', 'processingMode=cpu', ('checkpoint=' + $ck))
  $r = Invoke-Exe $mwcli (@('--study', $fixture, $out) + $opts + @('processMemoryMiB=24'))
  $d = $null; if (Test-Path -LiteralPath $out) { $d = Read-Json $out }
  Check 'memory' 'a too-small process budget stops the study without losing it' ($d -and ($d.run.stoppedByProcessMemory -or $d.completion.complete)) ('exit ' + $r.exit + '; stopped by the memory budget: ' + $(if ($d) { $d.run.stoppedByProcessMemory } else { 'no document' }) + '; peak ' + $r.peakMiB + ' MiB')
  $r = Invoke-Exe $mwcli (@('--study', $fixture, $out) + $opts + @('resume=1'))
  $d = $null; if (Test-Path -LiteralPath $out) { $d = Read-Json $out }
  Check 'memory' 'resumed with the automatic budget and completed' ($r.exit -eq 0 -and $d -and $d.completion.complete) ('exit ' + $r.exit + '; peak ' + $r.peakMiB + ' MiB; physical memory seen ' + $(if ($d) { $d.run.physicalMemoryMiB } else { '?' }) + ' MiB')
}

Run-Section 'throughput' {
  if ($Quick) { Add-Check 'throughput' 'training throughput' 'skipped' '-Quick was given'; return }
  $rows = @(); $specIndex = Read-Json (Join-Path $Root 'validation/5.6/windows/specs/index.json')
  foreach ($id in @('known-akq-river', 'flop3-kings-small', 'flop6-jack-small', 'icm8-bb-call-small', 'flop3-kings', 'flop6-jack', 'icm8-bb-call', 'btn25-open')) {
    # the training spec of each fixture (variant 0) is shipped as a file, so no JSON is rewritten by PowerShell
    $spec = Join-Path $Root ('validation/5.6/windows/specs/' + $id + '.spec.json'); $mem = ($specIndex.specs | Where-Object { $_.id -eq $id }).memoryMiB
    $best = $null; $info = $null
    foreach ($rep in 1..3) { $r = Invoke-Exe $mwcli @($spec, '300000', '1', (Join-Path $work 'tp.state'), [string]$mem); if ($r.exit -ne 0) { break }; $i = $r.out | ConvertFrom-Json; if ($null -eq $best -or $i.wallSeconds -lt $best) { $best = $i.wallSeconds; $info = $i } }
    if ($null -eq $best) { Add-Check 'throughput' $id 'failed' 'training did not run'; continue }
    $row = [pscustomobject]@{ fixture = $id; deals = $info.trainingDeals; bestSeconds = $best; dealsPerSecond = [math]::Round($info.trainingDeals / $best); stateVisitsPerSecond = [math]::Round($info.stateVisits / $best); tableMiB = $info.tableMiB; processPeakRssMiB = $info.processPeakRssMiB }
    $rows += $row; Add-Check 'throughput' $id 'info' ('' + $row.dealsPerSecond + ' sampled deals per second, one thread (' + $best + ' s for ' + $info.trainingDeals + ' deals; table ' + $info.tableMiB + ' MiB)')
  }
  $report.trainingThroughput = $rows
}

Run-Section 'desktop host' {
  # A fixed local port is asked for, so nothing has to be read from the host's console output.
  $proc = $null; $port = Get-Random -Minimum 20000 -Maximum 45000; $base = 'http://127.0.0.1:' + $port
  try {
    $proc = Start-Process -FilePath $host56 -ArgumentList ('--no-browser --port=' + $port) -WorkingDirectory $work -PassThru -WindowStyle Hidden
    $info = $null; $tries = 0
    while (-not $info -and $tries -lt 150 -and -not $proc.HasExited) { $tries++; try { $info = Invoke-RestMethod -Uri ($base + '/api/info') -TimeoutSec 5 } catch { Start-Sleep -Milliseconds 100 } }
    if (-not $info) { Add-Check 'desktop host' 'starts without a browser and answers /api/info' 'failed' ('no answer on ' + $base + ' (host exited: ' + $proc.HasExited + ')'); return }
    Check 'desktop host' 'starts without a browser and answers /api/info' $true $base
    Check 'desktop host' '/api/info version and build' ($info.version -eq '5.6' -and $info.build -eq $report.build) ('' + $info.version + ' ' + $info.build + '; studyApi ' + $info.studyApi + '; studyCheckpoints ' + $info.studyCheckpoints)
    $page = Invoke-WebRequest -Uri ($base + '/') -UseBasicParsing -TimeoutSec 30
    Check 'desktop host' 'interface served with the Study tab and this build' ($page.StatusCode -eq 200 -and $page.Content -match 'data-tab="study"' -and $page.Content.Contains([string]$report.build)) ('' + $page.Content.Length + ' characters')
    $saved = Invoke-RestMethod -Uri ($base + '/api/study/checkpoints') -TimeoutSec 30
    Check 'desktop host' 'saved-study list answers' ($null -ne $saved) 'answered'
  } finally { if ($proc -and -not $proc.HasExited) { Stop-Process -Id $proc.Id -Force } }
}

Run-Section 'GPU' {
  if ($SkipGpu) { Add-Check 'GPU' 'CUDA validation' 'skipped' '-SkipGpu was given'; return }
  $r = Invoke-Exe $mwcli @('--cuda-info'); $cuda = $null; try { $cuda = $r.out | ConvertFrom-Json } catch {}
  $report.cudaInfo = $cuda
  $available = $false; if ($cuda) { foreach ($n in @('available', 'ok', 'usable')) { if ($cuda.PSObject.Properties.Name -contains $n -and $cuda.$n) { $available = $true } } }
  if (-not $available) { Add-Check 'GPU' 'CUDA validation' 'skipped' ('no usable NVIDIA CUDA device answered on this PC: ' + $r.out.Trim()); $report.physicalNvidiaExecution = $false; return }
  Add-Check 'GPU' 'CUDA device' 'info' $r.out.Trim()
  $script = Join-Path $Root 'source/tools/validate_hardware.ps1'; $hw = Join-Path $Root 'hardware-validation.json'
  $t = Get-Date; & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $script | Out-Host; $code = $LASTEXITCODE
  $doc = $null; if (Test-Path -LiteralPath $hw) { $doc = Read-Json $hw }
  Check 'GPU' 'validate_hardware.ps1 (CPU against CUDA, bit for bit; budgets; cold and warm device; cancellation)' ($code -eq 0) ('exit ' + $code + ' after ' + [math]::Round(((Get-Date) - $t).TotalSeconds) + ' s; see hardware-validation.json')
  if ($doc) { $report.physicalNvidiaExecution = [bool]$doc.physicalNvidiaExecution; Check 'GPU' 'CUDA scored boards on this PC and matched the CPU' ([bool]$doc.physicalNvidiaExecution) ('physicalNvidiaExecution: ' + $doc.physicalNvidiaExecution) }
  # the four processing modes must give the same study measurements
  $fixture = Join-Path $Root 'studies/icm8-bb-call-small.emfix.json'; $points = @{}
  foreach ($mode in @('cpu', 'auto', 'hybrid', 'gpu')) { $o = Join-Path $work ('mode-' + $mode + '.json'); $r = Invoke-Exe $mwcli @('--study', $fixture, $o, 'seeds=2', 'budgets=2000,8000', 'threads=4', 'quiet=1', 'checkpoint=off', ('processingMode=' + $mode)); if ($r.exit -eq 0) { $points[$mode] = Study-Points (Read-Json $o) } else { $points[$mode] = 'failed: ' + $r.err.Trim() } }
  Check 'GPU' 'CPU, Automatic, Hybrid and GPU-Preferred give identical study measurements' (@($points.Values | Sort-Object -Unique).Count -eq 1 -and -not ($points['cpu'] -like 'failed*')) (($points.Keys | Sort-Object) -join ', ')
}

$failed = @($records | Where-Object { $_.status -eq 'failed' }); $skipped = @($records | Where-Object { $_.status -eq 'skipped' }); $passedCount = @($records | Where-Object { $_.status -eq 'passed' }).Count
$report.finished = (Get-Date).ToString('o'); $report.seconds = [math]::Round(((Get-Date) - $started).TotalSeconds, 1)
$report.summary = [ordered]@{ passed = $passedCount; failed = $failed.Count; skipped = $skipped.Count; allPassed = ($failed.Count -eq 0) }
$report.sections = $sections; $report.checks = $records
$jsonPath = Join-Path $Root 'Windows-validation-5.6.json'; $txtPath = Join-Path $Root 'Windows-validation-5.6.txt'
Write-Text $jsonPath ($report | ConvertTo-Json -Depth 12)
$lines = @('EightMax 5.6 Windows validation', ('Started ' + $report.started + ', ' + $report.seconds + ' s'), ('Physical Windows (no Wine or VM indicator): ' + $report.physicalWindows), ('Passed ' + $passedCount + ', failed ' + $failed.Count + ', skipped ' + $skipped.Count), '')
foreach ($c in $records) { $lines += ('[' + $c.status.ToUpper() + '] ' + $c.section + ' / ' + $c.name + ': ' + $(if ($c.detail -is [string]) { $c.detail } else { ($c.detail | ConvertTo-Json -Compress -Depth 6) })) }
Write-Text $txtPath ($lines -join "`r`n")
try { Remove-Item -LiteralPath $work -Recurse -Force } catch {}
Write-Host ''; Write-Host ('Passed ' + $passedCount + ', failed ' + $failed.Count + ', skipped ' + $skipped.Count + '. Report: ' + $jsonPath)
if ($failed.Count) { Write-Host 'FAILED checks:'; foreach ($c in $failed) { Write-Host ('  ' + $c.section + ' / ' + $c.name) }; exit 1 }
exit 0
