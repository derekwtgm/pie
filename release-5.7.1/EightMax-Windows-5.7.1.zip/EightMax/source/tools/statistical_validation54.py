"""Independent Gaussian random-effects data generator and SciPy oracle.
Runs the shipped C++ aggregation via study53_probe, measures coverage/false ranks.
No poker solver is used as its own reference. Python/NumPy generate known covariance.
"""
import argparse,json,subprocess,pathlib,platform
import numpy as np
from scipy.stats import t,norm
p=argparse.ArgumentParser();p.add_argument('probe');p.add_argument('out');p.add_argument('--trials',type=int,default=3000);a=p.parse_args()
def wilson(w,n):
 if not n:return None
 z=norm.ppf(.975);q=w/n;d=1+z*z/n;h=z*np.sqrt(q*(1-q)/n+z*z/(4*n*n))/d;c=(q+z*z/(2*n))/d;return {'successes':w,'trials':n,'rate':q,'wilson95':[c-h,c+h]}
checks=[]
quant=[{'df':df,'alpha':al}for df in [1,2,4,9,30,1000,100000]for al in [.05,.005,.00001]]
proc=subprocess.run([a.probe],input='\n'.join(map(json.dumps,quant))+'\n',text=True,capture_output=True,check=True)
for q,line in zip(quant,proc.stdout.splitlines()):
 got=json.loads(line)['critical'];want=t.ppf(1-q['alpha']/2,q['df']);checks.append({'df':q['df'],'alpha':q['alpha'],'actual':got,'reference':want,'passed':abs(got-want)<max(1e-8,abs(want)*1e-8)})
rng=np.random.default_rng(541811);results=[]
scenarios=[('independent_null',5,4,0,.2,.10,0,True,False),('identical_strategies_independent',5,4,0,.2,0,0,True,False),('shared_identical',5,4,0,.2,0,0,False,False),('shared_with_training_variation',5,4,0,.2,.1,.6,False,False),('correlated_actions_null',5,4,0,.2,.10,.9,True,False),('negative_correlated_actions',5,3,0,.2,.1,-.4,True,False),('positive_gap',12,4,1.0,.2,.1,.5,True,False),('exact_evaluation',5,4,0,0,.1,0,True,True),('two_replications',2,3,0,.2,.1,.3,True,False),('one_replication',1,3,0,.2,0,.3,True,False)]
scenarios += [('heavy_t3',5,4,0,.2,.1,.5,True,False),('skew_lognormal',10,4,0,.2,.1,.5,True,False),('rare_tail_mixture',5,4,0,.2,.1,.5,True,False)]
for name,n,k,gap,sigma,tau,rho,independent,exact in scenarios:
 cov=sigma*sigma*((1-rho)*np.eye(k)+rho*np.ones((k,k)));L=np.linalg.cholesky(cov+np.eye(k)*1e-30);mu=np.zeros(k);mu[0]=gap
 theta=mu+tau*rng.standard_normal((a.trials,n,k));noise=rng.standard_normal((a.trials,n if independent else 1,k))@L.T;y=theta+noise
 if name=='heavy_t3': noise=(rng.standard_t(3,(a.trials,n,k))/np.sqrt(3))@L.T;y=theta+noise
 if name=='skew_lognormal': noise=((np.exp(rng.standard_normal((a.trials,n,k)))-np.exp(.5))/np.sqrt(np.e*(np.e-1)))@L.T;y=theta+noise
 if name=='rare_tail_mixture': noise=(((rng.random((a.trials,n,k))<.01).astype(float)-.01)/np.sqrt(.0099))@L.T;y=theta+noise
 se=np.full((n,k),sigma);pair=np.sqrt(np.maximum(0,np.diag(cov)[:,None]+np.diag(cov)[None,:]-2*cov));pair=np.broadcast_to(pair,(n,k,k));family=k+k*(k-1)//2+1
 rows=[json.dumps({'values':v.tolist(),'errors':se.tolist(),'pairErrors':pair.tolist(),'family':family,'independent':independent,'samples':1000,'method':'exact'if exact else 'sampled','margin':.05})for v in y]
 r=subprocess.run([a.probe],input='\n'.join(rows)+'\n',capture_output=True,text=True,check=True)
 pop=cond=false=rank=avail=0
 for ti,line in enumerate(r.stdout.splitlines()):
  d=json.loads(line);pok=cok=True;available=True
  for p in d['pairwiseGaps']:
   i,j=int(p['actionA']),int(p['actionB']);z=p['difference'];pc=z['ci95'];cc=z['conditionalEvaluationCi95'];truth=mu[i]-mu[j];ct=theta[ti,:,i].mean()-theta[ti,:,j].mean()
   available&=pc is not None
   pok&=pc is not None and pc[0]-1e-12<=truth<=pc[1]+1e-12
   cok&=cc is not None and cc[0]-1e-12<=ct<=cc[1]+1e-12
  avail+=available;pop+=pok;cond+=cok
  if d['verdict']=='ranked':
   rank+=1;selected=int(d['gap']['higher']);false+=any(mu[selected]-mu[j]<=.05 for j in range(k)if j!=selected)
 results.append({'scenario':name,'replications':n,'actions':k,'mean':mu.tolist(),'evaluationCovariance':cov.tolist(),'trainingSD':tau,'evaluationStreams':'independent'if independent else 'shared','comparisonFamilySize':family,'populationIntervalAvailable':avail,'simultaneousPopulationCoverage':wilson(pop,avail),'simultaneousConditionalCoverage':wilson(cond,a.trials),'falseRanking':wilson(false,a.trials),'ranked':wilson(rank,a.trials)})
 print(name,results[-1]['simultaneousPopulationCoverage'],results[-1]['falseRanking'],flush=True)
report={'generator':'NumPy PCG64 seed 541811; Gaussian random effects plus standardized t3, lognormal and rare-event evaluation errors with known SEs; known covariance; SciPy Student-t reference','platform':platform.platform(),'trialsPerScenario':a.trials,'quantiles':checks,'scenarios':results,'limitations':'Coverage measured for declared Gaussian scenarios. No distribution-free guarantee for rare-tail or non-normal poker replications. Shared evaluation random-training intervals intentionally unavailable; conditional covariance-bound intervals measured instead.'}
report['calibrationWithinTestedTolerance']=all(c['passed']for c in checks) and all((not x['simultaneousPopulationCoverage'] or x['simultaneousPopulationCoverage']['wilson95'][1]>=.95)and x['simultaneousConditionalCoverage']['wilson95'][1]>=.95 and x['falseRanking']['wilson95'][0]<=.05 for x in results)
pathlib.Path(a.out).write_text(json.dumps(report,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+'\n');raise SystemExit(0)
