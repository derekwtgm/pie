"""Static checks of a PowerShell script written where PowerShell could not be run (5.7.1).

Not a parser. It finds the mistakes most likely in such a script, beyond the bracket and quote balance of
ps_balance.py, for the plain subset of PowerShell the EightMax validation scripts use:

  1  balance of (), {}, [] and of strings and here-strings (ps_balance.py's scan, repeated here to obtain the code
     with strings and comments blanked);
  2  syntax that Windows PowerShell 5.1 does not have: the ternary operator, ??, ??=, ?., && and || between
     commands, -Parallel, "clean" blocks, the pipeline chain operators;
  3  a function called in command position (Verb-Noun or a bare capitalised name defined by the script) that the
     script does not define and that is not one of the built-in cmdlets it is allowed to use;
  4  a variable that is read but never assigned anywhere in the script (a misspelt name), automatic and
     environment variables excepted.

usage: python3 -I ps_lint571.py file.ps1 [...]     exit status 1 on any finding; findings are printed one per line.
       python3 -I ps_lint571.py --json file.ps1     the findings as JSON
"""
import json, re, sys

AUTOMATIC = {'_', 'args', 'error', 'false', 'true', 'null', 'input', 'this', 'home', 'host', 'pid', 'pwd', 'matches', 'lastexitcode',
             'psscriptroot', 'pscommandpath', 'psversiontable', 'psitem', 'myinvocation', 'erroractionpreference', 'executioncontext',
             'psboundparameters', 'foreach', 'switch', 'event', 'sender', 'ofs', 'verbosepreference', 'warningpreference', 'progresspreference', 'stacktrace'}
BUILTIN = {'add-member', 'add-type', 'compare-object', 'convertfrom-json', 'convertto-json', 'copy-item', 'export-csv', 'foreach-object', 'format-list', 'format-table',
           'get-childitem', 'get-ciminstance', 'get-command', 'get-content', 'get-date', 'get-filehash', 'get-item', 'get-itemproperty', 'get-location', 'get-member', 'get-process',
           'get-random', 'get-variable', 'group-object', 'import-module', 'invoke-expression', 'invoke-webrequest', 'join-path', 'measure-object', 'move-item', 'new-item', 'new-object',
           'out-file', 'out-host', 'out-null', 'out-string', 'remove-item', 'remove-typedata', 'resolve-path', 'select-object', 'select-string', 'set-content', 'set-item',
           'set-location', 'set-strictmode', 'sort-object', 'split-path', 'start-process', 'start-sleep', 'stop-process', 'test-path', 'wait-process', 'where-object', 'write-error',
           'write-host', 'write-output', 'write-verbose', 'write-warning', 'get-wmiobject', 'push-location', 'pop-location', 'add-content', 'clear-content', 'rename-item', 'tee-object'}


def blank(path):
    """The script with comments and string contents replaced by spaces (line structure kept), or an error text."""
    s = open(path, encoding='utf-8-sig').read(); n = len(s); out = list(s); i = 0; line = 1; stack = []
    pairs = {')': '(', '}': '{', ']': '['}

    def wipe(a, b):
        for k in range(a, b):
            if out[k] != '\n': out[k] = ' '

    while i < n:
        c = s[i]
        if c == '\n': line += 1; i += 1; continue
        if s.startswith('<#', i):
            j = s.find('#>', i + 2)
            if j < 0: return None, f'{path}:{line}: unterminated block comment'
            wipe(i, j + 2); line += s.count('\n', i, j); i = j + 2; continue
        if c == '#':
            j = s.find('\n', i); j = n if j < 0 else j; wipe(i, j); i = j; continue
        if (s.startswith("@'", i) or s.startswith('@"', i)) and s[i + 2:i + 3] in ('\n', '\r'):
            end = "\n'@" if s[i + 1] == "'" else '\n"@'; j = s.find(end, i)
            if j < 0: return None, f'{path}:{line}: unterminated here-string'
            wipe(i + 2, j + 1); line += s.count('\n', i, j + 1); i = j + 3; continue
        if c == "'":
            j = i + 1
            while True:
                if j >= n: return None, f'{path}:{line}: unterminated single-quoted string'
                if s[j] == "'":
                    if j + 1 < n and s[j + 1] == "'": j += 2; continue
                    break
                j += 1
            wipe(i + 1, j); line += s.count('\n', i, j); i = j + 1; continue
        if c == '"':
            j = i + 1; depth = 0
            while True:
                if j >= n: return None, f'{path}:{line}: unterminated double-quoted string'
                if s[j] == '`': j += 2; continue
                if s.startswith('$(', j): depth += 1; j += 2; continue
                if depth and s[j] == ')': depth -= 1; j += 1; continue
                if s[j] == '"' and not depth:
                    if j + 1 < n and s[j + 1] == '"': j += 2; continue
                    break
                j += 1
            wipe(i + 1, j); line += s.count('\n', i, j); i = j + 1; continue
        if c == '`': i += 2; continue
        if c in '({[': stack.append((c, line))
        elif c in ')}]':
            if not stack or stack[-1][0] != pairs[c]:
                return None, f"{path}:{line}: unexpected '{c}'" + (f" (open '{stack[-1][0]}' from line {stack[-1][1]})" if stack else '')
            stack.pop()
        i += 1
    if stack: return None, f"{path}: unclosed '{stack[-1][0]}' opened at line {stack[-1][1]}"
    return ''.join(out), None


def lint(path):
    code, error = blank(path)
    if error: return [error]
    found = []; lines = code.split('\n')

    def add(number, text): found.append(f'{path}:{number}: {text}')

    # 2 syntax newer than Windows PowerShell 5.1
    for k, l in enumerate(lines, 1):
        if re.search(r'\?\?=?', l): add(k, 'null-coalescing operator (PowerShell 7)')
        if re.search(r'\?\.|\?\[', l): add(k, 'null-conditional member access (PowerShell 7)')
        if re.search(r'&&|\|\|', l): add(k, 'pipeline chain operator && or || (PowerShell 7)')
        if re.search(r'-Parallel\b', l, re.I): add(k, 'ForEach-Object -Parallel (PowerShell 7)')
        if re.search(r'\)\s*\?\s*[^:]+\s:\s', l) and not re.search(r'Where-Object|\?\s*\{', l): add(k, 'ternary operator (PowerShell 7)')
        if re.search(r'^\s*clean\s*\{', l, re.I): add(k, 'clean block (PowerShell 7.3)')

    # 3 functions
    defined = {m.group(1).lower() for m in re.finditer(r'\bfunction\s+([A-Za-z][\w-]*)', code)}
    for k, l in enumerate(lines, 1):
        # command position: at the start of a statement, after '{', ';', '|', '(' or '=' (an assignment from a command)
        for m in re.finditer(r'(?:^|[{;|(=])\s*(?:\$\w+\s*=\s*)?([A-Z][a-z]+-[A-Z][A-Za-z]+)\b', l):
            name = m.group(1).lower()
            if name not in defined and name not in BUILTIN: add(k, f'command {m.group(1)} is neither defined by the script nor an allowed built-in cmdlet')

    # 4 variables read but never assigned
    assigned = set(AUTOMATIC)
    for m in re.finditer(r'\$(?:script:|global:)?(\w+)\s*(?:=(?!=)|\+=|-=|\*=|/=|\+\+|--)', code): assigned.add(m.group(1).lower())
    for m in re.finditer(r'\bforeach\s*\(\s*\$(\w+)\s+in\b', code, re.I): assigned.add(m.group(1).lower())
    for m in re.finditer(r'\[ref\]\s*\$(\w+)', code, re.I): assigned.add(m.group(1).lower())
    # parameters: param(...) blocks and function Name(...) lists
    for m in re.finditer(r'\bparam\s*\(', code, re.I):
        depth = 1; j = m.end()
        while j < len(code) and depth: depth += code[j] == '('; depth -= code[j] == ')'; j += 1
        for v in re.finditer(r'\$(\w+)', code[m.end():j]): assigned.add(v.group(1).lower())
    for m in re.finditer(r'\bfunction\s+[A-Za-z][\w-]*\s*\(', code):
        depth = 1; j = m.end()
        while j < len(code) and depth: depth += code[j] == '('; depth -= code[j] == ')'; j += 1
        for v in re.finditer(r'\$(\w+)', code[m.end():j]): assigned.add(v.group(1).lower())
    for k, l in enumerate(lines, 1):
        for m in re.finditer(r'\$(?:script:|global:)?(\w+)', l):
            name = m.group(1).lower()
            if m.group(0).lower().startswith('$env') and l[m.end():m.end() + 1] == ':': continue
            if name not in assigned: add(k, f'variable ${m.group(1)} is read but never assigned in the script')
    return found


if __name__ == '__main__':
    args = sys.argv[1:]; as_json = '--json' in args; files = [a for a in args if a != '--json']
    if not files: print(__doc__); sys.exit(2)
    result = {f: lint(f) for f in files}; bad = sum(len(v) for v in result.values())
    if as_json: print(json.dumps({'files': result, 'findings': bad}))
    else:
        for f, v in result.items():
            for line in v: print(line)
            if not v: print(f'ok  {f}')
    sys.exit(1 if bad else 0)
