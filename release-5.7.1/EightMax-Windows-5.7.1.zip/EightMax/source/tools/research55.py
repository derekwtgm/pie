#!/usr/bin/env python3
"""EightMax 5.5 fixed-plan convergence comparison of ONE candidate: river opponent enumeration.
Usage: research55.py BASELINE_5.4_CLI CURRENT_CLI OUTPUT_DIRECTORY [--plan main|icm]

The plan (games, seeds, arms, budgets, comparison family, tests and the promotion rule) is written to plan.json before
any measurement. Every arm of a game/seed is trained in rotated order; each checkpoint is evaluated by the CURRENT
binary's exact all-seat best response in a separate process. Nothing is stopped or selected on results; every row is
kept in raw.jsonl. Research only: no default is changed by this script.

Tests per contrast (candidate minus baseline NashConv, paired by training seed):
  - exact two-sided sign test (distribution-free for the median paired difference), Bonferroni over the family;
  - paired Student-t interval, Bonferroni over the family (model-based; reported, never sufficient alone).
Verdict 'better'/'worse' requires the sign test to reject AND the t interval to exclude zero on the same side.
"""
import sys, pathlib, json, subprocess, time, resource, os, hashlib, math, statistics, platform, re, shutil, argparse
from scipy import stats
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('--plan', default='main'); ap.add_argument('--seeds', type=int, default=None)
A = ap.parse_args(); A.seeds = A.seeds or (20 if A.plan == 'main' else 10); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); out = pathlib.Path(A.out).resolve(); out.mkdir(parents=True, exist_ok=True); root = pathlib.Path(__file__).resolve().parent
if (out / 'raw.jsonl').exists(): raise SystemExit('Use a fresh output directory; old results must not be mixed.')
if A.plan == 'main':
    arms = {'baseline54': {}, 'default55': {}, 'river-enumeration': {'opponentEnumeration': 'river'}}
    games = ['hu-river', 'hu-turn', 'river3-chip', 'turn4']; deals = [4000, 20000, 100000]; seconds = [.1, .5]
else:   # the ICM comparisons 5.4 declared and could not finish (same arms, budgets and seeds as research54.py)
    arms = {'baseline53': {}, 'default54': {}, 'terminal-baseline': {'terminalBaseline': True}, 'dcfr': {'weighting': 'dcfr'}, 'dcfr-average3': {'weighting': 'dcfr', 'dcfrGamma': 3}, 'cfr-plus': {'regretMatching': 'plus'}, 'uniform': {'weighting': 'uniform'}}
    games = ['bubble4']; deals = [4000, 20000, 100000]; seconds = [.1]
base = list(arms)[0]
plan = {'plan': A.plan, 'games': games, 'seeds': list(range(901, 901 + A.seeds)), 'arms': arms, 'deals': deals, 'trainingSeconds': seconds, 'threads': 1, 'evaluationThreads': 1, 'memoryMiB': 128, 'evaluatorCacheMiB': 1024,
        'evaluation': 'exact all-seat best response (NashConv inside the abstraction), CPU, current binary, separate process from training',
        'baseline': base + ' = the unchanged 5.4 Linux binary with its default trainer' if A.plan == 'main' else base + ' = the baseline binary given on the command line',
        # the ICM plan completes the 5.4 family: its ORIGINAL size (3 games x 6 arms x 4 budgets = 72) is kept for the multiplicity adjustment
        'family': len(games) * (len(arms) - 1) * (len(deals) + len(seconds)) if A.plan == 'main' else 72,
        'tests': 'exact two-sided sign test and paired Student-t interval, both Bonferroni-adjusted over the whole family; a verdict needs both' if A.plan == 'main' else 'as declared by 5.4: two-sided paired Student-t interval, Bonferroni over the original 72 contrasts, decides the verdict; the exact sign test is reported beside it and decides nothing',
        'promotionRule': 'The candidate may replace the default trainer only if, in EVERY game of this plan, it is "better" at the largest equal-TIME budget and at the largest equal-DEAL budget, and "worse" in no contrast. Otherwise the default is unchanged and the candidate stays an opt-in experimental setting.' if A.plan == 'main' else 'none (completion of the 5.4 family; no promotion is considered)',
        'limitations': 'Small exact games only. NashConv is exact inside each abstraction; with more than two players it is not exploitability. Equal-time budgets are wall-clock on a shared machine: timing noise enters those contrasts.',
        'environment': platform.platform(), 'baselineSha256': hashlib.sha256(pathlib.Path(old).read_bytes()).hexdigest(), 'currentSha256': hashlib.sha256(pathlib.Path(new).read_bytes()).hexdigest(), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(out / 'plan.json').write_text(json.dumps(plan, indent=1))
peak = out / 'peak_rss'; subprocess.run(['gcc', '-O2', str(root / 'peak_rss.c'), '-o', str(peak)], check=True)
rows = []
def call(cli, args, env=None):
    t = time.perf_counter(); p = subprocess.run([str(peak), cli, *map(str, args)], capture_output=True, text=True, timeout=3600, env=env)
    if p.returncode: raise RuntimeError(p.stderr[-800:])
    m = re.search(r'peakRssKiB=(\d+) cpuSeconds=([\d.]+)', p.stderr); return json.loads(p.stdout), time.perf_counter() - t, float(m[2]) if m else None, int(m[1]) / 1024 if m else None
for game in games:
    for seed in plan['seeds']:
        order = list(arms); order = order[seed % len(order):] + order[:seed % len(order)]
        for arm in order:
            d = out / 'checkpoints' / game / str(seed) / arm; d.mkdir(parents=True, exist_ok=True); sp = d / 'spec.json'; st = d / 'state'; q = d / 'query.json'
            subprocess.run(['node', str(root / 'games48.js'), 'spec', game, str(sp), str(seed), json.dumps({**arms[arm], 'batchDeals': 1, 'device': 'cpu'})], check=True, capture_output=True)
            # evaluator cache: 1,024 MiB. The value of an exact evaluation does not depend on it (verified); with 128 MiB the ICM game's
            # showdown tables are rebuilt repeatedly (44 s instead of 1.2 s per checkpoint). Training memory stays at 128 MiB.
            q.write_text(json.dumps({'method': 'exact', 'device': 'cpu', 'threads': 1, 'timeLimitMs': 1800000, 'maxVisits': 2000000000, 'memoryMiB': 1024}))
            cli = old if arm == base else new; done = 0; train = 0
            for kind, budgets in [('deals', deals), ('time', seconds)]:
                for budget in budgets:
                    if kind == 'time': args = [sp, 10000000, 1, str(st) + '.next', 128]; env = {**os.environ, 'EM_TRAIN_CANCEL_AFTER_MS': str(round(budget * 1000))}; train = 0
                    else: args = [sp, budget - done, 1, str(st) + '.next', 128] + ([st] if done else []); env = None
                    info, sec, cpu, mem = call(cli, args, env); os.replace(str(st) + '.next', st); train += info['wallSeconds']
                    gain, evsec, evcpu, evmem = call(new, ['--gain', sp, st, q, 128])
                    if kind == 'deals': done = budget
                    row = {'game': game, 'seed': seed, 'arm': arm, 'kind': kind, 'budget': budget, 'deals': info['trainingDeals'], 'trainingSeconds': train, 'trainingProcessSeconds': sec, 'trainingCpuSeconds': cpu, 'trainingPeakRssMiB': mem, 'rows': info.get('rows'), 'tableMiB': info.get('tableMiB'),
                           'evaluationSeconds': evsec, 'evaluationCpuSeconds': evcpu, 'evaluationPeakRssMiB': evmem, 'nashConv': gain['nashConv'], 'exploitability': gain.get('exploitability'), 'largestUnilateralGain': gain['largestUnilateralGain'], 'seatGains': [s['gain'] for s in gain['seats']],
                           'checkpointSha256': hashlib.sha256(st.read_bytes()).hexdigest(), 'memoryStopped': info.get('limitReached', False), 'trainer': info.get('trainer')}
                    rows.append(row)
                    with (out / 'raw.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
            st.unlink(missing_ok=True)
        print(game, seed, flush=True)
family = plan['family']; comp = []
for game in games:
    for arm in list(arms)[1:]:
        for kind, budgets in [('deals', deals), ('time', seconds)]:
            for budget in budgets:
                B = {r['seed']: r for r in rows if (r['game'], r['arm'], r['kind'], r['budget']) == (game, base, kind, budget)}; C = {r['seed']: r for r in rows if (r['game'], r['arm'], r['kind'], r['budget']) == (game, arm, kind, budget)}
                dif = [C[s]['nashConv'] - B[s]['nashConv'] for s in plan['seeds']]; n = len(dif); mean = statistics.mean(dif); sd = statistics.stdev(dif)
                half = float(stats.t.ppf(1 - .05 / (2 * family), n - 1)) * sd / math.sqrt(n)
                neg = sum(x < 0 for x in dif); pos = sum(x > 0 for x in dif); nz = neg + pos
                p = float(stats.binomtest(min(neg, pos), nz, .5).pvalue) if nz else 1.0; padj = min(1.0, p * family)
                if A.plan == 'main': verdict = 'identical' if not nz else 'better' if padj < .05 and neg > pos and mean + half < 0 else 'worse' if padj < .05 and pos > neg and mean - half > 0 else 'unresolved'
                else: verdict = 'better' if mean + half < 0 else 'worse' if mean - half > 0 else 'unresolved'   # the 5.4 rule
                comp.append({'game': game, 'arm': arm, 'kind': kind, 'budget': budget, 'n': n, 'baselineMean': statistics.mean(r['nashConv'] for r in B.values()), 'candidateMean': statistics.mean(r['nashConv'] for r in C.values()), 'difference': mean,
                             'simultaneousTInterval95': [mean - half, mean + half], 'seedsCandidateLower': neg, 'seedsCandidateHigher': pos, 'signTestP': p, 'signTestPBonferroni': padj, 'familySize': family, 'verdict': verdict,
                             'baselineMeanDeals': statistics.mean(r['deals'] for r in B.values()), 'candidateMeanDeals': statistics.mean(r['deals'] for r in C.values()), 'baselineMeanTrainingSeconds': statistics.mean(r['trainingSeconds'] for r in B.values()), 'candidateMeanTrainingSeconds': statistics.mean(r['trainingSeconds'] for r in C.values()),
                             'baselineMeanRows': statistics.mean(r['rows'] or 0 for r in B.values()), 'candidateMeanRows': statistics.mean(r['rows'] or 0 for r in C.values())})
summary = {'plan': plan, 'comparisons': comp, 'rows': len(rows)}
if A.plan == 'main':
    cand = [c for c in comp if c['arm'] == 'river-enumeration']; ok = all(any(c['verdict'] == 'better' for c in cand if c['game'] == g and c['kind'] == 'time' and c['budget'] == max(seconds)) and any(c['verdict'] == 'better' for c in cand if c['game'] == g and c['kind'] == 'deals' and c['budget'] == max(deals)) for g in games) and not any(c['verdict'] == 'worse' for c in cand)
    ident = all(c['verdict'] == 'identical' for c in comp if c['arm'] == 'default55' and c['kind'] == 'deals')
    summary['promotion'] = {'ruleMet': ok, 'default55IdenticalToBaselineAtEqualDeals': ident, 'decision': 'promote' if ok else 'default unchanged; candidate remains opt-in experimental'}
(out / 'summary.json').write_text(json.dumps(summary, indent=1)); shutil.rmtree(out / 'checkpoints', ignore_errors=True); peak.unlink()
print(json.dumps(summary.get('promotion', {})))
