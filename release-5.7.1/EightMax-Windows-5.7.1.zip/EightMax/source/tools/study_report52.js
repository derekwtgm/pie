// EightMax 5.2: readable study results. Reads "EightMax study result" documents (mwcli --study or the Study tab's
// Export JSON) and writes one Markdown report: a row per decision, then per study the budgets, the sensitivity
// comparisons and the limits reached. Every number is taken from the documents (EM.study, the interface's functions).
//   node tools/study_report52.js <out.md> <result.json> [result.json ...] [--timing=idle-timing.json]
'use strict';
const fs = require('node:fs'), path = require('node:path');
const E = require('./loadlib'); require('../web/lib_study_ui');
const S = E.study, args = process.argv.slice(2), files = args.filter(a => !a.startsWith('--')), out = files.shift();
const timingArg = args.find(a => a.startsWith('--timing=')), timing = timingArg ? JSON.parse(fs.readFileSync(timingArg.slice(9), 'utf8')) : null;
if (!out || !files.length) { console.error('usage: node tools/study_report52.js <out.md> <result.json> [...] [--timing=file]'); process.exit(2); }
const docs = files.map(f => S.validateResult(JSON.parse(fs.readFileSync(f, 'utf8'))));
const L = [], p = s => L.push(s), ci = c => S.ci(c), d = S.deals;
const idle = (id, deals) => { const t = timing && timing.studies && timing.studies[id]; const r = t && t.find(x => x.deals === deals); return r ? r.trainingSeconds.toFixed(1) + ' s' : null; };
p('# EightMax 5.2 study results'); p('');
p('Generated from ' + docs.length + ' result documents (raw per-seed data: the JSON files next to this report). Build ' + [...new Set(docs.map(x => x.build))].join(', ') + '.'); p('');
p('How to read it. **Frequency** is the hero hand\'s average-strategy frequency (mean over independently seeded trainings; "sd" is the spread across those trainings). **EV gap** is EV(higher) − EV(lower) of the two actions with the highest mean EV; its 95% interval is over trained strategies and so contains both the spread between trainings and the evaluation sampling error, which is listed separately. **Quality** is exact (sum of every seat\'s exact best-response gain inside the fixture\'s abstraction) or sampled (one-shot deviations, a lower bound that cannot certify an equilibrium). Verdicts: *ranked* (the whole interval lies above the declared EV tolerance), *nearTie* (the whole interval lies inside ± tolerance: a mix is consistent), *smallEdge* (interval above zero but not above the tolerance), *unresolved*.'); p('');
p('## One row per decision (baseline variant)'); p('');
p('| Study | Hero and decision | Recommended action or mix | EV gap (95% interval over trainings) | Evaluation se / between-training sd | Quality (kind) | Budget used | Training time per seed' + (timing ? ' (idle machine)' : '') + ' | Peak RAM | Tolerance |'); p('|---|---|---|---|---|---|---|---|---|---|');
for (const doc of docs) { const v = doc.variants[0], h = S.headline(v), b = S.headlineBudget(v); if (!b || !b.actions) { p('| ' + doc.fixture.id + ' | – | no completed measurement | | | | | | | |'); continue; }
  const g = b.gap || {}, q = b.quality, lastQ = v.budgets.filter(x => x.quality).at(-1);
  p('| **' + doc.fixture.id + '** | ' + (v.decision.seatName || '') + ' ' + v.decision.hand + (v.decision.history.length ? ' after ' + v.decision.history.map(x => x.seatName + ' ' + x.action).join(', ') : ', first to act') + ' | **' + h.lead + '**: ' + h.mix + ' | ' + (g.higher ? g.higher + ' − ' + g.lower + ' = ' + S.signed(g.mean) + ' ' + v.utility.unit + ' ' + ci(g.ci95) : '–') + ' | ' + S.fmt(g.evaluationStdErrOfMean) + ' / ' + S.fmt(g.betweenStrategySd) + ' | ' + (q ? S.fmt(q.mean, 4) : lastQ ? S.fmt(lastQ.quality.mean, 4) + ' at ' + d(lastQ.budgetDeals) : 'n/a') + ' (' + v.qualityMetric.kind + ') | ' + d(h.budget) + ' deals | ' + (idle(doc.fixture.id, h.budget) || S.fmt(b.trainingSecondsMean, 1) + ' s') + ' | ' + S.fmt(b.processPeakRssMiB, 0) + ' MiB | ' + (h.met ? 'met at ' + d(v.firstBudgetMeetingTolerance) : '**not reached** (last ' + d(v.lastMeasuredBudget) + ')') + ' |'); }
p('');
p('## What changed when one input changed'); p('');
p('| Study | Variant (one change) | Most frequent action: baseline → variant | Seeds where it changed | Largest mean frequency change | EV gap in the variant | Added action | Note |'); p('|---|---|---|---|---|---|---|---|');
for (const doc of docs) for (const c of ((doc.sensitivity && doc.sensitivity.comparisons) || [])) { if (c.budgetDeals == null) { p('| ' + doc.fixture.id + ' | ' + c.variant + ' | ' + (c.note || '') + ' | | | | | |'); continue; }
  const g = c.variantGap, add = (c.addedActions || []).map(a => a.label + ': ' + S.pct(a.frequency) + (a.advantageOverBestOriginal ? ', EV vs ' + a.advantageOverBestOriginal.bestOriginalAction + ' ' + S.signed(a.advantageOverBestOriginal.mean) + ' ' + a.advantageOverBestOriginal.unit + ' ' + ci(a.advantageOverBestOriginal.ci95) : '') + (a.isLeaderByFrequency ? ' (**now most frequent**)' : '')).join('; ') || '–';
  p('| ' + doc.fixture.id + ' | **' + c.variant + '**: ' + c.change + ' | ' + c.baselineLeaderByFrequency + ' → ' + c.variantLeaderByFrequency + ' | ' + c.seedsWhereLeaderByFrequencyChanged + ' of ' + c.pairedSeeds + ' | ' + S.pct(c.largestMeanFrequencyChange) + ' | ' + (g ? g.higher + ' − ' + g.lower + ' = ' + S.signed(g.mean) + ' ' + g.unit + ' ' + ci(g.ci95) + ' (' + g.verdict + ')' : '–') + ' | ' + add + ' | ' + [c.shiftWhileNearlyTied ? '**frequencies shift while the leading actions stay nearly tied**' : '', c.sameUtility ? '' : 'different utility (' + c.baselineUnit + ' vs ' + c.variantUnit + '): EVs not compared', c.baselinePairInVariant && c.baselinePairInVariant.orderReversedInVariant ? 'the baseline\'s EV order of its two leading actions is reversed' : ''].filter(Boolean).join('; ') + ' |'); }
p('');
for (const doc of docs) {
  p('## ' + doc.fixture.id + ' — ' + doc.fixture.title); p('');
  const r = doc.run, de = doc.fixture.description || {};
  p('- ' + (de.actionHistory || '')); p('- Seeds ' + r.seeds.join(', ') + '; ' + r.threadsRequested + ' worker thread(s) requested on ' + r.logicalProcessors + ' logical processors; total ' + S.fmt(r.elapsedSeconds, 0) + ' s; process peak RAM ' + S.fmt(r.processPeakRssMiB, 0) + ' MiB.' + (r.stoppedByTimeLimit ? ' **Stopped by the time limit.**' : '') + (r.firstEvaluationError ? ' **Evaluation error: ' + r.firstEvaluationError + '**' : ''));
  p('- Declared tolerance: EV gap interval half-width ≤ ' + doc.tolerance.evGap + ', frequency sd ≤ ' + doc.tolerance.frequency + (doc.tolerance.quality != null ? ', quality ≤ ' + doc.tolerance.quality : '') + ', stable against the previous budget.'); p('');
  for (const v of doc.variants) {
    p('### ' + doc.fixture.id + ' / ' + v.name + (v.change ? ' — ' + v.change : '')); p('');
    p('EVs in **' + v.utility.unit + '** (' + v.utility.model + '). Quality metric: ' + v.qualityMetric.kind + ' — ' + v.qualityMetric.name + '.'); p('');
    p('| Budget (deals) | Seeds | ' + v.decision.actions.map(a => a.label + ' freq (sd)').join(' | ') + ' | ' + v.decision.actions.map(a => a.label + ' EV').join(' | ') + ' | EV gap | 95% interval | eval se | between sd | Quality | Untrained continuation (max) | Train s | EV s | Quality s | Verdict | Meets tolerance |');
    p('|' + '---|'.repeat(11 + 2 * v.decision.actions.length + 2));
    for (const b of v.budgets) { if (!b.actions) { p('| ' + d(b.budgetDeals) + ' | 0 | not measured |'); continue; } const g = b.gap || {};
      p('| ' + d(b.budgetDeals) + (b.seedsStoppedByMemoryLimit ? ' (**' + b.seedsStoppedByMemoryLimit + ' seed(s) stopped at the table budget, at most ' + d(b.dealsReachedMax) + ' deals**)' : '') + ' | ' + b.seeds + ' | ' + b.actions.map(a => S.pct(a.frequency.mean) + ' (' + S.pct(a.frequency.sdAcrossSeeds) + ')').join(' | ') + ' | ' + b.actions.map(a => S.signed(a.ev.mean)).join(' | ') + ' | ' + (g.higher ? g.higher + ' − ' + g.lower + ' = ' + S.signed(g.mean) : '–') + ' | ' + ci(g.ci95) + ' | ' + S.fmt(g.evaluationStdErrOfMean) + ' | ' + S.fmt(g.betweenStrategySd) + ' | ' + (b.quality ? S.fmt(b.quality.mean, 4) + (v.qualityMetric.kind === 'sampled' ? ' ± ' + S.fmt(b.quality.evaluationStdErrOfMean, 4) + ' se' : '') : 'not evaluated') + ' | ' + S.pct(Math.max(...b.actions.map(a => a.untrainedContinuationShare || 0))) + ' | ' + S.fmt(b.trainingSecondsMean, 2) + ' | ' + S.fmt(b.evSecondsMean, 2) + ' | ' + S.fmt(b.qualitySecondsMean, 2) + ' | ' + b.verdict + ' | ' + (b.meetsTolerance ? 'yes' : 'no') + ' |'); }
    p(''); p('**' + v.toleranceSummary + '.** ' + S.headline(v).text); p('');
  }
}
if (timing) { p('## Training time on an idle machine'); p(''); p(timing.note); p(''); p('| Study | Deals | Training seconds | Worker threads | Peak RSS (MiB) |'); p('|---|---|---|---|---|'); for (const [id, rows] of Object.entries(timing.studies)) for (const r of rows) p('| ' + id + ' | ' + d(r.deals) + ' | ' + r.trainingSeconds.toFixed(2) + ' | ' + r.threads + ' | ' + Math.round(r.peakRssMiB) + ' |'); p(''); }
fs.writeFileSync(out, L.join('\n') + '\n'); console.log('wrote', out, L.length, 'lines');
