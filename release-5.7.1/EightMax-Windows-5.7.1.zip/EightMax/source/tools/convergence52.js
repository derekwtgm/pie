// EightMax 5.2: does the 5.1 six-player gain survive longer solves? (Requirement 2)
//
// Arms are trainer configurations: the default (batchDeals 1, one worker by construction), fixed
// parallel64 and the warm-4-256 batch schedule. For each seed every arm trains the same game from scratch
// through a doubling grid of sampled-deal checkpoints until its cumulative TRAINING time passes the longest
// budget of the game (or a stop condition is met, which is recorded, never hidden). After the checkpoints
// that can bracket a budget the same independent evaluator measures the strategy:
//   exact    mwcli --gain method=exact: every seat's exact unilateral best-response gain inside the
//            abstraction; metric = their sum ("NashConv"; NOT exploitability in multiway games)
//   sampled  mwcli --gain method=sampled: one-shot deviation at one decision node per seat, a LOWER BOUND
//            on each seat's gain with a standard error; a low value cannot certify an equilibrium
// Training time (engine wallSeconds of mw_train) and evaluation time are recorded separately.
// Comparisons with the default arm, paired by seed:
//   equal wall time   metric interpolated (log-log for exact, linear in log time for sampled) inside each
//                     arm's OBSERVED time range at each predefined budget; a seed whose curves do not both
//                     span the budget is EXCLUDED for that budget and counted (never clamped)
//   equal deals       at checkpoint deal counts both arms reached (results do not depend on worker count,
//                     so this isolates the schedule from parallelism)
// Exact metric: paired mean of ln ratios, t interval; sampled metric: paired mean difference in utility
// units. Holm over the primary comparisons of the plan.
//
// usage: node tools/convergence52.js <mwcli> <out.json> --plan=plan.json [--only=game,game] [--seeds=a-b]
//        [--timing-only --metric-from=prior.json [--verify-seeds=N]] [--cpus=0-2] [--resume]
'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), { execFileSync, spawnSync } = require('node:child_process');
const G = require('./games48');
const E = require('./loadlib');
const args = process.argv.slice(2), [cliArg, out] = args.filter(a => !a.startsWith('--'));
const opt = (k, d) => { const a = args.find(x => x === '--' + k || x.startsWith('--' + k + '=')); return a ? (a.includes('=') ? a.slice(k.length + 3) : true) : d; };
if (!cliArg || !out || !opt('plan')) { console.error('usage: node tools/convergence52.js <mwcli> <out.json> --plan=plan.json [--only=..] [--seeds=a-b] [--timing-only --metric-from=prior.json] [--cpus=0-2] [--resume]'); process.exit(2); }
const cli = path.resolve(cliArg), planFile = path.resolve(opt('plan')), plan = JSON.parse(fs.readFileSync(planFile, 'utf8'));
const cpus = opt('cpus', plan.cpus || ''), pin = cpus ? ['taskset', '-c', cpus] : [];
const armOptions = name => {
  const a = plan.arms[name]; if (!a) throw new Error('unknown arm ' + name);
  return a;
};
const dealsBefore = (o, t) => { const B = o.batchDeals || 1; if (!o.batchSchedule) return t * B; let d = 0, b = o.batchSchedule.start, done = 0; while (done < t) { const cur = Math.min(b, B), span = b >= B ? t - done : Math.min(t - done, o.batchSchedule.doubleEvery); d += span * cur; done += span; b *= 2; } return d; };
const updatesFor = (o, deals) => { let lo = 0, hi = deals; while (lo < hi) { const mid = Math.floor((lo + hi) / 2); if (dealsBefore(o, mid) >= deals) hi = mid; else lo = mid + 1; } return lo; };
const fixtureCache = {};
function gameSpec(game, seed, specOptions) {
  if (game.source === 'games48') return G.spec(game.key, seed, specOptions);
  const file = path.resolve(path.dirname(planFile), game.file);
  const fx = fixtureCache[file] ||= JSON.parse(fs.readFileSync(file, 'utf8'));
  return E.MultiwayGame({ ...fx.variants[0].game, ...specOptions, privateSeed: seed }).nativeSpec();
}
const run = (a, o = {}) => { const r = spawnSync(pin.length ? pin[0] : cli, pin.length ? [...pin.slice(1), cli, ...a.map(String)] : a.map(String), { encoding: 'utf8', maxBuffer: 512 << 20, ...o }); return r; };
const seedList = s => typeof s === 'string' ? (() => { const [a, b] = s.split('-').map(Number); return Array.from({ length: b - a + 1 }, (_, i) => a + i); })() : s;
const only = opt('only') ? opt('only').split(',') : null, timingOnly = !!opt('timing-only');
const prior = opt('metric-from') ? JSON.parse(fs.readFileSync(opt('metric-from'), 'utf8')).raw : null, verifySeeds = +opt('verify-seeds', 0);
const games = plan.games.filter(g => !only || only.includes(g.key));
const rawFile = out + '.raw.jsonl';
// ---------------- measurement ----------------
function measure() {
  const done = new Set();
  if (opt('resume') && fs.existsSync(rawFile)) for (const l of fs.readFileSync(rawFile, 'utf8').split('\n').filter(Boolean)) { const r = JSON.parse(l); done.add(r.game + '|' + r.arm + '|' + r.seed); }
  else fs.writeFileSync(rawFile, '');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'em52-conv-'));
  for (const game of games) {
    const seeds = opt('seeds') ? seedList(opt('seeds')) : seedList(game.seeds), arms = game.arms || Object.keys(plan.arms);
    const maxBudget = Math.max(...game.budgets), minBudget = Math.min(...game.budgets);
    for (const seed of seeds) {
      const order = arms.map((v, i) => arms[(i + seed) % arms.length]);   // rotate the order per seed: machine drift affects every arm alike
      for (const arm of order) {
        if (done.has(game.key + '|' + arm + '|' + seed)) continue;
        const o = armOptions(arm), { threads, batchSchedule, ...specOptions } = o, sp = gameSpec(game, seed, specOptions);
        if (batchSchedule) sp.batchSchedule = batchSchedule;
        const spec = path.join(dir, 'spec.json'), st = path.join(dir, 'state'), q = path.join(dir, 'q.json');
        fs.writeFileSync(spec, JSON.stringify(sp));
        const ev = game.eval || { method: 'exact' };
        fs.writeFileSync(q, JSON.stringify(ev.method === 'exact' ? { method: 'exact', threads: plan.evalThreads, timeLimitMs: 3600000, maxVisits: 2000000000 }
          : { method: 'sampled', threads: plan.evalThreads, samples: ev.samples, selectionSamples: ev.selectionSamples, seed: ev.seed ?? 1, timeLimitMs: 3600000 }));
        let updates = 0, wall = 0, peak = 0, stop = null; const rows = [], memMiB = game.tableBudgetMiB || 512;
        const evaluate = row => {
          const t0 = process.hrtime.bigint(), r = run(['--gain', spec, st, q, game.evalMemoryMiB || 4096]);
          row.evalSeconds = Number(process.hrtime.bigint() - t0) / 1e9;
          if (r.status !== 0) { row.evalError = String(r.stderr).trim().slice(0, 300); return; }
          const g = JSON.parse(r.stdout); row.evalPeakRssMiB = g.processPeakRssMiB || null;
          if (ev.method === 'exact') { row.metric = g.nashConv; row.seatGains = g.seats.map(x => x.gain); }
          else { row.seatGains = g.seats.map(x => x.available ? x.gain.mean : null); row.seatStdErr = g.seats.map(x => x.available ? x.gain.stdErr : null);
            row.metric = row.seatGains.every(v => v != null) ? row.seatGains.reduce((x, y) => x + y, 0) : null; row.metricStdErr = row.metric == null ? null : Math.sqrt(row.seatStdErr.reduce((x, y) => x + y * y, 0)); }
        };
        if (game.timeExact) {
          // Checkpoints at exact training wall times: training is stopped by the engine's own stop flag
          // (EM_TRAIN_CANCEL_AFTER_MS, as the desktop Stop button) when the remaining time of the budget has
          // passed; committed updates are kept. The engine refuses more than 10,000,000 committed updates per
          // study: an arm that reaches that cap before a budget stops there, is evaluated there, and is
          // reported as capped (never as having reached the budget).
          const CAP = 10000000, tb = (opt('max-budget') ? game.budgets.filter(T => T <= +opt('max-budget')) : game.budgets).filter(T => !(game.longBudgetSeeds && T > game.longBudgetAbove && !seedList(game.longBudgetSeeds).includes(seed)));
          for (const T of tb) {
            let info = null, failed = null;
            while (wall < T - 0.0015 && updates < CAP) {
              const ms = Math.max(1, Math.ceil((T - wall) * 1000));
              const r = run([spec, CAP - updates, threads || plan.threads, st + '.next', memMiB, ...(updates ? [st] : [])], { env: { ...process.env, EM_TRAIN_CANCEL_AFTER_MS: String(ms) } });
              if (r.status !== 0) { failed = String(r.stderr).trim().slice(0, 300); break; }
              info = JSON.parse(r.stdout); fs.renameSync(st + '.next', st);
              wall += info.wallSeconds; peak = Math.max(peak, info.processPeakRssMiB || 0); updates = info.iterations;
              if (info.limitReached) { failed = 'strategy table reached the ' + memMiB + ' MiB budget at ' + info.trainingDeals + ' deals'; break; }
              if (!info.cancelled && updates < CAP) break;   // the request completed without the timer (cannot happen below the cap)
            }
            if (!info) { stop = failed || 'no training step'; break; }
            const capped = updates >= CAP && wall < T - 0.0015;
            const row = { atBudget: capped || failed ? null : T, capped, deals: info.trainingDeals, updates, threads: info.threads, rows: info.rows, tableMiB: info.tableMiB, wallSeconds: wall, peakRssMiB: peak };
            if (!timingOnly) evaluate(row);
            rows.push(row);
            if (failed) { stop = failed; break; }
            if (capped) { stop = 'update cap: 10,000,000 committed updates reached after ' + wall.toFixed(1) + ' s of training, before the ' + T + ' s budget'; break; }
          }
          stop = stop || 'budget covered';
        } else
        for (let gi = 0, target = game.grid ? game.grid[0] : (game.firstDeals || 2000); !stop; gi++, target = game.grid ? game.grid[gi] : target * 2) {
          if (target == null) { stop = 'grid complete'; break; }
          let want = updatesFor(sp, target) - updates; if (want <= 0) continue;
          let info = null;
          while (want > 0) {   // mwcli accepts at most 10,000,000 updates per call
            const chunk = Math.min(want, 10000000), r = run([spec, chunk, threads || plan.threads, st + '.next', memMiB, ...(updates ? [st] : [])]);
            if (r.status !== 0) { stop = 'training failed: ' + String(r.stderr).trim().slice(0, 300); break; }
            info = JSON.parse(r.stdout); fs.renameSync(st + '.next', st);
            wall += info.wallSeconds; peak = Math.max(peak, info.processPeakRssMiB || 0); want -= chunk; updates = info.iterations;
            if (info.limitReached) { stop = 'strategy table reached the ' + memMiB + ' MiB budget at ' + info.trainingDeals + ' deals'; break; }
          }
          if (!info) break;
          if (info.trainingDeals !== dealsBefore(sp, updates) && !info.limitReached) throw new Error('deal count mismatch');
          const row = { deals: info.trainingDeals, updates: info.iterations, threads: info.threads, rows: info.rows, tableMiB: info.tableMiB, wallSeconds: wall, peakRssMiB: peak };
          // evaluate only checkpoints that can bracket a budget (the previous one is needed for interpolation)
          const evalNow = !timingOnly && (wall >= minBudget / 2.2 || !!game.grid || (game.evalAll ?? false) || wall >= maxBudget);
          if (evalNow || (timingOnly && verifySeeds && seeds.indexOf(seed) < verifySeeds)) {
            const t0 = process.hrtime.bigint(), r = run(['--gain', spec, st, q, game.evalMemoryMiB || 4096]);
            row.evalSeconds = Number(process.hrtime.bigint() - t0) / 1e9;
            if (r.status !== 0) { row.evalError = String(r.stderr).trim().slice(0, 300); }
            else {
              const g = JSON.parse(r.stdout); row.evalPeakRssMiB = g.processPeakRssMiB || null;
              if (ev.method === 'exact') { row.metric = g.nashConv; row.seatGains = g.seats.map(s => s.gain); }
              else { row.seatGains = g.seats.map(s => s.available ? s.gain.mean : null); row.seatStdErr = g.seats.map(s => s.available ? s.gain.stdErr : null);
                row.metric = row.seatGains.every(v => v != null) ? row.seatGains.reduce((a, b) => a + b, 0) : null; row.metricStdErr = row.metric == null ? null : Math.sqrt(row.seatStdErr.reduce((a, b) => a + b * b, 0)); }
            }
          }
          rows.push(row);
          if (!game.grid && wall >= maxBudget) stop = 'budget covered';
          if (game.maxDeals && info.trainingDeals >= game.maxDeals) stop = stop || 'deal cap ' + game.maxDeals;
        }
        fs.appendFileSync(rawFile, JSON.stringify({ game: game.key, arm, seed, stop, rows }) + '\n');
        process.stderr.write(game.key + ' ' + arm + ' seed ' + seed + ' ' + rows.filter(r => r.metric != null).map(r => r.wallSeconds.toFixed(1) + 's:' + r.metric.toExponential(2)).join(' ') + ' | ' + wall.toFixed(1) + ' s, ' + rows.length + ' checkpoints, stop: ' + stop + '\n');
      }
    }
  }
  fs.rmSync(dir, { recursive: true, force: true });
}
// ---------------- statistics ----------------
function tq(df) { const t = { 1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262, 10: 2.228, 11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145, 15: 2.131, 16: 2.120, 17: 2.110, 18: 2.101, 19: 2.093, 20: 2.086, 21: 2.080, 22: 2.074, 23: 2.069, 24: 2.064, 29: 2.045, 34: 2.032, 39: 2.023, 49: 2.010, 59: 2.001 }; if (t[df]) return t[df]; const k = Object.keys(t).map(Number).filter(x => x <= df).pop(); return t[k] || 1.96; }
function betacf(a, b, x) { let c = 1, d = 1 - (a + b) * x / (a + 1); d = 1 / d; let h = d; for (let m = 1; m < 200; m++) { const m2 = 2 * m; let aa = m * (b - m) * x / ((a + m2 - 1) * (a + m2)); d = 1 + aa * d; c = 1 + aa / c; d = 1 / d; h *= d * c; aa = -(a + m) * (a + b + m) * x / ((a + m2) * (a + m2 + 1)); d = 1 + aa * d; c = 1 + aa / c; d = 1 / d; const del = d * c; h *= del; if (Math.abs(del - 1) < 1e-14) break; } return h; }
function lgamma(z) { const g = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5]; let x = z, y = z, t = x + 5.5; t -= (x + 0.5) * Math.log(t); let s = 1.000000000190015; for (const c of g) s += c / ++y; return -t + Math.log(2.5066282746310005 * s / x); }
function ibeta(a, b, x) { if (x <= 0) return 0; if (x >= 1) return 1; const bt = Math.exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * Math.log(x) + b * Math.log(1 - x)); return x < (a + 1) / (a + b + 2) ? bt * betacf(a, b, x) / a : 1 - bt * betacf(b, a, 1 - x) / b; }
const tTwoSided = (t, df) => Number.isFinite(t) ? ibeta(df / 2, 0.5, df / (df + t * t)) : 0;
const stats = v => { const n = v.length; if (!n) return { n: 0 }; const m = v.reduce((a, b) => a + b, 0) / n, sd = n > 1 ? Math.sqrt(v.reduce((a, b) => a + (b - m) ** 2, 0) / (n - 1)) : 0, s = v.slice().sort((a, b) => a - b);
  return { mean: m, median: n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2, sd, ci95: n > 1 ? tq(n - 1) * sd / Math.sqrt(n) : null, min: s[0], max: s[n - 1], n }; };
const paired = (d, log) => { if (d.length < 2) return { n: d.length }; const st = stats(d), se = st.sd / Math.sqrt(d.length), t = se > 0 ? st.mean / se : (st.mean === 0 ? 0 : Infinity);
  const base = { n: d.length, t, df: d.length - 1, p: tTwoSided(t, d.length - 1) };
  return log ? { ...base, meanLnRatio: st.mean, sdLnRatio: st.sd, ratio: Math.exp(st.mean), ratioCi95: [Math.exp(st.mean - st.ci95), Math.exp(st.mean + st.ci95)] }
    : { ...base, meanDifference: st.mean, sdDifference: st.sd, differenceCi95: [st.mean - st.ci95, st.mean + st.ci95] }; };
// metric at x (wall seconds or deals), interpolated in log x inside the observed range; null outside it
const at = (rows, x, k, log) => { const pts = rows.filter(r => r.metric != null).map(r => [Math.log(r[k]), log ? Math.log(Math.max(r.metric, 1e-12)) : r.metric]), lx = Math.log(x);
  if (!pts.length || lx < pts[0][0] - 1e-9 || lx > pts[pts.length - 1][0] + 1e-9) return null;
  for (let i = 1; i < pts.length; i++) if (lx <= pts[i][0] + 1e-9) { const f = pts[i][0] === pts[i - 1][0] ? 1 : (lx - pts[i - 1][0]) / (pts[i][0] - pts[i - 1][0]); return pts[i - 1][1] + Math.min(1, Math.max(0, f)) * (pts[i][1] - pts[i - 1][1]); }
  return pts[0][1]; };
// metric of one arm and seed at a time budget: the checkpoint taken at that budget (time-exact games) or interpolation
const atTime = (rows, T, log) => { if (rows.some(r => 'atBudget' in r)) { const r = rows.find(x => x.atBudget === T); return r && r.metric != null ? (log ? Math.log(Math.max(r.metric, 1e-12)) : r.metric) : null; } return at(rows, T, 'wallSeconds', log); };
const cappedRow = rows => rows.find(r => r.capped && r.metric != null) || null;
function analyse() {
  const raw = {}, stops = {};
  for (const l of fs.readFileSync(rawFile, 'utf8').split('\n').filter(Boolean)) { const r = JSON.parse(l); ((raw[r.game] ||= {})[r.arm] ||= {})[r.seed] = r.rows; ((stops[r.game] ||= {})[r.arm] ||= {})[r.seed] = r.stop; }
  let verified = null;
  if (prior) {   // timing-only reproduction: metric values come from the earlier study at the same (game, arm, seed, deals)
    verified = { checked: 0, identical: 0, mismatches: [] };
    for (const g in raw) for (const a in raw[g]) for (const s in raw[g][a]) for (const r of raw[g][a][s]) {
      const p = prior[g]?.[a]?.[s]?.find(x => x.deals === r.deals); if (!p) continue;
      if (r.metric != null) { verified.checked++; if (r.metric === p.nashConv) verified.identical++; else verified.mismatches.push({ g, a, s, deals: r.deals, here: r.metric, prior: p.nashConv }); }
      r.metric = p.nashConv; r.seatGains = p.seatGains; r.metricSource = 'earlier study (deterministic at equal deals)';
    }
  }
  const allPrimary = {};
  const report = { tool: 'convergence52', generated: new Date().toISOString(), cpu: os.cpus()[0].model, logicalCpus: os.cpus().length, pinnedCpus: cpus || null, mwcli: cli, build: execFileSync(cli, ['--build-id'], { encoding: 'utf8' }).trim(),
    plan: path.basename(planFile), planSha256: require('node:crypto').createHash('sha256').update(fs.readFileSync(planFile)).digest('hex'), trainingThreads: plan.threads, evaluationThreads: plan.evalThreads, arms: plan.arms, timingOnly, metricFromEarlierStudy: verified,
    method: 'See the header of tools/convergence52.js. Exact metric: sum of exact per-seat best-response gains inside the abstraction (not exploitability). Sampled metric: sum of one-shot-deviation gains (a lower bound per seat; cannot certify an equilibrium). Paired by seed against the default arm at equal training wall time (interpolated inside observed ranges, out-of-range seeds excluded and counted) and at equal sampled deals. Holm over the plan\'s primary comparisons, per arm.', games: [] };
  for (const game of games) {
    if (!raw[game.key]) continue;
    const arms = (game.arms || Object.keys(plan.arms)).filter(a => raw[game.key][a]), log = (game.eval?.method || 'exact') === 'exact';
    const seeds = Object.keys(raw[game.key][arms[0]]).map(Number).filter(s => arms.every(a => raw[game.key][a][s])).sort((a, b) => a - b);
    const g = { key: game.key, description: game.description, role: game.role, evaluation: game.eval || { method: 'exact' }, metric: log ? 'NashConv = sum of exact unilateral best-response gains inside this abstraction; NOT exploitability' : 'sum of sampled one-shot deviation gains (lower bound per seat) with standard error; cannot certify an unrestricted equilibrium',
      unit: game.unit || 'BB', budgets: game.budgets, primaryBudgets: game.primary || [], seeds, incomplete: [], arms: {}, equalTime: {}, equalDeals: {} };
    for (const a of arms) {
      const per = seeds.map(s => raw[game.key][a][s]);
      for (const s of seeds) if (!['budget covered', 'grid complete'].includes(stops[game.key][a][s])) g.incomplete.push({ arm: a, seed: s, stop: stops[game.key][a][s], reachedSeconds: raw[game.key][a][s].at(-1)?.wallSeconds ?? 0, reachedDeals: raw[game.key][a][s].at(-1)?.deals ?? 0 });
      g.arms[a] = { workerThreadsRequested: plan.arms[a].threads || plan.threads, workerThreadsUsedMax: Math.max(...per.flatMap(r => r.map(x => x.threads || 1))),
        atBudget: game.budgets.map(T => { const v = per.map(r => atTime(r, T, log)).filter(x => x != null); const dl = per.map(r => { const hit = r.find(x => x.atBudget === T); if (hit) return hit.deals; if (r.some(x => 'atBudget' in x)) return null; const pts = r.map(x => [Math.log(x.wallSeconds), Math.log(x.deals)]), lx = Math.log(T); if (lx < pts[0][0] || lx > pts.at(-1)[0]) return null; for (let i = 1; i < pts.length; i++) if (lx <= pts[i][0]) return Math.exp(pts[i - 1][1] + (lx - pts[i - 1][0]) / (pts[i][0] - pts[i - 1][0]) * (pts[i][1] - pts[i - 1][1])); return null; }).filter(x => x != null);
          return { budgetSeconds: T, seedsInRange: v.length, metric: v.length ? (log ? { geometricMean: Math.exp(stats(v).mean), ...stats(v.map(Math.exp)) } : stats(v)) : null, dealsAtBudget: dl.length ? stats(dl).mean : null }; }),
        totalTrainingSeconds: stats(per.map(r => r.at(-1)?.wallSeconds ?? 0)), totalEvaluationSeconds: stats(per.map(r => r.reduce((x, y) => x + (y.evalSeconds || 0), 0))), evaluationSecondsPerCall: stats(per.flatMap(r => r.filter(x => x.evalSeconds).map(x => x.evalSeconds))),
        peakTrainingRssMiB: Math.max(...per.flatMap(r => r.map(x => x.peakRssMiB || 0))), peakEvaluationRssMiB: Math.max(0, ...per.flatMap(r => r.map(x => x.evalPeakRssMiB || 0))), dealsPerSecond: stats(per.map(r => r.at(-1) ? r.at(-1).deals / r.at(-1).wallSeconds : 0)) };
    }
    for (const a of arms.slice(1)) {
      g.equalTime[a] = game.budgets.map(T => { const d = [], excluded = []; for (const s of seeds) { const x = atTime(raw[game.key][a][s], T, log), y = atTime(raw[game.key][arms[0]][s], T, log); if (x == null || y == null) excluded.push(s); else d.push(x - y); }
        const c = { budgetSeconds: T, ...paired(d, log), excludedSeeds: excluded }; if ((game.primary || []).includes(T)) { c.primary = true; (allPrimary[a] ||= []).push(c); } return c; });
      // budgets the default arm could not reach (10,000,000-update cap): the arm at the budget against the default at its cap.
      // NOT an equal-time comparison: the default trained for less time and cannot use more.
      if (game.timeExact) g.armAtBudgetVsDefaultAtUpdateCap = { ...(g.armAtBudgetVsDefaultAtUpdateCap || {}), [a]: game.budgets.map(T => { const d = [], capS = []; for (const s of seeds) { const c = cappedRow(raw[game.key][arms[0]][s]), x = atTime(raw[game.key][a][s], T, log); if (c && x != null && c.wallSeconds < T) { d.push(x - (log ? Math.log(Math.max(c.metric, 1e-12)) : c.metric)); capS.push(c.wallSeconds); } } return d.length >= 2 ? { budgetSeconds: T, defaultCapSeconds: stats(capS), ...paired(d, log) } : null; }).filter(Boolean) };
      if (game.timeExact) {   // equal deals: the arm interpolated (log-log between its own checkpoints) at the deals the default had at each of its checkpoints
        g.equalDeals[a] = game.budgets.map(T => { const d = [], dl = []; for (const s of seeds) { const y = raw[game.key][arms[0]][s].find(r => r.atBudget === T); if (!y || y.metric == null) continue; const x = at(raw[game.key][a][s], y.deals, 'deals', log); if (x != null) { d.push(x - (log ? Math.log(Math.max(y.metric, 1e-12)) : y.metric)); dl.push(y.deals); } } return d.length >= 2 ? { defaultBudgetSeconds: T, deals: stats(dl).mean, interpolated: true, ...paired(d, log), excludedSeeds: seeds.length - d.length } : null; }).filter(Boolean);
        continue;
      }
      const common = [...new Set(raw[game.key][arms[0]][seeds[0]].filter(r => r.metric != null).map(r => r.deals))];
      g.equalDeals[a] = common.map(D => { const d = [], excluded = []; for (const s of seeds) { const x = at(raw[game.key][a][s], D, 'deals', log), y = at(raw[game.key][arms[0]][s], D, 'deals', log); if (x == null || y == null) excluded.push(s); else d.push(x - y); } return { deals: D, ...paired(d, log), excludedSeeds: excluded.length }; }).filter(c => c.n >= 2);
    }
    // secondary: warm-4-256 against fixed parallel64 (same worker count: schedule alone)
    if (arms.includes('warm-4-256') && arms.includes('parallel64')) g.warmVsParallel64EqualTime = game.budgets.map(T => { const d = []; for (const s of seeds) { const x = atTime(raw[game.key]['warm-4-256'][s], T, log), y = atTime(raw[game.key].parallel64[s], T, log); if (x != null && y != null) d.push(x - y); } return { budgetSeconds: T, ...paired(d, log) }; });
    report.games.push(g);
    const f = c => c.n >= 2 ? (log ? c.ratio.toFixed(2) + '[' + c.ratioCi95.map(v => v.toFixed(2)).join(',') + ']' : c.meanDifference.toFixed(4) + '[' + c.differenceCi95.map(v => v.toFixed(4)).join(',') + ']') + 'n' + c.n : 'n<2';
    for (const a of arms.slice(1)) console.log(game.key.padEnd(14), a.padEnd(12), 'equal time', g.equalTime[a].map(c => c.budgetSeconds + 's:' + f(c)).join(' '), '| equal deals', g.equalDeals[a].map(c => Math.round(c.deals / 1000) + 'k:' + f(c)).join(' '));
  }
  for (const a in allPrimary) { const cs = allPrimary[a].filter(c => c.p != null); cs.slice().sort((x, y) => x.p - y.p).reduce((runMax, c, i) => { c.holmP = Math.max(runMax, Math.min(1, (cs.length - i) * c.p)); return c.holmP; }, 0); }
  report.raw = raw; report.stops = stops;
  fs.writeFileSync(out, JSON.stringify(report, null, 1));
  console.log('wrote', out);
}
if (!opt('analyse-only')) measure();
analyse();
