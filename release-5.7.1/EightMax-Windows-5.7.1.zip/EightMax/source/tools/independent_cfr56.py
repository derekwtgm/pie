#!/usr/bin/env python3
"""EightMax 5.6: INDEPENDENT exact expected CFR increments, compared with the engine's estimators.
Usage: independent_cfr56.py spec.json dump.json [more-dumps.json ...] > report.json

dump.json is written by source/tests/enum56.cpp: for one estimator (the default external sampling, the 5.5 "river"
enumeration, or the 5.6 "river-shared" / "river-cross" candidates) the Monte Carlo mean increment per sampled deal of
every table entry, with its standard error, read against a FROZEN table whose values are in the dump.

This script computes what those means should be. It shares no code with the engine: betting rules, side pots and the
seven-card evaluator are those of independent_br48.py (written for the best-response check and equally independent
of the engine); the strategy is regret matching on the frozen regrets; every compatible hand tuple (weighted by the
range weights) and every remaining board card is enumerated. For a row of seat p at betting path h, hand x and public
cards c, with A the event "the deal has hand x for p and public cards c":

  regret target(a)  = step    * sum over deals in A of P(deal) * prod_{i != p} pi_i(h) * (v_p(h,a) - v_p(h))
  average target(a) = avgStep * sum over deals in A of P(deal) * pi_p(h) * sigma(a)

where pi_i(h) is seat i's own strategy probability of its actions on h, v_p the expected chips of p under the frozen
strategies (expectation over later cards), and P(deal) the probability of the hand tuple and of the cards dealt so
far. These are the counterfactual regret and the reach-weighted strategy of the sampled-chance CFR update that
external sampling estimates. An estimator is unbiased when its mean agrees with the target within Monte Carlo error.

Verdict per dump: z = (mean - target) / standardError for every entry with a nonzero standard error and at least
MIN_NONZERO (500) deals with a nonzero increment; entries without sampling error must agree to 1e-9 relative. An
entry touched by only a few deals has a standard error estimated from those few (heavy-tailed) values and its z is
not approximately normal; such entries are counted and listed as not tested, never as agreeing. They shrink as the
number of deals grows (the formal runs use millions). PASS requires max |z| below the two-sided Bonferroni critical value at
0.05 over the tested entries (stated in the report) and no deterministic mismatch. This is a statistical check at the
resolution of the standard errors, which the report lists; it is not a proof."""
import sys, json, itertools, math, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from independent_br48 import Game, CHANCE
from statistics import NormalDist
MIN_NONZERO = 500

def targets(spec, frozen):
    g = Game(spec); n = g.n
    hands = [[(h[1], h[2], h[3]) for h in seat] for seat in spec['hands']]; board0 = list(spec['board'])
    deals = []
    for tup in itertools.product(*[range(len(s)) for s in hands]):
        cards = [c for p, i in enumerate(tup) for c in hands[p][i][:2]]
        if len(set(cards + board0)) != len(cards) + len(board0): continue
        w = 1.0
        for p, i in enumerate(tup): w *= hands[p][i][2]
        if w > 0: deals.append((tup, w))
    Z = sum(w for _, w in deals)
    def pub(board): return tuple(sorted(board[:3])) + tuple(board[3:])
    def sigma(key, k):
        r = frozen.get(key)
        if r is None or len(r) != 2 * k: return [1.0 / k] * k     # the engine's rule for a row that does not exist yet
        pos = [x if x > 0 else 0.0 for x in r[:k]]; t = sum(pos)
        return [x / t for x in pos] if t else [1.0 / k] * k
    reg, avg = {}, {}
    def walk(s, path, board, tup, reach, chance):
        """Returns the expected payoff vector under the frozen strategies and accumulates the targets."""
        p = g.actor(s)
        if p < 0:
            if sum(s.live) <= 1 or s.blen == 5: return g.payoff(s, board, [hands[i][tup[i]][:2] for i in range(n)])
            used = set(board) | {c for i in range(n) for c in hands[i][tup[i]][:2]}; rest = [x for x in range(52) if x not in used]; d = len(rest)
            t = g.next_street(s); acc = [0.0] * n
            for x in rest:
                v = walk(t, path + (CHANCE,), board + [x], tup, reach, chance / d)
                for i in range(n): acc[i] += v[i] / d
            return acc
        tos, facing = g.actions(s, p); k = len(tos)
        if k == 1: return walk(g.advance(s, p, 0, tos, facing), path + (0,), board, tup, reach, chance)
        key = (path, tup[p], pub(board)); sg = sigma(key, k); vs = []
        for a in range(k):
            r2 = reach[:]; r2[p] = reach[p] * sg[a]
            vs.append(walk(g.advance(s, p, a, tos, facing), path + (a,), board, tup, r2, chance))
        v = [sum(sg[a] * vs[a][i] for a in range(k)) for i in range(n)]
        others = 1.0
        for i in range(n):
            if i != p: others *= reach[i]
        R = reg.setdefault(key, [0.0] * k); A = avg.setdefault(key, [0.0] * k)
        for a in range(k):
            R[a] += chance * others * (vs[a][p] - v[p]); A[a] += chance * reach[p] * sg[a]
        return v
    for tup, w in deals: walk(g.root(), (), board0, tup, [1.0] * n, w / Z)
    return reg, avg, len(deals)

def main():
    spec = json.load(open(sys.argv[1])); reports = []; ok = True; cache = None
    for path in sys.argv[2:]:
        d = json.load(open(path)); frozen = {}
        for r in d['rows']:
            L = r['length']; c = r['cards']; frozen[(tuple(r['path']), r['hand'], (tuple(sorted(c[:3])) + tuple(c[3:L])) if L >= 3 else ())] = r['frozen']
        if cache is None or cache[0] != frozen: cache = (frozen, targets(spec, frozen))
        reg, avg, ndeals = cache[1]; step, astep = d['step'], d['averageStep']
        zs = {'regret': [], 'average': []}; det = 0; few = {'regret': 0, 'average': 0}; worst = {'regret': None, 'average': None}; rel = {'regret': 0.0, 'average': 0.0}
        for r in d['rows']:
            L = r['length']; c = r['cards']; key = (tuple(r['path']), r['hand'], (tuple(sorted(c[:3])) + tuple(c[3:L])) if L >= 3 else ()); k = r['k']
            for a in range(2 * k):
                kind = 'regret' if a < k else 'average'
                target = step * reg.get(key, [0.0] * k)[a] if a < k else astep * avg.get(key, [0.0] * k)[a - k]
                mean, se = r['mean'][a], r['standardError'][a]
                if se == 0:
                    if abs(mean - target) > 1e-9 * max(1.0, abs(target)): det += 1
                    continue
                if 'nonzeroDeals' in r and r['nonzeroDeals'][a] < MIN_NONZERO: few[kind] += 1; continue
                z = (mean - target) / se; zs[kind].append(z)
                if abs(target) > 0: rel[kind] = max(rel[kind], se / abs(target))
                if worst[kind] is None or abs(z) > abs(worst[kind]['z']): worst[kind] = {'z': z, 'path': r['path'], 'hand': r['hand'], 'action': a % k, 'mean': mean, 'target': target, 'standardError': se}
        tested = len(zs['regret']) + len(zs['average']); crit = NormalDist().inv_cdf(1 - 0.05 / (2 * max(1, tested)))
        def summ(v): return {'tested': len(v), 'maxAbsZ': max((abs(x) for x in v), default=0.0), 'shareAbove1.96': sum(abs(x) > 1.959963984540054 for x in v) / max(1, len(v)), 'meanZ': sum(v) / max(1, len(v)), 'rmsZ': math.sqrt(sum(x * x for x in v) / max(1, len(v)))}
        sr, sa = summ(zs['regret']), summ(zs['average']); passed = det == 0 and max(sr['maxAbsZ'], sa['maxAbsZ']) < crit; ok &= passed
        reports.append({'dump': os.path.basename(path), 'estimator': d['estimator'], 'trials': d['trials'], 'prefixDeals': d['prefixDeals'], 'stateVisitsPerDeal': d['stateVisitsPerDeal'], 'secondsPerDeal': d['secondsPerDeal'], 'dealsEnumerated': ndeals,
                        'rows': len(d['rows']), 'regret': sr, 'average': sa, 'worstRegret': worst['regret'], 'worstAverage': worst['average'], 'deterministicMismatches': det, 'entriesNotTestedForFewNonzeroDeals': few, 'minimumNonzeroDeals': MIN_NONZERO, 'bonferroniCriticalZ': crit, 'passed': passed})
    print(json.dumps({'tool': 'independent_cfr56', 'spec': os.path.basename(sys.argv[1]), 'players': spec['n'], 'startCards': len(spec['board']), 'allPassed': ok, 'estimators': reports}, indent=1))
    sys.exit(0 if ok else 1)

if __name__ == '__main__': main()
