#!/usr/bin/env python3
"""EightMax 5.5: the default trainer and the experimental river enumeration on the shipped tournament fixtures.
Usage: tournament55.py MWCLI OUTDIR

RESTRICTED measurements only. Exact whole-game evaluation is infeasible for these configurations; each fixture's own
quality metric is used (a sampled one-decision deviation gain: a lower bound on a seat's gain, not exploitability, not
calibrated). Descriptive: five paired seeds support no statistical verdict and none is drawn. The plan is written first."""
import sys, json, subprocess, pathlib, statistics, time, platform
cli, out = sys.argv[1], pathlib.Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True); root = pathlib.Path(__file__).resolve().parents[1]
FIX = [('btn25-open', 'eight-handed MTT, button open folded to, linked preflop to river, weighted ranges', True),
       ('flop3-kings', 'three-player postflop, two flop bet sizes, linked flop to river', True),
       ('flop6-jack', 'six-player postflop, side pots possible, flop and turn betting', False),
       ('icm8-bb-call', 'eight-handed final table, ICM, big blind facing an all-in, preflop and flop', False)]
plan = {'fixtures': [f[0] for f in FIX], 'variant': 'baseline (first variant of each fixture)', 'seeds': 5, 'seedList': [101, 102, 103, 104, 105], 'budgets': [20000, 100000], 'evaluationSamples': 4000, 'qualitySamples': 2000, 'threads': 4,
        'arms': {'default': {}, 'river-enumeration': {'opponentEnumeration': 'river'}}, 'metric': "each fixture's declared quality metric (sampled one-decision deviation gain) and the action-EV leader",
        'analysis': 'descriptive only: means, paired differences by seed, counts of seeds lower/higher; no significance statement', 'platform': platform.platform(), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(out / 'plan.json').write_text(json.dumps(plan, indent=1)); rows = []
for fixture, situation, river in FIX:
    fx = root / 'studies' / (fixture + '.emfix.json'); name = json.load(open(fx))['variants'][0]['name']; docs = {}
    for arm, extra in (('default', []), ('river-enumeration', ['opponentEnumeration=river'])):
        res = out / f'{fixture}-{arm}.json'
        p = subprocess.run([cli, '--study', str(fx), str(res), 'variants=' + name, 'seeds=101,102,103,104,105', 'budgets=20000,100000', 'evaluationSamples=4000', 'qualitySamples=2000', 'threads=4', 'checkpoint=off', 'quiet=1', *extra], capture_output=True, text=True)
        if p.returncode: raise SystemExit(p.stderr[-500:])
        docs[arm] = json.load(open(res)); print(fixture, arm, round(docs[arm]['run']['elapsedSeconds'], 1), 's', flush=True)
    for bi, budget in enumerate(plan['budgets']):
        def q(arm): return [s['budgets'][bi] for s in docs[arm]['variants'][0]['perSeed']]
        a, b = q('default'), q('river-enumeration'); ok = all(x['complete'] for x in a + b)
        qa, qb = [x['quality'] for x in a], [x['quality'] for x in b]; have = all(x is not None for x in qa + qb)   # some fixtures evaluate quality at the last budget only
        dif = [y - x for x, y in zip(qa, qb)] if have else []
        prev = lambda arm: [s['budgets'][bi - 1]['trainingSecondsCumulative'] if bi else 0 for s in docs[arm]['variants'][0]['perSeed']]
        tr = lambda arm, pts: statistics.mean(x['trainingSecondsCumulative'] - y for x, y in zip(pts, prev(arm)))
        agg = lambda arm: docs[arm]['variants'][0]['budgets'][bi]
        rows.append({'fixture': fixture, 'situation': situation, 'riverBetting': river, 'metric': docs['default']['variants'][0]['qualityMetric']['kind'] + ' one-decision gain (restricted)', 'budget': budget, 'complete': ok,
                     'qualityEvaluated': have, 'defaultQuality': statistics.mean(qa) if have else None, 'candidateQuality': statistics.mean(qb) if have else None, 'difference': statistics.mean(dif) if have else None, 'lower': sum(d < 0 for d in dif), 'higher': sum(d > 0 for d in dif), 'identical': qa == qb and [x['ev'] for x in a] == [x['ev'] for x in b],
                     'defaultTrainSeconds': tr('default', a), 'candidateTrainSeconds': tr('river-enumeration', b), 'defaultLeader': agg('default')['leader']['byEv'], 'candidateLeader': agg('river-enumeration')['leader']['byEv'],
                     'defaultVerdict': agg('default')['verdict'], 'candidateVerdict': agg('river-enumeration')['verdict'], 'defaultRows': statistics.mean(x['rows'] for x in a), 'candidateRows': statistics.mean(x['rows'] for x in b)})
noop = [r for r in rows if not r['riverBetting']]; act = [r for r in rows if r['riverBetting']]
reading = ('Fixtures without river betting: the candidate ' + ('produced identical measurements to the default in every row, as expected (it only acts on river decisions).' if all(r['identical'] for r in noop) else 'did NOT produce identical measurements in every row; see the raw documents.') +
           ' Fixtures with river betting: ' + '; '.join(f"{r['fixture']} at {r['budget']:,} deals: restricted quality {r['defaultQuality']:.4g} (default) vs {r['candidateQuality']:.4g} (candidate), lower in {r['lower']} of 5 seeds, training {r['candidateTrainSeconds'] / max(r['defaultTrainSeconds'], 1e-9):.1f}x the time" for r in act if r['qualityEvaluated']) +
           '. Five seeds and a restricted, uncalibrated metric support no conclusion about equilibrium quality in these games; the rows show cost and direction only. Verdicts of the action ranking: ' + ', '.join(sorted({r['defaultVerdict'] for r in rows} | {r['candidateVerdict'] for r in rows})) + '.')
(out / 'summary.json').write_text(json.dumps({'plan': plan, 'rows': rows, 'reading': reading}, indent=1)); print(reading)
