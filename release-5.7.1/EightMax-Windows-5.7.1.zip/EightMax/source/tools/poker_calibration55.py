#!/usr/bin/env python3
"""EightMax 5.5: end-to-end calibration of the sampled action evaluator against the EXACT evaluator.
Usage: poker_calibration55.py MWCLI OUTDIR [--seeds 300] [--samples 256,2000]

For each reference game (tools/games48.js; small enough for exact evaluation) a strategy is trained, the exact
action EVs of several hero hands at the root are computed, and the sampled evaluator is run with many independent
seeds. Measured against the exact values (the truth for the conditional estimand):
  - every sample inside the payoff bound derived from the betting rules (bounded.withinBounds), and the exact EVs too;
  - simultaneous coverage of all pairwise differences by the bounded-payoff intervals (bounded.pairwiseCi);
  - the same for the normal-approximation max-t intervals (multipleComparisons.pairwiseCi);
  - false 'supportedBest' statements of both.
The exact evaluator shares the betting/showdown code with the sampler but not the sampling, variance or interval code;
the exact evaluator itself is checked against independent Python references elsewhere (independent_br48.py).
"""
import argparse, json, pathlib, subprocess, math, sys, time, platform
from scipy.stats import norm
ap = argparse.ArgumentParser(); ap.add_argument('cli'); ap.add_argument('out'); ap.add_argument('--seeds', type=int, default=300); ap.add_argument('--samples', default='256,2000'); ap.add_argument('--games', default='hu-river,hu-turn,river3-chip,flop6,turn4,bubble4,final8'); ap.add_argument('--deals', type=int, default=20000)
A = ap.parse_args(); out = pathlib.Path(A.out); out.mkdir(parents=True, exist_ok=True); root = pathlib.Path(__file__).resolve().parent
def wilson(w, n):
    z = norm.ppf(.975); q = w / n; d = 1 + z * z / n; h = z * math.sqrt(q * (1 - q) / n + z * z / (4 * n * n)) / d; c = (q + z * z / (2 * n)) / d; return {'successes': w, 'trials': n, 'rate': q, 'wilson95': [c - h, c + h]}
def run(args, check=True):
    p = subprocess.run([A.cli, *map(str, args)], capture_output=True, text=True)
    if p.returncode and check: raise RuntimeError(p.stderr[:500])
    return json.loads(p.stdout) if p.returncode == 0 else None
plan = {'games': A.games.split(','), 'trainingDeals': A.deals, 'trainingSeed': 77, 'evaluationSeeds': A.seeds, 'samples': [int(x) for x in A.samples.split(',')], 'hands': 'first three hero hands at the root (path [])', 'passRule': 'no sample or exact EV outside the payoff bound; Wilson 95% upper limit of bounded simultaneous coverage >= 0.95 in every cell', 'platform': platform.platform(), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(out / 'poker-plan.json').write_text(json.dumps(plan, indent=1)); rows = []; fails = []
for game in plan['games']:
    d = out / 'work' / game; d.mkdir(parents=True, exist_ok=True); sp = d / 'spec.json'; st = d / 'state'; q = d / 'q.json'
    subprocess.run(['node', str(root / 'games48.js'), 'spec', game, str(sp), '77', json.dumps({'device': 'cpu'})], check=True, capture_output=True)
    run([sp, A.deals, 2, st, 256])
    for hand in range(3):
        q.write_text(json.dumps({'path': [], 'hands': [hand], 'method': 'exact', 'threads': 2, 'device': 'cpu', 'maxVisits': 2000000000, 'timeLimitMs': 600000}))
        ex = run(['--ev', sp, st, q, 256], check=False)
        if not ex or not ex['hands'][0].get('available'): continue
        truth = ex['hands'][0]['ev']; k = len(truth)
        if k < 2: continue
        for n in plan['samples']:
            c = dict(trials=0, within=0, ebCover=0, ebBestFalse=0, ebBest=0, mtCover=0, mtBestFalse=0, mtBest=0, exactInside=0, ebHalf=0.0, mtHalf=0.0); bound = None
            for seed in range(1, A.seeds + 1):
                q.write_text(json.dumps({'path': [], 'hands': [hand], 'method': 'sampled', 'samples': n, 'seed': seed, 'threads': 1, 'device': 'cpu', 'timeLimitMs': 600000}))
                r = run(['--ev', sp, st, q, 256], check=False)
                if not r: continue
                h = r['hands'][0]
                if not h.get('available') or h.get('status') != 'completed' or 'bounded' not in h: continue
                b = h['bounded']; mc = h.get('multipleComparisons'); c['trials'] += 1; bound = [b['lower'], b['upper']]
                c['within'] += b['withinBounds']; c['exactInside'] += all(b['lower'] - 1e-9 <= x <= b['upper'] + 1e-9 for x in truth)
                best = max(range(k), key=lambda a: truth[a])
                ok = True; hw = 0
                for i in range(k):
                    for j in range(k):
                        if i == j: continue
                        ci = b['pairwiseCi'][i][j]; ok &= ci is not None and ci[0] - 1e-9 <= truth[i] - truth[j] <= ci[1] + 1e-9
                        if ci: hw = max(hw, (ci[1] - ci[0]) / 2)
                c['ebCover'] += ok; c['ebHalf'] += hw
                if b['supportedBest'] is not None: c['ebBest'] += 1; c['ebBestFalse'] += any(truth[b['supportedBest']] <= truth[j] for j in range(k) if j != b['supportedBest'])
                if mc:
                    ok = True; hw = 0
                    for i in range(k):
                        for j in range(k):
                            if i == j: continue
                            ci = mc['pairwiseCi'][i][j]; ok &= ci is not None and ci[0] - 1e-9 <= truth[i] - truth[j] <= ci[1] + 1e-9
                            if ci: hw = max(hw, (ci[1] - ci[0]) / 2)
                    c['mtCover'] += ok; c['mtHalf'] += hw
                    if mc['supportedBest'] is not None: c['mtBest'] += 1; c['mtBestFalse'] += any(truth[mc['supportedBest']] <= truth[j] for j in range(k) if j != mc['supportedBest'])
            T = c['trials']
            if not T: continue
            row = {'game': game, 'hand': hand, 'actions': k, 'samples': n, 'exactEv': truth, 'payoffBound': bound, 'utility': ex.get('utility', {}).get('model'), 'trials': T, 'samplesWithinBound': c['within'], 'exactInsideBound': c['exactInside'],
                   'bounded': {'simultaneousCoverage': wilson(c['ebCover'], T), 'supportedBest': c['ebBest'], 'falseSupportedBest': c['ebBestFalse'], 'meanLargestHalfWidth': c['ebHalf'] / T},
                   'normalApproximation': {'simultaneousCoverage': wilson(c['mtCover'], T), 'supportedBest': c['mtBest'], 'falseSupportedBest': c['mtBestFalse'], 'meanLargestHalfWidth': c['mtHalf'] / T}}
            rows.append(row)
            if c['within'] != T or c['exactInside'] != T: fails.append(f'bound {game} hand {hand} n {n}')
            if row['bounded']['simultaneousCoverage']['wilson95'][1] < .95: fails.append(f'coverage {game} hand {hand} n {n}')
            print(game, hand, n, 'k', k, 'bound', bound, 'within', c['within'], '/', T, 'EB', c['ebCover'], 'best', c['ebBest'], 'false', c['ebBestFalse'], '| max-t', c['mtCover'], 'best', c['mtBest'], 'false', c['mtBestFalse'], '| half', round(row['bounded']['meanLargestHalfWidth'], 3), round(row['normalApproximation']['meanLargestHalfWidth'], 3), flush=True)
            with (out / 'poker-raw.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
(out / 'poker-calibration.json').write_text(json.dumps({'plan': plan, 'cells': rows, 'passRuleFailures': fails, 'passed': not fails}, indent=1) + '\n'); print('passed', not fails, fails)
