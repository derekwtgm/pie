// EightMax 5.2: the Study tab driven in a real browser against the desktop host (Requirements 1 and 3).
//
//   node tools/study_ui52.js <host executable> <release dir with studies/> <out-dir> [--wine] [--fixtures=id,id]
//
// For the host (Linux build, or the Windows EightMax.exe under Wine with --wine) it
//   1. opens the application, switches to the Study tab and checks the built-in fixture list;
//   2. for every shipped fixture: opens the fixture FILE through the file input, checks that the page reports
//      "the specification stored in the file equals the one this application builds from the form", presses
//      "Open in Multiway tab", presses Solve (the normal workflow), captures the specification the application
//      sends to the engine (POST /api/mw/init) and compares it with the fixture's, then asks the engine for the
//      decision node (POST /api/mw/node) and compares actor, pot and legal actions with the fixture;
//   3. runs a study from the page (known game; then an intentionally undertrained one), and compares EVERY number
//      shown in the result tables with the result document of the host (GET /api/study/result);
//   4. presses Export JSON and Export CSV and compares the downloaded files with that document;
//   5. opens a result file written by `mwcli --study` and checks it is displayed.
// Writes study-ui.json (every check with its values) and screenshots.
'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), net = require('node:net'), cp = require('node:child_process'), assert = require('node:assert/strict');
const { chromium } = require('playwright');
const args = process.argv.slice(2), [exeArg, relArg, outArg] = args.filter(a => !a.startsWith('--'));
const opt = (k, d) => { const a = args.find(x => x === '--' + k || x.startsWith('--' + k + '=')); return a ? (a.includes('=') ? a.slice(k.length + 3) : true) : d; };
if (!exeArg || !relArg || !outArg) { console.error('usage: node tools/study_ui52.js <host executable> <release dir> <out-dir> [--wine] [--fixtures=a,b]'); process.exit(2); }
const exe = path.resolve(exeArg), rel = path.resolve(relArg), out = path.resolve(outArg), wine = !!opt('wine');
fs.mkdirSync(out, { recursive: true });
const E = require('./loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river', 'lib_river_ui', 'lib_study_ui']) require('../web/' + l);
const S = E.study, checks = [];
const check = (name, ok, detail) => { checks.push({ name, passed: !!ok, ...(detail !== undefined ? { detail } : {}) }); if (!ok) console.error('FAILED: ' + name + (detail !== undefined ? ' ' + JSON.stringify(detail).slice(0, 600) : '')); };
(async () => {
  const port = await new Promise(r => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => r(p)); }); });
  const homeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'em52-ui-'));
  const env = { ...process.env, HOME: wine ? process.env.HOME : homeDir, USERPROFILE: homeDir, EIGHTMAX_GPU: 'off', WINEDEBUG: '-all' };
  const proc = wine ? cp.spawn('wine', [exe, '--no-browser', '--port=' + port], { env, stdio: 'ignore' }) : cp.spawn(exe, ['--no-browser', '--port=' + port], { env, stdio: 'ignore' });
  const url = 'http://127.0.0.1:' + port, api = async (p, body) => { const r = await fetch(url + '/api/' + p, body === undefined ? {} : { method: 'POST', headers: { 'X-EightMax': '1' }, body: JSON.stringify(body) }); return r.json(); };
  let info = null; for (let i = 0; i < 400 && !info; i++) { try { info = await api('info'); } catch { await new Promise(r => setTimeout(r, 50)); } }
  if (!info) { proc.kill(); throw new Error('the host did not start'); }
  const browser = await chromium.launch(), ctx = await browser.newContext({ acceptDownloads: true, viewport: { width: 1500, height: 1100 } }), page = await ctx.newPage();
  const inits = []; page.on('request', r => { if (r.method() === 'POST' && r.url().endsWith('/api/mw/init')) inits.push(r.postData()); });
  const report = { tool: 'study_ui52', generated: new Date().toISOString(), host: wine ? 'Windows executable under ' + cp.execSync('wine --version', { encoding: 'utf8' }).trim() : 'Linux build', executable: path.basename(exe), build: info.build, version: info.version, browser: 'Chromium ' + browser.version(), checks };
  try {
    await page.goto(url + '/#study'); await page.waitForSelector('#sd-pick');
    check('the host reports the study API and the 5.2 version', info.studyApi === 1 && info.version === '5.2', { studyApi: info.studyApi, version: info.version });
    const files = fs.readdirSync(path.join(rel, 'studies')).filter(f => f.endsWith('.emfix.json')).sort();
    const builtIn = await page.$$eval('#sd-pick option', o => o.map(x => x.textContent));
    check('every shipped fixture is in the built-in list', files.every(f => builtIn.includes(JSON.parse(fs.readFileSync(path.join(rel, 'studies', f), 'utf8')).title)), { builtIn: builtIn.length, files: files.length });
    const only = opt('fixtures') ? String(opt('fixtures')).split(',') : null;
    // ---- 2. every fixture through the normal workflow ----
    for (const file of files) {
      const fx = JSON.parse(fs.readFileSync(path.join(rel, 'studies', file), 'utf8')); if (only && !only.includes(fx.id)) continue;
      await page.goto(url + '/#study'); await page.waitForSelector('#sd-file');
      await page.setInputFiles('#sd-file', path.join(rel, 'studies', file)); await page.waitForFunction(t => document.querySelector('#sd-title')?.textContent === t && !!document.querySelector('#sd-check'), fx.title);
      const checkText = await page.textContent('#sd-check');
      check(fx.id + ': opened from its file; the stored specification equals the one the application builds', !/differs/.test(checkText) && (checkText.match(/equals the one this application builds/g) || []).length === fx.variants.length, checkText.slice(0, 200));
      check(fx.id + ': hero, legal actions and action history are shown as recorded', (await page.textContent('#sd-hero')).includes(fx.description.heroHand) && fx.variants[0].decision.actions.every(a => true) && (await page.textContent('#sd-actions')).split(' · ').length === fx.variants[0].decision.actions.length && (await page.textContent('#sd-fixture')).includes(fx.description.actionHistory));
      for (const v of fx.variants.slice(0, fx.kind === 'realistic' ? 1 : fx.variants.length)) {
        await page.goto(url + '/#study'); await page.waitForSelector('#sd-file'); await page.setInputFiles('#sd-file', path.join(rel, 'studies', file)); await page.waitForFunction(t => document.querySelector('#sd-title')?.textContent === t, fx.title);
        await page.selectOption('#sd-variant', v.name); inits.length = 0;
        await page.click('#sd-multiway'); await page.waitForSelector('#v-river:not([hidden]) [data-rv-solve]');
        // the Multiway form now holds the fixture's game: solve it with a small budget, as a user would
        await page.evaluate(() => { const e = document.querySelector('#rv-maxIter') || [...document.querySelectorAll('#v-river input')].find(x => /iter/i.test(x.id)); if (e) { e.value = '300'; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); } });
        await page.click('#v-river [data-rv-solve]');
        await page.waitForFunction(() => !document.querySelector('#v-river [data-rv-stop]:not([disabled])') || document.querySelector('#rv-output')?.textContent.length > 50, null, { timeout: 600000 }).catch(() => {});
        for (let i = 0; i < 3000 && !inits.length; i++) await new Promise(r => setTimeout(r, 20));
        const sent = inits.length ? JSON.parse(inits[0]) : null;
        // the worker adds the strategy table budget of the form (tableLimitMiB) when it sends the game; it is transport, not part of the game
        const budgetSent = sent ? sent.tableLimitMiB : null; if (sent) delete sent.tableLimitMiB;
        check(fx.id + '/' + v.name + ': the table budget sent with the game is the fixture form\'s memory budget', budgetSent === Number(v.spot.memoryMiB), { sent: budgetSent, form: v.spot.memoryMiB });
        check(fx.id + '/' + v.name + ': Solve in the Multiway tab sends the fixture\'s native specification to the engine', sent && JSON.stringify(sent) === JSON.stringify(v.nativeSpec), sent ? { differingFields: Object.keys({ ...sent, ...v.nativeSpec }).filter(k => JSON.stringify(sent[k]) !== JSON.stringify(v.nativeSpec[k])).map(k => k + ': sent ' + String(JSON.stringify(sent[k])).slice(0, 160) + ' / fixture ' + String(JSON.stringify(v.nativeSpec[k])).slice(0, 160)) } : 'no /api/mw/init request seen');
        let st; for (let i = 0; i < 30000; i++) { st = await api('mw/status'); if (st.loaded && !st.running && st.iterations > 0) break; await new Promise(r => setTimeout(r, 20)); }
        const node = await api('mw/node', { path: v.decision.path, board: [], rangeSeat: v.decision.seat, offset: v.decision.handIndex, limit: 1 });
        const cards = c => '23456789TJQKA'[c >> 2] + 'cdhs'[c & 3], hand = node.hands && node.hands.items[0] ? node.hands.items[0].cards.map(cards) : [];
        check(fx.id + '/' + v.name + ': the engine reaches the advertised decision (actor, pot, legal actions, hero hand)',
          node.node && node.node.kind === 'decision' && node.node.actor === v.decision.seat && node.node.pot === v.decision.potBB && JSON.stringify(node.actions.map(a => F_label(a))) === JSON.stringify(v.decision.actions.map(a => a.label)) && [hand.join(''), hand.slice().reverse().join('')].includes(v.decision.hand),
          { actor: node.node && node.node.actor, pot: node.node && node.node.pot, actions: node.actions && node.actions.map(F_label), hand: hand.join('') });
        await api('mw/stop', {}); for (let i = 0; i < 2000; i++) { if (!(await api('mw/status')).running) break; await new Promise(r => setTimeout(r, 10)); } await api('mw/free', {});
      }
      if (fx.id === 'flop6-jack') await page.screenshot({ path: path.join(out, 'multiway-flop6-jack.png') });
    }
    // ---- 3. run a study from the page and compare the display with the result document ----
    async function runFromPage(title, budgets, seeds, variant) {
      await page.goto(url + '/#study'); await page.waitForSelector('#sd-pick');
      await page.selectOption('#sd-pick', { label: title }); await page.waitForFunction(t => document.querySelector('#sd-title')?.textContent === t, title);
      await page.fill('#sd-budgets', budgets); await page.dispatchEvent('#sd-budgets', 'change'); await page.fill('#sd-seeds', String(seeds)); await page.dispatchEvent('#sd-seeds', 'change');
      if (variant) await page.selectOption('#sd-variant', variant);
      // Start, then wait for the HOST to finish this study and for the page to show exactly that result. (Waiting
      // only for the page's result table is a race: the table of the previous study is still on screen while the
      // start request is in flight. On the slower Wine host the first version of this tool read the old result.)
      const [resp] = await Promise.all([page.waitForResponse(r => r.url().endsWith('/api/study/start') && r.request().method() === 'POST'), page.click('#sd-run')]);
      if (resp.status() !== 200) throw new Error('study start refused: ' + resp.status());
      for (let i = 0; ; i++) { const st = await api('study/status'); if (!st.running) { if (st.error) throw new Error(st.error); break; } if (i > 90000) throw new Error('study did not finish'); await new Promise(r => setTimeout(r, 20)); }
      const doc = await api('study/result');
      await page.waitForFunction(e => window.EM.STUDY_LAST && window.EM.STUDY_LAST.run.elapsedSeconds === e && !document.querySelector('#sd-progress') && !!document.querySelector('#sd-headlines'), doc.run.elapsedSeconds, { timeout: 120000 });
      return doc;
    }
    async function compareDisplay(doc, label) {
      const shown = await page.evaluate(() => { const o = { actions: [], gaps: [], headlines: [] };
        for (const tr of document.querySelectorAll('tr[data-sd-budget]')) { const g = k => tr.querySelector('[data-k="' + k + '"]').textContent; o.actions.push({ variant: tr.closest('table').dataset.sdVariant, budget: +tr.dataset.sdBudget, action: tr.dataset.sdAction, frequencyMean: g('frequencyMean'), frequencySd: g('frequencySd'), evMean: g('evMean'), evSd: g('evSd'), evEvalSe: g('evEvalSe') }); }
        for (const tr of document.querySelectorAll('tr[data-sd-gap]')) { const g = k => tr.querySelector('[data-k="' + k + '"]')?.textContent ?? null; o.gaps.push({ variant: tr.closest('table').dataset.sdVariant, budget: +tr.dataset.sdGap, gapMean: g('gapMean'), gapCi: g('gapCi'), gapEvalSe: g('gapEvalSe'), gapBetweenSd: g('gapBetweenSd'), qualityMean: g('qualityMean'), trainSeconds: g('trainSeconds'), evSeconds: g('evSeconds'), qualitySeconds: g('qualitySeconds'), peakRss: g('peakRss'), verdict: g('verdict') }); }
        for (const tr of document.querySelectorAll('tr[data-sd-headline]')) o.headlines.push({ variant: tr.dataset.sdHeadline, lead: tr.querySelector('[data-k="lead"]').textContent, mix: tr.querySelector('[data-k="mix"]').textContent, gap: tr.querySelector('[data-k="gap"]').textContent, tolerance: tr.querySelector('[data-k="tolerance"]').textContent });
        return o; });
      let n = 0, bad = [];
      const eq = (what, a, b) => { n++; if (a !== b) bad.push({ what, shown: a, document: b }); };
      for (const r of shown.actions) { const v = doc.variants.find(x => x.name === r.variant), b = v.budgets.find(x => x.budgetDeals === r.budget), a = b.actions.find(x => x.label === r.action);
        eq(r.variant + ' ' + r.budget + ' ' + r.action + ' frequency', r.frequencyMean, S.pct(a.frequency.mean)); eq('frequency sd', r.frequencySd, S.pct(a.frequency.sdAcrossSeeds)); eq('EV', r.evMean, S.signed(a.ev.mean)); eq('EV sd', r.evSd, S.fmt(a.ev.sdAcrossSeeds)); eq('EV evaluation se', r.evEvalSe, S.fmt(a.evEvaluationStdErrOfMean)); }
      for (const r of shown.gaps) { const v = doc.variants.find(x => x.name === r.variant), b = v.budgets.find(x => x.budgetDeals === r.budget);
        if (b.gap) { eq('gap mean', r.gapMean, S.signed(b.gap.mean)); eq('gap interval', r.gapCi, S.ci(b.gap.ci95)); eq('gap evaluation se', r.gapEvalSe, S.fmt(b.gap.evaluationStdErrOfMean)); eq('gap between-strategy sd', r.gapBetweenSd, S.fmt(b.gap.betweenStrategySd)); }
        if (b.quality) eq('quality', r.qualityMean, S.fmt(b.quality.mean, 4)); eq('training seconds', r.trainSeconds, S.fmt(b.trainingSecondsMean, 2)); eq('EV seconds', r.evSeconds, S.fmt(b.evSecondsMean, 2)); eq('quality seconds', r.qualitySeconds, S.fmt(b.qualitySecondsMean, 2)); eq('peak RAM', r.peakRss, S.fmt(b.processPeakRssMiB, 0)); eq('verdict', r.verdict, b.verdict); }
      for (const r of shown.headlines) { const v = doc.variants.find(x => x.name === r.variant), h = S.headline(v); eq('headline lead', r.lead, h.lead); eq('headline mix', r.mix, h.mix); eq('headline gap', r.gap, h.gapText); }
      const v0 = doc.variants[0], rowsExpected = v0.budgets.reduce((m, b) => m + (b.actions ? b.actions.length : 0), 0);
      check(label + ': every displayed number equals the result document (' + n + ' values compared)', !bad.length && shown.actions.length === rowsExpected && shown.headlines.length === doc.variants.length, bad.length ? bad.slice(0, 5) : { values: n, actionRows: shown.actions.length, headlines: shown.headlines.length });
      return shown;
    }
    const known = JSON.parse(fs.readFileSync(path.join(rel, 'studies', 'known-akq-river.emfix.json'), 'utf8'));
    const doc = await runFromPage(known.title, '1000,10000,100000,1000000,4000000', 4);
    const shown = await compareDisplay(doc, 'known game');
    check('known game: the page shows the mix and the near-zero EV gap plainly', /Mix \(EVs within tolerance\)/.test(shown.headlines[0].lead) && /Call 10 \d+%/.test(shown.headlines[0].mix) && /first met at/.test(shown.headlines[0].tolerance), shown.headlines[0]);
    check('known game: quality metric, its unit and its kind are shown', /Quality metric \(exact\)/.test(await page.textContent('#sd-result')) && /in BB/.test(await page.textContent('#sd-result')));
    await page.screenshot({ path: path.join(out, 'study-known-game.png'), fullPage: true });
    // exports
    const [dj] = await Promise.all([page.waitForEvent('download'), page.click('#sd-json')]); const jsonFile = path.join(out, 'export-known.json'); await dj.saveAs(jsonFile);
    check('Export JSON writes the displayed result document', JSON.stringify(JSON.parse(fs.readFileSync(jsonFile, 'utf8'))) === JSON.stringify(doc), { bytes: fs.statSync(jsonFile).size, name: dj.suggestedFilename() });
    const [dc] = await Promise.all([page.waitForEvent('download'), page.click('#sd-csv')]); const csvFile = path.join(out, 'export-known.csv'); await dc.saveAs(csvFile);
    check('Export CSV equals the CSV of the result document', fs.readFileSync(csvFile, 'utf8') === S.toCSV(doc), { bytes: fs.statSync(csvFile).size, name: dc.suggestedFilename() });
    // per-seed table
    await page.click('[data-sd-seeds]'); const seedRows = await page.$$eval('.sd-seeds tbody tr', r => r.length);
    check('per-seed measurements are shown on request', seedRows === doc.variants[0].perSeed.reduce((n, s) => n + s.budgets.length, 0), seedRows);
    // the Quality tab's existing export carries the study once an analytics document exists (checked through the hook's data)
    check('the latest study result is attached to the existing analytics export', await page.evaluate(() => !!(window.EM.STUDY_LAST && window.EM.STUDY_LAST.format === 'EightMax study result')));
    // undertrained
    const small = JSON.parse(fs.readFileSync(path.join(rel, 'studies', 'flop3-kings-small.emfix.json'), 'utf8'));
    const under = await runFromPage(small.title, '100,200,400', 3, 'baseline'); const us = await compareDisplay(under, 'undertrained study');
    check('undertrained study: the tolerance is reported as not reached with the last measured budget and gap', /not reached; last measured 400 deals/.test(us.headlines[0].tolerance) && /= [+−]\d/.test(us.headlines[0].gap) && under.variants[0].firstBudgetMeetingTolerance === null, us.headlines[0]);
    await page.screenshot({ path: path.join(out, 'study-undertrained.png'), fullPage: true });
    // sensitivity display
    const sens = await runFromPage(small.title, '2000,20000', 3, 'all'); await compareDisplay(sens, 'three variants');
    const sensRows = await page.$$eval('#sd-sensitivity tbody tr', r => r.map(x => x.textContent));
    check('sensitivity table: one row per changed input, with the added action against the best original action', sensRows.length === 2 && /Bet to 9\.25: frequency/.test(sensRows[1]) && /EV vs best original/.test(sensRows[1]), sensRows.map(x => x.slice(0, 160)));
    await page.screenshot({ path: path.join(out, 'study-sensitivity.png'), fullPage: true });
    // ---- 5. a result written by the command line ----
    if (opt('cli-result')) { await page.setInputFiles('#sd-result-file', path.resolve(opt('cli-result'))); const cli = JSON.parse(fs.readFileSync(path.resolve(opt('cli-result')), 'utf8')); await page.waitForFunction(id => document.querySelector('#sd-result-head')?.textContent.includes(id), cli.fixture.id); await compareDisplay(cli, 'result file written by mwcli --study (' + cli.fixture.id + ')'); await page.screenshot({ path: path.join(out, 'study-cli-result.png'), fullPage: true }); }
  } catch (e) { check('the run completed without an exception', false, String(e && e.stack || e).slice(0, 1500)); }
  finally { await browser.close(); proc.kill(); if (wine) cp.spawnSync('wineserver', ['-k']); fs.rmSync(homeDir, { recursive: true, force: true }); }
  report.passed = checks.filter(c => c.passed).length; report.failed = checks.filter(c => !c.passed).length;
  fs.writeFileSync(path.join(out, 'study-ui.json'), JSON.stringify(report, null, 1));
  console.log('study UI checks: ' + report.passed + ' passed, ' + report.failed + ' failed (' + report.host + ', build ' + report.build + ')');
  process.exit(report.failed ? 1 : 0);
})();
function F_label(a) { return a.to > 0 && a.name !== 'Fold' && a.name !== 'Check' ? a.name + ' ' + (+a.to.toFixed(4)) : a.name; }
