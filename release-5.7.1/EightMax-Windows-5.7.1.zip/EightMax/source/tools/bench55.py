#!/usr/bin/env python3
"""EightMax 5.5 performance comparison against the unchanged 5.4 binary. Usage: bench55.py MWCLI_5.4 MWCLI_5.5 OUTDIR [sections]
sections: comma list of study,scaling,checkpoint,training (default all); rows are appended to OUTDIR/runs.jsonl.
Complete decision studies with identical options, alternating binaries, on an otherwise idle machine. Every run is kept
in runs.jsonl. Also: thread scaling of 5.5, checkpoint overhead, raw training throughput, and a check that both
versions measured the same per-seed numbers (action EVs, frequencies, quality) wherever both completed a point.
Nothing here is a claim about another machine."""
import sys, json, subprocess, time, pathlib, platform, os, statistics, hashlib, resource
old, new, out = sys.argv[1], sys.argv[2], pathlib.Path(sys.argv[3]); out.mkdir(parents=True, exist_ok=True); SECTIONS = (sys.argv[4] if len(sys.argv) > 4 else 'study,scaling,checkpoint,training').split(','); root = pathlib.Path(__file__).resolve().parents[1]
fx = lambda n: str(root / 'studies' / (n + '.emfix.json'))
WORK = [   # name, fixture, options (identical for both versions)
 ('akq-river exact, standard preset', 'known-akq-river', ['preset=standard']),
 ('3-player preflop small, sampled, standard preset', 'btn25-open-small', ['preset=standard']),
 ('3-player flop small, exact, standard preset', 'flop3-kings-small', ['preset=standard']),
 ('6-player flop, sampled, standard preset', 'flop6-jack', ['preset=standard']),
 ('3-player flop, sampled, standard preset', 'flop3-kings', ['preset=standard']),
 ('8-handed ICM small, exact, 2 seeds x 2 budgets', 'icm8-bb-call-small', ['seeds=101,102', 'budgets=1000,10000', 'variants=baseline', 'memoryMiB=512', 'timeLimitSeconds=900']),
 ('6-player flop small, exact, 2 seeds x 2 budgets', 'flop6-jack-small', ['seeds=101,102', 'budgets=1000,10000', 'variants=baseline', 'memoryMiB=512', 'timeLimitSeconds=900']),
 ('8-handed ICM, sampled, standard preset', 'icm8-bb-call', ['preset=standard']),
]
THREADS = 4; REPS = 2
def study(cli, fixture, opts, tag):
    res = out / 'results' / (tag + '.json'); res.parent.mkdir(exist_ok=True); t = time.perf_counter(); r0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    p = subprocess.run([cli, '--study', fx(fixture), str(res), *opts, 'quiet=1'], capture_output=True, text=True); wall = time.perf_counter() - t; r1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    if p.returncode: return {'error': p.stderr[-400:], 'wallSeconds': wall}
    d = json.load(open(res)); tr = ev = q = 0; pts = done = 0
    for v in d['variants']:
        for s in v['perSeed']:
            last = 0
            for b in s['budgets']:
                if b['status'] == 'unstarted': continue
                pts += 1; done += b['complete']; tr += b['trainingSecondsCumulative'] - last; last = b['trainingSecondsCumulative']; ev += b['evSeconds']; q += b['qualitySeconds']
    run = d['run']
    return {'wallSeconds': wall, 'studySeconds': run['elapsedSeconds'], 'cpuSeconds': (r1.ru_utime + r1.ru_stime) - (r0.ru_utime + r0.ru_stime), 'trainingSecondsSum': tr, 'actionEvSecondsSum': ev, 'qualitySecondsSum': q, 'pointsCompleted': done, 'pointsStarted': pts,
            'pointsRequested': sum(len(s['budgets']) for v in d['variants'] for s in v['perSeed']), 'peakRssMiB': run['processPeakRssMiB'], 'stoppedByTimeLimit': run['stoppedByTimeLimit'], 'parallelSeeds': run.get('parallelSeeds'), 'evaluationMemoryMiB': run.get('evaluationMemoryMiB'),
            'checkpoint': {k: run['checkpoint'][k] for k in ('enabled', 'commits', 'engineStateWrites', 'engineStateMiBWritten', 'secondsWriting')} if isinstance(run.get('checkpoint'), dict) else None, 'result': str(res.relative_to(out))}
def same_numbers(a, b):
    A, B = json.load(open(out / a)), json.load(open(out / b)); n = bad = 0
    for va, vb in zip(A['variants'], B['variants']):
        for sa, sb in zip(va['perSeed'], vb['perSeed']):
            for pa, pb in zip(sa['budgets'], sb['budgets']):
                if not (pa.get('complete') and pb.get('complete')): continue
                n += 1; bad += any(pa[k] != pb[k] for k in ('ev', 'frequency', 'evStdErr', 'quality', 'qualityStdErr', 'deals', 'rows', 'evaluationSeed'))
    return {'pointsCompared': n, 'pointsDiffering': bad}
env = {'platform': platform.platform(), 'logicalProcessors': os.cpu_count(), 'threadsRequested': THREADS, 'repetitions': REPS, 'old': hashlib.sha256(open(old, 'rb').read()).hexdigest(), 'new': hashlib.sha256(open(new, 'rb').read()).hexdigest(),
       'memTotalKiB': int(open('/proc/meminfo').readline().split()[1]), 'cpu': next((l.split(':')[1].strip() for l in open('/proc/cpuinfo') if l.startswith('model name')), '?'), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
       'note': 'shared cloud container, 4 logical processors; not the target Windows i7 / RTX 4060 Ti machine'}
if not (out / 'environment.json').exists(): (out / 'environment.json').write_text(json.dumps(env, indent=1))
log = (out / 'runs.jsonl').open('a'); rows = []
def rec(**k): rows.append(k); log.write(json.dumps(k) + '\n'); log.flush(); print(json.dumps({x: (round(y, 2) if isinstance(y, float) else y) for x, y in k.items() if x not in ('result',)})[:300], flush=True)
# 1. complete studies, alternating order
for name, fixture, opts in (WORK if 'study' in SECTIONS else []):
    for rep in range(REPS):
        for ver, cli in ([('5.4', old), ('5.5', new)] if rep % 2 == 0 else [('5.5', new), ('5.4', old)]):
            extra = ['checkpoint=off'] if ver == '5.5' else []
            r = study(cli, fixture, opts + ['threads=%d' % THREADS] + extra, f'{fixture}-{ver}-r{rep}'); rec(section='study', workload=name, fixture=fixture, version=ver, rep=rep, threads=THREADS, **r)
    a = [r for r in rows if r['section'] == 'study' and r['workload'] == name and r['version'] == '5.4' and 'result' in r]; b = [r for r in rows if r['section'] == 'study' and r['workload'] == name and r['version'] == '5.5' and 'result' in r]
    if a and b: rec(section='agreement', workload=name, **same_numbers(a[0]['result'], b[0]['result']))
# 2. thread scaling of 5.5 (and 5.4) on a training-dominated and an evaluation-dominated study
# (the 8-handed sampled ICM fixture was dropped from this section: four 5.4 runs of it alone take about 16 minutes)
for name, fixture, opts in ([WORK[3], WORK[5]] if 'scaling' in SECTIONS else []):
    for th in (1, 2, 4, 8):
        for ver, cli in (('5.4', old), ('5.5', new)):
            r = study(cli, fixture, opts + ['threads=%d' % th] + (['checkpoint=off'] if ver == '5.5' else []), f'scale-{fixture}-{ver}-t{th}'); rec(section='scaling', workload=name, fixture=fixture, version=ver, threads=th, **r)
# 3. checkpoint overhead (5.5): default interval, and an aggressive 1 s interval
name, fixture, opts = WORK[3]
for label, extra in [] if 'checkpoint' not in SECTIONS else [('off', ['checkpoint=off']), ('default (60 s + stage boundaries)', ['checkpoint=' + str(out / 'ck-default'), 'replaceCheckpoint=1']), ('every 1 s + stage boundaries', ['checkpoint=' + str(out / 'ck-1s'), 'checkpointSeconds=1', 'replaceCheckpoint=1'])]:
    for rep in range(REPS):
        r = study(new, fixture, opts + ['threads=%d' % THREADS] + extra, f'ckpt-{label.split()[0]}-r{rep}'); rec(section='checkpoint', workload=name, checkpointing=label, rep=rep, version='5.5', threads=THREADS, **r)
# 4. raw training throughput (identical default trainer): deals per second, one thread
tmp = out / 'train'; tmp.mkdir(exist_ok=True)
for fixture, deals in [] if 'training' not in SECTIONS else [('btn25-open', 200000), ('flop6-jack', 100000), ('icm8-bb-call', 200000), ('flop3-kings', 200000)]:
    spec = tmp / (fixture + '.json'); json.dump(json.load(open(fx(fixture)))['variants'][0]['nativeSpec'], open(spec, 'w'))
    for rep in range(3):
        for ver, cli in (('5.4', old), ('5.5', new)):
            p = subprocess.run([cli, str(spec), str(deals), '1', str(tmp / 'state'), '1024'], capture_output=True, text=True); d = json.loads(p.stdout)
            rec(section='training', fixture=fixture, version=ver, rep=rep, deals=d['trainingDeals'], wallSeconds=d['wallSeconds'], dealsPerSecond=d['trainingDeals'] / d['wallSeconds'], rows=d['rows'], tableMiB=d['tableMiB'], stateSha256=hashlib.sha256(open(tmp / 'state', 'rb').read()).hexdigest())
log.close(); (out / 'runs.json').write_text(json.dumps([json.loads(l) for l in open(out / 'runs.jsonl')], indent=1)); print('done')
