#!/usr/bin/env python3
"""EightMax 5.7: fixtures and golden values of mwcli --selftest57, written with the UNCHANGED 5.6 Linux binary.
usage: make_golden57.py <release root> <5.6 mwcli> <fixtures dir>"""
import sys, json, subprocess, hashlib, pathlib, re, tempfile
root, old, out = pathlib.Path(sys.argv[1]).resolve(), sys.argv[2], pathlib.Path(sys.argv[3]).resolve(); out.mkdir(parents=True, exist_ok=True)
tmp = pathlib.Path(tempfile.mkdtemp(prefix='golden57-'))
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def game(key, extra):
    p = tmp / 'g.json'; subprocess.run(['node', str(root / 'source/tools/games48.js'), 'spec', key, str(p), '977', json.dumps(extra)], check=True, capture_output=True); return json.loads(p.read_text())
def fixture(name): return json.loads((root / 'source/studies' / (name + '.emfix.json')).read_text())['variants'][0]['nativeSpec']
frozen = {'batchDeals': 64, 'actionStreams': 'deal'}
training = [('flop5-batch64', game('flop5', {**frozen, 'device': 'cpu'}), 400, 256),
            ('flop3-kings-compact-batch64', {**fixture('flop3-kings'), **frozen}, 150, 1024),
            ('flop3-kings-detailed-batch64', {**fixture('flop3-kings-detailed'), **frozen}, 60, 1024),
            ('icm8-bb-call-batch64', {**fixture('icm8-bb-call'), **frozen}, 300, 1024)]
doc = {'note': 'Golden values of mwcli --selftest57. Every state hash and every evaluation value below was produced by the unchanged EightMax 5.6 Linux binary (sha256 ' + sha(old) + ').', 'training': [], 'evaluation': []}
for name, spec, updates, mem in training:
    f = out / (name + '.spec.json'); f.write_text(json.dumps(spec)); st = tmp / 's.state'
    subprocess.run([old, str(f), str(updates), '1', str(st), str(mem)], check=True, capture_output=True)
    doc['training'].append({'name': name, 'spec': f.name, 'updates': updates, 'memoryMiB': mem, 'stateSha256': sha(st)}); print(name, sha(st)[:16], flush=True)
queries = {'sampled-small.query.json': {'method': 'sampled', 'samples': 4000, 'selectionSamples': 64, 'seed': 57, 'threads': 2, 'timeLimitMs': 900000},
           'sampled-large.query.json': {'method': 'sampled', 'samples': 1000, 'selectionSamples': 16, 'seed': 57, 'threads': 2, 'timeLimitMs': 900000},
           'exact.query.json': {'method': 'exact', 'device': 'cpu', 'threads': 2, 'timeLimitMs': 900000, 'maxVisits': 2000000000, 'memoryMiB': 256}}
for q, body in queries.items(): (out / q).write_text(json.dumps(body))
evaluation = [('btn25-open-small-sampled', fixture('btn25-open-small'), 20000, 256, 'sampled-small.query.json', '"gain":{"mean":'),
              ('flop3-kings-sampled', fixture('flop3-kings'), 20000, 1024, 'sampled-large.query.json', '"gain":{"mean":'),
              ('icm8-bb-call-sampled', fixture('icm8-bb-call'), 20000, 1024, 'sampled-small.query.json', '"gain":{"mean":'),
              ('flop6-jack-small-exact', fixture('flop6-jack-small'), 5000, 512, 'exact.query.json', '"gain":'),
              ('icm8-bb-call-small-exact', fixture('icm8-bb-call-small'), 5000, 256, 'exact.query.json', '"gain":')]
num = re.compile(r'-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?')
for name, spec, updates, mem, q, key in evaluation:
    f = out / (name + '.spec.json'); f.write_text(json.dumps(spec)); st = tmp / 's.state'
    subprocess.run([old, str(f), str(updates), '1', str(st), str(mem)], check=True, capture_output=True)
    r = subprocess.run([old, '--gain', str(f), str(st), str(out / q), str(mem)], check=True, capture_output=True, text=True)
    vals = []; at = 0
    while True:
        at = r.stdout.find(key, at)
        if at < 0: break
        m = num.match(r.stdout, at + len(key)); at += len(key)
        if m: vals.append(float(m.group(0)))
    assert vals, (name, r.stdout[:300])
    doc['evaluation'].append({'name': name, 'spec': f.name, 'updates': updates, 'memoryMiB': mem, 'query': q, 'compare': key, 'stateSha256': sha(st), 'values56': vals}); print(name, sha(st)[:16], vals[:3], len(vals), flush=True)
(out / 'golden57.json').write_text(json.dumps(doc, indent=1))
