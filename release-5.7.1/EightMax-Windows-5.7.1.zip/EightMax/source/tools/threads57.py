#!/usr/bin/env python3
"""EightMax 5.7: thread scaling of frozen-batch training against the unchanged 5.6 binary.
Usage: threads57.py MWCLI_5.6 MWCLI_5.7 OUT.json game:updates[,game:updates...] [--reps R] [--threads 1,2,4] [--arms old,new-fixed,new,new-legacy]
A game is a key of tools/games48.js or the id of a study fixture (its variant 0); it is trained with 64 deals per
update and per-deal action streams, the mode in which one training uses several threads. Arms:
  old         the 5.6 binary
  new         the 5.7 binary with its measured thread choice
  new-fixed   the 5.7 binary with every update on all the threads offered (EIGHTMAX_THREAD_CHOICE=fixed)
  new-legacy  the 5.7 binary with the 5.6 update (EIGHTMAX_LEGACY_BATCH=1): the 5.7 worker pool alone
Each (arm, thread count) is run R times in alternating order; best and median wall seconds, sampled deals per second,
the stage seconds the engine reports and the thread choice are recorded, and the SHA-256 of every saved state, which
must be the same for every arm and thread count of a game. Run on an otherwise idle machine."""
import sys, json, subprocess, hashlib, pathlib, os, platform, tempfile, statistics, argparse
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('games'); ap.add_argument('--reps', type=int, default=5); ap.add_argument('--threads', default='1,2,4')
ap.add_argument('--arms', default='old,new,new-fixed'); ap.add_argument('--mem', default='1024')
A = ap.parse_args(); tmp = pathlib.Path(tempfile.mkdtemp(prefix='em57-thr-')); root = pathlib.Path(__file__).resolve().parent.parent
def spec_of(game):
    p = tmp / (game + '-b64.json'); frozen = {'batchDeals': 64, 'actionStreams': 'deal'}
    fx = root / 'studies' / (game + '.emfix.json')
    if fx.exists(): p.write_text(json.dumps({**json.loads(fx.read_text())['variants'][0]['nativeSpec'], **frozen}))
    else: subprocess.run(['node', str(root / 'tools/games48.js'), 'spec', game, str(p), '977', json.dumps({**frozen, 'device': 'cpu'})], check=True, capture_output=True)
    return p
rows = []
def run(cli, spec, updates, t, env):
    st = tmp / 's.state'; e = dict(os.environ); e.update(env)
    r = subprocess.run([cli, str(spec), str(updates), str(t), str(st), A.mem], capture_output=True, text=True, env=e); assert r.returncode == 0, r.stderr[-300:]
    return json.loads(r.stdout), hashlib.sha256(st.read_bytes()).hexdigest()
ARMS = {'old': (A.old, {}), 'new': (A.new, {}), 'new-fixed': (A.new, {'EIGHTMAX_THREAD_CHOICE': 'fixed'}), 'new-legacy': (A.new, {'EIGHTMAX_LEGACY_BATCH': '1'})}
for item in A.games.split(','):
    game, updates = item.split(':'); spec = spec_of(game); hashes = set()
    cells = [(arm, t) for arm in A.arms.split(',') for t in map(int, A.threads.split(','))]
    res = {c: [] for c in cells}
    for rep in range(A.reps):
        for c in (cells if rep % 2 == 0 else cells[::-1]):
            cli, env = ARMS[c[0]]; info, h = run(cli, spec, int(updates), c[1], env); hashes.add(h); res[c].append(info)
    for c in cells:
        w = [i['wallSeconds'] for i in res[c]]; best = min(res[c], key=lambda i: i['wallSeconds'])
        rows.append({'game': game, 'arm': c[0], 'threads': c[1], 'threadsUsed': best['threads'], 'bestSeconds': min(w), 'medianSeconds': statistics.median(w), 'allSeconds': w, 'trainingDeals': best['trainingDeals'], 'stateVisits': best['stateVisits'],
                     'dealsPerSecondBest': best['trainingDeals'] / min(w), 'dealsPerSecondMedian': best['trainingDeals'] / statistics.median(w), 'seconds': best['seconds'], 'batchStages': best.get('batchStages'), 'threadChoice': best.get('threadChoice'), 'peakRssMiB': best.get('processPeakRssMiB')})
        print(game, c[0], c[1], 'best', round(min(w), 3), 'median', round(statistics.median(w), 3), 'deals/s(median)', round(best['trainingDeals'] / statistics.median(w)), best.get('threadChoice', {}).get('selected'), flush=True)
    for r in rows:
        if r['game'] == game: r['identicalStates'] = len(hashes) == 1
    print(game, 'identical states across all arms and thread counts:', len(hashes) == 1, flush=True)
json.dump({'environment': platform.platform(), 'logicalProcessors': os.cpu_count(), 'old': hashlib.sha256(open(A.old, 'rb').read()).hexdigest(), 'new': hashlib.sha256(open(A.new, 'rb').read()).hexdigest(), 'note': 'shared cloud container; not the target Windows i7 / RTX 4060 Ti machine', 'cpu': next((l.split(':')[1].strip() for l in open('/proc/cpuinfo') if l.startswith('model name')), '?'), 'repetitions': A.reps, 'rows': rows}, open(A.out, 'w'), indent=1)
