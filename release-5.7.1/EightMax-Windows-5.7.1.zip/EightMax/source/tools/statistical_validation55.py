#!/usr/bin/env python3
"""EightMax 5.5 statistical validation. Usage: statistical_validation55.py PROBE OUTDIR [--trials-a 3000] [--trials-b 4000]

The shipped C++ aggregation (study52.hpp aggregate -> study_stats53.hpp / study_stats55.hpp) is driven through
tests/study53_probe.cpp. All data, true values and reference formulas are produced here with NumPy/SciPy; no poker
solver code is its own reference.

  Part A  the 13 scenarios of 5.4 (statistical_validation54.py), same generator and seed, re-measured:
          the 5.4 interval (now `normalApproxConditionalCi95` / `ci95` / verdictFromModelBasedIntervalsAlone) must
          reproduce the 5.4 counts; the 5.5 verdict on the same inputs (no payoff bound available) is recorded.
  Part B  raw bounded samples: each replication's evaluation is a mean of N i.i.d. bounded draws with ESTIMATED
          standard errors, as in the application. Rare-event, skewed, heavy, correlated, non-identical, shared-stream,
          small-count and boundary cases. Conditional and (model-based) population coverage, false rankings, power,
          interval width and cost for the 5.5 interval and the 5.4 interval on identical data.
  Part C  exact evaluation with non-Gaussian TRAINING variation: what the model-based across-training interval does.
  Part D  formula checks: Student-t quantiles and empirical-Bernstein half-widths against independent references.

The protocol (scenarios, seeds, trial counts, pass rules) is written to OUTDIR/protocol.json BEFORE any measurement.
"""
import argparse, json, pathlib, platform, subprocess, time, math
import numpy as np
from scipy.stats import t as tdist, norm
from scipy import integrate

ap = argparse.ArgumentParser(); ap.add_argument('probe'); ap.add_argument('out'); ap.add_argument('--trials-a', type=int, default=3000); ap.add_argument('--trials-b', type=int, default=4000); ap.add_argument('--trials-c', type=int, default=4000)
A = ap.parse_args(); OUT = pathlib.Path(A.out); OUT.mkdir(parents=True, exist_ok=True)
MARGIN = .05

def wilson(w, n):
    if not n: return None
    z = norm.ppf(.975); q = w / n; d = 1 + z * z / n; h = z * math.sqrt(q * (1 - q) / n + z * z / (4 * n * n)) / d; c = (q + z * z / (2 * n)) / d
    return {'successes': int(w), 'trials': int(n), 'rate': q, 'wilson95': [c - h, c + h]}

def run_probe(rows):
    t0 = time.perf_counter()
    r = subprocess.run([A.probe], input='\n'.join(json.dumps(x) for x in rows) + '\n', capture_output=True, text=True, check=True)
    return [json.loads(l) for l in r.stdout.splitlines()], time.perf_counter() - t0

# ----------------------------------------------------------------------------------------------- protocol
SC_A = [('independent_null',5,4,0,.2,.10,0,True,False),('identical_strategies_independent',5,4,0,.2,0,0,True,False),('shared_identical',5,4,0,.2,0,0,False,False),('shared_with_training_variation',5,4,0,.2,.1,.6,False,False),('correlated_actions_null',5,4,0,.2,.10,.9,True,False),('negative_correlated_actions',5,3,0,.2,.1,-.4,True,False),('positive_gap',12,4,1.0,.2,.1,.5,True,False),('exact_evaluation',5,4,0,0,.1,0,True,True),('two_replications',2,3,0,.2,.1,.3,True,False),('one_replication',1,3,0,.2,0,.3,True,False),('heavy_t3',5,4,0,.2,.1,.5,True,False),('skew_lognormal',10,4,0,.2,.1,.5,True,False),('rare_tail_mixture',5,4,0,.2,.1,.5,True,False)]
# Part B scenarios: name -> dict(n seeds, k actions, N samples (int or list per seed), R range, kind, params)
SC_B = [
 dict(name='uniform_bounded', n=5, k=4, N=2000, R=1.0, kind='uniform', tau=.02),
 dict(name='rare_jackpot_Np1', n=5, k=4, N=1000, R=1.0, kind='jackpot', p=.001, tau=0, note='each action pays R with probability p, independently per action; N*p = 1'),
 dict(name='rare_jackpot_Np0.4', n=5, k=4, N=2000, R=1.0, kind='jackpot', p=.0002, tau=0, note='N*p = 0.4: most evaluations never see the event and report SE 0'),
 dict(name='rare_discordant_pair', n=5, k=3, N=2000, R=1.0, kind='discordant', p=.001, tau=0, note='common random numbers: actions agree except on a rare event where action 0 loses the whole range'),
 dict(name='rare_tail_mixture_raw', n=5, k=4, N=1000, R=1.0, kind='jackpot', p=.01, tau=.0, note='the 5.4 rare-tail generator (1% event) as raw samples with estimated SE'),
 dict(name='skew_beta', n=10, k=4, N=1000, R=1.0, kind='beta', a=.3, b=6.0, tau=.01),
 dict(name='heavy_power', n=5, k=4, N=1000, R=1.0, kind='power', e=6.0, tau=.0, note='X = R*U^6: mean R/7, most mass near zero'),
 dict(name='heavy_t3_clipped', n=5, k=4, N=1000, R=1.0, kind='t3clip', loc=.3, scale=.05, tau=0),
 dict(name='correlated_actions_crn', n=5, k=4, N=2000, R=1.0, kind='crn', rho=.95, tau=.01),
 dict(name='nonidentical_replications', n=5, k=4, N=[500,1000,2000,3000,4000], R=1.0, kind='jackpot_het', p=[.0005,.002,.01,.05,.2], tau=0),
 dict(name='shared_stream', n=5, k=4, N=1000, R=1.0, kind='jackpot', p=.002, tau=0, shared=True, note='every replication is evaluated on the SAME draws'),
 dict(name='small_count_64', n=5, k=4, N=64, R=1.0, kind='jackpot', p=.01, tau=0),
 dict(name='one_replication', n=1, k=3, N=2000, R=1.0, kind='jackpot', p=.001, tau=0),
 dict(name='two_replications', n=2, k=3, N=2000, R=1.0, kind='beta', a=.3, b=6.0, tau=.01),
 dict(name='positive_gap_power', n=5, k=4, N=20000, R=1.0, kind='gap', gap=.25, tau=.01, note='action 0 better by 0.25 R (margin 0.05): ranking power'),
 dict(name='positive_gap_small', n=5, k=4, N=20000, R=1.0, kind='gap', gap=.08, tau=.0, note='action 0 better by 0.08 R, close to the margin: power expected low'),
 dict(name='gap_at_margin', n=5, k=3, N=20000, R=1.0, kind='gap', gap=.05, tau=0, note='true gap equals the margin exactly: any ranking is false'),
 dict(name='wide_range_small_spread', n=5, k=4, N=20000, R=50.0, kind='spread', sd=.5, tau=.02, note='declared range 50 but samples spread about 1: the range term dominates'),
 dict(name='exact_evaluation', n=5, k=4, N=0, R=1.0, kind='exact', tau=.1),
 dict(name='understated_bound', n=5, k=4, N=1000, R=1.0, kind='jackpot', p=.00002, tau=0, declared=.5, note='DELIBERATELY WRONG: the declared range is half the true one. The per-sample check must withdraw calibration whenever a sample exceeds it; when no such sample is drawn the error is undetectable. Excluded from the pass rule; reported.'),
]
SC_C = [dict(name='gaussian_training', n=5, k=4, kind='normal'), dict(name='t3_training', n=5, k=4, kind='t3'), dict(name='lognormal_training', n=10, k=4, kind='lognormal'),
        dict(name='rare_training_event_p0.05', n=5, k=4, kind='rare', p=.05), dict(name='rare_training_event_n10', n=10, k=4, kind='rare', p=.05), dict(name='bimodal_training', n=5, k=4, kind='bimodal'),
        dict(name='rare_training_failure_action0', n=5, k=4, kind='rare0', p=.05, edge=0.0, note='action 0 is worth 1 less in 5% of trainings: true mean gap -0.05; most studies see no such training'),
        dict(name='rare_training_reversal', n=5, k=4, kind='rare0', p=.05, edge=.08, note='action 0 leads by 0.08 in 95% of trainings and trails by 0.92 in 5%: population mean gap 0.03 is BELOW the margin although nearly every study sees a clean 0.08 lead')]
protocol = {
 'run': 2, 'previousRuns': 'run1-reproduction-scoring/ (retained; harness scoring repair only, see its README)', 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'procedure': 'study-5.5-bounded-eb-v1 (study_stats55.hpp) via study53_probe', 'margin': MARGIN,
 'generator': {'A': 'NumPy PCG64 seed 541811 (identical to 5.4)', 'B': 'NumPy PCG64 seed 5501', 'C': 'NumPy PCG64 seed 5502', 'D': 'NumPy PCG64 seed 5503'},
 'trials': {'A': A.trials_a, 'B': A.trials_b, 'C': A.trials_c}, 'scenariosA': [s[0] for s in SC_A], 'scenariosB': SC_B, 'scenariosC': SC_C,
 'family': 'k + k(k-1)/2 + 1 per scenario (every action EV, every pair, one quality slot), as the study runner declares it',
 'measures': ['simultaneous conditional coverage (all action EVs and all pairs of the measured strategies)', 'simultaneous population coverage of the model-based interval', 'false ranking frequency (a ranked verdict whose selected action does not truly exceed every other by more than the margin; conditional truth and population truth separately)', 'power (ranked frequency where a true gap above the margin exists)', 'mean half-width of the leading-pair interval', 'aggregation cost'],
 'passRules': {
   'coverage': 'For every Part B scenario in which the 5.5 procedure makes a calibrated statement, the Wilson 95% upper limit of simultaneous conditional coverage must be >= 0.95 (no evidence of undercoverage). understated_bound is excluded and reported.',
   'falseRanking': 'For every Part A, B and C scenario the Wilson 95% lower limit of the false-ranking frequency (against the conditional truth) of the 5.5 verdict must be <= 0.05; the same rule applies to false nearTie and false smallEdge verdicts.',
   'refusal': 'Wherever no payoff bound is supplied (all of Part A with sampled evaluation and >= 2 complete replications) the 5.5 verdict must be "uncalibrated" in 100% of trials and no conditional interval may be published.',
   'reproduction': 'Part A counts for the 5.4 formula (pairwise conditional coverage as 5.4 scored it, population coverage, ranked and false-ranking counts) must equal validation/5.4/statistics/coverage.json exactly when run with 3000 trials. The stricter measure that also requires every single-action interval to cover is reported beside it.',
   'formulas': 'All Part D checks within 1e-8 relative.',
   'interpretation': 'Passing is evidence that the implementation matches the theorem under the simulated assumptions; the coverage guarantee itself rests on the proof and on the assumptions listed in STATISTICAL-VALIDATION-5.5.md, not on these runs.'},
 'platform': platform.platform(), 'numpy': np.__version__,
}
(OUT / 'protocol.json').write_text(json.dumps(protocol, indent=1) + '\n')
report = {'protocol': 'protocol.json', 'platform': platform.platform()}

# ----------------------------------------------------------------------------------------------- Part D
checks = []
quant = [{'df': df, 'alpha': al} for df in [1, 2, 4, 9, 30, 1000, 100000] for al in [.05, .005, .00001]]
res, _ = run_probe(quant)
for q, d in zip(quant, res):
    want = tdist.ppf(1 - q['alpha'] / 2, q['df']); checks.append({'kind': 't-quantile', **q, 'actual': d['critical'], 'reference': want, 'passed': abs(d['critical'] - want) < max(1e-8, abs(want) * 1e-8)})
rng = np.random.default_rng(5503); eb = []
for _ in range(400):
    n = int(rng.integers(2, 200000)); R = float(10 ** rng.uniform(-2, 3)); V = float((R * rng.uniform(0, .5)) ** 2) if rng.random() > .1 else 0.0; delta = float(10 ** rng.uniform(-9, -1))
    eb.append({'ebVariance': V, 'range': R, 'n': n, 'delta': delta})
res, _ = run_probe(eb)
for q, d in zip(eb, res):
    L = math.log(4 / q['delta']); want = min(q['range'], math.sqrt(2 * q['ebVariance'] * L / q['n']) + 7 * q['range'] * L / (3 * (q['n'] - 1)))
    checks.append({'kind': 'empirical-bernstein-half-width', **q, 'actual': d['half'], 'reference': want, 'passed': abs(d['half'] - want) <= 1e-10 * max(1.0, abs(want))})
# The Maurer-Pontil inequality itself, checked by brute force on the distribution family where it is tightest in
# practice (Bernoulli): exact binomial probability that the one-sided bound fails must be <= delta.
from scipy.stats import binom
mp = []
for n in [16, 64, 256, 1000, 4000]:
    for p in [.0002, .001, .01, .05, .2, .5, .9]:
        for delta in [.05, .005, .0005]:
            ks = np.arange(0, n + 1); m = ks / n; V = ks * (n - ks) / (n * (n - 1.0)); L = math.log(2 / delta)
            up = m + np.sqrt(2 * V * L / n) + 7 * L / (3 * (n - 1)); lo = m - np.sqrt(2 * V * L / n) - 7 * L / (3 * (n - 1))
            pm = binom.pmf(ks, n, p); fu = float(pm[up < p].sum()); fl = float(pm[lo > p].sum())
            mp.append({'n': n, 'p': p, 'delta': delta, 'failUpper': fu, 'failLower': fl, 'passed': fu <= delta and fl <= delta})
report['formulaChecks'] = {'tQuantiles': sum(c['kind'] == 't-quantile' for c in checks), 'ebHalfWidths': sum(c['kind'] != 't-quantile' for c in checks), 'failed': [c for c in checks if not c['passed']],
                           'bernoulliExactTailChecks': len(mp), 'bernoulliExactTailFailures': [x for x in mp if not x['passed']], 'bernoulliWorstFailureOverDelta': max(max(x['failUpper'], x['failLower']) / x['delta'] for x in mp)}
print('D', len(checks), 'formula checks,', len(report['formulaChecks']['failed']), 'failed;', len(mp), 'exact Bernoulli tail checks,', len(report['formulaChecks']['bernoulliExactTailFailures']), 'failed', flush=True)

# ----------------------------------------------------------------------------------------------- scoring
def score(docs, mu, theta, k, exact_eval=False):
    """docs: probe outputs per trial. mu: population means (k). theta: (trials, n, k) true per-replication values."""
    T = len(docs); c = dict(pop=0, popAvail=0, cond=0, condPublished=0, legacyCond=0, ranked=0, falseCond=0, falsePop=0, legacyRanked=0, legacyFalseCond=0, legacyFalsePop=0, uncal=0, legacyPairs=0, falseTie=0, falseEdge=0, ties=0, edges=0, halfEb=0.0, halfNormal=0.0, halfN=0)
    verd = {}
    for ti, d in enumerate(docs):
        ct = theta[ti].mean(axis=0); pok = True; cok = True; lok = True; lpk = True; avail = True; published = True
        for a in d['actions']:
            i = int(a['label']); z = a['ev']
            cc = z['conditionalEvaluationCi95']; lc = z['normalApproxConditionalCi95']; pc = z['ci95']
            published &= cc is not None; cok &= cc is not None and cc[0] - 1e-12 <= ct[i] <= cc[1] + 1e-12
            lok &= lc is not None and lc[0] - 1e-12 <= ct[i] <= lc[1] + 1e-12
        for p in d['pairwiseGaps']:
            i, j = int(p['actionA']), int(p['actionB']); z = p['difference']; pc = z['ci95']; cc = z['conditionalEvaluationCi95']; lc = z['normalApproxConditionalCi95']
            avail &= pc is not None; pok &= pc is not None and pc[0] - 1e-12 <= mu[i] - mu[j] <= pc[1] + 1e-12
            published &= cc is not None; cok &= cc is not None and cc[0] - 1e-12 <= ct[i] - ct[j] <= cc[1] + 1e-12
            lok &= lc is not None and lc[0] - 1e-12 <= ct[i] - ct[j] <= lc[1] + 1e-12; lpk &= lc is not None and lc[0] - 1e-12 <= ct[i] - ct[j] <= lc[1] + 1e-12
        c['legacyPairs'] += lpk; c['popAvail'] += avail; c['pop'] += pok and avail; c['condPublished'] += published; c['cond'] += cok and published; c['legacyCond'] += lok
        v = d['verdict']; verd[v] = verd.get(v, 0) + 1; c['uncal'] += v == 'uncalibrated'
        g = d.get('gap')
        if g and g.get('conditionalHalfWidth') is not None and g['normalApproxConditionalCi95']:
            c['halfEb'] += g['conditionalHalfWidth']; c['halfNormal'] += (g['normalApproxConditionalCi95'][1] - g['normalApproxConditionalCi95'][0]) / 2; c['halfN'] += 1
        def false(sel, truth): return any(truth[sel] - truth[j] <= MARGIN for j in range(k) if j != sel)
        if v == 'nearTie': c['ties'] += 1; c['falseTie'] += abs(ct[int(g['higher'])] - ct[int(g['lower'])]) > MARGIN
        if v == 'smallEdge': sel = int(g['higher']); c['edges'] += 1; c['falseEdge'] += any(ct[sel] - ct[j] <= 0 for j in range(k) if j != sel)
        if v == 'ranked':
            sel = int(g['higher']); c['ranked'] += 1; c['falseCond'] += false(sel, ct); c['falsePop'] += false(sel, mu)
        if d['confidence']['verdictFromModelBasedIntervalsAlone'] == 'ranked':
            sel = int(g['higher']); c['legacyRanked'] += 1; c['legacyFalseCond'] += false(sel, ct); c['legacyFalsePop'] += false(sel, mu)
    return {'trials': T, 'verdicts': verd,
            'v55': {'conditionalIntervalPublished': wilson(c['condPublished'], T), 'simultaneousConditionalCoverage': wilson(c['cond'], c['condPublished']), 'ranked': wilson(c['ranked'], T),
                    'falseRankingVsConditionalTruth': wilson(c['falseCond'], T), 'falseRankingVsPopulationTruth': wilson(c['falsePop'], T), 'uncalibratedVerdict': wilson(c['uncal'], T), 'nearTie': wilson(c['ties'], T), 'falseNearTieVsConditionalTruth': wilson(c['falseTie'], T), 'smallEdge': wilson(c['edges'], T), 'falseSmallEdgeVsConditionalTruth': wilson(c['falseEdge'], T),
                    'meanLeadingPairHalfWidth': c['halfEb'] / c['halfN'] if c['halfN'] else None},
            'v54formula': {'simultaneousConditionalCoverage': wilson(c['legacyCond'], T), 'simultaneousConditionalCoveragePairsOnly': wilson(c['legacyPairs'], T), 'ranked': wilson(c['legacyRanked'], T), 'falseRankingVsConditionalTruth': wilson(c['legacyFalseCond'], T),
                           'falseRankingVsPopulationTruth': wilson(c['legacyFalsePop'], T), 'meanLeadingPairHalfWidth': c['halfNormal'] / c['halfN'] if c['halfN'] else None},
            'modelBasedPopulation': {'intervalAvailable': c['popAvail'], 'simultaneousPopulationCoverage': wilson(c['pop'], c['popAvail'])}}

# ----------------------------------------------------------------------------------------------- Part A
rng = np.random.default_rng(541811); partA = []; T = A.trials_a
ref = None
try: ref = {s['scenario']: s for s in json.loads(pathlib.Path(__file__).resolve().parents[2].joinpath('validation/5.4/statistics/coverage.json').read_text())['scenarios']}
except Exception as e: print('no 5.4 reference:', e)
for name, n, k, gap, sigma, tau, rho, independent, exact in SC_A:
    cov = sigma * sigma * ((1 - rho) * np.eye(k) + rho * np.ones((k, k))); L = np.linalg.cholesky(cov + np.eye(k) * 1e-30); mu = np.zeros(k); mu[0] = gap
    theta = mu + tau * rng.standard_normal((T, n, k)); noise = rng.standard_normal((T, n if independent else 1, k)) @ L.T; y = theta + noise
    if name == 'heavy_t3': noise = (rng.standard_t(3, (T, n, k)) / np.sqrt(3)) @ L.T; y = theta + noise
    if name == 'skew_lognormal': noise = ((np.exp(rng.standard_normal((T, n, k))) - np.exp(.5)) / np.sqrt(np.e * (np.e - 1))) @ L.T; y = theta + noise
    if name == 'rare_tail_mixture': noise = (((rng.random((T, n, k)) < .01).astype(float) - .01) / np.sqrt(.0099)) @ L.T; y = theta + noise
    se = np.full((n, k), sigma); pair = np.sqrt(np.maximum(0, np.diag(cov)[:, None] + np.diag(cov)[None, :] - 2 * cov)); pair = np.broadcast_to(pair, (n, k, k)); family = k + k * (k - 1) // 2 + 1
    rows = [{'values': v.tolist(), 'errors': se.tolist(), 'pairErrors': pair.tolist(), 'family': family, 'independent': independent, 'samples': 1000, 'method': 'exact' if exact else 'sampled', 'margin': MARGIN} for v in y]
    docs, sec = run_probe(rows); s = score(docs, mu, theta, k); s.update({'scenario': name, 'replications': n, 'actions': k, 'evaluationStreams': 'independent' if independent else 'shared', 'comparisonFamilySize': family, 'aggregateMicrosecondsPerTrial': 1e6 * sec / T})
    if ref and name in ref and T == 3000:
        r = ref[name]; a = s['v54formula']; b = s['modelBasedPopulation']
        s['reproduces54'] = {'conditional': a['simultaneousConditionalCoveragePairsOnly']['successes'] == r['simultaneousConditionalCoverage']['successes'],
                             'population': (b['simultaneousPopulationCoverage'] or {}).get('successes') == (r['simultaneousPopulationCoverage'] or {}).get('successes'),
                             'ranked': a['ranked']['successes'] == r['ranked']['successes'], 'falseRanking': a['falseRankingVsPopulationTruth']['successes'] == r['falseRanking']['successes'],
                             'reference54': {'conditional': r['simultaneousConditionalCoverage']['successes'], 'population': (r['simultaneousPopulationCoverage'] or {}).get('successes'), 'ranked': r['ranked']['successes'], 'falseRanking': r['falseRanking']['successes']}}
    partA.append(s); print('A', name, 'legacy cond', a_ := s['v54formula']['simultaneousConditionalCoverage']['successes'], '/', T, 'v55 verdicts', s['verdicts'], 'reproduces', s.get('reproduces54', {}).get('conditional'), flush=True)
report['partA'] = partA

# ----------------------------------------------------------------------------------------------- Part B
rng = np.random.default_rng(5501); partB = []; T = A.trials_b
def t3clip_mean(loc, scale):
    f = lambda x: min(1.0, max(0.0, loc + scale * x)) * tdist.pdf(x, 3); a, b = (0 - loc) / scale, (1 - loc) / scale; return integrate.quad(f, a, b, limit=400)[0] + integrate.quad(f, b, np.inf, limit=400)[0]   # the integrand is zero below a
def draw(sc, shape, th, rng):
    """th: (..., k) per-replication mean shift already inside the generator's parameters. Returns samples in [0, R]/R units and the true mean."""
    kind = sc['kind']; k = shape[-1]
    if kind == 'uniform': lo = np.clip(th, 0, .5); x = lo[..., None, :] + (1 - .5) * rng.random(shape); return x, lo + .25
    if kind == 'jackpot': p = np.clip(sc['p'] + th, 0, 1); return (rng.random(shape) < p[..., None, :]).astype(float), p
    if kind == 'discordant':   # all actions share the base draw; action 0 additionally loses everything on a rare event
        base = .5 + .5 * rng.random(shape[:-1] + (1,)); x = np.repeat(base, k, axis=-1); ev = rng.random(shape[:-1]) < sc['p']; x[..., 0] = np.where(ev, 0.0, x[..., 0])
        m = np.full(th.shape, .75); m[..., 0] = .75 * (1 - sc['p']); return x, m
    if kind == 'beta': a = sc['a'] * (1 + np.clip(th, -.5, .5)); x = rng.beta(a[..., None, :] * np.ones(shape), sc['b']); return x, a / (a + sc['b'])
    if kind == 'power': return rng.random(shape) ** sc['e'], np.full(th.shape, 1 / (sc['e'] + 1))
    if kind == 't3clip': return np.clip(sc['loc'] + sc['scale'] * rng.standard_t(3, shape), 0, 1), np.full(th.shape, T3)
    if kind == 'crn': common = rng.random(shape[:-1] + (1,)); own = rng.random(shape); pick = rng.random(shape) < sc['rho']; x = .25 + .5 * np.where(pick, common, own); return x + np.clip(th, -.2, .2)[..., None, :], .5 + np.clip(th, -.2, .2)
    if kind == 'gap': g = np.zeros(k); g[0] = sc['gap']; p = np.clip(.4 + g + th, 0, 1); u = rng.random(shape[:-1] + (1,)); return (u < p[..., None, :]).astype(float), p   # common uniform: paired
    if kind == 'spread': c = .5 + np.clip(th, -.1, .1) / sc['R']; x = c[..., None, :] + (sc['sd'] / sc['R']) * (rng.random(shape) - .5) * math.sqrt(12); return x, c
    raise ValueError(kind)
T3 = None
for sc in SC_B:
    n, k, R = sc['n'], sc['k'], sc['R']; family = k + k * (k - 1) // 2 + 1; declared = sc.get('declared', R)
    mu = None; docs = []; thetas = []; sec = 0; violated = 0; undetected = 0
    if sc['kind'] == 't3clip': T3 = t3clip_mean(sc['loc'], sc['scale'])
    for start in range(0, T, 100):
        B = min(100, T - start); th = sc['tau'] * rng.standard_normal((B, n, k)); rows = []
        if sc['kind'] == 'exact':
            m = np.zeros(k); y = m + th; thetas.append(y)
            for v in y: rows.append({'values': v.tolist(), 'errors': np.zeros((n, k)).tolist(), 'pairErrors': np.zeros((n, k, k)).tolist(), 'family': family, 'independent': True, 'samples': 1000, 'method': 'exact', 'margin': MARGIN})
            d, s_ = run_probe(rows); docs += d; sec += s_; mu = m; continue
        Ns = sc['N'] if isinstance(sc['N'], list) else [sc['N']] * n
        vals = np.zeros((B, n, k)); ses = np.zeros((B, n, k)); pes = np.zeros((B, n, k, k)); true = np.zeros((B, n, k)); within = np.ones((B, n), bool)
        shared = None
        for r in range(n):
            s2 = dict(sc)
            if sc['kind'] == 'jackpot_het': s2 = dict(sc, kind='jackpot', p=sc['p'][r])
            if sc.get('shared') and shared is not None: x, m = shared
            else:
                x, m = draw(s2, (B, Ns[r], k), th[:, r, :], rng)
                if sc.get('shared'): shared = (x, m)
            x = x * R; m = m * R
            vals[:, r] = x.mean(axis=1); ses[:, r] = x.std(axis=1, ddof=1) / math.sqrt(Ns[r]); true[:, r] = m
            for i in range(k):
                for j in range(k):
                    if i != j: pes[:, r, i, j] = (x[:, :, i] - x[:, :, j]).std(axis=1, ddof=1) / math.sqrt(Ns[r])
            within[:, r] = (x.min(axis=(1, 2)) >= -1e-12) & (x.max(axis=(1, 2)) <= declared + 1e-12)
        thetas.append(true)
        for b in range(B):
            rows.append({'values': vals[b].tolist(), 'errors': ses[b].tolist(), 'pairErrors': pes[b].tolist(), 'family': family, 'independent': not sc.get('shared', False), 'samples': min(Ns), 'sampleCounts': Ns, 'ranges': [declared] * n, 'within': within[b].tolist(), 'method': 'sampled', 'margin': MARGIN})
            violated += (not within[b].all())
        d, s_ = run_probe(rows); docs += d; sec += s_
    theta = np.concatenate(thetas)
    if mu is None:
        # population mean: the generator's mean at zero training effect (tau enters linearly or is zero in every scenario)
        z, mu = draw(dict(sc, kind='jackpot', p=float(np.mean(sc['p']))) if sc['kind'] == 'jackpot_het' else sc, (1, 2, k), np.zeros((1, k)), np.random.default_rng(1)); mu = mu[0] * R
        if sc['kind'] == 'jackpot_het': mu = np.full(k, float(np.mean(sc['p'])) * R)
    s = score(docs, mu, theta, k); s.update({'scenario': sc['name'], 'spec': sc, 'comparisonFamilySize': family, 'aggregateMicrosecondsPerTrial': 1e6 * sec / T, 'trialsWithObservedBoundViolation': int(violated)})
    if sc['name'] == 'nonidentical_replications' or sc['tau']: s['modelBasedPopulation']['note'] = 'population truth is the mean over the generator of replications'
    partB.append(s)
    c = s['v55']['simultaneousConditionalCoverage']; l = s['v54formula']['simultaneousConditionalCoverage']
    print('B', sc['name'], 'v55 cond', c and (c['successes'], c['trials']), 'legacy cond', l['successes'], '/', T, 'verdicts', s['verdicts'], 'false', s['v55']['falseRankingVsConditionalTruth']['successes'], 'legacyFalse', s['v54formula']['falseRankingVsConditionalTruth']['successes'], 'halfEB/normal', s['v55']['meanLeadingPairHalfWidth'], s['v54formula']['meanLeadingPairHalfWidth'], flush=True)
report['partB'] = partB

# ----------------------------------------------------------------------------------------------- Part C
rng = np.random.default_rng(5502); partC = []; T = A.trials_c
for sc in SC_C:
    n, k = sc['n'], sc['k']; family = k + k * (k - 1) // 2 + 1; sd = .1
    if sc['kind'] == 'normal': th = sd * rng.standard_normal((T, n, k)); mu = np.zeros(k)
    if sc['kind'] == 't3': th = sd * rng.standard_t(3, (T, n, k)) / math.sqrt(3); mu = np.zeros(k)
    if sc['kind'] == 'lognormal': th = sd * (np.exp(rng.standard_normal((T, n, k))) - math.exp(.5)) / math.sqrt(math.e * (math.e - 1)); mu = np.zeros(k)
    if sc['kind'] == 'rare': th = (rng.random((T, n, k)) < sc['p']).astype(float); mu = np.full(k, sc['p'])   # a training run occasionally lands on a different strategy worth +1
    if sc['kind'] == 'rare0': th = .002 * rng.standard_normal((T, n, k)); th[:, :, 0] += sc['edge'] - (rng.random((T, n)) < sc['p']); mu = np.zeros(k); mu[0] = sc['edge'] - sc['p']
    if sc['kind'] == 'bimodal': th = np.where(rng.random((T, n, k)) < .5, -.2, .2) + .01 * rng.standard_normal((T, n, k)); mu = np.zeros(k)
    rows = [{'values': v.tolist(), 'errors': np.zeros((n, k)).tolist(), 'pairErrors': np.zeros((n, k, k)).tolist(), 'family': family, 'independent': True, 'samples': 1000, 'method': 'exact', 'margin': MARGIN} for v in th]
    docs, sec = run_probe(rows); s = score(docs, mu, th, k); s.update({'scenario': sc['name'], 'spec': sc, 'comparisonFamilySize': family}); partC.append(s)
    p = s['modelBasedPopulation']['simultaneousPopulationCoverage']; print('C', sc['name'], 'population coverage', p['successes'], '/', p['trials'], 'ranked', s['v55']['ranked']['successes'], 'falsePop', s['v55']['falseRankingVsPopulationTruth']['successes'], 'falseCond', s['v55']['falseRankingVsConditionalTruth']['successes'], flush=True)
report['partC'] = partC

# ----------------------------------------------------------------------------------------------- verdict
fails = []
for s in partB:
    if s['scenario'] == 'understated_bound': continue
    c = s['v55']['simultaneousConditionalCoverage']
    if c and c['wilson95'][1] < .95: fails.append('coverage ' + s['scenario'])
for s in partA + partB + partC:
    if s['scenario'] == 'understated_bound': continue
    if s['v55']['falseRankingVsConditionalTruth']['wilson95'][0] > .05: fails.append('falseRanking ' + s['scenario'])
    if s['v55']['falseNearTieVsConditionalTruth']['wilson95'][0] > .05 or s['v55']['falseSmallEdgeVsConditionalTruth']['wilson95'][0] > .05: fails.append('falseTieOrEdge ' + s['scenario'])
for s in partA:
    sampled = s['scenario'] != 'exact_evaluation'
    if sampled and s['v55']['conditionalIntervalPublished']['successes'] != 0: fails.append('refusal (interval published) ' + s['scenario'])
    if sampled and s['replications'] >= 2 and s['evaluationStreams'] == 'independent' and s['v55']['uncalibratedVerdict']['successes'] != s['trials']: fails.append('refusal (verdict) ' + s['scenario'])
    if 'reproduces54' in s and not all(v for kk, v in s['reproduces54'].items() if kk != 'reference54'): fails.append('reproduction ' + s['scenario'])
if report['formulaChecks']['failed'] or report['formulaChecks']['bernoulliExactTailFailures']: fails.append('formulas')
report['passRuleFailures'] = fails; report['allPassRulesMet'] = not fails
report['limitations'] = 'Coverage is measured for the listed generators only. The guarantee of the bounded-payoff interval is the Maurer-Pontil theorem under i.i.d. equal-weight samples in a true range at a fixed sample count; simulations check the implementation. The across-training interval is model-based (Part C shows where it fails) and is never sufficient for a ranking. An understated payoff bound is only detected when a sample exceeds it.'
(OUT / 'coverage.json').write_text(json.dumps(report, indent=1, default=lambda x: x.item() if isinstance(x, np.generic) else str(x)) + '\n')
print('pass rules met:', not fails, fails)
