#!/usr/bin/env python3
"""EightMax 5.7: evaluation speed against the unchanged 5.6 binary, same trained states, same queries.
Usage: evalbench57.py MWCLI_5.6 MWCLI_5.7 OUTDIR [--reps R] [--threads T]
For each case a state is trained once (the two binaries write the same state; checked), then each binary answers the
query R times, alternating. Reported: best and median wall seconds of the whole process (state loading included), the
seconds the engine reports for the evaluation itself, peak resident memory, and whether the results are the same
(sampled: every number of "seats" and "summary" equal; exact: relative tolerance 1e-9, largest difference reported).
Run on an otherwise idle machine. Rows are appended to OUTDIR/runs.jsonl as they are measured."""
import sys, json, subprocess, time, pathlib, platform, os, hashlib, statistics, argparse, resource
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('--reps', type=int, default=3); ap.add_argument('--threads', type=int, default=1)
A = ap.parse_args(); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); out = pathlib.Path(A.out).resolve(); out.mkdir(parents=True, exist_ok=True)
root = pathlib.Path(__file__).resolve().parent.parent
if (out / 'runs.jsonl').exists(): raise SystemExit('Use a fresh output directory.')
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def fixture(n): return json.loads((root / 'studies' / (n + '.emfix.json')).read_text())
def game(key):
    p = out / 'g.json'; subprocess.run(['node', str(root / 'tools/games48.js'), 'spec', key, str(p), '977', json.dumps({'device': 'cpu'})], check=True, capture_output=True); return json.loads(p.read_text())
T = A.threads
SAMPLED = {'method': 'sampled', 'samples': 20000, 'selectionSamples': 200, 'seed': 57, 'threads': T, 'timeLimitMs': 3600000}
EXACT = {'method': 'exact', 'device': 'cpu', 'threads': T, 'timeLimitMs': 3600000, 'maxVisits': 2000000000, 'memoryMiB': 1024}
CASES = [   # name, kind, spec, training deals, memory MiB, command, query
 ('3-player flop (flop3-kings): sampled response gain', 'sampled', fixture('flop3-kings')['variants'][0]['nativeSpec'], 250000, 2048, '--gain', SAMPLED),
 ('3-player preflop (btn25-open): sampled response gain', 'sampled', fixture('btn25-open')['variants'][0]['nativeSpec'], 250000, 2048, '--gain', {**SAMPLED, 'samples': 4000, 'selectionSamples': 48}),
 ('6-player flop (flop6-jack): sampled response gain', 'sampled', fixture('flop6-jack')['variants'][0]['nativeSpec'], 250000, 2048, '--gain', SAMPLED),
 ('8-handed ICM (icm8-bb-call): sampled response gain', 'sampled', fixture('icm8-bb-call')['variants'][0]['nativeSpec'], 250000, 2048, '--gain', SAMPLED),
 ('4-player turn (turn4): sampled response gain', 'sampled', game('turn4'), 100000, 256, '--gain', {**SAMPLED, 'samples': 200000, 'selectionSamples': 2000}),
 ('5-player flop (flop5): sampled response gain', 'sampled', game('flop5'), 100000, 256, '--gain', {**SAMPLED, 'samples': 200000, 'selectionSamples': 2000}),
 ('4-player ICM bubble (bubble4): sampled response gain', 'sampled', game('bubble4'), 100000, 256, '--gain', {**SAMPLED, 'samples': 200000, 'selectionSamples': 2000}),
 ('3-player flop (flop3-kings): sampled action EV of the study decision', 'sampled-ev', fixture('flop3-kings'), 250000, 2048, '--ev', None),
 ('6-player flop (flop6-jack): sampled action EV of the study decision', 'sampled-ev', fixture('flop6-jack'), 250000, 2048, '--ev', None),
 ('8-handed ICM (icm8-bb-call): sampled action EV of the study decision', 'sampled-ev', fixture('icm8-bb-call'), 250000, 2048, '--ev', None),
 ('3-player flop small (flop3-kings-small): exact NashConv', 'exact', fixture('flop3-kings-small')['variants'][0]['nativeSpec'], 20000, 512, '--gain', EXACT),
 ('4-player turn (turn4): exact NashConv', 'exact', game('turn4'), 100000, 256, '--gain', EXACT),
 ('5-player flop (flop5): exact NashConv', 'exact', game('flop5'), 100000, 256, '--gain', EXACT),
 ('6-player flop (flop6w): exact NashConv', 'exact', game('flop6w'), 100000, 256, '--gain', EXACT),
 ('8-handed ICM final table (final8w): exact NashConv', 'exact', game('final8w'), 100000, 256, '--gain', EXACT),
 ('4-player ICM bubble (bubble4): exact NashConv', 'exact', game('bubble4'), 100000, 256, '--gain', EXACT),
]
VOL = {'elapsedMs', 'deadline', 'execution', 'work', 'budgets', 'threads', 'engine', 'version', 'distinctCountKind', 'distinctFallbackInformationSets', 'distinctInformationSets'}
def strip(x): return [strip(v) for v in x] if isinstance(x, list) else {k: strip(v) for k, v in x.items() if k not in VOL} if isinstance(x, dict) else x
def numbers(x, acc):
    if isinstance(x, list): [numbers(v, acc) for v in x]
    elif isinstance(x, dict): [numbers(v, acc) for k, v in sorted(x.items())]
    elif isinstance(x, (int, float)) and not isinstance(x, bool): acc.append(float(x))
    return acc
env = {'platform': platform.platform(), 'logicalProcessors': os.cpu_count(), 'threads': T, 'repetitions': A.reps, 'old': sha(old), 'new': sha(new), 'cpu': next((l.split(':')[1].strip() for l in open('/proc/cpuinfo') if l.startswith('model name')), '?'),
       'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'note': 'shared cloud container; not the target Windows i7 / RTX 4060 Ti machine'}
(out / 'environment.json').write_text(json.dumps(env, indent=1)); summary = []
for i, (name, kind, spec, deals, mem, cmd, query) in enumerate(CASES):
    sp = out / ('case%02d.spec.json' % i); st = out / 'state'; st2 = out / 'state56'; q = out / ('case%02d.query.json' % i)
    if kind == 'sampled-ev':
        v = spec['variants'][0]; query = {'path': v['decision']['path'], 'board': v['decision'].get('board') or [], 'hands': [v['decision']['handIndex']], 'method': 'sampled', 'samples': 200000, 'seed': 57, 'threads': T, 'timeLimitMs': 3600000}; spec = v['nativeSpec']
    sp.write_text(json.dumps(spec)); q.write_text(json.dumps(query))
    subprocess.run([new, str(sp), str(deals), '1', str(st), str(mem)], check=True, capture_output=True); subprocess.run([old, str(sp), str(deals), '1', str(st2), str(mem)], check=True, capture_output=True)
    same_state = sha(st) == sha(st2); runs = {'old': [], 'new': []}; docs = {}
    for rep in range(A.reps):
        for arm in (('old', 'new') if rep % 2 == 0 else ('new', 'old')):
            cli = old if arm == 'old' else new; r0 = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss; t = time.perf_counter()
            p = subprocess.run([cli, cmd, str(sp), str(st), str(q)] + ([str(mem)] if cmd == '--gain' else []), capture_output=True, text=True); w = time.perf_counter() - t
            if p.returncode: raise SystemExit(name + ' ' + arm + ': ' + p.stderr[-400:])
            d = json.loads(p.stdout); docs[arm] = d; row = {'case': name, 'kind': kind, 'arm': arm, 'repetition': rep, 'wallSeconds': w, 'engineSeconds': (d.get('elapsedMs') or 0) / 1000, 'peakRssMiBOfChildrenSoFar': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / 1024}
            runs[arm].append(row)
            with (out / 'runs.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
    a, b = strip(docs['old']), strip(docs['new']); na, nb = numbers(a, []), numbers(b, [])
    worst = max((abs(x - y) / max(1e-300, abs(x), abs(y)) for x, y in zip(na, nb) if x != y), default=0.0) if len(na) == len(nb) else None
    def agg(rs): return {'bestSeconds': min(r['wallSeconds'] for r in rs), 'medianSeconds': statistics.median(r['wallSeconds'] for r in rs), 'bestEngineSeconds': min(r['engineSeconds'] for r in rs), 'medianEngineSeconds': statistics.median(r['engineSeconds'] for r in rs)}
    o, n = agg(runs['old']), agg(runs['new'])
    s = {'case': name, 'kind': kind, 'trainingDeals': deals, 'query': query, 'sameTrainedState': same_state, 'v56': o, 'v57': n, 'speedupMedian': o['medianSeconds'] / n['medianSeconds'], 'speedupBest': o['bestSeconds'] / n['bestSeconds'], 'speedupEngineMedian': (o['medianEngineSeconds'] / n['medianEngineSeconds']) if n['medianEngineSeconds'] else None,
         'identicalResults': a == b, 'numbersCompared': len(na), 'largestRelativeDifference': worst, 'nashConv': docs['new'].get('nashConv'), 'gains57': [(x.get('gain') or {}).get('mean') if isinstance(x.get('gain'), dict) else x.get('gain') for x in docs['new'].get('seats', [])]}
    summary.append(s); print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in s.items() if k not in ('query', 'gains57')})[:400], flush=True)
    for f in (st, st2): f.unlink()
(out / 'summary.json').write_text(json.dumps({'environment': env, 'cases': summary}, indent=1))
