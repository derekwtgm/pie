#!/usr/bin/env python3
"""EightMax 5.7 fixed-plan convergence comparison against the unchanged 5.6 binary.
Usage: research57.py BASELINE_5.6_CLI CURRENT_5.7_CLI OUTPUT_DIRECTORY [--plan main|flop6] [--seeds N] [--first-seed S] [--games a,b]
       research57.py --analyze OUTPUT_DIRECTORY

Arms (identical game, identical paired training seed, 128 MiB table budget):
  default56   5.6 binary, default trainer: one deal per update, one thread
  default57   5.7 binary, default trainer (the same code path: 5.7 did not change one-deal updates)
  batch56t4   5.6 binary, frozen batches: 64 deals per update, per-deal action streams, 4 threads offered
  batch57t4   5.7 binary, the same options: the parallel pipeline of 5.7 with its measured thread choice
plan "flop6" (the game 5.6 left unresolved) adds   baseline55: the 5.5 binary's default trainer (EM_RESEARCH_55=path).

The plan is written to plan.json BEFORE any measurement and the script refuses to reuse an output directory. Arms of a
(game, seed) are trained in rotated order, one process at a time (the four-thread arms use every processor of the
development container, so nothing else may run beside this script). Every checkpoint is evaluated by the 5.7 binary's
exact all-seat best response (NashConv inside the abstraction) in a separate process. Nothing is stopped or selected on
results; every row goes to raw.jsonl as it is produced. --analyze writes analysis.json from raw.jsonl and plan.json."""
import sys, pathlib, json, subprocess, time, os, hashlib, math, statistics, platform, argparse
root = pathlib.Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
FROZEN = {'batchDeals': 64, 'actionStreams': 'deal'}
ARMS = {'default56': ('old', {'batchDeals': 1}, 1), 'default57': ('new', {'batchDeals': 1}, 1), 'batch56t4': ('old', FROZEN, 4), 'batch57t4': ('new', FROZEN, 4)}
PLANS = {
 'main': dict(games=['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'flop6', 'final8', 'bubble4'], arms=['default56', 'default57', 'batch56t4', 'batch57t4'], deals=[19200], seconds=[0.25, 1.0], seeds=30, firstSeed=2001,
   identity=[('default57', 'default56'), ('batch57t4', 'batch56t4')],
   primary=[('batch57t4', 'batch56t4'), ('batch57t4', 'default57')], descriptive=[('default57', 'default56'), ('batch56t4', 'default56')],
   question='(Q1) Is 5.7 frozen-batch training on four threads closer to equilibrium than 5.6 frozen-batch training on four threads after the same wall-clock time? (Q2) Is it closer than the default one-deal trainer after the same wall-clock time?',
   promotionRule='Frozen-batch training becomes the default training mode only if batch57t4 vs default57 is "better" at the largest time budget in EVERY game. Otherwise it stays an option, and the report says in which games it helped.'),
 'flop6': dict(games=['flop6'], arms=['baseline55', 'default56', 'default57', 'batch57t4'], deals=[], seconds=[0.5, 2.0], seeds=160, firstSeed=3001,
   identity=[], primary=[('default56', 'baseline55'), ('default57', 'baseline55')], descriptive=[('default57', 'default56'), ('batch57t4', 'default57')],
   question='5.6 measured a lower mean NashConv than 5.5 on flop6 after 0.5 s (ratio 0.70, 40 of 60 seeds lower) and its primary test did not resolve it. With 160 paired seeds and a second, four times longer budget: is the faster default trainer closer to equilibrium at equal time on flop6?',
   promotionRule='None: no trainer is promoted by this plan. The 5.6 statement "unresolved on flop6" is replaced by "better" only if default56 vs baseline55 is "better" at 0.5 s under the test below.'),
}
def binom_two_sided(n, k):   # exact two-sided sign test: P(X <= min) + P(X >= max) for X ~ Bin(n, 1/2), capped at 1
    if n == 0: return 1.0
    lo = min(k, n - k); p = sum(math.comb(n, i) for i in range(0, lo + 1)) / 2 ** n; return min(1.0, 2 * p)
def t_quantile(p, df):       # two-sided Student t quantile by bisection on the regularized incomplete beta (no SciPy needed)
    def cdf(t):
        x = df / (df + t * t); a, b = df / 2, 0.5
        # continued fraction for I_x(a, b)
        def betacf(a, b, x):
            qab, qap, qam = a + b, a + 1, a - 1; c, d = 1.0, 1 - qab * x / qap; d = 1 / (d if abs(d) > 1e-300 else 1e-300); h = d
            for m in range(1, 400):
                m2 = 2 * m; aa = m * (b - m) * x / ((qam + m2) * (a + m2)); d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-300 else 1e-300); c = 1 + aa / c; c = c if abs(c) > 1e-300 else 1e-300; h *= d * c
                aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2)); d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-300 else 1e-300); c = 1 + aa / c; c = c if abs(c) > 1e-300 else 1e-300; de = d * c; h *= de
                if abs(de - 1) < 1e-14: break
            return h
        bt = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1 - x)) if 0 < x < 1 else 0.0
        ib = bt * betacf(a, b, x) / a if x < (a + 1) / (a + b + 2) else 1 - bt * betacf(b, a, 1 - x) / b
        return 1 - ib / 2
    lo, hi = 0.0, 1000.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if cdf(mid) < p: lo = mid
        else: hi = mid
    return (lo + hi) / 2
def contrast(rows, cand, ref, family):
    pairs = sorted(set(rows[cand]) & set(rows[ref])); d = [rows[cand][s] - rows[ref][s] for s in pairs]; n = len(d)
    if not n: return {'pairs': 0, 'verdict': 'no data'}
    lower = sum(x < 0 for x in d); higher = sum(x > 0 for x in d); equal = n - lower - higher
    mc, mr = statistics.fmean(rows[cand][s] for s in pairs), statistics.fmean(rows[ref][s] for s in pairs); md = statistics.fmean(d)
    out = {'pairs': n, 'meanCandidate': mc, 'meanReference': mr, 'ratioOfMeans': mc / mr if mr else None, 'meanDifference': md, 'medianDifference': statistics.median(d), 'seedsLower': lower, 'seedsHigher': higher, 'seedsEqual': equal, 'family': family}
    if equal == n: out['verdict'] = 'identical'; return out
    sd = statistics.stdev(d) if n > 1 else float('nan'); se = sd / math.sqrt(n); alpha = 0.05 / family
    p = binom_two_sided(lower + higher, lower); tq = t_quantile(1 - alpha / 2, n - 1) if n > 1 else float('inf'); lo, hi = md - tq * se, md + tq * se
    out.update(sdDifference=sd, signTestP=p, signTestPBonferroni=min(1.0, p * family), tIntervalBonferroni=[lo, hi],
               # paired seeds needed for the t interval at this family size to exclude 0 with 80% power if the true mean difference were the measured one
               seedsFor80PercentPower=(math.ceil(((tq + 0.8416) * sd / abs(md)) ** 2) if md and n > 1 and math.isfinite(tq) and math.isfinite(sd) else None))
    sign = p * family < 0.05; out['verdict'] = 'better' if sign and hi < 0 and lower > higher else 'worse' if sign and lo > 0 and higher > lower else 'unresolved'
    return out
def analyze(out):
    plan = json.loads((out / 'plan.json').read_text()); rows = [json.loads(l) for l in (out / 'raw.jsonl').read_text().splitlines() if l.strip()]
    res = {'plan': plan['plan'], 'rows': len(rows), 'games': {}}; budgets = [('deals', b) for b in plan['deals']] + [('time', b) for b in plan['trainingSeconds']]
    fam = len(plan['primary']) * len(plan['games'])
    for game in plan['games']:
        g = {}
        for kind, budget in budgets:
            by = {}; deals = {}
            for r in rows:
                if r['game'] == game and r['kind'] == kind and r['budget'] == budget: by.setdefault(r['arm'], {})[r['seed']] = r['nashConv']; deals.setdefault(r['arm'], []).append(r['deals'])
            cell = {'arms': {a: {'seeds': len(v), 'meanNashConv': statistics.fmean(v.values()), 'medianNashConv': statistics.median(v.values()), 'sdNashConv': statistics.stdev(v.values()) if len(v) > 1 else None, 'meanDeals': statistics.fmean(deals[a])} for a, v in by.items()}, 'contrasts': {}}
            for kindOf, lst in (('identity', plan['identity']), ('primary', plan['primary']), ('descriptive', plan['descriptive'])):
                for c, r in lst:
                    if c in by and r in by: cell['contrasts'][c + ' vs ' + r] = {'role': kindOf, **contrast(by, c, r, fam)}
            for c, r in plan['identity']:   # equal deals: the checkpoint files themselves
                if kind == 'deals':
                    a = {x['seed']: x['checkpointSha256'] for x in rows if x['game'] == game and x['kind'] == kind and x['budget'] == budget and x['arm'] == c}; b = {x['seed']: x['checkpointSha256'] for x in rows if x['game'] == game and x['kind'] == kind and x['budget'] == budget and x['arm'] == r}
                    cell['contrasts'][c + ' vs ' + r]['identicalCheckpointFiles'] = sum(a[s] == b[s] for s in a if s in b); cell['contrasts'][c + ' vs ' + r]['checkpointPairs'] = len(set(a) & set(b))
            g[kind + ':' + str(budget)] = cell
        res['games'][game] = g
    (out / 'analysis.json').write_text(json.dumps(res, indent=1)); return res
if len(sys.argv) >= 3 and sys.argv[1] == '--analyze':
    r = analyze(pathlib.Path(sys.argv[2]).resolve())
    for game, g in r['games'].items():
        for cell, c in g.items():
            for name, k in c['contrasts'].items(): print(game, cell, name, k['role'], k['verdict'], 'ratio %.3f' % k['ratioOfMeans'] if k.get('ratioOfMeans') else '', k.get('seedsLower'), '/', k.get('seedsHigher'), '/', k.get('seedsEqual'))
    sys.exit(0)
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('--plan', default='main'); ap.add_argument('--seeds', type=int, default=0); ap.add_argument('--first-seed', type=int, default=0); ap.add_argument('--games', default='')
A = ap.parse_args(); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); out = pathlib.Path(A.out).resolve(); P = PLANS[A.plan]
games = [g for g in A.games.split(',') if g] or P['games']; nseeds = A.seeds or P['seeds']; first = A.first_seed or P['firstSeed']
bins = {'old': old, 'new': new}
if 'baseline55' in P['arms']:
    b55 = os.environ.get('EM_RESEARCH_55'); assert b55, 'plan flop6 needs EM_RESEARCH_55=<5.5 mwcli>'; bins['v55'] = str(pathlib.Path(b55).resolve()); ARMS['baseline55'] = ('v55', {'batchDeals': 1}, 1)
out.mkdir(parents=True, exist_ok=True)
if (out / 'raw.jsonl').exists() or (out / 'plan.json').exists(): raise SystemExit('Use a fresh output directory; old results must not be mixed.')
plan = {'plan': A.plan, 'question': P['question'], 'games': games, 'seeds': list(range(first, first + nseeds)), 'arms': {a: {'binary': {'old': '5.6', 'new': '5.7', 'v55': '5.5'}[ARMS[a][0]], 'trainerOptions': ARMS[a][1], 'threadsOffered': ARMS[a][2]} for a in P['arms']},
        'deals': P['deals'], 'trainingSeconds': P['seconds'], 'memoryMiB': 128, 'evaluatorCacheMiB': 1024,
        'evaluation': 'exact all-seat best response (NashConv inside the abstraction; with more than two players it is not exploitability), CPU, one thread, 5.7 binary, separate process from training',
        'identity': P['identity'], 'primary': P['primary'], 'descriptive': P['descriptive'],
        'identityRule': 'At equal sampled deals the two arms of an identity contrast must write the same checkpoint file for every seed; any difference is a defect.',
        'primaryMetric': 'paired difference of exact NashConv at the largest equal-wall-clock training budget (%.2f s)' % P['seconds'][-1],
        'primaryFamily': '%d primary contrasts x %d games = %d tests at the largest time budget, Bonferroni over %d; the other budgets use the same penalty and are reported, not claimed' % (len(P['primary']), len(games), len(P['primary']) * len(games), len(P['primary']) * len(games)),
        'tests': 'exact two-sided sign test on the paired differences (distribution-free for the median) AND paired Student-t interval (model-based), each Bonferroni-adjusted; "better"/"worse" needs both on the same side; pairs with equal NashConv are "identical"; anything else is "unresolved" and is not a result',
        'stoppingRule': 'fixed: every arm x budget x seed of the plan is run once; no interim analysis; a failed process aborts the run and the directory is kept as it is',
        'promotionRule': P['promotionRule'],
        'limitations': 'Small games with exact evaluation only. NashConv is exact inside each abstraction. Equal-time budgets are wall-clock on a shared four-core virtual machine (the four-thread arms use all of it): timing noise enters those contrasts and is spread over the rotated arm order. Frozen batches (64 deals per update) are a different schedule of updates from the default trainer, so batch arms differ from default arms at equal deals by design.',
        'environment': platform.platform(), 'logicalProcessors': os.cpu_count(), 'binarySha256': {k: sha(v) for k, v in bins.items()}, 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(out / 'plan.json').write_text(json.dumps(plan, indent=1))
def call(cli, args, env=None):
    t = time.perf_counter(); p = subprocess.run([cli, *map(str, args)], capture_output=True, text=True, timeout=7200, env=env)
    if p.returncode: raise RuntimeError(p.stderr[-800:])
    return json.loads(p.stdout), time.perf_counter() - t
t0 = time.time()
for game in games:
    for seed in plan['seeds']:
        order = list(P['arms']); order = order[seed % len(order):] + order[:seed % len(order)]
        for arm in order:
            which, opts, threads = ARMS[arm]; cli = bins[which]
            d = out / 'work'; d.mkdir(parents=True, exist_ok=True); sp = d / 'spec.json'; st = d / 'state'; q = d / 'query.json'
            subprocess.run(['node', str(root / 'games48.js'), 'spec', game, str(sp), str(seed), json.dumps({**opts, 'device': 'cpu'})], check=True, capture_output=True)
            q.write_text(json.dumps({'method': 'exact', 'device': 'cpu', 'threads': 1, 'timeLimitMs': 1800000, 'maxVisits': 2000000000, 'memoryMiB': 1024}))
            per = opts['batchDeals']
            for kind, budgets in [('deals', P['deals']), ('time', P['seconds'])]:
                for budget in budgets:
                    if kind == 'time': args = [sp, 10000000 // per, threads, st, 128]; env = {**os.environ, 'EM_TRAIN_CANCEL_AFTER_MS': str(round(budget * 1000))}   # more updates than a time budget allows (the engine accepts at most 10,000,000)
                    else: args = [sp, budget // per, threads, st, 128]; env = None
                    info, sec = call(cli, args, env); gain, evsec = call(new, ['--gain', sp, st, q, 128])
                    row = {'game': game, 'seed': seed, 'arm': arm, 'kind': kind, 'budget': budget, 'deals': info['trainingDeals'], 'updates': info['iterations'], 'stateVisits': info['stateVisits'], 'trainingSeconds': info['wallSeconds'], 'trainingProcessSeconds': sec, 'threadsUsed': info.get('threads'),
                           'threadChoice': (info.get('threadChoice') or {}).get('selected'), 'rows': info.get('rows'), 'evaluationSeconds': evsec, 'nashConv': gain['nashConv'], 'largestUnilateralGain': gain['largestUnilateralGain'], 'checkpointSha256': sha(st), 'memoryStopped': info.get('limitReached', False)}
                    with (out / 'raw.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
        if seed == plan['seeds'][0] or (seed - first + 1) % 10 == 0: print(game, 'seed', seed, 'elapsed', round(time.time() - t0), 's', flush=True)
for f in (out / 'work').iterdir(): f.unlink()
(out / 'work').rmdir(); analyze(out); print('done', round(time.time() - t0), 's')
