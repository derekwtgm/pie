#!/usr/bin/env python3
"""EightMax 5.6: state identity of the optimized trainer against the unchanged 5.5 binary.
Usage: identity56.py BASELINE_5.5_CLI CURRENT_CLI OUTPUT_DIRECTORY [--deals N] [--quick]

5.6 changed how the external-sampling trainer finds child states, terminal pot layouts and table rows and how often it
reads the clock. None of these may change a single trained number. For every game of tools/games48.js and every
trainer configuration below, both binaries train the same spec and the saved state files must be byte-identical;
the reported counters (deals, state visits, rows, states, random streams, table memory, transient budget) must agree too.
The transient-memory PEAK (scratchPeakBytes) is recorded and not required to match: 5.6 keeps one undo journal per
training call instead of allocating one per update, and own-hand enumeration keeps one row-index frame per depth, so
the high-water mark of transient allocations moves by a few hundred bytes to a few kilobytes. The budget itself and
the per-deal transient limit are unchanged.
Each case is also trained in two parts (stop, save, continue) with the current binary and compared with the one-part
state. Every row is written to identity.jsonl; nothing is skipped on failure. Exit status 1 if any case differs."""
import sys, json, subprocess, hashlib, pathlib, argparse, os, time
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('--deals', type=int, default=24000); ap.add_argument('--quick', action='store_true')
A = ap.parse_args(); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); out = pathlib.Path(A.out).resolve(); out.mkdir(parents=True, exist_ok=True)
root = pathlib.Path(__file__).resolve().parent
if (out / 'identity.jsonl').exists(): raise SystemExit('Use a fresh output directory.')
games = ['hu-river', 'hu-turn', 'river3-chip', 'bubble4', 'flop6', 'final8', 'turn4', 'flop5', 'flop6w', 'final8w']
deal = {'actionStreams': 'deal'}
configs = {   # name: (spec options, threads, memory MiB)
    'default-b1': ({'batchDeals': 1}, 1, 128),
    'deal-streams-b1': ({**deal, 'batchDeals': 1}, 1, 128),
    'batch16-t1': ({**deal, 'batchDeals': 16}, 1, 128),
    'batch16-t4': ({**deal, 'batchDeals': 16}, 4, 128),
    'batch64-t3': ({**deal, 'batchDeals': 64}, 3, 256),
    'warmup-4-64': ({**deal, 'batchDeals': 64, 'batchSchedule': {'start': 4, 'doubleEvery': 50}}, 2, 256),
    'dcfr': ({'batchDeals': 1, 'weighting': 'dcfr'}, 1, 128),
    'dcfr-batch8': ({**deal, 'batchDeals': 8, 'weighting': 'dcfr'}, 2, 128),
    'uniform': ({'batchDeals': 1, 'weighting': 'uniform'}, 1, 128),
    'cfr-plus': ({'batchDeals': 1, 'regretMatching': 'plus'}, 1, 128),
    'terminal-baseline': ({'batchDeals': 1, 'terminalBaseline': True}, 1, 128),
    'terminal-expectation': ({'batchDeals': 1, 'terminalExpectation': True}, 1, 128),
    'own-hand-enumeration': ({'batchDeals': 1, 'ownHandEnumeration': True}, 1, 128),
    'river-enumeration-5.5': ({'batchDeals': 1, 'opponentEnumeration': 'river'}, 1, 128),
    'river-enum-own-hands-batch4': ({**deal, 'batchDeals': 4, 'opponentEnumeration': 'river', 'ownHandEnumeration': True}, 2, 128),
    'exploration-0.3': ({'batchDeals': 1, 'opponentExploration': 0.3}, 1, 128),
    'tight-memory-1MiB': ({**deal, 'batchDeals': 8}, 2, 1),
}
if A.quick: games = games[:4]; configs = {k: configs[k] for k in ['default-b1', 'batch16-t4', 'dcfr', 'river-enumeration-5.5']}
keep = ['iterations', 'trainingDeals', 'stateVisits', 'rng', 'actionRng', 'rows', 'states', 'tableMiB', 'tablePeakBytes', 'tableCapacityBytes', 'scratchBudgetBytes', 'attemptedDealsThisSession', 'transientLimitPerDealBytes', 'limitReached', 'batchDeals', 'weighting', 'trainer', 'stateCache', 'devicePath']
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() if pathlib.Path(p).exists() else None
def run(cli, args):
    p = subprocess.run([cli, *map(str, args)], capture_output=True, text=True, timeout=3600)
    if p.returncode: return {'error': (p.stderr or p.stdout)[-400:]}
    return json.loads(p.stdout)
bad = 0; n = 0; t0 = time.time()
for game in games:
    for name, (opts, threads, mem) in configs.items():
        d = out / 'work'; d.mkdir(exist_ok=True); spec = d / 'spec.json'
        mk = subprocess.run(['node', str(root / 'games48.js'), 'spec', game, str(spec), '977', json.dumps({**opts, 'device': 'cpu'})], capture_output=True, text=True)
        row = {'game': game, 'config': name, 'options': opts, 'threads': threads, 'memoryMiB': mem, 'deals': A.deals}
        if mk.returncode: row['specError'] = mk.stderr[-300:]; row['verdict'] = 'not applicable (the spec builder refused this combination)'
        else:
            updates = max(2, A.deals // opts.get('batchDeals', 1))
            a = run(old, [spec, updates, threads, d / 'old.state', mem]); b = run(new, [spec, updates, threads, d / 'new.state', mem])
            first = updates // 3
            c1 = run(new, [spec, first, threads, d / 'part.state', mem]); c2 = run(new, [spec, updates - first, threads, d / 'two.state', mem, d / 'part.state']) if 'error' not in c1 else c1
            if 'error' in a and 'error' in b:
                row.update(oldError=a['error'], newError=b['error'], verdict='identical refusal' if a['error'] == b['error'] else 'DIFFERENT ERRORS')
            elif 'error' in a or 'error' in b: row.update(oldError=a.get('error'), newError=b.get('error'), verdict='ONE BINARY FAILED')
            else:
                ha, hb, hc = sha(d / 'old.state'), sha(d / 'new.state'), sha(d / 'two.state')
                diff = [k for k in keep if a.get(k) != b.get(k)]
                row.update(oldScratchPeakBytes=a.get('scratchPeakBytes'), newScratchPeakBytes=b.get('scratchPeakBytes'), oldSha256=ha, newSha256=hb, twoPartSha256=hc, stateBytes=(d / 'new.state').stat().st_size, counterDifferences=diff, oldWallSeconds=a['wallSeconds'], newWallSeconds=b['wallSeconds'],
                           trainingDeals=b['trainingDeals'], stateVisits=b['stateVisits'], rows=b['rows'], limitReached=b['limitReached'], twoPartLimitReached=c2.get('limitReached'), linkCache=b.get('linkCache'), twoPartError=c2.get('error'))
                same = ha == hb and not diff
                # A run stopped by the memory budget is not continued, so its two-part state is not comparable.
                two = hc == hb or b['limitReached'] or bool(c2.get('limitReached'))
                row['verdict'] = 'identical' if same and two else 'STATE DIFFERS FROM 5.5' if not same else 'TWO-PART STATE DIFFERS'
            for f in d.iterdir(): f.unlink()
        if row['verdict'].isupper() or row['verdict'][0].isupper(): bad += 1
        n += 1
        with (out / 'identity.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
        print(game, name, row['verdict'], flush=True)
summary = {'cases': n, 'failures': bad, 'seconds': round(time.time() - t0, 1), 'baselineSha256': sha(old), 'currentSha256': sha(new), 'deals': A.deals}
(out / 'summary.json').write_text(json.dumps(summary, indent=1)); print(json.dumps(summary))
sys.exit(1 if bad else 0)
