#!/usr/bin/env python3
"""EightMax 5.7: state identity of the parallel frozen-batch trainer against the unchanged 5.6 binary.
Usage: identity57.py BASELINE_5.6_CLI CURRENT_CLI OUTPUT_DIRECTORY [--deals N] [--quick]

5.7 prepares, traverses and merges the deals of a frozen-batch update on several threads, chooses the number of
threads from measurements, and builds evaluation paths once. None of this may change a trained number. For every game
of tools/games48.js, every study fixture with hand groups and every trainer configuration below:
  - the 5.6 binary trains the spec once (the reference state), and once more with each other thread count when the
    table budget stops the training: the workers' transient memory comes out of the table budget, so with a budget
    of a megabyte the update at which training stops depends on the number of workers, in 5.6 and in 5.7 alike. A
    stopped training is therefore compared with the 5.6 binary run with the same number of threads;
  - the current binary trains it with each thread count of the configuration, once with the measured thread choice and
    once with every update forced onto all threads (EIGHTMAX_THREAD_CHOICE=fixed), and with the 5.6 update kept in the
    binary (EIGHTMAX_LEGACY_BATCH=1);
  - the current binary trains it in two parts with different thread counts (stop, save, continue).
Every saved state must be byte-identical to the reference, and the reported counters (deals, state visits, rows,
states, random streams, table memory, attempted deals, transient limit, limitReached) must agree.
NOT required to match, and recorded: scratchPeakBytes (as in 5.6) and tablePeakBytes. tablePeakBytes is the high-water
mark of table allocations including the old block of a growing vector; in a frozen batch the list of touched rows now
grows after the update's new rows exist instead of between them, which moves that mark by up to a few hundred bytes.
tableMiB and tableCapacityBytes (what a study's limit is compared with) are required to match.
Every row is written to identity.jsonl; nothing is skipped on failure. Exit status 1 if any case differs."""
import sys, json, subprocess, hashlib, pathlib, argparse, os, time
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('--deals', type=int, default=24000); ap.add_argument('--quick', action='store_true')
A = ap.parse_args(); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); out = pathlib.Path(A.out).resolve(); out.mkdir(parents=True, exist_ok=True)
root = pathlib.Path(__file__).resolve().parent
if (out / 'identity.jsonl').exists(): raise SystemExit('Use a fresh output directory.')
games = ['hu-river', 'hu-turn', 'river3-chip', 'bubble4', 'flop6', 'final8', 'turn4', 'flop5', 'flop6w', 'final8w']
fixtures = ['flop3-kings', 'flop6-jack', 'icm8-bb-call', 'btn25-open', 'flop3-kings-detailed']
deal = {'actionStreams': 'deal'}
configs = {   # name: (spec options, thread counts, memory MiB)
    'default-b1': ({'batchDeals': 1}, [1], 128),
    'deal-streams-b1': ({**deal, 'batchDeals': 1}, [1, 4], 128),
    'batch4': ({**deal, 'batchDeals': 4}, [1, 2, 4], 128),
    'batch16': ({**deal, 'batchDeals': 16}, [1, 2, 3, 4, 8], 128),
    'batch64': ({**deal, 'batchDeals': 64}, [1, 2, 3, 4, 8, 16], 256),
    'batch64-shared-stream': ({'batchDeals': 64}, [1, 4], 256),
    'warmup-4-64': ({**deal, 'batchDeals': 64, 'batchSchedule': {'start': 4, 'doubleEvery': 50}}, [1, 2, 4], 256),
    'dcfr-batch8': ({**deal, 'batchDeals': 8, 'weighting': 'dcfr'}, [1, 2, 4], 128),
    'dcfr-batch64': ({**deal, 'batchDeals': 64, 'weighting': 'dcfr'}, [1, 4], 256),
    'uniform-batch16': ({**deal, 'batchDeals': 16, 'weighting': 'uniform'}, [1, 4], 128),
    'cfr-plus-batch16': ({**deal, 'batchDeals': 16, 'regretMatching': 'plus'}, [1, 4], 128),
    'terminal-baseline-batch16': ({**deal, 'batchDeals': 16, 'terminalBaseline': True}, [1, 4], 128),
    'terminal-expectation-batch16': ({**deal, 'batchDeals': 16, 'terminalExpectation': True}, [1, 4], 128),
    'own-hand-enumeration-batch8': ({**deal, 'batchDeals': 8, 'ownHandEnumeration': True}, [1, 4], 128),
    'river-enum-own-hands-batch4': ({**deal, 'batchDeals': 4, 'opponentEnumeration': 'river', 'ownHandEnumeration': True}, [1, 2], 128),
    'river-shared-batch16': ({**deal, 'batchDeals': 16, 'opponentEnumeration': 'river-shared'}, [1, 4], 128),
    'river-cross-batch16': ({**deal, 'batchDeals': 16, 'opponentEnumeration': 'river-cross'}, [1, 4], 128),
    'exploration-0.3-batch16': ({**deal, 'batchDeals': 16, 'opponentExploration': 0.3}, [1, 4], 128),
    'tight-memory-1MiB-batch8': ({**deal, 'batchDeals': 8}, [1, 2, 4], 1),
    'tight-memory-1MiB-batch64': ({**deal, 'batchDeals': 64}, [1, 4], 1),
}
fixtureConfigs = {   # study fixtures (variant 0), Compact and Detailed hand groups
    'default-b1': ({'batchDeals': 1}, [1], 1024, 12000),
    'batch64': ({**deal, 'batchDeals': 64}, [1, 2, 4, 8], 1024, 9600),
    'batch16-dcfr': ({**deal, 'batchDeals': 16, 'weighting': 'dcfr'}, [1, 4], 1024, 6400),
    'batch64-2MiB': ({**deal, 'batchDeals': 64}, [1, 2, 4], 2, 25600),
    'batch8-1MiB': ({**deal, 'batchDeals': 8}, [1, 4], 1, 16000),
}
if A.quick: games = games[:4]; fixtures = fixtures[:2]; configs = {k: configs[k] for k in ['default-b1', 'batch16', 'batch64', 'dcfr-batch8', 'tight-memory-1MiB-batch8']}; fixtureConfigs = {k: fixtureConfigs[k] for k in ['batch64', 'batch64-2MiB']}
keep = ['iterations', 'trainingDeals', 'stateVisits', 'rng', 'actionRng', 'rows', 'states', 'tableMiB', 'tableCapacityBytes', 'scratchBudgetBytes', 'attemptedDealsThisSession', 'transientLimitPerDealBytes', 'limitReached', 'batchDeals', 'weighting', 'trainer', 'stateCache', 'devicePath']
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() if pathlib.Path(p).exists() else None
def run(cli, args, env=None):
    e = dict(os.environ); e.update(env or {})
    p = subprocess.run([cli, *map(str, args)], capture_output=True, text=True, timeout=3600, env=e)
    if p.returncode: return {'error': (p.stderr or p.stdout)[-400:]}
    return json.loads(p.stdout)
FIXED, LEGACY = {'EIGHTMAX_THREAD_CHOICE': 'fixed'}, {'EIGHTMAX_LEGACY_BATCH': '1'}
bad = 0; n = 0; runs = 0; t0 = time.time(); d = out / 'work'; d.mkdir(exist_ok=True)
def case(kind, name, cname, spec, opts, threads, mem, updates):
    global bad, n, runs
    row = {'kind': kind, 'game': name, 'config': cname, 'options': opts, 'threads': threads, 'memoryMiB': mem, 'updates': updates}
    a = run(old, [spec, updates, threads[-1], d / 'old.state', mem]); ha = sha(d / 'old.state') if 'error' not in a else None; runs += 1
    arms = []; problems = []
    frozen = opts.get('batchDeals', 1) > 1
    plan = [(t, 'measured', {}) for t in threads] + ([(t, 'fixed', FIXED) for t in threads if t > 1] + [(threads[-1], 'legacy', LEGACY)] if frozen else [])
    refs = {threads[-1]: (a, ha)}
    for t, mode, env in plan:
        b = run(new, [spec, updates, t, d / 'new.state', mem], env); runs += 1
        if t not in refs and ('error' in a or a.get('limitReached') or b.get('limitReached')):   # a stopped training: the 5.6 reference with the same thread count
            ra = run(old, [spec, updates, t, d / 'old-t.state', mem]); refs[t] = (ra, sha(d / 'old-t.state') if 'error' not in ra else None); runs += 1
        a, ha = refs.get(t, refs[threads[-1]])
        if 'error' in a or 'error' in b:
            same = 'error' in a and 'error' in b and a['error'] == b['error']
            arms.append({'threads': t, 'mode': mode, 'oldError': a.get('error'), 'newError': b.get('error'), 'identical': same})
            if not same: problems.append('%d threads %s: one binary failed or the refusals differ' % (t, mode))
            continue
        hb = sha(d / 'new.state'); diff = [k for k in keep if a.get(k) != b.get(k)]
        arms.append({'threads': t, 'mode': mode, 'sha256': hb, 'identical': hb == ha, 'counterDifferences': diff, 'threadsUsed': b.get('threads'), 'threadChoice': b.get('threadChoice'), 'wallSeconds': b['wallSeconds'],
                     'scratchPeakBytes': b.get('scratchPeakBytes'), 'tablePeakBytes': b.get('tablePeakBytes')})
        if hb != ha: problems.append('%d threads %s: STATE DIFFERS' % (t, mode))
        if diff: problems.append('%d threads %s: counters differ: %s' % (t, mode, ','.join(diff)))
    a, ha = refs[threads[-1]]
    row['referenceThreadCounts'] = sorted(refs)
    if 'error' not in a:
        first = updates // 3; t1, t2 = threads[0], threads[-1]
        c1 = run(new, [spec, first, t2, d / 'part.state', mem], FIXED); c2 = run(new, [spec, updates - first, max(1, t1), d / 'two.state', mem, d / 'part.state'], FIXED) if 'error' not in c1 else c1; runs += 2
        hc = sha(d / 'two.state') if 'error' not in c2 else None
        stopped = a.get('limitReached') or c1.get('limitReached') or c2.get('limitReached')   # a run stopped by the memory budget is not continued
        row.update(twoPartSha256=hc, twoPartIdentical=(hc == ha) if not stopped else None, twoPartError=c2.get('error'))
        if not stopped and hc != ha: problems.append('TWO-PART STATE DIFFERS')
        row.update(referenceSha256=ha, stateBytes=(d / 'old.state').stat().st_size, trainingDeals=a['trainingDeals'], stateVisits=a['stateVisits'], rows=a['rows'], limitReached=a['limitReached'], oldScratchPeakBytes=a.get('scratchPeakBytes'), oldTablePeakBytes=a.get('tablePeakBytes'), oldWallSeconds=a['wallSeconds'])
    row['arms'] = arms; row['verdict'] = 'identical' if not problems else 'DIFFERENT: ' + '; '.join(problems)
    for f in d.iterdir(): f.unlink()
    if problems: bad += 1
    n += 1
    with (out / 'identity.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
    print(name, cname, row['verdict'], flush=True)
for game in games:
    for cname, (opts, threads, mem) in configs.items():
        spec = d / 'spec.json'
        mk = subprocess.run(['node', str(root / 'games48.js'), 'spec', game, str(spec), '977', json.dumps({**opts, 'device': 'cpu'})], capture_output=True, text=True)
        if mk.returncode:
            n += 1
            with (out / 'identity.jsonl').open('a') as f: f.write(json.dumps({'kind': 'game', 'game': game, 'config': cname, 'options': opts, 'specError': mk.stderr[-300:], 'verdict': 'not applicable (the spec builder refused this combination)'}) + '\n')
            continue
        case('game', game, cname, spec, opts, threads, mem, max(2, A.deals // opts.get('batchDeals', 1)))
for name in fixtures:
    base = json.loads((root.parent / 'studies' / (name + '.emfix.json')).read_text())['variants'][0]['nativeSpec']
    for cname, (opts, threads, mem, deals) in fixtureConfigs.items():
        spec = d / 'spec.json'; spec.write_text(json.dumps({**base, **opts}))
        case('fixture', name, cname, spec, opts, threads, mem, max(2, deals // opts.get('batchDeals', 1)))
summary = {'cases': n, 'failures': bad, 'trainingRuns': runs, 'seconds': round(time.time() - t0, 1), 'baselineSha256': sha(old), 'currentSha256': sha(new), 'deals': A.deals}
(out / 'summary.json').write_text(json.dumps(summary, indent=1)); print(json.dumps(summary))
sys.exit(1 if bad else 0)
