#!/usr/bin/env python3
"""EightMax 5.7: complete decision studies against the unchanged 5.6 binary, identical options.
Usage: studybench57.py MWCLI_5.6 MWCLI_5.7 OUTDIR [--threads N] [--reps R]
Each study runs R times per binary, alternating. Reported: wall seconds (best), the sums of training, action-EV and
quality seconds over the study's points, checkpoint seconds, peak resident memory, and a comparison of every per-seed
measurement of the two versions (expected identical: the default trainer and both evaluators compute the same numbers).
Run on an otherwise idle machine. Every run is appended to OUTDIR/runs.jsonl."""
import sys, json, subprocess, time, pathlib, platform, os, hashlib, argparse, resource
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out'); ap.add_argument('--threads', type=int, default=4); ap.add_argument('--reps', type=int, default=1); ap.add_argument('--only', default='')
A = ap.parse_args(); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); out = pathlib.Path(A.out).resolve(); out.mkdir(parents=True, exist_ok=True)
root = pathlib.Path(__file__).resolve().parent.parent; fx = lambda n: str(root / 'studies' / (n + '.emfix.json'))
if (out / 'runs.jsonl').exists(): raise SystemExit('Use a fresh output directory.')
WORK = [   # the eight studies of the 5.6 performance report, same options
 ('akq-river exact, standard preset', 'known-akq-river', ['preset=standard']),
 ('3-player preflop small, sampled, standard preset', 'btn25-open-small', ['preset=standard']),
 ('3-player flop small, exact, standard preset', 'flop3-kings-small', ['preset=standard']),
 ('6-player flop, sampled, standard preset', 'flop6-jack', ['preset=standard']),
 ('3-player flop, sampled, standard preset', 'flop3-kings', ['preset=standard']),
 ('8-handed ICM small, exact, 2 seeds x 2 budgets', 'icm8-bb-call-small', ['seeds=101,102', 'budgets=1000,10000', 'variants=baseline', 'memoryMiB=512', 'timeLimitSeconds=900']),
 ('6-player flop small, exact, 2 seeds x 2 budgets', 'flop6-jack-small', ['seeds=101,102', 'budgets=1000,10000', 'variants=baseline', 'memoryMiB=512', 'timeLimitSeconds=900']),
 ('8-handed ICM, sampled, standard preset', 'icm8-bb-call', ['preset=standard']),
]
if A.only: WORK = [w for w in WORK if any(k in w[0] for k in A.only.split('|'))]
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
env = {'platform': platform.platform(), 'logicalProcessors': os.cpu_count(), 'threadsRequested': A.threads, 'repetitions': A.reps, 'old': sha(old), 'new': sha(new), 'cpu': next((l.split(':')[1].strip() for l in open('/proc/cpuinfo') if l.startswith('model name')), '?'),
       'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'note': 'shared cloud container; not the target Windows i7 / RTX 4060 Ti machine'}
(out / 'environment.json').write_text(json.dumps(env, indent=1)); (out / 'results').mkdir(exist_ok=True); summary = []
def points(d):
    rows = []
    for v in d['variants']:
        for s in v['perSeed']:
            for p in s['budgets']: rows.append({k: p.get(k) for k in ('budgetDeals', 'deals', 'rows', 'frequency', 'ev', 'evStdErr', 'fallbackShare', 'pairedDiffStdErr', 'quality', 'qualityStdErr', 'seatGain', 'seatGainStdErr', 'evaluationSeed', 'qualitySeed', 'evSamples', 'largestUnilateralGain')} | {'variant': v['name'], 'seed': s['seed']})
    return rows
def numbers(x, acc):
    if isinstance(x, list): [numbers(v, acc) for v in x]
    elif isinstance(x, dict): [numbers(v, acc) for k, v in sorted(x.items())]
    elif isinstance(x, (int, float)) and not isinstance(x, bool): acc.append(float(x))
    return acc
def study(cli, fixture, opts, tag):
    res = out / 'results' / (tag + '.json'); t = time.perf_counter()
    peak = out / 'peak_rss'
    if not peak.exists(): subprocess.run(['gcc', '-O2', str(root / 'tools/peak_rss.c'), '-o', str(peak)], check=True)
    p = subprocess.run([str(peak), cli, '--study', fx(fixture), str(res), *opts, 'threads=%d' % A.threads, 'quiet=1', 'checkpoint=off'], capture_output=True, text=True); wall = time.perf_counter() - t
    if p.returncode: return {'error': p.stderr[-400:], 'wallSeconds': wall}
    import re; m = re.search(r'peakRssKiB=(\d+) cpuSeconds=([\d.]+)', p.stderr)
    d = json.load(open(res)); tr = ev = q = 0.0; n = 0
    for v in d['variants']:
        for s in v['perSeed']:
            last = 0.0
            for b in s['budgets']: last = max(last, b.get('trainingSecondsCumulative') or 0); ev += b.get('evSeconds') or 0; q += b.get('qualitySeconds') or 0; n += 1
            tr += last
    return {'wallSeconds': wall, 'trainingSeconds': tr, 'evSeconds': ev, 'qualitySeconds': q, 'points': n, 'peakRssMiB': int(m[1]) / 1024 if m else None, 'cpuSeconds': float(m[2]) if m else None, 'complete': d['completion']['complete'], 'checkpointSeconds': (d['run'].get('checkpoint') or {}).get('secondsWriting'), 'doc': str(res)}
for i, (name, fixture, opts) in enumerate(WORK):
    runs = {'old': [], 'new': []}
    for rep in range(A.reps):
        for arm in (('old', 'new') if (rep + i) % 2 == 0 else ('new', 'old')):
            r = study(old if arm == 'old' else new, fixture, opts, 's%02d-%s-%d' % (i, arm, rep)); r.update(study=name, arm=arm, repetition=rep); runs[arm].append(r)
            with (out / 'runs.jsonl').open('a') as f: f.write(json.dumps(r) + '\n')
            print(name, arm, {k: (round(v, 2) if isinstance(v, float) else v) for k, v in r.items() if k in ('wallSeconds', 'trainingSeconds', 'evSeconds', 'qualitySeconds', 'peakRssMiB', 'error')}, flush=True)
    if any('error' in r for rs in runs.values() for r in rs): summary.append({'study': name, 'error': True}); continue
    bo = min(runs['old'], key=lambda r: r['wallSeconds']); bn = min(runs['new'], key=lambda r: r['wallSeconds'])
    pa, pb = points(json.load(open(bo['doc']))), points(json.load(open(bn['doc']))); na, nb = numbers(pa, []), numbers(pb, [])
    worst = max((abs(x - y) / max(1e-300, abs(x), abs(y)) for x, y in zip(na, nb) if x != y), default=0.0) if len(na) == len(nb) else None
    summary.append({'study': name, 'fixture': fixture, 'options': opts, 'v56': {k: bo[k] for k in ('wallSeconds', 'trainingSeconds', 'evSeconds', 'qualitySeconds', 'peakRssMiB', 'cpuSeconds', 'points')}, 'v57': {k: bn[k] for k in ('wallSeconds', 'trainingSeconds', 'evSeconds', 'qualitySeconds', 'peakRssMiB', 'cpuSeconds', 'points')},
                    'wallRatio56Over57': bo['wallSeconds'] / bn['wallSeconds'], 'evaluationRatio56Over57': ((bo['evSeconds'] + bo['qualitySeconds']) / (bn['evSeconds'] + bn['qualitySeconds'])) if (bn['evSeconds'] + bn['qualitySeconds']) > 0 else None,
                    'measurementPoints': len(pa), 'identicalMeasurements': pa == pb, 'numbersCompared': len(na), 'largestRelativeDifference': worst})
    print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in summary[-1].items() if k not in ('v56', 'v57', 'options')}), flush=True)
(out / 'summary.json').write_text(json.dumps({'environment': env, 'studies': summary}, indent=1))
