#!/usr/bin/env python3
"""EightMax 5.6: what a few independent trainings support -- adversarial validation of the replication verdicts.
Usage: statistical_validation56.py PROBE OUTPUT_DIRECTORY [--trials N] [--seed S]

PROBE is tests/study53_probe.cpp built against the shipped headers: every verdict below is produced by the C++
aggregation the application uses (study52.hpp aggregate(), study_stats55.hpp, study_stats56.hpp). All data and all
truths are generated here with NumPy; reference probabilities come from SciPy. The protocol (scenarios, trial counts,
pass rules) is written to OUTDIR/protocol.json before any trial is run, and every scenario's counts are kept.

What is tested (5.6 additions; the bounded-payoff intervals of 5.5 are re-tested by statistical_validation55.py):
  F  formulas: binomial tail, minimum trainings, undetectable failure rate, order-statistic coverage against SciPy
  R  refusal: with fewer trainings than the stated minimum no best action is ever declared, whatever the data
  N  null scenarios: the typical training does NOT favour the leader by the margin -> how often is it declared?
  A  adversarial training failures: a fraction of trainings is catastrophically wrong -> are observed failures
     always reported and the declaration withheld, and is the unobservable part stated?
  P  power (descriptive): how often a true, large edge is declared at 6-20 trainings
Truth for a declaration: "more than half of all trainings favour the leader over every other action by the margin".
The 5.5 verdict `ranked` (measured strategies + model-based interval) is scored beside it for comparison, against
the population MEAN, which is what its model-based half describes."""
import sys, json, subprocess, pathlib, argparse, math, time, platform
import numpy as np
from scipy import stats
ap = argparse.ArgumentParser(); ap.add_argument('probe'); ap.add_argument('out'); ap.add_argument('--trials', type=int, default=4000); ap.add_argument('--seed', type=int, default=5601)
A = ap.parse_args(); out = pathlib.Path(A.out); out.mkdir(parents=True, exist_ok=True)
if (out / 'results.json').exists(): raise SystemExit('Use a fresh output directory.')
MARGIN = 0.05
def wilson(w, n):
    if n == 0: return [0.0, 1.0]
    z = 1.959963984540054; p = w / n; d = 1 + z * z / n; c = p + z * z / (2 * n); h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)); return [max(0.0, (c - h) / d), min(1.0, (c + h) / d)]
def probe(rows):
    r = subprocess.run([A.probe], input='\n'.join(json.dumps(x) for x in rows) + '\n', capture_output=True, text=True, check=True)
    return [json.loads(l) for l in r.stdout.splitlines() if l.strip()]
# name, kind, n trainings, family, generator of true per-training gaps theta (trials x n), evaluation
BAD = -20.0
def good(rng, T, n): return 1.0 + 0.1 * rng.standard_normal((T, n))
def at_margin(rng, T, n): return MARGIN + 0.5 * rng.standard_normal((T, n))                       # P(theta > margin) = 1/2
def cauchy_margin(rng, T, n): return MARGIN + rng.standard_cauchy((T, n))                          # heavy tails, median = margin
def below_margin(rng, T, n): return 0.04 + 0.002 * rng.standard_normal((T, n))                     # positive, below the margin
def failures(frac):
    def gen(rng, T, n): th = good(rng, T, n); th[rng.random((T, n)) < frac] = BAD; return th
    return gen
SC = [
 dict(name='R_five_good_trainings', group='R', n=5, family=1, gen='good', evaluation='exact'),
 dict(name='R_eight_good_family7', group='R', n=8, family=7, gen='good', evaluation='exact'),
 dict(name='R_one_training', group='R', n=1, family=1, gen='good', evaluation='exact'),
 dict(name='N_margin_n6', group='N', n=6, family=1, gen='at_margin', evaluation='exact'),
 dict(name='N_margin_n10', group='N', n=10, family=1, gen='at_margin', evaluation='exact'),
 dict(name='N_cauchy_n10', group='N', n=10, family=1, gen='cauchy_margin', evaluation='exact'),
 dict(name='N_cauchy_n20', group='N', n=20, family=1, gen='cauchy_margin', evaluation='exact'),
 dict(name='N_below_margin_n8', group='N', n=8, family=1, gen='below_margin', evaluation='exact'),
 dict(name='N_majority_fail_n10', group='N', n=10, family=1, gen='failures', frac=0.6, evaluation='exact'),
 dict(name='N_margin_sampled_rare_tail_n8', group='N', n=8, family=1, gen='at_margin', evaluation='rare_tail', samples=4000),
 dict(name='N_below_margin_sampled_n8', group='N', n=8, family=1, gen='below_margin', evaluation='normal', samples=200000),
 dict(name='A_five_percent_fail_n6', group='A', n=6, family=1, gen='failures', frac=0.05, evaluation='exact'),
 dict(name='A_five_percent_fail_n10', group='A', n=10, family=1, gen='failures', frac=0.05, evaluation='exact'),
 dict(name='A_five_percent_fail_n20', group='A', n=20, family=1, gen='failures', frac=0.05, evaluation='exact'),
 dict(name='A_forty_percent_fail_n10', group='A', n=10, family=1, gen='failures', frac=0.4, evaluation='exact'),
 dict(name='A_five_percent_fail_sampled_n10', group='A', n=10, family=1, gen='failures', frac=0.05, evaluation='normal', samples=20000),
 dict(name='P_good_n6', group='P', n=6, family=1, gen='good', evaluation='exact'),
 dict(name='P_good_n9_family7', group='P', n=9, family=7, gen='good', evaluation='exact'),
 dict(name='P_good_sampled_n8', group='P', n=8, family=1, gen='good', evaluation='normal', samples=20000),
 dict(name='P_good_sampled_rare_tail_n8', group='P', n=8, family=1, gen='good', evaluation='rare_tail', samples=20000),
]
GEN = {'good': good, 'at_margin': at_margin, 'cauchy_margin': cauchy_margin, 'below_margin': below_margin}
protocol = {'tool': 'statistical_validation56.py', 'calculation': 'study-5.6-replication-v1', 'margin': MARGIN, 'trials': A.trials, 'seed': A.seed, 'scenarios': SC, 'payoffRange': 40.0,
 'truthForDeclaration': 'P(theta > margin) > 1/2 for a random training (theta: the true leading gap of that training); the leader is action 0 in every generator unless the data select action 1, in which case the declaration is scored against P(-theta > margin) > 1/2',
 'evaluationModels': {'exact': 'no evaluation error', 'normal': 'N i.i.d. samples of a payoff in [-20, 20] with mean theta and standard deviation 2 (clipped normal)', 'rare_tail': 'N i.i.d. samples: 20 with probability 0.0005, otherwise theta - 0.01 (so the mean is within 0.0001 of theta for |theta| < 1); the rare payoff is usually not drawn'},
 'passRules': {
  'F': 'every formula value agrees with SciPy to 1e-12 (binomial upper tail for n <= 40, minimum trainings, undetectable failure rate) and the order-statistic interval has the coverage it reports',
  'R': 'in every R scenario a best action is declared in 0 trials and the across-trainings verdict is insufficientReplication in every trial',
  'N': 'in every N scenario the Wilson 95% LOWER limit of the frequency of a false declaration is <= 0.05, and of a false across-trainings "ranked" verdict likewise',
  'A': 'in every A scenario: (1) no trial whose trainings contain BOTH a failed and a sound training declares a best action; (2) every such trial with exact evaluation reports trainingsDisagree; (3) the stated undetectable failure rate u(n) = 1 - 0.05^(1/n) is honest: where the true failure fraction is below u(n) the reported bound exceeds it (so nothing rarer is ever implied to be excluded), and where it is at or above u(n) the frequency of trials in which no failure was drawn has a Wilson lower limit <= 0.05; (4) false declarations (truth as above; this covers the trials in which every drawn training failed alike, where nothing can be seen to disagree) have a Wilson lower limit <= 0.05',
  'ruleHistory': 'A first development pass (800 trials, seed 77, kept in validation/5.6/statistics/development-pass) used rule (1) "no trial with a failed training declares". It flagged 7 of 800 trials of A_forty_percent_fail_n10 in which 9 or 10 of the 10 drawn trainings had failed: the trainings then agree with each other and the failed action leads. Such trials are sign-test errors, bounded by rule (4); rules (1)-(3) were restated in terms of what a study can observe (a mixture of failed and sound trainings) before the formal run. A second development pass (800 trials, seed 78) showed that rule (3), then worded "whenever the sound action is declared the bound is >= the true fraction", was itself wrong for a 40% failure rate at n = 10: the bound (26%) is below 40% by design and the 0.6% of studies that draw no failure are exactly the ones the bound allows for. Rule (3) now tests the statement the bound makes. No threshold was changed and no scenario was removed.',
  'P': 'descriptive: declaration frequency reported, no threshold'},
 'environment': platform.platform(), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(out / 'protocol.json').write_text(json.dumps(protocol, indent=1))
fails = []; rng = np.random.default_rng(A.seed)
# ---- F: formulas ----
F = {'binomialTailMaxError': 0.0, 'minimumTrainings': [], 'undetectable': [], 'orderStatistic': []}
rowsF = []
for n in range(1, 41):
    # one exact study with n trainings, s of them above the margin: read back the reported p-value and rates
    for s in sorted(set([0, n // 2, n - 1, n])):
        vals = [[1.0, 0.0]] * s + [[0.0, 0.0]] * (n - s)   # gap 1 (certifies the margin) or 0 (does not)
        rowsF.append(({'n': n, 's': s}, {'values': vals, 'errors': [[0, 0]] * n, 'pairErrors': [[[0, 0], [0, 0]]] * n, 'method': 'exact', 'independent': 1, 'family': 1, 'margin': MARGIN}))
docs = probe([r for _, r in rowsF])
for (meta, _), d in zip(rowsF, docs):
    r = d['confidence']['replication']; n, s = meta['n'], meta['s']
    if d['leader']['byEv'] != '0': continue
    ref = float(stats.binom.sf(s - 1, n, 0.5)); F['binomialTailMaxError'] = max(F['binomialTailMaxError'], abs(r['signTestPMargin'] - ref))
    refmin = next(k for k in range(1, 80) if 0.5 ** k <= 0.4 * 0.05)
    if r['minimumTrainingsForStatementAboutTypicalTraining'] != refmin: fails.append('F minimum trainings n=%d' % n)
    if abs(r['undetectableFailureRate'] - (1 - 0.05 ** (1 / n))) > 1e-12: fails.append('F undetectable n=%d' % n)
    mi = r['medianGapInterval']
    if mi:
        j = mi['orderStatistic']; cov = 1 - 2 * float(stats.binom.cdf(j - 1, n, 0.5))
        if abs(cov - mi['coverageAtLeast']) > 1e-12 or cov < 0.95 - 1e-12: fails.append('F order statistic n=%d' % n)
        if s == n: F['orderStatistic'].append({'n': n, 'rank': j, 'coverage': cov})
    elif n >= 6 and s == n: fails.append('F no median interval at n=%d' % n)
if F['binomialTailMaxError'] > 1e-12: fails.append('F binomial tail')
F['minimumTrainingsByFamily'] = {str(f): next(k for k in range(1, 80) if 0.5 ** k <= 0.4 * 0.05 / f) for f in (1, 2, 3, 6, 9, 12, 20, 40)}
F['undetectableFailureRateByTrainings'] = {str(n): 1 - 0.05 ** (1 / n) for n in (1, 2, 3, 5, 6, 8, 10, 15, 20, 30, 50)}
# ---- scenarios ----
R = 40.0   # declared width of one action value's range ([-20, 20]); the aggregator doubles it for a difference
def evaluate(rng, theta, kind, N):
    """Returns estimate, standard error of the estimate for each (trial, training)."""
    T, n = theta.shape
    if kind == 'exact': return theta.copy(), np.zeros_like(theta)
    est = np.empty_like(theta); se = np.empty_like(theta)
    for t in range(T):
        for r in range(n):
            th = theta[t, r]
            if kind == 'normal': x = np.clip(th + 2.0 * rng.standard_normal(N), -20, 20)
            else:
                x = np.full(N, min(20.0, max(-20.0, th - 0.01))); x[rng.random(N) < 0.0005] = 20.0
            est[t, r] = x.mean(); se[t, r] = x.std(ddof=1) / math.sqrt(N)
    return est, se
results = []
for sc in SC:
    T = A.trials if sc['evaluation'] == 'exact' else max(400, A.trials // 8)
    gen = failures(sc['frac']) if sc['gen'] == 'failures' else GEN[sc['gen']]
    theta = gen(rng, T, sc['n']); N = sc.get('samples', 0); est, se = evaluate(rng, theta, sc['evaluation'], N)
    rows = []
    for t in range(T):
        row = {'values': [[float(est[t, r]), 0.0] for r in range(sc['n'])], 'errors': [[float(se[t, r]), 0.0] for r in range(sc['n'])],
               'pairErrors': [[[0.0, float(se[t, r])], [float(se[t, r]), 0.0]] for r in range(sc['n'])], 'method': 'exact' if sc['evaluation'] == 'exact' else 'sampled', 'independent': 1, 'family': sc['family'], 'margin': MARGIN}
        if sc['evaluation'] != 'exact': row.update({'ranges': [R] * sc['n'], 'within': [True] * sc['n'], 'sampleCounts': [N] * sc['n'], 'samples': N})
        rows.append(row)
    docs = probe(rows)
    # population truths, by Monte Carlo on the generator (independent draw)
    big = gen(np.random.default_rng(A.seed + 99), 200000 // sc['n'], sc['n']).ravel()
    p0 = float((big > MARGIN).mean()); p1 = float((-big > MARGIN).mean()); mean_gap = float(big.mean())
    true0 = p0 > 0.5 + 0.01; true1 = p1 > 0.5 + 0.01      # scenarios at exactly 1/2 are nulls by construction
    if sc['gen'] in ('at_margin', 'cauchy_margin'): true0 = true1 = False
    c = dict(declared=0, falseDeclared=0, acrossRanked=0, falseAcrossRanked=0, insufficient=0, disagree=0, uncalibrated=0, ranked55=0, ranked55FalseForMean=0, failureObserved=0, mixedObserved=0, failureObservedAndDeclared=0, failureObservedNotReported=0, declaredWithUnderstatedFailureBound=0, smallEdge=0, unresolved=0)
    for t, d in enumerate(docs):
        rep = d['confidence']['replication']; lead = d['leader']['byEv']; truth = true0 if lead == '0' else true1
        decl = d['bestAction']['declared']; ar = rep['verdict'] == 'ranked'
        c['declared'] += decl; c['falseDeclared'] += decl and not truth; c['acrossRanked'] += ar; c['falseAcrossRanked'] += ar and not truth
        c['insufficient'] += rep['verdict'] == 'insufficientReplication'; c['disagree'] += rep['verdict'] == 'trainingsDisagree'; c['uncalibrated'] += rep['verdict'] == 'uncalibrated'; c['smallEdge'] += rep['verdict'] == 'smallEdge'; c['unresolved'] += rep['verdict'] == 'unresolved'
        r55 = d['verdict'] == 'ranked'; c['ranked55'] += r55; c['ranked55FalseForMean'] += r55 and not ((mean_gap if lead == '0' else -mean_gap) > MARGIN)
        if sc['gen'] == 'failures':
            seen = bool((theta[t] == BAD).any()); mixed = seen and bool((theta[t] != BAD).any()); c['failureObserved'] += seen; c['mixedObserved'] += mixed; c['failureObservedAndDeclared'] += mixed and decl
            c['failureObservedNotReported'] += mixed and sc['evaluation'] == 'exact' and rep['verdict'] != 'trainingsDisagree'
            c['declaredWithUnderstatedFailureBound'] += decl and lead == '0' and rep['undetectableFailureRate'] < sc['frac']
    s = {'scenario': sc['name'], 'group': sc['group'], 'spec': sc, 'trials': T, 'populationShareFavouringAction0ByMargin': p0, 'populationMeanGap': mean_gap, 'declarationTrueForAction0': true0, 'counts': {k: int(v) for k, v in c.items()},
         'declared': {'frequency': c['declared'] / T, 'wilson95': wilson(c['declared'], T)}, 'falseDeclaration': {'frequency': c['falseDeclared'] / T, 'wilson95': wilson(c['falseDeclared'], T)},
         'falseAcrossRanked': {'frequency': c['falseAcrossRanked'] / T, 'wilson95': wilson(c['falseAcrossRanked'], T)},
         'verdict55Ranked': {'frequency': c['ranked55'] / T, 'falseForPopulationMean': c['ranked55FalseForMean'] / T}}
    results.append(s)
    g = sc['group']
    if g == 'R' and (c['declared'] != 0 or c['insufficient'] != T): fails.append('R ' + sc['name'])
    if g == 'N' and (s['falseDeclaration']['wilson95'][0] > 0.05 or s['falseAcrossRanked']['wilson95'][0] > 0.05): fails.append('N ' + sc['name'])
    if g == 'A':
        if c['failureObservedAndDeclared']: fails.append('A declared although failed and sound trainings were both observed: ' + sc['name'])
        if c['failureObservedNotReported']: fails.append('A observed failure not reported: ' + sc['name'])
        u = 1 - 0.05 ** (1 / sc['n']); unseen = T - c['failureObserved']; s['undetectableFailureRate'] = u; s['noFailureDrawn'] = {'frequency': unseen / T, 'wilson95': wilson(unseen, T)}
        if sc['frac'] >= u and s['noFailureDrawn']['wilson95'][0] > 0.05: fails.append('A failures at or above the stated rate went unseen too often: ' + sc['name'])
        if sc['frac'] < u and c['declaredWithUnderstatedFailureBound']: fails.append('A understated failure bound: ' + sc['name'])
        if s['falseDeclaration']['wilson95'][0] > 0.05: fails.append('A false declaration: ' + sc['name'])
    print('%-34s T=%-5d declared %.4f  false declaration %.4f  5.5 ranked %.4f (false for the mean %.4f)  insufficient %d  disagree %d' % (sc['name'], T, s['declared']['frequency'], s['falseDeclaration']['frequency'], s['verdict55Ranked']['frequency'], s['verdict55Ranked']['falseForPopulationMean'], c['insufficient'], c['disagree']), flush=True)
doc = {'protocol': protocol, 'formulas': F, 'scenarios': results, 'failures': fails, 'passed': not fails}
(out / 'results.json').write_text(json.dumps(doc, indent=1))
print(json.dumps({'passed': not fails, 'failures': fails, 'formulaMaxError': F['binomialTailMaxError'], 'minimumTrainingsByFamily': F['minimumTrainingsByFamily']}))
sys.exit(0 if not fails else 1)
