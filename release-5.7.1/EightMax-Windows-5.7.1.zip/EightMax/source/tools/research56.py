#!/usr/bin/env python3
"""EightMax 5.6 fixed-plan convergence comparison.
Usage: research56.py BASELINE_5.5_CLI CURRENT_5.6_CLI OUTPUT_DIRECTORY [--games a,b] [--seeds N] [--first-seed S] [--analyze-only]

Arms (identical game, identical paired training seed, one training thread, 128 MiB):
  baseline55   the unchanged 5.5 binary, default trainer
  river55      the unchanged 5.5 binary, "opponentEnumeration":"river" (the 5.5 experimental candidate)
  default56    the 5.6 binary, default trainer (same estimator and same numbers per deal as 5.5; faster traversal)
  river56      the 5.6 binary, "opponentEnumeration":"river" (the 5.5 candidate on the 5.6 engine)
  cross56      the 5.6 binary, "opponentEnumeration":"river-cross" (THE 5.6 candidate: one shared walk per deal on
               final-street games; on earlier-street games every seat's traversal also updates the other seats'
               final-street information sets with weight 1/n)

The plan below is written to plan.json BEFORE any measurement and the script refuses to reuse an output directory.
Every arm of a (game, seed) is trained in rotated order; every checkpoint is evaluated by the 5.6 binary's exact
all-seat best response (NashConv inside the abstraction) in a separate process. Nothing is stopped or selected on
results; every row goes to raw.jsonl as it is produced, including rows of games that later turn out unfavourable.
--games lets several processes share the plan (one output directory per process, merged by --analyze-only DIR...)."""
import sys, pathlib, json, subprocess, time, os, hashlib, math, statistics, platform, re, argparse
ap = argparse.ArgumentParser(); ap.add_argument('old'); ap.add_argument('new'); ap.add_argument('out', nargs='+'); ap.add_argument('--games', default=''); ap.add_argument('--seeds', type=int, default=60); ap.add_argument('--first-seed', type=int, default=1001); ap.add_argument('--analyze-only', action='store_true')
A = ap.parse_args(); old, new = (str(pathlib.Path(x).resolve()) for x in (A.old, A.new)); root = pathlib.Path(__file__).resolve().parent
ARMS = {'baseline55': ('old', {}), 'river55': ('old', {'opponentEnumeration': 'river'}), 'default56': ('new', {}), 'river56': ('new', {'opponentEnumeration': 'river'}), 'cross56': ('new', {'opponentEnumeration': 'river-cross'})}
GAMES = ['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'flop6', 'final8', 'bubble4']
CHANGED = ['hu-river', 'hu-turn', 'river3-chip', 'turn4']     # games with final-street betting: the candidates change the traversal
DEALS = [4000, 20000, 100000]; SECONDS = [0.1, 0.5]
CONTRASTS = [('default56', 'baseline55'), ('cross56', 'default56'), ('cross56', 'baseline55'), ('cross56', 'river55'), ('river55', 'baseline55'), ('river56', 'default56')]
FAMILY = [c for c in CONTRASTS[:4]]                           # the declared family; the last two are descriptive replications
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def body_sha(p):   # an EMMW4 state without its JSON header (the header carries the study id, which hashes the trainer options)
    import struct; b = pathlib.Path(p).read_bytes(); return hashlib.sha256(b[12 + struct.unpack_from('<I', b, 8)[0]:]).hexdigest() if b[:5] == b'EMMW4' else None
def plan_for(games):
    return {'games': games, 'allGames': GAMES, 'gameRoles': {'hu-river': 'heads-up river', 'hu-turn': 'heads-up turn and river', 'river3-chip': 'three-player river with side pots', 'turn4': 'four-player turn and river',
            'flop6': 'six-player (multiway) flop, all-in or fold', 'final8': 'eight-handed ICM final table, push/fold', 'bubble4': 'four-player ICM bubble, push/fold'},
            'seeds': list(range(A.first_seed, A.first_seed + A.seeds)), 'arms': {k: {'binary': '5.5' if v[0] == 'old' else '5.6', 'trainerOptions': v[1]} for k, v in ARMS.items()},
            'deals': DEALS, 'trainingSeconds': SECONDS, 'threads': 1, 'memoryMiB': 128, 'evaluatorCacheMiB': 1024,
            'evaluation': 'exact all-seat best response (NashConv inside the abstraction; with more than two players it is not exploitability), CPU, 5.6 binary, separate process from training',
            'contrasts': [{'candidate': c, 'reference': r, 'inFamily': (c, r) in FAMILY} for c, r in CONTRASTS],
            'primaryMetric': 'paired difference of exact NashConv at the largest equal-wall-clock training budget (%.1f s)' % SECONDS[-1],
            'primaryFamily': 'default56 vs baseline55 and cross56 vs default56 at %.1f s in each of the %d games: %d contrasts, Bonferroni over %d' % (SECONDS[-1], len(GAMES), 2 * len(GAMES), 2 * len(GAMES)),
            'secondaryFamily': 'all %d declared contrasts x %d games x %d budgets = %d, Bonferroni over %d (reported for every contrast; the two descriptive replications use the same penalty)' % (len(FAMILY), len(GAMES), len(DEALS) + len(SECONDS), len(FAMILY) * len(GAMES) * (len(DEALS) + len(SECONDS)), len(FAMILY) * len(GAMES) * (len(DEALS) + len(SECONDS))),
            'tests': 'exact two-sided sign test on the paired differences (distribution-free for the median) AND paired Student-t interval (model-based), each Bonferroni-adjusted over the stated family; "better"/"worse" needs both on the same side; pairs with equal NashConv are "identical"',
            'stoppingRule': 'fixed: every arm x budget x seed of the plan is run once; no interim analysis; a failed process aborts the run and the directory is kept as it is',
            'engineClaimRule': 'The 5.6 default trainer is reported as closer to equilibrium at equal time on a game only where default56 vs baseline55 is "better" in the primary family. At equal deals default56 must reproduce baseline55 exactly (identical NashConv and identical checkpoint files); any difference is a defect.',
            'promotionRule': 'cross56 replaces the default trainer only if ALL hold: (P1) the independent expected-increment check (independent_cfr56.py) passes for river-cross on hu-river, river3-chip, hu-turn and turn4; (P2) cross56 vs default56 is "better" in the primary family in every game where it changes the traversal (%s); (P3) cross56 vs default56 is "worse" in no contrast of the secondary family, and in the games it does not change (%s) its equal-deal checkpoints are identical to default56 in every table byte (the state file without its JSON header, which carries a study id derived from the trainer options); (P4) regression limit: at no equal-time budget of any game is the mean NashConv of cross56 more than 5%% above that of default56; (P5) deterministic continuation and checkpoint tests pass with the candidate enabled. Otherwise the default is unchanged and the candidate stays opt-in.' % (', '.join(CHANGED), ', '.join(g for g in GAMES if g not in CHANGED)),
            'limitations': 'Small games with exact evaluation only. NashConv is exact inside each abstraction. Equal-time budgets are wall-clock on a shared four-core container, with up to two game streams running at once on separate cores: timing noise enters those contrasts but is spread over the rotated arm order.',
            'pilot': 'Before this plan was written, single-seed pilot runs (seed 901, 50,000 deals, all five games then available) were looked at to check that the candidates run; they are kept in validation/5.6/convergence/pilot and their seeds are not reused here.',
            'environment': platform.platform(), 'logicalProcessors': os.cpu_count(), 'baselineSha256': sha(old), 'currentSha256': sha(new), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
def run(out, games):
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'raw.jsonl').exists() or (out / 'plan.json').exists(): raise SystemExit('Use a fresh output directory; old results must not be mixed.')
    plan = plan_for(games); (out / 'plan.json').write_text(json.dumps(plan, indent=1))
    peak = out / 'peak_rss'; subprocess.run(['gcc', '-O2', str(root / 'peak_rss.c'), '-o', str(peak)], check=True)
    def call(cli, args, env=None):
        t = time.perf_counter(); p = subprocess.run([str(peak), cli, *map(str, args)], capture_output=True, text=True, timeout=7200, env=env)
        if p.returncode: raise RuntimeError(p.stderr[-800:])
        m = re.search(r'peakRssKiB=(\d+) cpuSeconds=([\d.]+)', p.stderr); return json.loads(p.stdout), time.perf_counter() - t, float(m[2]) if m else None, int(m[1]) / 1024 if m else None
    for game in games:
        for seed in plan['seeds']:
            order = list(ARMS); order = order[seed % len(order):] + order[:seed % len(order)]
            for arm in order:
                which, opts = ARMS[arm]; cli = old if which == 'old' else new
                d = out / 'work' / game / str(seed) / arm; d.mkdir(parents=True, exist_ok=True); sp = d / 'spec.json'; st = d / 'state'; q = d / 'query.json'
                subprocess.run(['node', str(root / 'games48.js'), 'spec', game, str(sp), str(seed), json.dumps({**opts, 'batchDeals': 1, 'device': 'cpu'})], check=True, capture_output=True)
                q.write_text(json.dumps({'method': 'exact', 'device': 'cpu', 'threads': 1, 'timeLimitMs': 1800000, 'maxVisits': 2000000000, 'memoryMiB': 1024}))
                done = 0
                for kind, budgets in [('deals', DEALS), ('time', SECONDS)]:
                    for budget in budgets:
                        if kind == 'time': args = [sp, 10000000, 1, str(st) + '.next', 128]; env = {**os.environ, 'EM_TRAIN_CANCEL_AFTER_MS': str(round(budget * 1000))}
                        else: args = [sp, budget - done, 1, str(st) + '.next', 128] + ([st] if done else []); env = None
                        info, sec, cpu, mem = call(cli, args, env); os.replace(str(st) + '.next', st)
                        gain, evsec, evcpu, evmem = call(new, ['--gain', sp, st, q, 128])
                        if kind == 'deals': done = budget
                        row = {'game': game, 'seed': seed, 'arm': arm, 'kind': kind, 'budget': budget, 'deals': info['trainingDeals'], 'stateVisits': info['stateVisits'], 'trainingSeconds': info['wallSeconds'], 'trainingProcessSeconds': sec, 'trainingCpuSeconds': cpu, 'trainingPeakRssMiB': mem,
                               'rows': info.get('rows'), 'tableMiB': info.get('tableMiB'), 'evaluationSeconds': evsec, 'evaluationCpuSeconds': evcpu, 'evaluationPeakRssMiB': evmem, 'nashConv': gain['nashConv'], 'exploitability': gain.get('exploitability'),
                               'largestUnilateralGain': gain['largestUnilateralGain'], 'seatGains': [s['gain'] for s in gain['seats']], 'checkpointSha256': sha(st), 'checkpointBodySha256': body_sha(st), 'memoryStopped': info.get('limitReached', False), 'trainer': info.get('trainer')}
                        with (out / 'raw.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
                st.unlink(missing_ok=True)
            print(game, seed, flush=True)
    (out / 'finished').write_text(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
def analyze(dirs, dest):
    from scipy import stats
    rows = []; plans = []
    for d in dirs:
        d = pathlib.Path(d); plans.append(json.loads((d / 'plan.json').read_text())); rows += [json.loads(l) for l in (d / 'raw.jsonl').read_text().splitlines() if l.strip()]
    games = [g for g in GAMES if any(r['game'] == g for r in rows)]; seeds = plans[0]['seeds']
    nsec = len(FAMILY) * len(GAMES) * (len(DEALS) + len(SECONDS)); nprim = 2 * len(GAMES); comp = []
    for game in games:
        for cand, ref in CONTRASTS:
            for kind, budgets in [('deals', DEALS), ('time', SECONDS)]:
                for budget in budgets:
                    B = {r['seed']: r for r in rows if (r['game'], r['arm'], r['kind'], r['budget']) == (game, ref, kind, budget)}; C = {r['seed']: r for r in rows if (r['game'], r['arm'], r['kind'], r['budget']) == (game, cand, kind, budget)}
                    ss = [s for s in seeds if s in B and s in C]
                    if len(ss) < 3: continue
                    dif = [C[s]['nashConv'] - B[s]['nashConv'] for s in ss]; n = len(dif); mean = statistics.mean(dif); sd = statistics.stdev(dif)
                    neg = sum(x < 0 for x in dif); pos = sum(x > 0 for x in dif); nz = neg + pos; p = float(stats.binomtest(min(neg, pos), nz, .5).pvalue) if nz else 1.0
                    primary = kind == 'time' and budget == SECONDS[-1] and (cand, ref) in FAMILY[:2]
                    def verdict(fam):
                        half = float(stats.t.ppf(1 - .05 / (2 * fam), n - 1)) * sd / math.sqrt(n); padj = min(1.0, p * fam)
                        v = 'identical' if not nz else 'better' if padj < .05 and neg > pos and mean + half < 0 else 'worse' if padj < .05 and pos > neg and mean - half > 0 else 'unresolved'
                        return v, [mean - half, mean + half], padj
                    vs, ivs, ps = verdict(nsec); row = {'game': game, 'candidate': cand, 'reference': ref, 'kind': kind, 'budget': budget, 'n': n, 'referenceMean': statistics.mean(B[s]['nashConv'] for s in ss), 'candidateMean': statistics.mean(C[s]['nashConv'] for s in ss),
                           'referenceMedian': statistics.median(B[s]['nashConv'] for s in ss), 'candidateMedian': statistics.median(C[s]['nashConv'] for s in ss), 'difference': mean, 'meanRatio': statistics.mean(C[s]['nashConv'] for s in ss) / max(1e-300, statistics.mean(B[s]['nashConv'] for s in ss)),
                           'seedsCandidateLower': neg, 'seedsCandidateHigher': pos, 'signTestP': p, 'inFamily': (cand, ref) in FAMILY, 'secondary': {'familySize': nsec, 'tInterval95': ivs, 'signTestPBonferroni': ps, 'verdict': vs},
                           'referenceDealsMean': statistics.mean(B[s]['deals'] for s in ss), 'candidateDealsMean': statistics.mean(C[s]['deals'] for s in ss), 'referenceSecondsMean': statistics.mean(B[s]['trainingSeconds'] for s in ss), 'candidateSecondsMean': statistics.mean(C[s]['trainingSeconds'] for s in ss),
                           'checkpointsIdentical': sum(C[s]['checkpointSha256'] == B[s]['checkpointSha256'] for s in ss), 'checkpointBodiesIdentical': sum(C[s].get('checkpointBodySha256') is not None and C[s].get('checkpointBodySha256') == B[s].get('checkpointBodySha256') for s in ss)}
                    if primary: vp, ivp, pp = verdict(nprim); row['primary'] = {'familySize': nprim, 'tInterval95': ivp, 'signTestPBonferroni': pp, 'verdict': vp}
                    comp.append(row)
    def find(game, cand, ref, kind, budget): return next((c for c in comp if (c['game'], c['candidate'], c['reference'], c['kind'], c['budget']) == (game, cand, ref, kind, budget)), None)
    engine = {g: (find(g, 'default56', 'baseline55', 'time', SECONDS[-1]) or {}).get('primary', {}).get('verdict') for g in games}
    eqdeal = {g: all((find(g, 'default56', 'baseline55', 'deals', b) or {'checkpointsIdentical': -1, 'n': 0})['checkpointsIdentical'] == (find(g, 'default56', 'baseline55', 'deals', b) or {'n': 0})['n'] for b in DEALS) for g in games}
    p2 = {g: (find(g, 'cross56', 'default56', 'time', SECONDS[-1]) or {}).get('primary', {}).get('verdict') for g in games if g in CHANGED}
    worse = [(c['game'], c['kind'], c['budget']) for c in comp if (c['candidate'], c['reference']) == ('cross56', 'default56') and c['secondary']['verdict'] == 'worse']
    noop = {g: all((find(g, 'cross56', 'default56', 'deals', b) or {'checkpointBodiesIdentical': -1, 'n': 0})['checkpointBodiesIdentical'] == (find(g, 'cross56', 'default56', 'deals', b) or {'n': 0})['n'] for b in DEALS) for g in games if g not in CHANGED}
    over = [(c['game'], c['budget'], c['meanRatio']) for c in comp if (c['candidate'], c['reference']) == ('cross56', 'default56') and c['kind'] == 'time' and c['meanRatio'] > 1.05]
    decision = {'engine': {'primaryVerdictByGame': engine, 'equalDealCheckpointsIdenticalByGame': eqdeal, 'gamesBetterAtEqualTime': [g for g, v in engine.items() if v == 'better']},
                'promotion': {'P2_primaryVerdictByChangedGame': p2, 'P2_met': bool(p2) and all(v == 'better' for v in p2.values()) and set(p2) == set(CHANGED), 'P3_worseContrasts': worse, 'P3_unchangedGamesIdentical': noop, 'P3_met': not worse and all(noop.values()),
                              'P4_meanRatioAbove1.05': over, 'P4_met': not over, 'note': 'P1 (independent expected-increment check) and P5 (checkpoint determinism) are decided by their own tests; see CONVERGENCE-5.6.md.'},
                'complete': all(len([r for r in rows if r['game'] == g]) == len(seeds) * len(ARMS) * (len(DEALS) + len(SECONDS)) for g in GAMES), 'gamesPresent': games, 'checkpoints': len(rows)}
    dest = pathlib.Path(dest); dest.mkdir(parents=True, exist_ok=True)
    (dest / 'comparisons.json').write_text(json.dumps({'plans': plans, 'decision': decision, 'comparisons': comp}, indent=1))
    with (dest / 'raw-merged.jsonl').open('w') as f:
        for r in rows: f.write(json.dumps(r) + '\n')
    print(json.dumps(decision, indent=1))
if A.analyze_only: analyze(A.out[:-1], A.out[-1])
else:
    games = [g for g in A.games.split(',') if g] or GAMES
    for g in games:
        if g not in GAMES: raise SystemExit('unknown game ' + g)
    run(pathlib.Path(A.out[0]).resolve(), games)
