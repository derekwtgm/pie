"""Bounded representative reruns with original fixtures and explicit reduced plans.
Uses an immutable, fingerprinted executable; every result retains that identity.
"""
import json,pathlib,subprocess,sys,platform,time
cli=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]).resolve();src=pathlib.Path(__file__).resolve().parents[1];out.mkdir(parents=True,exist_ok=True)
records=[]
ids=['known-akq-river','flop3-kings-small-undertrained','btn25-open','flop3-kings','flop6-jack','icm8-bb-call','btn25-open-small','flop3-kings-small','flop6-jack-small','icm8-bb-call-small']
for id in ids:
 original=id.removesuffix('-undertrained');f=json.loads((src/'studies'/f'{original}.emfix.json').read_text());plan=json.loads(json.dumps(f));plan['study']['threads']=2
 if id=='known-akq-river':plan['study']['seeds']=f['study']['seeds'][:5]
 elif id.endswith('-undertrained'):plan['variants']=f['variants'][:1];plan['study']['seeds']=f['study']['seeds'][:3];plan['study']['budgetsDeals']=[100,200,400]
 else:
  plan['study']['seeds']=f['study']['seeds'][:3];plan['study']['budgetsDeals']=[2000,20000,100000];plan['study']['memoryMiB']=256;plan['study']['timeLimitSeconds']=90
  # Preserve all variants and their games. Reduced evaluation targets are recorded
  # in the saved plan and JSON; these runs are NOT equal-budget 5.2 performance comparisons.
  if plan['study']['ev']['method']=='sampled':plan['study']['ev']['samples']=10000
  if plan['study']['quality']['method']=='sampled':plan['study']['quality'].update(samples=2000,selectionSamples=100)
  for v in plan['variants']:
   if v.get('ev',{}).get('method')=='sampled':v['ev']['samples']=10000
   if v.get('quality',{}).get('method')=='sampled':v['quality'].update(samples=2000,selectionSamples=100)
 input=out/f'{id}.plan.json';res=out/f'{id}.result.json';log=out/f'{id}.summary.txt';input.write_text(json.dumps(plan,indent=1)+'\n');start=time.time()
 r=subprocess.run([str(cli),'--study',str(input),str(res),'quiet=1'],capture_output=True,text=True,timeout=600);log.write_text(r.stdout+'\n'+r.stderr);records.append({'id':id,'originalFixture':original,'exit':r.returncode,'wallSeconds':time.time()-start,'result':res.name,'plan':input.name});print(id,r.returncode,round(time.time()-start,2),flush=True)
 if r.returncode:raise RuntimeError(r.stderr)
(out/'runs.json').write_text(json.dumps({'platform':platform.platform(),'executable':str(cli),'runs':records},indent=2)+'\n')
