// EightMax 5.2: decision studies in the interface (Study tab) and in the export workflow.
//
// EM.study: pure functions shared with the tests and the report tools.
//   validateResult(doc)      checks an "EightMax study result" document
//   headline(variant)        the recommended action or mix with its EV gap and uncertainty, as data
//   rows(doc)                one flat row per variant, budget and action (what the tables and the CSV show)
//   toCSV(doc)               the CSV export (same numbers as the JSON, full precision)
//   completeFixture(fx)      rebuilds every variant's game and native specification from its Multiway form
//                            state with the application's own code (EM.multiwaySpotConfig -> EM.MultiwayGame)
//                            and reports whether it equals the specification stored in the fixture
// EM.studyPanel(root, deps): the Study tab. Studies are run by the desktop host (POST /api/study/start; the
// same code as `mwcli --study`); the page only polls. Every number shown is read from the result document,
// which is also what "Export JSON" writes, so the display and the export cannot disagree.
(function (EM) {
'use strict';
const S = EM.study = {};
const isNum = v => typeof v === 'number' && Number.isFinite(v);
S.fmt = (v, d = 3) => !isNum(v) ? '–' : (v < 0 ? '−' : '') + Math.abs(v).toFixed(d);
S.signed = (v, d = 3) => !isNum(v) ? '–' : (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(d);
S.pct = (v, d = 1) => !isNum(v) ? '–' : (100 * v).toFixed(d) + '%';
S.ci = (c, d = 3) => Array.isArray(c) && c.length === 2 && c.every(isNum) ? '[' + S.signed(c[0], d) + ', ' + S.signed(c[1], d) + ']' : 'not estimable';
S.deals = v => !isNum(v) ? '–' : String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
// Calculation migration deliberately preserves all measurements and the original
// confidence fields. Shared 5.2 evaluation streams do not identify training-mean
// uncertainty; only exact evaluations support recomputing that interval.
// 5.5: the calibrated statement is the bounded-payoff conditional interval (native study_stats55.hpp).
// The 5.3 Student-t calculation remains the model-based interval across trainings.
S.CALCULATION = 'study-5.5-bounded-eb-v1';
S.MODEL_CALCULATION = 'study-5.3-tfloor-bonferroni-v1';
S.REVIEW = 'study-5.5-legacy-review-v1';
S.REASONS = {noPayoffBound:'No proven payoff bound accompanies these evaluations (the result was produced before 5.5). Only a normal-approximation interval exists; it under-covers when large payoffs are rare. Re-run the study for a calibrated statement.',
  payoffBoundViolated:'An evaluated sample lay outside the declared payoff bound; the bounded-payoff interval was withdrawn.', tooFewSamples:'Fewer than two evaluation samples.',
  sampledQuality:'Sampled quality has no finite-sample bound; use exact quality for a calibrated quality statement.', evaluationErrorUnavailable:'An evaluation standard error is unavailable.', noData:'No data.'};
// 5.5 review of a 5.3/5.4 document: measurements and model-based intervals are kept, but sampled evaluations carry no
// payoff bound, so their conditional intervals are relabelled as normal approximations and every ranking, near-tie,
// small-edge or tolerance statement that rested on them is withdrawn (kept under legacyConfidence55).
S.review55 = function(input, copied) {
  const d=copied?input:JSON.parse(JSON.stringify(input));
  d.recalculation55={sourceCalculationVersion:input.calculationVersion,sourceVersion:input.recalculation?.sourceVersion??input.version,sourceBuild:input.recalculation?.sourceBuild??input.build,
    note:'Confidence reviewed in 5.5. This result was produced before bounded-payoff intervals existed. Exact evaluations keep their statements. Sampled evaluations keep every measurement and the model-based intervals, but no calibrated conditional interval can be formed without a payoff bound, so rankings and tolerance claims based on them are withdrawn. Re-run the study for calibrated intervals.'};
  d.calculationVersion=S.REVIEW;
  for(const v of d.variants){let first=null;
    for(const b of v.budgets){
      const pts=v.perSeed.map(p=>p.budgets.find(x=>x.budgetDeals===b.budgetDeals)).filter(p=>p&&p.ev&&p.ev.length);
      const exact=pts.length>0&&pts.every(p=>p.evMethod==='exact'), qexact=pts.filter(p=>isNum(p.quality)).every(p=>p.qualityKind==='exact');
      const strip=st=>{if(!st||typeof st!=='object')return;st.normalApproxConditionalCi95=st.conditionalEvaluationCi95??null;st.conditionalCalibrated=exact;st.conditionalMethod=exact?'exact evaluation (no sampling error)':'none';if(!exact){st.conditionalEvaluationCi95=null;st.conditionalUncalibratedReason='noPayoffBound';}};
      for(const a of b.actions||[])strip(a.ev);strip(b.gap);for(const g of b.pairwiseGaps||[])strip(g.difference);
      b.confidence={evaluationCalibrated:exact,evaluationMethod:exact?'exact evaluation':'none',qualityCalibrated:!!b.quality&&qexact,acrossTrainings:'model-based Student t; supporting evidence only',verdictFromModelBasedIntervalsAlone:b.verdict};
      if(!exact){b.confidence.reason='noPayoffBound';b.confidence.reasonText=S.REASONS.noPayoffBound;
        if(['ranked','nearTie','smallEdge','unresolved'].includes(b.verdict)){b.legacyConfidence55={verdict:b.verdict,verdictText:b.verdictText,meetsTolerance:b.meetsTolerance};b.verdict='uncalibrated';b.verdictText='No ranking is stated: the evaluation uncertainty is not calibrated. '+S.REASONS.noPayoffBound;}
        if(b.toleranceChecks)b.toleranceChecks.gapResolvedToTolerance=false;b.meetsTolerance=false;}
      if(isNum(d.tolerance.quality)&&!qexact){if(b.toleranceChecks)b.toleranceChecks.qualityWithinTolerance=false;b.meetsTolerance=false;}
      if(b.meetsTolerance&&first===null)first=b.budgetDeals;
    }
    if(v.firstBudgetMeetingTolerance!=null&&v.firstBudgetMeetingTolerance!==first){v.legacyToleranceSummary55=v.toleranceSummary;v.firstBudgetMeetingTolerance=first;v.trainingSecondsAtFirstBudgetMeetingTolerance=first===null?null:v.budgets.find(b=>b.budgetDeals===first).trainingSecondsMean;
      v.toleranceSummary=first===null?'tolerance not established after the 5.5 confidence review (evaluation uncertainty not calibrated)':'tolerance first met at '+first+' sampled deals after the 5.5 confidence review';}
  }
  return d;
};
S.critical = function(df, alpha=.05) {
  if (!(df>=1 && alpha>0 && alpha<1)) return null;
  // Lanczos log gamma, independent implementation checked against native/SciPy.
  const lg=z=>{const c=[676.5203681218851,-1259.1392167224028,771.3234287776531,-176.6150291621406,12.507343278686905,-.13857109526572012,9.984369578019572e-6,1.5056327351493116e-7];if(z<.5)return Math.log(Math.PI)-Math.log(Math.sin(Math.PI*z))-lg(1-z);z--;let x=.99999999999980993;for(let i=0;i<c.length;i++)x+=c[i]/(z+i+1);let t=z+c.length-.5;return .5*Math.log(2*Math.PI)+(z+.5)*Math.log(t)-t+Math.log(x);};
  const cf=(a,b,x)=>{let c=1,d=1-(a+b)*x/(a+1);if(Math.abs(d)<1e-300)d=1e-300;d=1/d;let h=d;for(let m=1;m<=300;m++){let aa=m*(b-m)*x/((a+2*m-1)*(a+2*m));d=1+aa*d;if(Math.abs(d)<1e-300)d=1e-300;c=1+aa/c;if(Math.abs(c)<1e-300)c=1e-300;d=1/d;h*=d*c;aa=-(a+m)*(a+b+m)*x/((a+2*m)*(a+2*m+1));d=1+aa*d;if(Math.abs(d)<1e-300)d=1e-300;c=1+aa/c;if(Math.abs(c)<1e-300)c=1e-300;d=1/d;let v=d*c;h*=v;if(Math.abs(v-1)<2e-14)break;}return h;};
  df=Math.min(df,100000);
  const beta=(x,a,b)=>{if(x<=0)return 0;if(x>=1)return 1;const bt=Math.exp(lg(a+b)-lg(a)-lg(b)+a*Math.log(x)+b*Math.log1p(-x));return x<(a+1)/(a+b+2)?bt*cf(a,b,x)/a:1-bt*cf(b,a,1-x)/b;};
  const tail=t=>beta(df/(df+t*t),df/2,.5);let lo=0,hi=2;while(tail(hi)>alpha&&hi<1e15)hi*=2;for(let i=0;i<70;i++){let m=(lo+hi)/2;if(tail(m)>alpha)lo=m;else hi=m;}return (lo+hi)/2;
};
S.recalculateStat = function(values, errors, independent, df, family) {
  const n=values.length, mean=n?values.reduce((a,b)=>a+b,0)/n:null;
  const sd=n>1?Math.sqrt(values.reduce((a,b)=>a+(b-mean)**2,0)/(n-1)):null;
  const r={n,mean,sdAcrossSeeds:sd,min:n?Math.min(...values):null,max:n?Math.max(...values):null,ci95:null,conditionalEvaluationCi95:null,evaluationStdErrOfMean:null,totalStdErrOfMean:null,betweenStrategySd:null,comparisonFamilySize:family};
  if(!n||!values.every(isNum)||errors.length!==n||!errors.every(e=>isNum(e)&&e>=0))return r;
  const ss=errors.reduce((a,b)=>a+b,0),q=errors.reduce((a,b)=>a+b*b,0),exact=ss===0;
  const se=(independent?Math.sqrt(q):ss)/n;r.evaluationStdErrOfMean=se;
  if(!exact&&!(df>=1))return r;
  const ch=exact?0:S.critical(df,.05/family)*se;r.conditionalEvaluationCi95=[mean-ch,mean+ch];
  if(n<2||(!independent&&!exact))return r;
  r.degreesOfFreedom=exact?n-1:Math.min(n-1,df);r.criticalValue=S.critical(r.degreesOfFreedom,.05/family);
  r.totalStdErrOfMean=Math.max(sd/Math.sqrt(n),se);r.betweenStrategySd=Math.sqrt(Math.max(0,sd*sd-q/n));const h=r.criticalValue*r.totalStdErrOfMean;r.ci95=[mean-h,mean+h];return r;
};
S.upgradeResult = function(input) {
  if(input.calculationVersion===S.CALCULATION || input.calculationVersion===S.REVIEW)return input;
  if(input.calculationVersion===S.MODEL_CALCULATION || input.calculationVersion==='study-5.3-legacy-review-v1')return S.review55(input,false);
  const d=JSON.parse(JSON.stringify(input));
  d.calculationVersion='study-5.3-legacy-review-v1';
  d.recalculation={sourceVersion:input.version,sourceBuild:input.build,sourceCalculationVersion:input.calculationVersion||'5.2-unversioned',method:S.MODEL_CALCULATION,
    note:'Legacy confidence reviewed in 5.3. Exact-evaluation mean intervals recomputed with study-wide multiplicity. Shared sampled evaluations support only a conditional covariance upper-bound interval; fresh independent evaluation is required for confidence across trainings. Original confidence is retained in legacyConfidence; measurements, frequencies, EV estimates, settings and timings are preserved.'};
  const nb=d.run.budgetsDeals.length;
  let family=nb*d.variants.reduce((n,v,vi)=>{const k=v.decision.actions.length;return n+k+k*(k-1)/2+1+(vi?2*k+k*(k-1)/2:0);},0);family=Math.max(1,family);
  const oldSens=d.sensitivity;if(oldSens){d.legacySensitivity=oldSens;d.sensitivity=null;d.recalculation.sensitivity='Legacy sensitivity confidence withheld: paired raw values remain available; re-run for a complete recalculation.';}
  for(const v of d.variants){
    const requested=d.run.seeds,reqQ=isNum(d.tolerance.quality),k=v.decision.actions.length;
    v.legacyToleranceSummary=v.toleranceSummary;v.firstBudgetMeetingTolerance=null;v.trainingSecondsAtFirstBudgetMeetingTolerance=null;v.requestedSeeds=requested.length;v.lastCompleteBudget=null;
    for(const b of v.budgets){
      b.legacyConfidence={gap:b.gap,quality:b.quality,actionEv:b.actions?.map(a=>a.ev),actionEvaluationSe:b.actions?.map(a=>a.evEvaluationStdErrOfMean),toleranceChecks:b.toleranceChecks,meetsTolerance:b.meetsTolerance,verdict:b.verdict,verdictText:b.verdictText};
      const raw=requested.map(seed=>v.perSeed.find(p=>p.seed===seed)?.budgets.find(p=>p.budgetDeals===b.budgetDeals));
      const good=p=>p&&p.ev?.length===k&&p.ev.every(isNum)&&p.frequency?.length===k&&p.frequency.every(isNum)&&!p.evError;
      const qNeeded=p=>reqQ || ((v.evaluation?.quality?.method||d.run.quality?.method)!=='none' && ((v.evaluation?.quality?.budgets||d.run.quality?.budgets)!=='last'||b.budgetDeals===d.run.budgetsDeals.at(-1)));
      const complete=p=>good(p)&&p.deals>=b.budgetDeals&&!p.limitReached&&p.evStatus==='completed'&&(!qNeeded(p)||(isNum(p.quality)&&isNum(p.qualityStdErr)&&!p.qualityError));
      b.requestedSeeds=requested.length;b.completedSeeds=raw.filter(complete).length;b.evaluatedSeeds=raw.filter(good).length;b.complete=b.completedSeeds===b.requestedSeeds;
      b.seedStatuses=raw.map((p,i)=>({seed:requested[i],status:complete(p)?'completed':!p?'unstarted':p.limitReached?'memoryLimit':p.evError||p.qualityError?'evaluationFailed':'legacyIncomplete'}));
      if(b.complete)v.lastCompleteBudget=b.budgetDeals;
      const pts=raw.filter(good), exact=pts.length>0&&pts.every(p=>p.evMethod==='exact');
      const df=Math.min(100000,...pts.map(p=>p.evSamples-1));
      const stat=(x,se)=>S.recalculateStat(x,se,exact,df,family);
      if(b.actions)for(let i=0;i<k;i++){const st=stat(pts.map(p=>p.ev[i]),pts.map(p=>p.evStdErr?.[i]));b.actions[i].ev={...b.actions[i].ev,...st};b.actions[i].evEvaluationStdErrOfMean=st.evaluationStdErrOfMean;}
      let allRanked=true;
      if(b.gap&&b.actions){const ti=b.actions.findIndex(a=>a.label===b.gap.higher),si=b.actions.findIndex(a=>a.label===b.gap.lower);
        const pair=(i,j)=>stat(pts.map(p=>p.ev[i]-p.ev[j]),pts.map(p=>p.pairedDiffStdErr?.[i]?.[j]));
        b.gap={...b.gap,...pair(ti,si),uncertaintyNote:d.recalculation.note};
        b.pairwiseGaps=[];for(let i=0;i<k;i++)for(let j=i+1;j<k;j++)b.pairwiseGaps.push({actionA:b.actions[i].label,actionB:b.actions[j].label,difference:pair(i,j)});
        for(let j=0;j<k;j++)if(j!==ti){const g=pair(ti,j);allRanked&&=!!g.ci95&&g.ci95[0]>d.tolerance.evGap;}
      }
      const qp=pts.filter(p=>isNum(p.quality)),qe=qp.every(p=>p.qualityKind==='exact');
      if(b.quality){const q=S.recalculateStat(qp.map(p=>p.quality),qp.map(p=>p.qualityStdErr),qe,Math.min(100000,...qp.map(p=>(p.qualitySamples||0)-1)),family);b.quality={...b.quality,...q};}
      const g=b.gap,tc=b.toleranceChecks||{};
      tc.allSeedsReachedBudget=b.complete;tc.gapCi95HalfWidth=g?.ci95?(g.ci95[1]-g.ci95[0])/2:null;tc.gapResolvedToTolerance=isNum(tc.gapCi95HalfWidth)&&tc.gapCi95HalfWidth<=d.tolerance.evGap;
      tc.qualityUpperBound=b.quality?.ci95?.[1]??null;tc.qualityWithinTolerance=!reqQ||(b.quality?.n===requested.length&&isNum(tc.qualityUpperBound)&&tc.qualityUpperBound<=d.tolerance.quality);
      b.toleranceChecks=tc;b.meetsTolerance=false;
      b.verdict=!b.complete?'incomplete':!g?.ci95?'uncertaintyUnavailable':allRanked?'ranked':g.ci95[0]>=-d.tolerance.evGap&&g.ci95[1]<=d.tolerance.evGap?'nearTie':'unresolved';
      b.verdictText=!exact?'Legacy sampled result: fresh independent evaluation required for confidence across trainings.':b.complete?'Recalculated exact-evaluation interval with study-wide multiplicity; descriptive stability must also pass.':'Legacy partial study: ranking withheld.';
    }
    for(let i=0;i<v.budgets.length;i++){const b=v.budgets[i],p=v.budgets[i-1],tc=b.toleranceChecks;
      tc.stableAcrossBudgets=p&&p.complete&&b.complete?tc.stableAcrossBudgets:null;
      b.meetsTolerance=b.complete&&tc.frequencyStable&&tc.gapResolvedToTolerance&&tc.qualityWithinTolerance&&(v.budgets.length===1||tc.stableAcrossBudgets===true);
      if(b.meetsTolerance&&v.firstBudgetMeetingTolerance===null){v.firstBudgetMeetingTolerance=b.budgetDeals;v.trainingSecondsAtFirstBudgetMeetingTolerance=b.trainingSecondsMean;}
    }
    v.toleranceSummary=(v.firstBudgetMeetingTolerance===null?'tolerance not reached after legacy confidence review':'tolerance first met at '+v.firstBudgetMeetingTolerance+' sampled deals after recalculation')+'; final budget '+v.budgets.at(-1).completedSeeds+'/'+requested.length+' seeds complete';
  }
  return S.review55(d,true);
};

S.validateResult = function (doc) {
  if (!doc || typeof doc !== 'object' || doc.format !== 'EightMax study result' || doc.formatVersion !== 1) throw new Error('Not an EightMax study result (format "EightMax study result", formatVersion 1)');
  if (!Array.isArray(doc.variants) || !doc.variants.length || !doc.tolerance || !doc.run) throw new Error('The study result has no variants');
  for (const v of doc.variants) if (!Array.isArray(v.budgets) || !Array.isArray(v.perSeed) || !v.decision || !v.utility) throw new Error('Variant ' + (v && v.name) + ' is incomplete');
  return S.upgradeResult(doc);
};
S.validateFixture = function (fx) {
  if (!fx || typeof fx !== 'object' || fx.format !== 'EightMax study fixture' || fx.formatVersion !== 1) throw new Error('Not an EightMax study fixture (format "EightMax study fixture", formatVersion 1)');
  if (!fx.study || !Array.isArray(fx.variants) || !fx.variants.length) throw new Error('The study fixture has no study plan or variants');
  for (const v of fx.variants) if (!v.name || !v.spot || !v.decision || !Array.isArray(v.decision.actions)) throw new Error('Variant ' + (v && v.name) + ' needs a form state (spot) and a decision');
  return fx;
};
// The budget a variant's headline is taken from: the first budget meeting the declared tolerance, otherwise the last measured one.
S.headlineBudget = function (v) {
  const key = v.firstBudgetMeetingTolerance ?? v.lastMeasuredBudget;
  return key == null ? null : v.budgets.find(b => b.budgetDeals === key) || null;
};
S.headline = function (v) {
  const b = S.headlineBudget(v), unit = v.utility.unit;
  if (!b || !b.actions) return { budget: null, met: false, verdict: 'noData', text: 'No completed measurement.', actions: [], gap: null, unit };
  const acts = b.actions.map(a => ({ label: a.label, frequency: a.frequency.mean, frequencySd: a.frequency.sdAcrossSeeds, ev: a.ev.mean })).sort((x, y) => y.frequency - x.frequency);
  const mix = acts.filter(a => a.frequency >= 0.005).map(a => a.label + ' ' + S.pct(a.frequency, 0)).join(', ');
  const g = b.gap, gapText = g ? g.higher + ' − ' + g.lower + ' = ' + S.signed(g.mean) + ' ' + unit + ', measured strategies (calibrated 95%) ' + (g.conditionalCalibrated===false||!g.conditionalEvaluationCi95 ? 'not calibrated' : S.ci(g.conditionalEvaluationCi95)) + ', across trainings (model-based 95%) ' + S.ci(g.ci95) : 'one legal action';
  // 5.6: a document that carries bestAction says whether a best action is DECLARED (calibrated for the measured strategies
  // AND supported for the typical training by the distribution-free sign test). Without the declaration the leader is
  // reported as the leader among the measured trainings, never as a recommendation.
  const declared = b.bestAction ? !!b.bestAction.declared : null, across = b.confidence && b.confidence.replication ? b.confidence.replication.verdict : null;
  const lead = { ranked: declared === false ? 'Leader among the measured trainings: ' + (g && g.higher) + ' (no best action declared)' : 'Prefer ' + (g && g.higher), nearTie: 'Mix (EVs within tolerance)', smallEdge: 'Small edge for ' + (g && g.higher), unresolved: 'Unresolved', singleSeed: 'One seed only', singleAction: 'Forced', noData: 'No data', incomplete: 'Incomplete study', uncertaintyUnavailable: 'Confidence unavailable', uncalibrated: 'Confidence not calibrated' }[b.verdict] || b.verdict;
  return { budget: b.budgetDeals, met: v.firstBudgetMeetingTolerance != null, verdict: b.verdict, calibrated: b.confidence ? !!b.confidence.evaluationCalibrated : null, lead, mix, actions: acts, gap: g || null, unit, gapText,
    bestActionDeclared: declared, acrossTrainingsVerdict: across, evaluationKind: b.confidence ? b.confidence.evaluationKind || null : null,
    completion: (b.completedSeeds ?? b.seeds) + '/' + (b.requestedSeeds ?? v.requestedSeeds ?? b.seeds) + ' seeds complete',
    text: lead + ': ' + mix + '. EV gap ' + gapText + '. ' + (v.firstBudgetMeetingTolerance != null ? 'Declared tolerance first met at ' + S.deals(b.budgetDeals) + ' deals.' : 'Declared tolerance NOT reached; last measured budget ' + S.deals(b.budgetDeals) + ' deals.') + ' ' + (b.completedSeeds ?? b.seeds) + '/' + (b.requestedSeeds ?? v.requestedSeeds ?? b.seeds) + ' seeds complete.' };
};
// 5.5 Study Accuracy and Recovery: one row per variant, from the stored document only (used by the panel and tests).
S.accuracy = function (doc) {
  const run = doc.run || {}, ck = run.checkpoint || {}, comp = doc.completion || null;
  return doc.variants.map(v => {
    const b = S.headlineBudget(v), last = v.budgets[v.budgets.length - 1] || {}, conf = b && b.confidence, kind = v.qualityMetric ? v.qualityMetric.kind : 'none';
    const trained = v.perSeed.every(s => s.budgets.every(x => x.status === 'completed' || (x.deals >= x.budgetDeals && !x.limitReached)));
    const evaluated = v.budgets.every(x => x.complete === true || (x.completedSeeds != null && x.completedSeeds === x.requestedSeeds));
    const calibrated = conf ? !!conf.evaluationCalibrated : null;
    // 5.6 documents: supported only when a best action is declared; older documents keep the 5.5 rule.
    const supported = !!b && (b.bestAction ? !!b.bestAction.declared : ['ranked', 'smallEdge'].includes(b.verdict));
    const rep = conf && conf.replication ? conf.replication : null;
    const warnings = [];
    for (const w of doc.statisticalWarnings || []) if (w.variant === v.name && !['sampledEvaluation', 'qualityNotCalibrated', 'incomplete'].includes(w.code)) warnings.push(w.text);
    if (!evaluated) warnings.push('Incomplete: ' + (last.completedSeeds ?? 0) + ' of ' + (last.requestedSeeds ?? v.requestedSeeds ?? '?') + ' seeds finished the last budget. No ranking or tolerance claim is made for incomplete budgets.');
    if (calibrated === false) warnings.push('Evaluation uncertainty is not calibrated: ' + (conf.reasonText || S.REASONS[conf.reason] || 'no calibrated statement is available') + ' No ranking is stated.');
    if (calibrated === null && b) warnings.push('This result was produced before 5.5 and carries no calibration status.');
    if (b && b.verdict === 'ranked' && !rep) warnings.push('The ranking is calibrated for the strategies that were trained and measured. Across new trainings it rests on a Student-t model of ' + (b.seeds ?? '?') + ' replications, which cannot detect a rare training failure.');
    if (kind === 'sampled') warnings.push('Quality is a sampled one-decision deviation gain: restricted, a lower bound, not exploitability, and not calibrated.');
    if (kind === 'exact' && v.decision && (v.decision.players || 0) > 2) warnings.push('Quality is exact inside this abstraction; with more than two players it is not exploitability.');
    return { variant: v.name, budget: b ? b.budgetDeals : null, trainingComplete: trained, evaluationComplete: evaluated, calibrated, calibrationMethod: conf ? conf.evaluationMethod : 'unknown (pre-5.5 document)',
      bestActionSupported: supported, verdict: b ? b.verdict : 'noData', toleranceMet: v.firstBudgetMeetingTolerance != null, metric: kind === 'exact' ? 'exact (inside the abstraction)' : kind === 'sampled' ? 'restricted (sampled one-decision gain)' : 'none',
      bestActionDeclared: b && b.bestAction ? !!b.bestAction.declared : null, acrossTrainingsVerdict: rep ? rep.verdict : null, trainings: rep ? rep.trainings : (b ? b.seeds : null),
      minimumTrainings: rep ? rep.minimumTrainingsForStatementAboutTypicalTraining : null, undetectableFailureRate: rep ? rep.undetectableFailureRate : null, evaluationKind: conf ? conf.evaluationKind || null : null,
      qualityCalibrated: conf ? !!conf.qualityCalibrated : null, checkpointAvailable: !!ck.enabled, resumable: !!(ck.resumable || (comp && comp.resumable)), studyComplete: comp ? !!comp.complete : evaluated, warnings };
  });
};
S.progressText = function (p, status) {   // what can be said reliably while a study runs: counts, never a time estimate
  if (!p) return { phase: 'starting', lines: [] };
  const lines = [], n = (x, d = 0) => isNum(x) ? x.toFixed(d) : '–';
  const phase = { beforeTraining: 'training', training: 'training', checkpoint: 'saving checkpoint', evaluating: 'evaluating action EVs and quality', actionEvaluated: 'evaluating strategy quality', evaluated: 'evaluated' }[p.phase] || p.phase || 'starting';
  if (isNum(p.pointsRequested)) lines.push(['Measurements complete', n(p.pointsCompleted) + ' of ' + n(p.pointsRequested) + (p.pointsRequested > 0 ? ' (' + (100 * p.pointsCompleted / p.pointsRequested).toFixed(0) + '% of the planned measurements; this is a count, not a time estimate)' : '')]);
  if (isNum(p.seedsRequested)) lines.push(['Training seeds complete', n(p.seedsCompleted) + ' of ' + n(p.seedsRequested) + (isNum(p.parallelSeeds) && p.parallelSeeds > 1 ? ' (' + p.parallelSeeds + ' run side by side)' : '')]);
  if (isNum(p.sampledDeals)) lines.push(['Current seed', (p.variant ? p.variant + ', ' : '') + 'seed ' + ((p.seedIndex ?? 0) + 1) + ', ' + S.deals(p.sampledDeals) + (isNum(p.budgetDeals) ? ' of ' + S.deals(p.budgetDeals) : '') + ' sampled deals']);
  lines.push(['Stage', phase]);
  const c = p.checkpoint;
  if (c) lines.push(['Checkpoint', !c.enabled ? 'off' : (c.commits > 0 ? c.commits + ' commits; last successful ' + (isNum(c.lastCommitStudyElapsedSeconds) && c.lastCommitStudyElapsedSeconds >= 0 ? n(Math.max(0, (p.studyElapsedSeconds ?? 0) - c.lastCommitStudyElapsedSeconds), 0) + ' s ago' : 'not yet') : 'no commit yet') + (c.resumed ? ' (resumed study)' : '') + (c.lastError ? ' — LAST WRITE FAILED: ' + c.lastError : '')]);
  if (isNum(p.processRssMiB)) lines.push(['Memory', n(p.processRssMiB) + ' MiB in use, peak ' + n(p.processPeakRssMiB) + ' MiB' + (p.processMemoryBudgetMiB > 0 ? ', budget ' + n(p.processMemoryBudgetMiB) + ' MiB' : '')]);
  lines.push(['Processing', (p.processingModeRequested || 'fixture') + ' requested' + (p.trainingDevicePath ? '; observed: ' + p.trainingDevicePath : '')]);
  lines.push(['Quality and confidence', 'reported when a budget has been evaluated; until then no estimate is shown']);
  return { phase, lines };
};
S.COLUMNS = ['study', 'variant', 'utilityModel', 'utilityUnit', 'heroHand', 'budgetDeals', 'seeds', 'action', 'frequencyMean', 'frequencySdAcrossSeeds', 'frequencyMin', 'frequencyMax', 'evMean', 'evSdAcrossSeeds', 'evEvaluationStdErrOfMean', 'untrainedContinuationShare',
  'gapHigher', 'gapLower', 'gapMean', 'gapCi95Low', 'gapCi95High', 'gapSdAcrossSeeds', 'gapEvaluationStdErrOfMean', 'gapBetweenStrategySd', 'qualityKind', 'qualityMean', 'qualitySdAcrossSeeds', 'qualityEvaluationStdErrOfMean',
  'trainingSecondsMean', 'evSecondsMean', 'qualitySecondsMean', 'processPeakRssMiB', 'trainingThreadsUsed', 'meetsTolerance', 'verdict', 'firstBudgetMeetingTolerance', 'calculationVersion', 'requestedSeeds', 'completedSeeds', 'complete', 'evCi95Low', 'evCi95High', 'evConditionalCi95Low', 'evConditionalCi95High', 'qualityCi95Low', 'qualityCi95High','studyPreset','processingModeRequested','confidenceLevel'];
S.rows = function (doc) {
  const out = [];
  for (const v of doc.variants) for (const b of v.budgets) for (const a of (b.actions || [])) {
    const g = b.gap || {}, q = b.quality || {}, ci = Array.isArray(g.ci95) ? g.ci95 : [null, null];
    out.push({ studyPreset:doc.run.preset??'fixture',processingModeRequested:doc.run.processingModeRequested??'fixture',confidenceLevel:doc.run.confidenceLevel??.95,calculationVersion:doc.calculationVersion,requestedSeeds:b.requestedSeeds,completedSeeds:b.completedSeeds,complete:b.complete,evCi95Low:a.ev.ci95?.[0],evCi95High:a.ev.ci95?.[1],evConditionalCi95Low:a.ev.conditionalEvaluationCi95?.[0],evConditionalCi95High:a.ev.conditionalEvaluationCi95?.[1],qualityCi95Low:q.ci95?.[0],qualityCi95High:q.ci95?.[1],study: doc.fixture.id, variant: v.name, utilityModel: v.utility.model, utilityUnit: v.utility.unit, heroHand: v.decision.hand, budgetDeals: b.budgetDeals, seeds: b.seeds, action: a.label,
      frequencyMean: a.frequency.mean, frequencySdAcrossSeeds: a.frequency.sdAcrossSeeds, frequencyMin: a.frequency.min, frequencyMax: a.frequency.max, evMean: a.ev.mean, evSdAcrossSeeds: a.ev.sdAcrossSeeds, evEvaluationStdErrOfMean: a.evEvaluationStdErrOfMean, untrainedContinuationShare: a.untrainedContinuationShare,
      gapHigher: g.higher ?? null, gapLower: g.lower ?? null, gapMean: g.mean ?? null, gapCi95Low: ci[0], gapCi95High: ci[1], gapSdAcrossSeeds: g.sdAcrossSeeds ?? null, gapEvaluationStdErrOfMean: g.evaluationStdErrOfMean ?? null, gapBetweenStrategySd: g.betweenStrategySd ?? null,
      qualityKind: v.qualityMetric.kind, qualityMean: q.mean ?? null, qualitySdAcrossSeeds: q.sdAcrossSeeds ?? null, qualityEvaluationStdErrOfMean: q.evaluationStdErrOfMean ?? null,
      trainingSecondsMean: b.trainingSecondsMean, evSecondsMean: b.evSecondsMean, qualitySecondsMean: b.qualitySecondsMean, processPeakRssMiB: b.processPeakRssMiB, trainingThreadsUsed: b.trainingThreadsUsed, meetsTolerance: b.meetsTolerance, verdict: b.verdict, firstBudgetMeetingTolerance: v.firstBudgetMeetingTolerance });
  }
  return out;
};
S.toCSV = function (doc) {
  const f = x => x === null || x === undefined || (typeof x === 'number' && !Number.isFinite(x)) ? '' : typeof x === 'string' && /[",\n]/.test(x) ? '"' + x.replace(/"/g, '""') + '"' : String(x);
  const lines = [S.COLUMNS.join(',')];
  for (const r of S.rows(doc)) lines.push(S.COLUMNS.map(c => f(r[c])).join(','));
  // Completion is exported even when a budget produced no action evaluations.
  lines.push('', 'study,variant,budgetDeals,requestedSeeds,completedSeeds,evaluatedSeeds,complete,meetsTolerance,calculationVersion');
  for(const v of doc.variants)for(const b of v.budgets)lines.push([doc.fixture.id,v.name,b.budgetDeals,b.requestedSeeds,b.completedSeeds,b.evaluatedSeeds,b.complete,b.meetsTolerance,doc.calculationVersion].map(f).join(','));
  // raw per-seed measurements, one row per variant, seed, budget and action
  lines.push('', ['study', 'variant', 'seed', 'budgetDeals', 'dealsReached', 'action', 'frequency', 'ev', 'evStdErr', 'fallbackShare', 'quality', 'qualityStdErr', 'trainingSecondsCumulative', 'evSeconds', 'qualitySeconds', 'processPeakRssMiB', 'limitReached', 'status', 'complete', 'evaluationSeed', 'qualitySeed', 'stopReason'].join(','));
  for (const v of doc.variants) for (const s of v.perSeed) for (const b of s.budgets) v.decision.actions.forEach((a, i) => lines.push([doc.fixture.id, v.name, s.seed, b.budgetDeals, b.deals, a.label, b.frequency[i], b.ev[i], b.evStdErr[i], b.fallbackShare[i], b.quality, b.qualityStdErr, b.trainingSecondsCumulative, b.evSeconds, b.qualitySeconds, b.processPeakRssMiB, b.limitReached, b.status, b.complete, b.evaluationSeed, b.qualitySeed, b.stopReason].map(f).join(',')));
  return lines.join('\n') + '\n';
};
// Rebuild game and native specification from the form state, exactly as the Multiway tab's Solve does on the desktop.
S.buildVariant = function (spot) {
  const game = { ...EM.multiwaySpotConfig(spot), engine: 'native' }, g = EM.MultiwayGame(game), why = g.nativeSupport();
  if (why) throw new Error('This form state is not eligible for native training: ' + why);
  return { game, nativeSpec: g.nativeSpec() };
};
S.completeFixture = function (fx) {
  S.validateFixture(fx); const checks = [];
  const variants = fx.variants.map(v => {
    const built = S.buildVariant(v.spot);
    const same = v.nativeSpec ? JSON.stringify(v.nativeSpec) === JSON.stringify(built.nativeSpec) : null;
    checks.push({ variant: v.name, storedSpecification: !!v.nativeSpec, rebuiltEqualsStored: same });
    return { ...v, game: v.game || built.game, nativeSpec: v.nativeSpec || built.nativeSpec };
  });
  return { fixture: { ...fx, variants }, checks };
};
// The compact form embedded in the page: everything except the two fields the application can rebuild.
S.compactFixture = fx => ({ ...fx, variants: fx.variants.map(({ game, nativeSpec, ...rest }) => rest) });

// ---------------- panel ----------------
EM.studyPanel = function (root, deps) {
  const { napi, NATIVE, esc, openInMultiway } = deps;
  const st = { fixtures: (EM.STUDY_FIXTURES || []).slice(), pick: 0, fixture: null, checks: null, result: null, resultSource: '', error: '', status: null, running: false, variant: 'all', seeds: '', budgets: '', threads: '', preset:'fixture',timeLimit:'',memory:'',samples:'',qualitySamples:'',mode:'fixture',openVariant: 0, showSeeds: false };
  const fx = () => st.fixture;
  const download = (name, text, type) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); };
  const presets54={quick:{seeds:2,budgets:'1000,10000',timeLimit:60,memory:256,samples:2000,qualitySamples:256},standard:{seeds:5,budgets:'10000,100000',timeLimit:600,memory:512,samples:20000,qualitySamples:4000},deep:{seeds:10,budgets:'100000,1000000',timeLimit:3600,memory:1024,samples:100000,qualitySamples:20000}};
  function choose(f) { st.fixture = f; st.checks = null; st.error = ''; st.variant = 'all'; st.seeds = String(f.study.seeds.length); st.budgets = f.study.budgetsDeals.join(','); st.openVariant = 0;st.preset='fixture';st.timeLimit='';st.memory='';st.samples='';st.qualitySamples=''; }
  if (st.fixtures.length) choose(st.fixtures[0]);
  const kv = (k, v) => `<tr><th>${esc(k)}</th><td>${v}</td></tr>`;
  function fixtureCard() {
    const f = fx(); if (!f) return '<p class="small muted">No study fixture is loaded.</p>';
    const d = f.description || {}, t = f.table || {}, v0 = f.variants[0], dec = v0.decision;
    const sizes = d.betSizes ? Object.entries(d.betSizes).map(([k, v]) => '<b>' + esc(k) + '</b>: ' + esc(v)).join('<br>') : '–';
    const stacks = d.stacksBB ? Object.entries(d.stacksBB).map(([k, v]) => esc(k) + ' ' + esc(v)).join(', ') : '–';
    return `<h3 id="sd-title">${esc(f.title)}</h3>
      <p class="small muted">${esc(f.id)} · ${esc(f.kind || 'study')}${f.companion ? ' · smaller companion: <b>' + esc(f.companion) + '</b>' : ''}${f.companionOf ? ' · simplified companion of <b>' + esc(f.companionOf) + '</b>' : ''}</p>
      <div class="sd-table"><table id="sd-fixture"><tbody>
      ${kv('Table', `${esc(t.players)} players dealt in · small blind ${esc(t.smallBlind)} BB · big blind ${esc(t.bigBlind)} BB · ante ${esc(t.antePerPlayer)} BB per player · pot before voluntary action ${esc(t.startingPotBeforeVoluntaryAction)} BB`)}
      ${kv('Stacks (BB)', stacks + ' · effective ' + esc(d.effectiveStacksBB))}
      ${d.payouts ? kv('Payouts', esc(d.payouts.places.join(', ')) + ' (' + esc(d.payouts.unit) + ')') : ''}
      ${kv('Positions', esc(d.positions || '–'))}
      ${kv('Action history', esc(d.actionHistory || '–'))}
      ${kv('Board', esc(d.board || '–'))}
      ${kv('Hero', `<b id="sd-hero">${esc(d.heroPosition)} with ${esc(d.heroHand)}</b> · pot ${esc(dec.potBB)} BB · to call ${esc(dec.toCallBB)} BB`)}
      ${kv('Legal actions', `<span id="sd-actions">${dec.actions.map(a => esc(a.label) + (a.potFraction ? ' (' + (100 * a.potFraction).toFixed(0) + '% pot)' : '')).join(' · ')}</span>`)}
      ${kv('Bet sizes', sizes)}
      ${kv('Utility', esc((d.utility && d.utility.model) || '') + ' EV in <b>' + esc((d.utility && d.utility.unit) || '') + '</b>. ' + esc((d.utility && d.utility.convention) || ''))}
      ${kv('Hand abstraction', esc(d.abstraction || '–'))}
      ${kv('Continuation', esc(d.continuation || '–'))}
      ${kv('Range weights', esc(d.rangeWeights || '–'))}
      ${d.knownSolution ? kv('Known solution', esc(d.knownSolution)) : ''}
      ${d.simplifications ? kv('Simplified from ' + esc(d.simplifiedFrom || ''), '<ul>' + d.simplifications.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>') : ''}
      ${kv('Assumptions', '<ul>' + (d.assumptions || []).map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>')}
      ${kv('Study plan', `seeds ${esc(f.study.seeds.join(', '))} · budgets ${f.study.budgetsDeals.map(S.deals).join(', ')} sampled deals · action EVs: ${esc(f.study.ev.method)}${f.study.ev.samples ? ' (' + S.deals(f.study.ev.samples) + ' paired samples)' : ''} · quality: ${esc(f.study.quality.method)} · declared tolerance: EV gap ± ${esc(f.study.tolerance.evGap)}, frequency sd ≤ ${esc(f.study.tolerance.frequency)}${f.study.tolerance.quality != null ? ', quality ≤ ' + esc(f.study.tolerance.quality) : ''}`)}
      </tbody></table></div>
      <div class="sd-table"><table id="sd-variants"><thead><tr><th>Variant</th><th>What changes (one input at a time)</th><th>Ranges (combinations per seat)</th><th>Legal actions at the decision</th></tr></thead><tbody>
      ${f.variants.map(v => `<tr><td><b>${esc(v.name)}</b></td><td>${esc(v.change || 'baseline')}</td><td>${(v.ranges || []).map(r => esc(r.name) + ' ' + esc(r.combinations)).join(', ')}</td><td>${v.decision.actions.map(a => esc(a.label)).join(' · ')}</td></tr>`).join('')}
      </tbody></table></div>
      <details><summary class="small">Range text per seat (baseline)</summary><div class="sd-table"><table><tbody>${(v0.ranges || []).map(r => `<tr><th>${esc(r.name)}</th><td class="sd-range">${esc(r.text)}</td></tr>`).join('')}</tbody></table></div></details>
      ${st.checks ? `<p class="small" id="sd-check">${st.checks.map(c => esc(c.variant) + ': ' + (c.rebuiltEqualsStored === null ? 'specification built by this application' : c.rebuiltEqualsStored ? 'the specification stored in the file equals the one this application builds from the form' : '<b class="warn">the stored specification differs from the one this application builds</b>')).join(' · ')}</p>` : ''}`;
  }
  function budgetTable(v) {
    const unit = v.utility.unit, head = `<thead><tr><th>Budget (deals)</th><th>Action</th><th>Frequency</th><th>sd across seeds</th><th>EV (${esc(unit)})</th><th>sd across seeds</th><th>evaluation se</th><th title="Share of evaluation samples that reached an information set training never visited; the evaluator plays those uniformly">untrained continuation</th></tr></thead>`;
    let body = '';
    for (const b of v.budgets) {
      if (!b.actions) { body += `<tr><td>${S.deals(b.budgetDeals)}</td><td colspan="7">${b.completedSeeds ?? 0}/${b.requestedSeeds ?? v.requestedSeeds ?? 0} seeds complete · ${esc(b.verdictText || 'not measured')}</td></tr>`; continue; }
      b.actions.forEach((a, i) => { body += `<tr data-sd-budget="${b.budgetDeals}" data-sd-action="${esc(a.label)}">${i === 0 ? `<td rowspan="${b.actions.length}">${S.deals(b.budgetDeals)}<br><span class="small muted">${b.completedSeeds ?? b.seeds}/${b.requestedSeeds ?? b.seeds} complete; ${b.seeds} evaluated</span></td>` : ''}<td>${esc(a.label)}</td><td data-k="frequencyMean">${S.pct(a.frequency.mean)}</td><td data-k="frequencySd">${S.pct(a.frequency.sdAcrossSeeds)}</td><td data-k="evMean">${S.signed(a.ev.mean)}</td><td data-k="evSd">${S.fmt(a.ev.sdAcrossSeeds)}</td><td data-k="evEvalSe">${S.fmt(a.evEvaluationStdErrOfMean)}</td><td data-k="untrained">${S.pct(a.untrainedContinuationShare)}</td></tr>`; });
      const g = b.gap, q = b.quality, tc = b.toleranceChecks || {};
      body += `<tr class="sd-sub" data-sd-gap="${b.budgetDeals}"><td colspan="8">` +
        (g ? `<b>EV gap</b> ${esc(g.higher)} − ${esc(g.lower)} = <b data-k="gapMean">${S.signed(g.mean)}</b> ${esc(unit)}, simultaneous 95% interval for the mean over trainings <span data-k="gapCi">${S.ci(g.ci95)}</span> · evaluation sampling se <span data-k="gapEvalSe">${S.fmt(g.evaluationStdErrOfMean)}</span> · estimated spread between trained strategies (sd) <span data-k="gapBetweenSd">${S.fmt(g.betweenStrategySd)}</span><br>` : '') +
        `<b>Strategy quality</b> ${q ? `<span data-k="qualityMean">${S.fmt(q.mean, 4)}</span> ${esc(unit)} (sd across seeds ${S.fmt(q.sdAcrossSeeds, 4)}${v.qualityMetric.kind === 'sampled' ? ', evaluation se ' + S.fmt(q.evaluationStdErrOfMean, 4) : ''})` : 'not available'} — <b>${esc(v.qualityMetric.kind)}</b>${q ? ' · simultaneous 95% ' + S.ci(q.ci95) : ''}<br>` +
        `<b>Cost</b> training <span data-k="trainSeconds">${S.fmt(b.trainingSecondsMean, 2)}</span> s (${esc(b.trainingThreadsUsed)} worker${b.trainingThreadsUsed === 1 ? '' : 's'}) · EV evaluation <span data-k="evSeconds">${S.fmt(b.evSecondsMean, 2)}</span> s · quality evaluation <span data-k="qualitySeconds">${S.fmt(b.qualitySecondsMean, 2)}</span> s per seed · process peak RAM <span data-k="peakRss">${S.fmt(b.processPeakRssMiB, 0)}</span> MiB${b.seedsStoppedByMemoryLimit ? ' · <b class="warn">' + b.seedsStoppedByMemoryLimit + ' seed(s) stopped at the strategy table budget before this budget</b>' : ''}<br>` +
        `<b>${b.meetsTolerance ? 'Meets the declared tolerance' : 'Does not meet the declared tolerance'}</b> (frequency sd ${S.pct(tc.maxFrequencySdAcrossSeeds)} vs ${S.pct(tc.frequencyTolerance)}; gap interval half-width ${S.fmt(tc.gapCi95HalfWidth)} vs ${S.fmt(tc.evGapTolerance)}${tc.stableAcrossBudgets === null || tc.stableAcrossBudgets === undefined ? '; no earlier budget to compare with' : '; change from the previous budget: frequency ' + S.pct(tc.largestFrequencyChangeFromPreviousBudget) + ', gap ' + S.fmt(tc.gapChangeFromPreviousBudget)}${isNum(tc.qualityTolerance) ? '; quality ' + S.fmt(tc.qualityMean, 4) + ' vs ' + S.fmt(tc.qualityTolerance, 4) : ''}) · <b data-k="verdict">${esc(b.verdict)}</b>: ${esc(b.verdictText)}</td></tr>`;
    }
    return `<div class="sd-table"><table class="sd-budgets" data-sd-variant="${esc(v.name)}">${head}<tbody>${body}</tbody></table></div>`;
  }
  function seedTable(v) {
    const acts = v.decision.actions.map(a => a.label);
    return `<div class="sd-table"><table class="sd-seeds"><thead><tr><th>Seed</th><th>Budget</th>${acts.map(a => '<th>' + esc(a) + ' freq</th>').join('')}${acts.map(a => '<th>' + esc(a) + ' EV</th>').join('')}<th>Quality</th><th>Train s</th><th>Rows</th></tr></thead><tbody>` +
      v.perSeed.map(s => s.budgets.map(b => `<tr><td>${s.seed}</td><td>${S.deals(b.budgetDeals)} · ${esc(b.status || 'legacy')}${b.limitReached ? ' <b class="warn">(table budget reached at ' + S.deals(b.deals) + ')</b>' : ''}</td>${acts.map((_,i) => '<td>' + S.pct(b.frequency[i]) + '</td>').join('')}${acts.map((_, i) => '<td>' + S.signed(b.ev[i]) + (b.evStdErr[i] ? ' ±' + S.fmt(b.evStdErr[i]) : '') + '</td>').join('')}<td>${S.fmt(b.quality, 4)}</td><td>${S.fmt(b.trainingSecondsCumulative, 2)}</td><td>${S.deals(b.rows)}</td></tr>`).join('')).join('') + '</tbody></table></div>';
  }
  function sensitivity(doc) {
    const s = doc.sensitivity; if (!s || !s.comparisons) return '';
    return `<h3>Sensitivity to ranges and bet sizes (baseline: ${esc(s.baseline)})</h3><p class="small muted">${esc(s.pairing)}</p><div class="sd-table"><table id="sd-sensitivity"><thead><tr><th>Variant</th><th>Change</th><th>Leading action (by frequency)</th><th>Seeds where the leader changed</th><th>Frequency of common actions (baseline → variant)</th><th>EV gap inside each model</th><th>Added action</th><th>Reading</th></tr></thead><tbody>` +
      s.comparisons.map(c => {
        if (c.budgetDeals == null) return `<tr><td>${esc(c.variant)}</td><td colspan="7">${esc(c.note || '')}</td></tr>`;
        const gp = (g) => g ? esc(g.higher) + ' − ' + esc(g.lower) + ' = ' + S.signed(g.mean) + ' ' + esc(g.unit) + ' ' + S.ci(g.ci95) + ' (' + esc(g.verdict) + ')' : '–';
        const added = (c.addedActions || []).map(a => `${esc(a.label)}: frequency ${S.pct(a.frequency)}${a.advantageOverBestOriginal ? '; EV vs best original (' + esc(a.advantageOverBestOriginal.bestOriginalAction) + ') ' + S.signed(a.advantageOverBestOriginal.mean) + ' ' + esc(a.advantageOverBestOriginal.unit) + ' ' + S.ci(a.advantageOverBestOriginal.ci95) : ''}${a.isLeaderByFrequency ? ' — <b>now the most frequent action</b>' : ''}`).join('<br>') || '–';
        const reading = [c.leaderByFrequencyChanged ? 'the most frequent action changed' : 'the most frequent action is unchanged', c.shiftWhileNearlyTied ? '<b>frequencies shift substantially while the leading actions stay nearly tied in EV</b>' : c.frequenciesShiftSubstantially ? 'frequencies shift substantially' : 'frequencies move little', c.sameUtility ? '' : 'utilities differ (' + esc(c.baselineUnit) + ' vs ' + esc(c.variantUnit) + '): EVs are not compared across the two'].filter(Boolean).join('; ');
        return `<tr data-sd-sens="${esc(c.variant)}"><td><b>${esc(c.variant)}</b><br><span class="small muted">at ${S.deals(c.budgetDeals)} deals</span></td><td>${esc(c.change)}</td><td>${esc(c.baselineLeaderByFrequency)} → ${esc(c.variantLeaderByFrequency)}</td><td>${c.seedsWhereLeaderByFrequencyChanged} of ${c.pairedSeeds}</td><td>${c.commonActions.map(a => esc(a.label) + ': ' + S.pct(a.baselineFrequency) + ' → ' + S.pct(a.variantFrequency) + ' (' + S.signed(100 * a.frequencyChange.mean, 1) + ' pts ' + (a.frequencyChange.ci95 ? '[' + S.signed(100 * a.frequencyChange.ci95[0], 1) + ', ' + S.signed(100 * a.frequencyChange.ci95[1], 1) + ']' : '') + ')').join('<br>')}</td><td>baseline: ${gp(c.baselineGap)}<br>variant: ${gp(c.variantGap)}</td><td>${added}</td><td>${reading}</td></tr>`;
      }).join('') + '</tbody></table></div>';
  }
  function resultCard() {
    const d = st.result; if (!d) return '<p class="small muted">No study result yet. Run a study' + (NATIVE ? '' : ' in the desktop application or with <code>mwcli --study</code>') + ', or open a result file.</p>';
    const r = d.run, t = d.tolerance;
    return `<p class="small" id="sd-result-head"><b>${esc(d.fixture.title)}</b> (${esc(d.fixture.id)}) · build ${esc(d.build)} · ${r.seeds.length} seeds · ${esc(r.threadsRequested)} worker threads requested on ${esc(r.logicalProcessors)} logical processors · total ${S.fmt(r.elapsedSeconds, 1)} s · process peak RAM ${S.fmt(r.processPeakRssMiB, 0)} MiB${st.resultSource ? ' · source: ' + esc(st.resultSource) : ''}</p>
      ${r.stoppedByTimeLimit ? '<p class="warn">Stopped by the time limit: later budgets or seeds are missing.</p>' : ''}${r.stoppedByUser ? '<p class="warn">Stopped before the plan was complete: partial measurements and all requested seed statuses are retained.</p>' : ''}${r.firstEvaluationError ? '<p class="warn">An evaluation failed: ' + esc(r.firstEvaluationError) + '</p>' : ''}
      <p class="small muted">${esc(r.hardwareNote || '')}</p><p id="sd-calculation" class="small">Calculation: ${esc(d.calculationVersion)}. ${esc(d.uncertainty?.method || '')} ${esc(d.uncertainty?.stopping || '')}</p>${d.recalculation ? '<p class="warn" id="sd-legacy">' + esc(d.recalculation.note) + '</p>' : ''}
      <div class="sd-table"><table id="sd-headlines"><thead><tr><th>Variant</th><th>Hero</th><th>Result</th><th>Frequencies</th><th>EV gap between the leading actions</th><th>Budget used</th><th>Training time</th><th>Peak RAM</th><th>Tolerance</th></tr></thead><tbody>
      ${d.variants.map(v => { const h = S.headline(v), b = S.headlineBudget(v); return `<tr data-sd-headline="${esc(v.name)}"><td><b>${esc(v.name)}</b></td><td>${esc(v.decision.seatName || '')} ${esc(v.decision.hand)}</td><td data-k="lead"><b>${esc(h.lead || h.text)}</b></td><td data-k="mix">${esc(h.mix || '')}</td><td data-k="gap">${esc(h.gapText || '')}</td><td>${S.deals(h.budget)} deals</td><td>${b ? S.fmt(b.trainingSecondsMean, 2) + ' s' : '–'}</td><td>${b ? S.fmt(b.processPeakRssMiB, 0) + ' MiB' : '–'}</td><td data-k="tolerance">${esc(h.completion || '0 complete')} · ${h.met ? 'first met at ' + S.deals(v.firstBudgetMeetingTolerance) + ' deals' : '<b class="warn">not reached</b>; last measured ' + S.deals(v.lastMeasuredBudget) + ' deals'}</td></tr>`; }).join('')}
      </tbody></table></div>
      <p class="small muted"><b>Declared tolerance.</b> ${esc(t.definition)}</p>
      <div class="row">${d.variants.map((v, i) => `<button type="button" class="btn sm ${i === st.openVariant ? 'primary' : ''}" data-sd-open="${i}">${esc(v.name)}</button>`).join('')}</div>
      ${(() => { const v = d.variants[Math.min(st.openVariant, d.variants.length - 1)]; return `<h3>${esc(v.name)}${v.change ? ': ' + esc(v.change) : ''}</h3>
        <p class="small">Hero <b>${esc(v.decision.seatName || '')} ${esc(v.decision.hand)}</b> · history: ${v.decision.history && v.decision.history.length ? v.decision.history.map(x => esc(x.seatName) + ' ' + esc(x.action)).join(', ') : 'first to act'} · EVs in <b>${esc(v.utility.unit)}</b> (${esc(v.utility.model)}).</p>
        <p class="small"><b>Quality metric (${esc(v.qualityMetric.kind)}):</b> ${esc(v.qualityMetric.name)}, in ${esc(v.qualityMetric.unit)}. ${esc(v.qualityMetric.meaning)}</p>
        ${budgetTable(v)}<p class="small" id="sd-first"><b>${esc(v.toleranceSummary)}</b>${v.firstBudgetMeetingTolerance != null ? ' (mean training time ' + S.fmt(v.trainingSecondsAtFirstBudgetMeetingTolerance, 2) + ' s per seed)' : ''}</p>
        <p class="row"><button type="button" class="btn sm" data-sd-seeds="1">${st.showSeeds ? 'Hide' : 'Show'} per-seed measurements</button></p>${st.showSeeds ? seedTable(v) : ''}`; })()}
      ${sensitivity(d)}`;
  }
  function render() {
    const f = fx(), p = st.status && st.status.progress;
    root.innerHTML = `<div class="card"><div class="row sb"><h2>Decision study</h2><span class="small muted">${NATIVE ? 'Runs in the native engine' : 'Offline page: open fixtures and results here; running a study needs the desktop application or mwcli --study'}</span></div>
      <p class="small muted">A study trains one poker decision from several random seeds through increasing budgets and reports, for the hero hand, every legal action's frequency and EV, the EV gap between the leading actions with its uncertainty, the quality of the surrounding strategy and what it cost. It answers: how much computation before the recommendation can be trusted, and does it change when a range or a bet size changes?</p>
      <div class="grid2">
        <div class="field"><label class="label" for="sd-pick">Built-in study fixture</label><select id="sd-pick" ${st.running ? 'disabled' : ''}>${st.fixtures.map((x, i) => `<option value="${i}" ${x === f ? 'selected' : ''}>${esc(x.title)}</option>`).join('')}${f && !st.fixtures.includes(f) ? '<option selected>' + esc(f.title) + ' (opened file)</option>' : ''}</select></div>
        <div class="field"><label class="label" for="sd-file">Open study fixture (.emfix.json)</label><input id="sd-file" type="file" accept=".json,application/json" ${st.running ? 'disabled' : ''}></div>
      </div>
      ${fixtureCard()}
      ${f ? `<div class="grid2">
        <div class="field"><label class="label" for="sd-variant">Variant to open or run</label><select id="sd-variant" ${st.running ? 'disabled' : ''}><option value="all" ${st.variant === 'all' ? 'selected' : ''}>all variants (baseline and sensitivity)</option>${f.variants.map(v => `<option value="${esc(v.name)}" ${st.variant === v.name ? 'selected' : ''}>${esc(v.name)}</option>`).join('')}</select></div>
        <div class="field"><label class="label" for="sd-seeds">Independent training seeds (1 to 100)</label><input id="sd-seeds" type="number" min="1" max="100" value="${esc(st.seeds)}" ${st.running ? 'disabled' : ''}></div>
        <div class="field"><label class="label" for="sd-budgets">Budgets (sampled deals, increasing)</label><input id="sd-budgets" type="text" value="${esc(st.budgets)}" ${st.running ? 'disabled' : ''}></div>
        <div class="field"><label class="label" for="sd-threads">Worker threads (blank: automatic)</label><input id="sd-threads" type="number" min="1" max="256" value="${esc(st.threads)}" ${st.running ? 'disabled' : ''}></div>
      </div>
      <div class="grid2">
        <div class="field"><label for="sd-preset">Study preset</label><select id="sd-preset" ${st.running?'disabled':''}>${['fixture','quick','standard','deep','research'].map(x=>`<option ${st.preset===x?'selected':''}>${x}</option>`).join('')}</select></div>
        <div class="field"><label for="sd-mode">Processing mode</label><select id="sd-mode" ${st.running?'disabled':''}>${[['fixture','Fixture setting'],['cpu','CPU only'],['auto','Automatic'],['hybrid','Hybrid'],['gpu','GPU preferred']].map(([v,n])=>`<option value="${v}" ${st.mode===v?'selected':''}>${n}</option>`).join('')}</select></div>
        ${[['timeLimit','Time limit in seconds (0: no limit)'],['memory','Training table / evaluation cache limit in MiB'],['samples','Action evaluation samples'],['qualitySamples','Quality evaluation samples']].map(([k,label])=>`<div class="field"><label for="sd-${k}">${label}</label><input id="sd-${k}" type="number" value="${esc(st[k])}" placeholder="fixture setting" ${st.running?'disabled':''}></div>`).join('')}
      </div>
      <p class="small muted">${st.preset==='quick'?'Quick Study is preliminary. ':''}A larger preset does not certify accuracy. Rankings rest on calibrated bounded-payoff intervals for the measured strategies (wider than the 5.4 intervals: more evaluation samples resolve smaller gaps) plus a model-based interval across trainings. Sample budgets affect sampled evaluators only. The table limit applies to one seed's tables; seeds run side by side within a process memory budget (70% of installed memory unless set), and the evaluation cache uses what that budget leaves. Studies are checkpointed automatically and can be resumed below.</p>
      <div class="row"><button type="button" class="btn" id="sd-multiway" ${st.running ? 'disabled' : ''}>Open in Multiway tab</button>
        ${NATIVE ? `<button type="button" class="btn primary" id="sd-run" ${st.running ? 'disabled' : ''}>Run study</button><button type="button" class="btn" id="sd-stop" ${st.running ? '' : 'disabled'}>Stop</button>` : ''}</div>` : ''}
      ${st.running ? `<p class="small" id="sd-progress">Running${p && p.variant ? ': variant ' + esc(p.variant) + ' (' + (p.variantIndex + 1) + '/' + p.variants + '), seed ' + (p.seedIndex + 1) + '/' + p.seeds + ', budget ' + (p.budgetIndex + 1) + '/' + p.budgets + ' (' + S.deals(p.budgetDeals) + ' deals)' : '…'} · ${S.fmt(st.status ? st.status.elapsedSeconds : 0, 0)} s elapsed · phase ${esc(p?.phase||'starting')} · ${esc(p?.trainer?.estimator||'algorithm pending')} ${esc(p?.trainer?.weighting||'')} · observed device ${esc(p?.trainingDevicePath||'pending')}${p?.sampledDeals!=null?' · '+S.deals(p.sampledDeals)+' sampled deals · table '+S.fmt(p.tableMiB,1)+' MiB · peak RAM '+S.fmt(p.processPeakRssMiB,0)+' MiB':''}</p>` : ''}
      ${st.error ? `<p class="warn" id="sd-error">${esc(st.error)}</p>` : ''}</div>
      ${recoveryCard()}
      <div class="card"><div class="row sb"><h2>Solver quality and progress</h2><div class="row"><label class="btn sm">Open result file<input type="file" id="sd-result-file" accept=".json,application/json" hidden></label>
        <button type="button" class="btn sm" id="sd-json" ${st.result ? '' : 'disabled'}>Export JSON</button><button type="button" class="btn sm" id="sd-csv" ${st.result ? '' : 'disabled'}>Export CSV</button></div></div>
      <div id="sd-result">${resultCard()}</div></div>`;
  }
  async function poll() {
    while (st.running) {
      try { st.status = await napi('/api/study/status'); } catch (e) { st.error = e.message; st.running = false; break; }
      if (!st.status.running) {
        st.running = false;
        if (st.status.error) st.error = st.status.error;
        else { try { st.result = S.validateResult(await napi('/api/study/result')); st.resultSource = 'this application'; EM.STUDY_LAST = st.result; } catch (e) { st.error = e.message; } }
        break;
      }
      render(); await new Promise(r => setTimeout(r, 400));
    }
    render(); loadCheckpoints();
  }
  function recoveryCard() {
    const d = st.result, p = st.status && st.status.progress, list = st.checkpoints && st.checkpoints.checkpoints || [];
    const yes = (v, good = 'yes', bad = 'no') => v === null || v === undefined ? '<span class="muted">unknown</span>' : v ? '<b>' + good + '</b>' : '<b class="warn">' + bad + '</b>';
    let live = '';
    if (st.running) { const t = S.progressText(p, st.status); live = `<h3>Running study</h3><div class="sd-table"><table id="sd-live"><tbody>${t.lines.map(([k, v]) => `<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join('')}</tbody></table></div>`; }
    let acc = '';
    if (d) { const rows = S.accuracy(d), ck = d.run.checkpoint, comp = d.completion;
      acc = `<h3>Last result: ${esc(d.fixture.title)}</h3>${comp && !comp.complete ? `<p class="warn" id="sd-incomplete"><b>Incomplete study</b> (${esc(comp.status)}): ${comp.pointsCompleted} of ${comp.pointsRequested} measurements. ${esc(comp.meaning)}${comp.resumable ? ' It can be resumed below.' : ''}</p>` : ''}
        <div class="sd-table"><table id="sd-accuracy"><thead><tr><th>Variant</th><th>Training</th><th>Evaluation</th><th>Confidence calibrated</th><th>Best action supported</th><th>Tolerance met</th><th>Quality metric</th><th>Checkpoint</th><th>Can resume</th></tr></thead><tbody>
        ${rows.map(r => `<tr data-sd-accuracy="${esc(r.variant)}"><td><b>${esc(r.variant)}</b>${r.budget != null ? '<br><span class="small muted">at ' + S.deals(r.budget) + ' deals</span>' : ''}</td><td>${yes(r.trainingComplete, 'complete', 'incomplete')}</td><td>${yes(r.evaluationComplete, 'complete', 'incomplete')}</td><td data-k="calibrated">${yes(r.calibrated, 'yes', 'NO')}<br><span class="small muted">${esc(r.calibrationMethod)}</span></td><td data-k="supported">${yes(r.bestActionSupported, 'yes', 'no')}<br><span class="small muted">${esc(r.verdict)}${r.acrossTrainingsVerdict ? '<br>across trainings: ' + esc(r.acrossTrainingsVerdict) + ' (' + esc(r.trainings) + (r.trainings === 1 ? ' training' : ' trainings') + (r.minimumTrainings != null ? ', ' + esc(r.minimumTrainings) + ' needed' : '') + ')' : ''}</span></td><td>${yes(r.toleranceMet)}</td><td>${esc(r.metric)}</td><td>${yes(r.checkpointAvailable, 'saved', 'none')}</td><td>${yes(r.resumable, 'yes', 'no')}</td></tr>`).join('')}
        </tbody></table></div>
        ${rows.some(r => r.warnings.length) ? '<ul class="small" id="sd-warnings">' + rows.flatMap(r => r.warnings.map(w => `<li class="${/not calibrated|Incomplete/.test(w) ? 'warn' : ''}"><b>${esc(r.variant)}:</b> ${esc(w)}</li>`)).join('') + '</ul>' : ''}
        ${ck && ck.enabled ? `<p class="small muted">Checkpoint folder: ${esc(ck.directory)} · ${ck.commits} commits, ${ck.engineStateWrites} engine states (${S.fmt(ck.engineStateMiBWritten, 1)} MiB, ${S.fmt(ck.secondsWriting, 2)} s writing)${ck.resumed ? ' · resumed ' + ck.resumeCount + ' time' + (ck.resumeCount === 1 ? '' : 's') + ', ' + ck.pointsRestored + ' measurements restored' : ''}${(ck.warnings || []).length ? ' · <b class="warn">' + ck.warnings.map(esc).join('; ') + '</b>' : ''}</p>` : ''}`; }
    const saved = !NATIVE ? '<p class="small muted">Saved studies are listed in the desktop application.</p>' : st.ckError ? `<p class="warn">${esc(st.ckError)}</p>` : !list.length ? '<p class="small muted" id="sd-nockpt">No saved study checkpoints.</p>' :
      `<div class="sd-table"><table id="sd-checkpoints"><thead><tr><th>Saved study</th><th>Status</th><th>Measurements</th><th>Saved</th><th>Time used</th><th></th></tr></thead><tbody>${list.map(c => `<tr data-sd-ckpt="${esc(c.id)}"><td><b>${esc(c.fixtureId || c.id)}</b><br><span class="small muted">${esc(c.id)}${c.preset && c.preset !== 'fixture' ? ' · ' + esc(c.preset) : ''}</span></td><td>${esc(c.status)}${c.sameBuild ? '' : '<br><span class="small warn">saved by build ' + esc(c.build) + '; resumable only with that build</span>'}${c.readFromPreviousManifest ? '<br><span class="small warn">latest manifest unreadable; previous commit shown</span>' : ''}</td><td>${c.pointsCompleted} of ${c.pointsRequested}</td><td>${c.savedAtUnixSeconds ? esc(new Date(c.savedAtUnixSeconds * 1000).toLocaleString()) : '–'}</td><td>${S.fmt(c.elapsedSeconds, 0)} s</td><td><button type="button" class="btn sm primary" data-sd-resume="${esc(c.id)}" ${c.resumable && !st.running ? '' : 'disabled'}>Resume</button> <button type="button" class="btn sm" data-sd-discard="${esc(c.id)}" ${st.running && st.status && st.status.checkpointId === c.id ? 'disabled' : ''}>Discard</button></td></tr>`).join('')}</tbody></table></div><p class="small muted">Folder: ${esc(st.checkpoints.directory)}</p>`;
    return `<div class="card" id="sd-recovery"><div class="row sb"><h2>Study accuracy and recovery</h2>${NATIVE ? '<button type="button" class="btn sm" id="sd-refresh">Refresh</button>' : ''}</div>
      <p class="small muted">Desktop studies are saved automatically (every completed measurement, every trained budget and at least once a minute while training). A study interrupted by Stop, a time or memory limit, closing the application or a crash continues from its last committed checkpoint and produces the same result as an uninterrupted run. A crash can lose the work since the last commit, never a committed one.</p>
      ${live}${acc}<h3>Saved studies</h3>${saved}</div>`;
  }
  root.addEventListener('change', e => {
    const t = e.target;
    if (t.id === 'sd-pick') { choose(st.fixtures[+t.value]); render(); }
    if (t.id === 'sd-variant') st.variant = t.value;
    if (t.id === 'sd-seeds') st.seeds = t.value;
    if (t.id === 'sd-budgets') st.budgets = t.value;
    if (t.id === 'sd-threads') st.threads = t.value;
    if(t.id==='sd-preset'){st.preset=t.value;if(presets54[t.value])Object.assign(st,presets54[t.value]);render();}
    if(t.id==='sd-mode')st.mode=t.value;
    for(const k of ['timeLimit','memory','samples','qualitySamples'])if(t.id==='sd-'+k)st[k]=t.value;
    if (t.id === 'sd-file' && t.files[0]) t.files[0].text().then(x => { const f = S.validateFixture(JSON.parse(x.replace(/^﻿/, ''))); choose(f); st.checks = S.completeFixture(f).checks; render(); }).catch(err => { st.error = 'Could not open the study fixture: ' + err.message; render(); });
    if (t.id === 'sd-result-file' && t.files[0]) { const name = t.files[0].name; t.files[0].text().then(x => { st.result = S.validateResult(JSON.parse(x.replace(/^﻿/, ''))); st.resultSource = name; st.openVariant = 0; st.error = ''; EM.STUDY_LAST = st.result; render(); }).catch(err => { st.error = 'Could not open the study result: ' + err.message; render(); }); }
  });
  root.addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.sdOpen != null) { st.openVariant = +b.dataset.sdOpen; render(); return; }
    if (b.dataset.sdSeeds) { st.showSeeds = !st.showSeeds; render(); return; }
    if (b.id === 'sd-json' && st.result) download('EightMax-study-' + st.result.fixture.id + '.json', JSON.stringify(st.result, null, 1), 'application/json');
    if (b.id === 'sd-csv' && st.result) download('EightMax-study-' + st.result.fixture.id + '.csv', S.toCSV(st.result), 'text/csv');
    if (b.id === 'sd-multiway' && fx()) {
      const v = fx().variants.find(x => x.name === st.variant) || fx().variants[0];
      if (!openInMultiway(JSON.parse(JSON.stringify(v.spot)), fx(), v)) { st.error = 'The Multiway tab is busy; stop its training first.'; render(); }
    }
    if (b.id === 'sd-stop' && st.running) napi('/api/study/stop', {}).catch(() => {});
    if (b.id === 'sd-refresh') { loadCheckpoints(); return; }
    if (b.dataset.sdResume && !st.running) { st.error = ''; try { const o = {}; if (String(st.threads).trim() !== '') o.threads = Number(st.threads); await napi('/api/study/resume', { checkpointId: b.dataset.sdResume, options: o }); st.running = true; st.status = null; render(); poll(); } catch (err) { st.error = 'Could not resume: ' + err.message; render(); } return; }
    if (b.dataset.sdDiscard) { if (typeof confirm === 'function' && !confirm('Delete the saved study ' + b.dataset.sdDiscard + '? Its checkpoint cannot be recovered.')) return; try { await napi('/api/study/discard', { checkpointId: b.dataset.sdDiscard }); } catch (err) { st.error = 'Could not discard: ' + err.message; } loadCheckpoints(); return; }
    if (b.id === 'sd-run' && fx() && !st.running) {
      st.error = '';
      try {
        const done = S.completeFixture(fx()); st.checks = done.checks;
        const bad = done.checks.find(c => c.rebuiltEqualsStored === false); if (bad) throw new Error('Variant ' + bad.variant + ': the specification stored in the fixture differs from the one this application builds from its form state');
        const options = { variants: st.variant,preset:st.preset,processingMode:st.mode };
        for(const [k,target] of [['timeLimit','timeLimitSeconds'],['memory','memoryMiB'],['samples','evaluationSamples'],['qualitySamples','qualitySamples']])if(String(st[k]).trim()!==''){const v=Number(st[k]);if(!Number.isFinite(v)||v<0)throw new Error('Invalid '+k);options[target]=v;}
        const n = Number(st.seeds); if (!Number.isInteger(n) || n < 1 || n > 100) throw new Error('Seeds must be a whole number from 1 to 100');
        options.seeds=n<=fx().study.seeds.length?fx().study.seeds.slice(0,n):Array.from({length:n},(_,i)=>101+i);
        const budgets = String(st.budgets).split(/[\s,]+/).filter(Boolean).map(Number); if (!budgets.length || budgets.some(x => !Number.isInteger(x) || x < 1) || budgets.some((x, i) => i && x <= budgets[i - 1])) throw new Error('Budgets must be increasing whole numbers of sampled deals');
        options.budgets = budgets;
        if (String(st.threads).trim() !== '') { const th = Number(st.threads); if (!Number.isInteger(th) || th < 1 || th > 256) throw new Error('Worker threads must be 1 to 256'); options.threads = th; }
        await napi('/api/study/start', { fixture: done.fixture, options });
        st.running = true; st.status = null; render(); poll();
      } catch (err) { st.error = err.message; render(); }
    }
  });
  async function loadCheckpoints() { if (!NATIVE) return; try { st.checkpoints = await napi('/api/study/checkpoints'); st.ckError = ''; } catch (e) { st.checkpoints = null; st.ckError = e.message; } render(); }
  render(); loadCheckpoints();
  // resume the display of a study started earlier in this host session
  if (NATIVE) napi('/api/study/status').then(s => { if (s.running) { st.running = true; st.status = s; render(); poll(); } else if (s.hasResult && !st.result) napi('/api/study/result').then(r => { st.result = S.validateResult(r); st.resultSource = 'this application'; EM.STUDY_LAST = st.result; render(); }).catch(() => {}); }).catch(() => {});
  return { render, get state() { return st; } };
};
})(globalThis.EM || (globalThis.EM = {}));
