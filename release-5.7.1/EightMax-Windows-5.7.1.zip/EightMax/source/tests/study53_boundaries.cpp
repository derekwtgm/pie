// Drives the normal study C API, with deterministic cancellation on its progress
// events. No solver mocks and no production-only fault-injection switches.
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include "mw.h"
#include "json.h"
struct Context { volatile int stop=0; std::string phase;int wanted=1,seen=0; };
static void progress(void*ctx,const char*j){auto&c=*(Context*)ctx;char e[128];JV*r=json_parse(j,std::strlen(j),e,sizeof e);const JV*p=r?jget(r,"phase"):nullptr;if(p&&p->type==J_STR&&c.phase==p->str&&++c.seen==c.wanted)__atomic_store_n(&c.stop,1,__ATOMIC_RELAXED);if(r)json_free(r);}
int main(int argc,char**argv){if(argc<6)return 2;std::ifstream f(argv[1]);std::stringstream b;b<<f.rdbuf();std::string fx=b.str();Context c;c.phase=argv[3];c.wanted=std::stoi(argv[4]);JB out;jb_init(&out);char err[768]="";mw_study_identity("5.3","boundary-driver");int st=mw_study_run(fx.data(),fx.size(),argv[5],std::strlen(argv[5]),&out,err,sizeof err,&c.stop,progress,&c);if(st!=200){fprintf(stderr,"%d %s\n",st,err);return 1;}std::ofstream o(argv[2]);o.write(out.s,out.n);jb_free(&out);return 0;}
