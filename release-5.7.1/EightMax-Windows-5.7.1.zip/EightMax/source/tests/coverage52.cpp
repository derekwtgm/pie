// EightMax 5.2: a deadline or a cancellation that falls into a coverage-tier promotion is noticed by the promoting
// thread itself (native/coverage.hpp: SharedCoverage::stopCheck).
//
// 5.1: the thread that prepares and copies a larger tier did not read the clock, and with one evaluation worker
// (or with every other worker waiting for the exclusive section) nobody else did either, so a stop was only
// published after the promotion. This test drives a SharedCoverage with ONE thread, as a single evaluation
// worker does, and a stop check that publishes a stop at its k-th call:
//   - without a stop check (5.1 behaviour, EM_EV_PROMOTION_CHECK=0) every promotion completes and the check is
//     never consulted;
//   - with it, the stop is published DURING the promotion, the promotion is abandoned, the present tier stays
//     current and every key inserted so far is still found exactly once;
//   - after the stop is cleared the parked tier is reused, promotions resume and all keys are counted exactly.
// Deterministic: no clock is involved. Prints one JSON object per check and a final {"failures":n}.
#include <atomic>
#include <cstdio>
#include <vector>
#include "coverage.hpp"
using emcov::Budget; using emcov::Coverage; using emcov::Key; using emcov::SharedCoverage;
static int failures = 0;
static void check(const char *name, bool ok, long long a = 0, long long b = 0) { std::printf("{\"check\":\"%s\",\"passed\":%s,\"a\":%lld,\"b\":%lld}\n", name, ok ? "true" : "false", a, b); if (!ok) failures++; }
struct Ctx { std::atomic<int> stop{0}; long long calls = 0, fireAt = -1; };
int main() {
  const size_t N = 200000;
  auto key = [](size_t i) { return Key{0x9e3779b97f4a7c15ULL * (i + 1), (uint64_t)(i % 7) + 1}; };
  // --- 5.1 behaviour: no stop check ---
  { auto ledger = std::make_shared<Budget>(64u << 20); SharedCoverage s(ledger, 60u << 20); Ctx c; s.stop = &c.stop;
    for (size_t i = 0; i < N; i++) s.mark(key(i), Coverage::STORED);
    check("no stop check: promotions complete, the check is never called", s.promotions.load() >= 3 && s.copyChecks.load() == 0 && (size_t)s.distinct == N, (long long)s.promotions.load(), (long long)s.copyChecks.load()); }
  // --- 5.2: the promoting thread consults the check; the stop arrives inside a promotion ---
  { auto ledger = std::make_shared<Budget>(64u << 20); SharedCoverage s(ledger, 60u << 20); Ctx c; s.stop = &c.stop; s.stopCheckCtx = &c;
    s.stopCheck = [](void *p) { Ctx &x = *static_cast<Ctx *>(p); if (++x.calls == x.fireAt) x.stop.store(2); };
    size_t i = 0; for (; i < N / 2; i++) s.mark(key(i), Coverage::STORED);
    const size_t promoted = s.promotions.load(), callsBefore = (size_t)c.calls;
    check("the promoting thread calls the stop check while it prepares and copies a tier", callsBefore > 0 && s.copyChecks.load() == callsBefore, (long long)callsBefore, (long long)promoted);
    c.fireAt = c.calls + 2;   // publish a stop at the second check of the NEXT promotion
    size_t atStop = 0; for (; i < N && !c.stop.load(); i++) { s.mark(key(i), Coverage::STORED); atStop = i + 1; }
    check("a stop published inside a promotion is seen before the promotion finishes", c.stop.load() == 2 && atStop < N, (long long)atStop, (long long)N);
    check("that promotion is abandoned and the present tier stays current", s.abandoned.load() == 1 && s.promotions.load() == promoted, (long long)s.abandoned.load(), (long long)s.promotions.load());
    check("every key inserted before the stop is still held exactly once", (size_t)s.distinct == atStop, (long long)(size_t)s.distinct, (long long)atStop);
    for (size_t k = 0; k < atStop; k++) s.mark(key(k), Coverage::STORED);   // re-marking finds every key: the count must not change
    check("re-marking the same keys while the stop is pending adds none", (size_t)s.distinct == atStop, (long long)(size_t)s.distinct, (long long)atStop);
    c.stop.store(0); c.fireAt = -1;
    for (; i < N; i++) s.mark(key(i), Coverage::STORED);
    check("after the stop is cleared promotions resume and the count is exact", (size_t)s.distinct == N && s.promotions.load() > promoted && s.status.load() == emcov::COV_OK, (long long)(size_t)s.distinct, (long long)s.promotions.load());
    check("the ledger was never exceeded", ledger->peak.load() <= (64u << 20), (long long)ledger->peak.load(), 64ll << 20); }
  std::printf("{\"failures\":%d}\n", failures);
  return failures ? 1 : 0;
}
