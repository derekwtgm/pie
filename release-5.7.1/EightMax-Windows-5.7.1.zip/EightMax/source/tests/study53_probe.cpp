// JSON-lines adapter to the shipped aggregate/statistics functions; no alternate estimator.
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <iostream>
#include <string>
#include "mw.h"
#include "json.h"
#include "study52.hpp"
int main(){using namespace study52;std::string line;while(std::getline(std::cin,line)){char err[256]="";JV*r=json_parse(line.data(),line.size(),err,sizeof err);if(!r)return 2;
 if(at(r,"ebVariance")){Out o;o.raw("{");o.kn("half",study55::ebHalf(numOr(at(r,"ebVariance"),NAN),numOr(at(r,"range"),NAN),numOr(at(r,"n"),NAN),numOr(at(r,"delta"),NAN)));o.raw("}");puts(o.s.c_str());json_free(r);continue;}
 if(at(r,"df")){Out o;o.raw("{");o.kn("critical",study53::critical(numOr(at(r,"df"),1),numOr(at(r,"alpha"),.05)));o.raw("}");puts(o.s.c_str());json_free(r);continue;}
 Variant v;const JV*x=at(r,"values"),*e=at(r,"errors"),*pairs=at(r,"pairErrors");int k=idx(x,0)?idx(x,0)->n:0;for(int j=0;j<k;j++)v.labels.push_back(std::to_string(j));v.unit="BB";v.comparisonFamily=(int)numOr(at(r,"family"),std::max(1,k*(k-1)/2));
 for(int i=0;x&&i<x->n;i++){Point p;p.have=true;p.complete=true;p.status="completed";p.independentEvaluation=at(r,"independent")&&at(r,"independent")->num!=0;p.evSamples=(long long)numOr(at(r,"samples"),1000);p.evMethod=strOr(at(r,"method"),"sampled");p.qualityKind=p.evMethod;p.qualitySamples=p.evSamples;
  // 5.5: optional per-replication payoff bound {"ranges":[R..],"within":[bool..],"sampleCounts":[n..]}
  if(const JV*rg=idx(at(r,"ranges"),i)){p.evLower=0;p.evUpper=numOr(rg,NAN);p.evWithin=!at(r,"within")||(idx(at(r,"within"),i)&&idx(at(r,"within"),i)->num!=0);}if(const JV*sc=idx(at(r,"sampleCounts"),i))p.evSamples=(long long)numOr(sc,0);
  for(int j=0;j<k;j++){p.ev.push_back(numOr(idx(idx(x,i),j),NAN));p.se.push_back(numOr(idx(idx(e,i),j),NAN));p.freq.push_back(1.0/k);p.fallback.push_back(0);std::vector<double> row;for(int t=0;t<k;t++)row.push_back(numOr(idx(idx(idx(pairs,i),j),t),NAN));p.pairSe.push_back(row);}v.seeds.push_back({p});}
 Tol tol;tol.evGap=numOr(at(r,"margin"),.05);auto a=aggregate(v,0,tol);Out o;aggW(o,v,a,1,tol);puts(o.s.c_str());json_free(r);
 }return 0;}
