// EightMax 5.5: unbiasedness and variance of the experimental river opponent enumeration ("opponentEnumeration":"river").
// Usage: enum55 spec.json prefixDeals trials [control]
//
// One engine is trained for `prefixDeals` updates with the default estimator. Its tables (cumulative regrets and
// average-strategy sums of every row) are then FROZEN and `trials` independent deals are traversed with the default
// estimator and `trials` with the candidate, each from a different pseudorandom stream, for every updating seat. The
// increment each traversal would add to every table entry is recorded. If both estimators are unbiased for the same quantity, the mean increment of every
// entry agrees within Monte Carlo error. Reported: the largest two-sample z statistic over all entries (regret and
// average entries separately), the share of |z| > 1.96, and the ratio of summed increment variances.
// Includes mw.cpp to read the tables directly; no engine code is modified.
#include "../native/mw.cpp"
#include <fstream>
#include <iterator>
int main(int argc, char **argv) {
  if (argc != 4 && argc != 5) { std::fprintf(stderr, "usage: enum55 spec.json prefixDeals trials [control]\n"); return 2; }
  const bool control = argc == 5;   // control: both arms use the DEFAULT estimator (different streams); calibrates the test itself
  std::ifstream file(argv[1]); std::string spec{std::istreambuf_iterator<char>(file), {}};
  const long long prefix = std::atoll(argv[2]), trials = std::atoll(argv[3]); char error[512] = {};
  MW *m = mw_create(spec.data(), spec.size(), 256, error, sizeof error);
  if (!m) { std::fprintf(stderr, "%s\n", error); return 1; }
  if (m->batchDeals != 1) { std::fprintf(stderr, "use batchDeals 1\n"); return 2; }
  es::Game &g = *m->es; g.enumerateFrom = 0;
  if (!mw_train(m, prefix, 1, nullptr, nullptr, nullptr, error, sizeof error)) { std::fprintf(stderr, "%s\n", error); return 1; }
  const std::vector<double> base(m->vals.begin(), m->vals.end()); const size_t rows = m->rows.size(), states = g.states.parent.size(), N = base.size();
  const long long it0 = m->iterations, deals0 = m->trainingDeals, visits0 = m->stateVisits;
  std::vector<char> isRegret(N, 0); for (const auto &r : m->rows) for (int a = 0; a < r.k; a++) isRegret[r.off + (size_t)a] = 1;
  std::vector<long double> add(N, 0); std::vector<long double> sum[2], sq[2]; for (int e = 0; e < 2; e++) { sum[e].assign(N, 0); sq[e].assign(N, 0); }
  double seconds[2] = {0, 0}; long long visits[2] = {0, 0};
  // The traversal is driven exactly as es::train() drives it (deal, score, card codes, one Walker::run per updating
  // seat) but NOTHING is merged: every seat of every trial reads the same frozen table. (Through mw_train the second
  // seat of an update would read the first seat's freshly merged increments, whose distribution differs between the
  // estimators, so expected increments of later seats legitimately differ at second order.)
  ScratchBudget budget((size_t)64 << 20, g.scratchPeak); es::Walker walker(*m, g, budget); es::Unit u(budget);
  g.setStoreCap(m->budgetBytes); g.extendStore(m->stateVisits); g.unitLimitBytes = (size_t)16 << 20;
  const double step = m->linear ? (double)(it0 + 1) : 1.0, avgStep = step;
  for (int e = 0; e < 2; e++) {
    g.enumerateFrom = e && !control ? 5 : 0;
    for (long long s = 0; s < trials; s++) {
      const uint32_t seed = study53::mix((uint32_t)(s * 2 + e) + 0x55u);
      m->rng.state = seed; Rng actions{study53::mix(seed ^ 0xabcdef01u)};
      u.clear(); if (!m->deal(u.w, 0)) { std::fprintf(stderr, "deal failed\n"); return 1; }
      m->score(u.w); es::codes(u, m->n);
      const double t0 = es::now();
      for (int p = 0; p < m->n; p++) {
        u.pending.clear(); u.incs.clear(); u.vals.clear();
        walker.run(u, p, actions, step, avgStep);
        if (u.overflow || !u.pending.empty()) { std::fprintf(stderr, "the traversal reached an unvisited state: use a longer prefix\n"); return 3; }
        for (const es::Inc &inc : u.incs) {
          const long long r = m->findRow(es::rowKey((uint32_t)inc.ref, inc.hand, inc.code));
          if (r < 0) { std::fprintf(stderr, "the traversal reached an unvisited row: use a longer prefix\n"); return 3; }
          const size_t o = m->rows[(size_t)r].off;
          for (int a = 0; a < 2 * inc.k; a++) { const long double d = u.vals[inc.off + (size_t)a]; add[o + (size_t)a] += d; }
        }
        visits[e] += u.visits; u.visits = 0;
      }
      seconds[e] += es::now() - t0;
      // one trial's increment of entry i is the sum over the seats' traversals
      for (size_t i = 0; i < N; i++) if (add[i] != 0) { sum[e][i] += add[i]; sq[e][i] += add[i] * add[i]; add[i] = 0; }
    }
  }
  double maxZ[2] = {0, 0}, var[2][2] = {{0, 0}, {0, 0}}; long long cnt[2] = {0, 0}, over[2] = {0, 0}, deterministicMismatch = 0;
  for (size_t i = 0; i < N; i++) {
    const int kind = isRegret[i] ? 0 : 1; long double mean[2], v[2];
    for (int e = 0; e < 2; e++) { mean[e] = sum[e][i] / trials; v[e] = (sq[e][i] - trials * mean[e] * mean[e]) / (trials - 1); if (v[e] < 0) v[e] = 0; var[kind][e] += (double)v[e]; }
    const long double se = std::sqrt((double)((v[0] + v[1]) / trials));
    if (se == 0) { if (std::fabs((double)(mean[0] - mean[1])) > 1e-9 * std::max(1.0, std::fabs((double)mean[0]))) deterministicMismatch++; continue; }
    const double z = std::fabs((double)((mean[0] - mean[1]) / se)); cnt[kind]++; over[kind] += z > 1.959963984540054; maxZ[kind] = std::max(maxZ[kind], z);
  }
  std::printf("{\"arms\":\"%s\",\"prefixDeals\":%lld,\"trials\":%lld,\"rows\":%zu,\"states\":%zu,\"entries\":%zu,"
              "\"regret\":{\"tested\":%lld,\"maxAbsZ\":%.4f,\"shareAbove1.96\":%.5f,\"varianceDefault\":%.9g,\"varianceCandidate\":%.9g,\"varianceRatio\":%.5f},"
              "\"average\":{\"tested\":%lld,\"maxAbsZ\":%.4f,\"shareAbove1.96\":%.5f,\"varianceDefault\":%.9g,\"varianceCandidate\":%.9g,\"varianceRatio\":%.5f},"
              "\"deterministicMismatches\":%lld,\"secondsPerUpdate\":[%.9g,%.9g],\"stateVisitsPerUpdate\":[%.3f,%.3f]}\n",
              control ? "default vs default (control)" : "default vs river enumeration", prefix, trials, rows, states, N, cnt[0], maxZ[0], cnt[0] ? (double)over[0] / cnt[0] : 0, var[0][0], var[0][1], var[0][0] > 0 ? var[0][1] / var[0][0] : 0,
              cnt[1], maxZ[1], cnt[1] ? (double)over[1] / cnt[1] : 0, var[1][0], var[1][1], var[1][0] > 0 ? var[1][1] / var[1][0] : 0,
              deterministicMismatch, seconds[0] / trials, seconds[1] / trials, (double)visits[0] / trials, (double)visits[1] / trials);
  mw_free(m); return 0;
}
