'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process');const G=require('../tools/games48'),build=require('./native_build');
const cli=()=>process.env.EM_TEST_MWCLI||build.cli().cli;
const {withHost,home}=require('./checkpoint_host');
test('5.4 desktop publishes complete large progress JSON and remains cancellable',{timeout:120000},async t=>{
  const f=JSON.parse(fs.readFileSync(path.join(__dirname,'../studies/known-akq-river.emfix.json')));
  f.variants=f.variants.slice(0,1);f.variants[0].name='progress-"\\\n'+ 'x'.repeat(10000);
  await withHost(home(t),{},async api=>{
    assert.equal((await api('study/start',{fixture:f,options:{seeds:2,budgets:[100000000],threads:1,timeLimitSeconds:30}})).status,200);
    let seen=false,st;
    for(let i=0;i<300;i++){
      st=await(await api('study/status')).json();
      if(st.progress?.phase==='training'){
        assert.equal(st.progress.variant,f.variants[0].name);assert.ok(st.progress.sampledDeals>0);
        assert.ok(JSON.stringify(st.progress).length>10000);assert.ok(st.progress.trainer);seen=true;break;
      }
      if(!st.running)break;
      await new Promise(r=>setTimeout(r,20));
    }
    assert.equal((await api('study/stop',{})).status,200);
    for(let i=0;i<3000;i++){st=await(await api('study/status')).json();if(!st.running)break;await new Promise(r=>setTimeout(r,20));}
    assert.ok(seen,'observed complete large training progress');assert.equal(st.running,false);assert.equal(st.error,null);
    const result=await(await api('study/result')).json();assert.equal(result.run.stoppedByUser,true);
    assert.ok(result.variants.every(v=>v.budgets.every(b=>!b.complete&&!b.meetsTolerance)));
  });
});
function tmp(t){let d=fs.mkdtempSync(path.join(os.tmpdir(),'em54-'));t.after(()=>fs.rmSync(d,{recursive:true,force:true}));return d;}
function run(a,env={}){let r=cp.spawnSync(cli(),a.map(String),{encoding:'utf8',timeout:180000,maxBuffer:64<<20,env:{...process.env,...env}});assert.equal(r.status,0,r.stderr);return JSON.parse(r.stdout);}
function study(t,opts=[],alter=f=>f){let d=tmp(t),f=alter(JSON.parse(fs.readFileSync(path.join(__dirname,'../studies/known-akq-river.emfix.json'))));fs.writeFileSync(d+'/f',JSON.stringify(f));let r=cp.spawnSync(cli(),['--study',d+'/f',d+'/r','quiet=1',...opts],{encoding:'utf8',timeout:180000});return {r,doc:r.status===0?JSON.parse(fs.readFileSync(d+'/r')):null};}
test('5.4 exact policy cache preserves values and logical coverage for river turn sidepots and ICM',{timeout:600000},t=>{for(const key of ['hu-river','hu-turn','river3-chip','bubble4']){let d=tmp(t);fs.writeFileSync(d+'/s',JSON.stringify(G.spec(key,804)));run([d+'/s',1000,1,d+'/st',128]);fs.writeFileSync(d+'/q',JSON.stringify({method:'exact',device:'cpu',threads:1,timeLimitMs:180000}));let a=run(['--gain',d+'/s',d+'/st',d+'/q']),b=run(['--gain',d+'/s',d+'/st',d+'/q'],{EM_BR_NO_POLICY_CACHE:'1'});assert.equal(a.nashConv,b.nashConv);assert.equal(a.largestUnilateralGain,Math.max(...a.seats.map(x=>x.gain)));for(let i=0;i<a.seats.length;i++)for(const k of ['gain','gainBits','policyValue','bestResponseValue','policyLookups','fallbackLookups','distinctInformationSets','distinctFallbackInformationSets'])assert.deepEqual(a.seats[i][k],b.seats[i][k],key+' '+k);}});
test('5.4 native presets respect explicit overrides',t=>{let {r,doc}=study(t,['preset=deep','seeds=2','budgets=100,200','timeLimitSeconds=10','memoryMiB=32','processingMode=cpu']);assert.equal(r.status,0,r.stderr);assert.equal(doc.run.preset,'deep');assert.equal(doc.run.seeds.length,2);assert.equal(doc.run.tableBudgetMiB,32);assert.equal(doc.run.processingModeRequested,'cpu');assert.equal(doc.run.timeLimitSeconds,10);assert.ok(doc.variants[0].budgets.every(x=>x.complete));assert.ok(doc.variants[0].perSeed.every(x=>x.budgets.every(b=>b.trainingDeviceRequested==='cpu')));});
test('5.4 quick is preliminary and generates independent seed list',t=>{let {r,doc}=study(t,['preset=quick','budgets=100']);assert.equal(r.status,0,r.stderr);assert.equal(doc.run.preliminary,true);assert.deepEqual(doc.run.seeds,[101,102]);});
test('5.4 sampled budget controls reach evaluators and preserve independent streams',t=>{let {r,doc}=study(t,['seeds=2','budgets=100','evaluationSamples=128','qualitySamples=64','processingMode=cpu'],f=>{f.study.ev={method:'sampled',samples:1000};f.study.quality={method:'sampled',samples:256,selectionSamples:16};return f;});assert.equal(r.status,0,r.stderr);for(let x of doc.variants[0].perSeed){assert.equal(x.budgets[0].evSamples,128);assert.equal(x.budgets[0].qualitySamples,64);}assert.notEqual(doc.variants[0].perSeed[0].budgets[0].evaluationSeed,doc.variants[0].perSeed[1].budgets[0].evaluationSeed);});
test('5.4 invalid controls are refused',t=>{for(let o of ['preset=unknown','processingMode=bad','evaluationSamples=63','qualitySamples=64.5'])assert.notEqual(study(t,[o,'budgets=100']).r.status,0,o);});
test('5.4 interrupted study cannot rank or claim tolerance',t=>{let {r,doc}=study(t,['preset=deep','timeLimitSeconds=0.001']);assert.equal(r.status,0,r.stderr);assert.equal(doc.run.stoppedByTimeLimit,true);assert.ok(doc.variants.every(v=>v.budgets.every(b=>!b.complete&&!b.meetsTolerance&&b.verdict!=='ranked')));});
test('5.4 experimental configurations have deterministic checkpoint continuation',t=>{for(let o of [{},{terminalBaseline:true},{weighting:'dcfr'},{weighting:'dcfr',dcfrGamma:3},{regretMatching:'plus'},{weighting:'uniform'}]){let d=tmp(t);fs.writeFileSync(d+'/s',JSON.stringify(G.spec('hu-river',811,o)));run([d+'/s',1000,1,d+'/full',128]);run([d+'/s',400,1,d+'/part',128]);run([d+'/s',600,1,d+'/resume',128,d+'/part']);assert.deepEqual(fs.readFileSync(d+'/full'),fs.readFileSync(d+'/resume'),JSON.stringify(o));}});
