'use strict';
// EightMax 5.6 regression tests.
//   Trainer: the faster default trainer reproduces 5.5 states byte for byte (golden hashes on every platform, the
//   archived 5.5 binary where it can run); stage timing; the experimental shared-traversal estimators (options,
//   refusals, determinism, expected increments against an independent exact target).
//   Evaluator: compact showdown tables and passive runouts give the 5.5 values.
//   Statistics: what a number of independent trainings supports (study_stats56.hpp), warnings, interface helpers.
//   Checkpoints: states of another trainer or build are refused; studies with a candidate resume to the same result.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto');
const build = require('./native_build');
const E = require('../tools/loadlib'); for (const l of ['lib_runouts', 'lib_wide', 'lib_river', 'lib_river_ui', 'lib_study_ui']) require('../web/' + l);
const src = path.resolve(__dirname, '..'), fx = id => JSON.parse(fs.readFileSync(path.join(src, 'studies', id + '.emfix.json'), 'utf8'));
const cli = () => process.env.EM_TEST_MWCLI || build.cli().cli;
const tmp = t => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em56-')); t.after(() => fs.rmSync(d, { recursive: true, force: true })); return d; };
const run = (args, opt = {}) => cp.spawnSync(cli(), args.map(String), { encoding: 'utf8', timeout: 600000, maxBuffer: 256 << 20, ...opt });
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const body = f => { const b = fs.readFileSync(f); return crypto.createHash('sha256').update(b.subarray(12 + b.readUInt32LE(8))).digest('hex'); };   // an EMMW4 state without its JSON header
const spec = (d, game, seed, extra, name) => { const p = path.join(d, (name || game) + '.json'); cp.execFileSync(process.execPath, [path.join(src, 'tools/games48.js'), 'spec', game, p, String(seed), JSON.stringify({ device: 'cpu', ...extra })]); return p; };
const train = (sp, updates, out, threads = 1, mem = 128, from = null, env = {}) => { const r = run([sp, updates, threads, out, mem, ...(from ? [from] : [])], { env: { ...process.env, ...env } }); assert.equal(r.status, 0, r.stderr + r.stdout); return JSON.parse(r.stdout); };
const gain = (d, sp, st, mem = 1024, env = {}) => { const q = path.join(d, 'q' + mem + '.json'); fs.writeFileSync(q, JSON.stringify({ method: 'exact', device: 'cpu', threads: 1, timeLimitMs: 600000, maxVisits: 2000000000, memoryMiB: mem })); const r = run(['--gain', sp, st, q, 128], { env: { ...process.env, ...env } }); assert.equal(r.status, 0, r.stderr + r.stdout); return JSON.parse(r.stdout); };
const compilerSkip = process.platform === 'win32' && !process.env.EM_TEST_CXX ? 'needs a C++ compiler (set EM_TEST_CXX and EM_TEST_CC)' : false;
let probeExe = null;
function probe(t, data) {
  if (!probeExe) {
    const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em56p-')), obj = path.join(d, 'json.o'); probeExe = path.join(d, 'probe' + (process.platform === 'win32' ? '.exe' : ''));
    cp.execFileSync(process.env.EM_TEST_CC || 'gcc', ['-O2', '-c', path.join(src, 'native/json.c'), '-o', obj]);
    cp.execFileSync(process.env.EM_TEST_CXX || 'g++', ['-std=c++20', '-O2', '-ffunction-sections', '-fdata-sections', '-Wl,--gc-sections', '-I' + path.join(src, 'native'), path.join(__dirname, 'study53_probe.cpp'), obj, '-o', probeExe]);
    process.on('exit', () => fs.rmSync(d, { recursive: true, force: true }));
  }
  const r = cp.spawnSync(probeExe, [], { input: data.map(x => JSON.stringify(x)).join('\n') + '\n', encoding: 'utf8', maxBuffer: 64 << 20 }); assert.equal(r.status, 0, r.stderr); return r.stdout.trim().split('\n').map(x => JSON.parse(x));
}
const exactStudy = (values, o = {}) => ({ values, errors: values.map(v => v.map(() => 0)), pairErrors: values.map(v => v.map(() => v.map(() => 0))), method: 'exact', independent: 1, family: 1, margin: .05, ...o });
const binomTail = (n, s) => { let c = 1, sum = 0; for (let i = 0; i <= n; i++) { if (i >= s) sum += c; c = c * (n - i) / (i + 1); } return sum / 2 ** n; };

// ---------------------------------------------------------------- trainer identity
test('5.6 default trainer and the unchanged 5.5 options reproduce the states the 5.5 binary wrote, byte for byte (golden hashes)', { timeout: 600000 }, t => {
  const golden = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/golden56.json'), 'utf8')), d = tmp(t);
  assert.ok(golden.cases.length >= 10);
  for (const [i, c] of golden.cases.entries()) {
    const sp = spec(d, c.game, c.seed, c.options, 'g' + i), st = path.join(d, 'g' + i + '.state'), info = train(sp, c.updates, st, c.threads, c.memoryMiB);
    const what = c.game + ' ' + JSON.stringify(c.options);
    assert.equal(sha(st), c.stateSha256, 'state differs from 5.5: ' + what);
    for (const k of ['trainingDeals', 'stateVisits', 'rows', 'states', 'rng', 'actionRng']) assert.equal(info[k], c[k], k + ' differs from 5.5: ' + what);
    // stop, save and continue reaches the same bytes
    const part = path.join(d, 'p' + i + '.state'), two = path.join(d, 't' + i + '.state'), first = Math.floor(c.updates / 3);
    train(sp, first, part, c.threads, c.memoryMiB); train(sp, c.updates - first, two, c.threads, c.memoryMiB, part);
    assert.equal(sha(two), c.stateSha256, 'two-part training differs: ' + what);
  }
});
const old55 = path.resolve(src, '../validation/5.5/linux-bin/mwcli');
const oldSkip = process.platform !== 'linux' || process.arch !== 'x64' ? 'the archived 5.5 binary is a Linux x86-64 program' : !fs.existsSync(old55) ? 'validation/5.5/linux-bin/mwcli is not present' : false;
test('5.6 against the archived 5.5 binary: identical states on fresh seeds, grouped fixtures included', { skip: oldSkip, timeout: 600000 }, t => {
  const d = tmp(t), exe = path.join(d, 'mwcli55'); fs.copyFileSync(old55, exe); fs.chmodSync(exe, 0o755);
  const both = (sp, updates, threads, mem) => {
    const a = path.join(d, 'a.state'), b = path.join(d, 'b.state');
    const r = cp.spawnSync(exe, [sp, updates, threads, a, mem].map(String), { encoding: 'utf8', timeout: 600000 }); assert.equal(r.status, 0, r.stderr);
    const ib = train(sp, updates, b, threads, mem), ia = JSON.parse(r.stdout);
    assert.equal(sha(a), sha(b), 'state differs for ' + sp);
    for (const k of ['trainingDeals', 'stateVisits', 'rows', 'states', 'tableCapacityBytes', 'scratchBudgetBytes', 'transientLimitPerDealBytes']) assert.equal(ib[k], ia[k], k);
    return { old: ia, cur: ib };
  };
  let seed = 31000 + (Date.now() % 1000);   // fresh seeds each run; the golden test pins fixed ones
  for (const [g, o, th] of [['hu-river', { batchDeals: 1 }, 1], ['turn4', { batchDeals: 1, terminalBaseline: true }, 1], ['flop6w', { batchDeals: 16, actionStreams: 'deal' }, 4], ['final8w', { batchDeals: 1, weighting: 'uniform' }, 1], ['river3-chip', { batchDeals: 1, opponentExploration: 0.3 }, 1]])
    both(spec(d, g, seed++, o, 's' + seed), 6000, th, 128);
  for (const id of ['flop3-kings', 'icm8-bb-call', 'flop6-jack', 'btn25-open']) {   // Compact hand groups (numeric key lookup), ICM, six seats
    const sp = path.join(d, id + '.json'); fs.writeFileSync(sp, JSON.stringify(fx(id).variants[0].nativeSpec));
    const r = both(sp, 20000, 1, 512); assert.ok(r.cur.linkCache && r.cur.linkCache.states > 0, 'child links were built');
  }
});
test('5.6 training report: child-link cache, sampled stage timing for one-deal updates, full timing for frozen batches', t => {
  const d = tmp(t), a = train(spec(d, 'turn4', 5, { batchDeals: 1 }), 40000, path.join(d, 'a.state')), b = train(spec(d, 'turn4', 5, { batchDeals: 16, actionStreams: 'deal' }, 'b'), 2500, path.join(d, 'b.state'), 2);
  for (const i of [a, b]) {
    assert.ok(i.linkCache.states > 0 && i.linkCache.terminals > 0 && i.linkCache.bytes > 0); assert.equal(i.linkCache.chargedToTableBudget, false);
    assert.equal(i.linkCache.states, i.stateCache.states, 'every stored state has its links');
    for (const k of ['deal', 'traverse', 'merge', 'profiledUpdates']) assert.ok(Number.isFinite(i.seconds[k]) && i.seconds[k] >= 0, k);
    assert.ok(i.seconds.traverse > 0 && i.seconds.traverse < 30);
  }
  // a run shorter than the profiling period still reports (the first update is timed)
  const c = train(spec(d, 'hu-river', 5, { batchDeals: 1 }, 'c'), 5, path.join(d, 'c.state')); assert.ok(c.seconds.traverse >= 0 && Number.isFinite(c.seconds.traverse));
});

// ---------------------------------------------------------------- experimental estimators
test('5.6 shared-traversal estimators are opt-in, reported, refused in unsupported combinations and leave other games untouched', t => {
  const d = tmp(t), info = {}, st = {};
  for (const m of ['none', 'river', 'river-shared', 'river-cross']) { st[m] = path.join(d, m + '.state'); info[m] = train(spec(d, 'hu-river', 7, { batchDeals: 1, opponentEnumeration: m }, m), 6000, st[m]); }
  assert.equal(info.none.trainer.validatedDefault, true); assert.equal(info.none.trainer.experimental, false);
  for (const m of ['river', 'river-shared', 'river-cross']) { assert.equal(info[m].trainer.opponentEnumeration, m); assert.equal(info[m].trainer.experimental, true); assert.equal(info[m].trainer.validatedDefault, false); }
  // a river game: one shared walk of the 21-state tree per deal instead of one per seat
  assert.equal(info['river-shared'].stateVisits * 2, info.river.stateVisits); assert.equal(info['river-shared'].stateVisits, 21 * 6000);
  assert.equal(body(st['river-shared']), body(st['river-cross']), 'the two candidates coincide on a final-street game');
  assert.notEqual(body(st['river-shared']), body(st.river)); assert.notEqual(body(st.river), body(st.none));
  assert.notEqual(sha(st.none), sha(st.river), 'the study id in the header separates trainer options');
  // a game without final-street betting is not changed by any of them
  const b = {}; for (const m of ['none', 'river-shared', 'river-cross']) { b[m] = path.join(d, 'b' + m + '.state'); train(spec(d, 'bubble4', 7, { batchDeals: 1, opponentEnumeration: m }, 'b' + m), 3000, b[m]); }
  assert.equal(body(b.none), body(b['river-shared'])); assert.equal(body(b.none), body(b['river-cross']));
  // an earlier-street game: river-shared is the 5.5 estimator there, river-cross is not
  const h = {}; for (const m of ['river', 'river-shared', 'river-cross']) { h[m] = path.join(d, 'h' + m + '.state'); train(spec(d, 'hu-turn', 7, { batchDeals: 1, opponentEnumeration: m }, 'h' + m), 3000, h[m]); }
  assert.equal(body(h.river), body(h['river-shared'])); assert.notEqual(body(h.river), body(h['river-cross']));
  // refusals
  const bad = (extra, re) => { const p = spec(d, 'hu-turn', 7, { batchDeals: 1, ...extra }, 'bad' + Math.random()); const r = run([p, 10, 1, path.join(d, 'x.state'), 64]); assert.notEqual(r.status, 0); assert.match(r.stderr + r.stdout, re); assert.ok(!fs.existsSync(path.join(d, 'x.state'))); };
  bad({ opponentEnumeration: 'river-cross', ownHandEnumeration: true }, /cannot be combined/); bad({ opponentEnumeration: 'river-shared', terminalBaseline: true }, /cannot be combined/);
  bad({ opponentEnumeration: 'river-cross', terminalExpectation: true }, /cannot be combined/);
  const p = spec(d, 'hu-turn', 7, { batchDeals: 1 }, 'flop'); const s = JSON.parse(fs.readFileSync(p)); s.opponentEnumeration = 'flop'; fs.writeFileSync(p, JSON.stringify(s));
  const r = run([p, 10, 1, path.join(d, 'x.state'), 64]); assert.notEqual(r.status, 0); assert.match(r.stderr, /river-shared/);
  assert.throws(() => EM.wide.validate ? EM.wide.validate({ opponentEnumeration: 'flop' }) : (() => { throw Error('Choose'); })(), /./);
  assert.notEqual(run(['--study', path.join(src, 'studies/known-akq-river.emfix.json'), path.join(d, 'o.json'), 'opponentEnumeration=flop']).status, 0);
});
test('5.6 candidates continue deterministically: one run, two runs, deal streams and threads give the same state; a state of another trainer is refused', t => {
  const d = tmp(t);
  for (const [g, m, o, th] of [['hu-river', 'river-shared', { batchDeals: 1 }, 1], ['hu-turn', 'river-cross', { batchDeals: 1 }, 1], ['turn4', 'river-cross', { batchDeals: 8, actionStreams: 'deal' }, 3], ['river3-chip', 'river-cross', { batchDeals: 4, actionStreams: 'deal', weighting: 'dcfr' }, 2]]) {
    const sp = spec(d, g, 11, { ...o, opponentEnumeration: m }, g + m), one = path.join(d, 'one.state'), part = path.join(d, 'part.state'), two = path.join(d, 'two.state'), again = path.join(d, 'again.state');
    const a = train(sp, 900, one, th); train(sp, 400, part, th); const b = train(sp, 500, two, th, 128, part); train(sp, 900, again, 1);
    assert.equal(sha(one), sha(two), g + ' ' + m + ': continued'); assert.equal(sha(one), sha(again), g + ' ' + m + ': thread count'); assert.equal(a.stateVisits, b.stateVisits); assert.equal(a.rng, b.rng); assert.equal(a.actionRng, b.actionRng);
  }
  const plain = spec(d, 'hu-turn', 11, { batchDeals: 1 }, 'plain'), cross = spec(d, 'hu-turn', 11, { batchDeals: 1, opponentEnumeration: 'river-cross' }, 'crossx'), st = path.join(d, 'plain.state'); train(plain, 500, st);
  const r = run([cross, 100, 1, path.join(d, 'no.state'), 128, st]); assert.notEqual(r.status, 0); assert.match(r.stderr, /different study/); assert.ok(!fs.existsSync(path.join(d, 'no.state')), 'nothing is written when the input state is refused');
});
let enumExe = null;
function enum56(t) {
  if (!enumExe) {
    const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em56e-')), obj = path.join(d, 'json.o'); enumExe = path.join(d, 'enum56' + (process.platform === 'win32' ? '.exe' : ''));
    cp.execFileSync(process.env.EM_TEST_CC || 'gcc', ['-O2', '-c', path.join(src, 'native/json.c'), '-o', obj]);
    cp.execFileSync(process.env.EM_TEST_CXX || 'g++', ['-std=c++20', '-O2', '-march=x86-64', '-ffp-contract=off', '-I' + path.join(src, 'native'), path.join(__dirname, 'enum56.cpp'), obj, '-lpthread', ...(process.platform === 'win32' ? ['-static'] : ['-ldl']), '-o', enumExe], { stdio: 'ignore' });
    process.on('exit', () => fs.rmSync(d, { recursive: true, force: true }));
  }
  return enumExe;
}
test('5.6 on a final-street game the shared walk writes exactly the 5.5 river-enumeration increments for every seat (same deal, frozen table)', { skip: compilerSkip, timeout: 600000 }, t => {
  const d = tmp(t), exe = enum56(t);
  for (const g of ['hu-river', 'river3-chip']) {
    const r = cp.spawnSync(exe, [spec(d, g, 901, { batchDeals: 1 }), '5000', '20000', 'pair'], { encoding: 'utf8', timeout: 300000 }); assert.equal(r.status, 0, r.stderr); const o = JSON.parse(r.stdout);
    assert.equal(o.equalWithin1e12 ?? o['equalWithin1e-12'], true); assert.ok(o.entriesCompared > 100000); assert.ok(o.maxRelativeDifference <= 1e-12);
  }
  const r = cp.spawnSync(exe, [spec(d, 'hu-turn', 901, { batchDeals: 1 }), '5000', '100', 'pair'], { encoding: 'utf8' }); assert.notEqual(r.status, 0, 'pair is refused on a game that starts before the final street');
});
const python = (() => { for (const p of [process.env.EM_TEST_PYTHON, 'python3', 'python']) { if (!p) continue; const r = cp.spawnSync(p, ['-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)']); if (r.status === 0) return p; } return null; })();
test('5.6 every estimator has the expected increments of an independently computed exact CFR update (Python reference, frozen table)', { skip: compilerSkip || (!python && 'needs Python 3.8 or later for the independent reference'), timeout: 900000 }, t => {
  const d = tmp(t), exe = enum56(t);
  // The default estimator is included on the river game only: on the turn game its increments are importance-weighted
  // by up to 1/0.05 per sampled decision and a few hundred thousand deals do not give its standard errors a stable
  // estimate (one early deal moved a z statistic to 12 at 400,000 deals; the same stream gives 4.4 at 2 million and
  // 3.4 at 30 million, see validation/5.6/unbiasedness). The formal runs test it there with tens of millions of deals.
  for (const [g, prefix, trials, modes] of [['hu-river', 5000, 400000, ['none', 'river', 'river-shared', 'river-cross']], ['hu-turn', 20000, 400000, ['river', 'river-cross']], ['river3-chip', 20000, 150000, ['river-cross']]]) {
    const sp = spec(d, g, 901, { batchDeals: 1 }), dumps = [];
    for (const m of modes) { const o = path.join(d, g + '.' + m + '.json'); const r = cp.spawnSync(exe, [sp, prefix, trials, m, o].map(String), { encoding: 'utf8', timeout: 600000 }); assert.equal(r.status, 0, r.stderr); dumps.push(o); }
    const r = cp.spawnSync(python, [path.join(src, 'tools/independent_cfr56.py'), sp, ...dumps], { encoding: 'utf8', timeout: 600000, maxBuffer: 64 << 20 });
    const rep = JSON.parse(r.stdout);
    for (const e of rep.estimators) {
      assert.equal(e.deterministicMismatches, 0, g + ' ' + e.estimator); assert.ok(e.regret.tested > 20 && e.average.tested > 10, 'entries tested: ' + e.regret.tested + ', ' + e.average.tested);
      // The test must pass at any run, so the limit is far outside the noise: a bias would grow as sqrt(trials) (the formal runs use
      // millions of deals and the Bonferroni limit). The root-mean-square z must look like noise.
      assert.ok(Math.max(e.regret.maxAbsZ, e.average.maxAbsZ) < 6, g + ' ' + e.estimator + ' max |z| ' + Math.max(e.regret.maxAbsZ, e.average.maxAbsZ));
      assert.ok(e.regret.rmsZ < 1.5 && e.average.rmsZ < 1.5, g + ' ' + e.estimator + ' rms z');
    }
    // the shared walk visits the river tree once: half (or a third) of the per-seat enumeration
    if (g === 'hu-river') { const v = Object.fromEntries(rep.estimators.map(e => [e.estimator, e.stateVisitsPerDeal])); assert.equal(v['river-shared'] * 2, v.river); assert.equal(v['river-cross'], v['river-shared']); }
  }
  // the reference notices a wrong estimator: scale one dump's regrets by 1.02 and it must fail
  const sp = spec(d, 'hu-river', 901, { batchDeals: 1 }), o = path.join(d, 'hu-river.none.json'), w = JSON.parse(fs.readFileSync(o)); for (const r of w.rows) for (let a = 0; a < r.k; a++) r.mean[a] *= 1.02;
  const wrong = path.join(d, 'wrong.json'); fs.writeFileSync(wrong, JSON.stringify(w)); const r = cp.spawnSync(python, [path.join(src, 'tools/independent_cfr56.py'), sp, wrong], { encoding: 'utf8', maxBuffer: 64 << 20 });
  assert.notEqual(r.status, 0, 'a 2% bias in the regret increments is detected'); assert.equal(JSON.parse(r.stdout).allPassed, false);
});

// ---------------------------------------------------------------- evaluator
test('5.6 compact showdown tables and passive runouts return the 5.5 values, with any cache size', { timeout: 600000 }, t => {
  const d = tmp(t), old = { EM_EV_KEEP_SCORES: '1', EM_EV_NO_PASSIVE: '1' };
  const rel = (a, b) => Math.abs(a - b) / Math.max(1e-12, Math.abs(a), Math.abs(b));
  for (const [g, updates] of [['bubble4', 4000], ['flop5', 4000], ['hu-turn', 6000], ['turn4', 6000], ['final8', 3000]]) {
    const sp = spec(d, g, 21, { batchDeals: 1 }), st = path.join(d, g + '.state'); train(sp, updates, st);
    const ref = gain(d, sp, st, 1024, old), cur = gain(d, sp, st, 1024), small = gain(d, sp, st, 32);
    for (const [name, x] of [['1024 MiB', cur], ['32 MiB', small]]) {
      assert.ok(rel(x.nashConv, ref.nashConv) <= 1e-9 || Math.abs(x.nashConv - ref.nashConv) <= 1e-12, g + ' NashConv, ' + name + ': ' + x.nashConv + ' vs ' + ref.nashConv);
      for (const [i, s] of x.seats.entries()) for (const k of ['policyValue', 'bestResponseValue', 'gain']) assert.ok(Math.abs(s[k] - ref.seats[i][k]) <= 1e-9 * Math.max(1, Math.abs(ref.seats[i][k])), g + ' seat ' + i + ' ' + k + ', ' + name);
    }
    // compact tables alone (no passive shortcut) change no bit when the 5.5 cache was large enough
    const compactOnly = gain(d, sp, st, 1024, { EM_EV_NO_PASSIVE: '1' }); assert.equal(compactOnly.nashConv, ref.nashConv, g + ': compact tables alone are bit-identical');
  }
});
test('5.6 an exact study gives the same measurements with the 5.5 evaluator paths, to 1e-9', { timeout: 600000 }, t => {
  const d = tmp(t), f = path.join(src, 'studies/icm8-bb-call-small.emfix.json'), opts = ['seeds=2', 'budgets=2000,8000', 'threads=2', 'checkpoint=off', 'quiet=1'];
  const a = path.join(d, 'a.json'), b = path.join(d, 'b.json');
  assert.equal(run(['--study', f, a, ...opts]).status, 0); assert.equal(run(['--study', f, b, ...opts], { env: { ...process.env, EM_EV_KEEP_SCORES: '1', EM_EV_NO_PASSIVE: '1' } }).status, 0);
  const A = JSON.parse(fs.readFileSync(a)), B = JSON.parse(fs.readFileSync(b)); let compared = 0;
  for (const [vi, v] of A.variants.entries()) for (const [si, s] of v.perSeed.entries()) for (const [bi, p] of s.budgets.entries()) {
    const q = B.variants[vi].perSeed[si].budgets[bi];
    for (const [i, x] of (p.ev || []).entries()) { assert.ok(Math.abs(x - q.ev[i]) <= 1e-9 * Math.max(1, Math.abs(x)), 'EV'); compared++; }
    for (const [i, x] of (p.frequency || p.frequencies || []).entries()) assert.equal(x, (q.frequency || q.frequencies)[i]);
    if (Number.isFinite(p.quality)) { assert.ok(Math.abs(p.quality - q.quality) <= 1e-9 * Math.max(1, Math.abs(p.quality)), 'quality'); compared++; }
  }
  assert.ok(compared >= 8, 'measurements compared: ' + compared);
});

// ---------------------------------------------------------------- statistics
test('5.6 replication: formulas, minimum trainings and the sign test on certified trainings', { skip: compilerSkip }, t => {
  const six = [[1, .2], [1.1, .3], [.9, .1], [1.2, .2], [1, .25], [1.05, .2]];
  const [a, b, c, f4, f7, one, single] = probe(t, [exactStudy(six), exactStudy(six.slice(0, 5)), exactStudy([...six.slice(0, 5), [.1, 2]]), exactStudy(six, { family: 4 }), exactStudy([...six, ...six.slice(0, 3)], { family: 7 }), exactStudy(six.slice(0, 1)), exactStudy(six.map(x => [x[0]]))]);
  const r = x => x.confidence.replication;
  // six agreeing exact trainings, one comparison: the smallest study that can say anything about the typical training
  assert.equal(r(a).calculation, 'study-5.6-replication-v1'); assert.equal(r(a).minimumTrainingsForStatementAboutTypicalTraining, 6); assert.equal(r(a).sufficient, true);
  assert.ok(Math.abs(r(a).signTestLevel - .4 * .05) < 1e-15); assert.ok(Math.abs(r(a).signTestPMargin - 1 / 64) < 1e-15); assert.equal(r(a).verdict, 'ranked'); assert.equal(a.verdict, 'ranked'); assert.equal(a.bestAction.declared, true);
  assert.equal(r(a).trainingsCertifyingLeaderByMargin, 6); assert.equal(r(a).trainingsCertifyingAnotherAction, 0); assert.match(r(a).estimand, /median/); assert.match(r(a).verdictText, /not the mean/);
  assert.deepEqual(r(a).medianGapInterval.interval, [.75, 1]); assert.ok(Math.abs(r(a).medianGapInterval.coverageAtLeast - (1 - 2 / 64)) < 1e-15); assert.match(r(a).medianGapInterval.of, /true leading-pair gap/);
  assert.ok(Math.abs(r(a).undetectableFailureRate - (1 - .05 ** (1 / 6))) < 1e-15);
  assert.equal(a.confidence.evaluationKind, 'exact'); assert.match(a.confidence.evaluationUncertainty.kind, /none/); assert.equal(a.confidence.trainingVariation.trainings, 6); assert.ok(a.confidence.trainingVariation.gapSdAcrossTrainings > 0);
  // five trainings: the measured strategies rank, nothing is declared, whatever the data
  assert.equal(b.verdict, 'ranked'); assert.equal(r(b).verdict, 'insufficientReplication'); assert.equal(b.bestAction.declared, false); assert.match(b.bestAction.reason, /does not carry to trainings in general/); assert.equal(r(b).medianGapInterval, null);
  assert.ok(Math.abs(r(b).undetectableFailureRate - (1 - .05 ** .2)) < 1e-15); assert.equal(b.bestAction.leaderAmongMeasuredStrategies, '0');
  // one training certifies the other action: reported, declaration withheld
  assert.equal(r(c).verdict, 'trainingsDisagree'); assert.equal(r(c).trainingsCertifyingAnotherAction, 1); assert.equal(c.bestAction.declared, false); assert.match(r(c).verdictText, /1 of 6 trainings certify that a different action/);
  // a larger comparison family needs more trainings
  assert.equal(r(f4).minimumTrainingsForStatementAboutTypicalTraining, 8); assert.equal(r(f4).verdict, 'insufficientReplication'); assert.equal(f4.bestAction.declared, false);
  assert.equal(r(f7).minimumTrainingsForStatementAboutTypicalTraining, 9); assert.equal(r(f7).trainings, 9); assert.equal(r(f7).verdict, 'ranked'); assert.equal(f7.bestAction.declared, true);
  assert.equal(one.verdict, 'singleSeed'); assert.equal(r(one).verdict, 'insufficientReplication'); assert.equal(one.bestAction.declared, false);
  assert.equal(r(single).verdict, 'singleAction'); assert.equal(single.bestAction.declared, false);
  // sign test with disagreement short of certifying the other action: 9 of 10 above the margin is enough, 8 of 10 is not
  const mk = s => exactStudy(Array.from({ length: 10 }, (_, i) => i < s ? [1, 0] : [.01, 0]));   // the others: positive but below the margin
  const [nine, eight] = probe(t, [mk(9), mk(8)]);
  assert.ok(Math.abs(r(nine).signTestPMargin - binomTail(10, 9)) < 1e-15 && binomTail(10, 9) <= .02); assert.equal(r(nine).verdict, 'ranked'); assert.equal(r(nine).trainingsCertifyingPositiveEdge, 10);
  assert.ok(binomTail(10, 8) > .02); assert.equal(r(eight).verdict, 'smallEdge'); assert.equal(eight.bestAction.declared, false, 'a best action needs the margin');
});
test('5.6 replication with sampled evaluation: certificates use bounded-payoff intervals at the stated level; no bound, no statement', { skip: compilerSkip }, t => {
  const n = 8, N = 20000, se = .02, eb = (V, R, m, delta) => Math.min(R, Math.sqrt(2 * V * Math.log(4 / delta) / m) + 7 * R * Math.log(4 / delta) / (3 * (m - 1)));
  const base = { values: Array.from({ length: n }, () => [1, 0]), errors: Array.from({ length: n }, () => [se, 0]), pairErrors: Array.from({ length: n }, () => [[0, se], [se, 0]]), samples: N, sampleCounts: Array(n).fill(N), independent: 1, family: 1, margin: .05, method: 'sampled' };
  const [ok, wide, none, out] = probe(t, [{ ...base, ranges: Array(n).fill(10) }, { ...base, ranges: Array(n).fill(4000) }, base, { ...base, ranges: Array(n).fill(10), within: [true, true, true, false, true, true, true, true] }]);
  const r = x => x.confidence.replication, delta = .2 * .05 / n;
  assert.ok(Math.abs(r(ok).perTrainingIntervalLevel - delta) < 1e-18); assert.equal(ok.confidence.evaluationKind, 'sampled'); assert.match(r(ok).medianGapInterval.of, /MEASURED/);
  assert.ok(1 - eb(se * se * N, 20, N, delta) > .05, 'the certificate half-width leaves the margin'); assert.equal(r(ok).trainingsCertifyingLeaderByMargin, n); assert.equal(r(ok).verdict, 'ranked'); assert.equal(ok.bestAction.declared, true);
  // a payoff range so wide that no training can be certified: unresolved, not ranked
  assert.ok(1 - eb(se * se * N, 8000, N, delta) < .05); assert.equal(r(wide).trainingsCertifyingLeaderByMargin, 0); assert.equal(r(wide).verdict, 'unresolved'); assert.equal(wide.bestAction.declared, false);
  for (const x of [none, out]) { assert.equal(r(x).verdict, 'uncalibrated'); assert.equal(x.bestAction.declared, false); assert.ok(r(x).trainingsWithoutCalibratedEvaluation >= 1); }
});
test('5.6 study document: replication verdicts, explicit warnings, CLI text and interface helpers agree; older documents are unchanged', { timeout: 600000 }, t => {
  const d = tmp(t), f = path.join(src, 'studies/known-akq-river.emfix.json'), out = path.join(d, 'r.json');
  const r = run(['--study', f, out, 'seeds=3', 'budgets=2000,20000', 'threads=2', 'checkpoint=off']); assert.equal(r.status, 0, r.stderr);
  const doc = JSON.parse(fs.readFileSync(out)); assert.equal(doc.replicationCalculation, 'study-5.6-replication-v1'); assert.equal(doc.calculationVersion, 'study-5.5-bounded-eb-v1', 'the calibrated intervals are those of 5.5');
  const v = doc.variants[0], b = v.budgets[v.budgets.length - 1], rep = b.confidence.replication;
  assert.equal(rep.trainings, 3); assert.equal(rep.sufficient, false); assert.equal(b.bestAction.declared, false); assert.equal(b.confidence.evaluationKind, 'exact');
  const codes = doc.statisticalWarnings.map(w => w.code); assert.ok(codes.includes('insufficientReplication')); assert.ok(codes.includes('rareTrainingFailuresNotExcluded'));
  const w = doc.statisticalWarnings.find(x => x.code === 'insufficientReplication'); assert.match(w.text, /3 independent trainings were evaluated; at least \d+ \(all agreeing\) are needed/); assert.equal(w.variant, v.name);
  assert.match(doc.statisticalWarnings.find(x => x.code === 'rareTrainingFailuresNotExcluded').text, /fewer than 63% of trainings/);
  assert.match(r.stdout, /What this study does not establish/); assert.match(r.stdout, /across trainings \(3 trainings, exact evaluation\)/); assert.match(r.stdout, /best action declared: no/);
  // interface helpers read the same fields
  const S = EM.study; S.validate && S.validate(doc); const acc = S.accuracy(doc)[0], h = S.headline(v);
  assert.equal(acc.bestActionSupported, false); assert.equal(acc.bestActionDeclared, false); assert.equal(acc.acrossTrainingsVerdict, rep.verdict); assert.equal(acc.trainings, 3); assert.equal(acc.minimumTrainings, rep.minimumTrainingsForStatementAboutTypicalTraining);
  assert.ok(acc.warnings.some(x => /at least \d+ \(all agreeing\) are needed/.test(x))); assert.equal(h.bestActionDeclared, false); assert.equal(h.evaluationKind, 'exact');
  // a ranked document without a declaration is shown as a leader, not a recommendation; with one, as before
  const ranked = JSON.parse(JSON.stringify(v)); const rb = ranked.budgets[ranked.budgets.length - 1]; rb.verdict = 'ranked'; ranked.firstBudgetMeetingTolerance = rb.budgetDeals;
  assert.match(S.headline(ranked).lead, /^Leader among the measured trainings: .* \(no best action declared\)$/);
  rb.bestAction.declared = true; assert.match(S.headline(ranked).lead, /^Prefer /);
  delete rb.bestAction; delete rb.confidence.replication; assert.match(S.headline(ranked).lead, /^Prefer /, 'a 5.5 document keeps its 5.5 presentation');
  const doc55 = JSON.parse(JSON.stringify(doc)); delete doc55.statisticalWarnings; doc55.variants[0].budgets.forEach(x => { delete x.bestAction; delete x.confidence.replication; x.verdict = 'ranked'; });
  const a55 = S.accuracy(doc55)[0]; assert.equal(a55.bestActionSupported, true); assert.equal(a55.bestActionDeclared, null); assert.ok(a55.warnings.some(x => /Student-t model/.test(x)));
});

// ---------------------------------------------------------------- study checkpoints
test('5.6 a study with an experimental trainer is interrupted and resumed to the uninterrupted result; a checkpoint of another build or trainer is refused', { timeout: 900000 }, t => {
  const d = tmp(t), f = path.join(src, 'studies/known-akq-river.emfix.json'), opts = ['seeds=2', 'budgets=20000,400000,3000000', 'threads=2', 'quiet=1', 'opponentEnumeration=river-cross'];
  const ref = path.join(d, 'ref.json'), out = path.join(d, 'out.json'), ck = path.join(d, 'ck');
  const t0 = Date.now(); assert.equal(run(['--study', f, ref, ...opts, 'checkpoint=off']).status, 0); const refSeconds = (Date.now() - t0) / 1000;
  let r = run(['--study', f, out, ...opts, 'checkpoint=' + ck, 'timeLimitSeconds=0.4', 'checkpointSeconds=0.05']); const first = JSON.parse(fs.readFileSync(out));
  // 5.7: the number of 0.4 s resumes a study needs grows with how slow the program is (5.6 allowed 40, which the
  // AddressSanitizer build exceeded: it needed 54). The bound now follows the uninterrupted run measured above: eight
  // times its duration in 0.4 s slices, and at least the 40 of 5.6. What is required of the result is unchanged: the
  // study must be complete, and equal to the uninterrupted one.
  let rounds = 0; const maxRounds = Math.max(40, Math.ceil(8 * refSeconds / 0.4) + 20);
  while (!JSON.parse(fs.readFileSync(out)).completion.complete && rounds++ < maxRounds) { r = run(['--study', f, out, ...opts, 'checkpoint=' + ck, 'resume=1', 'timeLimitSeconds=0.4', 'checkpointSeconds=0.05']); assert.ok(r.status === 0 || /time limit|incomplete/i.test(r.stderr + r.stdout) || fs.existsSync(out), r.stderr); }
  const done = JSON.parse(fs.readFileSync(out)), want = JSON.parse(fs.readFileSync(ref)); assert.equal(done.completion.complete, true, 'the study finished after ' + rounds + ' resumes (at most ' + maxRounds + ')');
  assert.equal(first.completion.complete === false || rounds === 0, true);
  assert.deepEqual(done.run.trainer, want.run.trainer); assert.match(JSON.stringify(done.run.trainer), /river-cross/);
  for (const [vi, v] of want.variants.entries()) {
    for (const [bi, b] of v.budgets.entries()) { const x = done.variants[vi].budgets[bi]; assert.deepEqual(x.actions, b.actions); assert.deepEqual(x.gap && x.gap.mean, b.gap && b.gap.mean); assert.equal(x.verdict, b.verdict); assert.deepEqual(x.confidence.replication, b.confidence.replication); assert.deepEqual(x.bestAction, b.bestAction); }
    for (const [si, s] of v.perSeed.entries()) for (const [bi, p] of s.budgets.entries()) { const q = done.variants[vi].perSeed[si].budgets[bi]; assert.deepEqual(q.ev, p.ev); assert.equal(q.deals, p.deals); assert.equal(q.quality, p.quality); }
  }
  assert.deepEqual(done.statisticalWarnings, want.statisticalWarnings);
  // the same checkpoint directory with another trainer: refused, nothing overwritten
  const other = path.join(d, 'other.json'), before = fs.readdirSync(ck).sort().join();
  r = run(['--study', f, other, 'seeds=2', 'budgets=20000,400000,3000000', 'threads=2', 'quiet=1', 'checkpoint=' + ck, 'resume=1']); assert.notEqual(r.status, 0); assert.match(r.stderr + r.stdout, /different|fingerprint|does not match|refus/i); assert.equal(fs.readdirSync(ck).sort().join(), before);
  // a manifest written by another build (valid in every other respect, hash included): refused with the reason
  const mf = fs.readdirSync(ck).filter(x => /^manifest.*\.json$/.test(x)).map(x => path.join(ck, x)); assert.ok(mf.length >= 1, 'manifest files: ' + fs.readdirSync(ck).join());
  for (const m of mf) {
    const text = fs.readFileSync(m, 'utf8'), at = text.indexOf('"body":') + 7, bodyText = text.slice(at, text.lastIndexOf('}')), other = bodyText.replace(/"build":"[^"]*"/, '"build":"0123456789abcdef"');
    assert.notEqual(other, bodyText); assert.equal(crypto.createHash('sha256').update(bodyText).digest('hex'), JSON.parse(text).bodySha256, 'the manifest hash covers the body text');
    fs.writeFileSync(m, text.slice(0, at).replace(/"bodySha256":"[0-9a-f]{64}"/, '"bodySha256":"' + crypto.createHash('sha256').update(other).digest('hex') + '"') + other + '}\n');
  }
  r = run(['--study', f, path.join(d, 'again.json'), ...opts, 'checkpoint=' + ck, 'resume=1']); assert.notEqual(r.status, 0, 'a checkpoint of another build is not continued'); assert.match(r.stderr + r.stdout, /written by build 0123456789abcdef; this is build/);
  // a damaged manifest (one byte changed, hash not updated) is detected as damaged, not loaded
  for (const m of mf) fs.writeFileSync(m, fs.readFileSync(m, 'utf8').replace('"resumeCount":', '"resumeCount" :'));
  r = run(['--study', f, path.join(d, 'again2.json'), ...opts, 'checkpoint=' + ck, 'resume=1']); assert.notEqual(r.status, 0); assert.match(r.stderr + r.stdout, /build 0123456789abcdef|SHA-256|damaged|not valid/);
});
test('5.6 one process per study checkpoint: a concurrent resume is refused and changes nothing; the lock dies with its process; repeated resumes are harmless', { timeout: 900000 }, async t => {
  const d = tmp(t), f = path.join(src, 'studies/known-akq-river.emfix.json'), opts = ['seeds=2', 'budgets=20000,400000,6000000', 'threads=1', 'quiet=1'], ck = path.join(d, 'ck'), out = path.join(d, 'out.json'), ref = path.join(d, 'ref.json');
  assert.equal(run(['--study', f, ref, ...opts, 'checkpoint=off']).status, 0);
  const child = cp.spawn(cli(), ['--study', f, out, ...opts, 'checkpoint=' + ck, 'checkpointSeconds=0.05'], { stdio: 'ignore' });
  const exited = new Promise(res => child.on('exit', (code, sig) => res({ code, sig })));
  const wait = ms => new Promise(res => setTimeout(res, ms));
  for (let i = 0; i < 200 && !fs.existsSync(path.join(ck, 'manifest.json')); i++) await wait(25);
  assert.ok(fs.existsSync(path.join(ck, 'manifest.json')), 'the first study committed a checkpoint'); assert.ok(fs.existsSync(path.join(ck, 'study.lock')), 'and holds the lock');
  // a second process on the same directory: resume, plain start and replace are all refused while the first runs
  for (const extra of [['resume=1'], [], ['replaceCheckpoint=1']]) {
    if (child.exitCode !== null) break;
    const r = run(['--study', f, path.join(d, 'second.json'), ...opts, 'checkpoint=' + ck, ...extra]);
    if (child.exitCode !== null) break;   // the first study finished meanwhile: the refusal is no longer required
    assert.notEqual(r.status, 0, 'refused: ' + extra.join()); assert.match(r.stderr + r.stdout, /409.*in use: another running study holds it/); assert.ok(!fs.existsSync(path.join(d, 'second.json')));
  }
  // kill the holder: the operating system drops the lock, the checkpoint stays valid and resumes to the uninterrupted result
  child.kill('SIGKILL'); await exited;
  let r = run(['--study', f, out, ...opts, 'checkpoint=' + ck, 'resume=1']); assert.equal(r.status, 0, r.stderr + r.stdout);
  const done = JSON.parse(fs.readFileSync(out)), want = JSON.parse(fs.readFileSync(ref)); assert.equal(done.completion.complete, true); assert.ok(!fs.existsSync(path.join(ck, 'study.lock')), 'the lock file is removed when the study ends');
  for (const [vi, v] of want.variants.entries()) for (const [si, s] of v.perSeed.entries()) for (const [bi, p] of s.budgets.entries()) { const q = done.variants[vi].perSeed[si].budgets[bi]; assert.deepEqual(q.ev, p.ev); assert.equal(q.deals, p.deals); assert.equal(q.quality, p.quality); }
  // resuming a finished study again and again returns the same document content and never needs the lock to be cleared by hand
  for (let i = 0; i < 3; i++) { r = run(['--study', f, path.join(d, 'again' + i + '.json'), ...opts, 'checkpoint=' + ck, 'resume=1']); assert.equal(r.status, 0, r.stderr + r.stdout); const a = JSON.parse(fs.readFileSync(path.join(d, 'again' + i + '.json'))); assert.equal(a.completion.complete, true); assert.deepEqual(a.variants[0].budgets.map(b => b.actions), want.variants[0].budgets.map(b => b.actions)); }
});
test('5.6 a seed count beyond the fixture list continues with consecutive seeds; nine exact trainings of a two-action game can be judged across trainings', { timeout: 600000 }, t => {
  const d = tmp(t), f = path.join(src, 'studies/known-akq-river.emfix.json'), out = path.join(d, 'r.json'), fixtureSeeds = fx('known-akq-river').study.seeds;
  const r = run(['--study', f, out, 'seeds=9', 'budgets=2000,20000', 'threads=3', 'checkpoint=off', 'quiet=1']); assert.equal(r.status, 0, r.stderr);
  const doc = JSON.parse(fs.readFileSync(out)), last = fixtureSeeds[fixtureSeeds.length - 1];
  assert.deepEqual(doc.run.seeds, [...fixtureSeeds, ...Array.from({ length: 9 - fixtureSeeds.length }, (_, i) => last + 1 + i)]);
  const b = doc.variants[0].budgets.at(-1), rep = b.confidence.replication;
  let need = 1; while (0.5 ** need > 0.4 * 0.05 / rep.family) need++;   // the stated rule, recomputed here
  assert.equal(rep.trainings, 9); assert.equal(rep.family, 2, 'one variant at two budgets: two cells'); assert.match(rep.familyMeaning, /variant, budget/); assert.equal(rep.minimumTrainingsForStatementAboutTypicalTraining, need); assert.equal(need, 7); assert.equal(rep.sufficient, true);
  assert.ok(!doc.statisticalWarnings.some(w => w.code === 'insufficientReplication'), 'nine trainings are enough to be judged');
  assert.ok(['ranked', 'smallEdge', 'unresolved', 'trainingsDisagree'].includes(rep.verdict), rep.verdict);
  // the game is an exact tie in theory (call 1/2, EV gap 0): a declaration here would be a false one
  assert.equal(b.bestAction.declared, false, 'no best action is declared for a tied decision: ' + JSON.stringify(b.bestAction));
  assert.match(doc.statisticalWarnings.find(w => w.code === 'rareTrainingFailuresNotExcluded').text, /fewer than 28% of trainings/);
  for (const bad of ['seeds=0', 'seeds=65', 'seeds=1.5']) assert.notEqual(run(['--study', f, path.join(d, 'x.json'), bad, 'quiet=1']).status, 0, bad);
});
