'use strict';
// EightMax 5.5 regression tests. Statistics (Stage 1): bounded-payoff conditional intervals, refusal without a
// payoff bound, calibrated verdicts, evaluator payoff bounds, review of pre-5.5 documents.
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process');
const build=require('./native_build');
const E=require('../tools/loadlib');for(const l of ['lib_runouts','lib_wide','lib_river','lib_river_ui','lib_study_ui'])require('../web/'+l);
const src=path.resolve(__dirname,'..'),fx=id=>JSON.parse(fs.readFileSync(path.join(src,'studies',id+'.emfix.json'),'utf8'));
const cli=()=>process.env.EM_TEST_MWCLI||build.cli().cli;
const tmp=t=>{let d=fs.mkdtempSync(path.join(os.tmpdir(),'em55-'));t.after(()=>fs.rmSync(d,{recursive:true,force:true}));return d;};
const run=(args,opt={})=>cp.spawnSync(cli(),args.map(String),{encoding:'utf8',timeout:600000,maxBuffer:256<<20,...opt});
function study(t,f,opts=[]){const d=tmp(t),input=path.join(d,'fixture.json'),out=path.join(d,'result.json');fs.writeFileSync(input,JSON.stringify(f));const r=run(['--study',input,out,'quiet=1',...opts]);assert.equal(r.status,0,r.stderr+r.stdout);return {doc:JSON.parse(fs.readFileSync(out)),text:r.stdout,dir:d,input,out};}
let probeExe=null;
function probe(t,data){
 if(!probeExe){const d=fs.mkdtempSync(path.join(os.tmpdir(),'em55p-')),obj=path.join(d,'json.o');probeExe=path.join(d,'probe'+(process.platform==='win32'?'.exe':''));
  cp.execFileSync(process.env.EM_TEST_CC||'gcc',['-O2','-c',path.join(src,'native/json.c'),'-o',obj]);
  cp.execFileSync(process.env.EM_TEST_CXX||'g++',['-std=c++20','-O2','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-I'+path.join(src,'native'),path.join(__dirname,'study53_probe.cpp'),obj,'-o',probeExe]);
  process.on('exit',()=>fs.rmSync(d,{recursive:true,force:true}));}
 const r=cp.spawnSync(probeExe,[],{input:data.map(x=>JSON.stringify(x)).join('\n')+'\n',encoding:'utf8',maxBuffer:64<<20});assert.equal(r.status,0,r.stderr);return r.stdout.trim().split('\n').map(x=>JSON.parse(x));}
// independent re-statement of the Maurer-Pontil two-sided half-width
const eb=(V,R,n,delta)=>Math.min(R,Math.sqrt(2*V*Math.log(4/delta)/n)+7*R*Math.log(4/delta)/(3*(n-1)));
const syn=(o={})=>({values:Array.from({length:5},()=>[1,0]),errors:Array.from({length:5},()=>[.02,.02]),pairErrors:Array.from({length:5},()=>[[0,.01],[.01,0]]),samples:20000,independent:true,family:4,margin:.05,...o});

test('5.5 bounded-payoff interval: formula, union over replications, Bonferroni family and range doubling for differences',t=>{
 const [r]=probe(t,[syn({ranges:[10,10,10,10,10]})]);const n=20000,delta=.05/4/5;
 const a=r.actions[0].ev,g=r.gap;
 assert.equal(a.conditionalCalibrated,true);assert.match(a.conditionalMethod,/Bernstein/);
 assert.ok(Math.abs(a.conditionalHalfWidth-eb(.02*.02*n,10,n,delta))<1e-12);
 assert.ok(Math.abs(g.conditionalHalfWidth-eb(.01*.01*n,20,n,delta))<1e-12,'a difference of two samples has twice the range');
 assert.deepEqual(g.conditionalEvaluationCi95.map(x=>+x.toFixed(9)),[1-g.conditionalHalfWidth,1+g.conditionalHalfWidth].map(x=>+x.toFixed(9)));
 assert.ok(g.normalApproxConditionalCi95[1]-g.normalApproxConditionalCi95[0]<2*g.conditionalHalfWidth,'the bounded interval is wider than the normal approximation here');
 assert.equal(r.verdict,'ranked');assert.equal(r.confidence.evaluationCalibrated,true);
 // per-replication sample counts and ranges
 const [h]=probe(t,[syn({ranges:[10,20,30,40,50],sampleCounts:[1000,2000,4000,8000,16000]})]);
 const want=[[10,1000],[20,2000],[30,4000],[40,8000],[50,16000]].map(([R,m])=>eb(.02*.02*m,R,m,delta)).reduce((x,y)=>x+y)/5;
 assert.ok(Math.abs(h.actions[0].ev.conditionalHalfWidth-want)<1e-12);
});
test('5.5 no payoff bound: no conditional interval is published and no ranking, near tie or small edge is stated',t=>{
 const [r,tie]=probe(t,[syn(),syn({values:Array.from({length:5},()=>[0,0]),errors:Array.from({length:5},()=>[1e-4,1e-4]),pairErrors:Array.from({length:5},()=>[[0,1e-4],[1e-4,0]])})]);
 for(const x of [r,tie]){assert.equal(x.verdict,'uncalibrated');assert.equal(x.gap.conditionalEvaluationCi95,null);assert.equal(x.gap.conditionalCalibrated,false);assert.equal(x.confidence.reason,'noPayoffBound');assert.equal(x.meetsTolerance,false);assert.ok(x.gap.normalApproxConditionalCi95);assert.ok(x.gap.ci95);}
 assert.equal(r.confidence.verdictFromModelBasedIntervalsAlone,'ranked','5.4 would have ranked this input');
 assert.equal(tie.confidence.verdictFromModelBasedIntervalsAlone,'nearTie');
});
test('5.5 exactness is declared, never inferred from a zero standard error; a bound violation withdraws calibration',t=>{
 const zero={errors:Array.from({length:5},()=>[0,0]),pairErrors:Array.from({length:5},()=>[[0,0],[0,0]])};
 const [sampled,exact,violated,nob]=probe(t,[syn({...zero,ranges:[10,10,10,10,10]}),syn({...zero,method:'exact'}),syn({ranges:[10,10,10,10,10],within:[true,true,false,true,true]}),syn(zero)]);
 assert.equal(sampled.gap.conditionalCalibrated,true);assert.ok(sampled.gap.conditionalHalfWidth>0,'identical samples (the rare event was not drawn) still leave the range term');
 assert.ok(Math.abs(sampled.gap.conditionalHalfWidth-eb(0,20,20000,.05/4/5))<1e-12);
 assert.equal(exact.gap.conditionalHalfWidth,0);assert.match(exact.gap.conditionalMethod,/exact/);assert.equal(exact.verdict,'ranked');
 assert.equal(violated.verdict,'uncalibrated');assert.equal(violated.confidence.reason,'payoffBoundViolated');assert.equal(violated.gap.conditionalEvaluationCi95,null);
 assert.equal(nob.verdict,'uncalibrated','sampled with SE 0 and no bound is not treated as exact');
});
test('5.5 a ranking needs BOTH the calibrated conditional interval and the model-based interval; tolerance needs calibration',t=>{
 // model-based interval is tight (identical replications, tiny SE) but the bounded interval is wide (huge range)
 const [wide,ok]=probe(t,[syn({ranges:Array(5).fill(5000)}),syn({ranges:Array(5).fill(1)})]);
 assert.equal(wide.confidence.verdictFromModelBasedIntervalsAlone,'ranked');assert.equal(wide.verdict,'unresolved');assert.ok(wide.gap.conditionalEvaluationCi95[0]<.05);
 assert.equal(wide.toleranceChecks.gapResolvedToTolerance,false);
 assert.equal(ok.verdict,'ranked');assert.match(ok.verdictText,/measured strategies/);
});
test('5.5 sampled evaluator reports proven payoff bounds; every sample and the exact values lie inside; chip and ICM',t=>{
 const d=tmp(t),games=['hu-river','river3-chip','flop6','bubble4'];
 for(const g of games){const sp=path.join(d,g+'.json'),st=path.join(d,g+'.state'),q=path.join(d,'q.json');
  cp.execFileSync('node',[path.join(src,'tools/games48.js'),'spec',g,sp,'5',JSON.stringify({device:'cpu'})]);
  assert.equal(run([sp,2000,1,st,64]).status,0);
  fs.writeFileSync(q,JSON.stringify({path:[],hands:[0],method:'exact',threads:1,device:'cpu'}));const ex=JSON.parse(run(['--ev',sp,st,q,64]).stdout).hands[0];
  fs.writeFileSync(q,JSON.stringify({path:[],hands:[0],method:'sampled',samples:1024,seed:3,threads:1,device:'cpu'}));const r=run(['--ev',sp,st,q,64]);assert.equal(r.status,0,r.stderr);
  const h=JSON.parse(r.stdout).hands[0],b=h.bounded;assert.ok(b,'bounded block for '+g);assert.equal(b.method,'empirical-bernstein-maurer-pontil');
  assert.equal(b.withinBounds,true);assert.equal(b.calibrated,true);assert.ok(b.lower<=b.observedMin&&b.observedMax<=b.upper,g);
  for(const x of ex.ev)assert.ok(x>=b.lower-1e-9&&x<=b.upper+1e-9,g+' exact EV inside the bound');
  assert.equal(ex.bounded,undefined,'exact results carry no sampling bound');
  const k=h.ev.length,n=h.samples,R=b.upper-b.lower,delta=.05/Math.max(1,k*(k-1)/2);
  for(let i=0;i<k;i++)for(let j=0;j<k;j++)if(i!==j){const half=eb(b.pairStdErr[i][j]**2*n,2*R,n,delta);assert.ok(Math.abs(b.pairwiseCi[i][j][0]-(h.ev[i]-h.ev[j]-half))<1e-9);assert.ok(b.pairwiseCi[i][j][0]<=ex.ev[i]-ex.ev[j]+1e-9&&ex.ev[i]-ex.ev[j]<=b.pairwiseCi[i][j][1]+1e-9,g+' covers the exact difference');}
  if(g==='bubble4'){assert.equal(b.lower,0);assert.equal(b.upper,50);}
  if(g==='hu-river'){assert.equal(b.lower,-20);assert.equal(b.upper,30);}   // stack 20; common pot 10 + the other stack 20
 }
});
test('5.5 study document: calculation identifier, per-seed bounds, calibrated intervals, CLI text and CSV agree',t=>{
 const f=fx('known-akq-river');f.study.ev={method:'sampled',samples:4000,seed:9};
 const {doc,text}=study(t,f,['seeds=3','budgets=200,2000','threads=1']);
 assert.equal(doc.calculationVersion,'study-5.5-bounded-eb-v1');assert.equal(doc.calculationVersion,E.study.CALCULATION);assert.equal(doc.modelBasedCalculation,'study-5.3-tfloor-bonferroni-v1');
 assert.match(doc.uncertainty.calibratedAssumptions,/independent, identically distributed/);
 for(const v of doc.variants){for(const s of v.perSeed)for(const b of s.budgets){assert.equal(b.evSamplesWithinBound,true);assert.ok(b.evPayoffUpperBound>b.evPayoffLowerBound);}
  for(const b of v.budgets){assert.equal(b.confidence.evaluationCalibrated,true);assert.ok(b.gap.conditionalEvaluationCi95);
   const nw=(b.gap.normalApproxConditionalCi95[1]-b.gap.normalApproxConditionalCi95[0])/2;assert.ok(b.gap.conditionalHalfWidth>=nw,'never narrower than the 5.4 interval on this fixture');
   if(b.verdict==='ranked'||b.verdict==='smallEdge')assert.ok(b.gap.conditionalEvaluationCi95[0]>0);}}
 assert.match(text,/measured strategies \(calibrated simultaneous 95%\)/);assert.match(text,/across trainings \(model-based simultaneous 95%\)/);
 assert.equal(E.study.validateResult(doc),doc,'a 5.5 document is not rewritten');
 const exact=study(t,fx('known-akq-river'),['seeds=2','budgets=200']).doc;for(const b of exact.variants[0].budgets){assert.equal(b.confidence.evaluationMethod,'exact evaluation');assert.equal(b.gap.conditionalHalfWidth,0);}
});
test('5.5 review of 5.4 and 5.2 documents: measurements kept, uncalibrated rankings and tolerance claims withdrawn, exact results kept, idempotent',t=>{
 const dir=path.join(src,'../validation/5.4/studies');let sampledSeen=0,exactSeen=0;
 for(const name of fs.readdirSync(dir).filter(x=>x.endsWith('.result.json'))){const old=JSON.parse(fs.readFileSync(path.join(dir,name))),up=E.study.validateResult(old);
  assert.equal(up.calculationVersion,'study-5.5-legacy-review-v1');assert.equal(up.recalculation55.sourceCalculationVersion,'study-5.3-tfloor-bonferroni-v1');assert.notEqual(up,old);
  assert.deepEqual(up.variants.map(v=>v.perSeed),old.variants.map(v=>v.perSeed),'per-seed measurements are untouched');assert.equal(E.study.validateResult(up),up);
  for(let vi=0;vi<up.variants.length;vi++)for(let bi=0;bi<up.variants[vi].budgets.length;bi++){const b=up.variants[vi].budgets[bi],o=old.variants[vi].budgets[bi];if(!b.actions)continue;
   const exact=b.confidence.evaluationCalibrated;assert.deepEqual(b.gap?.ci95,o.gap?.ci95,'model-based interval kept');
   if(exact){exactSeen++;assert.equal(b.verdict,o.verdict);assert.deepEqual(b.gap?.conditionalEvaluationCi95,o.gap?.conditionalEvaluationCi95);}
   else{sampledSeen++;assert.equal(b.meetsTolerance,false);assert.ok(!['ranked','nearTie','smallEdge'].includes(b.verdict));if(b.gap){assert.equal(b.gap.conditionalEvaluationCi95,null);assert.deepEqual(b.gap.normalApproxConditionalCi95,o.gap.conditionalEvaluationCi95);}
    if(['ranked','nearTie','smallEdge','unresolved'].includes(o.verdict)){assert.equal(b.verdict,'uncalibrated');assert.equal(b.legacyConfidence55.verdict,o.verdict);}}}
 }
 assert.ok(sampledSeen>0&&exactSeen>0,'both kinds of 5.4 document were exercised');
 const v52=E.study.validateResult(JSON.parse(fs.readFileSync(path.join(src,'../validation/5.2/studies/btn25-open-small.result.json'))));
 assert.equal(v52.calculationVersion,'study-5.5-legacy-review-v1');assert.ok(v52.recalculation&&v52.recalculation55);
 assert.match(E.study.headline(v52.variants[0]).text,/not calibrated|Confidence|Incomplete|No /);
});

// ---------------- Stage 2: experimental trainer ----------------
test('5.5 default trainer is unchanged by the experimental option; river enumeration is opt-in, deterministic and reported', t => {
 const d = tmp(t), spec = (g, extra) => { const p = path.join(d, g + (extra.opponentEnumeration || '') + '.json'); cp.execFileSync('node', [path.join(src, 'tools/games48.js'), 'spec', g, p, '7', JSON.stringify({ batchDeals: 1, device: 'cpu', ...extra })]); return p; };
 const train = (sp, n, out, from) => { const r = run([sp, n, 1, out, 64, ...(from ? [from] : [])]); assert.equal(r.status, 0, r.stderr); return JSON.parse(r.stdout); };
 const a = spec('hu-river', {}), b = spec('hu-river', { opponentEnumeration: 'river' }), none = spec('hu-river', { opponentEnumeration: 'none' });
 const ia = train(a, 3000, path.join(d, 'a.state')), ib = train(b, 3000, path.join(d, 'b.state')); train(b, 3000, path.join(d, 'b2.state'));
 assert.equal(ia.trainer.opponentEnumeration, 'none'); assert.equal(ia.trainer.validatedDefault, true); assert.equal(ib.trainer.opponentEnumeration, 'river'); assert.equal(ib.trainer.experimental, true); assert.equal(ib.trainer.validatedDefault, false);
 assert.ok(!fs.readFileSync(path.join(d, 'a.state')).equals(fs.readFileSync(path.join(d, 'b.state'))), 'the candidate trains differently');
 assert.ok(fs.readFileSync(path.join(d, 'b.state')).equals(fs.readFileSync(path.join(d, 'b2.state'))), 'the candidate is deterministic');
 // "none" is the default trainer (same numbers); continuation through a state file is exact for the candidate too
 const sn = path.join(d, 'none.state'); train(none, 3000, sn); const q = path.join(d, 'q.json'); fs.writeFileSync(q, JSON.stringify({ method: 'exact', device: 'cpu', threads: 1 }));
 const g = (sp, st) => JSON.parse(run(['--gain', sp, st, q, 64]).stdout).nashConv; assert.equal(g(none, sn), g(a, path.join(d, 'a.state')));
 train(b, 1234, path.join(d, 'p.state')); train(b, 1766, path.join(d, 'c.state'), path.join(d, 'p.state')); assert.ok(fs.readFileSync(path.join(d, 'c.state')).equals(fs.readFileSync(path.join(d, 'b.state'))), 'resumed candidate equals uninterrupted candidate');
 // a game with no river betting: the option changes nothing that is trained
 const pa = spec('bubble4', {}), pb = spec('bubble4', { opponentEnumeration: 'river' }); train(pa, 2000, path.join(d, 'pa.state')); train(pb, 2000, path.join(d, 'pb.state')); assert.equal(g(pa, path.join(d, 'pa.state')), g(pb, path.join(d, 'pb.state')));
 const bad = path.join(d, 'bad.json'); const s = JSON.parse(fs.readFileSync(b)); s.opponentEnumeration = 'flop'; fs.writeFileSync(bad, JSON.stringify(s)); assert.notEqual(run([bad, 10, 1, path.join(d, 'x.state'), 64]).status, 0);
});

// ---------------- Stages 3-5: study execution, checkpoints, recovery ----------------
const eq = require('node:child_process'), equivalent = (a, b) => { const r = eq.spawnSync('python3', [path.join(src, 'tools/study_equivalence55.py'), a, b], { encoding: 'utf8' }); return { same: r.status === 0, text: r.stdout }; };
const F6 = path.join(src, 'studies/flop6-jack.emfix.json'), OPT = ['budgets=8000,32000', 'seeds=101,102,103', 'threads=3', 'evaluationSamples=1000', 'qualitySamples=128', 'variants=baseline', 'quiet=1'];
let reference = null; const ref = t => { if (!reference) { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em55r-')); process.on('exit', () => fs.rmSync(d, { recursive: true, force: true })); reference = path.join(d, 'ref.json'); const r = run(['--study', F6, reference, ...OPT, 'parallelSeeds=1']); assert.equal(r.status, 0, r.stderr); } return reference; };
const doc = p => JSON.parse(fs.readFileSync(p));
test('5.5 seeds run side by side, the evaluator cache size and checkpointing never change a study result', t => {
 const d = tmp(t), a = path.join(d, 'par.json'), b = path.join(d, 'ck.json'), c = path.join(d, 'mem.json');
 assert.equal(run(['--study', F6, a, ...OPT, 'parallelSeeds=3']).status, 0); assert.equal(run(['--study', F6, b, ...OPT, 'checkpoint=' + path.join(d, 'c'), 'checkpointSeconds=0.05', 'checkpointUpdates=3000']).status, 0);
 assert.equal(run(['--study', F6, c, ...OPT, 'evaluationMemoryMiB=64', 'parallelSeeds=2']).status, 0);
 for (const x of [a, b, c]) { const e = equivalent(ref(t), x); assert.ok(e.same, e.text); }
 const A = doc(a).run, B = doc(b).run; assert.equal(doc(ref(t)).run.parallelSeeds, 1); assert.equal(A.parallelSeeds, 3); assert.ok(B.checkpoint.enabled && B.checkpoint.commits > 6 && B.checkpoint.engineStateWrites >= 6); assert.equal(B.checkpoint.finalStatus, 'complete'); assert.equal(B.checkpoint.resumable, false);
 assert.deepEqual(fs.readdirSync(path.join(d, 'c')).sort(), ['manifest.json', 'manifest.prev.json'], 'a finished study keeps its manifest and drops the engine states');
 assert.equal(doc(c).run.evaluationMemoryMiB, 64); assert.equal(doc(a).completion.complete, true);
});
test('5.5 time limit, cancellation and repeated hard kills: the resumed study equals the uninterrupted one', async t => {
 const d = tmp(t);
 { const o = path.join(d, 'time.json'), c = 'checkpoint=' + path.join(d, 'ct'); let r = run(['--study', F6, o, ...OPT, c, 'checkpointSeconds=0.1', 'timeLimitSeconds=0.6']); assert.equal(r.status, 0, r.stderr); let x = doc(o);
  assert.equal(x.completion.complete, false); assert.equal(x.completion.status, 'timeLimit'); assert.equal(x.completion.resumable, true); assert.match(r.stdout, /INCOMPLETE/); for (const v of x.variants) for (const b of v.budgets) if (!b.complete) { assert.equal(b.meetsTolerance, false); assert.ok(!['ranked', 'nearTie', 'smallEdge'].includes(b.verdict)); }
  assert.equal(run(['--study', F6, o, ...OPT, c, 'requireComplete=1', 'timeLimitSeconds=0.2', 'resume=1']).status, 3, 'requireComplete turns an incomplete study into a failing exit code');
  r = run(['--study', F6, o, ...OPT, c, 'resume=1']); assert.equal(r.status, 0, r.stderr); x = doc(o); assert.equal(x.completion.complete, true); assert.ok(x.run.checkpoint.resumed && x.run.checkpoint.resumeCount >= 2); assert.deepEqual(x.run.checkpoint.warnings, []); const e = equivalent(ref(t), o); assert.ok(e.same, e.text); }
 { const o = path.join(d, 'cancel.json'), c = 'checkpoint=' + path.join(d, 'cc'); let r = run(['--study', F6, o, ...OPT, c, 'checkpointSeconds=0'], { env: { ...process.env, EM_STUDY_CANCEL_AFTER_MS: '700' } }); assert.equal(r.status, 0, r.stderr); let x = doc(o);
  assert.equal(x.run.stoppedByUser, true); assert.equal(x.completion.status, 'cancelled'); assert.ok(fs.readdirSync(path.join(d, 'cc')).some(f => f.endsWith('.state')), 'cancellation commits the engine state it stopped at');
  r = run(['--study', F6, o, ...OPT, c, 'resume=1']); assert.equal(r.status, 0, r.stderr); const e = equivalent(ref(t), o); assert.ok(e.same, e.text); assert.deepEqual(doc(o).run.checkpoint.warnings, []); }
 { const o = path.join(d, 'kill.json'), dir = path.join(d, 'ck'); let kills = 0;
  for (const ms of [500, 900, 300, 1300]) { const p = cp.spawn(cli(), ['--study', F6, o, ...OPT, 'checkpoint=' + dir, 'checkpointSeconds=0.05', ...(fs.existsSync(path.join(dir, 'manifest.json')) ? ['resume=1'] : [])], { stdio: 'ignore' });
   const exited = new Promise(r => p.once('exit', r)); await new Promise(r => setTimeout(r, ms)); if (p.exitCode === null) { p.kill('SIGKILL'); kills++; } await exited;
   const m = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'))); assert.equal(m.format, 'EightMax study checkpoint');   // the committed manifest always parses after a kill
   for (const j of m.body.jobs) if (j.state) assert.equal(require('node:crypto').createHash('sha256').update(fs.readFileSync(path.join(dir, j.state.file))).digest('hex'), j.state.sha256, 'every state named by the manifest is intact'); }
  assert.ok(kills >= 3, 'the study was killed while running');
  const r = run(['--study', F6, o, ...OPT, 'checkpoint=' + dir, 'resume=1']); assert.equal(r.status, 0, r.stderr); const e = equivalent(ref(t), o); assert.ok(e.same, e.text); assert.deepEqual(doc(o).run.checkpoint.warnings, []);
  assert.deepEqual(fs.readdirSync(dir).sort(), ['manifest.json', 'manifest.prev.json'], 'temporary files of killed writers are swept'); }
});
test('5.5 damaged checkpoints are detected: a bad engine state is discarded, a bad manifest falls back to the previous commit, nothing is overwritten by default', t => {
 const d = tmp(t), o = path.join(d, 'o.json'), dir = path.join(d, 'c'), c = 'checkpoint=' + dir;
 assert.equal(run(['--study', F6, o, ...OPT, c, 'checkpointSeconds=0.1', 'timeLimitSeconds=0.7']).status, 0);
 const man = path.join(dir, 'manifest.json'), before = fs.readFileSync(man), m = JSON.parse(before), withState = m.body.jobs.filter(j => j.state); assert.ok(withState.length > 0);
 // existing checkpoint, no resume: refused, untouched
 let r = run(['--study', F6, o, ...OPT, c]); assert.equal(r.status, 5); assert.match(r.stderr, /already exists/); assert.ok(fs.readFileSync(man).equals(before));
 // another study: refused, untouched
 r = run(['--study', F6, o, ...OPT.map(x => x.startsWith('seeds=') ? 'seeds=101,102,104' : x), c, 'resume=1']); assert.equal(r.status, 5); assert.match(r.stderr, /different study/); assert.ok(fs.readFileSync(man).equals(before));
 // an edited manifest body no longer matches its hash
 const copy = path.join(d, 'copy'); fs.cpSync(dir, copy, { recursive: true }); const ed = JSON.parse(before); ed.body.sequence += 1000;   /* any edit of the body, whatever the study had reached */ fs.writeFileSync(path.join(copy, 'manifest.json'), JSON.stringify(ed)); fs.rmSync(path.join(copy, 'manifest.prev.json'), { force: true });
 r = run(['--study', F6, path.join(d, 'x.json'), ...OPT, 'checkpoint=' + copy, 'resume=1']); assert.equal(r.status, 5); assert.match(r.stderr, /SHA-256/);
 // flip one byte of an engine state: detected by its hash, dropped, the seed retrained, the result unchanged
 const sf = path.join(dir, withState[0].state.file), bytes = fs.readFileSync(sf); bytes[bytes.length >> 1] ^= 0xff; fs.writeFileSync(sf, bytes);
 // truncate the current manifest: the previous commit is used
 fs.writeFileSync(man, before.subarray(0, 200));
 r = run(['--study', F6, o, ...OPT, c, 'resume=1']); assert.equal(r.status, 0, r.stderr); const x = doc(o); assert.equal(x.completion.complete, true); assert.equal(x.run.checkpoint.resumedFrom, 'manifest.prev.json'); assert.match(x.run.checkpoint.resumeNote, /previous committed manifest/);
 const e = equivalent(ref(t), o); assert.ok(e.same, e.text);
 // damaged state with an intact manifest
 const d2 = path.join(d, 'c2'), o2 = path.join(d, 'o2.json'); assert.equal(run(['--study', F6, o2, ...OPT, 'checkpoint=' + d2, 'checkpointSeconds=0.1', 'timeLimitSeconds=0.7']).status, 0);
 const m2 = JSON.parse(fs.readFileSync(path.join(d2, 'manifest.json'))), j2 = m2.body.jobs.find(j => j.state); const s2 = path.join(d2, j2.state.file), b2 = fs.readFileSync(s2); b2[100] ^= 1; fs.writeFileSync(s2, b2);
 r = run(['--study', F6, o2, ...OPT, 'checkpoint=' + d2, 'resume=1']); assert.equal(r.status, 0, r.stderr); const y = doc(o2); assert.ok(y.run.checkpoint.warnings.some(w => /does not match its recorded SHA-256/.test(w)), JSON.stringify(y.run.checkpoint.warnings)); assert.match(r.stdout, /checkpoint warning/);
 const e2 = equivalent(ref(t), o2); assert.ok(e2.same, e2.text);
 // both manifests destroyed: refused with a clear message, and replaceCheckpoint starts over
 fs.writeFileSync(path.join(d2, 'manifest.json'), 'x'); fs.writeFileSync(path.join(d2, 'manifest.prev.json'), 'y'); r = run(['--study', F6, o2, ...OPT, 'checkpoint=' + d2, 'resume=1']); assert.equal(r.status, 5); assert.match(r.stderr, /no usable manifest/);
 r = run(['--study', F6, o2, ...OPT, 'checkpoint=' + d2, 'replaceCheckpoint=1']); assert.equal(r.status, 0, r.stderr); assert.ok(equivalent(ref(t), o2).same);
});
test('5.5 process memory budget: a study over its budget stops safely, keeps a valid checkpoint and resumes; bad options are refused', t => {
 const d = tmp(t), o = path.join(d, 'o.json'), c = 'checkpoint=' + path.join(d, 'c');
 let r = run(['--study', F6, o, ...OPT, c, 'processMemoryMiB=8']); assert.equal(r.status, 0, r.stderr); let x = doc(o);
 assert.equal(x.run.stoppedByProcessMemory, true); assert.equal(x.completion.status, 'processMemoryLimit'); assert.equal(x.completion.complete, false); assert.equal(x.run.parallelSeeds, 1, 'a small budget admits one seed at a time');
 r = run(['--study', F6, o, ...OPT, c, 'resume=1']); assert.equal(r.status, 0, r.stderr); const e = equivalent(ref(t), o); assert.ok(e.same, e.text);
 x = doc(o); assert.ok(x.run.processMemoryBudgetMiB > 0 && x.run.processMemoryBudgetAutomatic); assert.ok(x.run.processMemoryBudgetMiB <= 0.7 * x.run.physicalMemoryMiB + 1); assert.ok(x.run.evaluationMemoryMiB >= Math.min(4096, x.run.tableBudgetMiB));
 for (const bad of ['parallelSeeds=0', 'processMemoryMiB=-1', 'evaluationMemoryMiB=4', 'checkpointSeconds=-2', 'resume=2', 'opponentEnumeration=flop']) assert.notEqual(run(['--study', F6, o, ...OPT, bad]).status, 0, bad);
 assert.notEqual(run(['--study', F6, o, ...OPT.filter(x => !x.startsWith('quiet')), 'resume=1', 'checkpoint=off']).status, 0, 'resume needs a checkpoint');
});
test('5.5 longer presets checkpoint by default next to the result; quick studies do not', t => {
 const d = tmp(t), f = fx('known-akq-river'), input = path.join(d, 'f.json'); fs.writeFileSync(input, JSON.stringify(f));
 const q = path.join(d, 'q.json'), s = path.join(d, 's.json');
 assert.equal(run(['--study', input, q, 'preset=quick', 'quiet=1']).status, 0); assert.equal(doc(q).run.checkpoint.enabled, false); assert.ok(!fs.existsSync(q + '.checkpoint'));
 assert.equal(run(['--study', input, s, 'preset=standard', 'budgets=500,2000', 'quiet=1']).status, 0); assert.equal(doc(s).run.checkpoint.enabled, true); assert.equal(doc(s).run.checkpoint.intervalSeconds, 60); assert.ok(fs.existsSync(path.join(s + '.checkpoint', 'manifest.json')));
 assert.equal(run(['--study', input, s, 'preset=standard', 'budgets=500,2000', 'quiet=1']).status, 5, 'the default checkpoint is not overwritten either');
 assert.equal(run(['--study', input, s, 'preset=standard', 'budgets=500,2000', 'quiet=1', 'resume=1']).status, 0); assert.equal(doc(s).run.checkpoint.pointsRestored, doc(s).completion.pointsRequested, 'resuming a finished study restores every measurement and trains nothing');
 assert.equal(run(['--study', input, s, 'preset=standard', 'budgets=500,2000', 'quiet=1', 'checkpoint=off']).status, 0); assert.equal(doc(s).run.checkpoint.enabled, false);
});
test('5.5 Study Accuracy and Recovery helpers: flags, warnings and progress text come from the stored document', t => {
 const f = fx('known-akq-river'); f.study.ev = { method: 'sampled', samples: 2000, seed: 3 };
 const a = study(t, f, ['seeds=3', 'budgets=300,3000']).doc, rows = E.study.accuracy(a);
 assert.equal(rows.length, a.variants.length); for (const r of rows) { assert.equal(r.trainingComplete, true); assert.equal(r.evaluationComplete, true); assert.equal(r.calibrated, true); assert.match(r.calibrationMethod, /Bernstein/); assert.equal(r.studyComplete, true); assert.equal(r.checkpointAvailable, false); assert.equal(r.resumable, false); assert.match(r.metric, /exact/); }
 const old = E.study.validateResult(JSON.parse(fs.readFileSync(path.join(src, '../validation/5.4/studies/btn25-open.result.json')))), ro = E.study.accuracy(old);
 assert.ok(ro.some(r => r.calibrated === false && r.warnings.some(w => /not calibrated/.test(w)) && !r.bestActionSupported));
 const big = fx('known-akq-river'); big.study.seeds = Array.from({ length: 40 }, (_, i) => i + 1);
 const part = study(t, big, ['budgets=2000,400000', 'timeLimitSeconds=0.3']).doc, rp = E.study.accuracy(part);
 assert.equal(rp[0].evaluationComplete, false); assert.equal(rp[0].studyComplete, false); assert.ok(rp[0].warnings.some(w => /^Incomplete/.test(w))); assert.equal(rp[0].toleranceMet, false);
 const p = E.study.progressText({ phase: 'training', variant: 'baseline', seedIndex: 1, sampledDeals: 5000, budgetDeals: 20000, pointsCompleted: 3, pointsRequested: 12, seedsCompleted: 1, seedsRequested: 6, parallelSeeds: 2, processRssMiB: 120.4, processPeakRssMiB: 130, processMemoryBudgetMiB: 11000, processingModeRequested: 'cpu', trainingDevicePath: 'CPU scoring', studyElapsedSeconds: 30, checkpoint: { enabled: true, commits: 4, lastCommitStudyElapsedSeconds: 22, resumed: true, lastError: '' } });
 const text = p.lines.map(l => l.join(': ')).join('\n'); assert.match(text, /3 of 12/); assert.match(text, /25% of the planned measurements; this is a count, not a time estimate/); assert.match(text, /1 of 6 \(2 run side by side\)/); assert.match(text, /last successful 8 s ago \(resumed study\)/); assert.match(text, /120 MiB in use, peak 130 MiB, budget 11000 MiB/); assert.match(text, /observed: CPU scoring/); assert.ok(!/remaining|ETA/i.test(text));
 assert.match(E.study.progressText({ phase: 'training', checkpoint: { enabled: true, commits: 1, lastCommitStudyElapsedSeconds: 1, lastError: 'disk full' } }).lines.map(l => l.join(' ')).join(' '), /LAST WRITE FAILED: disk full/);
});
// ---------------- desktop host ----------------
const { withHost, home } = require('./checkpoint_host');
const hostSkip = !(process.env.EM_TEST_HOST || build.host().exe) && (build.host().why || 'no native host');
test('5.5 desktop: studies are checkpointed, listed, resumed after Stop and after the host process is killed, and discarded, without the command line', { skip: hostSkip, timeout: 600000 }, async t => {
 const h = home(t), fixture = JSON.parse(fs.readFileSync(F6)), options = { variants: 'baseline', seeds: [101, 102, 103], budgets: [8000, 32000], threads: 3, evaluationSamples: 1000, qualitySamples: 128, checkpointSeconds: 0.05 };
 const wait = async api => { let st; for (let i = 0; i < 6000; i++) { st = await (await api('study/status')).json(); if (!st.running) break; await new Promise(r => setTimeout(r, 20)); } return st; };
 const strip = x => { const d = path.join(tmp(t), 'x.json'); fs.writeFileSync(d, JSON.stringify(x)); return d; };
 let id;
 await withHost(h, {}, async api => {
  const info = await (await api('info')).json(); assert.equal(info.studyApi, 1); assert.equal(info.studyCheckpoints, 1);
  assert.deepEqual((await (await api('study/checkpoints')).json()).checkpoints, []);
  assert.equal((await api('study/start', { fixture, options, checkpointId: '../x' })).status, 400); assert.equal((await api('study/resume', { checkpointId: 'missing' })).status, 404); assert.equal((await api('study/discard', { checkpointId: 'missing' })).status, 404);
  const started = await (await api('study/start', { fixture, options })).json(); id = started.checkpointId; assert.match(id, /^flop6-jack-\d+$/);
  let seen = null; for (let i = 0; i < 400 && !seen; i++) { const s = await (await api('study/status')).json(); if (s.progress && s.progress.checkpoint && s.progress.checkpoint.commits > 1 && s.progress.pointsRequested === 6) seen = s; else await new Promise(r => setTimeout(r, 10)); }
  assert.ok(seen, 'progress reports checkpoint commits and measurement counts'); assert.equal(seen.checkpointId, id); assert.ok(seen.progress.processRssMiB > 0 && seen.progress.processMemoryBudgetMiB > 0);
  assert.equal((await api('study/discard', { checkpointId: id })).status, 409, 'the running study cannot be discarded');
  assert.equal((await api('study/stop', {})).status, 200); const st = await wait(api); assert.equal(st.error, null);
  const partial = await (await api('study/result')).json(); assert.equal(partial.completion.complete, false); assert.equal(partial.run.stoppedByUser, true); assert.equal(partial.run.checkpoint.resumable, true);
  const list = (await (await api('study/checkpoints')).json()).checkpoints; assert.equal(list.length, 1); assert.equal(list[0].id, id); assert.equal(list[0].status, 'cancelled'); assert.equal(list[0].resumable, true); assert.equal(list[0].fixtureId, 'flop6-jack'); assert.equal(list[0].pointsRequested, 6);
  assert.equal((await api('study/start', { fixture, options, checkpointId: id })).status, 409, 'an existing checkpoint id is never overwritten');
  // resume, then kill the whole host process while it runs
  assert.equal((await (await api('study/resume', { checkpointId: id })).json()).resumed, true); await new Promise(r => setTimeout(r, 600));
 });   // withHost kills the host here (SIGTERM) while the study is running
 const dir = path.join(h, 'EightMax', 'studies', id); assert.ok(fs.existsSync(path.join(dir, 'request.json'))); JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json')));
 await withHost(h, {}, async api => {
  const list = (await (await api('study/checkpoints')).json()).checkpoints; assert.equal(list.length, 1); assert.equal(list[0].resumable, true); assert.equal(list[0].hasRequest, true);
  assert.equal((await api('study/resume', { checkpointId: id, options: { threads: 2 } })).status, 200); const st = await wait(api); assert.equal(st.error, null);
  const done = await (await api('study/result')).json(); assert.equal(done.completion.complete, true); assert.ok(done.run.checkpoint.resumed); assert.equal(done.run.threadsRequested, 2); assert.deepEqual(done.run.checkpoint.warnings, []);
  // the test host and the test CLI are separate builds of the same source and label themselves differently; everything else must agree
  const refDoc = doc(ref(t)); const e = equivalent(ref(t), strip({ ...done, build: refDoc.build, version: refDoc.version })); assert.ok(e.same, e.text);
  const after = (await (await api('study/checkpoints')).json()).checkpoints[0]; assert.equal(after.status, 'complete'); assert.equal(after.resumable, false); assert.equal(after.pointsCompleted, 6);
  for (const r of E.study.accuracy(E.study.validateResult(done))) { assert.equal(r.checkpointAvailable, true); assert.equal(r.resumable, false); assert.equal(r.studyComplete, true); }
  assert.equal((await api('study/discard', { checkpointId: id })).status, 200); assert.ok(!fs.existsSync(dir)); assert.deepEqual((await (await api('study/checkpoints')).json()).checkpoints, []);
  // a study may opt out
  assert.equal((await (await api('study/start', { fixture: fx('known-akq-river'), options: { seeds: 2, budgets: [500] }, checkpoint: false })).json()).checkpointId, null); await wait(api); assert.equal((await (await api('study/result')).json()).run.checkpoint.enabled, false);
 });
});
test('5.5 river enumeration has the default estimator\'s expected regret and average-strategy increments (frozen table) and lower variance', { timeout: 600000 }, t => {
 const d = tmp(t), exe = path.join(d, 'enum55'), obj = path.join(d, 'json.o');
 cp.execFileSync(process.env.EM_TEST_CC || 'gcc', ['-O2', '-c', path.join(src, 'native/json.c'), '-o', obj]);
 cp.execFileSync(process.env.EM_TEST_CXX || 'g++', ['-std=c++20', '-O2', '-march=x86-64', '-ffp-contract=off', '-I' + path.join(src, 'native'), path.join(__dirname, 'enum55.cpp'), obj, '-lpthread', '-ldl', '-o', exe], { stdio: 'pipe' });
 for (const g of ['hu-river', 'river3-chip']) { const sp = path.join(d, g + '.json'); cp.execFileSync('node', [path.join(src, 'tools/games48.js'), 'spec', g, sp, '901', JSON.stringify({ batchDeals: 1, device: 'cpu' })]);
  const r = JSON.parse(cp.execFileSync(exe, [sp, '5000', '300000'], { encoding: 'utf8' })), c = JSON.parse(cp.execFileSync(exe, [sp, '5000', '300000', 'control'], { encoding: 'utf8' }));
  assert.equal(r.deterministicMismatches, 0); assert.ok(r.regret.tested > 50 && r.average.tested > 50);
  // Bonferroni two-sided 0.1% over the tested entries is about 4.6; the average increments of the default are heavy-tailed, so the control sets the scale
  assert.ok(r.regret.maxAbsZ < 5, g + ' regret z ' + r.regret.maxAbsZ); assert.ok(r.average.maxAbsZ < Math.max(5, c.average.maxAbsZ + 2), g + ' average z ' + r.average.maxAbsZ + ' control ' + c.average.maxAbsZ);
  assert.ok(r.regret.varianceRatio < 0.8 && r.average.varianceRatio < 0.2, g + ' variance ratios ' + r.regret.varianceRatio + ' ' + r.average.varianceRatio);
  assert.ok(Math.abs(c.regret.varianceRatio - 1) < 0.1, 'control arms have equal variance'); assert.ok(r.stateVisitsPerUpdate[1] > r.stateVisitsPerUpdate[0]); }
});
