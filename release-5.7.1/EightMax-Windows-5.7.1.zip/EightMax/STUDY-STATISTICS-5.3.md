# EightMax 5.3 study statistics

Calculation identifier: `study-5.3-tfloor-bonferroni-v1`.

## What the intervals mean

For a fixed fixture, variant, training budget, and action (or a fixed pair of actions), let theta_r be the true evaluation value of the strategy trained with seed r. The evaluator returns Y_r with estimated sampling SE e_r. Actions within one evaluation use the SAME worlds and continuation draws, so action differences use their paired SE, including covariance. They are never treated as independent action observations.

New studies derive different deterministic pseudorandom streams for every training replication, variant, budget, and evaluation purpose. `evaluationSeed`, `qualitySeed`, the derivation, and the relationships are exported. This is reproducible pseudorandom sampling, not a claim that a deterministic PRNG supplies a mathematical independence proof. The derivation is mix32(base XOR mix32(training seed) XOR mix32(budget) XOR FNV-1a(variant name) XOR purpose); EV purpose is 0x45560053 and quality purpose is 0x51550053. The mix constants are 0x7feb352d and 0x846ca68b, with shifts 16,15,16. A run-wide set detects collisions and increments the seed until unused. Traversal order is variant, seed, budget, EV then quality. Changing the selected plan can change collision resolution; every used seed is retained.

There are two distinct interval families:

- `ci95` targets the expected value over independent training replications at this fixed budget. It is NOT a prediction interval for one trained strategy and does not quantify distance to a poker equilibrium.
- `conditionalEvaluationCi95` targets the mean of the true values of the particular strategies that were measured. It contains evaluation sampling uncertainty only. For one replication, this is the interval for that one fixed strategy's evaluation value.

For n replications and independent evaluation streams, evaluation SE of the mean is sqrt(sum(e_r^2))/n. Observed across-run standard deviation is s_Y. The across-training interval is:

    mean(Y) +/- t_(1-alpha/(2M), df) * max(s_Y/sqrt(n), evaluation_SE)

Here df is min(n-1, smallest actual evaluation sample count minus one); exact evaluation uses n-1. The critical value is obtained by numerical inversion of the Student t distribution, checked against SciPy. A minimum SE floor prevents identical or nearly identical estimates from erasing evaluation uncertainty. It also prevents subtraction of estimated evaluation variance from making the inferential interval narrower. Under iid Gaussian replicate estimates this contains the ordinary t interval, so it cannot reduce its coverage. With heterogeneous, skewed or rare-tail poker replications this remains an APPROXIMATION. Small n does not justify claiming distribution-free 95% coverage. The included synthetic coverage report measures specified Gaussian random-effects cases, not all poker situations.

The conditional interval uses the evaluation SE and the minimum evaluation degrees of freedom, with the same multiplicity factor. If evaluations are shared or the relationship is unknown, it uses the covariance upper bound sum(e_r)/n (Cauchy-Schwarz). In that case the across-training interval is unavailable; the observed spread cannot identify the unseen common component. Exact evaluations have zero evaluation error; at least two independent training replications are still required for an across-training interval. Unknown errors are null, never zero.

`sdAcrossSeeds` is the observed spread of estimates. `betweenStrategySd` is a descriptive, truncated variance-component estimate sqrt(max(0,s_Y^2-mean(e_r^2))) for independent streams. It can be zero when observations do not identify training variation. In particular, zero does not mean there is no uncertainty. For quality, conservative per-seat covariance bounds can make this subtraction overestimate evaluation variance; the result is not an unbiased training-variance estimate. Ranking uses the total interval, never this descriptive component.

Frequency uncertainty has no evaluation sampling component: frequencies are read from the trained strategy. Frequency `ci95` fields are ordinary, pointwise t intervals; frequency SD and budget changes are descriptive checks and are not used as inferential ranking tests.

## Selection, multiplicity and repeated budgets

M is fixed from the requested plan before measurement. For every variant and budget it includes all action EVs, every unordered action pair, and the quality metric. For nonbaseline variants it additionally reserves 2k + k(k-1)/2 comparisons for frequency/EV changes and selected within-variant sensitivity pairs. This conservative count includes unmeasured budgets and omitted quality metrics. Conditional intervals and across-training intervals form separate simultaneous families; no joint 95% claim is made for combining the two families.

Each interval uses alpha=0.05/M. Bonferroni protects a selected leading pair without needing independence between action comparisons, variants, or budgets, subject to the accuracy of the component intervals. A `ranked` verdict requires the chosen action to exceed EVERY other action by the declared EV margin, not just the runner-up. A `nearTie` concerns only the selected leading pair and does not validate an equilibrium mixture. All pairwise intervals are exported.

The runner never stops on favorable values or when tolerance first passes. Successive-budget frequency/gap change checks are explicitly descriptive; they are not confidence sequences or statistical stopping rules. The first passing budget is identified within the predeclared family. Re-running studies, changing fixtures after inspecting results, or searching across independent files is not covered by that family.

## Quality and sensitivity

The exact quality metric is the sum of exact unilateral response gains within the specified abstraction. Sampled quality evaluates selected one-decision deviations and remains a lower bound, not exploitability or an equilibrium certificate. The sampled quality SE is the SUM of per-seat SEs, a covariance upper bound; unavailable seat SEs invalidate required quality. The scalar then uses the same across-replication calculation. A declared quality threshold requires all requested quality evaluations and a finite simultaneous UPPER bound below the threshold.

Sensitivity training results are paired by training seed. Evaluations use independent streams across variants, so the per-seed error of a difference is hypot(SE_baseline, SE_variant). The across-training paired differences use the same SE floor and study-wide family. Added-action and baseline-pair comparisons use the adjusted all-pairs intervals inside the variant. Reports explicitly identify incomplete comparisons. Cross-utility EV differences are not formed.

## Complete means complete

Every requested seed has a record at every requested budget: completed, unstarted, cancelled, timeLimit, memoryLimit, evaluationFailed, or trainingIncomplete, with a reason. A completed seed must reach the intended training budget and finish the action evaluation and every scheduled/required quality evaluation. Declaring a quality threshold overrides `quality.budgets:last` and requires quality at each budget. Missing quality, missing uncertainty, a partial action evaluation, or a memory stop cannot satisfy a required threshold.

Aggregates retain measurements but count `requestedSeeds`, `evaluatedSeeds`, and `completedSeeds` separately. All requested seeds must complete before tolerance can pass or a ranking can be declared. Both neighboring budgets must be complete for the descriptive stability check. An earlier valid passing budget remains identified when a later budget is incomplete, and the summary explicitly reports the latter. The CLI, desktop API, UI, JSON and CSV consume the same stored flags. CSV includes a separate completion table even for budgets with no action estimates.

Time and cancellation limits are cooperative. Training checks in 256-update chunks when a time limit or cancellation flag is present. Evaluations are capped to remaining study time subject to the evaluator's 100 ms minimum. A slow update, scheduling delay, or a 100 ms evaluator chunk can overrun the requested study deadline. This does not turn partial work into complete work.

## Older documents

Opening a document without the current calculation identifier creates a `study-5.3-legacy-review-v1` result. It retains all per-seed measurements, action frequencies, EV estimates, settings and timing. Original confidence and tolerance fields are stored under `legacyConfidence`, and the source version/build and recalculation method are explicit. Exact-evaluation intervals can be recomputed. Shared sampled evaluations cannot support an across-training confidence claim: that field is null, rankings are withheld, and fresh independent evaluation is requested. Where raw paired errors and sample counts permit, a conservative conditional interval is calculated. Old sensitivity confidence is preserved as historical data and withheld from the current display. Reopening a reviewed export is idempotent.

## References and independent checks

- NIST, Confidence Limits for the Mean: https://www.itl.nist.gov/div898/handbook/eda/section3/eda352.htm
- NIST, Bonferroni's Method: https://www.itl.nist.gov/div898/handbook/prc/section4/prc473.htm
- `source/tools/statistical_validation53.py` generates Gaussian effects and known correlated evaluation errors independently with NumPy, calls the actual C++ aggregate through `source/tests/study53_probe.cpp`, and compares quantiles with SciPy. It reports simultaneous interval coverage, false rankings and ranking power with Wilson 95% intervals. This is empirical evidence under the listed models, not a guarantee for arbitrary data.
