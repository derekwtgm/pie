@echo off
cd /d "%~dp0"
rem Checkpointed automatically into EightMax-5.7-standard-study.json.checkpoint. If it is interrupted, run "Resume 5.7 standard study.bat".
mwcli.exe --study studies\known-akq-river.emfix.json EightMax-5.7-standard-study.json preset=standard processingMode=auto
if errorlevel 5 echo A saved study already exists. Run "Resume 5.7 standard study.bat" to continue it.
pause
