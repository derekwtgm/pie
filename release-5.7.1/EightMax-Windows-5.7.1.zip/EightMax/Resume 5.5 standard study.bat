@echo off
cd /d "%~dp0"
mwcli.exe --study studies\known-akq-river.emfix.json EightMax-5.5-standard-study.json preset=standard processingMode=auto resume=1
pause
