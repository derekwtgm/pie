# EightMax Windows 5.2

Build **0e6886ced89b8f81**. EightMax.exe, mwcli.exe, gpustress.exe, BUILD-INFO.json, the offline page and the source fingerprint all report it; the Windows executables were built twice and are byte-identical.

**Baseline check (done first).** The attached 5.1 ZIP verified against its manifest (1,228 entries, 0 failures). Rebuilding its source here with the documented cross-compiler reproduced the three shipped 5.1 executables byte for byte (build 7d08acc7eb4577ee). The uploaded `Windows-self-test.json` (126 checks passed), `hardware-validation.json` (passed, physical RTX 4060 Ti execution verified), `device-results.json` and `EightMax-4.9-self-test.json` (15 passed) all carry that build. `EightMax-4.7-self-test` and `EightMax-4.8-self-test` were named in the request but not attached. Details: `validation/5.2/baseline/`.

**Where 5.2 was measured.** One development machine: Intel Xeon 2.30 GHz, **4 logical CPUs**, 15 GiB RAM, Linux, **no GPU**. "Windows" results are the release executables under Wine 9.0 on that machine. **Nothing in 5.2 ran on the target PC, on Windows itself, on 24 threads or on a physical NVIDIA GPU, and no Windows CI run was possible** (no repository access from this environment). The machine was suspended twice during the work; interrupted runs were repeated, completed ones kept (logged).

## What 5.2 adds

A **decision study**: for one hero hand at one decision, train the spot several times from independent seeds through growing budgets and report what the evidence says about the action. It is one native implementation (`source/native/study52.hpp`) reached three ways:

- **Study tab** in the Windows application: pick a built-in fixture or open a fixture file, read its full description, press *Open in Multiway tab* (the game appears in the normal form; Solve and the explorer work as usual) or *Run study*; *Export JSON / CSV*; *Open result file*.
- `mwcli.exe --study studies\flop6-jack.emfix.json result.json [variants= seeds= budgets= threads= memoryMiB= timeLimitSeconds=]` (or `Run 5.2 study.bat`).
- Desktop host routes `/api/study/start|status|result|stop`.

For every legal action it shows the average-strategy frequency and the EV; the **EV gap** between the two leading actions with a 95% interval over independently trained strategies; the **evaluation sampling error** (paired: every sample evaluates all actions on the same cards and continuation draws) separately from the **spread between trained strategies**; how both move across seeds and budgets; the **quality metric** with its unit and kind (exact / sampled lower bound); training, EV-evaluation and quality-evaluation seconds; peak RAM; the share of evaluation samples that ran into information sets training never visited; and the **first budget that meets the fixture's declared tolerance**, or the last measured gap and budget if none does. Chip EV is in BB; ICM EV is in percent of the prize pool; the two are never compared.

Verdicts: **ranked** (the whole interval of the gap lies above the declared EV tolerance), **nearTie** (the whole interval lies inside ± tolerance: a mix is consistent with the evidence and the frequencies are the result), **smallEdge** (above zero but not above the tolerance), **unresolved**.

Training code is unchanged: every existing option produces the 5.1 bytes (5.1 checkpoints continue to the 5.1 uninterrupted states; golden `aa809741…`).

## Summary: one row per decision

All rows: 5 seeds, the default trainer, baseline variant, numbers at the last budget (no realistic study met its declared tolerance, so none has an earlier "stable" budget). Times are training time per seed on the idle development machine with one worker (`validation/5.2/studies/idle-timing.json`); RAM is the process peak.

| Study | Hero and decision | Recommended action or mix | EV gap (95% interval over trainings) | Evaluation se / between-training sd | Quality (kind) | Budget used | Training time per seed | Peak RAM | Tolerance |
|---|---|---|---|---|---|---|---|---|---|
| **btn25-open** | BTN Kd8c, first to act | **Small edge for Raise to 2.2**: Raise to 2.2 87%, Fold 13% | Raise to 2.2 − Fold = +0.047 BB [+0.035, +0.060] | 0.004 / 0.003 | −0.0396 (sampled) | 4,000,000 deals | 85.2 s | 817 MiB | **not reached** (last 4,000,000) |
| **btn25-open-small** | BTN Kd8c, first to act | **Unresolved**: Fold 93%, Raise to 2.2 7% | Fold − Raise to 2.2 = +0.045 BB [−0.004, +0.095] | 0.002 / 0.040 | −0.0008 (sampled) | 2,000,000 deals | 9.0 s | 7 MiB | **not reached** (last 2,000,000) |
| **flop3-kings** | BTN KhJs after SB Check, BB Check | **Unresolved**: Bet to 2.442 82%, Check 15%, Bet to 5.55 3% | Bet to 2.442 − Bet to 5.55 = +0.025 BB [−0.036, +0.087] | 0.005 / 0.048 | 0.0540 (sampled) | 4,000,000 deals | 72.1 s | 57 MiB | **not reached** (last 4,000,000) |
| **flop3-kings-small** | BTN KhJs after SB Check, BB Check | **Unresolved**: Bet to 5.55 63%, Bet to 2.442 37% | Bet to 2.442 − Bet to 5.55 = +0.050 BB [−0.170, +0.269] | 0.000 / 0.177 | 0.0198 (exact) | 2,000,000 deals | 11.5 s | 6 MiB | **not reached** (last 2,000,000) |
| **flop3-kings-detailed** | BTN KhJs after SB Check, BB Check | **Unresolved**: Check 49%, Bet to 2.442 40%, Bet to 5.55 10% | Bet to 2.442 − Check = +0.087 BB [−0.163, +0.336] | 0.019 / 0.007 | n/a (none) | 4,000,000 deals | 167.4 s | 1548 MiB | **not reached** (last 4,000,000) |
| **flop6-jack** | UTG+1 AdJs after SB Check, BB Check | **Small edge for Check**: Bet to 8.448 38%, Bet to 4.224 31%, Check 30% | Check − Bet to 8.448 = +0.101 BB [+0.034, +0.169] | 0.008 / 0.051 | −0.0984 (sampled) | 4,000,000 deals | 191.1 s | 87 MiB | **not reached** (last 4,000,000) |
| **flop6-jack-small** | UTG+1 AdJs after SB Check, BB Check | **Unresolved**: Bet to 4.224 51%, Bet to 8.448 49%, Check 1% | Bet to 8.448 − Bet to 4.224 = +0.088 BB [−0.198, +0.374] | 0.000 / 0.230 | 0.1774 (exact) | 2,000,000 deals | 17.4 s | 11 MiB | **not reached** (last 2,000,000) |
| **icm8-bb-call** | BB AdTc after BTN All-in 39.9, SB Fold | **Small edge for Call 17.9**: Call 17.9 71%, Fold 29% | Call 17.9 − Fold = +0.044 percent of the prize pool [+0.033, +0.055] | 0.002 / 0.008 | 0.0016 (sampled) | 8,000,000 deals | 66.8 s | 50 MiB | **not reached** (last 8,000,000) |
| **icm8-bb-call-small** | BB AdTc after BTN All-in 39.9, SB Fold | **Prefer Fold**: Fold 100% | Fold − Call 17.9 = +0.724 percent of the prize pool [+0.724, +0.725] | 0.000 / 0.000 | 0.0000 (exact) | 2,000,000 deals | 3.9 s | 509 MiB | met at 2,000,000 |
| **known-akq-river** | Seat 2 KhKd after Seat 1 All-in 10 | **Mix (EVs within tolerance)**: Fold 50%, Call 10 50% | Fold − Call 10 = +0.002 BB [−0.015, +0.019] | 0.000 / 0.017 | 0.0092 (exact) | 4,000,000 deals | 4.1 s | 6 MiB | met at 4,000,000 |

Full tables per budget, per variant and per seed: `validation/5.2/studies/STUDY-RESULTS.md` and the `*.result.json` files (open them in the Study tab).

## Answers

**1. On which six-player studies did adaptive training produce a reproducible improvement at longer budgets?** **None.** In the pre-registered confirmation (12 fresh seeds, three worker threads, exact wall-time checkpoints) warm-4-256 was *worse* than the default on flop6 at 10 s (NashConv ×2.11 [1.24, 3.58], Holm p = 0.04), no different on flop6w (×1.03 [0.79, 1.35] at 10 s; ×0.84 [0.48, 1.44] at 60 s) and not better on the realistic six-way fixture at 60 s (sampled metric −0.014 BB [−0.034, +0.005]; it was better there at 10 s, −0.027 BB [−0.049, −0.004], a secondary comparison). At 300 s (three seeds, descriptive) it was worse than the default in every seed on flop6 and on the realistic fixture. All three parts of the frozen rule fail, so **no six-player preset is exposed** and the default is unchanged. The 5.1 one-second gain does reproduce on this machine (×0.79 and ×0.75 at 1 s on the 5.1 seeds), so the gain is real but short-lived. Section 2.

**2. Which decisions stabilized within the available budget, and which remained unresolved?** Stabilized (declared tolerance met): the known A-K-Q game (a true 50/50 mix, gap 0) and the small exact ICM companion (fold; chip-EV variant call). Informative but not stable to tolerance: the realistic ICM call (A-To is a near-indifferent mix under ICM, gap 0.04% of the prize pool; a clear call in chip EV) and the 25 BB button open (K-8 offsuit raises 87% of the time; raise leads fold by +0.047 BB [+0.035, +0.060], a small edge that sits on the 0.05 BB tolerance, with the frequency still varying by 15 points between seeds). **Unresolved**: both flop studies, realistic and small. The three-way flop leans to the small bet by frequency (82%) but its EV edge over the large bet is +0.03 BB with an interval that includes zero; the six-way flop is a three-way mix whose frequencies and EVs still disagree at 4 million deals. Their small exact companions show why: at exact NashConv of 0.02 BB (three-way) and 0.18 BB (six-way) different seeds still land on different mixes.

**3. Did any practical recommendation change when one reasonable modelling assumption changed?** Yes, in three places. (a) **Utility:** the same big-blind call is a clear call in chip EV (+4.1 BB) and a near-tie under ICM in the realistic fixture, and flips from call to fold in the small exact companion. (b) **Added size in the small three-way flop:** the 125% overbet becomes the most frequent action (52%) in all five seeds, yet its EV advantage is +0.31 BB with an interval of [−1.34, +1.96]: frequencies moved, the ranking is not established. (c) **Wider caller range on the six-way flop:** the large bet rises from 38% to 52% while the EV gap between check and large bet stays inside ±0.2 BB: again a frequency shift without a resolved EV difference. No variant produced an EV ranking that reversed an *established* baseline ranking. For the question "does the solver still prefer the smaller bet six-way?": it never preferred it. The 33% bet is the lowest-EV of the three actions in the baseline (−0.23 BB against checking) and in both variants; the added pot-size bet is used 2% of the time and is 0.17 BB worse than checking.

**4. Which claims were verified on Windows, on physical NVIDIA hardware, or only on the development machine?**

| Claim | Verified on |
|---|---|
| 5.1 baseline: Windows self-test 126/126, hardware validation, four device modes one checksum, 1 calibration + 99 reuses in GPU Preferred and Hybrid | **Target PC, physical RTX 4060 Ti** (your uploaded reports; they describe 5.1) |
| 5.2 Windows executables start, report the build, run a study that matches the known game's closed form, pass the 4.7 / 4.8 / 4.9 self-tests, serve the Study tab; study results equal the Linux results; the Study tab's displayed numbers equal the exported data | Release `.exe` files under **Wine** on the development machine (not Windows) |
| 5.2 device fixture: one canonical state in all four modes, Automatic does not open CUDA, 1 calibration + 99 reuses, crossover routes | **Simulated CUDA driver** (Linux test double and Windows DLL under Wine). No GPU |
| Every 5.2 timing, the six-player confirmation, the decision studies, deadline latencies, sanitizers, the Linux regression | **Development machine only** (4 CPUs, Linux) |
| Anything on real Windows, on 24 threads or on the RTX 4060 Ti for 5.2 | **Not verified** |

## 1. Study fixtures (requirement 1)

Ten files in `studies/` (also built into the page). Each records table (8 players dealt in, 0.5 / 1 blinds, 0.1 ante per player, 2.3 BB before voluntary action), stacks, positions, action history, board, hero seat and hand, legal actions with amounts, bet sizes per street, utility model and unit, hand abstraction, continuation assumptions, range text and weights per seat, and the study plan with its declared tolerance.

| Fixture | Decision | Model |
|---|---|---|
| `btn25-open` | Folded to the button, 25 BB, K♦8♣: fold or raise to 2.2 | BTN / SB / BB, every hand; blinds weighted for bunching after five folds (1.00 / 0.95 / 0.90 by strength tier); blinds fold, call or 3-bet all-in; linked flop 50%, turn 66%, river 75%; Compact hand groups |
| `flop3-kings` | BTN open, both blinds call; K♠8♦5♥, checked to the button with K♥J♠: check, bet 33%, bet 75% | Weighted class ranges (109 / 262 / 360 combinations); turn 66%, river 75%; Compact groups |
| `flop6-jack` | UTG+1 raises to 2, five callers; J♥8♦4♣, two checks, UTG+1 with A♦J♠ and three players behind: check, bet 33%, bet 66% | Weighted class ranges (59-125 combinations a seat); turn bet 66%, no river betting; Compact groups |
| `icm8-bb-call` | Final table, stacks 22 / 9 / 31 / 14 / 27 / 40 / 12 / 18 BB, payouts 30-20-14-11-9-7-5-4%; BTN (40) all-in, SB folds, BB (18) with A♦T♣: call or fold | BTN / SB / BB every hand with bunching weights; ICM in percent of the prize pool; `chip-ev` variant of the same spot in BB |

Each has a **wider-range** and an **added-size** variant that change exactly one input (tested), and a **small companion** (`*-small`: short weighted ranges, exact cards, less or no later betting) whose `simplifications` list says precisely what was cut. `known-akq-river` is a textbook game with a closed-form mixed equilibrium, used to test the report.

**Limits reached, and what was kept.**

- `flop3-kings-detailed` is the three-way flop as first specified, with the application's default Detailed hand groups. It is kept: both seeds hit the 2,048 MiB strategy-table budget before 4,000,000 deals (at most 3,696,343), with 59% of the hero's evaluation samples still reaching untrained information sets. `flop3-kings` (Compact groups, same ranges and bets) is the workable version.
- **Exact evaluation** is feasible only when every preflop line ends all-in or folded. A 2.2 BB raise that can reach a checked-down flop makes the exact evaluators walk every runout: a single exact best response exceeded 2,000,000,000 visits after 72-99 s. So `btn25-open-small` and the added-size variant of `icm8-bb-call-small` use sampled evaluation (stated in the fixture), and the realistic fixtures use the sampled one-shot deviation metric.
- **The engine stops at 10,000,000 committed updates per study** (unchanged from 5.1). The study refuses a larger budget with that reason; the ICM fixture's budgets were set to 0.5 / 2 / 8 million deals because of it.

**Normal workflow, verified.** For every fixture, `tools/study_ui52.js` opened the file in the Study tab, pressed *Open in Multiway tab* and *Solve*, captured the specification the application sent to the engine and compared it with the fixture's (equal for every variant tested), then asked the engine for the decision node and compared actor, pot, legal actions and hero hand. Result: 91 of 91 checks pass on the Linux host and 91 of 91 on `EightMax.exe` under Wine (`validation/5.2/ui/`). `tests/v52.test.js` regenerates every fixture through the form → game → native specification path and compares byte for byte.

## 2. Six-player schedule at longer budgets (requirement 2)

**Short-budget baseline, reproduced.** The 5.1 confirmation (seeds 701-740, 4 threads) re-timed here; NashConv at equal deals is deterministic and was checked against the 5.1 raw data on 186 re-evaluated checkpoints (0 mismatches).

| warm-4-256 vs default, equal time | 5.1 machine | this machine |
|---|---|---|
| flop6 @ 1 s | 0.69 [0.56, 0.85] | 0.79 [0.64, 0.98] |
| flop6w @ 1 s | 0.61 [0.54, 0.68] | 0.75 [0.66, 0.86] |
| river3 @ 0.01 s (control, margin 1.15) | 1.08 [0.95, 1.22] | 1.17 [1.06, 1.29] |

The gain is smaller here because the batched arms' throughput advantage is smaller (about 1.5× deals per second with four threads here against 1.9× there). At equal sampled deals the ratios are near 1 on both machines: **the one-second gain is parallel throughput, not the schedule.**

**Frozen before confirmation** (`validation/5.2/six-player/preregistration.json`, committed before any confirmation run): fixtures flop6, flop6w (original, exact NashConv) and `flop6-jack` (realistic; sampled one-shot deviation gains with 400,000 evaluation samples, one decision node per seat, common random numbers across arms), controls river3-chip and turn4; arms default (one worker by construction), parallel64 and warm-4-256 (three workers, CPUs 0-2); checkpoints at exact training wall times 10, 60 and 300 s (300 s for three seeds); fresh seeds 801-812, justified by compute (12 seeds detect a 30% effect with about 80% power, not the 20% minimum meaningful improvement; an interval containing both 0.80 and 1.00 is "inconclusive"); four primary comparisons with Holm; control margin 1.15; incomplete runs kept, excluded from what they cannot support, and counted.

**A hard limit found while planning.** The engine refuses more than 10,000,000 committed updates. The default trainer commits one deal per update, so it stops after 49-55 s on flop6 (12 seeds) and 66-79 s on flop6w (the three seeds that were run past 60 s). It cannot use a 60 s (flop6) or 300 s budget at all; the batched arms can. The report compares each batched arm at the budget with the default at its cap separately and labels it as not an equal-time comparison.

**Confirmation** (`confirmation.json`, `decision.json`; ratio or difference vs default at equal training time; lower is better):

| Fixture (metric) | 10 s | 60 s | 300 s (3 seeds) |
|---|---|---|---|
| flop6, warm-4-256 (exact NashConv ratio) | **2.11 [1.24, 3.58]** worse | default capped at ~52 s; vs default at its cap 0.94 [0.55, 1.59] | vs default at its cap 3.26 [0.38, 27.7]; worse in 3 of 3 seeds |
| flop6w, warm-4-256 | 1.03 [0.79, 1.35] | 0.84 [0.48, 1.44] inconclusive | default capped at ~73 s; vs cap 1.17 [0.15, 9.1] |
| flop6-jack, warm-4-256 (sampled, BB difference) | −0.027 [−0.049, −0.004] | −0.014 [−0.034, +0.005] | +0.022 [−0.020, +0.064]; worse in 3 of 3 seeds |
| flop6, parallel64 | 2.62 [1.49, 4.61] worse | vs cap 1.30 [0.68, 2.49] | vs cap 4.06 [0.46, 36.2] |
| flop6w, parallel64 | 0.83 [0.55, 1.26] | 1.08 [0.72, 1.62] | vs cap 1.59 [0.83, 3.04] |
| flop6-jack, parallel64 | −0.045 [−0.072, −0.017] | −0.024 [−0.053, +0.006] | +0.008 [−0.117, +0.133] |
| river3-chip, warm-4-256 (control) | 1 s: 1.29 [0.97, 1.73] | 10 s: 0.83 [0.54, 1.28] | – |
| turn4, warm-4-256 (control) | 1 s: 0.91 [0.70, 1.18] | 10 s: 1.02 [0.80, 1.30] | – |

- **Decision:** rule (a) (≥ 20% better with Holm p < 0.05 at flop6w @ 60 s and flop6 @ 10 s) fails; rule (b) (no primary worse than default) fails on flop6 @ 10 s; rule (c) fails at 300 s. **No preset; `batchSchedule` stays an opt-in native/CLI option; default unchanged.** No control comparison demonstrates non-inferiority either (upper bounds 1.18-1.73 against the 1.15 margin, with 12 seeds).
- **Worker counts and deals.** Default: 1 worker, 192k (flop6), 140k (flop6w), 22k (flop6-jack) deals per second. Batched arms: 3 workers, 275-281k, 214-216k, 38-39k: a 1.4-1.75× throughput advantage. On river3 a batch is too small to split, so the batched arms also ran on one worker.
- **Equal sampled deals** (schedule without parallelism; interpolated between an arm's own checkpoints): flop6w at 8.4 M deals 1.03 [0.66, 1.61]; flop6-jack at 1.3 M deals +0.020 BB [−0.001, +0.042]; river3 0.96 [0.64, 1.43]; turn4 1.19 [0.91, 1.55]. No schedule effect in either direction is established.
- **warm-4-256 vs parallel64** (same worker count): 0.72-1.24 with intervals that all include 1.
- **Longer is not better on flop6.** Geometric-mean NashConv of warm-4-256: 0.037 BB at 10 s (2.8 M deals), 0.031 at 60 s (17 M), 0.093 at 300 s (83 M); the default goes from 0.017 at 10 s (1.9 M deals) to 0.034 at its cap (10 M deals). The average strategy of this six-player all-in game does not keep approaching zero gain; CFR has no convergence guarantee with more than two players. On flop6w and flop6-jack quality still improved from 10 s to 60 s.
- **Time and memory.** Training peak RSS 8 MiB (flop6, flop6w) and 57-73 MiB (flop6-jack). Evaluation per call: 0.75 s (flop6), 10.8 s (flop6w), 8.8 s (flop6-jack), recorded separately from training time.
- **Incomplete runs:** the default hit the update cap before 60 s in 12 of 12 flop6 seeds and before 300 s in 3 of 3 flop6w seeds (kept, reported as capped). No memory stops, no failed runs, no excluded or replaced seeds. Runs interrupted by the machine suspension were repeated from scratch.
- **What a sampled metric can say.** For flop6-jack the permitted deviations are one decision node per seat with the continuation unchanged, estimated from 400,000 samples (standard error about 0.01-0.02 BB per evaluation; values can be slightly negative). It is a lower bound: a low value does not certify an equilibrium of the fixture, let alone of the unrestricted game.

## 3. What solver uncertainty means for the action (requirement 3)

- **Same evaluation draws for competing actions.** Sampled action EVs use common random numbers (existing evaluator): every sample evaluates all actions on the same cards and continuation draws, and the paired standard error of each difference is taken from the evaluator's joint covariance. The same evaluation seed is used for every training seed and budget.
- **Two uncertainties, kept apart.** Per budget the result gives the 95% t interval of the mean gap over trained strategies (contains both sources), the evaluation standard error of that mean alone, and the between-training standard deviation after removing it. With exact evaluation the first is zero.
- **Declared tolerance.** A budget meets it when, across seeds, every action's frequency has sd ≤ `frequency`, the half-width of the gap interval is ≤ `evGap`, the quality metric is ≤ `quality` where declared, every seed reached the budget, and neither frequencies nor gap moved by more than the tolerance since the previous budget. Meeting it says the measured answer is stable; it does not certify an equilibrium.
- **Known small game** (`known-akq-river`: pot 10, bet 10; closed form: call 1/2, EV(call) = EV(fold) = 0). The study reports call 50.0% (sd 0.1%), gap +0.002 BB [−0.015, +0.019], verdict *nearTie*, exact quality 0.009 BB, tolerance first met at 4,000,000 deals; no budget reports a ranking. An independent test recomputes EV(call) by hand from the trained betting frequencies and matches the evaluator to 1e-9.
- **Intentionally undertrained study** (three-way flop companion at 100 / 200 / 400 deals): the tolerance is never met; the page and the CLI show "tolerance not reached; last measured budget 400" with the frequencies and the last gap.
- **Displayed numbers against exported data.** `tools/study_ui52.js` compared every value in the result tables with the result document (frequency, sd, EV, gap, interval, both error terms, quality, the three times, peak RAM, verdict, headline) and the downloaded JSON and CSV with the same document. 322 values were compared on the Linux host (known game, undertrained study, three-variant study, a result file written by `mwcli --study`); the Windows executable under Wine passes the same 91 checks. The exports are identical to the document.

## 4. Sensitivity to ranges and bet sizes (requirement 4)

Variants use the same seeds as the baseline and are compared by seed at the last common budget.

| Study | Variant (one change) | Most frequent action: baseline → variant | Seeds where it changed | Largest mean frequency change | EV gap in the variant | Added action | Note |
|---|---|---|---|---|---|---|---|
| btn25-open | **wider-range**: Blind ranges without the bunching weights: every hand of both blinds at weight 1 (weak hands are 11% more frequent than in the baseline). | Raise to 2.2 → Raise to 2.2 | 0 of 5 | 8.9% | Raise to 2.2 − Fold = +0.126 BB [+0.098, +0.153] (ranked) | – |  |
| btn25-open | **added-size**: The button may also open all-in (25 BB) in addition to raising to 2.2 BB. | Raise to 2.2 → Raise to 2.2 | 0 of 5 | 1.3% | Raise to 2.2 − Fold = +0.039 BB [+0.008, +0.071] (smallEdge) | All-in 24.9: 0.1%, EV vs Raise to 2.2 −0.776 BB [−0.823, −0.728] |  |
| btn25-open-small | **wider-range**: The big blind range gains a weaker hand (Jh4h at weight 1). | Fold → Fold | 0 of 5 | 0.6% | Fold − Raise to 2.2 = +0.029 BB [−0.003, +0.062] (unresolved) | – |  |
| btn25-open-small | **added-size**: The button may also open all-in (25 BB). | Fold → Fold | 0 of 5 | 0.6% | Fold − Raise to 2.2 = +0.033 BB [+0.015, +0.051] (smallEdge) | All-in 24.9: 0.0%, EV vs Fold −1.050 BB [−1.054, −1.046] |  |
| flop3-kings | **wider-range**: The big blind calls preflop with a wider range: 15 more offsuit and suited classes (K7o, K6o:0.5, Q8o, J8o, T8o, 97o, 86o:0.5, 76o, Q7s, J7s, T7s, 96s, 85s, 74s:0.5, 53s). | Bet to 2.442 → Bet to 2.442 | 0 of 5 | 3.5% | Bet to 2.442 − Bet to 5.55 = +0.019 BB [−0.046, +0.083] (unresolved) | – |  |
| flop3-kings | **added-size**: A 125% pot overbet is added on the flop (33%, 75% and 125% pot). | Bet to 2.442 → Bet to 2.442 | 0 of 5 | 0.2% | Bet to 2.442 − Bet to 5.55 = +0.053 BB [−0.042, +0.148] (unresolved) | Bet to 9.25: 0.1%, EV vs Bet to 2.442 −0.223 BB [−0.390, −0.056] |  |
| flop3-kings-small | **wider-range**: The big blind range gains two weaker hands (Jh9h and 6h4h at weight 1). | Bet to 5.55 → Bet to 5.55 | 1 of 5 | 10.8% | Bet to 5.55 − Bet to 2.442 = +0.060 BB [−0.006, +0.126] (unresolved) | – | the baseline's EV order of its two leading actions is reversed |
| flop3-kings-small | **added-size**: A 125% pot overbet is added on the flop. | Bet to 5.55 → Bet to 9.25 | 5 of 5 | 30.8% | Bet to 9.25 − Bet to 5.55 = +0.313 BB [−1.336, +1.962] (unresolved) | Bet to 9.25: 52.0%, EV vs Bet to 5.55 +0.313 BB [−1.336, +1.962] (**now most frequent**) | the baseline's EV order of its two leading actions is reversed |
| flop6-jack | **wider-range**: The button (the last caller) holds a wider range: 15 more classes (22, A6s, A2s, K8s, Q8s, J7s, T7s, 96s, 65s, 54s:0.5, KTo, QTo, J9o, T9o:0.5, A9o:0.5). | Bet to 8.448 → Bet to 8.448 | 1 of 5 | 13.9% | Check − Bet to 8.448 = +0.019 BB [−0.157, +0.196] (unresolved) | – |  |
| flop6-jack | **added-size**: A pot-size bet (100% pot) is added on the flop (33%, 66% and 100% pot). | Bet to 8.448 → Bet to 8.448 | 1 of 5 | 6.5% | Check − Bet to 8.448 = +0.117 BB [+0.025, +0.209] (smallEdge) | Bet to 12.8: 2.3%, EV vs Check −0.170 BB [−0.326, −0.014] |  |
| flop6-jack-small | **wider-range**: The button range gains a weaker hand (Tc7c at weight 1). | Bet to 4.224 → Bet to 4.224 | 2 of 5 | 48.2% | Bet to 4.224 − Bet to 8.448 = +0.107 BB [−0.196, +0.411] (unresolved) | – | the baseline's EV order of its two leading actions is reversed |
| flop6-jack-small | **added-size**: A pot-size bet (100% pot) is added on the flop. | Bet to 4.224 → Bet to 4.224 | 2 of 5 | 8.2% | Bet to 8.448 − Bet to 4.224 = +0.177 BB [−0.006, +0.361] (unresolved) | Bet to 12.8: 0.0%, EV vs Bet to 8.448 −0.742 BB [−1.045, −0.438] |  |
| icm8-bb-call | **wider-range**: No bunching weights: every hand of BTN, SB and BB at weight 1 (weak hands 11% more frequent). | Call 17.9 → Call 17.9 | 1 of 5 | 26.4% | Call 17.9 − Fold = +0.065 percent of the prize pool [+0.049, +0.080] (smallEdge) | – |  |
| icm8-bb-call | **added-size**: The button may also raise to 2.2 BB instead of moving all-in (blinds can call or re-raise all-in; one all-in bet on the flop). | Call 17.9 → Call 17.9 | 1 of 5 | 28.6% | Call 17.9 − Fold = +0.166 percent of the prize pool [+0.127, +0.205] (ranked) | – |  |
| icm8-bb-call | **chip-ev**: Same stacks, ranges and actions, but utilities are chips (BB) instead of ICM prize share. | Call 17.9 → Call 17.9 | 1 of 5 | 29.0% | Call 17.9 − Fold = +4.082 BB [+4.008, +4.156] (ranked) | – | different utility (percent of the prize pool vs BB): EVs not compared |
| icm8-bb-call-small | **wider-range**: The button range gains a weaker hand (Jc6c at weight 1). | Fold → Fold | 0 of 5 | 0.0% | Fold − Call 17.9 = +0.635 percent of the prize pool [+0.635, +0.635] (ranked) | – |  |
| icm8-bb-call-small | **added-size**: The button may also raise to 2.2 BB instead of moving all-in (postflop checked down). The quality metric of this variant is sampled: exact best response exceeds the work limit once a 2.2 BB raise can reach the flop. | Fold → Fold | 0 of 5 | 0.0% | Fold − Call 17.9 = +0.719 percent of the prize pool [+0.711, +0.726] (ranked) | – |  |
| icm8-bb-call-small | **chip-ev**: Same spot with chip utilities (BB) instead of ICM prize share. | Fold → Call 17.9 | 5 of 5 | 100.0% | Call 17.9 − Fold = +0.479 BB [+0.479, +0.479] (ranked) | – | different utility (percent of the prize pool vs BB): EVs not compared; the baseline's EV order of its two leading actions is reversed |

Reading it: the most frequent action changed in a majority of seeds only for the chip-EV variants and for the overbet in the small three-way flop; elsewhere frequencies moved by up to 14-48 points while the EV gap between the leading actions stayed unresolved or inside the tolerance. Where an added size was taken up at all in a realistic fixture it was worse than the best original action (three-way overbet −0.22 BB, six-way pot bet −0.17 BB, button open-jam −0.78 BB).

## 5. Reliability and packaging (requirement 5)

**Deadline behaviour.** New telemetry (`EM_QUERY_TIMING`): how long after the stop the slowest worker noticed it, the stage of that check and of its previous check, the length of that gap, and when the workers had ended and were joined. Cost: one branch per clock check; bookkeeping only once a stop exists.

`tools/deadline52.js`, release build 0e6886ced89b8f81, 100 trials per condition, 2 evaluation workers, stall detector running (2,200 deadline queries per condition):

| Return latency | n | median | p95 | p99 | max |
|---|---|---|---|---|---|
| idle, 100 ms limit | 1,400 | 101.1 | 104.9 | 106.8 | 109.2 ms |
| idle, 250 ms limit | 400 | 252.5 | 257.1 | 259.0 | 260.4 ms |
| idle, 600 ms limit | 400 | 602.5 | 607.3 | 608.5 | 609.6 ms |
| 8 busy processes on 2 CPUs, 100 ms limit | 1,400 | 105.6 | 117.3 | 124.2 | 133.6 ms |
| 8 busy processes, 250 ms limit | 400 | 258.3 | 271.5 | 279.4 | 287.7 ms |
| 8 busy processes, 600 ms limit | 400 | 611.3 | 632.9 | 645.0 | 667.0 ms |

Idle: overshoot median 1.3, p99 8.1, max 10.4 ms; workers joined 0.3 ms (median), 5.0 ms (max) after the stop. Contended: overshoot median 7.0, p99 32.9, max 67.0 ms; join after stop max 24.4 ms. (The predecessor build gave the same picture; its numbers are in `deadline/predecessor-64104bb/`.) **0 failing trials of 200** (tolerance 150 ms). The 5.1 event (stop at 100.0 ms, return at 262.6 ms) did not recur.

**A long section was found and shortened.** The telemetry showed 80-145 ms without a deadline check in the eight-player ICM sampled evaluation, on an idle machine, in 142 of 200 such queries. Cause: when the shared strategy-coverage table is promoted to a larger tier, one thread prepares the new tier and copies every key under an exclusive section and did not read the clock. With several workers another worker normally publishes the stop and the copy is abandoned; with one worker, or when the others wait for that section, nobody did until the copy ended. The section grows with the table, which fits the 211 ms gap of the 5.1 report (it cannot be proven to be the same event). 5.2: the promoting thread reads the deadline and the cancellation flag every 4,096 slots and every 64 pages and abandons the promotion; the set stays exact and the parked tier is reused. `EM_EV_PROMOTION_CHECK=0` restores the 5.1 behaviour for comparison. Measured with the stop placed at every 3 ms from 60 to 420 ms (`promotion52-final.json`, release build):

| Stop inside the promotion window | 5.1 behaviour: p99 / max | 5.2: p99 / max |
|---|---|---|
| cancellation, 1 worker | 15.4 / 19.7 ms | 3.0 / 3.2 ms |
| deadline overshoot, 1 worker | 21.2 / 22.0 ms | 6.1 / 6.4 ms |
| cancellation, 2 workers | 5.5 / 6.0 ms | 6.1 / 6.7 ms |
| deadline overshoot, 2 workers | 9.9 / 11.1 ms | 12.0 / 13.7 ms |

`tests/coverage52.cpp` proves the mechanism without a clock (a stop published inside a promotion is seen before it finishes; the promotion is abandoned; every key is still held exactly once; promotions resume afterwards). Evaluation results are bit-identical with and without the check, and an exact result that finishes inside its deadline is still returned (tested).

**Checkpoints.** Raw and EMZ1 checkpoints written by 4.9 and 5.0 (files of the 5.1 package) and by the **5.1 release `mwcli.exe`** (new fixtures in `validation/5.2/fixtures/`) continue in 5.2 to the 5.1 uninterrupted states: ICM golden `aa809741…`, external-sampling `d7821ad6…`, and the adaptive schedule saved after 4, 5, 6, 14, 15 and 16 updates (before, at and after both batch-size changes; two of them also as EMZ1; 1 and 4 workers) to `7453f92d…`. The files hold regrets, average strategy, both RNGs, counters and schedule state, so equal hashes mean all of them are equal. The inherited 5.1 tests still pass on 5.2: resume at every transition of a 5.2-written schedule, cancellation and a memory-budget stop inside an uncommitted batch, a mismatched schedule refused.

**GPU scheduling.** Unchanged code. On the 2,400-deal fixture CPU Only, Automatic, GPU Preferred and Hybrid end in the canonical state `91786e3a…` with RNG 4225209845, with no driver and with the simulated driver, on Linux and with the Windows executable and the test-double DLL under Wine; Automatic does not open CUDA; GPU Preferred and Hybrid make 1 calibration ("first measurement in this job") and 99 reuses. The 5.1 crossover tests (GPU-profitable, CPU-profitable, crossover inside one job, fault fallback) pass on 5.2. **Hardware actually used for 5.2: the simulated driver only.** The physical RTX 4060 Ti results in your uploaded reports are for 5.1; since the training and scheduling code is unchanged they are expected to carry over, which is not verified.

**Release identity.** The 5.1 difference is explained in `validation/5.2/release/README.md`: the "1,237 entries" archive was assembled on the CI runner from executables compiled there plus twelve runner-generated files (named in the workflow), while the shipped ZIP of 1,228 entries was packaged on the development machine with the release executables. They are different archives of the same source build ID, so CI's verification did not cover the shipped file. The arithmetic implies three evidence files were added after the CI commit; without the run artifact only one of them can be named. For 5.2, `tools/release52.py` builds the one ZIP, hashes it, extracts that exact file into an empty directory and there verifies the manifest, the build identity and the executables (smoke test under Wine), and writes `EightMax-Windows-5.2.identity.json` beside the ZIP. Archive hash, manifest count, executable hashes and build ID are in that record and in the delivery message.

## 6. Validation (requirement 6)

- **Linux regression** (release build 0e6886ced89b8f81): `tools/run_tests.js` **529 passed, 0 failed, 1 skipped, 0 timed out** (the skip is the read-only-folder test: the suite runs as root). 5.1 had 510; the 19 new tests are `tests/v52.test.js`. `validation/5.2/regression-linux.json`.
- **Sanitizers** (`tools/sanitize52.sh`, run on the release build 0e6886ced89b8f81): the whole 5.1/5.0 pass, `tests/v52.test.js` against the ASan+UBSan CLI and host (19 passed), `tests/coverage52.cpp` under ASan+UBSan, a ThreadSanitizer build of the host and CLI running a parallel decision study (results identical to ASan+UBSan), timed-out and cancelled exact evaluations with 4 workers, and the host study job under TSan. **All passed, no report.** `validation/5.2/sanitizers/`.
- **Windows executables under Wine** (not real Windows): 4.7 / 4.8 / 4.9 self-tests 10 + 9 + 15 checks pass; `tests/v52.test.js` 17 passed (two tests not run under Wine, reasons recorded in `wine/wine-run.log`); four processing modes with the test-double DLL end in `91786e3a…`; Study tab 91/91. The self-tests, v52 and device-mode runs under Wine used predecessor build 64104bb52e491e49 (sources identical to the release except one test tool); the browser checks used the release build.
- **Windows CI: not run** (no repository access here). `.github/workflows/windows.yml` is updated (v52 in the GCC/Clang job, release52.py, RELEASE-5.2.md, studies folder) but untested.
- **Failures and skips, all of them:** one skip in the regression (above); an early Wine run failed 2 tests (a too-strict telemetry assertion and the 4.5 s host start-up allowance, both test defects, fixed or excluded with the reason recorded); two browser-tool failures under Wine from a race in the tool (fixed; first run kept in `ui/wine-first-run-tool-race/`); the btn25 small companion was resized twice after exact evaluation proved infeasible (measured, described above). No timeouts. No unavailable-hardware skip other than the missing GPU, Windows host and CI.

## Limitations

- **No Windows machine, no 24-thread CPU, no physical GPU, no Windows CI in 5.2.** Windows evidence is Wine; GPU evidence is a simulated driver.
- **Study timings** inside the result documents were taken while other work shared the machine; use `idle-timing.json` for cost. On the target PC the default trainer still uses one thread, so expect similar or better per-seed times, and more seeds in parallel if you run several `mwcli --study` processes.
- **Five seeds** give wide intervals (t = 2.78). Several "unresolved" verdicts may resolve with more seeds or deals; the default trainer cannot go beyond 10,000,000 deals per study.
- **Multiway studies do not have to converge.** With three or more players, low gains do not make the equilibrium unique, and the small exact fixtures show different seeds settling on different mixes with different hero EVs. A stable recommendation there needs agreement across seeds, which is what the study measures.
- **The quality metric of the realistic fixtures is a sampled lower bound** and was slightly negative in several studies (selection noise): it can show a problem, not certify its absence.
- **Hand groups** (Compact) are an abstraction of the realistic fixtures; the result is about the abstract game.
