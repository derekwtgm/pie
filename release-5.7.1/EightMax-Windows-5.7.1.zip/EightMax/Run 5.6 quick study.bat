@echo off
cd /d "%~dp0"
mwcli.exe --study studies\known-akq-river.emfix.json EightMax-5.6-quick-study.json preset=quick processingMode=auto
pause
