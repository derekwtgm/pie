# EightMax 5.4 user guide

1. Extract the complete ZIP into a new folder. Keep your old folder and saved studies.
2. On Windows open `EightMax.exe`. No separate Python or Node installation is needed to run the application.
3. Open **Decision study**. Choose a fixture or open your saved fixture.
4. Choose Quick, Standard, Deep or Research. Quick is preliminary. Standard requests five independent trainings, Deep ten. Research leaves the current settings under your control. A preset does not guarantee accuracy.
5. Set seed count, increasing deal budgets, worker threads, time limit, memory and evaluation samples. Sample counts apply to sampled evaluation only.
6. Choose CPU only, Automatic, Hybrid or GPU preferred. CPU fallback remains available. The observed device can be CPU even when another mode was requested.
7. Click **Run study**. Periodic training updates show deals, algorithm, device, table size and peak RAM. Evaluation phases are displayed, but a continuous evaluation percentage and reliable finish-time estimate are not available.
8. **Stop** retains partial measurements and completion statuses. Export JSON to keep them. An exported partial study is not an automatically resumable training checkpoint.
9. Read completion counts and ranking status. An estimated best action is not necessarily statistically supported. Unresolved means evidence does not establish a ranking; incomplete means requested work is missing.
10. Export JSON for full diagnostics, CSV for tables. Existing saved studies and solver checkpoint formats remain supported.

## Quality and uncertainty

Exact NashConv sums all seats' unilateral best-response gains inside the configured game. Largest unilateral gain is the largest seat's gain. Two-player chip-EV exploitability uses NashConv / 2. A sampled one-decision response is a restricted response test; a small value cannot certify near-GTO play.

Confidence remains the 5.3 Student-t calculation with evaluation-error floor and Bonferroni correction. It is approximate for heterogeneous and non-Gaussian results. Synthetic rare-tail testing found conditional-interval undercoverage. There is no distribution-free 95% guarantee.

The training-table and evaluation-cache limits are separate budgets, not a cap on all process RAM. Keep headroom for Windows and other programs. Physical RTX 4060 Ti performance and native Windows execution were not validated in the development environment.

The included **Run 5.4 quick study.bat** and **Run 5.4 standard study.bat** demonstrate the known A-K-Q study without typing commands. These scripts save results beside the application.

## CLI

From the extracted folder:

```bat
mwcli.exe --study studies\known-akq-river.emfix.json my-study.json preset=standard processingMode=cpu timeLimitSeconds=600 threads=4
```

Explicit options override preset defaults. Other options: `seeds`, `budgets`, `memoryMiB`, `evaluationSamples`, `qualitySamples`, `variants`, `quiet`. To exceed the fixture's seed count, supply an explicit comma-separated list in the CLI. The desktop generates distinct seeds for larger counts.

Existing solver checkpoint import/export and raw/EMZ1 formats remain supported. Automatic study checkpoint scheduling/resumption, selectable confidence levels and sequential adaptive evaluation are not implemented in 5.4.
