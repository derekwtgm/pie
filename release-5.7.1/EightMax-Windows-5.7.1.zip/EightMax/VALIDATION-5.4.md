# Validation — EightMax 5.4

Build `980f82b97a922d4d`. Baseline ZIP CRC and all 1,544 manifest entries passed. Baseline build `55c4fffde6deb9a1` and source/executable identity matched. All historical source, tests, studies and evidence remain available.

## Fresh execution

- Final-source suite: 551/552 passed, with no skipped tests. The loaded deadline test overran by 464.3 ms while other suites were active. Its unchanged isolated rerun, still using nine deliberate load processes, passed with overruns of 9.0–36.5 ms. Thus all 552 distinct checks have passing outcomes; the original timing failure remains recorded.
- Development suite: 549/551 passed. Rich progress JSON exceeded the old 512-byte buffer; whole-document publication repaired the defect and the final host/large-progress tests passed. A separate 51.3 ms overrun against a 50 ms allowance passed unchanged in isolation. These deadlines are cooperative targets, not real-time OS guarantees.
- Raw records: `tests/development-regression.tap`, `tests/full-regression.tap`, `tests/reruns.json`, `tests/final-reruns.json` and their referenced rerun logs under validation/5.4.
- ASan/UBSan/float-cast-overflow focused run: 22/22 passed, 0 failed. Third-party QuickJS uses ASan only. Leak detection is disabled and unverified.
- Fresh 5.3-to-5.4 raw/EMZ1 checkpoint continuations: 24 byte-identical checks across six trainer configurations and 1/4 resume threads.
- Independent reference suite: 28 passed, 0 failed; 36 full-width comparison records also retained.
- Desktop DOM/events/export harness: 4304 assertions, 0 failures; actual Linux host API used. This is not a graphical browser or Windows visual test.
- Statistical simulation: 39000 trials, 21 quantile checks. Rare-tail conditional coverage failed; this diagnostic is not hidden among passing regressions.
- Convergence: 564 checkpoint evaluations and 48 corrected paired comparisons.
- Performance: four thread counts (1, 2, 4, 8), four exact workloads, three arms, five rounds; four complete study workflows with five paired rounds. All measurements, failures and controls retained.

The full suite covers legacy raw/EMZ1 checkpoints including 5.1/5.2/5.3 continuation, RNG/regret/average-state preservation, damaged files, transactional memory/cancellation recovery, CPU operation, GPU fallback simulations, chip EV/ICM, weighted ranges, linked streets, individual antes and desktop/CLI paths. New trainer-configuration checkpoint tests compare uninterrupted and resumed files byte for byte. No new checkpoint format was introduced.

## Scope and gaps

Native Windows execution/UI and physical RTX 4060 Ti testing are unavailable. Linux timing is not a prediction for the user's 13th-generation i7. Simulated CUDA checks establish fallback/integration behavior only. Leak checking was disabled; address/undefined-behaviour checks are separate evidence. There is no full-game GTO certificate.

Not implemented: a new learned variance-reduction estimator; adaptive sequential evaluation; selectable confidence levels; automatic study-level checkpoint/resume; new CUDA kernels; a global process-memory limit; a continuous evaluation percentage or reliable ETA. Existing solver checkpoints and partial study results remain supported. See `validation/5.4/NOT-IMPLEMENTED.md`.

The first development workspace was cleared during a usage interruption. Its incomplete logs are not counted. Changes were restored from the conversation and all evidence reported here was rerun in the recovered workspace. Any later isolated reruns are recorded separately; see validation-summary.json and tests/.

## Reproduction

See BUILD-5.4.md. The canonical ZIP's external identity JSON records the final archive hash, extracted checksum verification, source/executable identity and extracted-artifact smoke tests. Historical validation directories describe their historical releases, not this one.
