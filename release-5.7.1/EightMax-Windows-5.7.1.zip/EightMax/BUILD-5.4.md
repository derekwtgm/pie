# Building EightMax 5.4

Final source/build identifier: `980f82b97a922d4d`. Statistics identifier: `study-5.3-tfloor-bonferroni-v1` (formula unchanged). Complete source is included. Windows programs are unsigned x64 PE executables with statically linked language runtime/zlib and normal Windows system-DLL dependencies.

Build requirements: Node, Python 3, GCC/G++ supporting C++20, zlib; Linux host also needs OpenSSL development libraries. Windows cross-build uses MinGW-w64 POSIX GCC 14.2.0 and its static zlib. Research scripts require NumPy/SciPy; DOM harness requires jsdom. These are developer requirements, not runtime requirements for the Windows application.

From the release root:

```sh
node source/tools/build.js build
sh source/native/build.sh linux "$PWD/build/native.html" "$PWD/build/linux"
CC=x86_64-w64-mingw32-gcc-posix CXX=x86_64-w64-mingw32-g++-posix sh source/native/build.sh windows "$PWD/build/native.html" "$PWD/build/windows"
```

Windows MSYS2 can use CC=gcc CXX=g++ with the windows target. Compiler flags retain strict arithmetic and no FMA contraction in native multiway code. Do not change source after building without regenerating the interface and binaries; the builder and verifier enforce fingerprint agreement.

Copy build/windows executables, build/EightMax-Offline.html and build/build-info.json (as BUILD-INFO.json) to the release root. Copy Linux programs to validation/5.4/linux-bin for Linux artifact smoke tests.

```sh
EM_TEST_MWCLI="$PWD/build/linux/mwcli" EM_TEST_HOST="$PWD/build/linux/eightmax" ASAN_OPTIONS=detect_leaks=0 NODE_OPTIONS="--require=$PWD/validation/5.3/sanitizers/no-leaks.cjs" node --test --test-concurrency=3 --test-reporter=tap source/tests/*.test.js
bash validation/5.3/sanitizers/build-final.sh source build sanitized
ASAN_OPTIONS=detect_leaks=0 EM_TEST_MWCLI="$PWD/sanitized/mwcli" EM_TEST_HOST="$PWD/sanitized/eightmax" node --test source/tests/v53.test.js source/tests/v54.test.js
node source/tools/verify_build.js .
python3 validation/5.4/release54.py . output
```

The last command generates SHA256SUMS.txt, builds the ZIP, verifies CRC, extracts the exact ZIP to a fresh directory, checks every checksum and all build identities, then runs Linux CLI/checkpoint/desktop API smoke tests. Linux execution does not validate the Windows executables. The external identity JSON holds the ZIP's own SHA-256; it cannot be embedded into that same ZIP.

Convergence reproduction: `python3 source/tools/research54.py /path/to/unchanged-5.3-mwcli build/linux/mwcli fresh-output-directory`. Fixed plan and every raw record are retained. Performance and study runners under validation/5.4 retain exact parameters. Adjust the baseline binary path in those runners to your extracted 5.3 folder. Use the same compiler, resource settings and idle machine for timing comparisons.
