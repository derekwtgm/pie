# Convergence — EightMax 5.4

Final build `980f82b97a922d4d`. Fixed plan: three small exact games, ten paired training seeds (901–910), seven arms, three deal budgets (4,000 / 20,000 / 100,000) and a separately started 0.1-second training budget. 564 measured checkpoints. One training thread, one evaluation thread, 128 MiB in each arm. Single-deal batches are held equal.

The baseline arm trains with the unchanged 5.3 Linux binary. All arms are evaluated with the same separate 5.4 exact evaluator, whose results are checked against the old loop and independent references. Exact evaluations need no sampling streams or evaluation confidence intervals. Across-seed intervals concern training variation and remain approximate.

72 contrasts were declared before execution; 48 were completed. The 24 ICM contrasts are not completed; no ICM comparative conclusion is drawn. Observed exact ICM evaluation cost was 64–71 seconds per checkpoint, making the remaining matrix several hours long. The full original multiplicity penalty is retained. See convergence/INTERRUPTION.md. Two-sided paired Student-t intervals use Bonferroni over that entire family. No result-dependent stopping or favorable-seed selection. No default was promoted.

| Game | Arm | Comparison | Budget | Baseline NashConv | Candidate NashConv | Difference CI (simultaneous 95%) | Verdict |
|---|---|---|---:|---:|---:|---|---|
| hu-river | default54 | deals | 4000 | 0.918956 | 0.918956 | [0, 0] | unresolved |
| hu-river | default54 | deals | 20000 | 0.326275 | 0.326275 | [0, 0] | unresolved |
| hu-river | default54 | deals | 100000 | 0.140849 | 0.140849 | [0, 0] | unresolved |
| hu-river | default54 | time | 0.1 | 0.151809 | 0.144273 | [-0.0405822, 0.0255101] | unresolved |
| hu-river | terminal-baseline | deals | 4000 | 0.918956 | 0.641581 | [-1.01186, 0.457106] | unresolved |
| hu-river | terminal-baseline | deals | 20000 | 0.326275 | 0.260578 | [-0.219002, 0.0876085] | unresolved |
| hu-river | terminal-baseline | deals | 100000 | 0.140849 | 0.130205 | [-0.101846, 0.0805572] | unresolved |
| hu-river | terminal-baseline | time | 0.1 | 0.151809 | 0.153554 | [-0.0724672, 0.0759567] | unresolved |
| hu-river | dcfr | deals | 4000 | 0.918956 | 1.00555 | [-0.686118, 0.859308] | unresolved |
| hu-river | dcfr | deals | 20000 | 0.326275 | 0.483232 | [0.0156275, 0.298287] | worse |
| hu-river | dcfr | deals | 100000 | 0.140849 | 0.233531 | [0.0217297, 0.163634] | worse |
| hu-river | dcfr | time | 0.1 | 0.151809 | 0.278772 | [0.0752324, 0.178692] | worse |
| hu-river | dcfr-average3 | deals | 4000 | 0.918956 | 1.01829 | [-0.672807, 0.871475] | unresolved |
| hu-river | dcfr-average3 | deals | 20000 | 0.326275 | 0.487932 | [0.0176796, 0.305635] | worse |
| hu-river | dcfr-average3 | deals | 100000 | 0.140849 | 0.238334 | [0.025852, 0.169117] | worse |
| hu-river | dcfr-average3 | time | 0.1 | 0.151809 | 0.284939 | [0.0744015, 0.191858] | worse |
| hu-river | cfr-plus | deals | 4000 | 0.918956 | 1.41871 | [-0.294357, 1.29387] | unresolved |
| hu-river | cfr-plus | deals | 20000 | 0.326275 | 0.719282 | [0.291405, 0.494609] | worse |
| hu-river | cfr-plus | deals | 100000 | 0.140849 | 0.358715 | [0.150465, 0.285265] | worse |
| hu-river | cfr-plus | time | 0.1 | 0.151809 | 0.415166 | [0.199832, 0.326882] | worse |
| hu-river | uniform | deals | 4000 | 0.918956 | 0.708946 | [-0.940542, 0.520522] | unresolved |
| hu-river | uniform | deals | 20000 | 0.326275 | 0.315553 | [-0.161641, 0.140198] | unresolved |
| hu-river | uniform | deals | 100000 | 0.140849 | 0.13422 | [-0.08125, 0.0679909] | unresolved |
| hu-river | uniform | time | 0.1 | 0.151809 | 0.141322 | [-0.0897152, 0.0687402] | unresolved |
| river3-chip | default54 | deals | 4000 | 0.349372 | 0.349372 | [0, 0] | unresolved |
| river3-chip | default54 | deals | 20000 | 0.163785 | 0.163785 | [0, 0] | unresolved |
| river3-chip | default54 | deals | 100000 | 0.0686896 | 0.0686896 | [0, 0] | unresolved |
| river3-chip | default54 | time | 0.1 | 0.0872198 | 0.0913869 | [-0.0257506, 0.0340848] | unresolved |
| river3-chip | terminal-baseline | deals | 4000 | 0.349372 | 0.323088 | [-0.137211, 0.0846442] | unresolved |
| river3-chip | terminal-baseline | deals | 20000 | 0.163785 | 0.134779 | [-0.111579, 0.053567] | unresolved |
| river3-chip | terminal-baseline | deals | 100000 | 0.0686896 | 0.0469273 | [-0.060749, 0.0172243] | unresolved |
| river3-chip | terminal-baseline | time | 0.1 | 0.0872198 | 0.086456 | [-0.0335183, 0.0319907] | unresolved |
| river3-chip | dcfr | deals | 4000 | 0.349372 | 0.721337 | [0.205272, 0.53866] | worse |
| river3-chip | dcfr | deals | 20000 | 0.163785 | 0.301385 | [0.0313835, 0.243815] | worse |
| river3-chip | dcfr | deals | 100000 | 0.0686896 | 0.14483 | [0.0430943, 0.109186] | worse |
| river3-chip | dcfr | time | 0.1 | 0.0872198 | 0.22657 | [0.103015, 0.175684] | worse |
| river3-chip | dcfr-average3 | deals | 4000 | 0.349372 | 0.713697 | [0.178662, 0.549987] | worse |
| river3-chip | dcfr-average3 | deals | 20000 | 0.163785 | 0.297013 | [0.0334734, 0.232982] | worse |
| river3-chip | dcfr-average3 | deals | 100000 | 0.0686896 | 0.142187 | [0.0401892, 0.106805] | worse |
| river3-chip | dcfr-average3 | time | 0.1 | 0.0872198 | 0.218992 | [0.0880122, 0.175531] | worse |
| river3-chip | cfr-plus | deals | 4000 | 0.349372 | 1.07184 | [0.562862, 0.882075] | worse |
| river3-chip | cfr-plus | deals | 20000 | 0.163785 | 0.503135 | [0.23171, 0.446989] | worse |
| river3-chip | cfr-plus | deals | 100000 | 0.0686896 | 0.242432 | [0.141827, 0.205658] | worse |
| river3-chip | cfr-plus | time | 0.1 | 0.0872198 | 0.415122 | [-0.0162881, 0.672092] | unresolved |
| river3-chip | uniform | deals | 4000 | 0.349372 | 0.513858 | [-0.0205456, 0.349518] | unresolved |
| river3-chip | uniform | deals | 20000 | 0.163785 | 0.178323 | [-0.0735469, 0.102622] | unresolved |
| river3-chip | uniform | deals | 100000 | 0.0686896 | 0.064148 | [-0.0342009, 0.0251175] | unresolved |
| river3-chip | uniform | time | 0.1 | 0.0872198 | 0.115232 | [-0.0273315, 0.0833563] | unresolved |

## Cost interpretation

Equal-time runs use the engine cancellation timer, so observed time may slightly overrun the target and includes OS scheduling noise. CPU seconds, setup, training-process wall time, cumulative evaluation time, total measured workflow time and peak RSS are separately retained. CPU/RSS columns measure training and evaluation child processes; Python/Node orchestration CPU and memory are excluded, although setup wall time is included. Research orchestration and additional checkpoint-copy/plotting overhead are excluded from per-row totals; the full stage wall time is recorded separately. Equal CPU time and equal total workflow time are not independently enforced experiment arms. Do not describe them as such. GPU memory is null because no physical GPU was measured.

The default/current states are byte-identical in 60/60 equal-deal pairs. The optimization concerns evaluation work, not a different trained policy. In heads-up chip EV, exploitability is half the displayed NashConv. Multiplayer and ICM NashConv is a sum of unilateral gains, not two-player exploitability.

Raw: `validation/5.4/convergence/plan.json`, `raw.jsonl`, `summary.json`, and per-budget checkpoint files. Reference full-width CFR/CFR+/linear/DCFR results are separate in `validation/5.4/reference/fullwidth.json`; their timings ran alongside validation and are not performance claims.
