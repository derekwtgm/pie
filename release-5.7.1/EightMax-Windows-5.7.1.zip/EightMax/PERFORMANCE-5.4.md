# Performance — EightMax 5.4

Measured on AMD EPYC 9V74 80-Core Processor, Linux, 9 visible logical CPUs. These are not i7/RTX 4060 Ti measurements.

## Complete response-evaluation requests

The exact ICM timing matrix was omitted after the convergence feasibility review; the four remaining workloads are reported in full. The same trained checkpoint and request are evaluated by the 5.3 binary, 5.4 binary and 5.4 cache-disabled control. Arm order rotates over five rounds. Includes process startup, checkpoint restore, evaluation and output. All exact gains must remain bit-identical. The listed ratio intervals from the inherited benchmark are pointwise 95%, not corrected across the whole matrix; interpret them as workload-specific measurements.

| Threads | Game | 5.3 median s | 5.4 median s | Time ratio | Pointwise 95% ratio interval | Peak 5.3/5.4 MiB | Same exact result |
|---:|---|---:|---:|---:|---|---|---|
| 1 | hu-river | 0.0048 | 0.0040 | 0.979 | [0.744, 1.289] | 3.1640625/3.140625 | True |
| 1 | hu-turn | 0.0043 | 0.0044 | 0.942 | [0.662, 1.340] | 3.2734375/3.28125 | True |
| 1 | river3-chip | 0.0045 | 0.0045 | 0.988 | [0.821, 1.188] | 3.1484375/3.1953125 | True |
| 1 | flop6 | 1.8044 | 1.8725 | 1.023 | [0.986, 1.061] | 4.7734375/4.765625 | True |
| 2 | hu-river | 0.0045 | 0.0049 | 1.101 | [0.978, 1.238] | 3.1640625/3.16015625 | True |
| 2 | hu-turn | 0.0048 | 0.0044 | 0.898 | [0.752, 1.072] | 3.28515625/3.33984375 | True |
| 2 | river3-chip | 0.0043 | 0.0043 | 0.993 | [0.904, 1.090] | 3.15234375/3.16015625 | True |
| 2 | flop6 | 0.9690 | 0.9968 | 0.968 | [0.765, 1.224] | 6.41796875/6.46484375 | True |
| 4 | hu-river | 0.0046 | 0.0046 | 0.961 | [0.646, 1.431] | 3.16796875/3.14453125 | True |
| 4 | hu-turn | 0.0046 | 0.0051 | 0.963 | [0.824, 1.126] | 3.22265625/3.28515625 | True |
| 4 | river3-chip | 0.0041 | 0.0042 | 0.982 | [0.777, 1.241] | 3.16015625/3.16015625 | True |
| 4 | flop6 | 0.6740 | 0.6527 | 0.999 | [0.940, 1.061] | 9.66015625/9.65625 | True |
| 8 | hu-river | 0.0033 | 0.0033 | 0.938 | [0.812, 1.082] | 3.1484375/3.21484375 | True |
| 8 | hu-turn | 0.0045 | 0.0045 | 1.042 | [0.897, 1.209] | 3.34765625/3.30078125 | True |
| 8 | river3-chip | 0.0041 | 0.0040 | 0.938 | [0.879, 1.002] | 3.1484375/3.09765625 | True |
| 8 | flop6 | 0.4169 | 0.4487 | 1.086 | [0.986, 1.196] | 12.83203125/12.89453125 | True |

## Complete study workflows

Five paired rounds per fixture include setup, training, action evaluation, quality evaluation and saving the result. Known A-K-Q and the three-player companion use exact evaluation. The six-player and ICM companions use identical fixed sampled evaluators in both binaries (4,000 action and 1,000 restricted-response quality samples), after an all-exact attempt was interrupted for runtime feasibility. See performance/PROTOCOL-NOTE.md; this benchmark was adjusted for resource cost and is not claimed to be fully preregistered. Numeric measurements and completion statuses must match. Ratio intervals below are Bonferroni-adjusted over four fixtures.

| Fixture / evaluation | 5.3 median s | 5.4 median s | Geometric time ratio | Simultaneous 95% interval | Identical measurements |
|---|---:|---:|---:|---|---|
| known-akq-river / exact | 0.0329 | 0.0338 | 1.026 | [0.898, 1.173] | True |
| flop3-kings-small / exact | 1.9990 | 1.9638 | 1.002 | [0.911, 1.101] | True |
| flop6-jack-small / sampled | 4.7671 | 4.8076 | 1.015 | [0.904, 1.138] | True |
| icm8-bb-call-small / sampled | 0.1230 | 0.1205 | 0.969 | [0.945, 0.994] | True |

No universal speedup is asserted. Small heads-up requests can pay cache overhead without reuse, while multiway nodes can reuse many policies. Negative and inconclusive timing results remain included. Training is unchanged in implementation; no training-throughput improvement is established. The sampled ICM complete-study ratio corresponds to 3.1% less elapsed time (family-adjusted 95% interval: about 0.6–5.5% less). This small host-specific result is not attributed specifically to the exact-policy cache, which is not used by that sampled path. Other complete-workflow comparisons are inconclusive. Peak RSS and wall latency are separate quantities. No physical GPU timing or VRAM use was measured. Raw per-round results and reproduction commands are in `validation/5.4/performance/`.
