# Accuracy report — EightMax 5.4

Build `980f82b97a922d4d`. This release adds study controls and an evaluated exact-response optimization; it does not claim a new universal GTO accuracy level.

## Independent mathematical checks

28 independent reference checks passed, 0 failed. These cover known Kuhn values, Leduc, weighted small games, exact responses, counterfactual regrets, strategy averaging, 20,000 side-pot showdowns and 2,000 ICM/bust cases. The full regression also compares native multi-street best responses against separate Python betting, ranking, chance and pot implementations. These independent implementations share no native payoff/evaluation code.

The default/current equal-deal states agree in 60/60 pairs. Exact quality is inside the chosen abstraction. A low sampled one-decision response gain is not full-game exploitability, and cannot certify equilibrium.

## Practical studies

These nine fresh runs use three seeds, budgets 10,000 and 100,000 deals, CPU-only mode, two threads, 256 MiB engine budgets, 4,000 action samples, 1,000 quality samples where sampled, and a 180-second cap. They are small, transparent replication studies, not a claim that the longer Deep preset has converged. Changes in budget/settings prevent direct quality comparisons to the old 5.3 representative runs.

| Fixture | Budget | Completed/requested | Ranking | Tolerance met |
|---|---:|---|---|---|
| known-akq-river | 10000 | 3/3 | unresolved | False |
| known-akq-river | 100000 | 3/3 | unresolved | False |
| btn25-open-small | 10000 | 3/3 | unresolved | False |
| btn25-open-small | 100000 | 3/3 | unresolved | False |
| flop3-kings-small | 10000 | 3/3 | unresolved | False |
| flop3-kings-small | 100000 | 3/3 | unresolved | False |
| flop6-jack-small | 10000 | 3/3 | unresolved | False |
| flop6-jack-small | 100000 | 3/3 | unresolved | False |
| icm8-bb-call-small | 10000 | 2/3 | incomplete | False |
| icm8-bb-call-small | 100000 | 2/3 | incomplete | False |
| btn25-open | 10000 | 3/3 | unresolved | False |
| btn25-open | 100000 | 2/3 | incomplete | False |
| flop3-kings | 10000 | 3/3 | unresolved | False |
| flop3-kings | 100000 | 3/3 | unresolved | False |
| flop6-jack | 10000 | 3/3 | unresolved | False |
| flop6-jack | 100000 | 3/3 | unresolved | False |
| icm8-bb-call | 10000 | 3/3 | unresolved | False |
| icm8-bb-call | 100000 | 3/3 | unresolved | False |

## Statistical checks

3000 trials in each of 13 predeclared synthetic scenarios; 21 independent SciPy quantile checks passed. Per-scenario coverage, false-ranking counts and Wilson intervals are in statistics/coverage.json. Errors use known covariance/standard errors; this is not a validation of all poker-estimated SEs.

Rare-tail conditional coverage was 86.5667% (2597/3000), Wilson 95% [85.2995%, 87.7403%]. This failed the nominal 95% calibration target. The full calibration flag is false and the result is retained. The baseline interval formula is preserved, not silently relabeled as distribution-free. No narrower replacement is promoted.

## Interpretation

Candidates can win individual small-game comparisons without being robust across games, budgets and timing constraints. CONVERGENCE-5.4.md retains every corrected result. No default change or overall percentage closer-to-GTO claim is justified by this release. Larger linked-street weighted-range tournament equilibrium quality remains an open problem.
