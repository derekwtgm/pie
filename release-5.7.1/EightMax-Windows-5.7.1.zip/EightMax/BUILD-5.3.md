# Building and validating EightMax 5.3

The delivered Windows x64 programs were cross-compiled from final source build `55c4fffde6deb9a1` on Linux using MinGW-w64 POSIX GCC 14.2.0. Linux builds used Debian GCC/G++ 14.2.0. See `validation/5.3/build-logs/` for compiler output and executable identity checks. These are cross-build results, not Windows runtime validation. No external Python or Node installation is needed to run the Windows executables.

## Build from the complete release source

Build dependencies: Node 24, Python 3, a C++20 GCC/G++ toolchain, zlib development headers/library, and OpenSSL development libraries for the Linux desktop host. A Windows cross-build requires the x86_64 MinGW-w64 POSIX compiler, winpthreads, and MinGW static zlib. On Windows, the supplied workflow uses MSYS2 UCRT64 GCC and zlib; that workflow was not executed for this release.

Run from the extracted EightMax directory:

```sh
node source/tools/build.js build
sh source/native/build.sh linux "$PWD/build/native.html" "$PWD/build/linux"
CC=x86_64-w64-mingw32-gcc-posix CXX=x86_64-w64-mingw32-g++-posix sh source/native/build.sh windows "$PWD/build/native.html" "$PWD/build/windows"
```

For a native MSYS2 build on Windows, use `CC=gcc CXX=g++` with the Windows command. Keep `build-info.json` beside `native.html`. The builder refuses a UI/source fingerprint mismatch. Compiler and linker flags are in `source/native/build.sh`; native multiway code uses `-ffp-contract=off` and no fast-math. The Windows programs link the language runtime and zlib statically; Windows system DLLs remain normal dependencies. They are not code-signed.

## Regression and sanitizer validation

```sh
ASAN_OPTIONS=detect_leaks=0 EM_TEST_HOST="$PWD/build/linux/eightmax" EM_TEST_MWCLI="$PWD/build/linux/mwcli" node source/tools/run_tests.js regression.json --limit=900
```

On a tracing-restricted host only, two older tests force leak detection back on. The validation adapter below changes only `detect_leaks=1` to `detect_leaks=0` in their child process environment:

```sh
NODE_OPTIONS="--require=$PWD/validation/5.3/sanitizers/no-leaks.cjs" ASAN_OPTIONS=detect_leaks=0 EM_TEST_HOST="$PWD/build/linux/eightmax" EM_TEST_MWCLI="$PWD/build/linux/mwcli" node source/tools/run_tests.js regression-no-leaks.json --limit=900
bash validation/5.3/sanitizers/build-final.sh source build sanitized
ASAN_OPTIONS=detect_leaks=0 EM_TEST_HOST="$PWD/sanitized/eightmax" EM_TEST_MWCLI="$PWD/sanitized/mwcli" node --test source/tests/v53.test.js
```

Do not describe a run with leak detection disabled as a leak check. `validation/5.3/sanitizers/` retains the failures with leaks enabled and successful available checks. Vendored QuickJS uses AddressSanitizer only; changed application paths use address, undefined-behaviour and float-cast-overflow instrumentation. Sanitizer builds are validation artifacts; the shipped Windows binaries are optimized release builds.

The independent statistics runner requires NumPy and SciPy. Its native adapter can be built with:

```sh
gcc -O2 -c source/native/json.c -o json.o
g++ -std=c++20 -O2 -ffunction-sections -fdata-sections -Wl,--gc-sections -Isource/native source/tests/study53_probe.cpp json.o -o study53-probe
python3 source/tools/statistical_validation53.py ./study53-probe statistics.json --trials 3000
```

The browser check is `source/tools/study_ui53.js`; it requires Playwright/Chromium. The DOM fallback at `validation/5.3/ui/check-dom.cjs` requires jsdom 31.0.1 and is explicitly not a graphical browser or Windows test. Its invocation is `node validation/5.3/ui/check-dom.cjs . /absolute/path/to/jsdom`.

## Package and check the exact archive

Copy `build/windows/{EightMax.exe,mwcli.exe,gpustress.exe}`, `build/EightMax-Offline.html` and `build/build-info.json` (renamed `BUILD-INFO.json`) into the release root. Retain source, studies, validation, root documentation and `.github`. Keep build logs in a directory named `build-logs`, because transient `build` directories are excluded.

```sh
node source/tools/verify_build.js .
python3 source/tools/release53.py . output
```

The release tool generates `SHA256SUMS.txt`, creates one ZIP, hashes it, extracts that exact ZIP into a new empty directory, verifies every manifest entry and build identifier, and runs available smoke checks. On Linux without Wine, it uses the included `validation/5.3/linux-bin` programs and labels the results as Linux. It does not claim that this executes the Windows binaries. The external `.identity.json` identifies the canonical archive; a ZIP cannot contain its own final SHA-256.
