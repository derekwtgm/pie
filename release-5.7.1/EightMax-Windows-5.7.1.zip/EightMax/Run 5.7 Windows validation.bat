@echo off
setlocal
cd /d "%~dp0"
echo EightMax 5.7 validation on this Windows PC. Nothing is installed. This takes 10 to 40 minutes.
echo Reports are written into this folder:
echo   Windows-selftest-5.7.json      checks made by mwcli.exe itself (no PowerShell needed)
echo   Windows-validation-5.7.json    every check, with its status: passed, failed, skipped or untested
echo   Windows-validation-5.7.txt     the same as text
echo.
echo Step 1 of 2: mwcli.exe --selftest57
set "em_st=%TEMP%\EightMax-5.7-selftest-%RANDOM%%RANDOM%"
mwcli.exe --selftest57 "validation\5.7\fixtures" "%em_st%"
set "selftest_result=%errorlevel%"
if exist "%em_st%\selftest57.json" copy /y "%em_st%\selftest57.json" "Windows-selftest-5.7.json" >nul
if exist "%em_st%" rmdir /s /q "%em_st%"
if "%selftest_result%"=="0" (echo Self-test: every check passed.) else (echo Self-test: exit status %selftest_result%. See Windows-selftest-5.7.json.)
echo.
echo Step 2 of 2: the validation script
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows57.ps1" %*
set "eightmax_result=%errorlevel%"
echo.
if "%eightmax_result%"=="0" echo Every required check passed. Skipped checks, if any, are listed above with their reason.
if "%eightmax_result%"=="1" echo At least one required check failed or could not be made. Please keep the three report files.
if not "%eightmax_result%"=="0" if not "%eightmax_result%"=="1" echo The validation script itself did not finish ^(exit status %eightmax_result%^). It has never been run on Windows before this release; please keep the report files and the text above. The self-test result of step 1 stands on its own.
if not "%selftest_result%"=="0" if "%eightmax_result%"=="0" set "eightmax_result=1"
pause
exit /b %eightmax_result%
