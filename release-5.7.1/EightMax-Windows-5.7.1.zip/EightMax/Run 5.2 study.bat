@echo off
rem EightMax 5.2: run a decision study from the command line (no PowerShell needed).
rem   "Run 5.2 study.bat"                      the known small game (a few seconds)
rem   "Run 5.2 study.bat" flop6-jack           any fixture in the studies folder
rem   "Run 5.2 study.bat" flop6-jack seeds=2   extra options are passed to mwcli --study
rem Writes study-results\<fixture>.result.json (open it in the Study tab with "Open result file").
cd /d "%~dp0"
set "eightmax_fixture=%~1"
if "%eightmax_fixture%"=="" set "eightmax_fixture=known-akq-river"
if not exist "%~dp0studies\%eightmax_fixture%.emfix.json" (echo No fixture named %eightmax_fixture% in the studies folder. & dir /b "%~dp0studies\*.emfix.json" & if /i not "%~2"=="/nopause" pause & exit /b 2)
if not exist "%~dp0study-results" mkdir "%~dp0study-results"
"%~dp0mwcli.exe" --study "%~dp0studies\%eightmax_fixture%.emfix.json" "%~dp0study-results\%eightmax_fixture%.result.json" %2 %3 %4 %5 %6
set "eightmax_52_result=%errorlevel%"
echo.
if "%eightmax_52_result%"=="0" (echo Result: study-results\%eightmax_fixture%.result.json) else (echo The study failed. The message above says why.)
pause
exit /b %eightmax_52_result%
