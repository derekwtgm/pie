@echo off
cd /d "%~dp0"
rem Nine independent trainings: enough for this fixture to be judged across trainings (see USER-GUIDE-5.7.md).
mwcli.exe --study studies\known-akq-river.emfix.json EightMax-5.7-replicated-study.json preset=standard seeds=9 processingMode=auto
pause
