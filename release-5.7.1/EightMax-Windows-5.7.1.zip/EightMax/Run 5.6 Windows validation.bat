@echo off
cd /d "%~dp0"
echo EightMax 5.6 validation on this Windows PC. Nothing is installed. This takes 10 to 40 minutes.
echo A report is written to Windows-validation-5.6.json and Windows-validation-5.6.txt in this folder.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "source\tools\validate_windows56.ps1" %*
set "eightmax_result=%errorlevel%"
echo.
if "%eightmax_result%"=="0" (echo Every check passed.) else (echo At least one check failed. Please keep Windows-validation-5.6.json and Windows-validation-5.6.txt.)
pause
exit /b %eightmax_result%
