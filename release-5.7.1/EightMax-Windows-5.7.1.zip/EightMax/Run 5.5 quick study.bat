@echo off
cd /d "%~dp0"
mwcli.exe --study studies\known-akq-river.emfix.json EightMax-5.5-quick-study.json preset=quick processingMode=auto
pause
