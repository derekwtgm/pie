# EightMax Windows 5.4 — completion report

Build `980f82b97a922d4d`. This is a rebuilt, packaged incremental release, with complete source and raw evidence. It does not implement every research direction in the original master prompt. The unchanged 5.3 default trainer remains the default.

1. **Implemented:** bounded policy reuse in exact best-response evaluation; explicit largest unilateral gain; Quick/Standard/Deep/Research study presets; evaluation, time, memory, seed, thread and processing controls; richer training progress and export diagnostics. Repaired the desktop's fixed-size progress buffer so larger JSON snapshots remain valid and cancellation works.
2. **Algorithms:** the training algorithm itself is unchanged. Controlled experiments compare existing terminal-baseline, DCFR, CFR+, uniform-weighting configurations and DCFR average exponent gamma=3 against unchanged 5.3 and 5.4 defaults. Full-width reference CFR variants are also exercised independently. No new learned variance-reduction estimator is claimed.
3. **Independent mathematical evidence:** 28 independent reference checks; separate Python/native response comparisons in the regression suite; 564 exact checkpoint evaluations in total: 560 in two completed small games with ten paired seeds, and four retained records from an incomplete ICM comparison. Exact exploitability is NashConv / 2 for heads-up chip EV; multiplayer NashConv sums unilateral gains. A restricted sampled response gain is never a full-game equilibrium certificate.
4. **Candidate outcomes:** {'unresolved': 28, 'worse': 20} among 48 completed comparisons, Bonferroni-adjusted over the original 72-contrast family; another 24 ICM comparisons were not completed. Every result, including unfavorable and inconclusive results, is retained. No candidate showed a statistically supported improvement.
5. **Efficiency:** complete response requests and complete studies were measured against the 5.3 binary on the same Linux host. The table below reports complete-study timing; a ratio below 1 means less elapsed time. This is not target-i7 or physical RTX performance. Setup, evaluation time, total workflow time and peak RAM are retained separately. Equal CPU-time and equal complete-workflow-time arms were not independently enforced.
6. **Closer to equilibrium:** the unchanged defaults produced identical checkpoints in 60/60 equal-deal pairs. Thus no default strategy-quality improvement at equal deals is demonstrated. See all equal-time and equal-deal candidate comparisons in CONVERGENCE-5.4.md. No overall percentage closer to GTO is supported.
7. **Tests:** 552 distinct regression checks passed after one isolated final-source timing rerun; 0 remain failed and 0 were skipped. The original full run had 551 passes and 1 failure. The CPU-load timing failure and all earlier development failures remain in the logs. Sanitizers: 22 passed; DOM/event/export checks: 4304 assertions; fresh 5.3 checkpoint continuation: 24 byte-identical checks. Statistical evidence includes 39,000 trials and 21 quantile checks, but is not an all-pass calibration result.
8. **Outstanding validation:** native Windows/UI execution, physical NVIDIA execution/VRAM/timing, target-PC performance and leak checking. Rare-tail conditional confidence coverage was 86.57%, Wilson 95% [85.30%, 87.74%], below nominal coverage. The result is retained and disclosed; the formula is not relabeled as distribution-free. Nine fresh practical studies completed 15/18 declared seed/budget groups; 0/18 met their fixture tolerances. Completion and tolerance are separate outcomes.
9. **Compatibility:** rebuilt Windows x64 executables, source and interface share the build fingerprint. Legacy raw/EMZ1 checkpoints and 5.1/5.2/5.3 continuation paths are preserved and tested on Linux. Windows runtime compatibility itself remains unverified. Existing saved-study readers, exports, chip EV, ICM, weighted ranges, side pots, linked streets, tournament defaults and four processing modes remain supported. Study partial results are not automatic resumable training checkpoints.
10. **Priorities for 5.5:** strengthen rare-tail uncertainty with defensible bounded or anytime-valid procedures; add automatic study checkpoint/resume; run larger predeclared convergence studies with CPU/total-workflow cost matching; validate the actual Windows/RTX 4060 Ti path before making target-machine performance claims.

## Candidate comparison counts

Counts combine the predeclared games, budgets and cost conditions; they are not a probability that an algorithm is better in a new game.

| Candidate | Supported better | Supported worse | Unresolved |
|---|---:|---:|---:|
| default54 | 0 | 0 | 8 |
| terminal-baseline | 0 | 0 | 8 |
| dcfr | 0 | 7 | 1 |
| dcfr-average3 | 0 | 7 | 1 |
| cfr-plus | 0 | 6 | 2 |
| uniform | 0 | 0 | 8 |

## Complete-study timing

| Fixture | 5.3 median seconds | 5.4 median seconds | Geometric time ratio | Family-adjusted 95% ratio interval |
|---|---:|---:|---:|---|
| known-akq-river / exact | 0.033 | 0.034 | 1.026 | [0.898, 1.173] |
| flop3-kings-small / exact | 1.999 | 1.964 | 1.002 | [0.911, 1.101] |
| flop6-jack-small / sampled | 4.767 | 4.808 | 1.015 | [0.904, 1.138] |
| icm8-bb-call-small / sampled | 0.123 | 0.121 | 0.969 | [0.945, 0.994] |

## Not implemented

Selectable confidence levels; a new sequential/adaptive evaluation procedure; automatic study checkpoint intervals/resumption; new CUDA kernels; new chance-sampling or learned baseline algorithms; global process-memory enforcement; continuous evaluation percentages/ETA; new NUMA/work-stealing/external-memory scheduling. Fresh multi-seed native full-traversal/grouped-hand convergence comparisons beyond the selected plan were not completed. Existing paths retain regression coverage. See validation/5.4/NOT-IMPLEMENTED.md.

## Included evidence

RELEASE-5.4.md, ACCURACY-REPORT-5.4.md, CONVERGENCE-5.4.md, PERFORMANCE-5.4.md, VALIDATION-5.4.md and BUILD-5.4.md contain detailed interpretation and reproduction steps. Raw JSON/JSONL/CSV, test logs, checkpoint files and a convergence plot are under validation/5.4. The external identity JSON records verification of the exact final ZIP after extraction, including its SHA-256.
