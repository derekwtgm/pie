'use strict';
// 0.29.0: ROOT CAUSE of the target PC's HTTP 400 on the very first desktop request (0.26.0), observed on a real Windows runner:
//   HTTP 400 {"error":"Method not found: 'System.String[] System.String.Split(Char, System.StringSplitOptions)'"}
// The host was compiled with Mono against MONO's class library, where text.Split(' ') binds to Split(char, StringSplitOptions =
// None). .NET Framework 4.8 has no such overload, so request parsing threw MissingMethodException and every request (health,
// shutdown...) became HTTP 400. 0.26, 0.27 and 0.28 binaries all contain the call. Fix: compile against the .NET Framework 4.8
// reference assemblies, which turns any API that Windows lacks into a compile error.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process');
const root = path.join(__dirname, '..');
const has = (c, a = ['--version']) => { try { cp.execFileSync(c, a, { stdio: 'pipe' }); return true; } catch (e) { return false; } };
const skip = has('which', ['monodis']) ? false : 'monodis (Mono) not installed';
for (const exe of ['desktop/bin/EightMaxWorkbench.exe', 'desktop/bin/EightMaxCapture.exe']) {
  test(exe + ' references no String.Split overload that .NET Framework 4.8 lacks', { skip }, () => {
    let il = ''; try { il = cp.execFileSync('monodis', [path.join(root, exe)], { encoding: 'utf8', maxBuffer: 64 << 20, stdio: ['ignore', 'pipe', 'ignore'] }); } catch (e) { il = e.stdout || ''; }
    assert.ok(il.length > 10000, 'disassembly produced');
    assert.doesNotMatch(il, /string::Split\(char, valuetype/, 'Split(char, StringSplitOptions) does not exist on .NET Framework');
    assert.doesNotMatch(il, /string::Split\(string, valuetype/, 'Split(string, StringSplitOptions) does not exist on .NET Framework');
    assert.doesNotMatch(il, /string::Contains\(char\)|string::StartsWith\(char\)|string::EndsWith\(char\)/, '.NET Core-only string overloads');
  });
}
test('the build and the component manifest state that executables are compiled against the .NET Framework 4.8 reference assemblies', () => {
  const comp = JSON.parse(fs.readFileSync(path.join(root, 'desktop/COMPONENT-VERSIONS.json'), 'utf8'));
  assert.match(comp.components['desktop/DesktopHost.cs'].compiler, /4\.8 REFERENCE assemblies/);
  assert.match(fs.readFileSync(path.join(root, 'tests/windows-025.test.cjs'), 'utf8'), /4\.8-api/);
});
