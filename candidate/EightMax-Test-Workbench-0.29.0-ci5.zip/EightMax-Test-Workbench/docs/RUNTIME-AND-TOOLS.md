# Bundled runtime and tools (0.27)

Ordinary use needs nothing installed: `START-DESKTOP.cmd` (host, prebuilt) or `START.html` (any current browser), as in 0.25/0.26.

The development / QA tools (`tools\*.cjs`: strategy training, coverage scenario, benchmarks, replay, recognition reports) are Node.js programs. 0.27 bundles the **official, unmodified Node.js v22.23.5 win-x64** (`runtime\node\node.exe`, licence beside it, provenance and the zip's SHA-256 in `runtime\node\PROVENANCE.json`; the SHA-256 was compared with nodejs.org's `SHASUMS256.txt`). Run any tool with:

    RUN-TOOL.cmd tools\full-hand-scenario.cjs --hands=20 --seed=2024 --out=reports\my-scenario.json

`RUN-TOOL.cmd` points `EIGHTMAX_TEST_CLI` at the bundled `native\mwcli.exe` unless you set it. **Not verified on Windows**: neither the bundled node.exe nor the launcher was executed (the build machine was Linux). FFmpeg (video replay) is still **not** bundled: the two usual Windows build sites were not reachable from the build machine, and the Windows builds available elsewhere are GPL-licensed, which brings source-distribution obligations that this release did not take on. Put `ffmpeg.exe` on PATH or give its path to the replay tool (docs/VIDEO-REPLAY.md).

The Windows Graphics Capture helper is self-contained (.NET 8 runtime inside the file); the host and capture tool need the .NET Framework 4.x that ships with Windows 10/11.
