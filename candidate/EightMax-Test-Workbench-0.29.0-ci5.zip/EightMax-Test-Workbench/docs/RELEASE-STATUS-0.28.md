# Release status 0.28.0 — what was verified, and how

Build environment: Ubuntu 24.04 container (Linux 6.18, 4 vCPU Xeon @ 2.1 GHz, 15.7 GiB RAM, no GPU), Node.js 22, Mono 6.8.0.105,
.NET SDK 8.0.134, PowerShell 7.4.6, Xvfb + openbox, Playwright Chromium. **No Windows machine was available.** Wine was tried as an
extra execution check and crashed at start-up in this container, so no Windows binary was executed at all.

Verification levels, strongest first: **Validated on target hardware** › **Executed on Windows** › **Integration-tested** (real code,
real runtime, Linux) › **Unit-tested** › **Compiled** / **Cross-compiled** › **Source reviewed**.

| Component | Strongest level reached in 0.28.0 | Not done |
|---|---|---|
| Capture self-test (EightMaxCapture.cs) | Cross-compiled (Mono, C# 5); **integration-tested**: the real self-test flow ran on Mono WinForms/X11 with a test double for the Win32 capture calls — all 8 stages pass, closed window → `target-lost`, exit 0; injected fault → exit 4 with the stage named | PrintWindow/BitBlt on Windows; other DPI settings |
| Test-Capture.ps1 | Integration-tested under PowerShell 7 with stub tools, including a replay of the exact 0.26 crash | Windows PowerShell 5.1 run |
| Desktop host HTTP (DesktopHost.cs) | Cross-compiled; **integration-tested**: real request reader/router against .NET `HttpWebRequest` (Mono) and raw sockets; 19 framing/validation cases | Windows PowerShell 5.1 / .NET Framework client on Windows; cause of the first-GET 400 (H1) |
| Graceful shutdown | **Integration-tested**: the real host process (Mono, headless message loop) exits by itself 0.1 s after authenticated shutdown in idle, after-error, stalled-connection and wrong-token-first scenarios; no watchdog; session file removed | Shutdown with a running native job (needs Windows job objects + mwcli.exe) |
| Test-Desktop.ps1 | Parsed (PowerShell 7); structure tested | Executed on Windows |
| Windows Graphics Capture helper | **Cross-compiled** (.NET 8 SDK, win-x64 self-contained, 41 MB); source reviewed; stub-driven acceptance script test | Executed on Windows (never) |
| Results collector | **Integration-tested** under PowerShell 7 on the real 0.26 reports (redaction, originals unchanged, ZIP layout, summary) | Desktop path / Explorer / message box on Windows |
| Release orchestrator (Test-Release.ps1) | Parsed; criterion → check mapping verified by test | Executed on Windows |
| Dashboard test-results panel | Unit-tested model; START.html rebuilt; Playwright suite passes | Real host endpoints on Windows |
| Native solver | Linux build of the bundled source: full native test set, checkpoints, cancel/resume, coverage runs. Windows: the unchanged `mwcli.exe` passed its 2,000-update self-test on the target PC (0.26 hardware check) | 0.28 Windows run |
| Ten-table scheduler | Unit/integration-tested; benchmarks on the Linux container | Target-PC measurements |
| Bundled Node.js | Official binary, checksum verified | Executed on Windows |
| Installer / rollback / uninstall | Parsed; unchanged logic except version source | Executed on Windows |

**Critical Windows acceptance criteria (brief §15): every one is NOT VERIFIED ON WINDOWS.** The repairs address the two
reproducible failures at confirmed causes; whether the first-GET HTTP 400 is gone cannot be known until RUN-RELEASE-ACCEPTANCE.cmd
runs on the target PC, which now records the exact request, route and error code if it is not.
