# Release status 0.26.0
Verified on Linux (621 tests, 0 failures, 2 skips). NOT verified on Windows. Host/capture executables remain 0.25.0 (not rebuilt). WGC is source-only. 2–7 seat vision not implemented. See docs/0.26-validation-report.md.
