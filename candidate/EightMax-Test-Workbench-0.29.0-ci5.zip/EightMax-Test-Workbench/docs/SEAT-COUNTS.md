# Two to eight seats (0.27)

The image reader and the hand-state engine used to be eight-seat only. In 0.27 both accept 2–8 seats.

* **Layouts.** `defaultLayout(n)` / `defaultLayoutV2(n)` (`src/vision-ocr.js`) generate an n-seat layout: seats on an ellipse, seat 0 always the hero position at the bottom. For 8 seats the geometry is **byte-identical to 0.26.0** (verified by SHA-256 in the tests). For 2–7 seats each seat's bet box is placed on the first free position along the seat→pot line (then shifted above/below it) so that no bet box overlaps a card, marker, banner or another box, with a six-pixel margin: a drawn rectangle inside a numeral box corrupts its digits (found and fixed while building this: 5- and 7-seat tables first failed on exactly that). `layoutConflicts(layout)` lists any overlap.
* **Profiles.** Several profiles may share the 1.6 aspect ratio, one per seat count. `ProfileSet.select(img, seats)` picks by seat count; if the seat count is not given and more than one seat count matches, the result is `ambiguous-layout` — it is never guessed.
* **State engine.** `new HandStateEngine(table, { seats: n })` accepts exactly the layouts `eightmax-<n>max-v1/v2` with `layout.seats === n`; anything else is an `unrecognized-layout` rejection. Start pot, ledger, action seats and button/actor ranges follow n.
* **Pipeline.** `FH.makeVision(table, widths, seats)`; `SingleTablePipeline` takes the seat count from the table.
* **Solver.** The trained studies are **8-handed**. For any other seat count the pipeline produces the explicit result `player-count-unsupported` (missing capability "strategy for n-handed tables"); in Simulation mode a labelled scripted fallback may play, in a strict run the hand is suspended. An 8-handed strategy is never adapted to another table size.
* **Dashboard.** *Seats (offline client)* selector (2–8) in the capture panel; position names for each seat count.

## What was measured (built-in renderer only)
Complete hands from pixels with 2, 3, 4, 5, 6, 7 and 8 seats: vision → state → scripted decision → execution → acknowledgement, 8 hands each in the test suite, 0 rejected frames, 0 suspended hands, 0 acknowledgement mismatches, chips conserved; every hero position at four resolutions for 6 seats. **Nothing is claimed for any external client.**

## Not implemented
Empty seats, sitting-out and departed players: every seat of a table is occupied; a table with a missing seat does not match a layout and is rejected rather than guessed. Observed-range updates for fewer players, and n-handed strategy studies.
