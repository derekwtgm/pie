# Release status 0.27.0
Verified on Linux only. NOT verified on Windows. All Windows programs were compiled from the shipped source (host and capture tool with Mono, WGC helper with the .NET 8 SDK) but none was run. WGC is manual-only. 2–8 seats work in vision/state/pipeline on the built-in renderer; strategies remain 8-handed. See docs/0.27-validation-report.md.
