// EightMax 0.28.0 - protocol harness. Runs the REAL DesktopHost.cs request reader/router (compiled with Mono) against the
// .NET HttpWebRequest client (the client Windows PowerShell 5.1 Invoke-WebRequest uses) and raw sockets.
// Prints one JSON line per case. Linux/Mono only: the Win32 parts (native jobs, UI thread, capture) are not exercised.
using System; using System.Collections.Generic; using System.IO; using System.Net; using System.Net.Sockets; using System.Reflection; using System.Text; using System.Threading;
public static class DesktopProtocolHarness {
    static string token; static int port = 48713;
    static string Esc(string s){ if(s==null) return "null"; var b=new StringBuilder("\""); foreach(char c in s){ if(c=='"'||c=='\\') b.Append('\\').Append(c); else if(c<32) b.AppendFormat("\\u{0:x4}",(int)c); else b.Append(c);} return b.Append('"').ToString(); }
    static void Emit(string name,int status,string body,double ms){ Console.WriteLine("{\"case\":"+Esc(name)+",\"status\":"+status+",\"ms\":"+((int)ms)+",\"body\":"+Esc(body)+"}"); }
    static void Web(string name,string method,string path,string body,Action<HttpWebRequest> tweak){
        var sw=System.Diagnostics.Stopwatch.StartNew();
        var req=(HttpWebRequest)WebRequest.Create("http://127.0.0.1:"+port+path); req.Method=method; req.Timeout=8000; req.Proxy=null;
        req.UserAgent="Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1"; req.Headers["X-EightMax-Session"]=token; req.Headers["X-EightMax-Step"]=name;
        if(tweak!=null) tweak(req);
        try{
            if(body!=null){ byte[] b=Encoding.UTF8.GetBytes(body); req.ContentType="application/json"; req.ContentLength=b.Length; using(var s=req.GetRequestStream()) s.Write(b,0,b.Length);} else req.ContentLength=0; // PS 5.1 sets ContentLength=0 when there is no body
            using(var r=(HttpWebResponse)req.GetResponse()) Emit(name,(int)r.StatusCode,new StreamReader(r.GetResponseStream()).ReadToEnd(),sw.Elapsed.TotalMilliseconds);
        }catch(WebException e){ var r=e.Response as HttpWebResponse; Emit(name,r==null?-1:(int)r.StatusCode,r==null?e.Status+": "+e.Message:new StreamReader(r.GetResponseStream()).ReadToEnd(),sw.Elapsed.TotalMilliseconds); }
    }
    static void Raw(string name,string request){
        var sw=System.Diagnostics.Stopwatch.StartNew();
        try{ using(var c=new TcpClient("127.0.0.1",port)){ var s=c.GetStream(); s.ReadTimeout=8000; byte[] q=Encoding.ASCII.GetBytes(request.Replace("{token}",token)); s.Write(q,0,q.Length); c.Client.Shutdown(SocketShutdown.Send);
            var ms=new MemoryStream(); var buf=new byte[8192]; int n; while((n=s.Read(buf,0,buf.Length))>0) ms.Write(buf,0,n);
            string text=Encoding.UTF8.GetString(ms.ToArray()); int status=-1; if(text.StartsWith("HTTP/1.1 ")) int.TryParse(text.Substring(9,3),out status);
            int bodyAt=text.IndexOf("\r\n\r\n"); Emit(name,status,bodyAt<0?text:text.Substring(bodyAt+4),sw.Elapsed.TotalMilliseconds); } }
        catch(Exception e){ Emit(name,-1,e.GetType().Name+": "+e.Message,sw.Elapsed.TotalMilliseconds); }
    }
    public static int Main(string[] a){
        var host=new EightMax.Workbench.DesktopHost(a[0], Path.Combine(Path.GetTempPath(),"eightmax-harness-ready-"+Guid.NewGuid().ToString("N")+".json"));
        var t=typeof(EightMax.Workbench.DesktopHost); var bf=BindingFlags.NonPublic|BindingFlags.Instance;
        var l=new TcpListener(IPAddress.Loopback,port); l.Start(8); t.GetField("listener",bf).SetValue(host,l);
        token=(string)t.GetField("token",bf).GetValue(host);
        new Thread(()=>t.GetMethod("ServerLoop",bf).Invoke(host,null)){IsBackground=true}.Start();
        Web("health-get","GET","/api/desktop/health",null,null);
        Web("cancel-intent-post-with-body-expect-100","POST","/api/native/cancel-intent","{\"format\":\"not-a-job\"}",null);
        Web("job-post-invalid-json","POST","/api/native/jobs","{not json",null);
        Web("capture-open-without-consent","POST","/api/capture/open","{\"target\":{\"kind\":\"region\",\"x\":0,\"y\":0,\"width\":64,\"height\":64}}",null);
        Web("wrong-token","GET","/api/desktop/health",null,r=>r.Headers["X-EightMax-Session"]="0000");
        Web("foreign-origin","GET","/api/desktop/health",null,r=>r.Headers["Origin"]="https://example.invalid");
        Web("unknown-route","GET","/api/native/jobs/0123456789abcdef0123456789abcdef",null,null);
        Web("requests-log","GET","/api/desktop/requests",null,null);
        Raw("raw-localhost-host","GET /api/desktop/health HTTP/1.1\r\nHost: localhost:48713\r\nX-EightMax-Session: {token}\r\n\r\n");
        Raw("raw-bad-host","GET /api/desktop/health HTTP/1.1\r\nHost: evil.example:48713\r\nX-EightMax-Session: {token}\r\n\r\n");
        Raw("raw-chunked","POST /api/native/jobs HTTP/1.1\r\nHost: 127.0.0.1:48713\r\nX-EightMax-Session: {token}\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n");
        Raw("raw-expect-other","POST /api/native/jobs HTTP/1.1\r\nHost: 127.0.0.1:48713\r\nX-EightMax-Session: {token}\r\nExpect: something\r\nContent-Length: 2\r\n\r\n{}");
        Raw("raw-proxy-form","GET http://127.0.0.1:48713/api/desktop/health HTTP/1.1\r\nHost: 127.0.0.1:48713\r\n\r\n");
        Raw("raw-get-with-body","GET /api/desktop/health HTTP/1.1\r\nHost: 127.0.0.1:48713\r\nContent-Length: 2\r\n\r\n{}");
        Raw("raw-duplicate-header","GET /api/desktop/health HTTP/1.1\r\nHost: 127.0.0.1:48713\r\nHost: 127.0.0.1:48713\r\n\r\n");
        Raw("raw-oversize-body","POST /api/native/jobs HTTP/1.1\r\nHost: 127.0.0.1:48713\r\nContent-Length: 9999999\r\n\r\n");
        Raw("raw-garbage","HELLO\r\n\r\n");
        Web("shutdown-post-no-body","POST","/api/desktop/shutdown",null,null);
        Thread.Sleep(300);
        Web("after-shutdown-health","GET","/api/desktop/health",null,null);
        return 0;
    }
}
