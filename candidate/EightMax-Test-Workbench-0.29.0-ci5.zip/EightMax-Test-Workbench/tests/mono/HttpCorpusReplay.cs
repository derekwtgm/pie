// EightMax 0.29.0 - replays tests/fixtures/http-corpus/*.http byte-for-byte into the REAL DesktopHost.cs request reader/router
// (compiled with Mono). Requests with "Expect: 100-continue" are sent the way .NET Framework HttpWebRequest sends them: headers,
// wait for the interim "100 Continue", then the body. One JSON line per case. Also tests a start-up race: a client that connects
// and sends its request BEFORE the server loop runs. Linux/Mono only; proves framing rules, not Windows networking.
using System; using System.IO; using System.Net; using System.Net.Sockets; using System.Reflection; using System.Text; using System.Threading;
public static class HttpCorpusReplay {
    static string token; const int Port = 48713;
    static string Esc(string s){ var b=new StringBuilder("\""); foreach(char c in s??""){ if(c=='"'||c=='\\') b.Append('\\').Append(c); else if(c<32) b.AppendFormat("\\u{0:x4}",(int)c); else b.Append(c);} return b.Append('"').ToString(); }
    static string ReadAll(NetworkStream s){ var ms=new MemoryStream(); var buf=new byte[8192]; int n; try{ while((n=s.Read(buf,0,buf.Length))>0) ms.Write(buf,0,n);}catch(IOException){} return Encoding.UTF8.GetString(ms.ToArray()); }
    static void Case(string name, string raw){
        var sw=System.Diagnostics.Stopwatch.StartNew(); bool sawContinue=false;
        using(var c=new TcpClient("127.0.0.1",Port)){ var s=c.GetStream(); s.ReadTimeout=9000; raw=raw.Replace("{token}",token);
            int split=raw.IndexOf("\r\n\r\n"); bool expect=raw.IndexOf("Expect: 100-continue",StringComparison.OrdinalIgnoreCase)>=0 && split>0 && split+4<raw.Length;
            if(expect){ byte[] head=Encoding.ASCII.GetBytes(raw.Substring(0,split+4)); s.Write(head,0,head.Length);
                var got=new StringBuilder(); while(!got.ToString().EndsWith("\r\n\r\n")){ int b=s.ReadByte(); if(b<0) break; got.Append((char)b);} sawContinue=got.ToString().StartsWith("HTTP/1.1 100 Continue");
                byte[] body=Encoding.ASCII.GetBytes(raw.Substring(split+4)); s.Write(body,0,body.Length); }
            else { byte[] all=Encoding.ASCII.GetBytes(raw); s.Write(all,0,all.Length); }
            try{ c.Client.Shutdown(SocketShutdown.Send);}catch{}
            string text=ReadAll(s); int status=-1; if(text.StartsWith("HTTP/1.")) int.TryParse(text.Substring(9,3),out status); int at=text.IndexOf("\r\n\r\n");
            Console.WriteLine("{\"case\":"+Esc(name)+",\"status\":"+status+",\"continue\":"+(sawContinue?"true":"false")+",\"ms\":"+(int)sw.Elapsed.TotalMilliseconds+",\"body\":"+Esc(at<0?text:text.Substring(at+4))+"}"); }
    }
    public static int Main(string[] a){
        var host=new EightMax.Workbench.DesktopHost(a[0], Path.Combine(Path.GetTempPath(),"em-corpus-ready-"+Guid.NewGuid().ToString("N")+".json"));
        var t=typeof(EightMax.Workbench.DesktopHost); var bf=BindingFlags.NonPublic|BindingFlags.Instance;
        var l=new TcpListener(IPAddress.Loopback,Port); l.Start(8); t.GetField("listener",bf).SetValue(host,l); token=(string)t.GetField("token",bf).GetValue(host);
        // start-up race: the request is fully sent while nobody accepts yet (it waits in the listen backlog)
        var early=new Thread(()=>Case("connect-before-server-loop","GET /api/desktop/health HTTP/1.1\r\nX-EightMax-Session: {token}\r\nHost: 127.0.0.1:48713\r\nContent-Length: 0\r\n\r\n")); early.Start(); Thread.Sleep(700);
        new Thread(()=>t.GetMethod("ServerLoop",bf).Invoke(host,null)){IsBackground=true}.Start(); early.Join();
        foreach(var f in Directory.GetFiles(a[1],"*.http")) { Array.Sort(new string[0]); Case(Path.GetFileNameWithoutExtension(f), File.ReadAllText(f)); }
        return 0;
    }
}
