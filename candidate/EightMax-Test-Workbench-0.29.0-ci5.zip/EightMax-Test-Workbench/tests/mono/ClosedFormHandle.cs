// EightMax 0.28.0 regression: demonstrates (with a real WinForms runtime - Mono on X11, NOT Windows) the 0.26.0 capture
// self-test defect: reading Form.Handle after Close() of a modeless (Show()n) form throws ObjectDisposedException.
// The 0.28.0 self-test captures the handle once while the form is alive and never touches the Form after Close().
using System; using System.Windows.Forms;
public static class ClosedFormHandle {
    [STAThread] public static int Main() {
        Form f = new Form(); f.Text = "closed-handle regression"; f.Show(); Application.DoEvents();
        IntPtr saved = f.Handle; f.Close(); Application.DoEvents();
        string pattern026; try { IntPtr again = f.Handle; pattern026 = "no-exception handle=" + again; } catch (ObjectDisposedException) { pattern026 = "ObjectDisposedException"; }
        Console.WriteLine("{\"isDisposedAfterClose\":" + (f.IsDisposed ? "true" : "false") + ",\"pattern026\":\"" + pattern026 + "\",\"pattern028SavedHandleNonZero\":" + (saved != IntPtr.Zero ? "true" : "false") + "}");
        return 0;
    }
}
