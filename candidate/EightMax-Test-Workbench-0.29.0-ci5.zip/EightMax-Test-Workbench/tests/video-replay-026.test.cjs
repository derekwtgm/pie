'use strict';
/* 0.26 video replay: real FFmpeg encodes frames rendered by the built-in renderer into files; replay decodes them again. Skipped (not passed) without FFmpeg. */
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const V = require('../src/video-replay.js'), SIM = require('../src/sim-display.js'), EM = require('../src/engine.js'), M = require('../src/vision-metrics.js'), FH = require('../src/full-hand.js'), { engine } = require('./screen-util.cjs');
const ffmpeg = V.locate('ffmpeg'), need = ffmpeg ? {} : { skip: 'FFmpeg not available (put ffmpeg in tools/ffmpeg, set EIGHTMAX_FFMPEG or PATH)' };
const W = 960; let built;
/** Plays one table with a fixed seed and renders one frame per decision; returns RGBA frames and the truth of each. */
function scenario(frames = 40, seed = 6001) {
  const t = new EM.Table(1, seed), imgs = [], truths = [], heroes = []; t.startHand();
  while (imgs.length < frames) {
    if (t.status !== 'playing') { t.startHand(); continue; }
    const hero = t.actor, l = t.legal(); truths.push(M.truthFromTable(t, hero)); heroes.push(hero); imgs.push(SIM.renderTable(t, W, { v2: true, heroSeat: hero, seed: 3 }));
    const pick = imgs.length % 4; t.execute(pick === 0 && l.canRaise ? t.request('raise', Math.min(l.maxRaiseTo, l.minRaiseTo), 0) : l.toCall > 0 ? t.request(pick === 1 ? 'fold' : 'call', 0, 0) : t.request('check', 0, 0), 0);
  } return { imgs, truths, heroes, w: imgs[0].width, h: imgs[0].height };
}
function encode(sc, out, args) { // 2 frames per second, so a frame lasts 500 ms
  const c = cp.spawnSync(ffmpeg, ['-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', sc.w + 'x' + sc.h, '-r', '2', '-i', 'pipe:0', ...args, out], { input: Buffer.concat(sc.imgs.map((i) => Buffer.from(i.data.buffer, i.data.byteOffset, i.data.byteLength))), maxBuffer: 1 << 28 });
  assert.equal(c.status, 0, String(c.stderr)); return out;
}
function setup() { if (built) return built; const d = fs.mkdtempSync(path.join(os.tmpdir(), 'em026v-')), sc = scenario(); built = { d, sc, lossless: encode(sc, path.join(d, 'lossless.mkv'), ['-c:v', 'ffv1']), h264: encode(sc, path.join(d, 'h264.mp4'), ['-c:v', 'libx264', '-crf', '14', '-pix_fmt', 'yuv420p']) }; return built; }

test('probe reports size, codec and duration; a missing or non-video file is refused with a code', need, async () => {
  const b = setup(), i = await V.probe(b.lossless); assert.equal(i.width, b.sc.w); assert.equal(i.height, b.sc.h); assert.ok(Math.abs(i.durationMs - 20000) < 600, 'duration ' + i.durationMs); assert.ok(Math.abs(i.fps - 2) < 0.01);
  await assert.rejects(V.probe(path.join(b.d, 'nope.mkv')), { code: 'no-file' }); fs.writeFileSync(path.join(b.d, 'junk.mp4'), 'this is not a video'); await assert.rejects(V.probe(path.join(b.d, 'junk.mp4')), (e) => ['unreadable', 'no-video-stream'].includes(e.code));
});
test('lossless replay returns exactly the encoded pixels, with timestamps on the requested interval and unique frame ids', need, async () => {
  const b = setup(), r = await V.VideoReplay.open(b.lossless, { intervalMs: 500 }); const got = []; for await (const f of r.frames()) got.push(f);
  assert.ok(got.length >= 38 && got.length <= 41, 'frames ' + got.length); got.forEach((f, i) => { assert.equal(f.seq, i); assert.equal(f.tMs, i * 500); assert.equal(f.width, b.sc.w); assert.equal(f.data.length, b.sc.w * b.sc.h * 4); });
  for (const i of [0, 7, 19, 33]) { const a = got[i].data, e = b.sc.imgs[i].data; let diff = 0; for (let k = 0; k < a.length; k += 4) if (a[k] !== e[k] || a[k + 1] !== e[k + 1] || a[k + 2] !== e[k + 2]) diff++; assert.equal(diff, 0, 'frame ' + i + ' differs in ' + diff + ' pixels'); }
});
test('frame interval selects frames: 2 s steps return every fourth frame at the right timestamps; range and maxFrames bound the replay', need, async () => {
  const b = setup(), r = await V.VideoReplay.open(b.lossless, { intervalMs: 2000, startMs: 2000, endMs: 12000 }); const t = []; for await (const f of r.frames()) t.push(f.tMs); assert.deepEqual(t, [2000, 4000, 6000, 8000, 10000]);
  const m = await V.VideoReplay.open(b.lossless, { intervalMs: 500, maxFrames: 3 }); let n = 0; for await (const f of m.frames()) n++; assert.equal(n, 3);
  await assert.rejects(V.VideoReplay.open(b.lossless, { intervalMs: 1 }), { code: 'bad-interval' }); await assert.rejects(V.VideoReplay.open(b.lossless, { startMs: 99999999 }), { code: 'bad-range' });
});
test('pause holds the replay without losing or repeating frames; resume continues; seek jumps and keeps frame ids increasing', need, async () => {
  const b = setup(), r = await V.VideoReplay.open(b.lossless, { intervalMs: 500 }), seen = []; let pausedAt = 0;
  for await (const f of r.frames()) {
    seen.push({ seq: f.seq, tMs: f.tMs });
    if (f.seq === 3) { r.pause(); pausedAt = seen.length; setTimeout(() => { assert.equal(seen.length, pausedAt, 'nothing delivered while paused'); r.resume(); }, 300); }
    if (f.seq === 6) r.seek(10000); if (seen.length > 14) r.close();
  }
  assert.deepEqual(seen.slice(0, 7).map((x) => x.tMs), [0, 500, 1000, 1500, 2000, 2500, 3000]); assert.equal(seen[7].tMs, 10000); assert.ok(seen[7].seq === 7 && seen.every((x, i) => i === 0 || x.seq === seen[i - 1].seq + 1), 'ids increase across the seek'); assert.deepEqual(seen.slice(7, 10).map((x) => x.tMs), [10000, 10500, 11000]);
  assert.throws(() => r.seek(-5), { code: 'bad-seek' }); assert.throws(() => r.seek(1e9), { code: 'bad-seek' });
});
test('recognition from video: lossless frames are read, any rejection is explicit, and false acceptances are counted separately (H.264 reported apart)', need, async () => {
  const b = setup(), out = {};
  for (const [name, file] of [['lossless', b.lossless], ['h264', b.h264]]) {
    const metrics = new M.MetricsCollector(), replay = await V.VideoReplay.open(file, { intervalMs: 500 }), eng = engine(), vision = FH.makeVision(1);
    const res = await V.recognizeVideo({ replay, vision, engine: eng, metrics, truthAt: (f) => b.sc.truths[f.seq], heroSeatAt: (f) => b.sc.heroes[f.seq] }); out[name] = res.report;
    assert.ok(res.frames.length >= 38); assert.equal(res.report.frames, res.frames.length);
  }
  assert.equal(out.lossless.falseAcceptances, 0, 'lossless: no false acceptance'); assert.ok(out.lossless.accepted >= 20, 'lossless accepted ' + out.lossless.accepted + ' of ' + out.lossless.frames);
  assert.equal(out.h264.accepted + out.h264.rejected, out.h264.frames); assert.ok(out.h264.falseAcceptances <= out.h264.accepted);
  fs.writeFileSync(path.join(os.tmpdir(), 'em026-video-recognition.json'), JSON.stringify({ lossless: out.lossless, h264: out.h264 }, null, 1));
});
test('a corrupted video is reported, not silently treated as empty', need, async () => {
  const b = setup(), bad = path.join(b.d, 'cut.mkv'), buf = fs.readFileSync(b.lossless); fs.writeFileSync(bad, buf.subarray(0, 9000)); let threw = null, n = 0;
  try { const r = await V.VideoReplay.open(bad, { intervalMs: 500 }); for await (const f of r.frames()) n++; } catch (e) { threw = e; }
  assert.ok(threw ? ['decode', 'unreadable', 'no-video-stream'].includes(threw.code) : n < 20, 'truncated file must error or yield far fewer frames than the original');
});
test('without FFmpeg every entry point fails with code no-ffmpeg', () => { const keep = [process.env.PATH, process.env.EIGHTMAX_FFMPEG, process.env.EIGHTMAX_FFPROBE]; process.env.PATH = '/nonexistent'; delete process.env.EIGHTMAX_FFMPEG; delete process.env.EIGHTMAX_FFPROBE; try { if (V.locate('ffmpeg')) return; return assert.rejects(V.probe(__filename), { code: 'no-ffmpeg' }); } finally { process.env.PATH = keep[0]; if (keep[1]) process.env.EIGHTMAX_FFMPEG = keep[1]; if (keep[2]) process.env.EIGHTMAX_FFPROBE = keep[2]; } });
