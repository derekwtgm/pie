'use strict';
// 0.29.0 consolidation guard: nothing added by 0.27.0 or 0.28.0 (after the 0.26.0 common ancestor) may silently disappear,
// and the key capability of each side must still be present. Inventory: docs/CONSOLIDATION-INVENTORY-0.29.json.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path');
const root = path.join(__dirname, '..'), read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const inv = JSON.parse(read('docs/CONSOLIDATION-INVENTORY-0.29.json'));

test('every file added by 0.27.0 or 0.28.0 is present, or listed as replaced with a reason and its replacement exists', () => {
  const missing = [];
  for (const f of [...inv.addedIn027, ...inv.addedIn028]) if (!fs.existsSync(path.join(root, f)) && !inv.replaced[f]) missing.push(f);
  assert.deepEqual(missing, []);
  for (const [f, why] of Object.entries(inv.replaced)) { assert.ok(why.length > 20, f); assert.ok(!fs.existsSync(path.join(root, f)), f + ' is listed as replaced but still present'); }
  assert.ok(fs.existsSync(path.join(root, 'tests/wgc-027.test.cjs')) && fs.existsSync(path.join(root, 'tests/wgc-028.test.cjs')));
  assert.ok(inv.addedIn027.includes('tests/seats-027.test.cjs') && inv.addedIn028.includes('tests/windows-repairs-028.test.cjs'));
});
test('0.27 capabilities kept: 2-8 seat layouts and pipeline, seat-count strategy refusal, solver-in-the-loop benchmark, PNG writer, runtime docs', () => {
  const OCR = require('../src/vision-ocr.js'); for (let n = 2; n <= 8; n++) assert.equal(OCR.defaultLayout(n).seats.length, n);
  assert.match(read('src/full-hand.js') + read('src/hand-state.js'), /player-count-unsupported/);
  for (const f of ['tools/multitable-benchmark-027.cjs', 'desktop/wgc/PngWriter.cs', 'tools/wgc-png-check/Program.cs', 'docs/SEAT-COUNTS.md', 'docs/ENGINE-5.3-EVALUATION.md', 'docs/RUNTIME-AND-TOOLS.md', 'docs/0.27-validation-report.md', 'reports/0.27-benchmark-D-solver-in-loop-linux-simulated.json', 'reports/0.27-scenario240-seed2024.json', 'reports/0.27-scenario240-seed7.json', 'reports/0.27-scenario240-seed99.json', 'RUN-TOOL.cmd']) assert.ok(fs.existsSync(path.join(root, f)), f);
  assert.match(read('desktop/wgc/Program.cs'), /PngWriter\.Encode/, 'the helper writes PNGs with the restored 0.27 encoder');
  assert.match(read('dashboard.html'), /id="cap-seats"/); assert.match(read('dashboard.html'), /id="cap-method"/);
});
test('0.28 repairs kept: closed-handle-safe self-test, Expect 100-continue, structured errors, shutdown, collector, results panel, memory awareness', () => {
  const cap = read('desktop/capture/EightMaxCapture.cs'), host = read('desktop/DesktopHost.cs');
  assert.match(cap, /hwnd = f\.Handle; hwndText =/); assert.match(host, /HTTP\/1\.1 100 Continue/); assert.match(host, /class RequestError/); assert.match(host, /void RequestExit\(/);
  assert.match(host, /readonly Semaphore connectionSlots/); assert.match(read('windows/Test-Capture.ps1'), /Invoke-EmTool/);
  for (const f of ['COLLECT-TEST-RESULTS.cmd', 'windows/Collect-TestResults.ps1', 'src/test-results.js', 'src/test-results-ui.js', 'desktop/wgc/SelfTest.cs', 'docs/DESKTOP-PROTOCOL-0.28.md']) assert.ok(fs.existsSync(path.join(root, f)), f);
  assert.equal(typeof require('../src/strategy-budget.js').nativeConcurrency, 'function');
  assert.match(read('desktop/wgc/Program.cs'), /--session/);
});
test('the consolidated choices are the documented ones: 0.27 WGC route and manual-only rule, 0.28 helper, Node v22.23.5', () => {
  const CM = require('../src/capture-manager.js'); assert.equal(CM.CATALOG['windows-graphics-capture'].manualOnly, true);
  assert.match(read('desktop/CaptureService.cs'), /static string GrabWgc/); assert.doesNotMatch(read('desktop/DesktopHost.cs'), /string WgcGrab\(/, 'no second, competing WGC route');
  assert.equal(JSON.parse(read('runtime/node/PROVENANCE.json')).version, 'v22.23.5');
  const doc = read('docs/CONSOLIDATION-0.29.md'); for (const k of ['DesktopHost.cs', 'CaptureService.cs', 'Program.cs', 'capture-manager.js', 'node.exe', 'Test-Desktop.ps1']) assert.ok(doc.includes(k), k);
});
