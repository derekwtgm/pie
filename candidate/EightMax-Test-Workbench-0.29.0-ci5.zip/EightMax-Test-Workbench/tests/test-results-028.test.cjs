'use strict';
// 0.28.0: dashboard test-results model, friendly error explanations and desktop client error codes.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path');
const M = require('../src/test-results.js');
const H = require('../src/desktop-host.js');
const root = path.join(__dirname, '..');

test('each class of failure gets the plain-language explanation the brief asks for, keeping technical detail', () => {
  assert.equal(M.explain({ check: 'selftest:detect-closed', detail: 'x' }).title, 'Screen capture failed');
  assert.match(M.explain({ check: 'selftest:detect-closed' }).text, /target window was closed or capture could not continue/);
  assert.equal(M.explain({ check: 'Desktop acceptance completed', detail: 'The remote server returned an error: (400) Bad Request.' }).title, 'Desktop connection failed');
  assert.match(M.explain({ errorCode: 'invalid-request' }).text, /local API request was rejected\. Open diagnostics/);
  assert.equal(M.explain({ check: 'desktop/Managed reviewed CPU workflow' }).title, 'Solver unavailable');
  assert.equal(M.explain({ errorCode: 'memory-budget-exceeded' }).title, 'Insufficient memory');
  assert.equal(M.explain({ check: 'wgc:first-frame' }).title, 'Windows Graphics Capture unavailable');
  assert.equal(M.explain({ check: 'Graceful desktop shutdown' }).title, 'Desktop shutdown failed');
  assert.equal(M.explain({ errorClass: 'timeout', check: 'whatever' }).title, 'A check took too long');
  assert.equal(M.explain({ errorClass: 'missing-executable' }).title, 'Program file missing');
  assert.equal(M.explain({ check: 'x', detail: 'tech' }).technical, 'tech');
});

test('summary view: last test, counts, report location and explained failures (from the real 0.26 Windows reports)', () => {
  const summary = { format: 'eightmax-test-results-summary', version: 1, appVersion: '0.28.0', testsCompleted: 2, testsPassed: 0, testsFailed: 2, checksPassed: 5, checksFailed: 4, checksSkipped: 1,
    tests: [
      { test: 'desktop-acceptance', at: '2026-11-18T14:49:59Z', passed: false, passedChecks: 2, failed: 2, skipped: 0, report: 'Diagnostics/desktop-ee87/EightMax-desktop-acceptance.json', failures: [{ check: 'Desktop acceptance completed', detail: 'The remote server returned an error: (400) Bad Request.' }, { check: 'Graceful desktop shutdown', detail: 'The test had to terminate its owned host process.' }] },
      { test: 'capture-acceptance', at: '2026-11-18T14:49:48Z', passed: false, passedChecks: 2, failed: 1, skipped: 0, report: 'ReleaseAcceptance/x/capture/capture-acceptance.json', failures: [{ check: 'acceptance-run', detail: '(empty detail - 0.26 harness defect)' }] }] };
  const v = M.view(summary);
  assert.equal(v.lastTest, 'desktop-acceptance'); assert.equal(v.lastStatus, 'fail'); assert.equal(v.lastPassed, 2); assert.equal(v.lastFailed, 2);
  assert.equal(v.reportLocation, 'Diagnostics/desktop-ee87/EightMax-desktop-acceptance.json');
  assert.deepEqual(v.failures.map((f) => f.title), ['Desktop connection failed', 'Desktop shutdown failed', 'Screen capture failed']);
  assert.throws(() => M.view({ format: 'other' }), /Unsupported/);
  assert.equal(M.view({ format: 'eightmax-test-results-summary', version: 1, tests: [] }).lastStatus, 'none');
});

test('desktop client keeps the host error code, status and request id (0.26 reported only "(400) Bad Request")', async () => {
  const token = 'a'.repeat(64);
  const c = new H.Client({ token, fetch: async () => ({ ok: false, status: 400, headers: { get: () => null }, text: async () => JSON.stringify({ error: 'Unsupported native job.', code: 'invalid-request', requestId: 'r7', status: 400 }) }) });
  await assert.rejects(c.call('/api/native/jobs', 'POST', { x: 1 }), (e) => e.message === 'Unsupported native job.' && e.code === 'invalid-request' && e.status === 400 && e.requestId === 'r7');
  const ok = new H.Client({ token, fetch: async () => ({ ok: true, status: 200, headers: { get: () => null }, text: async () => '{"format":"eightmax-test-results-summary","version":1}' }) });
  assert.equal((await ok.call('/api/desktop/test-results')).format, 'eightmax-test-results-summary');
  await assert.rejects(ok.call('/api/desktop/anything-else'), /Unknown desktop route/);
  assert.match(M.errorMessage(Object.assign(Error('Bad host'), { code: 'invalid-host' })), /^Desktop connection failed: .*code invalid-host.*Technical detail: Bad host/);
});

test('dashboard has every requested control and the panel is in the standalone page', () => {
  const html = fs.readFileSync(path.join(root, 'START.html'), 'utf8');
  for (const id of ['tr-start-sim', 'tr-stop-sim', 'tr-load-strategy', 'tr-start-study', 'tr-stop-study', 'tr-capture-settings', 'tr-test-capture', 'tr-windows-checks', 'tr-hardware', 'tr-refresh', 'tr-collect', 'tr-export-diagnostics', 'tr-emergency', 'tr-open-folder', 'tr-export-zip', 'tr-last-at', 'tr-last-status', 'tr-passed', 'tr-failed', 'tr-skipped', 'tr-failures', 'tr-location'])
    assert.ok(html.includes('id="' + id + '"'), id);
  assert.ok(html.includes('WorkbenchTestResults'));
  for (const id of ['start', 'pause', 'stop', 'study-nav', 'cpu-open', 'desktop-run-native', 'desktop-cancel-native', 'cap-nav', 'diagnostics-nav', 'diagnostics-export']) assert.ok(html.includes('id="' + id + '"'), 'panel shortcut target ' + id);
});

test('host launches only a fixed whitelist of the release\'s own tools and refuses acceptance runs while it holds the port', () => {
  const s = fs.readFileSync(path.join(root, 'desktop/DesktopHost.cs'), 'utf8');
  assert.match(s, /\{"capture-check","RUN-CAPTURE-CHECK\.cmd"\}/); assert.match(s, /\{"collect-results","COLLECT-TEST-RESULTS\.cmd"\}/);
  assert.match(s, /host-must-be-closed/); assert.match(s, /unknown-tool/);
  assert.match(s, /Path\.Combine\(root,Tools\[tool\]\)/, 'only files from the release folder');
});
