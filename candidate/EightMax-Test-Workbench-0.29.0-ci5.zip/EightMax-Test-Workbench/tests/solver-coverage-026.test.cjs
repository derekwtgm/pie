'use strict';
const test = require('node:test'), assert = require('node:assert/strict'), ST = require('../src/solver-tree.js'), FH = require('../src/full-hand.js'), EX = require('../src/test-executor.js');
test('regression (found in the 0.26 240-hand run, seed 5239 hand 69): a tree "Bet" entry becomes a RAISE when the table already has a wager, as the executor requires', () => {
  const bet = { kind: 'bet', to: 300 }, raise = { kind: 'raise', to: 500 };
  assert.deepEqual(ST.executableFor(bet, { currentBet: 100, street: 'flop' }), { type: 'raise', amount: 300 });   // facing a wager: was 'bet' -> executor refused with bet-facing-a-wager, the hand was suspended
  assert.deepEqual(ST.executableFor(bet, { currentBet: 0, street: 'flop' }), { type: 'bet', amount: 300 });
  assert.deepEqual(ST.executableFor(raise, { currentBet: 0, street: 'flop' }), { type: 'bet', amount: 500 }, 'no wager yet: the executor rejects raise-with-no-wager');
  assert.deepEqual(ST.executableFor(raise, { currentBet: 0, street: 'preflop' }), { type: 'raise', amount: 500 });
  assert.deepEqual(ST.executableFor(bet), { type: 'bet', amount: 300 }, 'without request context the menu label is kept (menu walking only)');
  assert.deepEqual(ST.executableFor({ kind: 'allin', to: null }, { currentBet: 100 }), { type: 'allin' }); assert.deepEqual(ST.executableFor({ kind: 'call', amount: null }, { currentBet: 100 }), { type: 'call' });
});
test('the executor still refuses a wrong bet/raise word (the guard that caught the defect is intact)', () => {
  const src = require('node:fs').readFileSync(require('node:path').join(__dirname, '../src/test-executor.js'), 'utf8'); assert.match(src, /bet-facing-a-wager \(use raise\)/); assert.match(src, /raise-with-no-wager \(use bet\)/);
});
