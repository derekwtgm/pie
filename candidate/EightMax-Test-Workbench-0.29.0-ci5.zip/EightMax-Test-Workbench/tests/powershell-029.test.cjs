'use strict';
// 0.29.0: Windows PowerShell 5.1 pitfalls found by running the scripts on a real Windows runner (they passed every Linux check):
//  1. Install-Workbench.ps1 assigned a command line to $uninstall; variable names ignore case, so that is the [switch]$Uninstall
//     parameter and every install failed ("Cannot convert value System.String to type SwitchParameter").
//  2. Run-Native-Study.ps1 filtered steps with '-isnot [pscustomobject]'; in 5.1 every ConvertFrom-Json value is PSObject-wrapped, so
//     all steps were dropped and every reviewed native job failed ("Query path differs from reviewed target").
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path');
const root = path.join(__dirname, '..');
const scripts = [...fs.readdirSync(path.join(root, 'windows')).filter((f) => f.endsWith('.ps1')).map((f) => 'windows/' + f), 'native/Run-Native-Study.ps1'];
const code = (t) => t.replace(/<#[\s\S]*?#>/g, '').split('\n').map((l) => l.replace(/(^|\s)#.*$/, '')).join('\n');
test('no script assigns to a variable whose name (ignoring case) is one of its own [switch] parameters', () => {
  for (const f of scripts) {
    const t = code(fs.readFileSync(path.join(root, f), 'utf8')), m = /^\s*param\s*\(([^)]*)\)/im.exec(t); if (!m) continue;
    for (const sw of [...m[1].matchAll(/\[switch\]\s*\$(\w+)/gi)].map((x) => x[1])) {
      const bad = [...t.matchAll(new RegExp('\\$' + sw + '\\s*=(?!=)', 'gi'))].filter((x) => !/^\$\w+\s*=\s*\$(true|false)/i.test(x[0]));
      assert.deepEqual(bad.map((x) => x[0]), [], f + ': assignment to switch parameter $' + sw);
    }
  }
});
test('no script uses -is / -isnot [pscustomobject] to tell JSON values apart (always true for PSObject-wrapped values in 5.1)', () => {
  for (const f of scripts) assert.doesNotMatch(code(fs.readFileSync(path.join(root, f), 'utf8')), /-is(not)?\s+\[(pscustomobject|psobject)\]/i, f);
});
test('no script passes $null to a .NET method (Windows PowerShell turns it into "" - [IO.File]::Replace then fails "path is not of a legal form")', () => {
  for (const f of scripts) assert.doesNotMatch(code(fs.readFileSync(path.join(root, f), 'utf8')), /\[[A-Za-z.]+\]::[A-Za-z]+\([^()]*\$null[^()]*\)/, f);
});
