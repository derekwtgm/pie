'use strict';
/* 0.26 strategy-memory tests. Pure tests always run; tests that need the native engine run when EIGHTMAX_TEST_CLI (or native/mwcli.exe on Windows) exists
 * and are reported as SKIPPED - never passed - otherwise. */
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const EM = require('./load-solver.cjs'), A = require('../src/study-adapter.js'), T = require('../tools/studies.cjs'), B = require('../src/strategy-budget.js');
const { StrategyStore, StoreError, nativeBackedGame } = require('../src/strategy-store.js'), N = require('../tools/native-training.cjs'), { cliPath } = require('../tools/train-study.cjs');
const cli = cliPath(), G = 1073741824, needCli = cli ? {} : { skip: 'native EightMax engine not available (set EIGHTMAX_TEST_CLI)' };
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'em026-'));
let specCache; function specFile(dir) { const prepared = A.prepare(EM, { config: T.PREFLOP8_LINKED, iterations: 1, timeMs: 1000, strategyBudgetMiB: 32 }); const f = path.join(dir, 'spec.json'); fs.writeFileSync(f, JSON.stringify(A.nativeJob(prepared, 't').spec)); return { f, prepared }; }

test('budget planner: 16 GB machine permits 256 MiB to 4 GiB, an 8 GB machine with little free RAM does not permit 4 GiB', () => {
  const p16 = B.plan({ totalRamBytes: 16 * G, freeRamBytes: 11 * G }); assert.deepEqual(p16.profiles.map((x) => x.permitted), [true, true, true, true, true]); assert.equal(p16.recommendedMiB, 4096);
  const p8 = B.plan({ totalRamBytes: 8 * G, freeRamBytes: 5 * G }); assert.deepEqual(p8.profiles.map((x) => x.permitted), [true, true, true, true, false]); assert.match(p8.profiles[4].why, /FREE memory|total RAM/);
  assert.ok(p16.reserveMiB >= 3072, 'Windows reserve is kept');
});
test('budget planner refuses unsafe, fractional, tiny and oversized requests and unknown RAM', () => {
  assert.equal(B.plan({ totalRamBytes: 6 * G, freeRamBytes: 5 * G, requestedMiB: 4096 }).ok, false); assert.equal(B.plan({ totalRamBytes: 6 * G, freeRamBytes: 5 * G, requestedMiB: 4096 }).code, 'exceeds-ram'); assert.equal(B.plan({ totalRamBytes: 8 * G, freeRamBytes: 5 * G, requestedMiB: 4096 }).code, 'exceeds-free-ram');
  assert.equal(B.plan({ totalRamBytes: 16 * G, freeRamBytes: 2 * G, requestedMiB: 2048 }).code, 'exceeds-free-ram');
  for (const bad of [10, 63, 16385, 1.5, '1024', NaN]) assert.equal(B.plan({ totalRamBytes: 16 * G, requestedMiB: bad }).code, 'out-of-range', String(bad));
  assert.equal(B.plan({ totalRamBytes: 0 }).code, 'unknown-ram'); assert.equal(B.plan({ totalRamBytes: 16 * G, freeRamBytes: 12 * G, requestedMiB: 2048 }).grantedMiB, 2048);
});
test('budget planner: more concurrent native processes lowers the per-process ceiling', () => { const one = B.plan({ totalRamBytes: 16 * G, concurrentNative: 1 }), three = B.plan({ totalRamBytes: 16 * G, concurrentNative: 3 }); assert.ok(three.ceilingMiB < one.ceilingMiB / 2); });
test('a native run that hit its memory ceiling is NEVER reported as complete (0.25 defect)', () => {
  const mk = (o) => ({ iterations: 67273, tableMiB: 177.7, budgetMiB: 256, limitReached: false, cancelled: false, processPeakRssMiB: 234, studyId: 'x', ...o });
  const lim = B.interpretNativeRun(mk({ limitReached: true }), 250000); assert.equal(lim.status, 'memory-limited'); assert.equal(lim.complete, false); assert.match(lim.reason, /67273 of 250000/);
  assert.equal(B.interpretNativeRun(mk({ limitReached: false, iterations: 250000 }), 250000).status, 'complete');
  assert.equal(B.interpretNativeRun(mk({ cancelled: true }), 250000).status, 'cancelled'); assert.equal(B.interpretNativeRun(mk({}), 250000).status, 'invalid'); assert.equal(B.interpretNativeRun(null, 5).status, 'invalid');
});
test('nextBudget picks the next permitted profile only', () => { const p = B.plan({ totalRamBytes: 8 * G, freeRamBytes: 5 * G }); assert.equal(B.nextBudget(256, p), 512); assert.equal(B.nextBudget(2048, p), null); });
test('adapter: JavaScript budget capped at the engine limit (256), native budget separate and carried into the job; 0.25 default preserved', () => {
  assert.throws(() => A.prepare(EM, { config: T.PREFLOP8_LINKED, strategyBudgetMiB: 512 }), /8 to 256 MiB/); assert.throws(() => A.prepare(EM, { config: T.PREFLOP8_LINKED, nativeMemoryMiB: 8 }), /64 to 16384/);
  const base = A.prepare(EM, { config: T.PREFLOP8_LINKED, iterations: 5 }); assert.equal(A.nativeJob(base, 'a').memoryMiB, 256);
  const big = A.prepare(EM, { config: T.PREFLOP8_LINKED, iterations: 5, nativeMemoryMiB: 2048 }); assert.equal(A.nativeJob(big, 'b').memoryMiB, 2048); assert.equal(A.nativeJob(big, 'c', { memoryMiB: 512 }).memoryMiB, 512);
});

test('lazy store matches a full JavaScript import exactly, stays inside its cache bound and evicts', needCli, async () => {
  const d = tmp(), { f, prepared } = specFile(d), out = path.join(d, 's.state');
  const r = await N.trainNative({ cli, specFile: f, updates: 12000, budgetMiB: 512, threads: 1, outFile: out }); assert.equal(r.run.status, 'complete');
  const js = A.prepare(EM, { config: T.PREFLOP8_LINKED, iterations: 1, timeMs: 1000, strategyBudgetMiB: 256 }); js.game.importNative(fs.readFileSync(out));
  const store = StrategyStore.open(out, { cacheBytes: 2 << 20 }), g = nativeBackedGame(prepared.game, prepared, store); let n = 0, missing = 0, seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) >>> 0) / 4294967296;
  for (let trial = 0; trial < 150; trial++) { const steps = []; let key = 'r'; for (let depth = 0; depth < 6; depth++) { const v = g.view(steps); if (v.kind !== 'player') break;
    for (let q = 0; q < 3; q++) { const rows = prepared.spec.hands[v.seat], row = rows[Math.floor(rnd() * rows.length)], h = { id: row[0], a: row[1], b: row[2], w: row[3] }, a = g.averageAt(key, [], v.seat, h), b = js.game.averageAt(key, js.spec.board, v.seat, h); n++;
      if (!a) missing++; assert.equal(!!a, !!b, 'stored/unstored agree'); if (a) assert.deepEqual(Array.from(a), Array.from(b)); }
    const s = Math.floor(rnd() * v.actions.length); steps.push(s); key += s; } }
  const st = store.stats(); assert.ok(n > 1000); assert.ok(missing > 0 && missing < n, 'some information sets are genuinely unstored'); assert.ok(st.peakCacheBytes <= 2 << 20, 'cache bound respected'); assert.ok(st.evictions > 0, 'eviction happened'); assert.ok(st.hits > 0);
  assert.throws(() => g.averageAt('r', [3], 0, { id: 0 }), /preflop information sets only/); store.close(); fs.rmSync(d, { recursive: true, force: true });
});
test('corrupt, truncated, trailing-data, wrong-magic and header-damaged states are refused with a code', needCli, async () => {
  const d = tmp(), { f } = specFile(d), out = path.join(d, 's.state'); await N.trainNative({ cli, specFile: f, updates: 3000, budgetMiB: 256, threads: 1, outFile: out }); const good = fs.readFileSync(out);
  const tryOpen = (buf) => { const p = path.join(d, 'x.state'); fs.writeFileSync(p, buf); try { StrategyStore.open(p).close(); return 'opened'; } catch (e) { assert.ok(e instanceof StoreError, e.message); return e.code; } };
  assert.equal(tryOpen(good), 'opened');
  const flip = Buffer.from(good); flip[good.length - 100] ^= 0x40; assert.equal(tryOpen(flip), 'checksum');
  assert.equal(tryOpen(good.subarray(0, good.length - 77)), 'checksum'); assert.ok(['truncated', 'bad-header'].includes(tryOpen(good.subarray(0, 40))));
  assert.equal(tryOpen(Buffer.concat([good, Buffer.from('junk')])), 'checksum'); const bm = Buffer.from(good); bm[0] = 0x58; assert.equal(tryOpen(bm), 'bad-magic');
  const hh = Buffer.from(good); hh.writeUInt32LE(0x7fffffff, 8); assert.equal(tryOpen(hh), 'bad-header'); assert.equal(tryOpen(Buffer.alloc(5)), 'truncated');
  fs.rmSync(d, { recursive: true, force: true });
});
test('memory exhaustion: a tiny budget stops as memory-limited (not complete); resuming at a larger budget reproduces the uninterrupted study byte for byte', needCli, async () => {
  const d = tmp(), { f } = specFile(d), direct = await N.trainNative({ cli, specFile: f, updates: 20000, budgetMiB: 512, threads: 1, outFile: path.join(d, 'direct.state') });
  const lim = await N.trainNative({ cli, specFile: f, updates: 20000, budgetMiB: 64, threads: 1, outFile: path.join(d, 'lim.state') });
  assert.equal(lim.run.status, 'memory-limited'); assert.ok(lim.run.updatesDone < 20000); assert.equal(lim.run.complete, false);
  const res = await N.trainNative({ cli, specFile: f, updates: 20000, budgetMiB: 512, threads: 1, outFile: path.join(d, 'res.state'), resumeFrom: path.join(d, 'lim.state') });
  assert.equal(res.run.status, 'complete'); assert.equal(res.sha256, direct.sha256, 'deterministic continuation across a memory-limited stop');
  const a = await N.trainNative({ cli, specFile: f, updates: 8000, budgetMiB: 512, threads: 1, outFile: path.join(d, 'a.state') }), b = await N.trainNative({ cli, specFile: f, updates: 20000, budgetMiB: 512, threads: 1, outFile: path.join(d, 'b.state'), resumeFrom: path.join(d, 'a.state') });
  assert.equal(b.sha256, direct.sha256, 'checkpoint (8,000) + continuation equals one uninterrupted run');
  await assert.rejects(N.trainNative({ cli, specFile: f, updates: 8000, budgetMiB: 512, threads: 1, outFile: path.join(d, 'c.state'), resumeFrom: path.join(d, 'b.state') }), { code: 'nothing-to-do' }); fs.rmSync(d, { recursive: true, force: true });
});
test('ensureStudy: escalates a memory-limited study to the next permitted budget, reuses the cached result, refuses an unsafe budget', needCli, async () => {
  const d = tmp(), { f } = specFile(d), sys = { totalRamBytes: 16 * G, freeRamBytes: 12 * G };
  const direct = await N.trainNative({ cli, specFile: f, updates: 90000, budgetMiB: 1024, threads: 1, outFile: path.join(d, 'direct.state') });
  const e = await N.ensureStudy({ cli, specFile: f, updates: 90000, budgetMiB: 64, threads: 1, dir: path.join(d, 'c'), name: 'p', system: sys, cacheBytes: 1 << 20 });
  assert.equal(e.meta.status, 'complete'); assert.ok(e.meta.history.length >= 2 && e.meta.history[0].status === 'memory-limited' && e.meta.history.at(-1).resumed); assert.equal(e.meta.sha256, direct.sha256); e.store.close();
  const again = await N.ensureStudy({ cli, specFile: f, updates: 90000, budgetMiB: 64, threads: 1, dir: path.join(d, 'c'), name: 'p', system: sys }); assert.equal(again.meta.cached, true); again.store.close();
  await assert.rejects(N.ensureStudy({ cli, specFile: f, updates: 5000, budgetMiB: 4096, threads: 1, dir: path.join(d, 'z'), name: 'q', system: { totalRamBytes: 4 * G, freeRamBytes: 2 * G } }), { code: 'exceeds-ram' });
  fs.writeFileSync(path.join(d, 'c', 'p-90000.state'), Buffer.from('damaged')); const rebuilt = await N.ensureStudy({ cli, specFile: f, updates: 90000, budgetMiB: 64, threads: 1, dir: path.join(d, 'c'), name: 'p', system: sys }); assert.equal(rebuilt.meta.status, 'complete'); rebuilt.store.close(); fs.rmSync(d, { recursive: true, force: true });
});
test('interrupted training leaves the previous state intact and no temporary files; a failed final write is reported and cleaned up', needCli, async () => {
  const d = tmp(), { f } = specFile(d), out = path.join(d, 'keep.state'); await N.trainNative({ cli, specFile: f, updates: 3000, budgetMiB: 256, threads: 1, outFile: out }); const before = N.sha256File(out);
  const ac = new AbortController(); const p = N.trainNative({ cli, specFile: f, updates: 400000, budgetMiB: 1024, threads: 1, outFile: out, signal: ac.signal }); setTimeout(() => ac.abort(), 400);
  await assert.rejects(p, { code: 'cancelled' }); assert.equal(N.sha256File(out), before); assert.deepEqual(fs.readdirSync(d).filter((x) => x.includes('.tmp')), []);
  const blocked = path.join(d, 'blocked.state'); fs.mkdirSync(blocked); fs.writeFileSync(path.join(blocked, 'x'), '1');
  await assert.rejects(N.trainNative({ cli, specFile: f, updates: 2000, budgetMiB: 256, threads: 1, outFile: blocked }), { code: 'write-failed' }); assert.deepEqual(fs.readdirSync(d).filter((x) => x.includes('.tmp')), []);
  await assert.rejects(N.trainNative({ cli: path.join(d, 'nope'), specFile: f, updates: 1, budgetMiB: 256, outFile: out }), { code: 'no-engine' }); await assert.rejects(N.trainNative({ cli, specFile: f, updates: 1, budgetMiB: 5, outFile: out }), { code: 'bad-budget' }); fs.rmSync(d, { recursive: true, force: true });
});
test('native training is deterministic: two runs of the same study have identical bytes', needCli, async () => {
  const d = tmp(), { f } = specFile(d), a = await N.trainNative({ cli, specFile: f, updates: 6000, budgetMiB: 256, threads: 1, outFile: path.join(d, 'a') }), b = await N.trainNative({ cli, specFile: f, updates: 6000, budgetMiB: 256, threads: 1, outFile: path.join(d, 'b') }); assert.equal(a.sha256, b.sha256); fs.rmSync(d, { recursive: true, force: true });
});
test('0.25 synchronous trainer now refuses a truncated study instead of using it as if complete', needCli, () => {
  const { trainStudy } = require('../tools/train-study.cjs'), d = tmp();
  try { assert.throws(() => trainStudy(250000, { config: T.PREFLOP8_LINKED, name: 'refuse-test', cacheDir: d, threads: 2, budgetMiB: 64 }), (e) => e.code === 'memory-limited' && /shorter than requested/.test(e.message)); assert.deepEqual(fs.readdirSync(d).filter((x) => x.endsWith('.state')), [], 'no truncated state was cached'); }
  finally { fs.rmSync(d, { recursive: true, force: true }); }
});
