'use strict';
/* 0.27 workload D: COMPLETE AUTOMATED SIMULATION WITH THE REAL SOLVER IN THE LOOP, kept apart from the lookup (A), pipeline-only (B) and
 * isolated solving (C) numbers. Every table renders pixels, recognises them, reconstructs the state and asks a real EightMax study source
 * (the trained linked preflop study plus on-demand postflop studies trained by the native CLI). Scripted fallbacks are labelled and counted.
 * SIMULATED TABLES on this machine. Not real-client and not Windows target-hardware numbers.
 * usage: EIGHTMAX_TEST_CLI=<mwcli> node tools/multitable-benchmark-027.cjs --tables=1,2,5,10 --hands=2 --workers=4 --updates=250000 --post=8000 --out=reports/x.json */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.replace(/^--/, '').split('=')));
const { summarise, inWorker } = require('./multitable-benchmark-024.cjs'), RM = require('../src/resource-monitor.js');
const cli = process.env.EIGHTMAX_TEST_CLI; if (!cli) { console.error('EIGHTMAX_TEST_CLI is required: workload D needs the native engine.'); process.exit(2); }
const tablesList = String(args.tables || '1,2,5,10').split(',').map(Number), hands = +(args.hands || 2), workers = +(args.workers || 4), seed = +(args.seed || 4127), updates = +(args.updates || 250000), post = +(args.post || 8000);
(async () => {
  const solver = { kind: 'preflop-linked', cli, updates, postIterations: post, budgetMiB: +(args.budget || 1024), cacheDir: args.cache || path.join(os.tmpdir(), 'eightmax-study-cache') };
  const doc = { format: 'eightmax-multitable-benchmark-d', version: 1, appVersion: require('../src/engine.js').VERSION, generatedAt: new Date().toISOString(), classification: 'SIMULATED TABLES with the REAL solver in the loop; this machine only; not real-client; not Windows target hardware; no GPU',
    machine: { platform: process.platform, arch: process.arch, node: process.version, cpu: os.cpus()[0] && os.cpus()[0].model, logicalCpus: os.cpus().length, totalMemBytes: os.totalmem() }, handsPerTable: hands, seed, solver: { preflopUpdates: updates, postflopIterationsPerStudy: post, backend: 'native-cli-cpu', convergence: 'unproven' }, runs: {} };
  for (const tables of tablesList) {
    const groups = Array.from({ length: Math.min(workers, tables) }, () => []); for (let i = 1; i <= tables; i++) groups[(i - 1) % groups.length].push(i);
    const mon = new RM.RunMonitor({ intervalMs: 100 }).start(); const t0 = Date.now();
    const parts = await Promise.all(groups.map((g, gi) => inWorker({ tables: g, hands, seed, workerId: gi + 1, solver }))); parts.forEach((x) => mon.workerReport(x.self));
    const s = summarise(parts, mon.report({ workers: groups.length })); mon.stop();
    const tot = parts.flatMap((p) => p.reports).reduce((a, r) => { a.solver += r.totals.solverActions; a.scripted += r.totals.scriptedActions; a.unavailable += r.totals.unavailable; a.stale += r.totals.staleDecisions; a.suspended += r.totals.suspended; a.completed += r.completed; return a; }, { solver: 0, scripted: 0, unavailable: 0, stale: 0, suspended: 0, completed: 0 });
    doc.runs[tables] = { workers: groups.length, wallMs: s.wallMs, handsCompleted: tot.completed, handsRequested: tables * hands, solverActions: tot.solver, scriptedFallbackActions: tot.scripted, solverShare: tot.solver / Math.max(1, tot.solver + tot.scripted), unavailableDecisions: tot.unavailable, staleDecisions: tot.stale, suspendedHands: tot.suspended, handsPerSecond: s.handsPerSecond, actionsPerSecond: s.actionsPerSecond, decisionCycleMsP50: s.decisionCycleMsP50, decisionCycleMsP95Worst: s.decisionCycleMsP95Worst, ackMismatches: s.ackMismatches, resources: s.resources };
    process.stderr.write('D ' + tables + ' tables: ' + Math.round(s.wallMs) + ' ms, hands ' + tot.completed + '/' + tables * hands + ', solver ' + tot.solver + ' / scripted ' + tot.scripted + ', cycle p50 ' + s.decisionCycleMsP50 + ' ms, p95(worst worker) ' + s.decisionCycleMsP95Worst + ' ms\n');
  }
  const text = JSON.stringify(doc, null, 2); if (args.out) { fs.mkdirSync(path.dirname(args.out), { recursive: true }); fs.writeFileSync(args.out, text); } else console.log(text);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
