using System; using System.IO;
// usage: WgcPngCheck <out.png> <width> <height>   writes a deterministic BGRA test pattern: B=x*7, G=y*5, R=(x+y)*3 (mod 256)
static class P { static int Main(string[] a) { int w = int.Parse(a[1]), h = int.Parse(a[2]); var b = new byte[w * h * 4];
  for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) { int i = (y * w + x) * 4; b[i] = (byte)(x * 7); b[i + 1] = (byte)(y * 5); b[i + 2] = (byte)((x + y) * 3); b[i + 3] = 0; }
  File.WriteAllBytes(a[0], EightMax.Workbench.Wgc.PngWriter.Encode(b, w, h)); return 0; } }
