'use strict';
/* Train the eight-seat 25 BB preflop push/fold study and return a prepared study.
 * Uses the native EightMax CLI when given (EIGHTMAX_TEST_CLI on Linux, native\mwcli.exe on Windows), otherwise the
 * JavaScript reference engine (slow: ~4,000 updates/s). The trained state is cached by update count. */
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), cp = require('node:child_process');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js');

function cliPath() {
  if (process.env.EIGHTMAX_TEST_CLI && fs.existsSync(process.env.EIGHTMAX_TEST_CLI)) return process.env.EIGHTMAX_TEST_CLI;
  const exe = path.join(__dirname, '..', 'native', 'mwcli.exe');
  if (process.platform === 'win32' && fs.existsSync(exe)) return exe;
  return null;
}
function trainStudy(updates, options = {}) {
  const cfg = options.name || options.example || 'preflop8', cacheDir = options.cacheDir || path.join(os.tmpdir(), 'eightmax-study-cache');
  const prepared = A.prepare(EM, { config: options.config || A.EXAMPLES[cfg], iterations: updates, timeMs: 600000, strategyBudgetMiB: options.budgetMiB });
  const cli = options.forceJs ? null : cliPath();
  fs.mkdirSync(cacheDir, { recursive: true });
  const state = path.join(cacheDir, cfg + '-' + updates + (cli ? '-native' : '-js') + '.state');
  let backend;
  if (fs.existsSync(state)) { prepared.game.importNative(fs.readFileSync(state)); backend = cli ? 'native-cli-cpu (cached state)' : 'javascript-reference-cpu (cached state)'; }
  else if (cli) {
    const spec = path.join(cacheDir, cfg + '-' + updates + '.spec.json'), tmp = state + '.tmp' + process.pid;
    fs.writeFileSync(spec, JSON.stringify(A.nativeJob(prepared, 'train').spec));
    const r = cp.spawnSync(cli, [spec, String(updates), String(options.threads || 4), tmp, String(options.budgetMiB ? Math.max(512, options.budgetMiB * 2) : 512)], { encoding: 'utf8', timeout: 600000 });
    if (r.status !== 0) throw new Error('Native training failed: ' + (r.stderr || r.stdout || r.status));
    // 0.26: a run that filled its memory budget exits 0 but is SHORTER than requested; 0.25 used it as if complete. Refuse it (use trainStudyLazy with a larger budget).
    try { const run = require('../src/strategy-budget.js').interpretNativeRun(JSON.parse(r.stdout.trim().split('\n').pop()), updates); if (!run.complete) { fs.rmSync(tmp, { force: true }); const e = new Error('Native study is ' + run.status + ': ' + run.reason + '. Use trainStudyLazy with a larger budget (see docs/STRATEGY-MEMORY.md).'); e.code = run.status; throw e; } } catch (e) { if (e.code === 'memory-limited' || e.code === 'cancelled' || e.code === 'invalid') throw e; }
    fs.renameSync(tmp, state); prepared.game.importNative(fs.readFileSync(state)); backend = 'native-cli-cpu';
  } else { prepared.game.iterate(updates); fs.writeFileSync(state, Buffer.from(prepared.game.exportNative())); backend = 'javascript-reference-cpu'; }
  return { prepared, backend, updates: prepared.game.iterations, statePath: state, EM };
}

/* 0.26: the old synchronous path imported the whole native state into the JavaScript heap and, worse, accepted a run that had stopped at its memory ceiling.
 * trainStudyLazy trains under an explicit, planner-checked budget (resuming at a larger one when permitted), verifies the state, and answers lookups from the
 * state file through a bounded cache - the strategy table is never copied into Node. Preflop information sets only (what PreflopTreeSource reads). */
async function trainStudyLazy(updates, options = {}) {
  const N = require('./native-training.cjs'), { nativeBackedGame } = require('../src/strategy-store.js');
  const cfg = options.name || options.example || 'preflop8', cacheDir = options.cacheDir || path.join(os.tmpdir(), 'eightmax-study-cache'), cli = options.cli || cliPath();
  if (!cli) { const e = new Error('Lazy native studies need the native EightMax engine (EIGHTMAX_TEST_CLI or native/mwcli.exe)'); e.code = 'no-engine'; throw e; }
  const prepared = A.prepare(EM, { config: options.config || A.EXAMPLES[cfg], iterations: updates, timeMs: 600000, strategyBudgetMiB: 32 });
  fs.mkdirSync(cacheDir, { recursive: true });
  const specFile = path.join(cacheDir, cfg + '.spec.json'); fs.writeFileSync(specFile, JSON.stringify(A.nativeJob(prepared, 'train').spec));
  const r = await N.ensureStudy({ cli, specFile, updates, budgetMiB: options.budgetMiB || 1024, threads: options.threads || 2, dir: cacheDir, name: cfg, autoEscalate: options.autoEscalate !== false, system: options.system, cacheBytes: options.cacheBytes, signal: options.signal });
  const base = prepared.game; prepared.game = nativeBackedGame(base, prepared, r.store);
  return { prepared, backend: 'native-cli-cpu (lazy state file)', updates: r.meta.updatesDone, requestedUpdates: updates, complete: r.meta.status === 'complete', meta: r.meta, store: r.store, statePath: r.store.file, EM };
}
module.exports = { trainStudy, trainStudyLazy, cliPath };
