"""0.29.0 developer utility: regenerate desktop/COMPONENT-VERSIONS.json from the SHIPPED binaries (hashes are never typed by hand).
Run after rebuilding desktop/bin/*.exe. The version comes from src/engine.js; facts about how each binary was built are stated below."""
import hashlib, json, re
from pathlib import Path
root = Path(__file__).resolve().parent.parent
v = re.search(r"const VERSION='([0-9.]+)'", (root / 'src/engine.js').read_text()).group(1)
sha = lambda p: hashlib.sha256((root / p).read_bytes()).hexdigest()
mono = 'Mono mcs 6.8.0.105 against the .NET Framework 4.8 REFERENCE assemblies (-nostdlib, /usr/lib/mono/4.8-api), -langversion:5 -platform:x64 -optimize+. 0.26-0.28 compiled against Mono\'s own class library, which bound String.Split(char) to an overload .NET Framework lacks: every request failed with HTTP 400 on Windows.'
dotnet = '.NET SDK 8.0.134 on Linux, net8.0-windows10.0.22000.0, win-x64 self-contained single file, EnableWindowsTargeting'
c = {
 'desktop/DesktopHost.cs': {'version': v, 'rebuilt': True, 'binary': 'desktop/bin/EightMaxWorkbench.exe', 'sha256': sha('desktop/bin/EightMaxWorkbench.exe'), 'compiler': mono, 'executedOnWindows': False,
   'origin': '0.28 host (HTTP framing, structured errors, request log, concurrent connections, graceful shutdown, dashboard tools) + 0.27 WGC routing through CaptureService'},
 'desktop/CaptureService.cs': {'version': v, 'rebuilt': True, 'binary': 'desktop/bin/EightMaxWorkbench.exe', 'alsoCompiledInto': 'desktop/bin/EightMaxCapture.exe', 'compiler': mono, 'executedOnWindows': False,
   'origin': '0.27 (GrabWgc: identity checked before the helper runs, no fallback) + 0.28 (per-thread DPI awareness, WindowExists) + 0.29 (HelperRoot lookup)'},
 'desktop/capture/EightMaxCapture.cs': {'version': v, 'rebuilt': True, 'binary': 'desktop/bin/EightMaxCapture.exe', 'sha256': sha('desktop/bin/EightMaxCapture.exe'), 'compiler': mono, 'executedOnWindows': False,
   'origin': '0.28 staged self-test (closed-window handle fix)'},
 'desktop/wgc/Program.cs': {'version': v, 'rebuilt': True, 'binary': 'desktop/bin/EightMaxWgc.exe', 'sha256': sha('desktop/bin/EightMaxWgc.exe'), 'compiler': dotnet, 'executedOnWindows': False,
   'origin': '0.28 persistent sessions + self-test (SelfTest.cs) + 0.27 PngWriter.cs and resolution-changed refusal',
   'versionIdentification': 'File properties show ' + v + ' (read on the Windows CI runner for the 0.29 candidate) and EightMaxWgc.exe --version prints it. Correction to 0.28: the missing version there came from project metadata missing in the build, not from building on Linux.'},
 'desktop/wgc/PngWriter.cs': {'version': v, 'rebuilt': True, 'binary': 'desktop/bin/EightMaxWgc.exe', 'compiler': dotnet, 'executedOnWindows': False, 'origin': '0.27; bit-exact output verified on Linux by tests/wgc-027.test.cjs'},
 'runtime/node/node.exe': {'version': 'v22.23.5', 'rebuilt': False, 'binary': 'runtime/node/node.exe', 'sha256': sha('runtime/node/node.exe'), 'source': 'official nodejs.org win-x64 archive (runtime/node/PROVENANCE.json)', 'executedOnWindows': False},
 'native/mwcli.exe': {'version': 'EightMax 5.1 build 7d08acc7eb4577ee', 'rebuilt': False, 'binary': 'native/mwcli.exe', 'sha256': sha('native/mwcli.exe'), 'source': 'unchanged supplied engine', 'executedOnWindows': True,
   'windowsEvidence': '2000-update CPU self-test passed on the target PC with 0.26.0 (hardware-facts.json, 2026-11-18)'},
}
doc = {'format': 'eightmax-component-versions', 'version': 2, 'appVersion': v,
 'note': 'Every Windows executable built for this release identifies itself as ' + v + ' (file ProductVersion, or --version for EightMaxWgc.exe). All were BUILT on Linux from the shipped sources. Never executed on Windows (except the unchanged native engine, see its entry).',
 'components': c}
(root / 'desktop/COMPONENT-VERSIONS.json').write_text(json.dumps(doc, indent=2) + '\n')
print('components written for', v)
