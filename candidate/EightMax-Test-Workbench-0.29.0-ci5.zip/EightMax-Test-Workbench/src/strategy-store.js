'use strict';
/* EightMax Test Workbench 0.26: lazy, bounded, streaming access to a native EMMW4 strategy state.
 *
 * WHY (defect found in 0.25): a trained native state was read with game.importNative(), which copies EVERY row into the JavaScript heap
 * (a 183 MiB state needed about 1.1 GB of Node memory and was refused above the engine's 256 MiB JavaScript strategy cap), so the
 * studies the native engine can train (hundreds of thousands of updates) could not be used for decisions.
 *
 * This module never loads the table. open() makes ONE chunked pass over the file that
 *   - verifies the whole-file CRC32 recorded in the header (corrupt / truncated / trailing data are refused),
 *   - reads the tree table (parent, action slot, kind, actor, street length, action count of each state),
 *   - records where the rows of every state live (offset + row count) - an index, not the data.
 * rowsAt(state) then reads only that state's rows (a few hundred KB) through a byte-bounded LRU cache.
 * Resident memory = index + cache budget, independent of the state size.
 *
 * Layout read here (see native/source/MW-PROTOCOL.md; checked against lib_wide.js importExternal):
 *   "EMMW4\0\0\0" | u32 headerLen | header JSON | u32 stateCount | stateCount x (u32 parent, u8 slot, u8 kind, u8 actor, u8 length, u8 k)
 *   | u32 rowCount | rowCount x (u32 state, u16 hand, 5 x u8 card+1, u8 k, k x f64 regret, k x f64 average [, u32 sync when rowSync=1])
 * Only the plain row layout is read. Grouped-key states (rowKeys=1) are refused with code 'unsupported-layout'. */
const fs = require('node:fs'), zlib = require('node:zlib');

class StoreError extends Error { constructor(code, message) { super(message); this.code = code; this.name = 'StoreError'; } }
const MAGIC = Buffer.from('EMMW4\0\0\0', 'latin1');
const DEFAULT_CHUNK = 8 << 20, DEFAULT_CACHE = 64 << 20;

function readExact(fd, pos, len) {
  const b = Buffer.allocUnsafe(len); let got = 0;
  while (got < len) { const n = fs.readSync(fd, b, got, len - got, pos + got); if (n <= 0) throw new StoreError('truncated', 'State file ended early (' + (pos + got) + ' of ' + (pos + len) + ' bytes)'); got += n; }
  return b;
}

class StrategyStore {
  /** options: chunkBytes, cacheBytes (hard bound on cached row tables), verify (default true: CRC the whole file) */
  static open(file, options = {}) {
    const s = new StrategyStore(file, options); try { s._build(); } catch (e) { s.close(); throw e; } return s;
  }
  constructor(file, options) {
    this.file = file; this.chunkBytes = Math.max(64 << 10, options.chunkBytes || DEFAULT_CHUNK); this.cacheBytes = Math.max(0, options.cacheBytes === undefined ? DEFAULT_CACHE : options.cacheBytes);
    this.verify = options.verify !== false; this.fd = fs.openSync(file, 'r'); this.size = fs.fstatSync(this.fd).size;
    this.cache = new Map(); this.cacheUsed = 0;
    this.counters = { hits: 0, misses: 0, evictions: 0, uncachedOversize: 0, bytesRead: 0, peakCacheBytes: 0 };
  }
  close() { if (this.fd !== null && this.fd !== undefined) { try { fs.closeSync(this.fd); } catch (e) { /* already closed */ } this.fd = null; this.cache.clear(); this.cacheUsed = 0; } }

  _build() {
    const t0 = process.hrtime.bigint(); const fd = this.fd;
    if (this.size < 20) throw new StoreError('truncated', 'State file is too small to be a native state');
    const top = readExact(fd, 0, 12);
    if (!top.subarray(0, 8).equals(MAGIC)) throw new StoreError('bad-magic', 'Not a native external-sampling (EMMW4) state');
    const hl = top.readUInt32LE(8); if (hl < 2 || hl > (1 << 20) || 12 + hl + 8 > this.size) throw new StoreError('bad-header', 'Invalid state header length');
    let head; try { head = JSON.parse(readExact(fd, 12, hl).toString('utf8')); } catch (e) { throw new StoreError('bad-header', 'State header is not valid JSON'); }
    if (head.rowSync !== undefined || head.rowKeys !== undefined) throw new StoreError('unsupported-layout', 'Only the plain EMMW4 row layout can be read lazily; import this state in full instead');
    for (const f of ['iterations', 'trainingDeals', 'stateVisits']) if (!Number.isSafeInteger(head[f]) || head[f] < 0) throw new StoreError('bad-header', 'Invalid counter ' + f);
    this.header = head; this.bodyStart = 12 + hl;
    // pass 1: CRC over everything after the header, chunked
    if (this.verify) {
      let crc = 0, pos = this.bodyStart; const buf = Buffer.allocUnsafe(Math.min(this.chunkBytes, Math.max(1, this.size - pos)));
      while (pos < this.size) { const n = fs.readSync(fd, buf, 0, Math.min(buf.length, this.size - pos), pos); if (n <= 0) throw new StoreError('truncated', 'State file ended early'); crc = zlib.crc32(buf.subarray(0, n), crc); pos += n; this.counters.bytesRead += n; }
      const hex = (crc >>> 0).toString(16).padStart(8, '0');
      if (head.rowCrc32 === undefined) throw new StoreError('no-checksum', 'State has no row checksum; refusing to trust it');
      if (head.rowCrc32 !== hex) throw new StoreError('checksum', 'State checksum mismatch (stored ' + head.rowCrc32 + ', computed ' + hex + '): the file is corrupt or truncated');
    }
    // tree table
    let p = this.bodyStart; const sc = readExact(fd, p, 4).readUInt32LE(0); p += 4;
    if (sc < 1 || p + sc * 9 + 4 > this.size) throw new StoreError('bad-table', 'Invalid state-table size');
    const tb = readExact(fd, p, sc * 9); p += sc * 9;
    this.stateCount = sc; this.parent = new Uint32Array(sc); this.slot = new Uint8Array(sc); this.kind = new Uint8Array(sc); this.actor = new Uint8Array(sc); this.length = new Uint8Array(sc); this.k = new Uint8Array(sc);
    // child lookup: compressed rows over parents on the preflop street only (the lazy reader serves preflop information sets),
    // typed arrays instead of a Map so the index stays small even for trees with millions of postflop states
    const cnt = new Uint32Array(sc + 1);
    for (let i = 0; i < sc; i++) {
      const o = i * 9, par = tb.readUInt32LE(o);
      this.parent[i] = par; this.slot[i] = tb[o + 4]; this.kind[i] = tb[o + 5]; this.actor[i] = tb[o + 6]; this.length[i] = tb[o + 7]; this.k[i] = tb[o + 8];
      if (i === 0 ? par !== 0xffffffff : par >= i) throw new StoreError('bad-table', 'Invalid parent link in state table');
    }
    for (let i = 1; i < sc; i++) if (this.length[this.parent[i]] === 0) cnt[this.parent[i] + 1]++;
    for (let i = 0; i < sc; i++) cnt[i + 1] += cnt[i];
    this.childStart = cnt; this.childList = new Uint32Array(cnt[sc]); const fill = cnt.slice(0, sc);
    for (let i = 1; i < sc; i++) if (this.length[this.parent[i]] === 0) this.childList[fill[this.parent[i]]++] = i;
    const rowCount = readExact(fd, p, 4).readUInt32LE(0); p += 4; this.rowCount = rowCount; this.rowsStart = p;
    // pass 2: index rows (runs of consecutive rows of the same state)
    const runState = [], runOffs = [], runCounts = [], runLens = []; let carry = Buffer.alloc(0), pos = p, seen = 0, curState = -1, curOff = 0, curN = 0, curLen = 0;
    const flush = () => { if (curN) { runState.push(curState); runOffs.push(curOff); runCounts.push(curN); runLens.push(curLen); curN = 0; } };
    const buf = Buffer.allocUnsafe(this.chunkBytes); this.preflopRows = 0;
    while (seen < rowCount) {
      const n = pos < this.size ? fs.readSync(fd, buf, 0, Math.min(buf.length, this.size - pos), pos) : 0;
      if (n <= 0) throw new StoreError('truncated', 'State ended after ' + seen + ' of ' + rowCount + ' rows');
      this.counters.bytesRead += n; const data = carry.length ? Buffer.concat([carry, buf.subarray(0, n)]) : buf.subarray(0, n); const base = pos - carry.length; pos += n;
      let o = 0;
      while (seen < rowCount && o + 12 <= data.length) {
        const k = data[o + 11], len = 12 + 16 * k; if (o + len > data.length) break;
        const st = data.readUInt32LE(o); if (st >= sc || this.kind[st] !== 0 || this.k[st] !== k) throw new StoreError('bad-row', 'Row ' + seen + ' does not match the tree table');
        if (this.length[st] === 0) {   // preflop information sets are indexed; later-street rows are only validated and counted
          this.preflopRows++;
          if (st !== curState || curLen !== len || curOff + curN * len !== base + o) { flush(); curState = st; curOff = base + o; curLen = len; }
          curN++;
        }
        o += len; seen++;
      }
      carry = Buffer.from(data.subarray(o));
    }
    flush();
    if (carry.length || pos !== this.size) throw new StoreError('trailing', 'State has trailing or partial data after the last row');
    // runs of one state, in file order, addressed through a counting-sorted index
    const nr = runState.length; this.runOff = Float64Array.from(runOffs); this.runCount = Uint32Array.from(runCounts); this.runLen = Uint16Array.from(runLens);
    const rc = new Uint32Array(sc + 1); for (let i = 0; i < nr; i++) rc[runState[i] + 1]++; for (let i = 0; i < sc; i++) rc[i + 1] += rc[i];
    this.runStart = rc; this.runList = new Uint32Array(nr); const rf = rc.slice(0, sc); for (let i = 0; i < nr; i++) this.runList[rf[runState[i]]++] = i;
    this.runTotal = nr;
    this.openMs = Number(process.hrtime.bigint() - t0) / 1e6;
    this.indexBytesEstimate = sc * 17 + this.runTotal * 22 + (sc + 1) * 8;
  }

  /** Tree state id for an action-path string such as "r", "r1", "r120". null if the path is not in the state table. */
  stateOf(path) {
    if (typeof path !== 'string' || path[0] !== 'r') return null;
    let s = 0;
    for (let i = 1; i < path.length; i++) {
      const c = path[i], slot = c === 'c' ? 7 : (c >= '0' && c <= '7' ? +c : -1); if (slot < 0 || this.length[s] !== 0) return null;
      let next = -1; for (let j = this.childStart[s]; j < this.childStart[s + 1]; j++) { const ch = this.childList[j]; if (this.slot[ch] === slot) { next = ch; break; } }
      if (next < 0) return null; s = next;
    }
    return s;
  }

  /** All stored rows of one tree state: Map "hand|cards" -> {regret: Float64Array, average: Float64Array}. Bounded LRU cache. */
  rowsAt(state) {
    const hit = this.cache.get(state);
    if (hit) { this.counters.hits++; this.cache.delete(state); this.cache.set(state, hit); return hit.rows; }
    this.counters.misses++; const rows = new Map(); let bytes = 64;
    for (let j = this.runStart[state]; j < this.runStart[state + 1]; j++) {
      const run = this.runList[j], off = this.runOff[run], n = this.runCount[run], len = this.runLen[run], b = readExact(this.fd, off, n * len); this.counters.bytesRead += b.length;
      for (let i = 0; i < n; i++) {
        const o = i * len, k = b[o + 11], reg = new Float64Array(k), avg = new Float64Array(k);
        for (let a = 0; a < k; a++) { reg[a] = b.readDoubleLE(o + 12 + 8 * a); avg[a] = b.readDoubleLE(o + 12 + 8 * (k + a)); }
        rows.set(b.readUInt16LE(o + 4) + '|' + b[o + 6] + ',' + b[o + 7] + ',' + b[o + 8] + ',' + b[o + 9] + ',' + b[o + 10], { regret: reg, average: avg }); bytes += 96 + 16 * k;
      }
    }
    if (bytes > this.cacheBytes) { this.counters.uncachedOversize++; return rows; }
    while (this.cacheUsed + bytes > this.cacheBytes && this.cache.size) { const [k0, v0] = this.cache.entries().next().value; this.cache.delete(k0); this.cacheUsed -= v0.bytes; this.counters.evictions++; }
    this.cache.set(state, { rows, bytes }); this.cacheUsed += bytes; if (this.cacheUsed > this.counters.peakCacheBytes) this.counters.peakCacheBytes = this.cacheUsed;
    return rows;
  }

  /** Normalised average strategy of one hand at one path, exactly as EightMax's averageAt returns it; null when the information set was never stored. */
  averageAt(path, seat, handIndex) {
    const st = this.stateOf(path); if (st === null || this.kind[st] !== 0 || this.actor[st] !== seat) return null;
    const row = this.rowsAt(st).get(handIndex + '|0,0,0,0,0'); if (!row) return null;
    const k = row.average.length, out = new Float64Array(k); let total = 0;
    for (let a = 0; a < k; a++) { out[a] = Math.max(0, row.average[a]); total += out[a]; }
    for (let a = 0; a < k; a++) out[a] = total ? out[a] / total : 1 / k;
    return out;
  }
  /** Which fraction of a state's hands have stored rows (information-set coverage of one node). */
  coverageAt(path, rangeSize) { const st = this.stateOf(path); if (st === null) return null; let n = 0; for (let j = this.runStart[st]; j < this.runStart[st + 1]; j++) n += this.runCount[this.runList[j]]; return { state: st, rows: n, rangeSize, share: rangeSize ? n / rangeSize : null }; }
  stats() { return { file: this.file, sizeBytes: this.size, iterations: this.header.iterations, stateCount: this.stateCount, rowCount: this.rowCount, indexedRuns: this.runTotal, preflopRows: this.preflopRows, openMs: this.openMs, indexBytesEstimate: this.indexBytesEstimate, cacheBytes: this.cacheBytes, cacheUsedBytes: this.cacheUsed, cachedNodes: this.cache.size, ...this.counters }; }
}

/** Makes a lookup-only "game" for TreeStudy: the tree shape (view) comes from the cheap JavaScript game; strategies come from the store. */
function nativeBackedGame(baseGame, prepared, store) {
  const index = new Map(); prepared.spec.hands.forEach((rows, seat) => index.set(seat, new Map(rows.map((r, i) => [r[0], i]))));
  return {
    view: (steps) => baseGame.view(steps),
    averageAt(path, publicCards, seat, hand) {
      if (publicCards && publicCards.length) throw new StoreError('unsupported-street', 'Lazy lookup covers preflop information sets only');
      const i = index.get(seat) && index.get(seat).get(hand.id); if (i === undefined) return null; return store.averageAt(path, seat, i);
    },
    get iterations() { return store.header.iterations; }, get limitReached() { return false; }, get strategyMiB() { return store.cacheUsed / 1048576; }, store, lazy: true
  };
}

module.exports = { StrategyStore, StoreError, nativeBackedGame };
