/* EightMax Test Workbench 0.28.0 - test-results model for the dashboard (pure functions; unit-tested in tests/test-results-028.test.cjs).
   Turns the collector summary (windows/Collect-TestResults.ps1 -SummaryOnly, format eightmax-test-results-summary) into what the
   "Test results" panel shows, and maps technical failures onto plain-language explanations. Technical detail is always kept. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.WorkbenchTestResults=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const EXPLAIN=[
 {id:'wgc',test:/wgc|graphics-capture|windows graphics capture/i,title:'Windows Graphics Capture unavailable',text:'The capture helper could not initialize or is unsupported.'},
 {id:'capture',test:/capture|selftest|target-lost|target-minimized|monitors-listed|windows-listed|print-?window/i,title:'Screen capture failed',text:'The target window was closed or capture could not continue.'},
 {id:'shutdown',test:/shutdown|orphan|process-left|process cleanup/i,title:'Desktop shutdown failed',text:'The desktop host or a helper process did not stop by itself. The technical log shows which process was left running.'},
 {id:'memory',test:/memory|budget|ram|out-of-memory/i,title:'Insufficient memory',text:'The requested study exceeds the current safe memory budget.'},
 {id:'solver',test:/native|mwcli|solver|reviewed cpu|checkpoint|resume/i,title:'Solver unavailable',text:'The native solver failed to start or did not respond.'},
 {id:'desktop',test:/desktop|http|request|api|session-required|invalid-request|invalid-host|chunked|expectation|duplicate-header|malformed-header|proxy-form|host-busy|host-stopping|body-|bad request|framing|400|403/i,title:'Desktop connection failed',text:'A local API request was rejected. Open diagnostics to view the request and error code.'},
 {id:'missing',test:/missing-executable|missing|not present|extract the complete/i,title:'Program file missing',text:'A required program file is missing. Extract the complete ZIP again.'},
 {id:'integrity',test:/integrity|checksum|sha256/i,title:'Release files changed',text:'Some release files do not match their checksums. Extract the complete ZIP again.'},
 {id:'timeout',test:/timeout|timed out|exceeded/i,title:'A check took too long',text:'A step did not finish in time and was stopped. Close other heavy programs and run the check again.'}
];
function explain(failure){
 const f=failure||{};const hay=[f.errorClass,f.errorCode,f.code,f.check,f.stage,f.test,f.detail].filter(Boolean).join(' ');
 if(f.errorClass==='timeout')return {id:'timeout',title:EXPLAIN[8].title,text:EXPLAIN[8].text,technical:String(f.detail||'')};
 if(f.errorClass==='missing-executable'||f.errorClass==='missing-dependency')return {id:'missing',title:EXPLAIN[6].title,text:EXPLAIN[6].text,technical:String(f.detail||'')};
 for(const e of EXPLAIN)if(e.test.test(hay))return {id:e.id,title:e.title,text:e.text,technical:String(f.detail||'')};
 return {id:'other',title:'A check failed',text:'Open the report for the technical details.',technical:String(f.detail||'')};
}
function num(v){return Number.isFinite(v)?v:0;}
/** Validates a collector summary and returns the view model for the panel. Throws on an unrecognised document. */
function view(summary){
 if(!summary||summary.format!=='eightmax-test-results-summary'||summary.version!==1)throw Error('Unsupported test-results summary');
 const tests=Array.isArray(summary.tests)?summary.tests:[];
 const last=tests[0]||null;
 const failures=[];for(const t of tests.slice(0,10))for(const f of (Array.isArray(t.failures)?t.failures:[]).slice(0,20))failures.push({test:t.test,at:t.at,check:f.check,code:f.errorCode||null,...explain({...f,test:t.test})});
 return {
  lastTestAt:last?last.at:null,lastTest:last?last.test:null,lastStatus:last?(last.passed?'pass':'fail'):'none',
  lastPassed:last?num(last.passedChecks):0,lastFailed:last?num(last.failed):0,lastSkipped:last?num(last.skipped):0,
  testsCompleted:num(summary.testsCompleted),testsPassed:num(summary.testsPassed),testsFailed:num(summary.testsFailed),
  checksPassed:num(summary.checksPassed),checksFailed:num(summary.checksFailed),checksSkipped:num(summary.checksSkipped),
  reportLocation:last?last.report:null,failures:failures.slice(0,30),appVersion:summary.appVersion||null,collectedAt:summary.collectedAtUtc||null
 };
}
/** Plain-language message for any error thrown by a desktop request (keeps the code and request for diagnostics). */
function errorMessage(e){const code=e&&e.code?String(e.code):'';const x=explain({errorCode:code,detail:e&&e.message});return x.title+': '+x.text+(code?' (code '+code+')':'')+(e&&e.message?' Technical detail: '+String(e.message).slice(0,400):'');}
return {EXPLAIN,explain,view,errorMessage};
});
