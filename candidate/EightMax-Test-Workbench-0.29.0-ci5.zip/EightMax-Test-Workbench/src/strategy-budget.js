/* EightMax Test Workbench 0.26: strategy-memory budgets and honest interpretation of native training results.
 *
 * Defects found in 0.25 (reproduced with the bundled native engine, 250,000-update eight-seat linked preflop study):
 *   1. A native run that fills its memory budget STOPS EARLY BUT EXITS WITH STATUS 0 and reports limitReached:true. 0.25 ignored the flag:
 *      a 256 MiB run silently produced a study of ~67,000 updates that was used as if it had 250,000.
 *   2. The memory figure was a hard-coded constant at every call site (256 in nativeJob / nativeTrainer / solver-factory), not a setting.
 *   3. The JavaScript adapter accepted 8..1024 MiB while the JavaScript engine itself refuses anything above 256 MiB, and a native state
 *      was loaded entirely into the Node heap (see strategy-store.js).
 * This module is pure (no I/O) so the dashboard, the workers and the tests share one set of rules. */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.WorkbenchStrategyBudget = factory(); })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MiB = 1048576;
  const PROFILES = Object.freeze([256, 512, 1024, 2048, 4096]);
  const NATIVE_MIN_MIB = 64, NATIVE_MAX_MIB = 16384;      // refuse values outside what the native CLI documents as sensible
  const JS_ENGINE_MAX_MIB = 256;                           // EightMax 5.1 JavaScript reference engine limit (measured: "must be between 1 and 256 MiB")
  const NATIVE_SCRATCH_MIB = 128;                          // measured scratch/transient allowance beyond the table (tablePeakBytes vs capacity, scratchBudgetBytes)

  /** How much memory the OTHER parts of the application and Windows need. Conservative; adjustable through options. */
  function reserveMiB(totalMiB, o = {}) { return Math.max(o.minReserveMiB === undefined ? 3072 : o.minReserveMiB, Math.round(totalMiB * (o.reserveFraction === undefined ? 0.20 : o.reserveFraction))); }

  /**
   * Which native strategy-memory budgets may be used on this machine.
   * input: { totalRamBytes, freeRamBytes, requestedMiB?, hostMiB? (dashboard + Node workers + lazy strategy cache, default 768), concurrentNative? (default 1), minReserveMiB?, reserveFraction? }
   * A budget is a CEILING on the native table. The check is on the worst case: budget + scratch must fit beside the reserve,
   * the host and (for free memory) a safety headroom. Nothing is permitted merely because it is a known profile.
   */
  function plan(input) {
    const total = Math.floor((input.totalRamBytes || 0) / MiB), free = Math.floor((input.freeRamBytes === undefined ? input.totalRamBytes : input.freeRamBytes) / MiB);
    if (!(total > 0)) return { ok: false, code: 'unknown-ram', reason: 'System memory could not be read; no budget is permitted until it can', profiles: [] };
    const host = input.hostMiB === undefined ? 768 : input.hostMiB, conc = Math.max(1, input.concurrentNative || 1), reserve = reserveMiB(total, input);
    const totalCeiling = Math.floor((total - reserve - host) / conc) - NATIVE_SCRATCH_MIB;         // would fit if the machine were otherwise idle
    const freeCeiling = Math.floor((free - Math.min(reserve, Math.round(free * 0.35)) - host) / conc) - NATIVE_SCRATCH_MIB;   // fits in what is free right now
    const ceiling = Math.max(0, Math.min(totalCeiling, freeCeiling));
    const profiles = PROFILES.map((m) => ({ miB: m, permitted: m <= ceiling, why: m <= ceiling ? 'fits (table + ' + NATIVE_SCRATCH_MIB + ' MiB scratch + host ' + host + ' MiB + Windows reserve ' + reserve + ' MiB)' : (m > totalCeiling ? 'exceeds total RAM minus reserve (' + totalCeiling + ' MiB available to the native table)' : 'not enough FREE memory right now (' + freeCeiling + ' MiB available to the native table)') }));
    const out = { ok: true, totalMiB: total, freeMiB: free, reserveMiB: reserve, hostMiB: host, concurrentNative: conc, ceilingMiB: ceiling, totalCeilingMiB: totalCeiling, freeCeilingMiB: freeCeiling, profiles, recommendedMiB: Math.max(0, ...profiles.filter((p) => p.permitted).map((p) => p.miB)) || 0 };
    if (input.requestedMiB !== undefined) {
      const r = input.requestedMiB;
      if (!Number.isInteger(r) || r < NATIVE_MIN_MIB || r > NATIVE_MAX_MIB) Object.assign(out, { ok: false, code: 'out-of-range', reason: 'Budget must be a whole number from ' + NATIVE_MIN_MIB + ' to ' + NATIVE_MAX_MIB + ' MiB' });
      else if (r > ceiling) Object.assign(out, { ok: false, code: r > totalCeiling ? 'exceeds-ram' : 'exceeds-free-ram', reason: r + ' MiB is not safe here: at most ' + ceiling + ' MiB can be given to the native table (' + total + ' MiB RAM, ' + free + ' MiB free, ' + reserve + ' MiB kept for Windows)' });
      else out.grantedMiB = r;
    }
    return out;
  }

  /** The adapter's check for the in-JavaScript reference engine (distinct from the native budget). */
  function validateJsBudget(mib) { return mib === undefined || (Number.isInteger(mib) && mib >= 8 && mib <= JS_ENGINE_MAX_MIB); }

  /**
   * Interpret the final JSON line printed by mwcli. NEVER reports success for a run that hit its memory ceiling.
   * info: parsed JSON; requestedUpdates: what was asked (cumulative target). Returns { status, complete, ... }.
   *   status: 'complete' | 'memory-limited' | 'cancelled' | 'invalid'
   */
  function interpretNativeRun(info, requestedUpdates) {
    if (!info || typeof info !== 'object' || !Number.isFinite(info.iterations)) return { status: 'invalid', complete: false, reason: 'The native engine did not report an iteration count' };
    const done = info.iterations, base = { updatesDone: done, updatesRequested: requestedUpdates, tableMiB: info.tableMiB, tablePeakMiB: info.tablePeakBytes === undefined ? null : +(info.tablePeakBytes / MiB).toFixed(1), processPeakRssMiB: info.processPeakRssMiB, budgetMiB: info.budgetMiB, rows: info.rows, wallSeconds: info.wallSeconds, studyId: info.studyId };
    if (info.cancelled) return { ...base, status: 'cancelled', complete: false, reason: 'Training was cancelled after ' + done + ' updates' };
    if (info.limitReached) return { ...base, status: 'memory-limited', complete: false, reason: 'The strategy table filled the ' + info.budgetMiB + ' MiB budget after ' + done + ' of ' + requestedUpdates + ' updates; the study is shorter than requested' };
    if (done < requestedUpdates) return { ...base, status: 'invalid', complete: false, reason: 'Native run stopped at ' + done + ' of ' + requestedUpdates + ' updates without reporting a reason' };
    return { ...base, status: 'complete', complete: true };
  }

  /** Next budget to try after a memory-limited run, or null when the planner permits nothing larger. */
  function nextBudget(currentMiB, planResult) { const bigger = (planResult.profiles || []).filter((p) => p.permitted && p.miB > currentMiB).map((p) => p.miB); return bigger.length ? Math.min(...bigger) : null; }

  /**
   * 0.28.0: how many native solver jobs may run AT THE SAME TIME without exhausting system memory, given what is free now
   * (other programs included). Each job needs its table budget + scratch; the Windows reserve and the host are kept free.
   * input: { totalRamBytes, freeRamBytes, perJobMiB, maxJobs?, hostMiB?, minReserveMiB?, reserveFraction? }
   * Returns { jobs (0..maxJobs), perJobMiB, ceilingPerJobMiB, reason }. jobs 0 means: do not start another native job now.
   */
  function nativeConcurrency(input) {
    const maxJobs = Math.max(1, Math.min(16, input.maxJobs || 4)), per = input.perJobMiB;
    if (!Number.isInteger(per) || per < NATIVE_MIN_MIB || per > NATIVE_MAX_MIB) return { jobs: 0, perJobMiB: per, code: 'out-of-range', reason: 'Per-job budget must be a whole number from ' + NATIVE_MIN_MIB + ' to ' + NATIVE_MAX_MIB + ' MiB' };
    let jobs = 0, last = null;
    for (let n = 1; n <= maxJobs; n++) { const p = plan({ ...input, concurrentNative: n, requestedMiB: per }); last = p; if (!p.ok) break; jobs = n; }
    const one = plan({ ...input, concurrentNative: 1 });
    return { jobs, perJobMiB: per, ceilingPerJobMiB: one.ok ? one.ceilingMiB : 0, code: jobs ? 'ok' : (last && last.code) || 'insufficient-memory',
      reason: jobs ? jobs + ' simultaneous native job(s) of ' + per + ' MiB fit beside the Windows reserve and the host' : 'Insufficient memory: even one ' + per + ' MiB native job exceeds the current safe memory budget (' + (one.ok ? one.ceilingMiB : 0) + ' MiB available per job)' };
  }

  /**
   * 0.28.0: system memory pressure 0..1 that accounts for OTHER programs. 0.26 measured only this process's RSS against a fixed
   * budget, so ten tables could keep growing while Windows itself ran out of memory.
   */
  function systemPressure(freeBytes, totalBytes, o = {}) {
    if (!(totalBytes > 0) || !(freeBytes >= 0)) return 0;
    const reserve = (o.reserveMiB === undefined ? Math.min(2048, Math.max(1024, Math.round(totalBytes / MiB * 0.1))) : o.reserveMiB) * MiB;
    const headroom = freeBytes - reserve;
    if (headroom <= 0) return 1;
    return headroom < 512 * MiB ? 0.92 : headroom < 1024 * MiB ? 0.8 : 0;
  }

  return { MiB, PROFILES, NATIVE_MIN_MIB, NATIVE_MAX_MIB, JS_ENGINE_MAX_MIB, NATIVE_SCRATCH_MIB, reserveMiB, plan, validateJsBudget, interpretNativeRun, nextBudget, nativeConcurrency, systemPressure };
});
