/* EightMax Test Workbench 0.28.0 - "Test results & Windows checks" panel. Desktop-host features need START-DESKTOP.cmd;
   in a plain browser the panel explains which .cmd file to double-click instead. */
(function(){
'use strict';
const $=id=>document.getElementById(id),M=window.WorkbenchTestResults;
const panel=$('tr-panel');if(!panel||!M)return;
let secret=null;
function token(){if(secret)return secret;const d=window.WorkbenchDesktop&&window.WorkbenchDesktop.fromPage&&window.WorkbenchDesktop.fromPage(window);secret=d&&d.secret?d.secret:null;return secret;}
async function host(method,path,body){
 const t=token();if(!t){const e=Error('Open the workbench with START-DESKTOP.cmd to use this button.');e.code='no-desktop-host';throw e;}
 const r=await fetch('http://127.0.0.1:48713'+path,{method,headers:{'X-EightMax-Session':t,'X-EightMax-Step':'dashboard-test-results',...(body===undefined?{}:{'Content-Type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body),credentials:'omit',cache:'no-store'});
 let j=null;try{j=await r.json();}catch(e){}
 if(!r.ok){const e=Error((j&&j.error)||('HTTP '+r.status));e.code=j&&j.code;e.status=r.status;e.requestId=j&&j.requestId;throw e;}
 return j;
}
function status(text,bad){const s=$('tr-status');s.textContent=text;s.classList.toggle('bad',!!bad);}
function render(v){
 $('tr-last-at').textContent=v.lastTestAt?new Date(v.lastTestAt).toLocaleString():'No test reports found yet';
 $('tr-last-status').textContent=v.lastStatus==='pass'?'PASSED':v.lastStatus==='fail'?'FAILED':'—';$('tr-last-status').className=v.lastStatus==='pass'?'good':v.lastStatus==='fail'?'bad':'';
 $('tr-last-name').textContent=v.lastTest||'—';$('tr-passed').textContent=v.lastPassed;$('tr-failed').textContent=v.lastFailed;$('tr-skipped').textContent=v.lastSkipped;
 $('tr-location').textContent=v.reportLocation?('%LOCALAPPDATA%\\EightMax-Test-Workbench\\'+v.reportLocation.replace(/\//g,'\\')):'—';
 $('tr-totals').textContent=v.testsCompleted+' reports: '+v.testsPassed+' passed, '+v.testsFailed+' failed · checks '+v.checksPassed+' passed, '+v.checksFailed+' failed, '+v.checksSkipped+' skipped';
 const list=$('tr-failures');list.textContent='';
 if(!v.failures.length){const li=document.createElement('li');li.textContent='No failed checks in the collected reports.';list.appendChild(li);}
 for(const f of v.failures){const li=document.createElement('li');const b=document.createElement('b');b.textContent=f.title+': ';li.appendChild(b);li.appendChild(document.createTextNode(f.text+' '));
  const d=document.createElement('details');const s=document.createElement('summary');s.textContent='Technical detail ('+f.test+' · '+(f.code||f.check)+')';d.appendChild(s);const pre=document.createElement('pre');pre.textContent=f.technical;d.appendChild(pre);li.appendChild(d);list.appendChild(li);}
}
async function refresh(){status('Reading the latest test reports…');try{render(M.view(await host('GET','/api/desktop/test-results')));status('Test reports read. Nothing was run.');}catch(e){status(M.errorMessage(e),true);}}
async function launch(tool,label){status('Starting '+label+'…');try{const r=await host('POST','/api/desktop/launch',{tool});status(r.message);}catch(e){status(e.code==='no-desktop-host'?'Double-click '+label+' in the release folder (this page is not connected to the desktop host).':e.code==='host-must-be-closed'?e.message:M.errorMessage(e),true);}}
const click=id=>{const el=$(id);if(el)el.click();};
const open=id=>{const el=$(id);if(el)el.click();};
const wire=(id,fn)=>{const el=$(id);if(el)el.addEventListener('click',fn);};
wire('tr-nav',()=>{panel.hidden=false;panel.scrollIntoView({behavior:'smooth'});if(token())refresh();else status('Not connected to the desktop host: buttons that run Windows checks need START-DESKTOP.cmd. You can still double-click RUN-RELEASE-ACCEPTANCE.cmd and COLLECT-TEST-RESULTS.cmd in the release folder.');});
wire('tr-close',()=>{panel.hidden=true;});
wire('tr-refresh',refresh);
wire('tr-start-sim',()=>click('start'));wire('tr-stop-sim',()=>click('pause'));wire('tr-emergency',()=>click('stop'));
wire('tr-load-strategy',()=>{open('study-nav');click('cpu-open');});wire('tr-start-study',()=>{open('study-nav');click('desktop-run-native');});wire('tr-stop-study',()=>{open('study-nav');click('desktop-cancel-native');});
wire('tr-capture-settings',()=>open('cap-nav'));wire('tr-export-diagnostics',()=>{open('diagnostics-nav');click('diagnostics-export');});
wire('tr-test-capture',()=>launch('capture-check','RUN-CAPTURE-CHECK.cmd'));wire('tr-test-wgc',()=>launch('wgc-check','RUN-WGC-CHECK.cmd'));
wire('tr-windows-checks',()=>launch('windows-checks','RUN-WINDOWS-CHECKS.cmd'));wire('tr-hardware',()=>launch('hardware-check','RUN-HARDWARE-CHECK.cmd'));
wire('tr-release',()=>launch('release-acceptance','RUN-RELEASE-ACCEPTANCE.cmd'));wire('tr-collect',()=>launch('collect-results','COLLECT-TEST-RESULTS.cmd'));wire('tr-export-zip',()=>launch('collect-results','COLLECT-TEST-RESULTS.cmd'));
wire('tr-open-folder',()=>launch('open-results-folder','the results folder'));
})();
