'use strict';
// 0.29.0: solver-in-the-loop latency work. 0.27's ten-table benchmark D showed a ~1.6 s worst-worker P95 decision cycle; measured in
// 0.29: it is the cost of training a fresh postflop study in the decision path (0.5-2 s per spot on a 4-core container), not CPU
// contention (capping concurrent native solves did not lower it) and not cross-worker duplication (no spot was trained twice by two
// workers). Concurrent requests for a study that is still training now share that training instead of starting another.
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const EM = require('../tests/load-solver.cjs'), A = require('../src/study-adapter.js'), ST = require('../src/solver-tree.js'), SS = require('../src/solver-service.js'), HS = require('../src/hand-state.js'), E = require('../src/engine.js');
const { screen, engine } = require('./screen-util.cjs');
function flopSpot(seed = 5, skipPlayers = 0) {
  const t = new E.Table(1, seed), e = engine(); let seq = 0; t.startHand(); e.ingest(screen(t, seq++));
  for (let i = 0; i < 8; i++) { if (i < skipPlayers) t.execute(t.request('fold', 0, 0), 0); else t.execute(t.request(t.legal().toCall > 0 ? 'call' : 'check', 0, 0), 0); if (t.status === 'playing' && t.street === 'preflop') e.ingest(screen(t, seq++)); }
  const r = e.ingest(screen(t, seq++)); assert.ok(r.accepted, JSON.stringify(r.issues)); return { t, e, state: r.state, seq: () => seq++ };
}

test('two concurrent requests for the same untrained postflop spot train it once and both get the same study answer', async () => {
  let trainings = 0;
  const trainer = async (prepared, it) => { trainings++; await new Promise((r) => setTimeout(r, 60)); prepared.game.iterate(it); };
  const src = new ST.PostflopStudySource({ EM, adapter: A, iterations: 1200, trainer });
  const { state } = flopSpot(5, 4), req = SS.requestFromState(state);
  const [a, b] = await Promise.all([src.decide(req), src.decide(req)]);
  assert.equal(trainings, 1, 'the second request waited for the first training'); assert.equal(src.info().coalesced, 1); assert.equal(src.info().built, 1);
  assert.equal(a.status, b.status); assert.deepEqual(a.probabilities || null, b.probabilities || null);
  assert.ok(src.info().buildMsMax >= 50);
});
test('a failed training is reported to every waiting request and nothing is cached', async () => {
  const trainer = async () => { await new Promise((r) => setTimeout(r, 30)); throw new Error('engine stopped'); };
  const src = new ST.PostflopStudySource({ EM, adapter: A, iterations: 1200, trainer });
  const { state } = flopSpot(5, 4), req = SS.requestFromState(state);
  const [a, b] = await Promise.all([src.decide(req), src.decide(req)]);
  assert.equal(a.status, 'error'); assert.equal(b.status, 'error'); assert.match(b.reason, /engine stopped/); assert.equal(src.info().cached, 0);
});
test('native trainings can be capped across workers and processes, and each training is logged with its wait and solve time', async () => {
  const T = require('../tools/studies.cjs'), d = fs.mkdtempSync(path.join(os.tmpdir(), 'em-cap-')), log = path.join(d, 'log.jsonl');
  const src = fs.readFileSync(path.join(__dirname, '../tools/studies.cjs'), 'utf8');
  assert.match(src, /fs\.mkdirSync\(d\); return d;/, 'atomic mkdir slots'); assert.match(src, /EIGHTMAX_MAX_NATIVE_TRAINING/);
  assert.equal(typeof T.nativeTrainer('/nonexistent', { maxConcurrent: 1, slotDir: path.join(d, 'slots'), log }), 'function');
});
