// EightMax 5.9: mwcli --response spec.json state request.json [memoryMiB]
// Trained response of every requested seat against a trained state (response58.hpp: the measure; response59.hpp: its
// evaluation; response_stats59.hpp: the confidence statements of the summary).
// request.json: {"seats":[...], "responseDeals":N, "seed":S, "threads":T, "samples":M, "exact":false, "exactMaxVisits":V,
//                "timeLimitMs":ms, "saveStates":"path prefix", "futureActions":..., "parallelSeats":P,
//                "confidence":0.95, "analyses":1, "evaluationSeed":E, "randomStreams":"5.9"}
//   seats           default: every seat
//   responseDeals   sampled deals of response training per seat (default 200000); one walk per deal, for this seat only
//   samples         evaluation deals per seat (default 200000; rounded up to blocks of 1024), independent of the training
//   futureActions   auto (default) | enumerate | sample: whether the other seats' actions are enumerated or sampled in
//                   the evaluation walk (auto: enumerated when the betting tree has at most 4,096 states)
//   exact           also evaluate the response exactly and compute the exact best response (small games only)
//   saveStates      writes "<prefix><seat>.state": an ordinary state file whose policy "average" is (response, sigma of
//                   the others) and whose policy "current" is sigma. It is NOT a training state.
//   parallelSeats   seats handled side by side (default 1). The result does not depend on it.
//   confidence      5.9: familywise confidence of summary.simultaneous and summary.pooledIndependent (default 0.95;
//                   from 0.5 to 0.999999)
//   analyses        5.9: the number of PRESPECIFIED response analyses of this trained state (other response budgets
//                   or seeds) among which the largest bound will be reported (default 1). The error probability is
//                   divided by it, so the largest of the bounds is still a statement at `confidence`.
//   evaluationSeed  5.9: seed of the evaluation streams (default: seed). The response training uses `seed` only, so the
//                   same response can be evaluated on other, independent deals.
//   randomStreams   5.9: "5.9" (default: counter-based Philox4x64-10 streams, response59.hpp) | "5.8" (the 5.8
//                   streams: the sampled estimates then have the bits 5.8 printed)
// Each seat is an independent copy of the trained state, so the seats are independent of one another.
namespace rsp59 {
static double num(const JV *v, double def = NAN) { return v && v->type == J_NUM ? v->num : def; }
static std::string bitsOf(double v) { uint64_t u; std::memcpy(&u, &v, sizeof u); char b[20]; std::snprintf(b, sizeof b, "%016llx", (unsigned long long)u); return b; }   // IEEE 754 bit pattern (no reader can re-round it)
static int run(int argc, char **argv) {
  if (argc < 5 || argc > 6) { std::fprintf(stderr, "usage: mwcli --response spec.json state request.json [memoryMiB]\n"); return 2; }
  std::vector<unsigned char> spec = slurp(argv[2]), reqBytes = slurp(argv[4]); char err[512] = ""; double mib = 4096;
  if (argc == 6 && !numberArg(argv[5], mib)) { std::fprintf(stderr, "error: bad memoryMiB\n"); return 2; }
  if (spec.empty()) { std::fprintf(stderr, "cannot read %s\n", argv[2]); return 2; }
  size_t skip = reqBytes.size() >= 3 && reqBytes[0] == 0xEF && reqBytes[1] == 0xBB && reqBytes[2] == 0xBF ? 3 : 0;
  JV *req = json_parse((const char *)reqBytes.data() + skip, reqBytes.size() - skip, err, sizeof err);
  if (!req || req->type != J_OBJ) { std::fprintf(stderr, "error: request: %s\n", req ? "must be a JSON object" : err); if (req) json_free(req); return 2; }
  struct FreeReq { JV *v; ~FreeReq() { json_free(v); } } freeReq{req};
  static const char *known[] = {"seats", "responseDeals", "seed", "threads", "samples", "exact", "exactMaxVisits", "timeLimitMs", "saveStates", "futureActions", "parallelSeats", "confidence", "analyses", "evaluationSeed", "randomStreams"};
  for (int i = 0; i < req->n; i++) { bool ok = false; for (const char *k : known) ok |= !std::strcmp(k, req->keys[i]); if (!ok) { std::fprintf(stderr, "error: unknown request field \"%s\"\n", req->keys[i]); return 2; } }
  auto whole = [&](const char *name, long long lo, long long hi, long long def, long long &out) {
    const JV *v = jget(req, name); if (!v) { out = def; return true; }
    if (v->type != J_NUM || !std::isfinite(v->num) || std::floor(v->num) != v->num || v->num < (double)lo || v->num > (double)hi) { std::fprintf(stderr, "error: %s must be a whole number from %lld to %lld\n", name, lo, hi); return false; }
    out = (long long)v->num; return true;
  };
  long long deals, seed, threads, samples, exactVisits, timeMs, parallelSeats, analyses, evalSeed;
  if (!whole("parallelSeats", 1, 8, 1, parallelSeats) || !whole("analyses", 1, 1000, 1, analyses)) return 2;
  if (!whole("responseDeals", 1, 640000000LL, 200000, deals) || !whole("seed", 0, 4294967295LL, 1, seed) || !whole("threads", 1, 256, 1, threads) ||
      !whole("samples", 1024, 1000000000LL, 200000, samples) || !whole("exactMaxVisits", 1000, 2000000000LL, 2000000000LL, exactVisits) || !whole("timeLimitMs", 100, 86400000, 3600000, timeMs)) return 2;
  if (!whole("evaluationSeed", 0, 4294967295LL, seed, evalSeed)) return 2;
  double confidence = 0.95;
  if (const JV *c = jget(req, "confidence")) { if (c->type != J_NUM || !(c->num >= 0.5) || !(c->num <= 0.999999)) { std::fprintf(stderr, "error: confidence must be a number from 0.5 to 0.999999\n"); return 2; } confidence = c->num; }
  const JV *rs = jget(req, "randomStreams"); std::string streams = "5.9";
  if (rs) { if (rs->type != J_STR || (std::strcmp(rs->str, "5.9") && std::strcmp(rs->str, "5.8"))) { std::fprintf(stderr, "error: randomStreams must be \"5.9\" or \"5.8\"\n"); return 2; } streams = rs->str; }
  const JV *ex = jget(req, "exact"); if (ex && ex->type != J_BOOL) { std::fprintf(stderr, "error: exact must be true or false\n"); return 2; }
  const bool exact = ex && ex->num != 0;
  const JV *sv = jget(req, "saveStates"); if (sv && sv->type != J_STR) { std::fprintf(stderr, "error: saveStates must be a string\n"); return 2; }
  const JV *fa = jget(req, "futureActions"); std::string future = "auto";
  if (fa) { if (fa->type != J_STR || (std::strcmp(fa->str, "auto") && std::strcmp(fa->str, "enumerate") && std::strcmp(fa->str, "sample"))) { std::fprintf(stderr, "error: futureActions must be auto, enumerate or sample\n"); return 2; } future = fa->str; }
  const std::string prefix = sv ? sv->str : ""; const std::string text((const char *)spec.data(), spec.size());
  auto load = [&](MW *&m) {
    uint64_t size = 0; std::string why; FILE *f = openCheckpoint(argv[3], size, why);
    if (!f) { std::fprintf(stderr, "error: cannot read state '%s': %s\n", argv[3], why.c_str()); return false; }
    const int st = mw_load_stream(f, size, text.c_str(), mib, -1, &m, err, sizeof err, nullptr, nullptr); std::fclose(f);
    if (st != 200) { std::fprintf(stderr, "error: state '%s' was refused (status %d): %s\n", argv[3], st, err[0] ? err : "unreadable"); return false; }
    return true;
  };
  MW *probe = nullptr; if (!load(probe)) return 1;
  JB info; jb_init(&info); mw_info(probe, &info); JV *iv = json_parse(info.s, info.n, err, sizeof err); jb_free(&info);
  JV *sj = json_parse(text.c_str(), text.size(), err, sizeof err);   // the state was accepted for this spec, so the spec parses
  const int players = (int)num(sj ? jget(sj, "n") : nullptr, 0), batch = std::max(1, (int)num(sj ? jget(sj, "batchDeals") : nullptr, 1));
  const JV *icmSpec = sj ? jget(sj, "icm") : nullptr; const bool icm = icmSpec && icmSpec->type == J_OBJ;   // the utility of the study: ICM tournament equity, else chips
  if (sj) json_free(sj);
  const long long sourceUpdates = (long long)num(iv ? jget(iv, "iterations") : nullptr, 0), sourceDeals = (long long)num(iv ? jget(iv, "trainingDeals") : nullptr, 0);
  if (iv) json_free(iv);
  mw_free(probe);
  if (players < 2 || players > 8) { std::fprintf(stderr, "error: the state reports no player count\n"); return 1; }
  std::vector<int> seats;
  if (const JV *s = jget(req, "seats")) {
    if (s->type != J_ARR || s->n < 1 || s->n > 8) { std::fprintf(stderr, "error: seats must be an array of 1 to 8 seat numbers\n"); return 2; }
    for (int i = 0; i < s->n; i++) { const JV *x = s->items[i]; if (x->type != J_NUM || std::floor(x->num) != x->num || x->num < 0 || x->num >= players) { std::fprintf(stderr, "error: seats must hold whole numbers from 0 to %d\n", players - 1); return 2; }
      for (int q : seats) if (q == (int)x->num) { std::fprintf(stderr, "error: seats lists a seat twice\n"); return 2; }
      seats.push_back((int)x->num); }
  } else for (int p = 0; p < players; p++) seats.push_back(p);
  const long long updates = (deals + batch - 1) / batch;
  if (updates > 10000000LL) { std::fprintf(stderr, "error: responseDeals needs %lld updates of %d deals; the engine trains at most 10,000,000 updates per state (nothing was started)\n", updates, batch); return 2; }
  JB o; jb_init(&o);
  char alphaText[40]; std::snprintf(alphaText, sizeof alphaText, "%.15g", 1 - confidence);   // 1 - 0.95 is 0.050000000000000044 in binary arithmetic: the level is the decimal number the request means
  const double alphaFamily = std::strtod(alphaText, nullptr), alphaSeat = alphaFamily / (double)analyses / (double)seats.size();   // (B) of response_stats59.hpp: fixed before anything is measured
  jb_printf(&o, "{\"tool\":\"mwcli response 5.9\",\"schema\":\"response-5.9\",\"build\":\"%s\",\"version\":\"%s\",\"players\":%d,\"sourceUpdates\":%lld,\"sourceDeals\":%lld,\"batchDeals\":%d,\"responseDealsPerSeat\":%lld,\"responseUpdatesPerSeat\":%lld,\"evaluationSamplesRequested\":%lld,\"seed\":%lld,\"threads\":%lld,\"parallelSeats\":%lld,\"exactRequested\":%s",
            EM_BUILD_ID, EM_VERSION, players, sourceUpdates, sourceDeals, batch, updates * batch, updates, samples, seed, threads, parallelSeats, exact ? "true" : "false");
  jb_printf(&o, ",\"evaluationSeed\":%lld,\"randomStreams\":\"%s\",\"confidence\":%.17g,\"analyses\":%lld,\"perSeatAlpha\":%.17g", evalSeed, streams.c_str(), confidence, analyses, alphaSeat);
  jb_puts(&o, ",\"measure\":\"trained response: per seat, the gain of the average strategy of a response training against the other seats' average strategies\",\"direction\":\"each seat gain is a lower bound of that seat's best-response gain; their sum is a lower bound of NashConv inside the study's betting abstraction. Not an upper bound; not exploitability for more than two seats or an ICM utility.\",\"seats\":[");
  double sum = 0, var = 0, sumFloor = 0, exactSum = 0, exactBr = 0; bool allSampled = true, allExact = exact; const auto t0 = std::chrono::steady_clock::now();
  // One seat = one fresh load of the state, its own response training and its own evaluation streams, so the seats
  // are independent of one another and of the order and number of threads that run them ("parallelSeats").
  struct SeatOut { std::string json, error; int exitCode = 0; double mean = NAN, se = NAN, exactGain = NAN, brGain = NAN, variance = NAN, n = 0, width = NAN; bool sampled = false, exactOk = false, within = false; };
  std::vector<SeatOut> outs(seats.size());
  std::mutex loadMu;
  auto runSeat = [&](size_t si) {
    SeatOut &R = outs[si]; const int seat = seats[si]; char err[512] = ""; JB o; jb_init(&o); struct FreeO { JB *b; ~FreeO() { jb_free(b); } } freeO{&o};
    auto fail = [&](int code, const std::string &text) { R.exitCode = code; R.error = text; };
    MW *m = nullptr;
    { std::lock_guard<std::mutex> l(loadMu);   // load() reports through the shared error buffer
      uint64_t size = 0; std::string why; FILE *f = openCheckpoint(argv[3], size, why);
      if (!f) { fail(1, std::string("cannot read state '") + argv[3] + "': " + why); return; }
      const int st = mw_load_stream(f, size, text.c_str(), mib, -1, &m, err, sizeof err, nullptr, nullptr); std::fclose(f);
      if (st != 200) { fail(1, std::string("state '") + argv[3] + "' was refused (status " + std::to_string(st) + "): " + (err[0] ? err : "unreadable")); return; } }
    struct FreeM { MW *m; ~FreeM() { mw_free(m); } } freeM{m};
    char rq[256]; std::snprintf(rq, sizeof rq, "{\"seat\":%d,\"seed\":%lld}", seat, seed);
    JB b; jb_init(&b); int st = mw_response_begin(m, rq, std::strlen(rq), &b, err, sizeof err);
    if (st != 200) { jb_free(&b); fail(1, "seat " + std::to_string(seat) + ": " + err); return; }
    jb_printf(&o, "{\"seat\":%d,\"begin\":%.*s", seat, (int)b.n, b.s); jb_free(&b);
    const auto a0 = std::chrono::steady_clock::now();
    if (!mw_train(m, updates, (int)threads, nullptr, nullptr, nullptr, err, sizeof err)) { fail(1, "seat " + std::to_string(seat) + ": response training failed: " + err); return; }
    const double trainSeconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - a0).count();
    jb_init(&b); st = mw_response_end(m, &b, err, sizeof err);
    if (st != 200) { jb_free(&b); fail(1, "seat " + std::to_string(seat) + ": " + err); return; }
    jb_printf(&o, ",\"trainingSeconds\":%.6f,\"end\":%.*s", trainSeconds, (int)b.n, b.s); jb_free(&b);
    { JB mi; jb_init(&mi); mw_info(m, &mi); JV *v = json_parse(mi.s, mi.n, err, sizeof err); jb_free(&mi);
      if (v) { jb_puts(&o, ",\"tableMiB\":"); jb_printf(&o, "%.6f", num(jget(v, "tableMiB"), 0)); json_free(v); } }
    if (!prefix.empty()) {
      const std::string path = prefix + std::to_string(seat) + ".state"; SaveReport rep;
      saveWithReport(path.c_str(), [&](FILE *f) { return mw_write_stream(m, f, nullptr) > 0; }, rep);
      if (!rep.ok) { fail(4, "cannot write '" + path + "': " + rep.text()); return; }
      jb_puts(&o, ",\"savedState\":"); jb_str(&o, path.c_str());
    }
    char vq[384]; std::snprintf(vq, sizeof vq, "{\"samples\":%lld,\"seed\":%lld,\"threads\":%lld,\"timeLimitMs\":%lld,\"futureActions\":\"%s\",\"streams\":\"%s\",\"alpha\":%.17g}", samples, evalSeed, std::min<long long>(threads, 64), timeMs, future.c_str(), streams.c_str(), alphaSeat);
    jb_init(&b); volatile int cancel = 0; st = mw_response_value(m, vq, std::strlen(vq), &b, err, sizeof err, &cancel);
    if (st != 200) { jb_puts(&o, ",\"sampled\":{\"available\":false,\"reason\":"); jb_str(&o, err); jb_putc(&o, '}'); }
    else {
      jb_printf(&o, ",\"sampled\":%.*s", (int)b.n, b.s);
      JV *v = json_parse(b.s, b.n, err, sizeof err); const JV *g = v ? jget(v, "gain") : nullptr; R.mean = num(g ? jget(g, "mean") : nullptr); R.se = num(g ? jget(g, "stdErr") : nullptr);
      R.sampled = std::isfinite(R.mean) && std::isfinite(R.se);
      const JV *sx = v ? jget(v, "statistics") : nullptr; const JV *wn = sx ? jget(sx, "withinProvenRange") : nullptr;
      R.variance = num(sx ? jget(sx, "sampleVariance") : nullptr); R.n = num(sx ? jget(sx, "samples") : nullptr, 0); R.width = num(sx ? jget(sx, "provenSampleRange") : nullptr); R.within = wn && wn->type == J_BOOL && wn->num != 0;
      if (v) json_free(v);
    }
    jb_free(&b);
    if (exact) {
      double pv[2] = {NAN, NAN}, br[2] = {NAN, NAN}; std::string why; double exactSeconds = 0;
      for (int which = 0; which < 2 && why.empty(); which++) {
        char eq[400]; std::snprintf(eq, sizeof eq, "{\"method\":\"exact\",\"seats\":[%d],\"policy\":\"%s\",\"device\":\"cpu\",\"threads\":1,\"timeLimitMs\":%lld,\"maxVisits\":%lld,\"memoryMiB\":1024}", seat, which ? "current" : "average", timeMs, exactVisits);
        jb_init(&b); const auto e0 = std::chrono::steady_clock::now(); st = mw_response_gain(m, eq, std::strlen(eq), &b, err, sizeof err, &cancel);
        exactSeconds += std::chrono::duration<double>(std::chrono::steady_clock::now() - e0).count();
        if (st != 200) why = err;
        else { JV *v = json_parse(b.s, b.n, err, sizeof err); const JV *ss = v ? jget(v, "seats") : nullptr; const JV *s0 = ss && ss->type == J_ARR && ss->n == 1 ? ss->items[0] : nullptr;
          pv[which] = num(s0 ? jget(s0, "policyValue") : nullptr); br[which] = num(s0 ? jget(s0, "bestResponseValue") : nullptr); if (v) json_free(v);
          if (!std::isfinite(pv[which]) || !std::isfinite(br[which])) why = "the exact evaluator returned no value"; }
        jb_free(&b);
      }
      if (!why.empty()) { jb_puts(&o, ",\"exact\":{\"available\":false,\"reason\":"); jb_str(&o, why.c_str()); jb_putc(&o, '}'); }
      else {
        // average = (response, sigma_-seat); current = sigma. The best response to sigma_-seat is the same in both.
        R.exactGain = pv[0] - pv[1]; R.brGain = br[1] - pv[1]; R.exactOk = true;
        jb_printf(&o, ",\"exact\":{\"available\":true,\"policyValue\":%.17g,\"responseValue\":%.17g,\"gain\":%.17g,\"bestResponseValue\":%.17g,\"bestResponseValueFromResponseProfile\":%.17g,\"bestResponseGain\":%.17g,\"shareOfBestResponseGain\":", pv[1], pv[0], R.exactGain, br[1], br[0], R.brGain);
        if (R.brGain > 0) jb_printf(&o, "%.17g", R.exactGain / R.brGain); else jb_puts(&o, "null");
        jb_printf(&o, ",\"gainBits\":\"%s\",\"bestResponseGainBits\":\"%s\",\"seconds\":%.3f}", bitsOf(R.exactGain).c_str(), bitsOf(R.brGain).c_str(), exactSeconds);
      }
    }
    jb_putc(&o, '}');
    R.json.assign(o.s ? o.s : "", o.n);
  };
  { std::atomic<size_t> next{0}; std::vector<std::thread> pool; const size_t workers = (size_t)std::max<long long>(1, std::min<long long>(parallelSeats, (long long)seats.size()));
    auto body = [&] { for (size_t i; (i = next.fetch_add(1)) < seats.size();) runSeat(i); };
    for (size_t w = 1; w < workers; w++) pool.emplace_back(body);
    body(); for (auto &t : pool) t.join(); }
  for (size_t si = 0; si < seats.size(); si++) {
    const SeatOut &R = outs[si];
    if (R.exitCode) { std::fprintf(stderr, "error: %s\n", R.error.c_str()); jb_free(&o); return R.exitCode; }
    if (si) jb_putc(&o, ','); jb_putn(&o, R.json.data(), R.json.size());
    if (R.sampled) { sum += R.mean; var += R.se * R.se; sumFloor += std::max(0.0, R.mean - 1.6448536269514722 * R.se); } else allSampled = false;
    if (exact) { if (R.exactOk) { exactSum += R.exactGain; exactBr += R.brGain; } else allExact = false; }
  }
  jb_puts(&o, "]");
  const bool every = (int)seats.size() == players;
  // ---- 5.9 summary. Three kinds of numbers, kept apart: estimates (sumOfSeatGains), normal-approximation bounds
  // (sumOfNormalApproximationLowerBounds95 and its 5.8 name), and confidence statements with a proof (simultaneous,
  // pooledIndependent). See response_stats59.hpp and STATISTICAL-CHANGES-5.9.md.
  std::vector<stats59::Seat> stat(seats.size());
  size_t evaluated = 0;
  for (size_t si = 0; si < seats.size(); si++) { const SeatOut &R = outs[si]; stats59::Seat &q = stat[si]; q.seat = seats[si]; q.available = R.sampled && R.n >= 2 && std::isfinite(R.variance) && std::isfinite(R.width); q.within = R.within; q.mean = R.mean; q.variance = R.variance; q.n = R.n; q.width = R.width; evaluated += q.available; }
  const stats59::Simultaneous sim = stats59::simultaneous(stat, alphaFamily, (int)analyses); const stats59::Pooled pool = stats59::pooledIndependent(stat, alphaFamily, (int)analyses);
  auto numOrNull = [&](double v) { if (std::isfinite(v)) jb_printf(&o, "%.17g", v); else jb_puts(&o, "null"); };
  jb_printf(&o, ",\"summary\":{\"seatsRequested\":%zu,\"seatsEvaluated\":%zu,\"allSeats\":%s,\"unit\":\"%s\"", seats.size(), evaluated, every ? "true" : "false", icm ? "payout units (ICM tournament equity)" : "BB (chip EV)");
  if (allSampled) {
    jb_printf(&o, ",\"sumOfSeatGains\":{\"mean\":%.17g,\"stdErr\":%.17g,\"ci95\":[%.17g,%.17g],\"kind\":\"estimate of the sum of the response gains; stdErr and ci95 are normal approximations (not calibrated: see simultaneous)\"}", sum, std::sqrt(var), sum - 1.959963984540054 * std::sqrt(var), sum + 1.959963984540054 * std::sqrt(var));
    // 5.8 name and 5.9 name of the SAME number: the sum of the per-seat one-sided normal-approximation bounds.
    jb_printf(&o, ",\"sumOfSeatLowerBounds95\":%.17g,\"sumOfNormalApproximationLowerBounds95\":%.17g", sumFloor, sumFloor);
  }
  jb_puts(&o, ",\"deprecated\":{\"sumOfSeatLowerBounds95\":{\"since\":\"5.9\",\"status\":\"kept with its 5.8 value and meaning; will be removed in a later release\",\"sameNumberAs\":\"sumOfNormalApproximationLowerBounds95\",\"useInstead\":\"simultaneous.nashConvLowerBound\",\"why\":\"it adds per-seat one-sided NORMAL-APPROXIMATION bounds (mean - 1.645 standard errors, floored at 0). It is not a 95% statement about the sum: the normal approximation has no finite-sample guarantee (it fails with rare actions of large consequence), and k separate 95% statements do not hold together with 95%.\"}}");
  { // (B) simultaneous, by the union bound: the recommended statement
    jb_printf(&o, ",\"simultaneous\":{\"calculation\":\"%s\",\"recommended\":true,\"calibrated\":%s,\"reason\":", stats59::CALC_SIMULTANEOUS, sim.calibrated ? "true" : "false"); jb_str(&o, stats59::reasonText(sim.reason));
    jb_printf(&o, ",\"confidence\":%.17g,\"alpha\":%.17g,\"analyses\":%lld,\"alphaPerAnalysis\":%.17g,\"family\":{\"size\":%zu,\"seats\":[", confidence, alphaFamily, analyses, alphaFamily / (double)analyses, seats.size());
    for (size_t si = 0; si < seats.size(); si++) jb_printf(&o, "%s%d", si ? "," : "", seats[si]);
    jb_puts(&o, "],\"statement\":\"for every seat of the family at once: the gain of that seat's trained response is at least its responseGainLowerBound\"}");
    jb_printf(&o, ",\"allocation\":\"equal: alpha / analyses / seats\",\"perSeatAlpha\":%.17g,\"perSeatMethod\":\"%s\"", alphaSeat, stats59::METHOD_SEAT);
    jb_puts(&o, ",\"dependenceBetweenSeats\":\"none assumed: the union bound holds under any dependence between the seats' evaluations\"");
    jb_puts(&o, ",\"seats\":[");
    for (size_t i = 0; i < sim.seats.size(); i++) { const stats59::SeatBound &b = sim.seats[i];
      jb_printf(&o, "%s{\"seat\":%d,\"evaluated\":%s,\"alpha\":%.17g,\"half\":", i ? "," : "", b.seat, b.available ? "true" : "false", b.delta); numOrNull(b.half);
      jb_puts(&o, ",\"responseGainLowerBound\":"); numOrNull(b.lower); jb_puts(&o, ",\"bestResponseGainLowerBound\":"); numOrNull(b.floored); jb_putc(&o, '}'); }
    jb_printf(&o, "],\"complete\":%s,\"sumOfResponseGainsLowerBound\":", sim.complete ? "true" : "false"); numOrNull(sim.calibrated ? sim.sumOfGainsLower : NAN);
    jb_puts(&o, ",\"nashConvLowerBound\":"); numOrNull(sim.calibrated ? sim.bestResponseSumLower : NAN);
    jb_printf(&o, ",\"nashConvLowerBoundUsesEverySeat\":%s", every && sim.complete ? "true" : "false");
    jb_puts(&o, ",\"relationToNashConv\":\"NashConv is the sum over ALL seats of the best-response gains b_i, each >= 0 and >= the gain of any one response. With probability at least `confidence`: NashConv >= sum over the family of b_i >= nashConvLowerBound (the sum of max(0, responseGainLowerBound); a seat without a completed evaluation contributes 0). A LOWER bound inside the study's betting abstraction: it is not an upper bound, not exploitability, and a small value does not show that the strategy is close to equilibrium.\"");
    jb_puts(&o, ",\"assumptions\":[\"each seat's evaluation samples are independent and identically distributed with equal weights (one stream per block of deals)\",\"every sample lies in the proven payoff range (checked; a violation withdraws the statement)\",\"the sample count was fixed before any value was seen (a time limit fails the evaluation instead of shortening it)\",\"each response was fixed before its evaluation samples were drawn (training and evaluation use separate random streams)\",\"the pseudo-random numbers behave as independent uniform numbers\",\"the family (seats, confidence, analyses) was fixed in the request, before measurement\"]");
    jb_puts(&o, ",\"notCovered\":\"choosing among several runs after seeing their results (other seeds, budgets or sample counts) unless `analyses` counted them in advance\"}");
  }
  { // (C) pooled over independent seats
    jb_printf(&o, ",\"pooledIndependent\":{\"calculation\":\"%s\",\"recommended\":false,\"calibrated\":%s,\"reason\":", stats59::CALC_POOLED, pool.calibrated ? "true" : "false"); jb_str(&o, stats59::reasonText(pool.reason));
    jb_printf(&o, ",\"confidence\":%.17g,\"alpha\":%.17g,\"analyses\":%lld,\"family\":{\"seats\":%zu,\"subsets\":%lld,\"statement\":\"for every non-empty subset of the seats at once: the sum of the response gains of the subset is at least the subset's bound\"}", confidence, alphaFamily, analyses, seats.size(), pool.subsets);
    jb_puts(&o, ",\"allocation\":{\"perSubsetBernstein\":"); numOrNull(pool.deltaBernstein); jb_puts(&o, ",\"perSeatVariance\":"); numOrNull(pool.deltaVariance); jb_putc(&o, '}');
    jb_puts(&o, ",\"method\":\"Bernstein's inequality for sums of independent bounded variables, with every seat's true variance bounded from its sample variance (Maurer-Pontil 2009, Theorem 10); union bound over the subsets and the variance bounds\"");
    jb_puts(&o, ",\"dependenceBetweenSeats\":\"ASSUMED INDEPENDENT: each seat is evaluated on its own random streams. Without that assumption use simultaneous.\"");
    jb_printf(&o, ",\"complete\":%s,\"sumOfResponseGainsLowerBound\":", pool.complete ? "true" : "false"); numOrNull(pool.calibrated ? pool.allSeatsLower : NAN);
    jb_puts(&o, ",\"bestSubset\":{\"seats\":["); for (size_t i = 0; i < pool.bestSubset.size(); i++) jb_printf(&o, "%s%d", i ? "," : "", pool.bestSubset[i]);
    jb_puts(&o, "],\"sumOfResponseGainsLowerBound\":"); numOrNull(pool.calibrated ? pool.bestSubsetLower : NAN); jb_putc(&o, '}');
    jb_puts(&o, ",\"nashConvLowerBound\":"); numOrNull(pool.calibrated ? pool.bestResponseSumLower : NAN);
    jb_puts(&o, ",\"relationToNashConv\":\"with probability at least `confidence`, NashConv >= the sum of the best-response gains of the best subset >= nashConvLowerBound = max(0, bestSubset.sumOfResponseGainsLowerBound). A LOWER bound; never an upper bound.\"");
    jb_puts(&o, ",\"withSimultaneous\":\"a separate statement at the same confidence. Reporting the larger of simultaneous.nashConvLowerBound and this value is a statement at confidence 1 - 2 * alpha; request confidence 0.975 to report the larger one at 0.95.\"}");
  }
  jb_puts(&o, every ? ",\"reading\":\"sumOfSeatGains ESTIMATES a lower bound of NashConv (no confidence statement). simultaneous.nashConvLowerBound is the confidence statement to quote: distribution-free, all seats at once. pooledIndependent is tighter for several seats and additionally assumes independent seat evaluations. sumOfNormalApproximationLowerBounds95 (5.8: sumOfSeatLowerBounds95) adds per-seat normal-approximation bounds and is not a confidence statement about the sum.\""
                    : ",\"reading\":\"not every seat was evaluated: every sum is over the evaluated seats only. Each is still a lower bound of NashConv, because the seats left out contribute best-response gains that are never negative.\"");
  if (exact && allExact) { jb_printf(&o, ",\"exactSumOfSeatGains\":%.17g,\"exactSumOfBestResponseGains\":%.17g,\"exactShare\":", exactSum, exactBr); if (exactBr > 0) jb_printf(&o, "%.17g", exactSum / exactBr); else jb_puts(&o, "null");
    if (every) jb_puts(&o, ",\"exactNashConv\":"), jb_printf(&o, "%.17g", exactBr);
    // 5.9: the statements above against the exact values of the same responses (validation; small games only)
    int seatHolds = 0, seatChecked = 0; for (size_t i = 0; i < sim.seats.size() && sim.calibrated; i++) if (sim.seats[i].available) { seatChecked++; seatHolds += sim.seats[i].lower <= outs[i].exactGain; }
    double bestExact = 0; for (int s : pool.bestSubset) for (size_t i = 0; i < seats.size(); i++) if (seats[i] == s) bestExact += outs[i].exactGain;
    jb_printf(&o, ",\"againstExact\":{\"seatBoundsChecked\":%d,\"seatBoundsHolding\":%d,\"simultaneousHolds\":%s,\"simultaneousNashConvBoundHolds\":%s,\"pooledAllSeatsHolds\":%s,\"pooledBestSubsetHolds\":%s}", seatChecked, seatHolds,
              sim.calibrated ? (seatHolds == seatChecked ? "true" : "false") : "null", sim.calibrated ? (sim.bestResponseSumLower <= exactBr ? "true" : "false") : "null",
              pool.calibrated && pool.complete ? (pool.allSeatsLower <= exactSum ? "true" : "false") : "null", pool.calibrated && !pool.bestSubset.empty() ? (pool.bestSubsetLower <= bestExact ? "true" : "false") : "null"); }
  jb_printf(&o, "},\"wallSeconds\":%.3f,\"processPeakRssMiB\":%.1f}", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count(), peakRssMiB());
  std::printf("%.*s\n", (int)o.n, o.s); jb_free(&o);
  return 0;
}
}
