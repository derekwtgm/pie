#!/usr/bin/env python3
"""EightMax 5.9: the confidence statements of the trained-response measure against EXACT values.

Usage: coverage59.py final8 <release root> <5.8 mwcli> <5.9 mwcli> <fresh out dir>
       coverage59.py games  <release root> <5.9 mwcli> <fresh out dir>
       coverage59.py analyze <out dir>          (re-reads raw.jsonl and rewrites summary.json)

final8  The limitation 5.8 reported, and what replaces it. Game final8 (eight-handed ICM final table), training seed
        5851, 5,000 updates, response seeds 1..120, each with its own response (10,000 response deals per seat),
        204,800 evaluation deals with SAMPLED opponent actions, exact gain of the same response - the design of
        validation/5.8/convergence/unbiased58.py. Three arms:
          A  the unchanged 5.8 program                       (expected: 193 of 960 estimates beyond 4 reported
                                                              standard errors, as 5.8 reported)
          B  the 5.9 program with {"randomStreams":"5.8"}    (expected: the numbers of arm A, value for value)
          C  the 5.9 program with its own streams
        For every run of B and C: every seat's one-sided distribution-free bound, the simultaneous statement and the
        pooled statement against the exact values, recomputed by tools/independent_stats59.py and compared with what
        mwcli printed; and the 5.8 normal-approximation numbers against the same exact values.
games   Coverage on the 14 reference games (tools/games58.js), two training seeds (5901, 5902), 5,000 updates, one
        response per seat (200,000 response deals, response seed 59), its exact gain and the exact best-response gain
        of every seat (exact NashConv), and 100 INDEPENDENT evaluations of that one fixed response (evaluation seeds
        1..100, 51,200 deals each, sampled opponent actions). 2,800 simultaneous statements, 14,000 seat statements.
What is counted (fixed here, before measurement):
  seat       L_i > exact gain_i                                    (allowed with probability alpha / seats each)
  family     any seat of a run violated                            (allowed with probability 0.05)
  nashconv   sum of max(0, L_i) > exact NashConv                   (allowed with probability 0.05)
  pooled     the pooled bound of the best subset > exact sum of that subset; pooled all-seats bound > exact sum
  normal     per seat: mean - 1.645 SE > exact gain (nominal 5%); and the 5.8 sum of floored normal bounds > the exact
             sum of max(0, gain_i) (which 5.8 did not call a confidence statement; shown for comparison)
  share      bound / exact value (how much of the truth each bound certifies), medians per game
Reading: the distribution-free bounds are PROVEN to miss at most at their level; observing no violation agrees with the
proof and does not extend it. A violation rate clearly above the level would falsify an assumption (the proven range,
the independence of the evaluation samples) and is the outcome this experiment could have produced.
Each sub-command writes plan.json before anything is measured and refuses an existing output directory."""
import sys, json, subprocess, pathlib, time, statistics, math, platform, os, hashlib
def tool(root):
    sys.path.insert(0, str(root / 'source' / 'tools')); import independent_stats59 as S; return S
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def build(cli): return subprocess.run([cli, '--build-id'], capture_output=True, text=True).stdout.strip()
def seats_of(doc):
    rows = []
    for s in doc['seats']:
        x = s['sampled']; st = x.get('statistics') or {}; lb = x.get('lowerBound') or {}; e = s.get('exact') or {}
        rows.append({'seat': s['seat'], 'mean': x['gain']['mean'], 'stdErr': x['gain']['stdErr'], 'bits': x['gain']['gainBits'], 'variance': st.get('sampleVariance'), 'n': st.get('samples', x.get('samples')), 'width': st.get('provenSampleRange', x['bounded']['sampleRange']),
                     'within': st.get('withinProvenRange', x['bounded']['withinBounds']), 'half95TwoSided': x['bounded']['half'], 'printedLower': lb.get('responseGain'), 'printedAlpha': lb.get('alpha'), 'exactGain': e.get('gain'), 'exactBestResponseGain': e.get('bestResponseGain'), 'opponentActions': x['opponentActions']})
    return rows
def printed(doc):
    S = doc['summary']; sim = S.get('simultaneous') or {}; po = S.get('pooledIndependent') or {}
    return {'legacySum': S.get('sumOfSeatLowerBounds95'), 'simSum': sim.get('sumOfResponseGainsLowerBound'), 'simNash': sim.get('nashConvLowerBound'), 'poolAll': po.get('sumOfResponseGainsLowerBound'), 'poolBest': (po.get('bestSubset') or {}).get('sumOfResponseGainsLowerBound'), 'poolSubset': (po.get('bestSubset') or {}).get('seats')}
def run(cli, spec, state, request, mem='512'):
    q = pathlib.Path(str(state) + '.rq.json'); q.write_text(json.dumps(request)); p = subprocess.run([cli, '--response', str(spec), str(state), str(q), mem], capture_output=True, text=True)
    return (json.loads(p.stdout), None) if p.returncode == 0 else (None, p.stderr.strip()[-300:])

def judge(S, seats, exact, br, pr, alpha=0.05):
    """One run against exact values. seats: rows of seats_of (variance may be None for the 5.8 program)."""
    k = len(seats); out = {}
    z = [(s['mean'] - e) / s['stdErr'] if s['stdErr'] > 0 else (0.0 if s['mean'] == e else math.copysign(1e300, s['mean'] - e)) for s, e in zip(seats, exact)]
    out['beyond4'] = sum(1 for v in z if abs(v) > 4); out['beyond3'] = sum(1 for v in z if abs(v) > 3); out['maxAbsZ'] = max(abs(v) for v in z)
    out['outsideTwoSided'] = sum(1 for s, e in zip(seats, exact) if not (abs(s['mean'] - e) <= s['half95TwoSided']))
    out['normalSeatMiss'] = sum(1 for s, e in zip(seats, exact) if s['mean'] - 1.6448536269514722 * s['stdErr'] > e)
    legacy = sum(max(0.0, s['mean'] - 1.6448536269514722 * s['stdErr']) for s in seats); out['legacySum'] = legacy; out['legacyAboveExactPositiveSum'] = legacy > sum(max(0.0, e) for e in exact); out['legacyAboveNashConv'] = legacy > sum(br) if br else None
    if all(s['variance'] is not None for s in seats):
        mine = [{'mean': s['mean'], 'variance': s['variance'], 'n': float(s['n']), 'width': s['width']} for s in seats]
        sim = S.simultaneous(mine, alpha); po = S.pooled(mine, alpha)
        out['seatViolations'] = sum(1 for lo, e in zip(sim['lower'], exact) if lo > e); out['family'] = out['seatViolations'] > 0
        out['simSum'] = sim['sumOfResponseGainsLowerBound']; out['simNash'] = sim['nashConvLowerBound']; out['simSumViolated'] = sim['sumOfResponseGainsLowerBound'] > sum(exact); out['nashViolated'] = (sim['nashConvLowerBound'] > sum(br)) if br else None
        out['poolAll'] = po['allSeatsLower']; out['poolBest'] = po['bestSubsetLower']; out['poolAllViolated'] = po['allSeatsLower'] > sum(exact); out['poolBestViolated'] = po['bestSubsetLower'] > sum(exact[i] for i in po['bestSubset']); out['poolNashViolated'] = (po['nashConvLowerBound'] > sum(br)) if br else None
        # the program's own numbers must be these numbers
        out['printedDiffers'] = int(not S.close(pr['simSum'], sim['sumOfResponseGainsLowerBound'])) + int(not S.close(pr['simNash'], sim['nashConvLowerBound'])) + int(not S.close(pr['poolAll'], po['allSeatsLower'])) + int(not S.close(pr['poolBest'], po['bestSubsetLower'])) + int(not S.close(pr['legacySum'], legacy))
        out['exactSum'] = sum(exact); out['exactNashConv'] = sum(br) if br else None
    return out

def analyze(out):
    plan = json.loads((out / 'plan.json').read_text()); rows = [json.loads(l) for l in (out / 'raw.jsonl').read_text().splitlines() if l.strip()]; ok = [r for r in rows if 'error' not in r]
    res = {'kind': plan['kind'], 'rows': len(rows), 'errors': len(rows) - len(ok), 'groups': {}}
    key = (lambda r: r['arm']) if plan['kind'] == 'final8' else (lambda r: r['game'])
    def agg(rs):
        j = [r['judge'] for r in rs]; seats = sum(len(r['seats']) for r in rs); g = {'runs': len(rs), 'seatEstimates': seats, 'beyond4StdErr': sum(x['beyond4'] for x in j), 'beyond3StdErr': sum(x['beyond3'] for x in j), 'largestDistanceInStdErr': max(x['maxAbsZ'] for x in j),
             'outsideTwoSidedDistributionFree': sum(x['outsideTwoSided'] for x in j), 'normalOneSided95SeatBoundAboveExact': sum(x['normalSeatMiss'] for x in j), 'normalOneSided95SeatMissRate': sum(x['normalSeatMiss'] for x in j) / seats,
             'legacySumAboveExactSumOfPositiveGains': sum(1 for x in j if x['legacyAboveExactPositiveSum']), 'legacySumAboveExactNashConv': sum(1 for x in j if x.get('legacyAboveNashConv'))}
        if all('seatViolations' in x for x in j):
            g.update({'seatBoundAboveExact': sum(x['seatViolations'] for x in j), 'runsWithAnySeatViolation': sum(1 for x in j if x['family']), 'simultaneousSumAboveExact': sum(1 for x in j if x['simSumViolated']), 'nashConvBoundAboveExactNashConv': sum(1 for x in j if x['nashViolated']),
                      'pooledAllSeatsAboveExact': sum(1 for x in j if x['poolAllViolated']), 'pooledBestSubsetAboveExact': sum(1 for x in j if x['poolBestViolated']), 'pooledNashConvAboveExactNashConv': sum(1 for x in j if x['poolNashViolated']), 'printedNumbersDifferFromIndependentRecomputation': sum(x['printedDiffers'] for x in j)})
            nc = [x for x in j if x.get('exactNashConv')]
            if nc: g.update({'medianExactNashConv': statistics.median(x['exactNashConv'] for x in nc), 'medianShareOfExactNashConv': {'simultaneous': statistics.median(x['simNash'] / x['exactNashConv'] for x in nc), 'pooledIndependent': statistics.median(max(0.0, x['poolBest']) / x['exactNashConv'] for x in nc), 'legacyNormalSum': statistics.median(x['legacySum'] / x['exactNashConv'] for x in nc), 'exactSumOfResponseGains': statistics.median(x['exactSum'] / x['exactNashConv'] for x in nc)}})
        return g
    for k in sorted({key(r) for r in ok}): res['groups'][k] = agg([r for r in ok if key(r) == k])
    if plan['kind'] == 'games': res['all'] = agg(ok)
    if plan['kind'] == 'final8':
        a = {(r['responseSeed']): r for r in ok if r['arm'] == 'A'}; b = {(r['responseSeed']): r for r in ok if r['arm'] == 'B'}
        same = sum(1 for k in a if k in b and [(s['bits'], s['stdErr'], s['exactGain']) for s in a[k]['seats']] == [(s['bits'], s['stdErr'], s['exactGain']) for s in b[k]['seats']])
        res['armBEqualsArmA'] = {'runsCompared': len([k for k in a if k in b]), 'identical': same}
    (out / 'summary.json').write_text(json.dumps(res, indent=1)); return res

if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else ''
    if cmd == 'analyze': print(json.dumps(analyze(pathlib.Path(sys.argv[2]).resolve()), indent=1)); sys.exit(0)
    if cmd not in ('final8', 'games'): print(__doc__); sys.exit(2)
    root = pathlib.Path(sys.argv[2]).resolve(); S = tool(root); args = sys.argv[3:]
    old = str(pathlib.Path(args.pop(0)).resolve()) if cmd == 'final8' else None; cli = str(pathlib.Path(args[0]).resolve()); out = pathlib.Path(args[1]).resolve()
    if out.exists(): sys.exit('output directory exists: ' + str(out))
    out.mkdir(parents=True); work = out / 'work'; work.mkdir()
    env = {'environment': platform.platform(), 'logicalProcessors': os.cpu_count(), 'binarySha256': sha(cli), 'build': build(cli), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    raw = open(out / 'raw.jsonl', 'w'); t0 = time.time()
    if cmd == 'final8':
        plan = {'kind': 'final8', 'question': 'Does the 5.8 program reproduce its reported normal-interval failure, does 5.9 reproduce 5.8 with the 5.8 streams, and do the 5.9 distribution-free statements hold where the normal interval fails?', 'game': 'final8', 'trainingSeed': 5851, 'trainingUpdates': 5000, 'responseSeeds': [1, 120],
                'request': {'responseDeals': 10000, 'samples': 204800, 'exact': True, 'futureActions': 'sample', 'threads': 1, 'parallelSeats': 2}, 'arms': {'A': 'the unchanged 5.8 program', 'B': '5.9 with randomStreams 5.8', 'C': '5.9 with its own streams'}, 'expected': {'A': '193 of 960 beyond 4 reported standard errors (MATHEMATICAL-VALIDATION-5.8.md, section 3.5)', 'B': 'identical to A'},
                'stoppingRule': 'fixed: 120 runs per arm', 'old': {'binarySha256': sha(old), 'build': build(old)}, **env}
        (out / 'plan.json').write_text(json.dumps(plan, indent=1)); sp = work / 'spec.json'; st = work / 'trained.state'
        subprocess.run(['node', str(root / 'source/tools/games58.js'), 'spec', plan['game'], str(sp), str(plan['trainingSeed'])], check=True, capture_output=True); subprocess.run([old, str(sp), str(plan['trainingUpdates']), '1', str(st), '256'], check=True, capture_output=True)
        for k in range(1, 121):
            for arm, exe, extra in (('A', old, {}), ('B', cli, {'randomStreams': '5.8'}), ('C', cli, {})):
                doc, err = run(exe, sp, st, {**plan['request'], **extra, 'seed': k})
                if err: raw.write(json.dumps({'arm': arm, 'responseSeed': k, 'error': err}) + '\n'); continue
                seats = seats_of(doc); exact = [s['exactGain'] for s in seats]; br = [s['exactBestResponseGain'] for s in seats]
                raw.write(json.dumps({'arm': arm, 'responseSeed': k, 'seats': seats, 'printed': printed(doc), 'judge': judge(S, seats, exact, br, printed(doc))}) + '\n'); raw.flush()
            if k % 20 == 0: print('final8 run', k, round(time.time() - t0), 's', flush=True)
    else:
        games = [g['key'] for g in json.loads(subprocess.run(['node', str(root / 'source/tools/games58.js'), 'describe'], capture_output=True, text=True, check=True).stdout)]
        plan = {'kind': 'games', 'question': 'On games where every value is known exactly: how often does each lower bound exceed the truth, and how much of the truth does it certify?', 'games': games, 'trainingSeeds': [5901, 5902], 'trainingUpdates': 5000, 'response': {'responseDeals': 200000, 'seed': 59}, 'evaluationSeeds': [1, 100],
                'evaluation': {'samples': 51200, 'futureActions': 'sample', 'threads': 1, 'parallelSeats': 3}, 'alpha': 0.05, 'timingPilot': 'one run per game with another training seed (5901 states were trained again for the plan) fixed the sizes; no coverage number was looked at to choose them', 'stoppingRule': 'fixed: every game x training seed x evaluation seed once; a failed run is recorded and the experiment continues', **env}
        (out / 'plan.json').write_text(json.dumps(plan, indent=1))
        for g in games:
            for ts in plan['trainingSeeds']:
                sp = work / 'spec.json'; st = work / 'trained.state'
                subprocess.run(['node', str(root / 'source/tools/games58.js'), 'spec', g, str(sp), str(ts)], check=True, capture_output=True); subprocess.run([cli, str(sp), str(plan['trainingUpdates']), '1', str(st), '256'], check=True, capture_output=True)
                doc, err = run(cli, sp, st, {**plan['response'], **plan['evaluation'], 'exact': True, 'evaluationSeed': 0})
                if err: raw.write(json.dumps({'game': g, 'trainingSeed': ts, 'error': 'exact: ' + err}) + '\n'); continue
                ex = seats_of(doc); exact = [s['exactGain'] for s in ex]; br = [s['exactBestResponseGain'] for s in ex]
                for e in range(1, 101):
                    doc, err = run(cli, sp, st, {**plan['response'], **plan['evaluation'], 'evaluationSeed': e})
                    if err: raw.write(json.dumps({'game': g, 'trainingSeed': ts, 'evaluationSeed': e, 'error': err}) + '\n'); continue
                    seats = seats_of(doc)
                    for s, a, b in zip(seats, exact, br): s['exactGain'] = a; s['exactBestResponseGain'] = b
                    raw.write(json.dumps({'game': g, 'trainingSeed': ts, 'evaluationSeed': e, 'seats': [{k: s[k] for k in ('seat', 'mean', 'stdErr', 'variance', 'n', 'width', 'half95TwoSided', 'exactGain', 'exactBestResponseGain')} for s in seats], 'printed': printed(doc), 'judge': judge(S, seats, exact, br, printed(doc))}) + '\n')
                raw.flush(); print(g, ts, round(time.time() - t0), 's', flush=True)
    raw.close()
    for f in work.iterdir(): f.unlink()
    work.rmdir(); r = analyze(out); print(json.dumps(r, indent=1)[:3000])
