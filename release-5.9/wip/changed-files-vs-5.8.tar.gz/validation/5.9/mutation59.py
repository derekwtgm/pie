#!/usr/bin/env python3
"""EightMax 5.9: does mwcli --selftest59 notice when what it tests is broken?
Usage: mutation59.py <release root> <work dir>        (writes validation/5.9/mutation59.json)

For each mutant the engine source is copied, ONE behaviour that 5.9 added is broken by a text substitution, the
command-line program is compiled, and the sections of --selftest59 that cover that behaviour are run. A mutant is
DETECTED when the self-test exits with a non-zero status and at least one of the checks expected to notice is not
'passed'. The control is the unmodified source: every check must pass. A mutant that compiles but is not detected is
a hole in the self-test and is reported as such; nothing is tuned afterwards to hide it."""
import sys, json, subprocess, pathlib, shutil, time
root = pathlib.Path(sys.argv[1]).resolve(); work = pathlib.Path(sys.argv[2]).resolve(); shutil.rmtree(work, ignore_errors=True); work.mkdir(parents=True)
MUTANTS = [
 ('control', 'the unmodified engine', None, None, None, ['engine', 'statistics', 'response'], []),
 ('log-of-one-over-delta', 'the seat bound uses ln(1/delta) instead of ln(2/delta) (a bound that is too narrow)', 'response_stats59.hpp', '  const double L = std::log(2 / delta);\n  return std::min(width, std::sqrt(2 * sampleVariance * L / n) + 7 * width * L / (3 * (n - 1)));', '  const double L = std::log(1 / delta);\n  return std::min(width, std::sqrt(2 * sampleVariance * L / n) + 7 * width * L / (3 * (n - 1)));', ['statistics'], ['S1']),
 ('no-range-term', 'the seat bound drops the term that protects against unseen rare values', 'response_stats59.hpp', 'std::sqrt(2 * sampleVariance * L / n) + 7 * width * L / (3 * (n - 1)));\n}\n// Upper confidence bound', 'std::sqrt(2 * sampleVariance * L / n));\n}\n// Upper confidence bound', ['statistics'], ['S1', 'S2']),
 ('no-family-division', 'every seat gets the whole error budget alpha instead of alpha / seats (not simultaneous)', 'response_stats59.hpp', 'r.alphaPerAnalysis = alpha / analyses; const double delta = r.alphaPerAnalysis / (double)S.size();', 'r.alphaPerAnalysis = alpha / analyses; const double delta = r.alphaPerAnalysis;', ['statistics'], ['S4']),
 ('no-floor', 'the NashConv bound adds negative seat bounds instead of flooring them at 0', 'response_stats59.hpp', 'b.lower = s.mean - b.half; b.floored = std::max(0.0, b.lower);', 'b.lower = s.mean - b.half; b.floored = b.lower;', ['statistics'], ['S4', 'S6']),
 ('unavailable-seat-ignored', 'a seat without evaluation no longer withholds the sum of response gains', 'response_stats59.hpp', 'r.calibrated = true; r.complete = all; r.bestResponseSumLower = floored; if (all) r.sumOfGainsLower = sum;', 'r.calibrated = true; r.complete = all; r.bestResponseSumLower = floored; r.sumOfGainsLower = sum;', ['statistics'], ['S4']),
 ('range-violation-ignored', 'a sample outside the proven range no longer withdraws the simultaneous statement', 'response_stats59.hpp', '      if (!s.within) { r.reason = "payoffBoundViolated"; r.seats.clear(); return r; }\n      b.half', '      b.half', ['statistics'], ['S4']),
 ('pooled-one-subset-budget', 'the pooled bound spends its Bernstein budget as if there were one subset (not simultaneous over subsets)', 'response_stats59.hpp', 'r.deltaBernstein = r.alphaPerAnalysis / (2.0 * (double)r.subsets);', 'r.deltaBernstein = r.alphaPerAnalysis / 2.0;', ['statistics'], ['S5']),
 ('pooled-sample-variance', 'the pooled bound uses the sample variance where the proof needs an upper bound of the true variance', 'response_stats59.hpp', 'const double sd = sdUpper(s.variance, s.width, s.n, r.deltaVariance);', 'const double sd = std::sqrt(s.variance);', ['statistics'], ['S5']),
 ('philox-multiplier', 'one multiplier of the generator is wrong by one bit', 'response59.hpp', 'mulhilo(0xD2E7470EE14C6C93ULL, c[0], hi0, lo0);', 'mulhilo(0xD2E7470EE14C6C91ULL, c[0], hi0, lo0);', ['engine'], ['E1']),
 ('philox-nine-rounds', 'the generator runs nine rounds instead of ten', 'response59.hpp', 'for (int r = 1; r < 10; r++) { k[0] += 0x9E3779B97F4A7C15ULL;', 'for (int r = 1; r < 9; r++) { k[0] += 0x9E3779B97F4A7C15ULL;', ['engine'], ['E1', 'E2']),
 ('stream-ignores-seat', 'the stream address ignores the seat (two seats would be evaluated on the same numbers)', 'response59.hpp', 'key{seed, DOMAIN59}, ctr{0, block, seat, purpose}', 'key{seed, DOMAIN59}, ctr{0, block, 0, purpose}', ['engine'], ['E3']),
 ('index-off-by-one-slot', 'the offset index returns the values of the next hash slot', 'response59.hpp', 'if ((uint64_t)hk[i] == key) return m.vals.data() + K.slotOff[i];', 'if ((uint64_t)hk[i] == key) return m.vals.data() + K.slotOff[(i + 1) & mask];', ['response'], ['R6', 'R1']),
 ('response-profile-swapped', 'the lean walk reads the response strategy from the wrong half of the row at the responding seat', 'response59.hpp', 'double pr[8], ps[8]; average59(reg ? reg + k : nullptr, k, pr); current59(reg, k, ps);', 'double pr[8], ps[8]; average59(reg, k, pr); current59(reg, k, ps);', ['response'], ['R6', 'R1']),
 ('seat-alpha-not-divided', 'the command line gives every seat alpha / analyses instead of alpha / analyses / seats', 'mwcli_response59.hpp', 'alphaSeat = alphaFamily / (double)analyses / (double)seats.size();', 'alphaSeat = alphaFamily / (double)analyses;', ['response'], ['R2']),
 ('legacy-field-changed', 'the deprecated 5.8 field silently changes its meaning (it would add the distribution-free bounds)', 'mwcli_response59.hpp', 'jb_printf(&o, ",\\"sumOfSeatLowerBounds95\\":%.17g,\\"sumOfNormalApproximationLowerBounds95\\":%.17g", sumFloor, sumFloor);', 'jb_printf(&o, ",\\"sumOfSeatLowerBounds95\\":%.17g,\\"sumOfNormalApproximationLowerBounds95\\":%.17g", sim.bestResponseSumLower, sumFloor);', ['response'], ['R2']),
]
rows = []; t0 = time.time()
(work / 'bi.h').write_text('#define EM_VERSION "5.9"\n#define EM_BUILD_ID "mutant"\n')
subprocess.run(['gcc', '-O1', '-c', str(root / 'source/native/json.c'), '-o', str(work / 'json.o')], check=True)
for name, what, file, old, new, sections, expected in MUTANTS:
    src = work / ('src-' + name); shutil.copytree(root / 'source/native', src)
    row = {'mutant': name, 'what': what, 'file': file, 'sections': sections, 'expectedToFail': expected}
    if file:
        p = src / file; text = p.read_text()
        if text.count(old) != 1: row.update({'error': 'the text to mutate occurs %d times' % text.count(old), 'detected': False}); rows.append(row); print(name, row['error'], flush=True); continue
        p.write_text(text.replace(old, new))
    exe = work / ('mwcli-' + name)
    c = subprocess.run('g++ -std=c++20 -O1 -march=x86-64 -ffp-contract=off -I. -c mw.cpp -o %s/mw-%s.o && g++ -std=c++20 -O1 -march=x86-64 -ffp-contract=off -I. -include %s/bi.h mwcli.cpp %s/mw-%s.o %s/json.o -lpthread -ldl -lz -o %s' % (work, name, work, work, name, work, exe), shell=True, cwd=str(src), capture_output=True, text=True)
    if c.returncode: row.update({'error': 'does not compile: ' + c.stderr[-300:], 'detected': None}); rows.append(row); print(name, 'does not compile', flush=True); shutil.rmtree(src); continue
    notPassed = []; exits = []
    for sec in sections:
        d = work / ('st-' + name + '-' + sec); r = subprocess.run([str(exe), '--selftest59', str(root / 'studies'), str(d), sec], capture_output=True, text=True); exits.append(r.returncode)
        try: notPassed += [c_['id'].split()[-1] for c_ in json.loads((d / 'selftest59.json').read_text())['checks'] if c_['status'] != 'passed']
        except Exception as e: notPassed.append('no report: ' + str(e)[:80])
        shutil.rmtree(d, ignore_errors=True)
    kinds = sorted(set(notPassed)); row.update({'exits': exits, 'kindsNotPassed': kinds, 'unexpectedKinds': [k for k in kinds if k not in expected], 'detected': (not kinds and not any(exits)) if name == 'control' else (any(exits) and any(k in kinds for k in expected))})
    rows.append(row); print(name, 'exits', exits, 'not passed', kinds, 'DETECTED' if row['detected'] else 'NOT DETECTED', flush=True)
    shutil.rmtree(src); exe.unlink(missing_ok=True)
mut = [r for r in rows if r['mutant'] != 'control']
out = {'what': 'mwcli --selftest59 run by engines with one 5.9 behaviour broken (text mutation of the source, -O1 build)', 'mutants': len(mut), 'detected': sum(1 for r in mut if r['detected']), 'notDetected': [r['mutant'] for r in mut if r['detected'] is False], 'didNotCompile': [r['mutant'] for r in mut if r['detected'] is None],
       'controlClean': bool(rows and rows[0]['detected']), 'everyMutantDetectedAndTheControlClean': all(r['detected'] for r in rows), 'seconds': round(time.time() - t0, 1), 'rows': rows}
(root / 'validation/5.9/mutation59.json').write_text(json.dumps(out, indent=1) + '\n'); print(json.dumps({k: v for k, v in out.items() if k != 'rows'}, indent=1))
shutil.rmtree(work, ignore_errors=True)
