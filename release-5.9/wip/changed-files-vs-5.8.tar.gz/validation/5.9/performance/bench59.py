#!/usr/bin/env python3
"""EightMax 5.9 performance against the unchanged 5.8 program. Usage:
  bench59.py <release root> <5.8 mwcli> <5.9 mwcli> <fresh out dir> [response|training|evaluation|study|cache ...]

Every comparison alternates the two programs (one run of each per repetition) and reports medians and minima; the
plan is written to plan.json before anything is measured. What is measured:

response   mwcli --response, the same request for both programs with the 5.8 evaluation streams and one thread, so both
           compute the SAME numbers (checked: estimate bits, variance and visits) and only time differs. Per fixture:
           seconds of response training, seconds of evaluation, wall seconds, peak resident memory. Fixtures: the
           three-player flop, six-player flop, three-player preflop and eight-handed ICM study fixtures (states of
           250,000 deals) and the reference games four-player turn, five-player flop and eight-handed ICM final table.
           Then, for 5.9 only: the default request (5.9 streams, evaluation on every logical processor) and sampled
           opponent actions - what a user gets without asking for anything.
training   default training, sampled deals per second: four study fixtures, 250,000 deals, one thread; frozen batches
           (64 deals per update) with 1, 2 and 4 threads on the six-player flop fixture. States must be identical.
evaluation exact best response (mwcli --gain, method exact) and the 5.7 sampled one-decision measure on reference games.
study      a complete study (mwcli --study) of two shipped fixtures with small budgets.
cache      first-level data-cache misses of the evaluation walk, counted by valgrind cachegrind (deterministic): the
           5.8 walk and the 5.9 walk inside the 5.9 program (EIGHTMAX_RESPONSE_WALK=5.8), small sample.
The development container has 4 logical processors and no hardware counters; numbers on the target PC will differ."""
import sys, json, subprocess, pathlib, time, statistics, platform, os, hashlib, re
root = pathlib.Path(sys.argv[1]).resolve(); old = str(pathlib.Path(sys.argv[2]).resolve()); new = str(pathlib.Path(sys.argv[3]).resolve()); out = pathlib.Path(sys.argv[4]).resolve(); parts = sys.argv[5:] or ['response', 'training', 'evaluation', 'study', 'cache']
if out.exists(): sys.exit('output directory exists: ' + str(out))
out.mkdir(parents=True); work = out / 'work'; work.mkdir()
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest(); build = lambda c: subprocess.run([c, '--build-id'], capture_output=True, text=True).stdout.strip()
FIX = ['flop3-kings', 'flop6-jack', 'btn25-open', 'icm8-bb-call']; REF = [('turn4', 20000), ('flop5', 20000), ('final8', 5000)]
plan = {'parts': parts, 'old': {'build': build(old), 'sha256': sha(old)}, 'new': {'build': build(new), 'sha256': sha(new)}, 'fixtures': FIX, 'referenceGames': REF, 'repetitions': {'response': 3, 'training': 5, 'evaluation': 3, 'study': 3},
        'responseRequest': {'responseDeals': 200000, 'samples': 51200, 'seed': 58, 'threads': 1}, 'order': 'alternating: one run of each program per repetition', 'statistic': 'median (minimum)',
        'environment': platform.platform(), 'logicalProcessors': os.cpu_count(), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(out / 'plan.json').write_text(json.dumps(plan, indent=1)); res = {}
def spec_fixture(fx):
    p = work / (fx + '.spec.json'); p.write_text(json.dumps(json.loads((root / 'studies' / (fx + '.emfix.json')).read_text(encoding='utf-8-sig'))['variants'][0]['nativeSpec'])); return p
def spec_game(key, extra=None):
    p = work / (key + '.spec.json'); subprocess.run(['node', str(root / 'source/tools/games58.js'), 'spec', key, str(p), '1'] + ([json.dumps(extra)] if extra else []), check=True, capture_output=True); return p
def timed(args, env=None):
    t = time.perf_counter(); p = subprocess.run(args, capture_output=True, text=True, env={**os.environ, **(env or {})}); return time.perf_counter() - t, p
med = lambda v: statistics.median(v)
def save(): (out / 'result.json').write_text(json.dumps(res, indent=1))
states = {}
def state_of(name, spec, deals):
    if name not in states: st = work / (name + '.state'); subprocess.run([old, str(spec), str(deals), '1', str(st), '2048'], check=True, capture_output=True); states[name] = st
    return states[name]
if 'response' in parts:
    rows = []
    for name, spec, deals in [(fx, spec_fixture(fx), 250000) for fx in FIX] + [(k, spec_game(k), u) for k, u in REF]:
        st = state_of(name, spec, deals); q = work / 'rq.json'; rq = dict(plan['responseRequest']); t = {'old': [], 'new': []}; parts_t = {'old': {'train': [], 'eval': []}, 'new': {'train': [], 'eval': []}}; rss = {'old': [], 'new': []}; bits = {}
        for rep in range(plan['repetitions']['response']):
            for which, exe, extra in (('old', old, {}), ('new', new, {'randomStreams': '5.8'})):
                q.write_text(json.dumps({**rq, **extra})); dt, p = timed([exe, '--response', str(spec), str(st), str(q), '2048'])
                if p.returncode: bits[which] = 'error: ' + p.stderr[-200:]; continue
                d = json.loads(p.stdout); t[which].append(d['wallSeconds']); parts_t[which]['train'].append(sum(s['trainingSeconds'] for s in d['seats'])); parts_t[which]['eval'].append(sum(s['sampled']['elapsedMs'] for s in d['seats']) / 1000); rss[which].append(d['processPeakRssMiB'])
                bits[which] = [(s['seat'], s['sampled']['gain']['gainBits'], s['sampled']['gain']['stdErr'], s['sampled']['visits']) for s in d['seats']]; opp = d['seats'][0]['sampled']['opponentActions']; players = d['players']
        row = {'fixture': name, 'players': players, 'opponentActions': opp, 'identicalNumbers': bits.get('old') == bits.get('new'), 'wall': {k: [med(v), min(v)] for k, v in t.items()}, 'training': {k: [med(v['train']), min(v['train'])] for k, v in parts_t.items()}, 'evaluation': {k: [med(v['eval']), min(v['eval'])] for k, v in parts_t.items()}, 'peakRssMiB': {k: max(v) for k, v in rss.items()}}
        row['wallReduction'] = 1 - row['wall']['new'][0] / row['wall']['old'][0]; row['evaluationSpeedup'] = row['evaluation']['old'][0] / row['evaluation']['new'][0]; row['trainingRatio'] = row['training']['new'][0] / row['training']['old'][0]
        # what a user gets by default in 5.9, and with sampled opponent actions (5.9 only; other numbers than above)
        for label, extra in (('default59', {}), ('sampled59', {'futureActions': 'sample'})):
            r2 = {k: v for k, v in rq.items() if k != 'threads'}; q.write_text(json.dumps({**r2, **extra})); dt, p = timed([new, '--response', str(spec), str(st), str(q), '2048'])
            if p.returncode == 0: d = json.loads(p.stdout); row[label] = {'wallSeconds': d['wallSeconds'], 'evaluationThreads': d['evaluationThreads'], 'opponentActions': d['seats'][0]['sampled']['opponentActions'], 'simultaneousNashConvLowerBound': d['summary']['simultaneous']['nashConvLowerBound'], 'pooledNashConvLowerBound': d['summary']['pooledIndependent']['nashConvLowerBound'], 'sumOfSeatGains': d['summary']['sumOfSeatGains']['mean'], 'evaluationSeconds': sum(s['sampled']['elapsedMs'] for s in d['seats']) / 1000}
        rows.append(row); res['response'] = rows; save(); print('response', name, 'identical', row['identicalNumbers'], 'wall 5.8 %.2f 5.9 %.2f (-%.0f%%) eval x%.2f train ratio %.2f' % (row['wall']['old'][0], row['wall']['new'][0], 100 * row['wallReduction'], row['evaluationSpeedup'], row['trainingRatio']), flush=True)
if 'training' in parts:
    rows = []
    cases = [(fx, spec_fixture(fx), 250000, 1) for fx in FIX]
    sp64 = work / 'flop6-jack-b64.spec.json'; d = json.loads(spec_fixture('flop6-jack').read_text()); d['batchDeals'] = 64; d['actionStreams'] = 'deal'; sp64.write_text(json.dumps(d)); cases += [('flop6-jack, 64 deals per update', sp64, 4000, th) for th in (1, 2, 4)]
    for name, spec, updates, threads in cases:
        t = {'old': [], 'new': []}; h = {'old': set(), 'new': set()}; rss = {'old': [], 'new': []}; deals = None
        for rep in range(plan['repetitions']['training']):
            for which, exe in (('old', old), ('new', new)):
                o = work / 't.state'; dt, p = timed([exe, str(spec), str(updates), str(threads), str(o), '2048'], {'EIGHTMAX_THREAD_CHOICE': 'fixed'} if threads > 1 else None)
                if p.returncode: continue
                j = json.loads(p.stdout); t[which].append(j['wallSeconds'] if isinstance(j.get('wallSeconds'), (int, float)) else dt); h[which].add(sha(o)); deals = j.get('trainingDeals', updates); rss[which].append(j.get('processPeakRssMiB'))
        row = {'case': name, 'threads': threads, 'deals': deals, 'identicalStates': len(h['old'] | h['new']) == 1, 'seconds': {k: [med(v), min(v)] for k, v in t.items()}, 'dealsPerSecond': {k: deals / med(v) for k, v in t.items()}, 'peakRssMiB': {k: max((x for x in v if x), default=None) for k, v in rss.items()}}
        row['ratio59Over58'] = row['seconds']['new'][0] / row['seconds']['old'][0]; rows.append(row); res['training'] = rows; save(); print('training', name, threads, 'identical', row['identicalStates'], '5.8 %.3f 5.9 %.3f ratio %.3f' % (row['seconds']['old'][0], row['seconds']['new'][0], row['ratio59Over58']), flush=True)
if 'evaluation' in parts:
    rows = []
    for key, updates in [('turn4', 20000), ('flop6', 20000), ('bubble4', 5000), ('mid3-turn', 10000)]:
        spec = spec_game(key); st = state_of(key, spec, updates)
        for label, rq in (('exact best response', {'method': 'exact', 'policy': 'average', 'device': 'cpu', 'threads': 1, 'timeLimitMs': 3600000, 'maxVisits': 2000000000, 'memoryMiB': 1024}), ('sampled one-decision measure', {'method': 'sampled', 'samples': 20000, 'selectionSamples': 200, 'seed': 58, 'threads': 1, 'timeLimitMs': 3600000})):
            q = work / 'g.json'; q.write_text(json.dumps(rq)); t = {'old': [], 'new': []}; outp = {}
            for rep in range(plan['repetitions']['evaluation']):
                for which, exe in (('old', old), ('new', new)):
                    dt, p = timed([exe, '--gain', str(spec), str(st), str(q), '512']); t[which].append(dt)
                    try: outp[which] = [(s.get('policyValue'), s.get('bestResponseValue'), (s.get('gain') or {}).get('mean') if isinstance(s.get('gain'), dict) else s.get('gain')) for s in json.loads(p.stdout)['seats']]
                    except Exception: outp[which] = 'error'
            row = {'game': key, 'measure': label, 'identicalValues': outp.get('old') == outp.get('new'), 'seconds': {k: [med(v), min(v)] for k, v in t.items()}}; row['ratio59Over58'] = row['seconds']['new'][0] / row['seconds']['old'][0]; rows.append(row); res['evaluation'] = rows; save()
            print('evaluation', key, label, 'identical', row['identicalValues'], 'ratio %.3f' % row['ratio59Over58'], flush=True)
if 'study' in parts:
    rows = []
    for fx, args in [('known-akq-river', ['seeds=1,2', 'budgets=20000,60000']), ('flop6-jack-small', ['variants=baseline', 'seeds=1,2', 'budgets=20000,60000', 'evaluationSamples=4096', 'qualitySamples=512'])]:
        t = {'old': [], 'new': []}; canon = {}
        for rep in range(plan['repetitions']['study']):
            for which, exe in (('old', old), ('new', new)):
                o = work / 'study.json'; dt, p = timed([exe, '--study', str(root / 'studies' / (fx + '.emfix.json')), str(o), 'quiet=1', 'checkpoint=off', 'threads=2'] + args); t[which].append(dt)
                try: d = json.loads(o.read_text()); canon[which] = json.dumps([[[b.get('ev'), b.get('frequency'), b.get('quality')] for b in s['budgets']] for v in d['variants'] for s in v['perSeed']])
                except Exception: canon[which] = 'error ' + p.stderr[-100:]
        row = {'fixture': fx, 'identicalMeasurements': canon.get('old') == canon.get('new'), 'seconds': {k: [med(v), min(v)] for k, v in t.items()}}; row['ratio59Over58'] = row['seconds']['new'][0] / row['seconds']['old'][0]; rows.append(row); res['study'] = rows; save()
        print('study', fx, 'identical', row['identicalMeasurements'], 'ratio %.3f' % row['ratio59Over58'], flush=True)
if 'cache' in parts:
    rows = []
    for fx, samples, fa in [('flop3-kings', 4096, 'auto'), ('flop6-jack', 40960, 'auto')]:
        spec = spec_fixture(fx); st = state_of(fx, spec, 250000); q = work / 'c.json'; q.write_text(json.dumps({'responseDeals': 2000, 'samples': samples, 'seed': 58, 'seats': [0], 'threads': 1, 'randomStreams': '5.8', 'futureActions': fa})); row = {'fixture': fx, 'evaluationDeals': samples}
        for label, env in (('walk58', {'EIGHTMAX_RESPONSE_WALK': '5.8'}), ('walk59NoIndex', {'EIGHTMAX_RESPONSE_INDEX': '0'}), ('walk59', {})):
            log = work / 'cg.out'; dt, p = timed(['valgrind', '--tool=cachegrind', '--cache-sim=yes', '--cachegrind-out-file=' + str(log), new, '--response', str(spec), str(st), str(q), '2048'], env)
            m = {k: int(v.replace(',', '')) for k, v in re.findall(r'==\d+==\s+(I\s+refs|D\s+refs|D1\s+misses|LLd\s+misses):\s+([\d,]+)', p.stderr)}
            try: d = json.loads(p.stdout); row[label] = {'instructions': m.get('I   refs'), 'dataReferences': m.get('D   refs'), 'd1Misses': m.get('D1  misses'), 'lastLevelDataMisses': m.get('LLd misses'), 'visits': d['seats'][0]['sampled']['visits'], 'gainBits': d['seats'][0]['sampled']['gain']['gainBits']}
            except Exception: row[label] = {'error': p.stderr[-300:]}
        rows.append(row); res['cache'] = rows; save(); print('cache', fx, json.dumps({k: (v.get('d1Misses'), v.get('instructions')) for k, v in row.items() if isinstance(v, dict)}), flush=True)
for f in work.iterdir(): f.unlink()
work.rmdir(); save(); print('done')
