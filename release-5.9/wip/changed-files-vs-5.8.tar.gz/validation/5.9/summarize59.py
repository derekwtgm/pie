#!/usr/bin/env python3
"""EightMax 5.9: validation/5.9/validation-summary.json from the evidence files of validation/5.9.
Usage: summarize59.py <release root>
Nothing is computed here that is not in an evidence file; a file that is missing is recorded as missing, never as passed.
The summary is embedded in EightMax-Windows-5.9.identity.json by release59.py (validationStatus)."""
import sys, json, pathlib, re, gzip
root = pathlib.Path(sys.argv[1]).resolve(); V = root / 'validation/5.9'
def J(p):
    p = V / p
    try: return json.loads(p.read_text(encoding='utf-8-sig'))
    except Exception: return None
def text(p):
    try: return (V / p).read_text(errors='replace')
    except Exception: return None
def tap(p):
    t = text(p)
    if t is None: return {'missing': str(p)}
    g = lambda k: int(re.search(r'^# %s (\d+)' % k, t, re.M).group(1)) if re.search(r'^# %s (\d+)' % k, t, re.M) else None
    return {'tests': g('tests'), 'passed': g('pass'), 'failed': g('fail'), 'skipped': g('skipped'), 'failedTests': [m.group(1) for m in re.finditer(r'^not ok \d+ - (.*)$', t, re.M)], 'skippedTests': [m.group(1) for m in re.finditer(r'^ok \d+ - (.*?) # SKIP', t, re.M)]}
def st(p):
    d = J(p)
    if not d: return {'missing': str(p)}
    return {'passed': d.get('passed'), 'failed': d.get('failed'), 'untested': d.get('untested'), 'build': d.get('build'), 'seconds': d.get('seconds'), 'checks': len(d.get('checks', [])), 'notPassed': [c.get('id') or c.get('name') for c in d.get('checks', []) if c.get('status', 'passed' if c.get('passed', True) else 'failed') != 'passed']}
def exitof(p):
    t = text(p); m = re.search(r'exit (\d+)', t or ''); return int(m.group(1)) if m else None
def ps(p):
    d = J(p)
    if not d: return {'missing': str(p)}
    c = d.get('checks', []); cnt = lambda s: sum(1 for x in c if x.get('status') == s)
    return {'tool': d.get('tool'), 'release': d.get('release'), 'mode': d.get('mode'), 'scriptCompleted': d.get('scriptCompleted'), 'passed': cnt('passed'), 'failed': cnt('failed'), 'skipped': cnt('skipped'), 'untested': cnt('untested'), 'info': cnt('info'),
            'notPassed': [{'section': x.get('section'), 'name': x.get('name'), 'status': x.get('status'), 'class': x.get('class'), 'detail': str(x.get('detail'))[:300]} for x in c if x.get('status') in ('failed', 'untested', 'skipped')]}
info = json.loads((root / 'BUILD-INFO.json').read_text())
S = {'release': info['version'], 'build': info['build'], 'successorOf': {'release': '5.8', 'build': 'd4001e2c0cd77f41'},
     'classes': {'1': 'independently mathematically validated (a proof, an independent implementation, an exact reference, or the unchanged 5.8 binary agrees)', '2': 'tested on Linux, under Wine or by simulation (the project\'s own tests; the Windows programs under Wine)', '3': 'implemented, awaiting physical Windows / GPU validation (never executed on Windows hardware or an NVIDIA GPU)', '4': 'unsuccessful, incomplete, not implemented or not executed'},
     'baseline58': J('baseline/baseline-5.8.json'),
     'regressionLinux': tap('tests/full-regression.tap'),
     'selftest59Linux': st('selftest/selftest59-linux.json'), 'selftest58Linux': st('selftest/selftest58-linux.json'), 'selftest571Linux': st('selftest/selftest571-linux.json'), 'selftest57Linux': st('selftest/selftest57-linux.json'),
     'independentImplementation': J('independent/selfcheck.json'), 'runFinalSteps': (text('run-final59-steps.txt') or '').strip().splitlines(),
     'statistics': {'final8': J('statistics/final8/summary.json'), 'games': (lambda d: {k: d[k] for k in ('rows', 'errors', 'all')} if d else None)(J('statistics/games/summary.json')), 'perGame': 'validation/5.9/statistics/games/summary.json'},
     'convergence': {'identityAgainst58': (lambda d: {k: d[k] for k in ('comparisons', 'identicalStates', 'errors', 'medianSecondsRatio59Over58')} if d else None)(J('convergence/identity/summary.json')),
                     'optionalTrainers': (lambda d: {'rows': d['rows'], 'errors': d['errors'], 'family': d['family'], 'promotion': d['promotion']} if d else None)(J('convergence/options/summary.json')), 'flop6Fixture': (lambda d: d['runs'] if d else None)(J('convergence/flop6/summary.json')),
                     'defaultTrainerChanged': False, 'experimentalAlgorithmPromoted': False, 'newEstimatorImplemented': False},
     'identityAgainst58': J('identity/summary.json'),
     'performance': J('performance/result.json'), 'experimentsNotAdopted': ['validation/5.9/experiments/prefetch-row-slot.md'],
     'desktopHostRefusedStudies': (lambda d: {'checksPassed': d['checksPassed'], 'checksTotal': d['checksTotal'], 'passed': d['passed'], 'checks': [{'name': c['name'], 'passed': c['passed']} for c in d['checks']]} if d else {'missing': 'host-refusal59.json'})(J('host-refusal59.json')),
     'ui': (lambda d: {'passed': d.get('passed'), 'checksPassed': d.get('checksPassed'), 'checksTotal': d.get('checksTotal'), 'browser': d.get('browser'), 'notPassed': [c['name'] for c in d.get('checks', []) if not c.get('passed')]} if d else {'missing': 'ui'})(J('ui/study-ui56.json') or J('ui/study_ui56.json') or J('ui/study_ui59.json')),
     'stability': (lambda d: {'passed': d.get('passed'), 'minutesRequested': d.get('minutesRequested'), 'checks': [{'name': c['name'], 'passed': c['passed']} for c in d.get('checks', [])]} if d else {'missing': 'stability'})(J('stability/stability59.json')),
     'sanitizers': {'summary': (text('sanitizers/summary.txt') or 'missing').strip().splitlines(), 'selftest59': st('sanitizers/selftest59-asan.json'), 'selftest58': st('sanitizers/selftest58-asan.json'), 'v59': tap('sanitizers/v59-asan-ubsan.tap')},
     'wine': {'wineVersion': (text('wine/wine-version.txt') or 'missing').strip(), 'buildId': (text('wine/build-id.txt') or 'missing').strip()[:60], 'selftest59': st('wine/selftest59-wine.json'), 'selftest58': st('wine/selftest58-wine.json'), 'selftest571': st('wine/selftest571-wine.json'), 'selftest57': st('wine/selftest57-wine.json'),
              'referenceResponses': (lambda d: {'cases': d['cases'], 'allIdentical': d['allIdentical']} if d else {'missing': 'reference-responses-wine.json'})(J('wine/reference-responses-wine.json')), 'independentImplementationExit': exitof('wine/independent-stats-wine.exit'),
              'hostRefusal': (lambda d: {'checksPassed': d['checksPassed'], 'checksTotal': d['checksTotal'], 'notPassed': [c['name'] for c in d['checks'] if not c['passed']]} if d else {'missing': 'host-refusal-wine.json'})(J('wine/host-refusal-wine.json')), 'tests': {'v59': tap('wine/v59.test.tap'), 'v58': tap('wine/v58.test.tap')}},
     'powershell': {'what': 'validate_windows59.ps1 executed by PowerShell 7 on LINUX against the Linux programs: the script\'s logic, not Windows', 'version': (text('powershell/powershell-version.txt') or 'missing').strip(), 'parser': (text('powershell/parser.txt') or 'missing').strip().splitlines(), 'focused': ps('powershell/Windows-focused-validation-5.9.json'), 'full': ps('powershell/Windows-validation-5.9.json')},
     'windows': {'class': 3, 'executedOnWindowsHardware': False, 'windowsPowerShell51Executed': False, 'ciWorkflowExecuted': False, 'why': 'The development session had no Windows machine and no access to a Windows CI runner.', 'launchers': ['Run 5.9 focused validation.bat', 'Run 5.9 Windows validation.bat', 'Run 5.9 response example.bat'], 'instructions': 'WINDOWS-TESTS-5.9.md'},
     'gpu': {'class': 3, 'cudaCodeChangedIn59': False, 'executedOnAnNvidiaGpuFor59': False, 'evidenceOf57OnTheTargetPc': 'validation/5.7.1/windows-5.7-physical (not evidence for 5.9)'}}
(V / 'validation-summary.json').write_text(json.dumps(S, indent=1) + '\n')
print(json.dumps({k: (v if not isinstance(v, (dict, list)) or k in ('regressionLinux', 'selftest59Linux', 'selftest58Linux', 'selftest571Linux', 'selftest57Linux', 'desktopHostRefusedStudies') else '...') for k, v in S.items()}, indent=1)[:2500])
