#!/bin/bash
# The validation chain of the final 5.9 build on Linux, apart from the regression suite (which is run first, alone:
# node --test --test-concurrency=3 --test-reporter=tap source/tests/*.test.js > validation/5.9/tests/full-regression.tap).
# Usage: bash validation/5.9/run_final59.sh <release root> <work dir>
# <release root> holds build/linux/{mwcli,eightmax,gpustress} (source/native/build.sh) next to the release files.
# Evidence goes to validation/5.9/. Steps run even if an earlier one fails; exit codes are recorded in <work dir>/steps.txt.
# (Sanitizers, Wine, PowerShell, the experiments and the packaging have their own commands: sanitize59.sh, wine59.sh,
# powershell59.sh, statistics/coverage59.py, convergence/convergence59.py, performance/bench59.py, release59.py.)
set -u
root=$(cd "$1" && pwd); work=$2; mkdir -p "$work"; cd "$root"; S="$work/steps.txt"; : > "$S"; V=validation/5.9
cli="$root/build/linux/mwcli"; host="$root/build/linux/eightmax"
echo "build $("$cli" --build-id) $(date -u +%FT%TZ)" | tee -a "$S"
# 1. the self-tests of the Linux build, kept as evidence
rm -rf "$V/selftest"; mkdir -p "$V/selftest"
for st in 59:studies 58:studies 571:studies 57:validation/5.7/fixtures; do
  n=${st%%:*}; dir=${st##*:}; rm -rf "$work/st$n"
  if [ "$n" = 57 ]; then "$cli" --selftest$n "$root/$dir" "$work/st$n" > "$V/selftest/selftest$n-linux.stdout" 2> "$V/selftest/selftest$n-linux.stderr"
  else "$cli" --selftest$n "$root/$dir" "$work/st$n" all > "$V/selftest/selftest$n-linux.stdout" 2> "$V/selftest/selftest$n-linux.stderr"; fi
  echo "selftest$n (Linux) exit $?" | tee -a "$S"; cp "$work/st$n/selftest$n.json" "$V/selftest/selftest$n-linux.json" 2>/dev/null
done
# 2. the independent Python implementation: generator, stream addresses, exact coverage, and the bounds of three results
mkdir -p "$V/independent"
python3 source/tools/independent_stats59.py selfcheck "$cli" > "$V/independent/selfcheck.json" 2> "$V/independent/selfcheck.stderr"; echo "independent selfcheck exit $?" | tee -a "$S"
python3 source/tools/independent_stats59.py coverage > "$V/independent/two-point-coverage.json"; echo "exact two-point coverage table exit $?" | tee -a "$S"
# 3. the desktop host and refused studies (nine checks)
node source/tools/host_refusal59.js "$host" "$root" "$V/host-refusal59.json" > "$V/host-refusal59.stdout" 2>&1; echo "desktop host, refused studies exit $?" | tee -a "$S"
# 4. the 5.8 host check of the same situation, for the record of what changed (its second check expected the leftover folder to hold request.json; with 5.9 there is no folder)
node validation/5.8/host_refusal58.js "$host" "$root" "$V/host-refusal58-with-the-5.9-host.json" > "$V/host-refusal58-with-the-5.9-host.stdout" 2>&1; echo "5.8 host refusal driver against the 5.9 host exit $?" | tee -a "$S"
# 5. the desktop interface in a browser, and the stability run
mkdir -p "$V/ui" "$V/stability"
node "$V/study_ui59.js" "$host" "$root" "$V/ui" > "$V/ui/study_ui59.stdout" 2>&1; echo "interface in a browser exit $?" | tee -a "$S"
node "$V/stability59.js" "$host" "$root" "$V/stability" --minutes=3 > "$V/stability/stability59.stdout" 2>&1; echo "stability (3 minutes) exit $?" | tee -a "$S"
# 6. identical training states: the unchanged 5.8 binary against this build (thread counts, trainer options, hand groups, table limits)
rm -rf "$work/identity" "$V/identity"; mkdir -p "$V/identity"; cp validation/5.8/linux-bin/mwcli "$work/mwcli58"; chmod +x "$work/mwcli58"
python3 source/tools/identity57.py "$work/mwcli58" "$cli" "$work/identity" > "$V/identity/identity-against-5.8.log" 2>&1; echo "identity against 5.8 exit $?" | tee -a "$S"
cp "$work/identity"/summary.json "$V/identity/" 2>/dev/null; gzip -9 -c "$work/identity/identity.jsonl" > "$V/identity/identity.jsonl.gz" 2>/dev/null; tail -3 "$V/identity/identity-against-5.8.log" | tee -a "$S"
echo "== done $(date -u +%H:%M:%S)" | tee -a "$S"; cp "$S" "$V/run-final59-steps.txt"
