#!/usr/bin/env python3
"""EightMax 5.9: convergence experiments. Usage:
  convergence59.py identity <release root> <5.8 mwcli> <5.9 mwcli> <fresh out dir>
  convergence59.py options  <release root> <5.9 mwcli> <fresh out dir>
  convergence59.py flop6    <release root> <5.9 mwcli> <fresh out dir>
  convergence59.py analyze  <out dir>

5.9 did not change a trainer. These experiments establish that, and test whether one of the OPTIONAL trainers the engine
already contains (each documented as experimental in earlier releases) should replace the default.

identity  The default trainer of 5.9 against the unchanged 5.8 program at equal sampled deals: seven reference games,
          two budgets, two fresh seeds, one and three threads. Expected: byte-identical states (so identical NashConv:
          "equal deals" needs no statistics). Training seconds of both are recorded for the equal-wall-clock question.
options   Does an optional trainer converge faster than the default? Seven reference games small enough for EXACT
          NashConv (heads-up river, heads-up turn, three-player river, four-player turn, six-player flop, eight-handed ICM
          final table, four-player ICM bubble), budgets 20,000 and 100,000 sampled deals, eight fresh seeds (5911..5918),
          the same seeds for every arm (paired). Arms:
            default            linear external sampling (what every release since 5.5 ships as default)
            terminalBaseline   the default with the terminal-sibling control variate ("terminalBaseline": true), a
                               variance-reduction estimator that is unbiased for the same expected regret increments
            dcfr               discounted CFR weighting (alpha 1.5, beta 0, gamma 2)
            plus               regret matching+ with linear averaging
          Measure: exact NashConv of the average strategy (mwcli --gain, method exact). Per game, budget and candidate:
          the mean over seeds of ln(NashConv candidate / NashConv default) with a paired Student-t interval. Multiple
          comparisons: 7 games x 2 budgets x 3 candidates = 42 intervals, Bonferroni: each at level 0.05 / 42.
          Verdicts: "better" (the whole interval below 0), "worse" (above 0), "unresolved". Training seconds are
          recorded; time per deal relative to the default is reported beside every verdict (equal wall clock).
          PROMOTION RULE, fixed here: a candidate replaces the default only if it is "better" on at least 4 of the 7
          games at the larger budget, "worse" on none at either budget, and its median time per deal is within 10% of
          the default's. Otherwise the default stays and the candidate stays optional.
flop6     The six-player flop FIXTURE (flop6-jack: 210,000 information sets after 250,000 deals; no exact NashConv).
          default against terminalBaseline, 250,000 deals, three seeds; measure: the trained-response lower bounds of
          NashConv with their 5.9 confidence statements (200,000 response deals per seat, 409,600 evaluation deals,
          sampled opponent actions). Both numbers are LOWER bounds: a smaller bound is consistent with a better
          strategy and does not establish it. No verdict is drawn from this part alone.
Each sub-command writes plan.json before anything is measured and refuses an existing output directory."""
import sys, json, subprocess, pathlib, time, statistics, math, platform, os, hashlib
GAMES = ['hu-river', 'hu-turn', 'river3-chip', 'turn4', 'flop6', 'final8', 'bubble4']
ARMS = {'default': {}, 'terminalBaseline': {'terminalBaseline': True}, 'dcfr': {'weighting': 'dcfr'}, 'plus': {'regretMatching': 'plus'}}
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def build(cli): return subprocess.run([cli, '--build-id'], capture_output=True, text=True).stdout.strip()
def spec_of(root, key, seed, extra, path):
    subprocess.run(['node', str(root / 'source/tools/games58.js'), 'spec', key, str(path), str(seed)], check=True, capture_output=True)
    if extra: d = json.loads(path.read_text()); d.update(extra); path.write_text(json.dumps(d))
def train(cli, spec, updates, threads, state, cont=None):
    t = time.perf_counter(); p = subprocess.run([cli, str(spec), str(updates), str(threads), str(state), '512'] + ([str(cont)] if cont else []), capture_output=True, text=True); return p.returncode, time.perf_counter() - t, p.stderr.strip()[-200:]
def nashconv(cli, spec, state, work):
    q = work / 'gain.json'; q.write_text(json.dumps({'method': 'exact', 'policy': 'average', 'device': 'cpu', 'threads': 1, 'timeLimitMs': 3600000, 'maxVisits': 2000000000, 'memoryMiB': 1024}))
    p = subprocess.run([cli, '--gain', str(spec), str(state), str(q), '512'], capture_output=True, text=True)
    if p.returncode: return None, p.stderr.strip()[-200:]
    d = json.loads(p.stdout); return sum(s['bestResponseValue'] - s['policyValue'] for s in d['seats']), None
# two-sided Student-t quantile by bisection on the regularised incomplete beta function (no SciPy needed)
def t_cdf(t, df):
    x = df / (df + t * t); a, b = df / 2.0, 0.5
    def betacf(a, b, x):
        qab, qap, qam = a + b, a + 1, a - 1; c, d = 1.0, 1 - qab * x / qap; d = 1 / (d if abs(d) > 1e-300 else 1e-300); h = d
        for m in range(1, 400):
            m2 = 2 * m; aa = m * (b - m) * x / ((qam + m2) * (a + m2)); d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-300 else 1e-300); c = 1 + aa / c; c = c if abs(c) > 1e-300 else 1e-300; h *= d * c
            aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2)); d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-300 else 1e-300); c = 1 + aa / c; c = c if abs(c) > 1e-300 else 1e-300; de = d * c; h *= de
            if abs(de - 1) < 1e-15: break
        return h
    bt = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1 - x)) if 0 < x < 1 else 0.0
    ib = bt * betacf(a, b, x) / a if x < (a + 1) / (a + b + 2) else 1 - bt * betacf(b, a, 1 - x) / b
    return 1 - ib / 2 if t >= 0 else ib / 2
def t_quantile(p, df):
    lo, hi = 0.0, 1000.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if t_cdf(mid, df) < p: lo = mid
        else: hi = mid
    return (lo + hi) / 2
def analyze(out):
    plan = json.loads((out / 'plan.json').read_text()); rows = [json.loads(l) for l in (out / 'raw.jsonl').read_text().splitlines() if l.strip()]; res = {'kind': plan['kind'], 'rows': len(rows), 'errors': sum(1 for r in rows if r.get('error'))}
    if plan['kind'] == 'identity':
        ok = [r for r in rows if not r.get('error')]; res.update({'comparisons': len(ok), 'identicalStates': sum(1 for r in ok if r['identical']), 'different': [r for r in ok if not r['identical']],
            'medianSecondsRatio59Over58': statistics.median(r['seconds59'] / r['seconds58'] for r in ok if r['seconds58'] > 0), 'perGame': {g: {'identical': sum(1 for r in ok if r['game'] == g and r['identical']), 'of': sum(1 for r in ok if r['game'] == g), 'medianSecondsRatio59Over58': statistics.median(r['seconds59'] / r['seconds58'] for r in ok if r['game'] == g)} for g in plan['games']}})
    elif plan['kind'] == 'options':
        fam = len(plan['games']) * len(plan['budgets']) * (len(plan['arms']) - 1); level = 0.05 / fam; res.update({'family': fam, 'levelPerInterval': level, 'contrasts': []})
        for g in plan['games']:
            for b in plan['budgets']:
                cell = {(r['arm'], r['seed']): r for r in rows if r['game'] == g and r['deals'] == b and not r.get('error') and r.get('nashConv') and r['nashConv'] > 0}
                for arm in plan['arms']:
                    if arm == 'default': continue
                    seeds = [s for s in plan['seeds'] if (arm, s) in cell and ('default', s) in cell]
                    if len(seeds) < 3: res['contrasts'].append({'game': g, 'deals': b, 'arm': arm, 'verdict': 'no data', 'seeds': len(seeds)}); continue
                    d = [math.log(cell[(arm, s)]['nashConv'] / cell[('default', s)]['nashConv']) for s in seeds]; n = len(d); mean = statistics.fmean(d); se = statistics.stdev(d) / math.sqrt(n); q = t_quantile(1 - level / 2, n - 1); lo, hi = mean - q * se, mean + q * se
                    tr = statistics.median(cell[(arm, s)]['trainSeconds'] / cell[('default', s)]['trainSeconds'] for s in seeds)
                    res['contrasts'].append({'game': g, 'deals': b, 'arm': arm, 'seeds': n, 'meanLogRatio': mean, 'ratioOfGeometricMeans': math.exp(mean), 'interval': [math.exp(lo), math.exp(hi)], 'tCritical': q, 'verdict': 'better' if hi < 0 else 'worse' if lo > 0 else 'unresolved',
                                             'unadjusted95': [math.exp(mean - t_quantile(0.975, n - 1) * se), math.exp(mean + t_quantile(0.975, n - 1) * se)], 'medianTimePerDealRelativeToDefault': tr,
                                             'medianNashConvDefault': statistics.median(cell[('default', s)]['nashConv'] for s in seeds), 'medianNashConvCandidate': statistics.median(cell[(arm, s)]['nashConv'] for s in seeds), 'candidateLowerInSeeds': sum(1 for x in d if x < 0)})
        big = max(plan['budgets']); res['promotion'] = {}
        for arm in plan['arms']:
            if arm == 'default': continue
            c = [x for x in res['contrasts'] if x['arm'] == arm and 'verdict' in x]; better = sum(1 for x in c if x['deals'] == big and x['verdict'] == 'better'); worse = sum(1 for x in c if x['verdict'] == 'worse'); times = [x['medianTimePerDealRelativeToDefault'] for x in c if 'medianTimePerDealRelativeToDefault' in x]
            tm = statistics.median(times) if times else None
            res['promotion'][arm] = {'betterAtTheLargerBudget': better, 'ofGames': len(plan['games']), 'worseAnywhere': worse, 'unresolved': sum(1 for x in c if x['verdict'] == 'unresolved'), 'medianTimePerDealRelativeToDefault': tm, 'promoted': bool(better >= 4 and worse == 0 and tm is not None and tm <= 1.10)}
    else:
        res['runs'] = [r for r in rows if not r.get('error')]
    (out / 'summary.json').write_text(json.dumps(res, indent=1)); return res
if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else ''
    if cmd == 'analyze': print(json.dumps(analyze(pathlib.Path(sys.argv[2]).resolve()), indent=1)[:6000]); sys.exit(0)
    if cmd not in ('identity', 'options', 'flop6'): print(__doc__); sys.exit(2)
    root = pathlib.Path(sys.argv[2]).resolve(); args = sys.argv[3:]; old = str(pathlib.Path(args.pop(0)).resolve()) if cmd == 'identity' else None
    cli = str(pathlib.Path(args[0]).resolve()); out = pathlib.Path(args[1]).resolve()
    if out.exists(): sys.exit('output directory exists: ' + str(out))
    out.mkdir(parents=True); work = out / 'work'; work.mkdir(); raw = open(out / 'raw.jsonl', 'w'); t0 = time.time()
    env = {'environment': platform.platform(), 'logicalProcessors': os.cpu_count(), 'binarySha256': sha(cli), 'build': build(cli), 'written': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    if cmd == 'identity':
        plan = {'kind': 'identity', 'question': 'Does the 5.9 default trainer write the states of the unchanged 5.8 program?', 'games': GAMES, 'budgets': [20000, 100000], 'seeds': [5921, 5922], 'threads': [1, 3], 'old': {'binarySha256': sha(old), 'build': build(old)}, 'expected': 'every state byte-identical', **env}
        (out / 'plan.json').write_text(json.dumps(plan, indent=1))
        for g in GAMES:
            for seed in plan['seeds']:
                sp = work / 'spec.json'; spec_of(root, g, seed, {}, sp)
                for b in plan['budgets']:
                    for th in plan['threads']:
                        a, b_ = work / 'a.state', work / 'b.state'; ra, sa, ea = train(old, sp, b, th, a); rb, sb, eb = train(cli, sp, b, th, b_)
                        row = {'game': g, 'seed': seed, 'deals': b, 'threads': th, 'seconds58': sa, 'seconds59': sb}
                        if ra or rb: row['error'] = ea or eb
                        else: row.update({'sha58': sha(a), 'sha59': sha(b_)}); row['identical'] = row['sha58'] == row['sha59']
                        raw.write(json.dumps(row) + '\n'); raw.flush()
            print(g, round(time.time() - t0), 's', flush=True)
    elif cmd == 'options':
        plan = {'kind': 'options', 'question': 'Does an optional trainer reach a lower exact NashConv than the default at equal sampled deals?', 'games': GAMES, 'budgets': [20000, 100000], 'seeds': list(range(5911, 5919)), 'arms': ARMS, 'measure': 'exact NashConv of the average strategy (mwcli --gain, method exact)',
                'statistics': 'paired Student-t interval of the mean log ratio over seeds; Bonferroni over 42 intervals', 'promotionRule': 'better on at least 4 of 7 games at 100,000 deals, worse on none at either budget, median time per deal within 10% of the default', 'stoppingRule': 'fixed: every game x seed x arm x budget once', **env}
        (out / 'plan.json').write_text(json.dumps(plan, indent=1))
        for g in GAMES:
            for seed in plan['seeds']:
                for arm, extra in ARMS.items():
                    sp = work / 'spec.json'; st = work / 's.state'; done = 0; total = 0.0
                    try: spec_of(root, g, seed, extra, sp)
                    except subprocess.CalledProcessError as e: raw.write(json.dumps({'game': g, 'seed': seed, 'arm': arm, 'error': 'spec'}) + '\n'); continue
                    for b in plan['budgets']:
                        rc, secs, err = train(cli, sp, b - done, 1, str(st) + '.next', st if done else None)
                        if rc: raw.write(json.dumps({'game': g, 'seed': seed, 'arm': arm, 'deals': b, 'error': err}) + '\n'); break
                        os.replace(str(st) + '.next', st); done = b; total += secs; nc, e2 = nashconv(cli, sp, st, work)
                        raw.write(json.dumps({'game': g, 'seed': seed, 'arm': arm, 'deals': b, 'nashConv': nc, 'trainSeconds': total, **({'error': e2} if e2 else {})}) + '\n'); raw.flush()
            print(g, round(time.time() - t0), 's', flush=True)
    else:
        plan = {'kind': 'flop6', 'question': 'On the six-player flop fixture: which lower bounds of NashConv do the trained responses certify for the default trainer and for the terminal-baseline estimator?', 'fixture': 'flop6-jack', 'deals': 250000, 'seeds': [5931, 5932, 5933], 'arms': {'default': {}, 'terminalBaseline': {'terminalBaseline': True}},
                'response': {'responseDeals': 200000, 'samples': 409600, 'seed': 59, 'futureActions': 'sample', 'parallelSeats': 3, 'threads': 1}, 'reading': 'lower bounds only; no verdict is drawn', **env}
        (out / 'plan.json').write_text(json.dumps(plan, indent=1)); base = json.loads((root / 'studies/flop6-jack.emfix.json').read_text(encoding='utf-8-sig'))['variants'][0]['nativeSpec']
        for seed in plan['seeds']:
            for arm, extra in plan['arms'].items():
                spec = json.loads(json.dumps(base)); spec['state']['rng'] = seed; spec['actionSeed'] = seed ^ 0x7138ab94; spec['state']['actionRng'] = spec['actionSeed']; spec.update(extra)
                sp = work / 'spec.json'; sp.write_text(json.dumps(spec)); st = work / 's.state'; q = work / 'rq.json'; q.write_text(json.dumps(plan['response']))
                t = time.perf_counter(); p = subprocess.run([cli, str(sp), str(plan['deals']), '1', str(st), '2048'], capture_output=True, text=True); ts = time.perf_counter() - t
                if p.returncode: raw.write(json.dumps({'seed': seed, 'arm': arm, 'error': p.stderr.strip()[-200:]}) + '\n'); continue
                t = time.perf_counter(); r = subprocess.run([cli, '--response', str(sp), str(st), str(q), '2048'], capture_output=True, text=True); rs = time.perf_counter() - t
                if r.returncode: raw.write(json.dumps({'seed': seed, 'arm': arm, 'error': r.stderr.strip()[-200:]}) + '\n'); continue
                d = json.loads(r.stdout); S = d['summary']
                raw.write(json.dumps({'seed': seed, 'arm': arm, 'trainSeconds': ts, 'responseSeconds': rs, 'rows': json.loads(p.stdout)['rows'], 'sumOfSeatGainsEstimate': S['sumOfSeatGains']['mean'], 'simultaneousNashConvLowerBound95': S['simultaneous']['nashConvLowerBound'], 'pooledNashConvLowerBound95': S['pooledIndependent']['nashConvLowerBound'],
                                      'normalSumOfLowerBounds': S['sumOfSeatLowerBounds95'], 'seatGains': [s['sampled']['gain']['mean'] for s in d['seats']], 'seatLowerBounds': [x['responseGainLowerBound'] for x in S['simultaneous']['seats']]}) + '\n'); raw.flush()
                print(seed, arm, round(time.time() - t0), 's', flush=True)
    raw.close()
    for f in work.iterdir(): f.unlink()
    work.rmdir(); print(json.dumps(analyze(out), indent=1)[:5000])
