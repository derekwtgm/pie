#!/bin/bash
# EightMax 5.9: the Windows programs under Wine. Usage: bash validation/5.9/wine59.sh <release root> <wrapper dir> <work dir>
# <wrapper dir> holds mwcli-wine and EightMax-wine: small scripts that start the Windows executable of <release root>
# under Wine with a minimal environment and pass on EightMax's own variables (validation/5.6/wine/wrapper-example.sh).
#  1. mwcli.exe --selftest59 (what "Run 5.9 focused validation.bat" runs first on a Windows PC), --selftest58,
#     --selftest571, --selftest57
#  2. the reference responses of validation/5.9/windows/response (5.9 streams, with the bounds of the summary) and of
#     validation/5.8/windows/response (5.8 streams): mwcli.exe must reproduce the bits of the Linux builds
#  3. the independent Python implementation against mwcli.exe (the generator's streams)
#  4. the desktop host EightMax.exe: tools/host_refusal59.js (a refused study leaves no folder)
#  5. the 5.9 and 5.8 regression files with the Windows programs in place of the Linux ones
# Wine is not Windows: this is evidence about the Windows executables, not about a Windows PC.
set -u
root=$(cd "$1" && pwd); wr=$(cd "$2" && pwd); work=$3; out="$root/validation/5.9/wine"; rm -rf "$work" "$out"; mkdir -p "$work" "$out"; cd "$root"
win() { printf 'Z:%s' "${1//\//\\}"; }
"$wr/mwcli-wine" --build-id > "$out/build-id.txt" 2>&1; cat "$out/build-id.txt"
wine --version > "$out/wine-version.txt" 2>&1
sha256sum mwcli.exe EightMax.exe gpustress.exe > "$out/executables.sha256"
for st in 59:studies:all 58:studies:all 571:studies:all 57:validation/5.7/fixtures:; do
  IFS=: read -r n dir mode <<< "$st"; mkdir -p "$work/st$n"
  if [ -n "$mode" ]; then "$wr/mwcli-wine" --selftest$n "$(win "$root/$dir")" "$(win "$work/st$n")" $mode > "$out/selftest$n-wine.stdout" 2> "$out/selftest$n-wine.stderr"
  else "$wr/mwcli-wine" --selftest$n "$(win "$root/$dir")" "$(win "$work/st$n")" > "$out/selftest$n-wine.stdout" 2> "$out/selftest$n-wine.stderr"; fi
  echo "selftest$n exit $?" | tee "$out/selftest$n-wine.exit"; cp "$work/st$n/selftest$n.json" "$out/selftest$n-wine.json" 2>/dev/null
done
# 2. reference responses
python3 - "$root" "$wr/mwcli-wine" "$work" > "$out/reference-responses-wine.json" <<'PY'
import sys, json, subprocess, hashlib, pathlib
root, cli, work = pathlib.Path(sys.argv[1]), sys.argv[2], pathlib.Path(sys.argv[3]); d = root / 'validation/5.9/windows/response'; g = json.loads((d / 'golden59.json').read_text()); rows = []
win = lambda p: 'Z:' + str(p).replace('/', '\\')
def response(spec, st, request, mem):
    r = subprocess.run([cli, '--response', win(spec), win(st), win(request), str(mem)], capture_output=True, text=True)
    try: return json.loads(r.stdout), ''
    except Exception as e: return None, r.stderr.strip()[-200:] or str(e)
for c in g['cases']:
    st = work / (c['name'] + '.state'); subprocess.run([cli, win(d / c['spec']), str(c['updates']), '1', win(st), str(c['memoryMiB'])], capture_output=True, text=True)
    sha = hashlib.sha256(st.read_bytes()).hexdigest() if st.exists() else ''; got = []; sums = []
    for request in (c['request'], c['parallelRequest']):
        doc, err = response(d / c['spec'], st, d / request, c['memoryMiB'])
        if doc: got.append(['%d:%s:%s:%s:%s' % (s['seat'], s['sampled']['gain']['gainBits'], s['sampled']['statistics']['sampleVarianceBits'], s['exact']['gainBits'], s['exact']['bestResponseGainBits']) for s in doc['seats']]); S = doc['summary']; sums.append([S['simultaneous']['bits']['sumOfResponseGainsLowerBound'], S['simultaneous']['bits']['nashConvLowerBound'], S['pooledIndependent']['bits']['sumOfResponseGainsLowerBound'], S['pooledIndependent']['bits']['bestSubset']])
        else: got.append(['error: ' + err]); sums.append([])
    rows.append({'name': c['name'], 'streams': '5.9', 'stateIdentical': sha == c['stateSha256'], 'responseBitsIdentical': got[0] == c['seatBits'], 'summaryBoundsIdentical': sums[0] == c['summaryBits'], 'parallelSeatsIdentical': got[1] == c['seatBits'] and sums[1] == c['summaryBits'], 'got': got[0], 'expected': c['seatBits']})
d8 = root / 'validation/5.8/windows/response'; g8 = json.loads((d8 / 'golden58.json').read_text())
for c in g8['cases']:
    st = work / (c['name'] + '.58.state'); subprocess.run([cli, win(d8 / c['spec']), str(c['updates']), '1', win(st), str(c['memoryMiB'])], capture_output=True, text=True)
    sha = hashlib.sha256(st.read_bytes()).hexdigest() if st.exists() else ''; doc, err = response(d8 / c['spec'], st, d / 'request-58-streams.json', c['memoryMiB'])
    got = ['%d:%s:%s:%s' % (s['seat'], s['sampled']['gain']['gainBits'], s['exact']['gainBits'], s['exact']['bestResponseGainBits']) for s in doc['seats']] if doc else ['error: ' + err]
    rows.append({'name': c['name'], 'streams': '5.8', 'stateIdentical': sha == c['stateSha256'], 'responseBitsIdentical': got == c['seatBits'], 'summaryBoundsIdentical': None, 'parallelSeatsIdentical': None, 'got': got, 'expected': c['seatBits']})
ok = all(r['stateIdentical'] and r['responseBitsIdentical'] and r['summaryBoundsIdentical'] is not False and r['parallelSeatsIdentical'] is not False for r in rows)
print(json.dumps({'what': 'mwcli.exe under Wine against the bits recorded by the Linux builds of 5.9 (5.9 streams) and of 5.8 (5.8 streams)', 'recordedBy': {'5.9': g['recordedBy'], '5.8': g8['recordedBy']}, 'cases': len(rows), 'allIdentical': ok, 'rows': rows}, indent=1)); sys.exit(0 if ok else 1)
PY
echo "reference responses exit $?" | tee "$out/reference-responses-wine.exit"
python3 source/tools/independent_stats59.py selfcheck "$wr/mwcli-wine" > "$out/independent-stats-wine.json" 2> "$out/independent-stats-wine.stderr"; echo "independent implementation against mwcli.exe exit $?" | tee "$out/independent-stats-wine.exit"
node source/tools/host_refusal59.js "$wr/EightMax-wine" "$root" "$out/host-refusal-wine.json" > "$out/host-refusal-wine.stdout" 2>&1; echo "desktop host, refused studies exit $?" | tee "$out/host-refusal-wine.exit"
: > "$out/tests.exit"
for f in v59 v58; do
  EM_TEST_MWCLI="$wr/mwcli-wine" EM_TEST_HOST="$wr/EightMax-wine" PATH="$PATH:$HOME/.dotnet/tools" timeout 10800 node --test --test-concurrency=1 --test-reporter=tap "source/tests/$f.test.js" > "$out/$f.test.tap" 2> "$out/$f.test.stderr"; echo "$f exit $?" | tee -a "$out/tests.exit"
  grep -E '^# (tests|pass|fail|skipped)' "$out/$f.test.tap" | tr '\n' ' '; echo
done
