import json, subprocess, os, statistics, hashlib, time, sys, platform
B58='/home/user/work/base58/EightMax/build/linux/mwcli'; DEV='/home/user/work/dev/mwcli'; PF='/home/user/work/dev/mwcli_pf'; P='/home/user/work/prof/'
plan={'question':'Does issuing a prefetch of the row-index slot (hrow) beside the key slot (hkeys) in MW::findRow speed up default training?','builds':{'5.8':B58,'5.9-candidate-without':DEV,'5.9-candidate-with-prefetch':PF},
      'fixtures':['flop6-jack','flop3-kings','btn25-open','icm8-bb-call'],'deals':250000,'threads':1,'repetitions':7,'order':'alternating: one run of every build per repetition','decision':'adopt only if the median time of the prefetch build is at least 3% below BOTH other builds on at least two of the three large fixtures and above neither by 3% on any; states must be byte-identical',
      'environment':platform.platform(),'logicalProcessors':os.cpu_count(),'written':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
json.dump(plan,open('plan.json','w'),indent=1)
rows=[]
for fx in plan['fixtures']:
    t={b:[] for b in plan['builds']}; sha={}
    for rep in range(plan['repetitions']):
        for b,exe in plan['builds'].items():
            out='s.state'; t0=time.perf_counter(); p=subprocess.run([exe,P+fx+'.spec.json',str(plan['deals']),'1',out,'2048'],capture_output=True,text=True,check=True); dt=time.perf_counter()-t0
            j=json.loads(p.stdout); t[b].append(j.get('wallSeconds', dt) if not isinstance(j.get('wallSeconds', dt), dict) else dt); sha.setdefault(b,set()).add(hashlib.sha256(open(out,'rb').read()).hexdigest())
    row={'fixture':fx,'identicalStates':len(set().union(*sha.values()))==1,'medianSeconds':{b:statistics.median(v) for b,v in t.items()},'minSeconds':{b:min(v) for b,v in t.items()},'all':t}
    rows.append(row); print(fx,row['identicalStates'],{b:round(v,3) for b,v in row['medianSeconds'].items()},{b:round(v,3) for b,v in row['minSeconds'].items()},flush=True)
json.dump({'rows':rows},open('result.json','w'),indent=1)
