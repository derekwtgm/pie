# Experiment (not adopted): prefetching the row-index slot in the trainer's strategy lookup

**Idea.** A strategy lookup of the default trainer is a chain of dependent memory reads: the hash slot's key
(`hkeys[i]`), the slot's row number (`hrow[i]`), the 40-byte row record (for the offset of the values), the values.
`hkeys[i]` and `hrow[i]` live in two parallel arrays at the SAME index, so the second read does not need the result of
the first: a prefetch of `hrow + i`, issued when `i` is known, lets the two cache misses overlap. Unlike the 5.8
experiment (compact row offsets) this changes no layout, no memory accounting and no stored byte.

**Change (one line in `MW::findRow`, mw.cpp):**

```cpp
    size_t mask = hkeys.size() - 1, i = mix(key) & mask;
    __builtin_prefetch(hrow.data() + i);        // the candidate
    while (hkeys[i] != -1) { if ((uint64_t)hkeys[i] == key) return hrow[i]; i = (i + 1) & mask; }
```

**Plan** (`prefetch-row-slot/plan.json`, written before measurement): the unchanged 5.8 program, the 5.9 development
build without the line and the same build with it; four shipped fixtures, 250,000 deals, one thread, 7 repetitions,
one run of every build per repetition (alternating); wall time of the process. Decision rule: adopt only if the median
of the prefetch build is at least 3% below BOTH other builds on at least two of the three large fixtures, and above
neither by 3% on any; the written states must be byte-identical.

**Result** (`prefetch-row-slot/result.json`; development container, 4 logical processors; median (minimum) seconds):

| Fixture | 5.8 | 5.9 without | 5.9 with prefetch | prefetch vs 5.8 | prefetch vs without | states identical |
|---|---|---|---|---|---|---|
| flop6-jack | 5.925 (5.678) | 5.889 (5.296) | 5.929 (5.842) | +0.1% | +0.7% | yes |
| flop3-kings | 2.603 (2.400) | 2.519 (2.461) | 2.571 (2.391) | -1.2% | +2.1% | yes |
| btn25-open | 2.502 (2.289) | 2.539 (2.478) | 2.472 (2.244) | -1.2% | -2.7% | yes |
| icm8-bb-call | 0.602 (0.580) | 0.685 (0.509) | 0.630 (0.581) | +4.7% | -7.9% | yes |

**Decision: not adopted.** No fixture shows the 3% the rule asks for; every difference is inside the run-to-run spread
of one build (compare a build's median with its minimum). The states of the three builds are byte-identical, as they
must be. The line was removed from the source; the 5.9 trainer's lookup is the 5.8 lookup.

**Why it does not help, and what does.** The chain has four links; the prefetch overlaps only the first two, and the
out-of-order core already starts the `hrow` read speculatively once the key comparison is predicted. The two links that
cost most - the row record and the values - still wait for one another. Removing a link needs the value offset next to
the hash slot. 5.9 does exactly that where it is free of side effects: the EVALUATION of a trained response builds a
32-bit offset per hash slot for the duration of one call (`SlotIndex59`, response59.hpp) and is 1.2 to 2.3 times faster
for it (PERFORMANCE-5.9.md, section 2). In the trainer the same index would have to be maintained while rows are added
and the hash table grows, and its 4 bytes per slot would have to be charged to the table budget - which moves the point
at which a table limit is reached, that is, changes trained states at a memory limit. That is a format-level change
(the conclusion 5.8 reached as well) and is left for a release that changes the state format deliberately.
