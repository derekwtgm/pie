#!/usr/bin/env python3
"""EightMax 5.9: records the reference responses of validation/5.9/windows/response from a Linux build.
Usage: make_golden59.py <release root> <mwcli>

For each case: the engine spec (tools/games58.js, seed 1), the trained state's SHA-256 and, with the 5.9 evaluation
streams, for every seat the bit patterns of the response gain estimated from independent deals, of its sample variance,
of its exact value and of the exact best-response gain, and the bit patterns of the four bounds of the summary
(simultaneous: sum of response gains, NashConv; pooled: all seats, best subset).
validate_windows59.ps1 (section "trained response"), tests/v59.test.js and validation/5.9/wine59.sh require another
build or platform to reproduce them exactly. request-58-streams.json is the request of the 5.8 references with
{"randomStreams":"5.8"}: with it this build must reproduce validation/5.8/windows/response/golden58.json."""
import sys, json, subprocess, pathlib, hashlib, tempfile, shutil
root = pathlib.Path(sys.argv[1]).resolve(); cli = str(pathlib.Path(sys.argv[2]).resolve()); out = root / 'validation/5.9/windows/response'; out.mkdir(parents=True, exist_ok=True)
CASES = [('hu-river', 20000), ('river3-chip', 20000), ('turn4', 20000), ('flop6', 20000), ('mid3-turn', 10000), ('sidepot3-icm', 20000), ('bubble4', 5000)]
request = {'responseDeals': 100000, 'samples': 20480, 'seed': 59, 'exact': True, 'threads': 1}
(out / 'request.json').write_text(json.dumps(request)); (out / 'request-parallel.json').write_text(json.dumps({**request, 'parallelSeats': 2, 'threads': 2}))
old = json.loads((root / 'validation/5.8/windows/response/request.json').read_text()); (out / 'request-58-streams.json').write_text(json.dumps({**old, 'randomStreams': '5.8'}))
(out / 'example-request.json').write_text(json.dumps({'responseDeals': 400000, 'samples': 409600, 'seed': 59, 'exact': True, 'parallelSeats': 3, 'futureActions': 'sample'}))
fx = json.loads((root / 'studies/flop6-jack-small.emfix.json').read_text(encoding='utf-8-sig')); (out / 'flop6-jack-small.spec.json').write_text(json.dumps(fx['variants'][0]['nativeSpec']))
work = pathlib.Path(tempfile.mkdtemp()); cases = []
try:
    for key, updates in CASES:
        spec = out / (key + '.spec.json'); subprocess.run(['node', str(root / 'source/tools/games58.js'), 'spec', key, str(spec), '1'], check=True)
        state = work / (key + '.state'); subprocess.run([cli, str(spec), str(updates), '1', str(state), '256'], check=True, capture_output=True)
        d = json.loads(subprocess.run([cli, '--response', str(spec), str(state), str(out / 'request.json'), '256'], check=True, capture_output=True, text=True).stdout)
        p = json.loads(subprocess.run([cli, '--response', str(spec), str(state), str(out / 'request-parallel.json'), '256'], check=True, capture_output=True, text=True).stdout)
        bits = lambda doc: ['%d:%s:%s:%s:%s' % (s['seat'], s['sampled']['gain']['gainBits'], s['sampled']['statistics']['sampleVarianceBits'], s['exact']['gainBits'], s['exact']['bestResponseGainBits']) for s in doc['seats']]
        sums = lambda doc: [doc['summary']['simultaneous']['bits']['sumOfResponseGainsLowerBound'], doc['summary']['simultaneous']['bits']['nashConvLowerBound'], doc['summary']['pooledIndependent']['bits']['sumOfResponseGainsLowerBound'], doc['summary']['pooledIndependent']['bits']['bestSubset']]
        assert bits(d) == bits(p) and sums(d) == sums(p), key; a = d['summary']['againstExact']; assert a['simultaneousHolds'] and a['simultaneousNashConvBoundHolds'] and a['pooledAllSeatsHolds'] and a['pooledBestSubsetHolds'], key
        cases.append({'name': key, 'spec': spec.name, 'updates': updates, 'memoryMiB': 256, 'request': 'request.json', 'parallelRequest': 'request-parallel.json', 'stateSha256': hashlib.sha256(state.read_bytes()).hexdigest(), 'seatBits': bits(d), 'summaryBits': sums(d),
                      'exactNashConv': d['summary']['exactNashConv'], 'exactSumOfSeatGains': d['summary']['exactSumOfSeatGains'], 'sampledSumOfSeatGains': d['summary']['sumOfSeatGains']['mean'], 'simultaneousNashConvLowerBound': d['summary']['simultaneous']['nashConvLowerBound'], 'pooledNashConvLowerBound': d['summary']['pooledIndependent']['nashConvLowerBound']})
        print(key, cases[-1]['stateSha256'][:16], 'exact NashConv', round(cases[-1]['exactNashConv'], 4), 'simultaneous', round(cases[-1]['simultaneousNashConvLowerBound'], 4), 'pooled', round(cases[-1]['pooledNashConvLowerBound'], 4), flush=True)
finally: shutil.rmtree(work, ignore_errors=True)
build = subprocess.run([cli, '--build-id'], capture_output=True, text=True).stdout.strip()
(out / 'golden59.json').write_text(json.dumps({'what': 'Reference responses of EightMax 5.9 (5.9 evaluation streams), recorded on Linux x86-64. seatBits: seat : IEEE 754 bits of the gain estimated from independent deals : of its sample variance : of the exact response gain : of the exact best-response gain. summaryBits: simultaneous sum of response gains, simultaneous NashConv bound, pooled all seats, pooled best subset.',
    'recordedBy': build, 'request': request, 'cases': cases}, indent=1))
