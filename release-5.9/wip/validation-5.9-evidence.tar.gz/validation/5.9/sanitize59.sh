#!/bin/bash
# EightMax 5.9 sanitizer runs: the code 5.9 added or touched (the evaluation walk and its offset index, the counter-based
# streams, the summary statistics, the response command line, the desktop host's undo of a refused study) and the code
# they run through. Usage: bash validation/5.9/sanitize59.sh <release root> <work dir>
#  1. AddressSanitizer + UndefinedBehaviorSanitizer + float-cast-overflow build of the host and CLI (the 5.3 builder);
#     then mwcli --selftest59 (all sections), --selftest58 (all sections), the response, stream and desktop-host tests
#     of the 5.9 regression file, and tools/host_refusal59.js against the instrumented host with its stderr kept.
#  2. ThreadSanitizer build of the CLI: responses of six seats, three side by side, with four evaluation threads each
#     (the shared offset index is read by all of them); frozen-batch response training on four threads; an ICM game with
#     parallel seats; both kinds of streams; mwcli --selftest59 (engine and statistics sections); the bits of the
#     instrumented program against the release program.
#  3. Leak check: the ASan CLI with detect_leaks=1 on a complete --response run with parallel seats, on an evaluation
#     that cannot finish in its time limit, and on a refused over-limit study.
set -u
root=$(cd "$1" && pwd); work=$2; out="$root/validation/5.9/sanitizers"; rm -rf "$work" "$out"; mkdir -p "$work" "$out"
T="$root/source/tests"; R="$root/validation/5.9/windows/response"
bash "$root/validation/5.3/sanitizers/build-final.sh" "$root/source" "$root/build" "$work/asan" > "$out/build-asan-ubsan.log" 2>&1; echo "asan build exit $?" | tee "$out/build-asan-ubsan.exit"
export ASAN_OPTIONS=detect_leaks=0:abort_on_error=0 UBSAN_OPTIONS=print_stacktrace=1
"$work/asan/mwcli" --selftest59 "$root/studies" "$work/st59-asan" all > "$out/selftest59-asan.stdout" 2> "$out/selftest59-asan.stderr"; echo "asan selftest59 exit $?" | tee "$out/selftest59-asan.exit"
cp "$work/st59-asan/selftest59.json" "$out/selftest59-asan.json" 2>/dev/null
"$work/asan/mwcli" --selftest58 "$root/studies" "$work/st58-asan" all > "$out/selftest58-asan.stdout" 2> "$out/selftest58-asan.stderr"; echo "asan selftest58 exit $?" | tee "$out/selftest58-asan.exit"
cp "$work/st58-asan/selftest58.json" "$out/selftest58-asan.json" 2>/dev/null
printf '#!/bin/sh\nexec "%s" "$@" 2>>"%s"\n' "$work/asan/eightmax" "$out/host-stderr.log" > "$work/asan/eightmax-keep-stderr"; chmod +x "$work/asan/eightmax-keep-stderr"; : > "$out/host-stderr.log"
EM_TEST_MWCLI="$work/asan/mwcli" EM_TEST_HOST="$work/asan/eightmax-keep-stderr" PATH="$PATH:$HOME/.dotnet/tools" \
  node --test --test-concurrency=1 --test-reporter=tap --test-name-pattern='5.9 response|5.9 streams|5.9 statistics and streams|5.9 desktop host|5.9 reference responses' "$T/v59.test.js" > "$out/v59-asan-ubsan.tap" 2> "$out/v59-asan-ubsan.stderr"
echo "asan tests (5.9 file: response, streams, statistics, desktop host, references) exit $?" | tee "$out/v59-asan-ubsan.exit"; tail -9 "$out/v59-asan-ubsan.tap"
grep -c -E 'ERROR: AddressSanitizer|runtime error:' "$out"/*.tap "$out"/*.stderr "$out"/*.stdout "$out/host-stderr.log" 2>/dev/null | tee "$out/sanitizer-report-counts.txt"
# 2
obj="$work/tsan"; mkdir -p "$obj"; printf '#define EM_VERSION "5.9"\n#define EM_BUILD_ID "tsan"\n' > "$obj/build_info.h"
( cd "$root/source/native" && g++ -std=c++20 -O1 -g1 -fsanitize=thread -fno-omit-frame-pointer -march=x86-64 -ffp-contract=off -I. -c mw.cpp -o "$obj/mw.o" && gcc -O1 -fsanitize=thread -c json.c -o "$obj/json.o" &&
  g++ -std=c++20 -O1 -g1 -fsanitize=thread -march=x86-64 -ffp-contract=off -I. -include "$obj/build_info.h" mwcli.cpp "$obj/mw.o" "$obj/json.o" -lpthread -ldl -lz -o "$obj/mwcli" ) > "$out/build-tsan.log" 2>&1; echo "tsan build exit $?" | tee "$out/build-tsan.exit"
export TSAN_OPTIONS=halt_on_error=0
{ node "$root/source/tools/games58.js" spec flop6 "$work/f6.json" 7 '{"batchDeals":8,"actionStreams":"deal"}'
  "$obj/mwcli" "$work/f6.json" 600 4 "$work/f6.state" 128 > /dev/null; echo "frozen-batch training on four threads exit $?"
  echo '{"responseDeals":8000,"samples":8192,"seed":59,"exact":true,"parallelSeats":3,"threads":4}' > "$work/rq.json"
  "$obj/mwcli" --response "$work/f6.json" "$work/f6.state" "$work/rq.json" 128 > "$work/f6-response.json"; echo "six seats, three side by side, four threads each (5.9 streams, offset index) exit $?"
  echo '{"responseDeals":8000,"samples":8192,"seed":59,"parallelSeats":2,"threads":4,"randomStreams":"5.8","futureActions":"sample"}' > "$work/rq58.json"
  "$obj/mwcli" --response "$work/f6.json" "$work/f6.state" "$work/rq58.json" 128 > "$work/f6-response-58.json"; echo "the 5.8 streams, sampled opponent actions, four threads exit $?"
  "$obj/mwcli" "$R/bubble4.spec.json" 1500 4 "$work/b4.state" 128 > /dev/null; echo "ICM frozen-batch training exit $?"
  echo '{"responseDeals":8000,"samples":4096,"seed":59,"exact":true,"parallelSeats":4,"threads":2}' > "$work/rq4.json"
  "$obj/mwcli" --response "$R/bubble4.spec.json" "$work/b4.state" "$work/rq4.json" 128 > "$work/b4-response.json"; echo "ICM response, four seats side by side exit $?"
  "$obj/mwcli" --selftest59 "$root/studies" "$work/st59-tsan" engine; echo "selftest59 (engine) exit $?"
  "$obj/mwcli" --selftest59 "$root/studies" "$work/st59-tsan-s" statistics; echo "selftest59 (statistics) exit $?"; } > "$out/tsan.log" 2>&1
echo "ThreadSanitizer warnings: $(grep -c 'WARNING: ThreadSanitizer' "$out/tsan.log")" | tee "$out/tsan-summary.txt"; grep -E 'exit [0-9]+' "$out/tsan.log" | tee -a "$out/tsan-summary.txt"
"$root/build/linux/mwcli" --response "$work/f6.json" "$work/f6.state" "$work/rq.json" 128 > "$work/f6-response-release.json" 2>/dev/null
"$root/build/linux/mwcli" --response "$work/f6.json" "$work/f6.state" "$work/rq58.json" 128 > "$work/f6-response-58-release.json" 2>/dev/null
python3 - "$work/f6-response.json" "$work/f6-response-release.json" "$work/f6-response-58.json" "$work/f6-response-58-release.json" <<'PY' | tee -a "$out/tsan-summary.txt"
import json, sys
a, b, c, d = (json.load(open(f)) for f in sys.argv[1:5]); bits = lambda x: [(s['seat'], s['sampled']['gain']['gainBits'], s['sampled']['statistics']['sampleVarianceBits']) for s in x['seats']]
print('response bits of the instrumented program equal the release program: 5.9 streams', bits(a) == bits(b), '5.8 streams', bits(c) == bits(d), '(%d seats)' % len(a['seats']))
PY
# 3
echo '{"responseDeals":20000,"samples":4096,"seed":59,"exact":true,"parallelSeats":2}' > "$work/rql.json"; echo '{"responseDeals":1000,"samples":1000000000,"seed":59,"timeLimitMs":100}' > "$work/rqu.json"
"$root/build/linux/mwcli" "$R/turn4.spec.json" 5000 1 "$work/t4.state" 128 > /dev/null
ASAN_OPTIONS=detect_leaks=1 "$work/asan/mwcli" --response "$R/turn4.spec.json" "$work/t4.state" "$work/rql.json" 128 > /dev/null 2> "$out/leak-response.log"; echo "$?" > "$out/leak-response.exit"
ASAN_OPTIONS=detect_leaks=1 "$work/asan/mwcli" --response "$R/turn4.spec.json" "$work/t4.state" "$work/rqu.json" 128 > /dev/null 2> "$out/leak-incomplete.log"; echo "$?" > "$out/leak-incomplete.exit"
ASAN_OPTIONS=detect_leaks=1 "$work/asan/mwcli" --study "$root/studies/known-akq-river.emfix.json" "$work/over.json" quiet=1 seeds=1 budgets=10000001 > /dev/null 2> "$out/leak-refused-study.log"; echo "$?" > "$out/leak-refused-study.exit"
echo "leak check: --response with parallel seats exit $(cat "$out/leak-response.exit") (0 expected), evaluation that cannot finish exit $(cat "$out/leak-incomplete.exit") (0 expected), refused over-limit study exit $(cat "$out/leak-refused-study.exit") (1 expected); LeakSanitizer reports: $(cat "$out/leak-response.log" "$out/leak-incomplete.log" "$out/leak-refused-study.log" | grep -c 'ERROR: LeakSanitizer')" | tee "$out/leak-summary.txt"
{ cat "$out"/build-asan-ubsan.exit "$out"/selftest59-asan.exit "$out"/selftest58-asan.exit "$out"/v59-asan-ubsan.exit "$out"/build-tsan.exit
  grep -E '^# (tests|pass|fail|skipped)' "$out/v59-asan-ubsan.tap" | tr '\n' ' '; echo "(v59-asan-ubsan)"
  echo "sanitizer reports (ERROR: AddressSanitizer / runtime error) in all outputs: $(awk -F: '{s+=$NF} END{print s+0}' "$out/sanitizer-report-counts.txt")"
  cat "$out/tsan-summary.txt" "$out/leak-summary.txt"; } > "$out/summary.txt"
cat "$out/summary.txt"
